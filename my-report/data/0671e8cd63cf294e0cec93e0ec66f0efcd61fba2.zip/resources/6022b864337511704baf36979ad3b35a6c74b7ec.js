define("PHICore_TH.referencesHealth$OutSystemsCharts", [], function () {
// Reference to producer 'OutSystemsCharts' is OK.
});
define("PHICore_TH.referencesHealth$OutSystemsUI", [], function () {
// Reference to producer 'OutSystemsUI' is OK.
});
define("PHICore_TH.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("PHICore_TH.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("PHICore_TH.referencesHealth", [], function () {
});
