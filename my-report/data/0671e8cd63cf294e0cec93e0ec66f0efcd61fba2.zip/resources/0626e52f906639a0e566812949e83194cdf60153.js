define("PHICore.Common_Widgets.SearchFilterPopup.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "OutSystemsUI.model", "Common_CW.controller", "Common_CS.model", "PHICore.model$KeyValuePairList", "PHICore.model$DropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptiRecord", "PHICore.model$SearchFilterRec", "PHICore.model$CaseFilterSearchFilterRecord", "PHICore.model$DropdownOptionList", "OutSystemsUI.model$DropdownTagsOptionalConfigsRec", "PHICore.referencesHealth", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$ClearDropdownTag", "PHICore.referencesHealth$Common_CW", "PHICore.model$TextText2RecordList", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$UserIdentifierTextRecordList", "Common_CW.controller$Set_Focus", "PHICore.model$CategoryRecordList", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusRecordList", "PHICore.model$PriorityRecordList", "PHICore.model$SubCategoryRecordList", "PHICore.model$UserRecordList", "PHICore.model$SLARecordList"], function (OutSystems, PHICoreModel, OutSystemsUIModel, Common_CWController, Common_CSModel) {
var OS = OutSystems.Internal;
var GetCategoriesAggrRec = (function (_super) {
__extends(GetCategoriesAggrRec, _super);
function GetCategoriesAggrRec(defaults) {
_super.apply(this, arguments);
}
GetCategoriesAggrRec.RecordListType = PHICoreModel.CategoryRecordList;
GetCategoriesAggrRec.init();
return GetCategoriesAggrRec;
})(OS.Model.AggregateRecord);
var GetUsersAssignedToAggrRec = (function (_super) {
__extends(GetUsersAssignedToAggrRec, _super);
function GetUsersAssignedToAggrRec(defaults) {
_super.apply(this, arguments);
}
GetUsersAssignedToAggrRec.RecordListType = PHICoreModel.UserIdentifierTextRecordList;
GetUsersAssignedToAggrRec.init();
return GetUsersAssignedToAggrRec;
})(OS.Model.AggregateRecord);
var GetTeamsAggrRec = (function (_super) {
__extends(GetTeamsAggrRec, _super);
function GetTeamsAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamsAggrRec.RecordListType = PHICoreModel.TeamTeamUserRecordList;
GetTeamsAggrRec.init();
return GetTeamsAggrRec;
})(OS.Model.AggregateRecord);
var GetStatusesAggrRec = (function (_super) {
__extends(GetStatusesAggrRec, _super);
function GetStatusesAggrRec(defaults) {
_super.apply(this, arguments);
}
GetStatusesAggrRec.RecordListType = PHICoreModel.StatusRecordList;
GetStatusesAggrRec.init();
return GetStatusesAggrRec;
})(OS.Model.AggregateRecord);
var GetPrioritiesAggrRec = (function (_super) {
__extends(GetPrioritiesAggrRec, _super);
function GetPrioritiesAggrRec(defaults) {
_super.apply(this, arguments);
}
GetPrioritiesAggrRec.RecordListType = PHICoreModel.PriorityRecordList;
GetPrioritiesAggrRec.init();
return GetPrioritiesAggrRec;
})(OS.Model.AggregateRecord);
var GetSubCategoryAggrRec = (function (_super) {
__extends(GetSubCategoryAggrRec, _super);
function GetSubCategoryAggrRec(defaults) {
_super.apply(this, arguments);
}
GetSubCategoryAggrRec.RecordListType = PHICoreModel.SubCategoryRecordList;
GetSubCategoryAggrRec.init();
return GetSubCategoryAggrRec;
})(OS.Model.AggregateRecord);
var GetUsersRaisedByAggrRec = (function (_super) {
__extends(GetUsersRaisedByAggrRec, _super);
function GetUsersRaisedByAggrRec(defaults) {
_super.apply(this, arguments);
}
GetUsersRaisedByAggrRec.RecordListType = PHICoreModel.UserRecordList;
GetUsersRaisedByAggrRec.init();
return GetUsersRaisedByAggrRec;
})(OS.Model.AggregateRecord);
var GetSLAsAggrRec = (function (_super) {
__extends(GetSLAsAggrRec, _super);
function GetSLAsAggrRec(defaults) {
_super.apply(this, arguments);
}
GetSLAsAggrRec.RecordListType = PHICoreModel.SLARecordList;
GetSLAsAggrRec.init();
return GetSLAsAggrRec;
})(OS.Model.AggregateRecord);

var GetJoinedFiltersDataActRec = (function (_super) {
__extends(GetJoinedFiltersDataActRec, _super);
function GetJoinedFiltersDataActRec(defaults) {
_super.apply(this, arguments);
}
GetJoinedFiltersDataActRec.attributesToDeclare = function () {
return [
this.attr("Joined_Category", "joined_CategoryOut", "Joined_Category", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Joined_SubCategory", "joined_SubCategoryOut", "Joined_SubCategory", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Joined_Teams", "joined_TeamsOut", "Joined_Teams", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Joined_AssignedTo", "joined_AssignedToOut", "Joined_AssignedTo", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetJoinedFiltersDataActRec.init();
return GetJoinedFiltersDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("AssignedToList", "assignedToListVar", "AssignedToList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.KeyValuePairList());
}, false, PHICoreModel.KeyValuePairList), 
this.attr("DropdownTagValueHolder", "dropdownTagValueHolderVar", "DropdownTagValueHolder", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.DropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptiRecord());
}, false, PHICoreModel.DropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptiRecord), 
this.attr("JoinedCategory", "joinedCategoryVar", "JoinedCategory", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("JoinedSubCategory", "joinedSubCategoryVar", "JoinedSubCategory", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("JoinedTeams", "joinedTeamsVar", "JoinedTeams", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("JoinedAssignedTo", "joinedAssignedToVar", "JoinedAssignedTo", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("Search_Filter", "search_FilterVar", "Search_Filter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("ExistingSearchFilter", "existingSearchFilterVar", "ExistingSearchFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseFilterSearchFilterRecord());
}, false, PHICoreModel.CaseFilterSearchFilterRecord), 
this.attr("IsValid", "isValidVar", "IsValid", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("FilterIndictor", "filterIndictorIn", "FilterIndictor", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_filterIndictorInDataFetchStatus", "_filterIndictorInDataFetchStatus", "_filterIndictorInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SearchFilter_Input", "searchFilter_InputIn", "SearchFilter_Input", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("_searchFilter_InputInDataFetchStatus", "_searchFilter_InputInDataFetchStatus", "_searchFilter_InputInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetCategories", "getCategoriesAggr", "getCategoriesAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCategoriesAggrRec());
}, true, GetCategoriesAggrRec), 
this.attr("GetUsersAssignedTo", "getUsersAssignedToAggr", "getUsersAssignedToAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetUsersAssignedToAggrRec());
}, true, GetUsersAssignedToAggrRec), 
this.attr("GetTeams", "getTeamsAggr", "getTeamsAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamsAggrRec());
}, true, GetTeamsAggrRec), 
this.attr("GetStatuses", "getStatusesAggr", "getStatusesAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetStatusesAggrRec());
}, true, GetStatusesAggrRec), 
this.attr("GetPriorities", "getPrioritiesAggr", "getPrioritiesAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetPrioritiesAggrRec());
}, true, GetPrioritiesAggrRec), 
this.attr("GetSubCategory", "getSubCategoryAggr", "getSubCategoryAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetSubCategoryAggrRec());
}, true, GetSubCategoryAggrRec), 
this.attr("GetUsersRaisedBy", "getUsersRaisedByAggr", "getUsersRaisedByAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetUsersRaisedByAggrRec());
}, true, GetUsersRaisedByAggrRec), 
this.attr("GetSLAs", "getSLAsAggr", "getSLAsAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetSLAsAggrRec());
}, true, GetSLAsAggrRec), 
this.attr("GetJoinedFilters", "getJoinedFiltersDataAct", "getJoinedFiltersDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetJoinedFiltersDataActRec());
}, true, GetJoinedFiltersDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form1: OS.Model.ValidationWidgetRecord,
Input_DueDateFromDatePicked: OS.Model.ValidationWidgetRecord,
Input_DueDateToDatePicked: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("FilterIndictor" in inputs) {
this.variables.filterIndictorIn = inputs.FilterIndictor;
if("_filterIndictorInDataFetchStatus" in inputs) {
this.variables._filterIndictorInDataFetchStatus = inputs._filterIndictorInDataFetchStatus;
}

}

if("SearchFilter_Input" in inputs) {
this.variables.searchFilter_InputIn = inputs.SearchFilter_Input;
if("_searchFilter_InputInDataFetchStatus" in inputs) {
this.variables._searchFilter_InputInDataFetchStatus = inputs._searchFilter_InputInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.SearchFilterPopup");
});
define("PHICore.Common_Widgets.SearchFilterPopup.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "OutSystemsUI.model", "Common_CW.controller", "Common_CS.model", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.SearchFilterPopup.mvc$model", "PHICore.Common_Widgets.SearchFilterPopup.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Interaction.DropdownTags.mvc$view", "Common_CW.PHICore_CW.PreviousFocus.mvc$view", "PHICore.model$KeyValuePairList", "PHICore.model$DropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptiRecord", "PHICore.model$SearchFilterRec", "PHICore.model$CaseFilterSearchFilterRecord", "PHICore.model$DropdownOptionList", "OutSystemsUI.model$DropdownTagsOptionalConfigsRec", "PHICore.referencesHealth", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$ClearDropdownTag", "PHICore.referencesHealth$Common_CW", "PHICore.model$TextText2RecordList", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$UserIdentifierTextRecordList", "Common_CW.controller$Set_Focus", "PHICore.model$CategoryRecordList", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusRecordList", "PHICore.model$PriorityRecordList", "PHICore.model$SubCategoryRecordList", "PHICore.model$UserRecordList", "PHICore.model$SLARecordList"], function (OutSystems, PHICoreModel, PHICoreController, OutSystemsUIModel, Common_CWController, Common_CSModel, React, OSView, PHICore_Common_Widgets_SearchFilterPopup_mvc_model, PHICore_Common_Widgets_SearchFilterPopup_mvc_controller, PHICoreClientVariables, OSWidgets, OutSystemsUI_Interaction_DropdownTags_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.SearchFilterPopup";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Interaction_DropdownTags_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_SearchFilterPopup_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_SearchFilterPopup_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "margin-bottom: 20px;"
},
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 18px;"
},
text: ["Filter"],
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
name: "DueDateFrom"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_DueDateFromDatePicked",
_idProps: {
service: idService,
name: "Label_DueDateFrom"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "heading",
text: ["Due Date From"],
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
extendedProperties: {
max: "9999-12-31",
"aria-labelledby": idService.getId("Label_DueDateFrom")
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Date*/ 4,
mandatory: false,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup/Input_DueDateFromDatePicked OnChange");
controller.input_DueDateFromDatePickedOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
prompt: "dd/mm/yyyy",
style: model.getCachedValue(idService.getId("Input_DueDateFromDatePicked.Style"), function () {
return ("form-control margin-bottom-none" + ((model.variables.isValidVar) ? ("") : (" not-valid")));
}, function () {
return model.variables.isValidVar;
}),
variable: model.createVariable(OS.Types.Date, model.variables.search_FilterVar.dueDateFromAttr, function (value) {
model.variables.search_FilterVar.dueDateFromAttr = value;
}),
_idProps: {
service: idService,
name: "Input_DueDateFromDatePicked"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if(!(model.variables.isValidVar), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: "Select a start date that is on or before the end date.",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
name: "DueDateTo"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_DueDateToDatePicked",
_idProps: {
service: idService,
name: "Label_DueDateTo"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "heading",
text: ["Due Date To"],
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
extendedProperties: {
max: "9999-12-31",
"aria-labelledby": idService.getId("Label_DueDateTo")
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Date*/ 4,
mandatory: false,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup/Input_DueDateToDatePicked OnChange");
controller.input_DueDateToDatePickedOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
prompt: "dd/mm/yyyy",
style: model.getCachedValue(idService.getId("Input_DueDateToDatePicked.Style"), function () {
return ("form-control margin-bottom-none" + ((model.variables.isValidVar) ? ("") : (" not-valid")));
}, function () {
return model.variables.isValidVar;
}),
variable: model.createVariable(OS.Types.Date, model.variables.search_FilterVar.dueDateToAttr, function (value) {
model.variables.search_FilterVar.dueDateToAttr = value;
}),
_idProps: {
service: idService,
name: "Input_DueDateToDatePicked"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if(!(model.variables.isValidVar), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: "Select an end date that is on or after the start date.",
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
name: "Category"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Category")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
StartingSelection: model.variables.dropdownTagValueHolderVar.categoryAttr,
OptionsList: model.getCachedValue(idService.getId("Dropdown_Category.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getCategoriesAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.categoryAttr.idAttr);
target.labelAttr = source.categoryAttr.descriptionAttr;
return target;
});
}, function () {
return model.variables.getCategoriesAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCategoriesAggr.dataFetchStatusAttr),
Prompt: "Select"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
return controller.onChangedCategory$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_Category",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
name: "SubCategory"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Sub-Category")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "Container_SubCategory"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
Prompt: "Select",
StartingSelection: model.variables.dropdownTagValueHolderVar.subCategoryAttr,
OptionalConfigs: model.getCachedValue(idService.getId("Dropdown_SubCategory.OptionalConfigs"), function () {
return function () {
var rec = new OutSystemsUIModel.DropdownTagsOptionalConfigsRec();
return rec;
}();
}),
OptionsList: model.getCachedValue(idService.getId("Dropdown_SubCategory.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getSubCategoryAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.subCategoryAttr.idAttr);
target.labelAttr = source.subCategoryAttr.nameAttr;
return target;
});
}, function () {
return model.variables.getSubCategoryAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getSubCategoryAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedSubCategory$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_SubCategory",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
name: "SLA"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, "SLA")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
StartingSelection: model.variables.dropdownTagValueHolderVar.sLAsAttr,
Prompt: "Select",
OptionsList: model.getCachedValue(idService.getId("Dropdown_SLA.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getSLAsAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = (source.sLAAttr.idAttr).toString();
target.labelAttr = source.sLAAttr.labelAttr;
return target;
});
}, function () {
return model.variables.getSLAsAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getSLAsAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedSLAs$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_SLA",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
name: "Priority"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Priority")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
StartingSelection: model.variables.dropdownTagValueHolderVar.priorityAttr,
OptionsList: model.getCachedValue(idService.getId("Dropdown_Priority.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getPrioritiesAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = (source.priorityAttr.idAttr).toString();
target.labelAttr = source.priorityAttr.labelAttr;
return target;
});
}, function () {
return model.variables.getPrioritiesAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getPrioritiesAggr.dataFetchStatusAttr),
Prompt: "Select"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedPriority$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_Priority",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
name: "Status"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Status")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
Prompt: "Select",
StartingSelection: model.variables.dropdownTagValueHolderVar.statusAttr,
OptionsList: model.getCachedValue(idService.getId("Dropdown_Status.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getStatusesAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = (source.statusAttr.idAttr).toString();
target.labelAttr = source.statusAttr.labelAttr;
return target;
});
}, function () {
return model.variables.getStatusesAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getStatusesAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedStatus$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_Status",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
name: "RaisedBy"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Raised By")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
OptionsList: model.getCachedValue(idService.getId("Dropdown_RaisedBy.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getUsersRaisedByAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = (source.userAttr.idAttr).toString();
target.labelAttr = source.userAttr.nameAttr;
return target;
});
}, function () {
return model.variables.getUsersRaisedByAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getUsersRaisedByAggr.dataFetchStatusAttr),
StartingSelection: model.variables.dropdownTagValueHolderVar.raisedByAttr,
Prompt: "Select"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedRaisedBy$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_RaisedBy",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: (model.variables.filterIndictorIn === 1),
_idProps: {
service: idService,
name: "Team"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._filterIndictorInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Team")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "56"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
OptionsList: model.getCachedValue(idService.getId("Dropdown_Team.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getTeamsAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.teamAttr.idAttr);
target.labelAttr = source.teamAttr.nameAttr;
return target;
});
}, function () {
return model.variables.getTeamsAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsAggr.dataFetchStatusAttr),
StartingSelection: model.variables.dropdownTagValueHolderVar.teamsAttr,
Prompt: "Select"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
return controller.onChangedTeams$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_Team",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: (model.variables.filterIndictorIn === 1),
_idProps: {
service: idService,
name: "AssignedTo"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._filterIndictorInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Assigned to")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_DropdownTags_mvc_view, {
inputs: {
Prompt: "Select",
OptionalConfigs: model.getCachedValue(idService.getId("Dropdown_AssignedTo.OptionalConfigs"), function () {
return function () {
var rec = new OutSystemsUIModel.DropdownTagsOptionalConfigsRec();
rec.isDisabledAttr = ((!(model.variables.getJoinedFiltersDataAct.isDataFetchedAttr) && !(model.variables.getTeamsAggr.isDataFetchedAttr)) && !(model.variables.getUsersAssignedToAggr.isDataFetchedAttr));
return rec;
}();
}, function () {
return model.variables.getJoinedFiltersDataAct.isDataFetchedAttr;
}, function () {
return model.variables.getTeamsAggr.isDataFetchedAttr;
}, function () {
return model.variables.getUsersAssignedToAggr.isDataFetchedAttr;
}),
StartingSelection: model.variables.dropdownTagValueHolderVar.assignedToAttr,
OptionsList: model.getCachedValue(idService.getId("Dropdown_AssignedTo.OptionsList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getUsersAssignedToAggr.listOut, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = (source.idAttr).toString();
target.labelAttr = source.nameAttr;
return target;
});
}, function () {
return model.variables.getUsersAssignedToAggr.listOut;
}),
_optionsListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getUsersAssignedToAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onChanged$Action: function (dropdownTagsIdIn, selectedOptionListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/DropdownTags OnChanged");
controller.onChangedAssignedTo$Action(selectedOptionListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "Dropdown_AssignedTo",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width12"
},
style: "display-flex justify-content-space-between",
visible: true,
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
uuid: "64"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup/Button OnClick");
controller.closeFilter$Action(model.variables.existingSearchFilterVar.searchAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "65"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Cancel"), React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup/btnClear OnClick");
return controller.onClear$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
name: "btnClear"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Clear")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup/Btn_Apply OnClick");
return controller.onClickApply$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "Btn_Apply"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Apply")))), React.createElement(Common_CW_PHICore_CW_PreviousFocus_mvc_view, {
inputs: {
CurrentElement: ("#" + idService.getId("Input_DueDateFromDatePicked")),
CurrentWidgetId: idService.getId("PreviousFocus"),
PreviousElement: ("#" + idService.getId("Btn_Apply"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
name: "PreviousFocus",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.SearchFilterPopup.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "OutSystemsUI.model", "Common_CW.controller", "Common_CS.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.SearchFilterPopup.mvc$debugger", "PHICore.Common_Widgets.SearchFilterPopup.mvc$controller.OnClear.JavaScriptRemoveValueJS", "PHICore.Common_Widgets.SearchFilterPopup.mvc$controller.OnReady.OnTabbingJavascriptJS", "PHICore.model$KeyValuePairList", "PHICore.model$DropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptionListDropdownOptiRecord", "PHICore.model$SearchFilterRec", "PHICore.model$CaseFilterSearchFilterRecord", "PHICore.model$DropdownOptionList", "OutSystemsUI.model$DropdownTagsOptionalConfigsRec", "PHICore.referencesHealth", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$ClearDropdownTag", "PHICore.referencesHealth$Common_CW", "PHICore.model$TextText2RecordList", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$UserIdentifierTextRecordList", "Common_CW.controller$Set_Focus", "PHICore.model$CategoryRecordList", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusRecordList", "PHICore.model$PriorityRecordList", "PHICore.model$SubCategoryRecordList", "PHICore.model$UserRecordList", "PHICore.model$SLARecordList"], function (OutSystems, PHICoreModel, PHICoreController, OutSystemsUIModel, Common_CWController, Common_CSModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_SearchFilterPopup_mvc_Debugger, PHICore_Common_Widgets_SearchFilterPopup_mvc_controller_OnClear_JavaScriptRemoveValueJS, PHICore_Common_Widgets_SearchFilterPopup_mvc_controller_OnReady_OnTabbingJavascriptJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getCategories$AggrRefresh: 0,
getUsersAssignedTo$AggrRefresh: -1,
getTeams$AggrRefresh: 0,
getStatuses$AggrRefresh: 0,
getPriorities$AggrRefresh: 0,
getSubCategory$AggrRefresh: -1,
getUsersRaisedBy$AggrRefresh: 0,
getSLAs$AggrRefresh: 0,
getJoinedFilters$DataActRefresh: -1
};
this.dataFetchDependentsGraph = {
getCategories$AggrRefresh: [],
getUsersAssignedTo$AggrRefresh: [],
getTeams$AggrRefresh: [],
getStatuses$AggrRefresh: [],
getPriorities$AggrRefresh: [],
getSubCategory$AggrRefresh: [],
getUsersRaisedBy$AggrRefresh: [],
getSLAs$AggrRefresh: [],
getJoinedFilters$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getCategories$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:VpdQD0rslEiXaxICqMV8CA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.VpdQD0rslEiXaxICqMV8CA:RRyqYe+GTuXeqxW5+gJO7A", "PHICore", "GetCategories", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetCategories");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetCategories", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetCategories", "dWk51msw8dYRW94B+0RMNw", maxRecords, startIndex, function (b) {
model.variables.getCategoriesAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCategoriesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCategoriesAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetCategories On After Fetch");
return controller._getCategoriesOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:VpdQD0rslEiXaxICqMV8CA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getUsersAssignedTo$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:0mOrHmVYfkiPNuQ6DduZbw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.0mOrHmVYfkiPNuQ6DduZbw:yio6_7kEnKy1rQ+mXsPpzQ", "PHICore", "GetUsersAssignedTo", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetUsersAssignedTo");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetUsersAssignedTo", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetUsersAssignedTo", "jbTOT5mvQFMmaJ3rjm1AGw", maxRecords, startIndex, function (b) {
model.variables.getUsersAssignedToAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getUsersAssignedToAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getUsersAssignedToAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:0mOrHmVYfkiPNuQ6DduZbw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getTeams$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:7YtbOjpzWUS4bgDT3ElHrA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.7YtbOjpzWUS4bgDT3ElHrA:Cv_xPigqphSnvIqE9uT4gA", "PHICore", "GetTeams", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetTeams");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeams", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetTeams", "7HsCFYxVu9IaYXzw8g21ww", maxRecords, startIndex, function (b) {
model.variables.getTeamsAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamsAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:7YtbOjpzWUS4bgDT3ElHrA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getStatuses$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:VV89iysoPU6qlGr+bXEJNA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.VV89iysoPU6qlGr+bXEJNA:XTvsJbHkG4Q0IYUPQhrkxA", "PHICore", "GetStatuses", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetStatuses");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetStatuses", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetStatuses", "oqaDLdcGk2o_unl1dmPsXA", maxRecords, startIndex, function (b) {
model.variables.getStatusesAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getStatusesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getStatusesAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:VV89iysoPU6qlGr+bXEJNA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getPriorities$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:AWAXjTMU2UaJnwip3Fxmbw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.AWAXjTMU2UaJnwip3Fxmbw:Z+UdsqAMc3gURjYR5mVbyQ", "PHICore", "GetPriorities", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetPriorities");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetPriorities", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetPriorities", "AgKvYUlKEWiOV5fDG0zhOw", maxRecords, startIndex, function (b) {
model.variables.getPrioritiesAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getPrioritiesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getPrioritiesAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:AWAXjTMU2UaJnwip3Fxmbw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getSubCategory$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:nWG7yA7AD0OLdBwEkVNfKg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.nWG7yA7AD0OLdBwEkVNfKg:xWb4ty+GS7gGF7q7c53CbA", "PHICore", "GetSubCategory", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetSubCategory");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetSubCategory", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetSubCategory", "f2_llbNTJkBUi_c0nXmBFw", maxRecords, startIndex, function (b) {
model.variables.getSubCategoryAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getSubCategoryAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getSubCategoryAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetSubCategory On After Fetch");
controller._getSubCategoryOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:nWG7yA7AD0OLdBwEkVNfKg", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getUsersRaisedBy$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:eVfl28yC0UyFMFmlQdaOVQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.eVfl28yC0UyFMFmlQdaOVQ:uVcO3cMjINOzSMDebDxTjg", "PHICore", "GetUsersRaisedBy", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetUsersRaisedBy");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetUsersRaisedBy", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetUsersRaisedBy", "9YkTPmgvIYwDAVPp3VoCYg", maxRecords, startIndex, function (b) {
model.variables.getUsersRaisedByAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getUsersRaisedByAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getUsersRaisedByAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:eVfl28yC0UyFMFmlQdaOVQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getSLAs$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:axyE8PQevEqk_P13Ppgs6g:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ScreenDataSets.axyE8PQevEqk_P13Ppgs6g:ISHRZ0FbLXVRbxCCMugR4w", "PHICore", "GetSLAs", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetSLAs");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetSLAs", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/ScreenDataSetGetSLAs", "QF_EMHHEacAmUFRA62fdrg", maxRecords, startIndex, function (b) {
model.variables.getSLAsAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getSLAsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getSLAsAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:axyE8PQevEqk_P13Ppgs6g", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getJoinedFilters$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:rQypBfIp5U+FzoJoRzZJVA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/DataActions.rQypBfIp5U+FzoJoRzZJVA:tC8c0bGJuw3l9je5k_ASwg", "PHICore", "GetJoinedFilters", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetJoinedFilters");
return controller.callDataAction("DataActionGetJoinedFilters", "screenservices/PHICore/Common_Widgets/SearchFilterPopup/DataActionGetJoinedFilters", "UMEfgA6CR7dFZm+DUV8NOA", function (b) {
model.variables.getJoinedFiltersDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getJoinedFiltersDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getJoinedFiltersDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup/GetJoinedFilters On After Fetch");
return controller._getJoinedFiltersOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:rQypBfIp5U+FzoJoRzZJVA", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getCategories$AggrRefresh", "getUsersAssignedTo$AggrRefresh", "getTeams$AggrRefresh", "getStatuses$AggrRefresh", "getPriorities$AggrRefresh", "getSubCategory$AggrRefresh", "getUsersRaisedBy$AggrRefresh", "getSLAs$AggrRefresh", "getJoinedFilters$DataActRefresh"];
// Client Actions
Controller.prototype._onClear$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClear");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnClear$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:CunrIGxd4EW18cggTSEVwg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.CunrIGxd4EW18cggTSEVwg:exgGSM2STavFBpEuUJCYhQ", "PHICore", "OnClear", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZkQp+pqJxUWTt75MM8GpgQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EQGvPOwZnU6tqZc7r8IHiw", callContext.id);
// ExistingSearchFilter = Search_Filter
model.variables.existingSearchFilterVar = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.search_FilterVar, new PHICoreModel.CaseFilterSearchFilterRecord(), function (source, target) {
target.caseFilterAttr.assignedToAttr = model.variables.dropdownTagValueHolderVar.assignedToAttr;
target.caseFilterAttr.categoryAttr = model.variables.dropdownTagValueHolderVar.categoryAttr;
target.caseFilterAttr.priorityAttr = model.variables.dropdownTagValueHolderVar.priorityAttr;
target.caseFilterAttr.raisedByAttr = model.variables.dropdownTagValueHolderVar.raisedByAttr;
target.caseFilterAttr.sLAsAttr = model.variables.dropdownTagValueHolderVar.sLAsAttr;
target.caseFilterAttr.statusAttr = model.variables.dropdownTagValueHolderVar.statusAttr;
target.caseFilterAttr.subCategoryAttr = model.variables.dropdownTagValueHolderVar.subCategoryAttr;
target.caseFilterAttr.teamsAttr = model.variables.dropdownTagValueHolderVar.teamsAttr;
target.searchAttr.dueDateFromAttr = source.dueDateFromAttr;
target.searchAttr.dueDateToAttr = source.dueDateToAttr;
target.searchAttr.categoryAttr = source.categoryAttr;
target.searchAttr.subCategoryAttr = source.subCategoryAttr;
target.searchAttr.sLAAttr = source.sLAAttr;
target.searchAttr.priorityAttr = source.priorityAttr;
target.searchAttr.statusAttr = source.statusAttr;
target.searchAttr.raisedByAttr = source.raisedByAttr;
target.searchAttr.assignedToAttr = source.assignedToAttr;
target.searchAttr.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EQGvPOwZnU6tqZc7r8IHiw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Search_Filter = EmptySearchFilter
model.variables.search_FilterVar = vars.value.emptySearchFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EQGvPOwZnU6tqZc7r8IHiw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Search_Filter.DueDateFrom = NullDate
model.variables.search_FilterVar.dueDateFromAttr = OS.BuiltinFunctions.nullDate();
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EQGvPOwZnU6tqZc7r8IHiw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Search_Filter.DueDateTo = NullDate
model.variables.search_FilterVar.dueDateToAttr = OS.BuiltinFunctions.nullDate();
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:B59dba615Eq9RBLGaIBiVw", callContext.id);
controller.safeExecuteJSNode(PHICore_Common_Widgets_SearchFilterPopup_mvc_controller_OnClear_JavaScriptRemoveValueJS, "JavaScriptRemoveValue", "OnClear", {
DueDateFromId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input_DueDateFromDatePicked"), OS.Types.Text),
DueDateToId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input_DueDateToDatePicked"), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+9zq_WcF+UifZRQfEONBDA", callContext.id);
// Execute Action: ClearDropdownTag_Category
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_Category"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vW6bBOT3xkGs0F8HBioySA", callContext.id);
// Execute Action: ClearDropdownTag_SubCategory
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_SubCategory"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HnGS6nf0y0q0Sb8bXNuj_Q", callContext.id);
// Execute Action: ClearDropdownTag_SLA
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_SLA"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:npE+BYWnzEK6ZQudIY+lUg", callContext.id);
// Execute Action: ClearDropdownTag_Priority
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_Priority"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AMZzj158PE6tPOHGP+YCTw", callContext.id);
// Execute Action: ClearDropdownTag_Status
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_Status"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Db7yu9ddxUeJUawwsV7grA", callContext.id);
// Execute Action: ClearDropdownTag_RaisedBy
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_RaisedBy"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bkttsJipVEW_A4xSDT6MGw", callContext.id);
// Execute Action: ClearDropdownTag_AssignedTo
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_AssignedTo"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4MjT6ESNv0eVEsey7J4NTA", callContext.id);
// Execute Action: ClearDropdownTag_Team
Common_CWController.default.clearDropdownTag$Action(idService.getId("Dropdown_Team"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CFbYLdhPjkeRLELBGrfpYA", callContext.id);
// Trigger Event: ClearSearchFilter
return controller.clearSearchFilter$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aNoDw5+yzk+ONPh1rHpFPQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:CunrIGxd4EW18cggTSEVwg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:CunrIGxd4EW18cggTSEVwg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnClear$vars", [{
name: "EmptySearchFilter",
attrName: "emptySearchFilterVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}]);
Controller.prototype._onChangedStatus$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedStatus");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedStatus$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ec8BJLyw_Ee3Ep6430GGBw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.ec8BJLyw_Ee3Ep6430GGBw:N5rz53KvveNqiy0lI+oA2A", "PHICore", "OnChangedStatus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LJ9brosWDEabuNLyOtPS8w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b5h063fHFkmQP3v8Dyd8mA", callContext.id);
// Search_Filter.Status = SelectedOptionList
model.variables.search_FilterVar.statusAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FCbwKvUvfkWyIuhkC1FSvA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ec8BJLyw_Ee3Ep6430GGBw", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedStatus$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:_gGMJhbQZkyl5PPbMpQm_A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions._gGMJhbQZkyl5PPbMpQm_A:lypZJsRZStV0UIncNgtL7g", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MlWmd_z0aUmL0POzFIP9Sw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VmqBBvkuOUy9p6V90NUAEA", callContext.id);
// Refresh Query: GetStatuses
var result = controller.getStatuses$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6Lml2jurb0WiLjp+OrhuRg", callContext.id);
// Refresh Query: GetJoinedFilters
var result = controller.getJoinedFilters$DataActRefresh(callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id);
// DropdownTagValueHolder.Category = Search_Filter.Category
model.variables.dropdownTagValueHolderVar.categoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.categoryAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DropdownTagValueHolder.SubCategory = Search_Filter.SubCategory
model.variables.dropdownTagValueHolderVar.subCategoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.subCategoryAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DropdownTagValueHolder.SLAs = Search_Filter.SLA
model.variables.dropdownTagValueHolderVar.sLAsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.sLAAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// DropdownTagValueHolder.Priority = Search_Filter.Priority
model.variables.dropdownTagValueHolderVar.priorityAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.priorityAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// DropdownTagValueHolder.Status = Search_Filter.Status
model.variables.dropdownTagValueHolderVar.statusAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.statusAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// DropdownTagValueHolder.RaisedBy = Search_Filter.RaisedBy
model.variables.dropdownTagValueHolderVar.raisedByAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.raisedByAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// DropdownTagValueHolder.Teams = Search_Filter.Teams
model.variables.dropdownTagValueHolderVar.teamsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.teamsAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu39KrSRJky5l7WKBlZbqQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// DropdownTagValueHolder.AssignedTo = Search_Filter.AssignedTo
model.variables.dropdownTagValueHolderVar.assignedToAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.assignedToAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OmzDanLoE0e9cxv4HiSOtw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_gGMJhbQZkyl5PPbMpQm_A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_gGMJhbQZkyl5PPbMpQm_A", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:vkiiKCoKHUWtjxQJkVGdvg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.vkiiKCoKHUWtjxQJkVGdvg:BRIinCZAJH9U4Lxb3gINjw", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zKpO6_KXlU+rRcp_KyfFXQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MVX06FEYXUaGeqcmrlhyPA", callContext.id);
// Search_Filter = SearchFilter_Input
model.variables.search_FilterVar = model.variables.searchFilter_InputIn;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LcMdAgOQhUiojWXt7aKayA", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.assignedToListVar, function () {
var list = new PHICoreModel.KeyValuePairList();
list.pushAll([function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(1);
rec.valueAttr = "AssignedTo1";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(2);
rec.valueAttr = "AssignedTo2";
return rec;
}()]);
return list;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id);
// DropdownTagValueHolder.Category = Search_Filter.Category
model.variables.dropdownTagValueHolderVar.categoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.categoryAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DropdownTagValueHolder.SubCategory = Search_Filter.SubCategory
model.variables.dropdownTagValueHolderVar.subCategoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.subCategoryAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DropdownTagValueHolder.SLAs = Search_Filter.SLA
model.variables.dropdownTagValueHolderVar.sLAsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.sLAAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// DropdownTagValueHolder.Priority = Search_Filter.Priority
model.variables.dropdownTagValueHolderVar.priorityAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.priorityAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// DropdownTagValueHolder.Status = Search_Filter.Status
model.variables.dropdownTagValueHolderVar.statusAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.statusAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// DropdownTagValueHolder.RaisedBy = Search_Filter.RaisedBy
model.variables.dropdownTagValueHolderVar.raisedByAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.raisedByAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// DropdownTagValueHolder.Teams = Search_Filter.Teams
model.variables.dropdownTagValueHolderVar.teamsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.teamsAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sM+NMfWngEquI5OOhI8RDA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// DropdownTagValueHolder.AssignedTo = Search_Filter.AssignedTo
model.variables.dropdownTagValueHolderVar.assignedToAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.assignedToAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Hhab9Ut_wke+w9ScIwsRYw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:vkiiKCoKHUWtjxQJkVGdvg", callContext.id);
}

};
Controller.prototype._onChangedPriority$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedPriority");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedPriority$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:VcXqPoxUBke9wMeCqNAV7Q:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.VcXqPoxUBke9wMeCqNAV7Q:p4MI34AqoDcInHeVUtBKWQ", "PHICore", "OnChangedPriority", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kw5iun6hGku1RxODu0AWzA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:laenMv1zGEWJV6JBjA7svA", callContext.id);
// Search_Filter.Priority = SelectedOptionList
model.variables.search_FilterVar.priorityAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uLWB9jzn80ipKSE1sKkPLA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:VcXqPoxUBke9wMeCqNAV7Q", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedPriority$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onChangedAssignedTo$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedAssignedTo");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedAssignedTo$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:e8bLTAVL8kCZnXVt44IFpA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.e8bLTAVL8kCZnXVt44IFpA:W5Bt2REN9ta_CvZft2yJ1Q", "PHICore", "OnChangedAssignedTo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f6BlGQSx7EKVQIcfxPMlEQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uFrw0vtgfEy3bo4J7rlyrg", callContext.id);
// Search_Filter.AssignedTo = SelectedOptionList
model.variables.search_FilterVar.assignedToAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l6Qcsli3wUSwEDkdF1_ZGA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:e8bLTAVL8kCZnXVt44IFpA", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedAssignedTo$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._getSubCategoryOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetSubCategoryOnAfterFetch");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:EPP7YlHX+UiaZGjqGLUu3w:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.EPP7YlHX+UiaZGjqGLUu3w:uIC_2Ezxr0dUgOaaiY6VSg", "PHICore", "GetSubCategoryOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Tl_pdUAfBkuibtcI2BNO5A", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1XeJ4mLDDUuEsprOktudKg", callContext.id);
// DropdownTagValueHolder.SubCategory = Search_Filter.SubCategory
model.variables.dropdownTagValueHolderVar.subCategoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.search_FilterVar.subCategoryAttr, new PHICoreModel.DropdownOptionList(), function (source, target) {
target.valueAttr = source.valueAttr;
target.labelAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zmvwcsSkzk6HYNDVEN8LVw", callContext.id);
// ExistingSearchFilter = SearchFilter_Input
model.variables.existingSearchFilterVar = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.searchFilter_InputIn, new PHICoreModel.CaseFilterSearchFilterRecord(), function (source, target) {
target.caseFilterAttr.assignedToAttr = model.variables.dropdownTagValueHolderVar.assignedToAttr;
target.caseFilterAttr.categoryAttr = model.variables.dropdownTagValueHolderVar.categoryAttr;
target.caseFilterAttr.priorityAttr = model.variables.dropdownTagValueHolderVar.priorityAttr;
target.caseFilterAttr.raisedByAttr = model.variables.dropdownTagValueHolderVar.raisedByAttr;
target.caseFilterAttr.sLAsAttr = model.variables.dropdownTagValueHolderVar.sLAsAttr;
target.caseFilterAttr.statusAttr = model.variables.dropdownTagValueHolderVar.statusAttr;
target.caseFilterAttr.subCategoryAttr = model.variables.dropdownTagValueHolderVar.subCategoryAttr;
target.caseFilterAttr.teamsAttr = model.variables.dropdownTagValueHolderVar.teamsAttr;
target.searchAttr.dueDateFromAttr = source.dueDateFromAttr;
target.searchAttr.dueDateToAttr = source.dueDateToAttr;
target.searchAttr.categoryAttr = source.categoryAttr;
target.searchAttr.subCategoryAttr = source.subCategoryAttr;
target.searchAttr.sLAAttr = source.sLAAttr;
target.searchAttr.priorityAttr = source.priorityAttr;
target.searchAttr.statusAttr = source.statusAttr;
target.searchAttr.raisedByAttr = source.raisedByAttr;
target.searchAttr.assignedToAttr = source.assignedToAttr;
target.searchAttr.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8kgEw5ybFkebTL0bHsHadw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:EPP7YlHX+UiaZGjqGLUu3w", callContext.id);
}

};
Controller.prototype._getCategoriesOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetCategoriesOnAfterFetch");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:JgWVaIZXdkSLKvnaYD4Dww:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.JgWVaIZXdkSLKvnaYD4Dww:0EQwBtmgB1GPAgdn6BpJgA", "PHICore", "GetCategoriesOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HJp2+XoicECIOZygvBm35A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NrUkXWe2Gk+BOHlZ2aWCKQ", callContext.id);
// Refresh Query: GetJoinedFilters
var result = controller.getJoinedFilters$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aubxyQjbsUiOn51VMMVQTg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JgWVaIZXdkSLKvnaYD4Dww", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JgWVaIZXdkSLKvnaYD4Dww", callContext.id);
throw ex;

});
};
Controller.prototype._onChangedTeams$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedTeams");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedTeams$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
var listIndexOfVar = new OS.DataTypes.VariableHolder();
var listDuplicate_AssignedToVar = new OS.DataTypes.VariableHolder();
var string_JoinVar = new OS.DataTypes.VariableHolder();
var listAnyVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listIndexOfVar = listIndexOfVar;
varBag.listDuplicate_AssignedToVar = listDuplicate_AssignedToVar;
varBag.string_JoinVar = string_JoinVar;
varBag.listAnyVar = listAnyVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:_PTaaP1P8Ei6r25kFtKQXw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions._PTaaP1P8Ei6r25kFtKQXw:h2BGoSumz0YmQ4vxBTnQMQ", "PHICore", "OnChangedTeams", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+PI+0Mij02a+BNExyR33Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2Igkg7yud0aL6YmULZqQOQ", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = source.valueAttr;
return target;
}), "#", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:a8h7sY1hvkOPoOdqAifkfw", callContext.id);
// JoinedTeams = "#" + String_Join.Text + "#"
model.variables.joinedTeamsVar = (("#" + string_JoinVar.value.textOut) + "#");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:a8h7sY1hvkOPoOdqAifkfw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Search_Filter.Teams = SelectedOptionList
model.variables.search_FilterVar.teamsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lupr6MWmc0amDE3Es0D+wg", callContext.id);
// Refresh Query: GetUsersAssignedTo
var result = controller.getUsersAssignedTo$AggrRefresh(1000, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3kK_d+kZ7EOAmFVqLdz4Qw", callContext.id);
// Execute Action: ListDuplicate_AssignedTo
listDuplicate_AssignedToVar.value = OS.SystemActions.listDuplicate(model.variables.dropdownTagValueHolderVar.assignedToAttr, callContext);

// Foreach DropdownTagValueHolder.AssignedTo
callContext.iterationContext.registerIterationStart(model.variables.dropdownTagValueHolderVar.assignedToAttr);
}).then(function () {
try {var assignedToIterator = callContext.iterationContext.getIterator(model.variables.dropdownTagValueHolderVar.assignedToAttr);
var assignedToIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7Cf6l5tdPUK5_+_gZ4dMtQ", callContext.id) && (assignedToIndex < model.variables.dropdownTagValueHolderVar.assignedToAttr.length))) {
assignedToIterator.currentRowNumber = assignedToIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5Lf0kwJBlEuY1Ia9nucdpw", callContext.id);
// Execute Action: ListAny
listAnyVar.value = OS.SystemActions.listAny(model.variables.getUsersAssignedToAggr.listOut, function (p) {
return (p.idAttr === OS.BuiltinFunctions.integerToIdentifier(OS.BuiltinFunctions.textToInteger(model.variables.dropdownTagValueHolderVar.assignedToAttr.getItem(assignedToIndex.valueOf()).valueAttr)));
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uO7242dpMUKhdNxbFxwcXA", callContext.id) && !(listAnyVar.value.resultOut))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FBnyPQ5bFUq+moOc26lN2w", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(listDuplicate_AssignedToVar.value.duplicatedListOut, function (p) {
return (p.valueAttr === model.variables.dropdownTagValueHolderVar.assignedToAttr.getItem(assignedToIndex.valueOf()).valueAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:06c1zBLhiEC1r4JWo46hsA", callContext.id) && ((listIndexOfVar.value.positionOut) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OY0_BAohj0Onvh89JNqLrA", callContext.id);
// Execute Action: ListRemove
OS.SystemActions.listRemove(listDuplicate_AssignedToVar.value.duplicatedListOut, listIndexOfVar.value.positionOut, callContext);
}

}

assignedToIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.dropdownTagValueHolderVar.assignedToAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:btCCBX3acUG_HRDve53ZTg", callContext.id);
// DropdownTagValueHolder.AssignedTo = ListDuplicate_AssignedTo.DuplicatedList
model.variables.dropdownTagValueHolderVar.assignedToAttr = listDuplicate_AssignedToVar.value.duplicatedListOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IuAplf1MT0qmGgOoVSPpWw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_PTaaP1P8Ei6r25kFtKQXw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_PTaaP1P8Ei6r25kFtKQXw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedTeams$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onChangedCategory$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedCategory");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedCategory$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
var string_JoinVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.string_JoinVar = string_JoinVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:MhQ6cSzxwkeM1HGMwiBlfg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.MhQ6cSzxwkeM1HGMwiBlfg:SFlzJAaXEZQvd89U4xCf1A", "PHICore", "OnChangedCategory", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KD+0PdKhE06m1wxfFeM9yA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MQ6K7K2X_UKcLfeGuSh5qQ", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = source.valueAttr;
return target;
}), "#", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:s_Gd+eYkI0qFGLdi_k9aBg", callContext.id);
// JoinedCategory = "#" + String_Join.Text + "#"
model.variables.joinedCategoryVar = (("#" + string_JoinVar.value.textOut) + "#");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:s_Gd+eYkI0qFGLdi_k9aBg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Search_Filter.Category = SelectedOptionList
model.variables.search_FilterVar.categoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:diEtGtuWxUa7jQfswJX5bA", callContext.id);
// Refresh Query: GetSubCategory
var result = controller.getSubCategory$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+o4INEpeVUygtPos6OVr9Q", callContext.id);
// Refresh Query: GetUsersAssignedTo
var result = controller.getUsersAssignedTo$AggrRefresh(1000, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1tkVAe_vkUmRnkU+OndX0Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:MhQ6cSzxwkeM1HGMwiBlfg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:MhQ6cSzxwkeM1HGMwiBlfg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedCategory$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onClickApply$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickApply");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ERixjSm_BE2BZXishslBJg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.ERixjSm_BE2BZXishslBJg:EzauCumy0OcP5VtdI8pjxw", "PHICore", "OnClickApply", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:joG50qwVTEefxh0lnrtYLQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jGlKut_9A0m9ZA0jxZpLjA", callContext.id) && model.variables.search_FilterVar.dueDateToAttr.lt(model.variables.search_FilterVar.dueDateFromAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:twtZ89+XvUuiB07_8M9tsw", callContext.id);
// IsValid = False
model.variables.isValidVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_LcQOvvF50ydaD56jXj0JA", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Errors have occurred, please review highlighted fields", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4WaLBB7_WEiiFZO5XSAilg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OqN7bE739UuS8jtavZmdAQ", callContext.id);
// Trigger Event: SearchFilterEvent
return controller.searchFilter$Action(model.variables.search_FilterVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4WaLBB7_WEiiFZO5XSAilg", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ERixjSm_BE2BZXishslBJg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ERixjSm_BE2BZXishslBJg", callContext.id);
throw ex;

});
};
Controller.prototype._onChangedSubCategory$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedSubCategory");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedSubCategory$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:8DLfmND5M0qNhEDdX6qEOQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.8DLfmND5M0qNhEDdX6qEOQ:ssCJLGGbowsTt44P7rj4iQ", "PHICore", "OnChangedSubCategory", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_yt24wCAZEa8TvrKiGX1sg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2b09Rbn40a8eQzx5YH1Ug", callContext.id);
// Search_Filter.SubCategory = SelectedOptionList
model.variables.search_FilterVar.subCategoryAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G66Ei6z59ka2iamrp6440Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8DLfmND5M0qNhEDdX6qEOQ", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedSubCategory$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onChangedSLAs$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedSLAs");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedSLAs$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:y_hXmVuF00mb5jP9DCacsQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.y_hXmVuF00mb5jP9DCacsQ:tNl_Jhmc+lzeChwLmvPMJA", "PHICore", "OnChangedSLAs", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rQ04VUq9c060fze473TDlg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VymP8IB1jU+tFLfw8Us23Q", callContext.id);
// Search_Filter.SLA = SelectedOptionList
model.variables.search_FilterVar.sLAAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xAF2Pmxm0k2pamFHW0x9IA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:y_hXmVuF00mb5jP9DCacsQ", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedSLAs$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._input_DueDateToDatePickedOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Input_DueDateToDatePickedOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:iqzrmRTgb0eiqYadqjgQlQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.iqzrmRTgb0eiqYadqjgQlQ:nHpM_1A9GYDB1oDWU86UNg", "PHICore", "Input_DueDateToDatePickedOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1bTVONz2M0+Evp4doXsQOQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ESqbzeIjyUaejEFNv6XsWQ", callContext.id);
// IsValid = True
model.variables.isValidVar = true;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l5hjdKSmF0+IKsEkO0SIBA", callContext.id) && model.variables.searchFilter_InputIn.dueDateToAttr.lt(model.variables.searchFilter_InputIn.dueDateFromAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6AeVa4rZwEqo2t4zDy4aiA", callContext.id);
// SearchFilter_Input.DueDateTo = SearchFilter_Input.DueDateFrom
model.variables.searchFilter_InputIn.dueDateToAttr = model.variables.searchFilter_InputIn.dueDateFromAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KU3HyIDJI0CZycom+AyFNQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KU3HyIDJI0CZycom+AyFNQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:iqzrmRTgb0eiqYadqjgQlQ", callContext.id);
}

};
Controller.prototype._getJoinedFiltersOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetJoinedFiltersOnAfterFetch");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:RSpJnfkOxUu73IEHCLLq6A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.RSpJnfkOxUu73IEHCLLq6A:9+hDv_5RgDbgob6jTHTUNQ", "PHICore", "GetJoinedFiltersOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L5hKMnDy70u51e1Tx_3Jjg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nAtqQQARE0Sxl8wpvU+lCg", callContext.id);
// JoinedCategory = GetJoinedFilters.Joined_Category
model.variables.joinedCategoryVar = model.variables.getJoinedFiltersDataAct.joined_CategoryOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nAtqQQARE0Sxl8wpvU+lCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedTeams = GetJoinedFilters.Joined_Teams
model.variables.joinedTeamsVar = model.variables.getJoinedFiltersDataAct.joined_TeamsOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nAtqQQARE0Sxl8wpvU+lCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// JoinedSubCategory = GetJoinedFilters.Joined_SubCategory
model.variables.joinedSubCategoryVar = model.variables.getJoinedFiltersDataAct.joined_SubCategoryOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nAtqQQARE0Sxl8wpvU+lCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// JoinedAssignedTo = GetJoinedFilters.Joined_AssignedTo
model.variables.joinedAssignedToVar = model.variables.getJoinedFiltersDataAct.joined_AssignedToOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7xeuEmau406G34PRfSQOmQ", callContext.id);
// Refresh Query: GetSubCategory
var result = controller.getSubCategory$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8EBBTjl720+ZY7MDSxvSEA", callContext.id);
// Refresh Query: GetUsersAssignedTo
var result = controller.getUsersAssignedTo$AggrRefresh(1000, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XnVHoEiCoEiM7pt8ZsSk9g", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:RSpJnfkOxUu73IEHCLLq6A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:RSpJnfkOxUu73IEHCLLq6A", callContext.id);
throw ex;

});
};
Controller.prototype._input_DueDateFromDatePickedOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Input_DueDateFromDatePickedOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:04MRt_6FBUi4iaetha1zZA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.04MRt_6FBUi4iaetha1zZA:JQql497t5vzX8BgvbYqZbA", "PHICore", "Input_DueDateFromDatePickedOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GF9vKhFPc0+IhO4HpMFA4Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IOfYhVyQqkqPUQJT6B2pag", callContext.id);
// IsValid = True
model.variables.isValidVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:czTSSFuIDU+AgWMZA1hrtQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:04MRt_6FBUi4iaetha1zZA", callContext.id);
}

};
Controller.prototype._onChangedRaisedBy$Action = function (selectedOptionListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChangedRaisedBy");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedRaisedBy$vars"))());
vars.value.selectedOptionListInLocal = selectedOptionListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:QikixRyrwkKgLeCsgMtWJA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.QikixRyrwkKgLeCsgMtWJA:Ej86iMRnl7byJgRqFaDOyQ", "PHICore", "OnChangedRaisedBy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZXvtAeWVokCCpC3z72wHJg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:74HJelIWOEi+sZ50T4a1cA", callContext.id);
// Search_Filter.RaisedBy = SelectedOptionList
model.variables.search_FilterVar.raisedByAttr = OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.selectedOptionListInLocal, new PHICoreModel.TextText2RecordList(), function (source, target) {
target.nameAttr = source.labelAttr;
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:44lhjLwhLka0I6UdeKL6kg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:QikixRyrwkKgLeCsgMtWJA", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchFilterPopup.OnChangedRaisedBy$vars", [{
name: "SelectedOptionList",
attrName: "selectedOptionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DropdownOptionList();
},
complexType: PHICoreModel.DropdownOptionList
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:bqW9z3H_TkqWr8PkD5R0EA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q/ClientActions.bqW9z3H_TkqWr8PkD5R0EA:MkBwaFk4cIbTGw5AeF8Siw", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eKZpIDKRMUmXlzRfBQhIXw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KvyQJm6maU+256ZYfeyoWA", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(true, idService.getId("Input_DueDateFromDatePicked"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TlZqQAJOdUeVbuL10vAzNw", callContext.id);
// the javascript for Tabbing
controller.safeExecuteJSNode(PHICore_Common_Widgets_SearchFilterPopup_mvc_controller_OnReady_OnTabbingJavascriptJS, "OnTabbingJavascript", "OnReady", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Form1"), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+Jl5OdHzcUSXYxu+DHi0eg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:bqW9z3H_TkqWr8PkD5R0EA", callContext.id);
}

};

Controller.prototype.onClear$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClear$Action, callContext);

};
Controller.prototype.onChangedStatus$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedStatus$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onChangedPriority$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedPriority$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onChangedAssignedTo$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedAssignedTo$Action, callContext, selectedOptionListIn);

};
Controller.prototype.getSubCategoryOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getSubCategoryOnAfterFetch$Action, callContext);

};
Controller.prototype.getCategoriesOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getCategoriesOnAfterFetch$Action, callContext);

};
Controller.prototype.onChangedTeams$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedTeams$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onChangedCategory$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedCategory$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onClickApply$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickApply$Action, callContext);

};
Controller.prototype.onChangedSubCategory$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedSubCategory$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onChangedSLAs$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedSLAs$Action, callContext, selectedOptionListIn);

};
Controller.prototype.input_DueDateToDatePickedOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._input_DueDateToDatePickedOnChange$Action, callContext);

};
Controller.prototype.getJoinedFiltersOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getJoinedFiltersOnAfterFetch$Action, callContext);

};
Controller.prototype.input_DueDateFromDatePickedOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._input_DueDateFromDatePickedOnChange$Action, callContext);

};
Controller.prototype.onChangedRaisedBy$Action = function (selectedOptionListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChangedRaisedBy$Action, callContext, selectedOptionListIn);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.searchFilter$Action = function () {
return Promise.resolve();
};
Controller.prototype.closeFilter$Action = function () {
return Promise.resolve();
};
Controller.prototype.clearSearchFilter$Action = function () {
return Promise.resolve();
};
Controller.prototype.refreshFilter$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:duKt0k5CkUmyrvNqsZvL9Q:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.duKt0k5CkUmyrvNqsZvL9Q:l1HydMvFkIiZJjn+M2US+g", "PHICore", "SearchFilterPopup", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:duKt0k5CkUmyrvNqsZvL9Q", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchFilterPopup On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});
define("PHICore.Common_Widgets.SearchFilterPopup.mvc$controller.OnClear.JavaScriptRemoveValueJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function(){
    document.getElementById($parameters.DueDateFromId).value='';
    document.getElementById($parameters.DueDateToId).value='';

    document.getElementById($parameters.DueDateFromId).removeAttribute('value');
    document.getElementById($parameters.DueDateToId).removeAttribute('value');

}, 0)
};
});
define("PHICore.Common_Widgets.SearchFilterPopup.mvc$controller.OnReady.OnTabbingJavascriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
let a = document.getElementById($parameters.WidgetId);
a.focus();
let keyboardfocusableElements = a.querySelectorAll(
  'a[href], button, input:not(.vscomp-hidden-input), [tabindex]:not([tabindex="-1"])',
);
a.addEventListener('keydown', function(e) {
  let firstFocusableElement = keyboardfocusableElements[0];
  let lastFocusableElement = keyboardfocusableElements[keyboardfocusableElements.length - 1];
if (event.key === 'Tab') {
    keyboardfocusableElements = checkFocusable();
    keyboardfocusableElements.forEach((element, index) => {
    element.setAttribute('tabindex', index + 1);
    });
      if (keyboardfocusableElements.length !== checkFocusable().length) {
      keyboardfocusableElements = checkFocusable();
    }
    event.preventDefault(); // Prevent the default tab behavior
     // If Shift+Tab is pressed and focus is on the first focusable element, move focus to the last focusable element
    if (e.shiftKey && document.activeElement === firstFocusableElement) {
      e.preventDefault();
      lastFocusableElement.focus();
    }
    // If Tab is pressed and focus is on the last focusable element, move focus to the first focusable element
    else if (!e.shiftKey && document.activeElement === lastFocusableElement) {
      e.preventDefault();
      firstFocusableElement.focus();
    }
    // Check if the Shift key is also pressed (Shift + Tab)
    else if (event.shiftKey) {
      focusPreviousElement();
    } else {
      focusNextElement();
    }
  }
});

function focusNextElement() {
  const activeElement = document.activeElement;
  let b;
  let index = Array.from(keyboardfocusableElements).indexOf(activeElement);
  // If the active element is not found or is the last one, focus the first element
  if (index === -1 || index === keyboardfocusableElements.length - 1) {
    keyboardfocusableElements[0].focus();
  } else {
    if (index === 0)
        b=1;
    else
        b=index + 1;
    console.log(b);
    keyboardfocusableElements[b].focus();
  }
}


function focusPreviousElement() {
  const activeElement = document.activeElement;
  let index = Array.from(keyboardfocusableElements).indexOf(activeElement);

  // If the active element is not found or is the first one, focus the last element
  if (index === -1 || index === 0) {
    keyboardfocusableElements[keyboardfocusableElements.length - 1].focus();
  } else {
    keyboardfocusableElements[index - 1].focus();
  }
}

function checkFocusable() {
  return a.querySelectorAll(
   'a[href], button, input:not(.vscomp-hidden-input), [tabindex]:not([tabindex="-1"])'
  );
}
};
});

define("PHICore.Common_Widgets.SearchFilterPopup.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"jpERsiRPVEi3UVfJ8oy0NQ": {
getter: function (varBag, idService) {
return varBag.vars.value.emptySearchFilterVar;
}
},
"B59dba615Eq9RBLGaIBiVw": {
getter: function (varBag, idService) {
return varBag.javaScriptRemoveValueJSResult.value;
}
},
"sIZHIhiDxkO_AUbklbjW9w": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"EnVVGRN4WUWKAUrroLswGg": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"JCykbEHxqkKbaEuopzEQ0A": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"EHi51+IvrE6VbmDwXbCPCg": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"FBnyPQ5bFUq+moOc26lN2w": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
},
"3kK_d+kZ7EOAmFVqLdz4Qw": {
getter: function (varBag, idService) {
return varBag.listDuplicate_AssignedToVar.value;
}
},
"2Igkg7yud0aL6YmULZqQOQ": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"5Lf0kwJBlEuY1Ia9nucdpw": {
getter: function (varBag, idService) {
return varBag.listAnyVar.value;
}
},
"nSP5cHfenU2eKo7QyOhq5g": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"MQ6K7K2X_UKcLfeGuSh5qQ": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"Pk_MZirSwEyujL5bTMY0jQ": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"RWALc1B44E29fxtjotT3Bw": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"cSl1ydSeakWY_oshbnXZEQ": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedOptionListInLocal;
}
},
"TlZqQAJOdUeVbuL10vAzNw": {
getter: function (varBag, idService) {
return varBag.onTabbingJavascriptJSResult.value;
}
},
"GCi4NjhrekaG10oGeEWATA": {
getter: function (varBag, idService) {
return varBag.model.variables.assignedToListVar;
}
},
"esy5LS6oeku+ybqVgAN_Yw": {
getter: function (varBag, idService) {
return varBag.model.variables.dropdownTagValueHolderVar;
}
},
"CXc7vDecdUS3FyGC4dDhGg": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedCategoryVar;
},
dataType: OS.Types.Text
},
"CWfbeCGaBk6eZcrLQeI8gw": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedSubCategoryVar;
},
dataType: OS.Types.Text
},
"8EjZ4h+lK0aZlxyOYG3QRg": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedTeamsVar;
},
dataType: OS.Types.Text
},
"ZmJ9wI9hckG1d47fI+D3WA": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedAssignedToVar;
},
dataType: OS.Types.Text
},
"WoNTJgpBwEybcxO4h+Lkaw": {
getter: function (varBag, idService) {
return varBag.model.variables.search_FilterVar;
}
},
"8HyPYOuT8E+rFWlzh19neQ": {
getter: function (varBag, idService) {
return varBag.model.variables.existingSearchFilterVar;
}
},
"APzbAP0A4k+9PkDCD3pBJw": {
getter: function (varBag, idService) {
return varBag.model.variables.isValidVar;
},
dataType: OS.Types.Boolean
},
"aQ3kJRUClUGh7bH0OVQchQ": {
getter: function (varBag, idService) {
return varBag.model.variables.filterIndictorIn;
},
dataType: OS.Types.Integer
},
"xFeKLnoDx0efahStuQ1Jcg": {
getter: function (varBag, idService) {
return varBag.model.variables.searchFilter_InputIn;
}
},
"rQypBfIp5U+FzoJoRzZJVA": {
getter: function (varBag, idService) {
return varBag.model.variables.getJoinedFiltersDataAct;
}
},
"VpdQD0rslEiXaxICqMV8CA": {
getter: function (varBag, idService) {
return varBag.model.variables.getCategoriesAggr;
}
},
"0mOrHmVYfkiPNuQ6DduZbw": {
getter: function (varBag, idService) {
return varBag.model.variables.getUsersAssignedToAggr;
}
},
"7YtbOjpzWUS4bgDT3ElHrA": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamsAggr;
}
},
"VV89iysoPU6qlGr+bXEJNA": {
getter: function (varBag, idService) {
return varBag.model.variables.getStatusesAggr;
}
},
"AWAXjTMU2UaJnwip3Fxmbw": {
getter: function (varBag, idService) {
return varBag.model.variables.getPrioritiesAggr;
}
},
"nWG7yA7AD0OLdBwEkVNfKg": {
getter: function (varBag, idService) {
return varBag.model.variables.getSubCategoryAggr;
}
},
"eVfl28yC0UyFMFmlQdaOVQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getUsersRaisedByAggr;
}
},
"axyE8PQevEqk_P13Ppgs6g": {
getter: function (varBag, idService) {
return varBag.model.variables.getSLAsAggr;
}
},
"2HD_IdI160Cpl+ZOgWCi_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form1"));
})(varBag.model, idService);
}
},
"1cwx2Ou+cEmTQZlyTW7UdQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DueDateFrom"));
})(varBag.model, idService);
}
},
"VYmiJsAb7EGkW2Cdej0z6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label_DueDateFrom"));
})(varBag.model, idService);
}
},
"wZN8Y+RDCkiquAKMGozI6Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_DueDateFromDatePicked"));
})(varBag.model, idService);
}
},
"atsKFRliQ0OZys36volR+g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DueDateTo"));
})(varBag.model, idService);
}
},
"U0hZAbul7kKClGsAfDC95A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Label_DueDateTo"));
})(varBag.model, idService);
}
},
"Bx7zBPZdC0W8keNBxGc_6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_DueDateToDatePicked"));
})(varBag.model, idService);
}
},
"hTJz6BsVqEKgGH8M5rKRww": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Category"));
})(varBag.model, idService);
}
},
"EtSOsW1Zr0G7rxyOSbblsg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Category"));
})(varBag.model, idService);
}
},
"y9Bq3IlSz0W1UDnGY61XOA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SubCategory"));
})(varBag.model, idService);
}
},
"okmFxuMAeE6TcFLdtCjvJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Container_SubCategory"));
})(varBag.model, idService);
}
},
"yjxGVNFzdUCNXLi4Zf2TDg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_SubCategory"));
})(varBag.model, idService);
}
},
"KQTQrzis6kivgCk1K93ybQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SLA"));
})(varBag.model, idService);
}
},
"EZ+CHCI3M0mvsrPgUpQHVw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_SLA"));
})(varBag.model, idService);
}
},
"5hHWH7z0PEa8nXzn+Rm7yQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Priority"));
})(varBag.model, idService);
}
},
"fxlN9iXVaUOvJnoqZ_1Vsg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Priority"));
})(varBag.model, idService);
}
},
"AlGPTNr8bUCO9IdRxgFbEA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Status"));
})(varBag.model, idService);
}
},
"a4qAamXojUS7Xlk+SAxkkQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Status"));
})(varBag.model, idService);
}
},
"gIAzbMZUekyZ11LIsQ9svQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RaisedBy"));
})(varBag.model, idService);
}
},
"O2fmTdhiRE6FAIk2oavGMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_RaisedBy"));
})(varBag.model, idService);
}
},
"BjHXuAEUC0muFg8_gySqgQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Team"));
})(varBag.model, idService);
}
},
"Crb2YfRsfUqy2rNMwHHbxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Team"));
})(varBag.model, idService);
}
},
"EOPfJkrVu0yF1tdWTo9iRA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AssignedTo"));
})(varBag.model, idService);
}
},
"SxoHlrrygU+5Hag94q7jNw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_AssignedTo"));
})(varBag.model, idService);
}
},
"FHRSFsNTukq76G9cXoGi0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("btnClear"));
})(varBag.model, idService);
}
},
"KloTZPBMo0qMMIYBzqpPSQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_Apply"));
})(varBag.model, idService);
}
},
"+lyaAczGoUW_GbQzkH8FlA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreviousFocus"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
