define("Common_CW.PHICore_CW.PreviousFocus.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model"], function (OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CurrentElement", "currentElementIn", "CurrentElement", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_currentElementInDataFetchStatus", "_currentElementInDataFetchStatus", "_currentElementInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("PreviousElement", "previousElementIn", "PreviousElement", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_previousElementInDataFetchStatus", "_previousElementInDataFetchStatus", "_previousElementInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CurrentWidgetId", "currentWidgetIdIn", "CurrentWidgetId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_currentWidgetIdInDataFetchStatus", "_currentWidgetIdInDataFetchStatus", "_currentWidgetIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("CurrentElement" in inputs) {
this.variables.currentElementIn = inputs.CurrentElement;
if("_currentElementInDataFetchStatus" in inputs) {
this.variables._currentElementInDataFetchStatus = inputs._currentElementInDataFetchStatus;
}

}

if("PreviousElement" in inputs) {
this.variables.previousElementIn = inputs.PreviousElement;
if("_previousElementInDataFetchStatus" in inputs) {
this.variables._previousElementInDataFetchStatus = inputs._previousElementInDataFetchStatus;
}

}

if("CurrentWidgetId" in inputs) {
this.variables.currentWidgetIdIn = inputs.CurrentWidgetId;
if("_currentWidgetIdInDataFetchStatus" in inputs) {
this.variables._currentWidgetIdInDataFetchStatus = inputs._currentWidgetIdInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.PreviousFocus");
});
define("Common_CW.PHICore_CW.PreviousFocus.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.PreviousFocus.mvc$model", "Common_CW.PHICore_CW.PreviousFocus.mvc$controller", "Common_CW.clientVariables"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_PreviousFocus_mvc_model, Common_CW_PHICore_CW_PreviousFocus_mvc_controller, Common_CWClientVariables) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.PreviousFocus";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_PreviousFocus_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_PreviousFocus_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.PreviousFocus.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.PreviousFocus.mvc$debugger", "Common_CW.PHICore_CW.PreviousFocus.mvc$controller.OnReady.JavaScript_AddKeyDownJS", "Common_CW.PHICore_CW.PreviousFocus.mvc$controller.OnDestroy.JavaScript_RemoveKeydownJS"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_PreviousFocus_mvc_Debugger, Common_CW_PHICore_CW_PreviousFocus_mvc_controller_OnReady_JavaScript_AddKeyDownJS, Common_CW_PHICore_CW_PreviousFocus_mvc_controller_OnDestroy_JavaScript_RemoveKeydownJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:xfizKe9OaE6iELyLhvL4Uw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.FFQnnO3u+0ectElClNHnAg/ClientActions.xfizKe9OaE6iELyLhvL4Uw:mpJzFka7xEkt_ishrdrC7A", "Common_CW", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:N0BR7z41NUqCs0EGOQDwhw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GodbVU4bo0GsjMJhdWDHOw", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_PreviousFocus_mvc_controller_OnReady_JavaScript_AddKeyDownJS, "JavaScript_AddKeyDown", "OnReady", {
VariableName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.replace(model.variables.currentWidgetIdIn, "-", ""), OS.Types.Text),
PreviousElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.previousElementIn, OS.Types.Text),
CurrentElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.currentElementIn, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:K+4dr9jCYkad0E2JeqI+JQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:xfizKe9OaE6iELyLhvL4Uw", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:AtysNpMVtkyEhYOgYkdgVA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.FFQnnO3u+0ectElClNHnAg/ClientActions.AtysNpMVtkyEhYOgYkdgVA:IzhmYSq8Eo8AX70iRiGLPw", "Common_CW", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_MYlYsZw6UOUQvcx4CsoTQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fJ24kph_1UqxAc518JiFLA", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_PreviousFocus_mvc_controller_OnDestroy_JavaScript_RemoveKeydownJS, "JavaScript_RemoveKeydown", "OnDestroy", {
VariableName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.replace(model.variables.currentWidgetIdIn, "-", ""), OS.Types.Text),
CurrentElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.currentElementIn, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rKp7H6DbEUOokY0E+eukgg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:AtysNpMVtkyEhYOgYkdgVA", callContext.id);
}

};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:FFQnnO3u+0ectElClNHnAg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.FFQnnO3u+0ectElClNHnAg:BQMunXAYnDQPOrEbvFukCA", "Common_CW", "PreviousFocus", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:FFQnnO3u+0ectElClNHnAg", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/PreviousFocus On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/PreviousFocus On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});
define("Common_CW.PHICore_CW.PreviousFocus.mvc$controller.OnReady.JavaScript_AddKeyDownJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// Define the event handler function
window[$parameters.VariableName] = function(e) {
    // Use the event parameter directly, no need to redefine it
    var charCode = e.which || e.keyCode;
    
    // Check if the Shift key and Tab key (key code 9) are pressed
    if (e.shiftKey && charCode == 9) {
        try {
            // Focus on the previous element and prevent the default behavior
            document.querySelector($parameters.PreviousElement).focus();
            e.preventDefault();
        } catch (error) {
            // Optionally log the error for debugging purposes
            console.error('Error focusing on the previous element:', error);
        }
    }
    return false;
};

// Get the current element using the provided selector
let element = document.querySelector($parameters.CurrentElement);

// If the element is found, add the event listener
if (element !== null) {
    element.addEventListener("keydown", window[$parameters.VariableName], false);
} else {
    // Optionally log if the element is not found
    console.warn('Element not found:', $parameters.CurrentElement);
}

};
});
define("Common_CW.PHICore_CW.PreviousFocus.mvc$controller.OnDestroy.JavaScript_RemoveKeydownJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
let element = document.querySelector($parameters.CurrentElement);
if (element !== null) { // Only proceed if the element is found
    try {
        // Check if the variable is defined on the window object before trying to remove the event listener
        if (window[$parameters.VariableName]) {
            element.removeEventListener("keydown", window[$parameters.VariableName], false);
        }
    } catch (error) {
        // Optionally log the error or handle it as needed
        console.error('Error removing event listener:', error);
    }
}

};
});

define("Common_CW.PHICore_CW.PreviousFocus.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"GodbVU4bo0GsjMJhdWDHOw": {
getter: function (varBag, idService) {
return varBag.javaScript_AddKeyDownJSResult.value;
}
},
"fJ24kph_1UqxAc518JiFLA": {
getter: function (varBag, idService) {
return varBag.javaScript_RemoveKeydownJSResult.value;
}
},
"vh+z90fgf0WeCeCxl9kjTg": {
getter: function (varBag, idService) {
return varBag.model.variables.currentElementIn;
},
dataType: OS.Types.Text
},
"2qMZWzPLnEiaKTojjKqm+Q": {
getter: function (varBag, idService) {
return varBag.model.variables.previousElementIn;
},
dataType: OS.Types.Text
},
"YprO7yhCek25uS2RSGnHeg": {
getter: function (varBag, idService) {
return varBag.model.variables.currentWidgetIdIn;
},
dataType: OS.Types.Text
},
"9r0zN1O+lkmW6_KtAjo2Vw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("False2"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
