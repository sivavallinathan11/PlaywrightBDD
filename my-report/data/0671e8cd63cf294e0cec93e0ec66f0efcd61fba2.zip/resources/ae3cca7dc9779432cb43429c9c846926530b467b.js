define("OutSystemsCharts.controller$AddModuleToBeLoaded", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$AddModuleToBeLoaded.AddModuleJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_AddModuleToBeLoaded_AddModuleJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.addModuleToBeLoaded$Action = function (highchartModulesIdentifierIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.AddModuleToBeLoaded$vars"))());
vars.value.highchartModulesIdentifierInLocal = highchartModulesIdentifierIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:T4iprWG+1ket8V+MmZj7Lw:/ClientActionFlows.T4iprWG+1ket8V+MmZj7Lw:vxqRNDCIKY0nXoDLFXAYrA", "OutSystemsCharts", "AddModuleToBeLoaded", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:elnK10pyTE6xSmpNZ25aRg", callContext.id);
var block2 = false;
do {
block2 = false;
var block4 = false;
do {
block4 = false;
var block1 = false;
do {
block1 = false;
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:BeWdUGr48Uu6hV3E26ckAg", callContext.id) && (vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.annotations))) {
// Annotations
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fipW+6+DCky9RUdpLgBYRA", callContext.id);
// ModuleURL = Scripts.Annotations.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Annotations.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.arcDiagram)) {
// ArcDiagram
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:slR0ipsvSkeRcgPDkmx06Q", callContext.id);
// ModuleURL = Scripts.ArcDiagram.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.ArcDiagram.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.bellcurve)) {
// Bellcurve
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ux9lp1uX1EqA1fVMfi9E0Q", callContext.id);
// ModuleURL = Scripts.HistogramBellcurve.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.HistogramBellcurve.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.boost)) {
// Boost
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ALQOx3cgwUSR75e5vCGibQ", callContext.id);
// ModuleURL = Scripts.Boost.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Boost.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.brokenAxis)) {
// BrokenAxis
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Qqy8xrEIZ0SD3ElerYH2Tw", callContext.id);
// ModuleURL = Scripts.BrokenAxis.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.BrokenAxis.js");
} else {
var block5 = false;
do {
block5 = false;
do {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.bullet)) {
// Bullet
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Z2ddWxIpG0+tiDG2imFZaw", callContext.id);
// ModuleURL = Scripts.Bullet.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Bullet.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.canvasTools)) {
// CanvasTools
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Y_OfquNCAUWtulMMAxLANw", callContext.id);
// ModuleURL = Scripts.CanvasTools.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.CanvasTools.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.cylinder)) {
// Cylinder
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:xG_dA0UOYUCMiHhG18X5JQ", callContext.id);
// ModuleURL = Scripts.Cylinder.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Cylinder.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.data)) {
// Data
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:H2AGSbT9wUSI6FLydaeZXg", callContext.id);
// ModuleURL = Scripts.Data.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Data.js");
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.dependencyWheel)) {
// DependencyWheel
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:XyXAr4bSQkGVTNj1VpXDSg", callContext.id);
// ModuleURL = Scripts.DependencyWheel.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.DependencyWheel.js");
} else {
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:p_NbpQOMfUuuNwqCKaZrog", callContext.id) && (vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.drilldown))) {
// Drilldown
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:4V4KXTt91kSUC51JKHSfMg", callContext.id);
// ModuleURL = Scripts.Drilldown.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Drilldown.js");
// jump to block1
block1 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.dumbbell)) {
// Dumbbell
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ImQ5oIsjXkGlB027cNNmVA", callContext.id);
// ModuleURL = Scripts.Dumbbell.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Dumbbell.js");
// jump to block1
block1 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.funnel)) {
// Funnel
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:81izDZrun0yznbfV+SzOvA", callContext.id);
// ModuleURL = Scripts.Funnel.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Funnel.js");
// jump to block1
block1 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.funnel3d)) {
// Funnel3d
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:iWtGzBDSykKWXg57C0_7vA", callContext.id);
// ModuleURL = Scripts.Funnel3d.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Funnel3d.js");
// jump to block1
block1 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.heatmap)) {
// Heatmap
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:38y+YOWwtUWb+EdQvSjrLg", callContext.id);
// ModuleURL = Scripts.Heatmap.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Heatmap.js");
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.histogram)) {
// Histogram
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:1aVxRkRqR0CteEr1x_hqHg", callContext.id);
// ModuleURL = Scripts.HistogramBellcurve.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.HistogramBellcurve.js");
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.itemSeries)) {
// ItemSeries
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:mM8GKLP4qka+rOcIUvkUbw", callContext.id);
// ModuleURL = Scripts.ItemSeries.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.ItemSeries.js");
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.lollipop)) {
// Lollipop
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Id7JTyPz2UqTfunup_bH_A", callContext.id);
// ModuleURL = Scripts.Lollipop.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Lollipop.js");
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.networkgraph)) {
// Networkgraph
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:OC2C0My+DEWZONzM7p7SPA", callContext.id);
// ModuleURL = Scripts.Networkgraph.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Networkgraph.js");
break;
} else {
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9d_7f1kcz0i2S48h+qWkXA", callContext.id) && (vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.offlineExporting))) {
// OfflineExporting
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wH+lYvOthEqB2EGdjdeNNw", callContext.id);
// ModuleURL = Scripts.OfflineExporting.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.OfflineExporting.js");
// jump to block4
block4 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.organization)) {
// Organization
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:TnlxKNNo5EKulOZE2iv6SA", callContext.id);
// ModuleURL = Scripts.Organization.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Organization.js");
// jump to block4
block4 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.pareto)) {
// Pareto
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:5wfTr34zsUii7bm_lUN8Vg", callContext.id);
// ModuleURL = Scripts.Pareto.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Pareto.js");
// jump to block4
block4 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.pictorial)) {
// Pictorial
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:E30oc7X0dUi659em+o_k3g", callContext.id);
// ModuleURL = Scripts.Pictorial.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Pictorial.js");
// jump to block4
block4 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.pyramid3d)) {
// Pyramid3d
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:jL557OHQu06bZQYzR571oA", callContext.id);
// ModuleURL = Scripts.Pyramid3d.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Pyramid3d.js");
// jump to block4
block4 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.sankey)) {
// Sankey
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wxSm1MFD2Ey2etBOHdUhBw", callContext.id);
// ModuleURL = Scripts.Sankey.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Sankey.js");
// jump to block5
block5 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.solidGauge)) {
// SolidGauge
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lfSMevquDUSTJqfuOaR+4A", callContext.id);
// ModuleURL = Scripts.SolidGauge.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.SolidGauge.js");
// jump to block5
block5 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.streamgraph)) {
// Streamgraph
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:bVNEZy_OYEmlFEB5oVNOxQ", callContext.id);
// ModuleURL = Scripts.Streamgraph.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Streamgraph.js");
// jump to block5
block5 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.sunburst)) {
// Sunburst
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9kVJzp5tokG3UpcU0Y209A", callContext.id);
// ModuleURL = Scripts.Sunburst.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Sunburst.js");
// jump to block5
block5 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.tilemap)) {
// Tilemap
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fyvTcD6DI0KkpZnGR2KeSA", callContext.id);
// ModuleURL = Scripts.Tilemap.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Tilemap.js");
// jump to block5
block5 = true;
break;
} else {
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:kJGIxb9WBkKOc7rDa2VfPw", callContext.id) && (vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.timeline))) {
// Timeline
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:YQRKlehhhUKh3QDxM0XAQA", callContext.id);
// ModuleURL = Scripts.Timeline.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Timeline.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.treegraph)) {
// Treegraph
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:t6J7H4Dg5ESL5QjZTECpEQ", callContext.id);
// ModuleURL = Scripts.Treegraph.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Treegraph.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.treemap)) {
// Treemap
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:dHsvgAw5L0y0yoUb83XbAQ", callContext.id);
// ModuleURL = Scripts.Treemap.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Treemap.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.variablePie)) {
// VariablePie
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:42c64JCYzkyxZgLjl_9gmQ", callContext.id);
// ModuleURL = Scripts.VariablePie.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.VariablePie.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.variwide)) {
// Variwide
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:b4yl9_eOZEy8HvuaGaB2wQ", callContext.id);
// ModuleURL = Scripts.Variwide.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Variwide.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.vector)) {
// Vector
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:gwcHPY585U2kwp88lUgdGA", callContext.id);
// ModuleURL = Scripts.Vector.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Vector.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.venn)) {
// Venn
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:k_jwxm0MfU6plFGJ07nCgQ", callContext.id);
// ModuleURL = Scripts.Venn.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Venn.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.windbarb)) {
// Windbarb
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:VVX5hasU7kajNtI13AY+Ew", callContext.id);
// ModuleURL = Scripts.Windbarb.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Windbarb.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.wordcloud)) {
// Wordcloud
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:OPOHvrxlAEeXUdAUHpYY2w", callContext.id);
// ModuleURL = Scripts.Wordcloud.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.Wordcloud.js");
// jump to block2
block2 = true;
break;
} else {
if((vars.value.highchartModulesIdentifierInLocal === OutSystemsChartsModel.staticEntities.highchartModules.xrange)) {
// Xrange
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wTUYNa+tbkOwOgZzfIJdZA", callContext.id);
// ModuleURL = Scripts.XRange.URL
vars.value.moduleURLVar = OS.Navigation.VersionedURL.getVersionedUrl("scripts/OutSystemsCharts.XRange.js");
// jump to block2
block2 = true;
break;
} else {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ZBxJfHGbbEeU3xvIhbfsyg", callContext.id);
return ;

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Lc1ThYBTW0aCTDZ7JCjoeA", callContext.id);
} while(false)
;
if((block1 || (block2 || (block4 || block5)))) {
break;
}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:R7iZGUAdPE6GycK7sNd4qw", callContext.id);
} while(false)
;
if((block1 || (block2 || block4))) {
break;
}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:5dOWYP8k6kimJ5jbUuB6HA", callContext.id);
// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:K9yXoW9QOUaEF9gZJYVqAA", callContext.id);
// jump to block2
block2 = true;
break;
}

}

}

}

}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:iJsQ7iUACUiMOj2QGhCkMA", callContext.id);
} while(false)
;
if((block2 || block4)) {
break;
}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:7H2XG3L0g0GdIuk82nWDEg", callContext.id);
} while(false)
;
if(block2) {
break;
}

// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:r3QyeHIDfE2zaxzFCFmetQ", callContext.id);
// ➡
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:tZhayBFK8kex2HGmQZSkiQ", callContext.id);
} while(false)
;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:To_U18m+jEmPZlQNUJIdaA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_AddModuleToBeLoaded_AddModuleJS, "AddModule", "AddModuleToBeLoaded", {
ModuleUrl: OS.DataConversion.JSNodeParamConverter.to(vars.value.moduleURLVar, OS.Types.Text),
ModuleName: OS.DataConversion.JSNodeParamConverter.to(vars.value.highchartModulesIdentifierInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:mfr58k5WtkCWxgw0WSQ0ug", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:T4iprWG+1ket8V+MmZj7Lw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.AddModuleToBeLoaded$vars", [{
name: "HighchartModulesIdentifier",
attrName: "highchartModulesIdentifierInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ModuleURL",
attrName: "moduleURLVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.addModuleToBeLoaded$Action = function (highchartModulesIdentifierIn) {
highchartModulesIdentifierIn = (highchartModulesIdentifierIn === undefined) ? "" : highchartModulesIdentifierIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.addModuleToBeLoaded$Action.bind(controller, highchartModulesIdentifierIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$AddModuleToBeLoaded.AddModuleJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.Advanced.AddScriptModule($parameters.ModuleName, $parameters.ModuleUrl);
};
});

define("OutSystemsCharts.controller$AdvancedFormat_Init_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedDataPointFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.advancedFormat_Init_v1$Action = function (dataPointFormatsIn, dataSeriesFormatsIn, xAxisJSONIn, yAxisJSONIn, highchartsJSONIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.AdvancedFormat_Init_v1$vars"))());
vars.value.dataPointFormatsInLocal = dataPointFormatsIn.clone();
vars.value.dataSeriesFormatsInLocal = dataSeriesFormatsIn.clone();
vars.value.xAxisJSONInLocal = xAxisJSONIn;
vars.value.yAxisJSONInLocal = yAxisJSONIn;
vars.value.highchartsJSONInLocal = highchartsJSONIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.AdvancedFormat_Init_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:XmgsH+5BUEOUnS3pK4Vgww:/ClientActionFlows.XmgsH+5BUEOUnS3pK4Vgww:1ozp26giX2WGOHhijm4x8w", "OutSystemsCharts", "AdvancedFormat_Init_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:x+CXQWLFvkC575QQkbuPdA", callContext.id);
// Set AdvancedFormat
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oEyhnRzTDkm_Rtynq8bf8Q", callContext.id);
// AdvancedFormat.DataPointFormats = DataPointFormats
outVars.value.advancedFormatOut.dataPointFormatsAttr = vars.value.dataPointFormatsInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oEyhnRzTDkm_Rtynq8bf8Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AdvancedFormat.DataSeriesFormats = DataSeriesFormats
outVars.value.advancedFormatOut.dataSeriesFormatsAttr = vars.value.dataSeriesFormatsInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oEyhnRzTDkm_Rtynq8bf8Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AdvancedFormat.XAxisJSON = XAxisJSON
outVars.value.advancedFormatOut.xAxisJSONAttr = vars.value.xAxisJSONInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oEyhnRzTDkm_Rtynq8bf8Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AdvancedFormat.YAxisJSON = YAxisJSON
outVars.value.advancedFormatOut.yAxisJSONAttr = vars.value.yAxisJSONInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oEyhnRzTDkm_Rtynq8bf8Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// AdvancedFormat.HighchartsJSON = HighchartsJSON
outVars.value.advancedFormatOut.highchartsJSONAttr = vars.value.highchartsJSONInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:KZ+_K0ieMEa2Z6nly_zM8A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:XmgsH+5BUEOUnS3pK4Vgww", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.AdvancedFormat_Init_v1$vars", [{
name: "DataPointFormats",
attrName: "dataPointFormatsInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_AdvancedDataPointFormatList();
},
complexType: OutSystemsChartsModel.Legacy_AdvancedDataPointFormatList
}, {
name: "DataSeriesFormats",
attrName: "dataSeriesFormatsInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_AdvancedDataSeriesFormatList();
},
complexType: OutSystemsChartsModel.Legacy_AdvancedDataSeriesFormatList
}, {
name: "XAxisJSON",
attrName: "xAxisJSONInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "YAxisJSON",
attrName: "yAxisJSONInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "HighchartsJSON",
attrName: "highchartsJSONInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.AdvancedFormat_Init_v1$outVars", [{
name: "AdvancedFormat",
attrName: "advancedFormatOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_AdvancedFormatRec();
},
complexType: OutSystemsChartsModel.Legacy_AdvancedFormatRec
}]);
OutSystemsChartsController.default.clientActionProxies.advancedFormat_Init_v1$Action = function (dataPointFormatsIn, dataSeriesFormatsIn, xAxisJSONIn, yAxisJSONIn, highchartsJSONIn) {
dataPointFormatsIn = (dataPointFormatsIn === undefined) ? new OutSystemsChartsModel.Legacy_AdvancedDataPointFormatList() : dataPointFormatsIn;
dataSeriesFormatsIn = (dataSeriesFormatsIn === undefined) ? new OutSystemsChartsModel.Legacy_AdvancedDataSeriesFormatList() : dataSeriesFormatsIn;
xAxisJSONIn = (xAxisJSONIn === undefined) ? "" : xAxisJSONIn;
yAxisJSONIn = (yAxisJSONIn === undefined) ? "" : yAxisJSONIn;
highchartsJSONIn = (highchartsJSONIn === undefined) ? "" : highchartsJSONIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.advancedFormat_Init_v1$Action.bind(controller, dataPointFormatsIn, dataSeriesFormatsIn, OS.DataConversion.JSNodeParamConverter.from(xAxisJSONIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(yAxisJSONIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(highchartsJSONIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AdvancedFormat: actionResults.advancedFormatOut
};
});
};
});

define("OutSystemsCharts.controller$ChartEventSubscribe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$ChartEventSubscribe.ChartEventRegisterJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_ChartEventSubscribe_ChartEventRegisterJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.chartEventSubscribe$Action = function (chartWidgetIdIn, chartEventIdIn, callbackIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.ChartEventSubscribe$vars"))());
vars.value.chartWidgetIdInLocal = chartWidgetIdIn;
vars.value.chartEventIdInLocal = chartEventIdIn;
vars.value.callbackInLocal = callbackIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:zV+pL5D78UqPcieCIjqa3w:/ClientActionFlows.zV+pL5D78UqPcieCIjqa3w:6GPu6eAw6yzOfcn7PHslCw", "OutSystemsCharts", "ChartEventSubscribe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wlMs15oqMEW4lPsLpV3iow", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:aXNWKuMVqk2mGc8AUKG1Ig", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_ChartEventSubscribe_ChartEventRegisterJS, "ChartEventRegister", "ChartEventSubscribe", {
ChartEventId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartEventIdInLocal, OS.Types.Text),
Callback: OS.DataConversion.JSNodeParamConverter.to(vars.value.callbackInLocal, OS.Types.Object),
ChartWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartWidgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:sY8_siphVEKSEBRZ02eGLA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:zV+pL5D78UqPcieCIjqa3w", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.ChartEventSubscribe$vars", [{
name: "ChartWidgetId",
attrName: "chartWidgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ChartEventId",
attrName: "chartEventIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Callback",
attrName: "callbackInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsChartsController.default.clientActionProxies.chartEventSubscribe$Action = function (chartWidgetIdIn, chartEventIdIn, callbackIn) {
chartWidgetIdIn = (chartWidgetIdIn === undefined) ? "" : chartWidgetIdIn;
chartEventIdIn = (chartEventIdIn === undefined) ? "" : chartEventIdIn;
callbackIn = (callbackIn === undefined) ? null : callbackIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.chartEventSubscribe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartWidgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(chartEventIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(callbackIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$ChartEventSubscribe.ChartEventRegisterJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.Events.Subscribe($parameters.ChartWidgetId,$parameters.ChartEventId,$parameters.Callback);
};
});

define("OutSystemsCharts.controller$ChartEventUnsubscribe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$ChartEventUnsubscribe.SeriesEventUnregisterJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_ChartEventUnsubscribe_SeriesEventUnregisterJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.chartEventUnsubscribe$Action = function (chartWidgetIdIn, chartEventIdIn, callbackIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.ChartEventUnsubscribe$vars"))());
vars.value.chartWidgetIdInLocal = chartWidgetIdIn;
vars.value.chartEventIdInLocal = chartEventIdIn;
vars.value.callbackInLocal = callbackIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:jKz3b7uDYESdf5cHJSlMYg:/ClientActionFlows.jKz3b7uDYESdf5cHJSlMYg:irZeTu+OHW1Ofd8Qw2U94Q", "OutSystemsCharts", "ChartEventUnsubscribe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:OwgPMsD9D0GaJxbtpWU30w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:qPa8VN0qmUK_xhJcwScpVA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_ChartEventUnsubscribe_SeriesEventUnregisterJS, "SeriesEventUnregister", "ChartEventUnsubscribe", {
Callback: OS.DataConversion.JSNodeParamConverter.to(vars.value.callbackInLocal, OS.Types.Object),
ChartWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartWidgetIdInLocal, OS.Types.Text),
ChartEventId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartEventIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:1cFxg1AvYUO5BUXNlIWrEg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:jKz3b7uDYESdf5cHJSlMYg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.ChartEventUnsubscribe$vars", [{
name: "ChartWidgetId",
attrName: "chartWidgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ChartEventId",
attrName: "chartEventIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Callback",
attrName: "callbackInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsChartsController.default.clientActionProxies.chartEventUnsubscribe$Action = function (chartWidgetIdIn, chartEventIdIn, callbackIn) {
chartWidgetIdIn = (chartWidgetIdIn === undefined) ? "" : chartWidgetIdIn;
chartEventIdIn = (chartEventIdIn === undefined) ? "" : chartEventIdIn;
callbackIn = (callbackIn === undefined) ? null : callbackIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.chartEventUnsubscribe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartWidgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(chartEventIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(callbackIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$ChartEventUnsubscribe.SeriesEventUnregisterJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.Events.Unsubscribe($parameters.ChartWidgetId,$parameters.ChartEventId,$parameters.Callback);
};
});

define("OutSystemsCharts.controller$ChartFormat_Init_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_ChartFormatRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.chartFormat_Init_v1$Action = function (showDataPointValuesIn, useAnimationIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.ChartFormat_Init_v1$vars"))());
vars.value.showDataPointValuesInLocal = showDataPointValuesIn;
vars.value.useAnimationInLocal = useAnimationIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.ChartFormat_Init_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:QsWMzoKNrUOSho1+zvc2GA:/ClientActionFlows.QsWMzoKNrUOSho1+zvc2GA:9XhL+BUeyOnb+peVT9YU4w", "OutSystemsCharts", "ChartFormat_Init_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:8G7xvgdvgU6Uv_OINIph7Q", callContext.id);
// Set ChartFormat
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:MqLUVslihE6r2h+x3nW35g", callContext.id);
// ChartFormat.ShowDataPointValues = ShowDataPointValues
outVars.value.chartFormatOut.showDataPointValuesAttr = vars.value.showDataPointValuesInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:MqLUVslihE6r2h+x3nW35g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ChartFormat.UseAnimation = UseAnimation
outVars.value.chartFormatOut.useAnimationAttr = vars.value.useAnimationInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:bZkrnbo4_kqPCT_6NLLtsg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:QsWMzoKNrUOSho1+zvc2GA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.ChartFormat_Init_v1$vars", [{
name: "ShowDataPointValues",
attrName: "showDataPointValuesInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "UseAnimation",
attrName: "useAnimationInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.ChartFormat_Init_v1$outVars", [{
name: "ChartFormat",
attrName: "chartFormatOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_ChartFormatRec();
},
complexType: OutSystemsChartsModel.Legacy_ChartFormatRec
}]);
OutSystemsChartsController.default.clientActionProxies.chartFormat_Init_v1$Action = function (showDataPointValuesIn, useAnimationIn) {
showDataPointValuesIn = (showDataPointValuesIn === undefined) ? false : showDataPointValuesIn;
useAnimationIn = (useAnimationIn === undefined) ? false : useAnimationIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.chartFormat_Init_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(showDataPointValuesIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(useAnimationIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ChartFormat: actionResults.chartFormatOut
};
});
};
});

define("OutSystemsCharts.controller$CreateAxis", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$CreateAxis.CreateAxisJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_CreateAxis_CreateAxisJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.createAxis$Action = function (uniqueIdIn, configsIn, typeIn, providerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.CreateAxis$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
vars.value.typeInLocal = typeIn;
vars.value.providerInLocal = providerIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:BREM9UreNkC94MwbS9avRQ:/ClientActionFlows.BREM9UreNkC94MwbS9avRQ:ybR5AsEh5LKErDumrIbLjQ", "OutSystemsCharts", "CreateAxis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pInOsJuz40acLqgJEp35+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:qEFFsHDywEWP12REQYxnAw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_CreateAxis_CreateAxisJS, "CreateAxis", "CreateAxis", {
provider: OS.DataConversion.JSNodeParamConverter.to(vars.value.providerInLocal, OS.Types.Text),
type: OS.DataConversion.JSNodeParamConverter.to(vars.value.typeInLocal, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lyXCM58lMEeG3pFiyE9nFw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:BREM9UreNkC94MwbS9avRQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.CreateAxis$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Type",
attrName: "typeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Provider",
attrName: "providerInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.createAxis$Action = function (uniqueIdIn, configsIn, typeIn, providerIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
typeIn = (typeIn === undefined) ? "" : typeIn;
providerIn = (providerIn === undefined) ? "" : providerIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.createAxis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), typeIn, providerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$CreateAxis.CreateAxisJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.AxisManager.CreateAxis(
    $parameters.uniqueId,
    $parameters.configs,
    $parameters.type,
    $parameters.provider
);
};
});

define("OutSystemsCharts.controller$CreateChart", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$CreateChart.CreateChartJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_CreateChart_CreateChartJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.createChart$Action = function (uniqueIdIn, typeIn, configsIn, versionIn, providerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.CreateChart$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.typeInLocal = typeIn;
vars.value.configsInLocal = configsIn;
vars.value.versionInLocal = versionIn;
vars.value.providerInLocal = providerIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:SgagkjkpjE+tMsiytpKiaA:/ClientActionFlows.SgagkjkpjE+tMsiytpKiaA:Qo5gp0Cwh_doii1SI4Sz0A", "OutSystemsCharts", "CreateChart", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lK+oZD3ozU69+oxGwGJSBg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lG2n0UxFe0uo8VH+2gxmYA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_CreateChart_CreateChartJS, "CreateChart", "CreateChart", {
provider: OS.DataConversion.JSNodeParamConverter.to(vars.value.providerInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
version: OS.DataConversion.JSNodeParamConverter.to(vars.value.versionInLocal, OS.Types.Text),
type: OS.DataConversion.JSNodeParamConverter.to(vars.value.typeInLocal, OS.Types.Text),
chartID: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pDSzKFecG0GDYn5ZnbNyng", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:SgagkjkpjE+tMsiytpKiaA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.CreateChart$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Type",
attrName: "typeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Version",
attrName: "versionInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Provider",
attrName: "providerInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.createChart$Action = function (uniqueIdIn, typeIn, configsIn, versionIn, providerIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
typeIn = (typeIn === undefined) ? "" : typeIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
versionIn = (versionIn === undefined) ? "" : versionIn;
providerIn = (providerIn === undefined) ? "" : providerIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.createChart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(typeIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), versionIn, providerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$CreateChart.CreateChartJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.CreateChart(
    $parameters.chartID,
    $parameters.type,
    $parameters.configs,
    $parameters.version,
    $parameters.provider
);
};
});

define("OutSystemsCharts.controller$CreateExport", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$CreateExport.CreateExportJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_CreateExport_CreateExportJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.createExport$Action = function (uniqueIdIn, configsIn, providerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.CreateExport$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
vars.value.providerInLocal = providerIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:END776SWr0GPfE+67_Z1Qw:/ClientActionFlows.END776SWr0GPfE+67_Z1Qw:lcfaOTM0iq2opqviq95dHA", "OutSystemsCharts", "CreateExport", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:AS+t9clTEkeKem5iooU2Og", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:tO4gGQlBNkKYIQ72ZCX8jA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_CreateExport_CreateExportJS, "CreateExport", "CreateExport", {
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
provider: OS.DataConversion.JSNodeParamConverter.to(vars.value.providerInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lvNAxwYHJUi98OqVEYFMXg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:END776SWr0GPfE+67_Z1Qw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.CreateExport$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Provider",
attrName: "providerInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.createExport$Action = function (uniqueIdIn, configsIn, providerIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
providerIn = (providerIn === undefined) ? "" : providerIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.createExport$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), providerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$CreateExport.CreateExportJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ExportManager.CreateExport(
    $parameters.uniqueId,
    $parameters.configs,
    $parameters.provider
);
};
});

define("OutSystemsCharts.controller$CreateLegend", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$CreateLegend.CreateLegendJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_CreateLegend_CreateLegendJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.createLegend$Action = function (uniqueIdIn, configsIn, providerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.CreateLegend$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
vars.value.providerInLocal = providerIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:ntm0Ngbq2kCmWRKGXD4bHA:/ClientActionFlows.ntm0Ngbq2kCmWRKGXD4bHA:pxmp9ezWOnxtTmdVY_qhcw", "OutSystemsCharts", "CreateLegend", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vT7ppVpHGkGbdWCNXJVdbA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:cBuKy23MG0OIZMxHC+Pv7A", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_CreateLegend_CreateLegendJS, "CreateLegend", "CreateLegend", {
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
provider: OS.DataConversion.JSNodeParamConverter.to(vars.value.providerInLocal, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Hwhlth68MkSALvpgfx216g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:ntm0Ngbq2kCmWRKGXD4bHA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.CreateLegend$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Provider",
attrName: "providerInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.createLegend$Action = function (uniqueIdIn, configsIn, providerIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
providerIn = (providerIn === undefined) ? "" : providerIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.createLegend$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), providerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$CreateLegend.CreateLegendJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.LegendManager.CreateLegend(
    $parameters.uniqueId,
    $parameters.configs,
    $parameters.provider
);
};
});

define("OutSystemsCharts.controller$CreateSeriesStyling", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$CreateSeriesStyling.CreateSeriesStylingJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_CreateSeriesStyling_CreateSeriesStylingJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.createSeriesStyling$Action = function (uniqueIdIn, configsIn, providerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.CreateSeriesStyling$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
vars.value.providerInLocal = providerIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:83+ihqReikqr1ucYnsjcAA:/ClientActionFlows.83+ihqReikqr1ucYnsjcAA:KAaMPS531I7oQ5JnxLwoBQ", "OutSystemsCharts", "CreateSeriesStyling", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0Vl1O0MRqEuxIN9QRM0Sag", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:im7Q_pDvAU+kxH+v2h0szg", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_CreateSeriesStyling_CreateSeriesStylingJS, "CreateSeriesStyling", "CreateSeriesStyling", {
provider: OS.DataConversion.JSNodeParamConverter.to(vars.value.providerInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:g1wqBbeo+k2G3h5pEQZAaw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:83+ihqReikqr1ucYnsjcAA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.CreateSeriesStyling$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Provider",
attrName: "providerInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.createSeriesStyling$Action = function (uniqueIdIn, configsIn, providerIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
providerIn = (providerIn === undefined) ? "" : providerIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.createSeriesStyling$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), providerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$CreateSeriesStyling.CreateSeriesStylingJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.SeriesManager.CreateSeriesStyling(
    $parameters.uniqueId,
    $parameters.configs,
    $parameters.provider
);
};
});

define("OutSystemsCharts.controller$DataPoint_Init_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_DataPointRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.dataPoint_Init_v1$Action = function (labelIn, valueIn, dataSeriesNameIn, tooltipIn, colorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DataPoint_Init_v1$vars"))());
vars.value.labelInLocal = labelIn;
vars.value.valueInLocal = valueIn;
vars.value.dataSeriesNameInLocal = dataSeriesNameIn;
vars.value.tooltipInLocal = tooltipIn;
vars.value.colorInLocal = colorIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DataPoint_Init_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:IMMgJt9B5kO20MGNHqYbYA:/ClientActionFlows.IMMgJt9B5kO20MGNHqYbYA:U1ROKnDBUnDQYFoDCuv5Pg", "OutSystemsCharts", "DataPoint_Init_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:GCzvnt1c9E+5U6vwMKEIjg", callContext.id);
// Set DataPoint
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fK8lJolH9kyPunBGGGYe6A", callContext.id);
// DataPoint.Label = Label
outVars.value.dataPointOut.labelAttr = vars.value.labelInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fK8lJolH9kyPunBGGGYe6A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DataPoint.Value = Value
outVars.value.dataPointOut.valueAttr = vars.value.valueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fK8lJolH9kyPunBGGGYe6A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DataPoint.SeriesName = DataSeriesName
outVars.value.dataPointOut.seriesNameAttr = vars.value.dataSeriesNameInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fK8lJolH9kyPunBGGGYe6A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// DataPoint.Color = Color
outVars.value.dataPointOut.colorAttr = vars.value.colorInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fK8lJolH9kyPunBGGGYe6A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// DataPoint.Tooltip = Tooltip
outVars.value.dataPointOut.tooltipAttr = vars.value.tooltipInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:qhmumdurH0OMo3ZXj+tpwg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:IMMgJt9B5kO20MGNHqYbYA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DataPoint_Init_v1$vars", [{
name: "Label",
attrName: "labelInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Value",
attrName: "valueInLocal",
mandatory: true,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}, {
name: "DataSeriesName",
attrName: "dataSeriesNameInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Tooltip",
attrName: "tooltipInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Color",
attrName: "colorInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DataPoint_Init_v1$outVars", [{
name: "DataPoint",
attrName: "dataPointOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_DataPointRec();
},
complexType: OutSystemsChartsModel.Legacy_DataPointRec
}]);
OutSystemsChartsController.default.clientActionProxies.dataPoint_Init_v1$Action = function (labelIn, valueIn, dataSeriesNameIn, tooltipIn, colorIn) {
labelIn = (labelIn === undefined) ? "" : labelIn;
valueIn = (valueIn === undefined) ? OS.DataTypes.Decimal.defaultValue : valueIn;
dataSeriesNameIn = (dataSeriesNameIn === undefined) ? "" : dataSeriesNameIn;
tooltipIn = (tooltipIn === undefined) ? "" : tooltipIn;
colorIn = (colorIn === undefined) ? "" : colorIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.dataPoint_Init_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(labelIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(valueIn, OS.Types.Decimal), OS.DataConversion.JSNodeParamConverter.from(dataSeriesNameIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(tooltipIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(colorIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
DataPoint: actionResults.dataPointOut
};
});
};
});

define("OutSystemsCharts.controller$DataPoint_InitMissing_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_DataPointRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.dataPoint_InitMissing_v1$Action = function (labelIn, dataSeriesNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DataPoint_InitMissing_v1$vars"))());
vars.value.labelInLocal = labelIn;
vars.value.dataSeriesNameInLocal = dataSeriesNameIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DataPoint_InitMissing_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:tf_qIgFQ00WWUCvi2YJDFQ:/ClientActionFlows.tf_qIgFQ00WWUCvi2YJDFQ:pwx1FuVRmDYo3qF8wJwVpA", "OutSystemsCharts", "DataPoint_InitMissing_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:cy7VW4SKhkqCkG36Bk_9Ng", callContext.id);
// Set DataPoint
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:sEVKLv12u0mtX92Z613lRA", callContext.id);
// DataPoint.Label = Label
outVars.value.dataPointOut.labelAttr = vars.value.labelInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:sEVKLv12u0mtX92Z613lRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// DataPoint.SeriesName = DataSeriesName
outVars.value.dataPointOut.seriesNameAttr = vars.value.dataSeriesNameInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:sEVKLv12u0mtX92Z613lRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// DataPoint.Value = -2147483647
outVars.value.dataPointOut.valueAttr = OS.BuiltinFunctions.integerToDecimal(-2147483647);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:bbt7clb25ECXNtb62oi+JQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:tf_qIgFQ00WWUCvi2YJDFQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DataPoint_InitMissing_v1$vars", [{
name: "Label",
attrName: "labelInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "DataSeriesName",
attrName: "dataSeriesNameInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DataPoint_InitMissing_v1$outVars", [{
name: "DataPoint",
attrName: "dataPointOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_DataPointRec();
},
complexType: OutSystemsChartsModel.Legacy_DataPointRec
}]);
OutSystemsChartsController.default.clientActionProxies.dataPoint_InitMissing_v1$Action = function (labelIn, dataSeriesNameIn) {
labelIn = (labelIn === undefined) ? "" : labelIn;
dataSeriesNameIn = (dataSeriesNameIn === undefined) ? "" : dataSeriesNameIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.dataPoint_InitMissing_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(labelIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(dataSeriesNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
DataPoint: actionResults.dataPointOut
};
});
};
});

define("OutSystemsCharts.controller$DateParseToJS_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.dateParseToJS_v1$Action = function (valueIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DateParseToJS_v1$vars"))());
vars.value.valueInLocal = valueIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DateParseToJS_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:up01xa+UmUiAuBWZQ0YA7A:/ClientActionFlows.up01xa+UmUiAuBWZQ0YA7A:d_4UtAJlMpHhnUtvBPCapA", "OutSystemsCharts", "DateParseToJS_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Kr+5bCykO0icjMI96tMt6w", callContext.id);
// Valid Date or DateTime?
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:_dh25eqfFkGBw9Jgx5TEaw", callContext.id) && (OS.BuiltinFunctions.textToDateValidate(vars.value.valueInLocal) || OS.BuiltinFunctions.textToDateTimeValidate(vars.value.valueInLocal)))) {
// Output
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:_ie+LTaOmUmIUtQ2_V3qXA", callContext.id);
// TempDateTime = If
vars.value.tempDateTimeVar = ((OS.BuiltinFunctions.textToDateTimeValidate(vars.value.valueInLocal)) ? (OS.BuiltinFunctions.textToDateTime(vars.value.valueInLocal)) : (OS.BuiltinFunctions.textToDate(vars.value.valueInLocal)));
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:_ie+LTaOmUmIUtQ2_V3qXA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Output = FormatDateTime
outVars.value.outputOut = OS.BuiltinFunctions.formatDateTime(vars.value.tempDateTimeVar, "yyyy-MM-ddTHH:mm:ss");
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3wcoUWO_Hke7+fSJcngMmQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:yZPuhPEgdEqGu6MLN0yWjQ", callContext.id);
// Output = Value
outVars.value.outputOut = vars.value.valueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3wcoUWO_Hke7+fSJcngMmQ", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:up01xa+UmUiAuBWZQ0YA7A", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DateParseToJS_v1$vars", [{
name: "Value",
attrName: "valueInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "TempDateTime",
attrName: "tempDateTimeVar",
mandatory: false,
dataType: OS.Types.DateTime,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DateParseToJS_v1$outVars", [{
name: "Output",
attrName: "outputOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.dateParseToJS_v1$Action = function (valueIn) {
valueIn = (valueIn === undefined) ? "" : valueIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.dateParseToJS_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(valueIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Output: OS.DataConversion.JSNodeParamConverter.to(actionResults.outputOut, OS.Types.Text)
};
});
};
});

define("OutSystemsCharts.controller$DestroyAxis", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$DestroyAxis.DisposeJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_DestroyAxis_DisposeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.destroyAxis$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyAxis$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
var disposeJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyAxis$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.disposeJSResult = disposeJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:xchm0kIiGU2gtJtob22snw:/ClientActionFlows.xchm0kIiGU2gtJtob22snw:iPknJp6vsx9YHwShq_tqdg", "OutSystemsCharts", "DestroyAxis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:OXQbI2_FNEufh79Xhhajcw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:YYIMOBQRmEq_zomaYisz1A", callContext.id);
disposeJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_DestroyAxis_DisposeJS, "Dispose", "DestroyAxis", {
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyAxis$disposeJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:L463BFcfgEyWycGOc+EStQ", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(disposeJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wQtWaMpYiEqhiIvAAN3dwg", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wQtWaMpYiEqhiIvAAN3dwg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:wQtWaMpYiEqhiIvAAN3dwg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:36FZWBAuD0GKusBoZb7FcQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:xchm0kIiGU2gtJtob22snw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyAxis$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyAxis$disposeJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyAxis$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.destroyAxis$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.destroyAxis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$DestroyAxis.DisposeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.AxisManager.Dispose($parameters.UniqueId);
};
});

define("OutSystemsCharts.controller$DestroyExport", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$DestroyExport.DisposeJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_DestroyExport_DisposeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.destroyExport$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyExport$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
var disposeJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyExport$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.disposeJSResult = disposeJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:WUwcNZcWh0SeKREr0uwWpw:/ClientActionFlows.WUwcNZcWh0SeKREr0uwWpw:gpXKViOXhUlBsE5p0Vd1xw", "OutSystemsCharts", "DestroyExport", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:JBtaVOpBM0W1Y1bKR7ozEg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:hVdyn6ZQ3kGS3FAttW4G8w", callContext.id);
disposeJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_DestroyExport_DisposeJS, "Dispose", "DestroyExport", {
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyExport$disposeJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lT0+YVCc9EKuf+OWHijsYQ", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(disposeJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
// Set output
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:e_m5nDHSukmaOXP7YS2AXQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:e_m5nDHSukmaOXP7YS2AXQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:e_m5nDHSukmaOXP7YS2AXQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:c8kxVWHfOE+H_DRqV8Djzw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:WUwcNZcWh0SeKREr0uwWpw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyExport$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyExport$disposeJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyExport$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.destroyExport$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.destroyExport$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$DestroyExport.DisposeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.ExportManager.Dispose($parameters.UniqueId);
};
});

define("OutSystemsCharts.controller$DestroyLegend", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$DestroyLegend.DisposeJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_DestroyLegend_DisposeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.destroyLegend$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyLegend$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
var disposeJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyLegend$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.disposeJSResult = disposeJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:AEndcwkuck2PZ3LbVl0FcA:/ClientActionFlows.AEndcwkuck2PZ3LbVl0FcA:FvE3GCZg1d+AwhUH+SWXGQ", "OutSystemsCharts", "DestroyLegend", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pjGmpc4Mv0KMbw2mAnRqbg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ZntvemRI+UmMEI8uDvPnHw", callContext.id);
disposeJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_DestroyLegend_DisposeJS, "Dispose", "DestroyLegend", {
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroyLegend$disposeJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:h0BTxm85SUu_AG+OQOhSEQ", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(disposeJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9cMDLmXCnk+XyZz2zYTmWQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9cMDLmXCnk+XyZz2zYTmWQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9cMDLmXCnk+XyZz2zYTmWQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:N00vuuthcUe1XYNMedVjZw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:AEndcwkuck2PZ3LbVl0FcA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyLegend$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyLegend$disposeJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroyLegend$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.destroyLegend$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.destroyLegend$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$DestroyLegend.DisposeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.LegendManager.Dispose($parameters.UniqueId);
};
});

define("OutSystemsCharts.controller$DestroySeriesStyling", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$DestroySeriesStyling.DisposeJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_DestroySeriesStyling_DisposeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.destroySeriesStyling$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroySeriesStyling$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
var disposeJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroySeriesStyling$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.disposeJSResult = disposeJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:beuu0qPYU0qv_bYaaf3aUQ:/ClientActionFlows.beuu0qPYU0qv_bYaaf3aUQ:kxa6db0STNIwJzSGkkpRCg", "OutSystemsCharts", "DestroySeriesStyling", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:VqulrmaaJU+HFr9utAH6tw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:El6JEIgwwUiad8qYbC+pCw", callContext.id);
disposeJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_DestroySeriesStyling_DisposeJS, "Dispose", "DestroySeriesStyling", {
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.DestroySeriesStyling$disposeJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:H1UucT4gpU2AV0Vc4T4DbQ", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(disposeJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:biZBXvYpF0WUIPiYuae_EQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:biZBXvYpF0WUIPiYuae_EQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:biZBXvYpF0WUIPiYuae_EQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:coZjyigSykKcLAD+8Kbewg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:beuu0qPYU0qv_bYaaf3aUQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroySeriesStyling$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroySeriesStyling$disposeJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.DestroySeriesStyling$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.destroySeriesStyling$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.destroySeriesStyling$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$DestroySeriesStyling.DisposeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.SeriesManager.Dispose($parameters.UniqueId);
};
});

define("OutSystemsCharts.controller$GenerateUniqueId", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$GenerateUniqueId.RandomStringJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_GenerateUniqueId_RandomStringJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.generateUniqueId$Action = function (current_Unique_IDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.GenerateUniqueId$vars"))());
vars.value.current_Unique_IDInLocal = current_Unique_IDIn;
var randomStringJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.GenerateUniqueId$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.randomStringJSResult = randomStringJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:KoqRLaKHpkOf6cPRqQiVww:/ClientActionFlows.KoqRLaKHpkOf6cPRqQiVww:yidS6tUEwkUex5cA3v_6NA", "OutSystemsCharts", "GenerateUniqueId", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:gTSEqtOUn0ml7Nry4+ApeQ", callContext.id);
// Current_ID is empty?
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:CrGwT32aiUK2oxtKMtSrcw", callContext.id) && (vars.value.current_Unique_IDInLocal === OS.BuiltinFunctions.nullTextIdentifier()))) {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:xdNIo_chiUW2yJFGrEEHMw", callContext.id);
randomStringJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_GenerateUniqueId_RandomStringJS, "RandomString", "GenerateUniqueId", {
UniqueID: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.GenerateUniqueId$randomStringJSResult"))();
jsNodeResult.uniqueIDOut = OS.DataConversion.JSNodeParamConverter.from($parameters.UniqueID, OS.Types.Text);
return jsNodeResult;
}, {}, {});
// Return new ID
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:jEZ6pjwn_E+pCvhabYxCLA", callContext.id);
// Unique_ID = RandomString.UniqueID
outVars.value.unique_IDOut = randomStringJSResult.value.uniqueIDOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:x8cp1ZPsI0KXI4um6_sAHg", callContext.id);
} else {
// Return current ID
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:aOyhwYRx5kiftL4+VCXiAA", callContext.id);
// Unique_ID = Current_Unique_ID
outVars.value.unique_IDOut = vars.value.current_Unique_IDInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:x8cp1ZPsI0KXI4um6_sAHg", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:KoqRLaKHpkOf6cPRqQiVww", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.GenerateUniqueId$vars", [{
name: "Current_Unique_ID",
attrName: "current_Unique_IDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.GenerateUniqueId$randomStringJSResult", [{
name: "UniqueID",
attrName: "uniqueIDOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.GenerateUniqueId$outVars", [{
name: "Unique_ID",
attrName: "unique_IDOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.generateUniqueId$Action = function (current_Unique_IDIn) {
current_Unique_IDIn = (current_Unique_IDIn === undefined) ? "" : current_Unique_IDIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.generateUniqueId$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(current_Unique_IDIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Unique_ID: OS.DataConversion.JSNodeParamConverter.to(actionResults.unique_IDOut, OS.Types.Text)
};
});
};
});
define("OutSystemsCharts.controller$GenerateUniqueId.RandomStringJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.UniqueID = Math.random().toString(36);

};
});

define("OutSystemsCharts.controller$InitChart", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$InitChart.InitChartJS", "OutSystemsCharts.model$DataPointList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_InitChart_InitChartJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.initChart$Action = function (uniqueIdIn, sourceDataPointListIn, xAxisTypeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.InitChart$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.sourceDataPointListInLocal = sourceDataPointListIn.clone();
vars.value.xAxisTypeInLocal = xAxisTypeIn;
var jSONSerialize_SourceDataPoint_ListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerialize_SourceDataPoint_ListVar = jSONSerialize_SourceDataPoint_ListVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:Cwy5sl_m70WnB8prZWZqpA:/ClientActionFlows.Cwy5sl_m70WnB8prZWZqpA:L8payWxFqJcSqc8e_VJEIg", "OutSystemsCharts", "InitChart", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:zvTCRWzm502nGV6sGxM7Lw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:qJjJVn6x30KxKQCbsrorKA", callContext.id);
// JSON Serialize: JSONSerialize_SourceDataPoint_List
jSONSerialize_SourceDataPoint_ListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.sourceDataPointListInLocal, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fGpphqry6kisbR18rhsxPw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_InitChart_InitChartJS, "InitChart", "InitChart", {
SourceDataPointList: OS.DataConversion.JSNodeParamConverter.to(jSONSerialize_SourceDataPoint_ListVar.value.jSONOut, OS.Types.Text),
xAxisType: OS.DataConversion.JSNodeParamConverter.to(vars.value.xAxisTypeInLocal, OS.Types.Text),
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:LO7j83+v8UiU3YF4HkdxsA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:Cwy5sl_m70WnB8prZWZqpA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.InitChart$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SourceDataPointList",
attrName: "sourceDataPointListInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.DataPointList();
},
complexType: OutSystemsChartsModel.DataPointList
}, {
name: "XAxisType",
attrName: "xAxisTypeInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.initChart$Action = function (uniqueIdIn, sourceDataPointListIn, xAxisTypeIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
sourceDataPointListIn = (sourceDataPointListIn === undefined) ? new OutSystemsChartsModel.DataPointList() : sourceDataPointListIn;
xAxisTypeIn = (xAxisTypeIn === undefined) ? "" : xAxisTypeIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.initChart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), sourceDataPointListIn, OS.DataConversion.JSNodeParamConverter.from(xAxisTypeIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$InitChart.InitChartJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.InitializeChart(
$parameters.UniqueId, 
$parameters.SourceDataPointList,
$parameters.xAxisType
);
};
});

define("OutSystemsCharts.controller$InitializeAxis", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$InitializeAxis.InitializeAxisJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_InitializeAxis_InitializeAxisJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.initializeAxis$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.InitializeAxis$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:Flzbe_WmOUKLaNUbKXhPfg:/ClientActionFlows.Flzbe_WmOUKLaNUbKXhPfg:PkRpUvtfkw2kGfTtzb+Y6g", "OutSystemsCharts", "InitializeAxis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:7ygfpmAbWkSqyyp9TQFCAg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:6_1vjNezgk+91xOOttgYAA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_InitializeAxis_InitializeAxisJS, "InitializeAxis", "InitializeAxis", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:EdrJGqLMl0W5royrdx_xhg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:Flzbe_WmOUKLaNUbKXhPfg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.InitializeAxis$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.initializeAxis$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.initializeAxis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$InitializeAxis.InitializeAxisJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.AxisManager.InitializeAxis($parameters.uniqueId);
};
});

define("OutSystemsCharts.controller$InitializeExport", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$InitializeExport.InitializeJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_InitializeExport_InitializeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.initializeExport$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.InitializeExport$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:gHC+baV7C0yJilUlocatGA:/ClientActionFlows.gHC+baV7C0yJilUlocatGA:tP6WIoECBSDdSp5v3Vp7jg", "OutSystemsCharts", "InitializeExport", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:rAiuBOrBzEqPrhhSt_fRzQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ZGjEWV0U_0ex9nIsAXR_Cw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_InitializeExport_InitializeJS, "Initialize", "InitializeExport", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:O28T2EjbeUmTa84T+85SuQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:gHC+baV7C0yJilUlocatGA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.InitializeExport$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.initializeExport$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.initializeExport$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$InitializeExport.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ExportManager.InitializeExport($parameters.uniqueId);
};
});

define("OutSystemsCharts.controller$InitializeLegend", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$InitializeLegend.InitializeJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_InitializeLegend_InitializeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.initializeLegend$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.InitializeLegend$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:CRAse0VVgEuk2nlg4PSOSg:/ClientActionFlows.CRAse0VVgEuk2nlg4PSOSg:g4xNSrL5onutCxWyXLGRcQ", "OutSystemsCharts", "InitializeLegend", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:iAwICF6z70a3PAsx9br3Cw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fu4yAIK77kGTpRNVDKTRtw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_InitializeLegend_InitializeJS, "Initialize", "InitializeLegend", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ASzZ_N03MEee5XB4Jb+iLQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:CRAse0VVgEuk2nlg4PSOSg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.InitializeLegend$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.initializeLegend$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.initializeLegend$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$InitializeLegend.InitializeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.LegendManager.InitializeLegend($parameters.uniqueId);
};
});

define("OutSystemsCharts.controller$InitializeSeriesStyling", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$InitializeSeriesStyling.InitializeSeriesStylingJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_InitializeSeriesStyling_InitializeSeriesStylingJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.initializeSeriesStyling$Action = function (uniqueIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.InitializeSeriesStyling$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:5JTv4pp010+6vyYqygr_kg:/ClientActionFlows.5JTv4pp010+6vyYqygr_kg:rXTkCS7vkNMOTZxCv2aYvw", "OutSystemsCharts", "InitializeSeriesStyling", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:8ylKhmxbjk6dLjcTkjhYDA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:05uEsUbFHkSz5kuU+jx0gg", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_InitializeSeriesStyling_InitializeSeriesStylingJS, "InitializeSeriesStyling", "InitializeSeriesStyling", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Igf4a9BFUUeJH4ZLDCsJsg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:5JTv4pp010+6vyYqygr_kg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.InitializeSeriesStyling$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.initializeSeriesStyling$Action = function (uniqueIdIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.initializeSeriesStyling$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$InitializeSeriesStyling.InitializeSeriesStylingJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.SeriesManager.InitializeSeriesStyling($parameters.uniqueId);
};
});

define("OutSystemsCharts.controller$Legacy_InitChart", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$Legacy_InitChart.InitChartJS", "OutSystemsCharts.model$Legacy_DataPointList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_Legacy_InitChart_InitChartJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.legacy_InitChart$Action = function (uniqueIdIn, sourceDataPointListIn, xAxisTypeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.Legacy_InitChart$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.sourceDataPointListInLocal = sourceDataPointListIn.clone();
vars.value.xAxisTypeInLocal = xAxisTypeIn;
var jSONSerialize_SourceDataPoint_ListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerialize_SourceDataPoint_ListVar = jSONSerialize_SourceDataPoint_ListVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:nApYDsmBUEepfRJ+kXN3KQ:/ClientActionFlows.nApYDsmBUEepfRJ+kXN3KQ:MpBbXnRyrkX6gJlSglmGFA", "OutSystemsCharts", "Legacy_InitChart", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:E8YY55xJ00OaDkDQosrHUg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ncmg3ZobxUq6C9NcjL71NA", callContext.id);
// JSON Serialize: JSONSerialize_SourceDataPoint_List
jSONSerialize_SourceDataPoint_ListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.sourceDataPointListInLocal, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:rIIABPAmxECqGVYKYK9t7w", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_Legacy_InitChart_InitChartJS, "InitChart", "Legacy_InitChart", {
UniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
xAxisType: OS.DataConversion.JSNodeParamConverter.to(vars.value.xAxisTypeInLocal, OS.Types.Text),
SourceDataPointList: OS.DataConversion.JSNodeParamConverter.to(jSONSerialize_SourceDataPoint_ListVar.value.jSONOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:MlxcxvB6qUquZNFvP4z_aQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:nApYDsmBUEepfRJ+kXN3KQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.Legacy_InitChart$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SourceDataPointList",
attrName: "sourceDataPointListInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_DataPointList();
},
complexType: OutSystemsChartsModel.Legacy_DataPointList
}, {
name: "XAxisType",
attrName: "xAxisTypeInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.legacy_InitChart$Action = function (uniqueIdIn, sourceDataPointListIn, xAxisTypeIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
sourceDataPointListIn = (sourceDataPointListIn === undefined) ? new OutSystemsChartsModel.Legacy_DataPointList() : sourceDataPointListIn;
xAxisTypeIn = (xAxisTypeIn === undefined) ? "" : xAxisTypeIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.legacy_InitChart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), sourceDataPointListIn, OS.DataConversion.JSNodeParamConverter.from(xAxisTypeIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$Legacy_InitChart.InitChartJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.InitializeChart(
$parameters.UniqueId, 
$parameters.SourceDataPointList,
$parameters.xAxisType
);
};
});

define("OutSystemsCharts.controller$LoadModules", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$LoadModules.ForceReloadJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_LoadModules_ForceReloadJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.loadModules$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var forceReloadJSResult = new OS.DataTypes.VariableHolder();
var deserializeErrorsVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OS.DataTypes.TextList))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.LoadModules$outVars"))());
varBag.callContext = callContext;
varBag.forceReloadJSResult = forceReloadJSResult;
varBag.deserializeErrorsVar = deserializeErrorsVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:IFPH5XezDkyLaAscKTsMbQ:/ClientActionFlows.IFPH5XezDkyLaAscKTsMbQ:ac1c7CJ5TSy+4wadjOtcsw", "OutSystemsCharts", "LoadModules", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0HRPNfiRxE+ogbsC6eOw4Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fAulriwF30uk6n6i6ySFvg", callContext.id);
return controller.safeExecuteAsyncJSNode(OutSystemsCharts_controller_LoadModules_ForceReloadJS, "ForceReload", "LoadModules", {
Success: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean),
DidSomething: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean),
ErrorMessageList: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.LoadModules$forceReloadJSResult"))();
jsNodeResult.successOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Success, OS.Types.Boolean);
jsNodeResult.didSomethingOut = OS.DataConversion.JSNodeParamConverter.from($parameters.DidSomething, OS.Types.Boolean);
jsNodeResult.errorMessageListOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ErrorMessageList, OS.Types.Text);
return jsNodeResult;
}, {
RequireScript: OS.SystemActions.requireScript
}, {}).then(function (results) {
forceReloadJSResult.value = results;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:TMeM5c2QHkerctY3Wb5+bQ", callContext.id) && forceReloadJSResult.value.successOut)) {
// Success = true
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ODxF9rjC3U2KXlRyXAtm8w", callContext.id);
// Success = True
outVars.value.successOut = true;
// ↘
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ba2UmKzI9EClgc6vYSYPkw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:SjJdWZ33T0qUN+Vjb4RBAQ", callContext.id);
// JSON Deserialize: DeserializeErrors
deserializeErrorsVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(forceReloadJSResult.value.errorMessageListOut, OS.DataTypes.TextList, false);
// Set ErrorMessage list
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:i7VIVj3PiUiJRtS1tgVlIA", callContext.id);
// ErrorMessage = DeserializeErrors.Data
outVars.value.errorMessageOut = deserializeErrorsVar.value.dataOut;
}

// Set DidSomething
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:GBFdBdLqtkSZqzp42LsnTA", callContext.id);
// DidSomething = ForceReload.DidSomething
outVars.value.didSomethingOut = forceReloadJSResult.value.didSomethingOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:m8HsIH8W30+T28y8FWNHeA", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:IFPH5XezDkyLaAscKTsMbQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:IFPH5XezDkyLaAscKTsMbQ", callContext.id);
throw ex;

});
};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.LoadModules$forceReloadJSResult", [{
name: "Success",
attrName: "successOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "DidSomething",
attrName: "didSomethingOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessageList",
attrName: "errorMessageListOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.LoadModules$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "DidSomething",
attrName: "didSomethingOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
OutSystemsChartsController.default.clientActionProxies.loadModules$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.loadModules$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
DidSomething: OS.DataConversion.JSNodeParamConverter.to(actionResults.didSomethingOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$LoadModules.ForceReloadJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
return new Promise(function ($resolve, $reject) {
OutSystems.ChartAPI.Advanced.LoadModules($actions.RequireScript).then((didSomething)=>{
    $parameters.Success = true; 
    $parameters.DidSomething = didSomething;
}).catch((error) => {
    $parameters.Success = false;
    $parameters.ErrorMessageList = error;
}).finally(()=>{
    $resolve();
});
});
};
});

define("OutSystemsCharts.controller$RemoveChart", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$RemoveChart.RemoveChartJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_RemoveChart_RemoveChartJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.removeChart$Action = function (chartWidgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.RemoveChart$vars"))());
vars.value.chartWidgetIdInLocal = chartWidgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:WwctmFxr6kafZupvzlhkcQ:/ClientActionFlows.WwctmFxr6kafZupvzlhkcQ:eJ5uwhIqJliSDElnOjNlbw", "OutSystemsCharts", "RemoveChart", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:aCW2u9DAREGXxS62XeyA_g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:FPuFf012Sk+Kq97K+GUmcA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_RemoveChart_RemoveChartJS, "RemoveChart", "RemoveChart", {
ChartWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartWidgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Cr9P6Mnjb0Sqv0e5bUUd8w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:WwctmFxr6kafZupvzlhkcQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.RemoveChart$vars", [{
name: "ChartWidgetId",
attrName: "chartWidgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.removeChart$Action = function (chartWidgetIdIn) {
chartWidgetIdIn = (chartWidgetIdIn === undefined) ? "" : chartWidgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.removeChart$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartWidgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$RemoveChart.RemoveChartJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.RemoveChart($parameters.ChartWidgetId)
};
});

define("OutSystemsCharts.controller$SeriesEventSubscribe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SeriesEventSubscribe.SeriesEventRegisterJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SeriesEventSubscribe_SeriesEventRegisterJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.seriesEventSubscribe$Action = function (chartWidgetIdIn, seriesEventIdIn, callbackIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SeriesEventSubscribe$vars"))());
vars.value.chartWidgetIdInLocal = chartWidgetIdIn;
vars.value.seriesEventIdInLocal = seriesEventIdIn;
vars.value.callbackInLocal = callbackIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:gI+026c0okGtaEhFxME2DA:/ClientActionFlows.gI+026c0okGtaEhFxME2DA:XWrfA7aZgFK8Axck453BwQ", "OutSystemsCharts", "SeriesEventSubscribe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ze_o_h6CCUGNtf8iV5fJCw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:dgNYw+O7_0iuR+GkDYuUmQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SeriesEventSubscribe_SeriesEventRegisterJS, "SeriesEventRegister", "SeriesEventSubscribe", {
ChartWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartWidgetIdInLocal, OS.Types.Text),
SeriesEventId: OS.DataConversion.JSNodeParamConverter.to(vars.value.seriesEventIdInLocal, OS.Types.Text),
Callback: OS.DataConversion.JSNodeParamConverter.to(vars.value.callbackInLocal, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:F0uFmngXjk2uYTyh0Zk8Bg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:gI+026c0okGtaEhFxME2DA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SeriesEventSubscribe$vars", [{
name: "ChartWidgetId",
attrName: "chartWidgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SeriesEventId",
attrName: "seriesEventIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Callback",
attrName: "callbackInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsChartsController.default.clientActionProxies.seriesEventSubscribe$Action = function (chartWidgetIdIn, seriesEventIdIn, callbackIn) {
chartWidgetIdIn = (chartWidgetIdIn === undefined) ? "" : chartWidgetIdIn;
seriesEventIdIn = (seriesEventIdIn === undefined) ? "" : seriesEventIdIn;
callbackIn = (callbackIn === undefined) ? null : callbackIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.seriesEventSubscribe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartWidgetIdIn, OS.Types.Text), seriesEventIdIn, OS.DataConversion.JSNodeParamConverter.from(callbackIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SeriesEventSubscribe.SeriesEventRegisterJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.SeriesManager.Events.Subscribe($parameters.ChartWidgetId,$parameters.SeriesEventId,$parameters.Callback);
};
});

define("OutSystemsCharts.controller$SeriesEventUnsubscribe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SeriesEventUnsubscribe.SeriesEventUnregisterJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SeriesEventUnsubscribe_SeriesEventUnregisterJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.seriesEventUnsubscribe$Action = function (chartWidgetIdIn, seriesEventIdIn, callbackIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SeriesEventUnsubscribe$vars"))());
vars.value.chartWidgetIdInLocal = chartWidgetIdIn;
vars.value.seriesEventIdInLocal = seriesEventIdIn;
vars.value.callbackInLocal = callbackIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:BAs7s4pydEGFc9djhkNvgg:/ClientActionFlows.BAs7s4pydEGFc9djhkNvgg:LJTkxULzzNZCcDVMhsoTSA", "OutSystemsCharts", "SeriesEventUnsubscribe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:67SffRqgX0ubHo6Zocsl2w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:O4fHn6ImmEi9KbpWIhOxsA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SeriesEventUnsubscribe_SeriesEventUnregisterJS, "SeriesEventUnregister", "SeriesEventUnsubscribe", {
ChartWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartWidgetIdInLocal, OS.Types.Text),
Callback: OS.DataConversion.JSNodeParamConverter.to(vars.value.callbackInLocal, OS.Types.Object),
SeriesEventId: OS.DataConversion.JSNodeParamConverter.to(vars.value.seriesEventIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0qC6ph1p9UiTzGrD23JJLA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:BAs7s4pydEGFc9djhkNvgg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SeriesEventUnsubscribe$vars", [{
name: "ChartWidgetId",
attrName: "chartWidgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SeriesEventId",
attrName: "seriesEventIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Callback",
attrName: "callbackInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsChartsController.default.clientActionProxies.seriesEventUnsubscribe$Action = function (chartWidgetIdIn, seriesEventIdIn, callbackIn) {
chartWidgetIdIn = (chartWidgetIdIn === undefined) ? "" : chartWidgetIdIn;
seriesEventIdIn = (seriesEventIdIn === undefined) ? "" : seriesEventIdIn;
callbackIn = (callbackIn === undefined) ? null : callbackIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.seriesEventUnsubscribe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartWidgetIdIn, OS.Types.Text), seriesEventIdIn, OS.DataConversion.JSNodeParamConverter.from(callbackIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SeriesEventUnsubscribe.SeriesEventUnregisterJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.SeriesManager.Events.Unsubscribe($parameters.ChartWidgetId,$parameters.SeriesEventId,$parameters.Callback);
};
});

define("OutSystemsCharts.controller$SetHighchartsChartConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SetHighchartsChartConfigs.SetHighchartsChartConfigsJS", "OutSystemsCharts.model$PropertyValueList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SetHighchartsChartConfigs_SetHighchartsChartConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.setHighchartsChartConfigs$Action = function (widgetIdIn, propertyValueListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SetHighchartsChartConfigs$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.propertyValueListInLocal = propertyValueListIn.clone();
var jSONSerializeVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerializeVar = jSONSerializeVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:vOD63RWVY0a6cYMwwzm4Og:/ClientActionFlows.vOD63RWVY0a6cYMwwzm4Og:4SKdobAfPq+uRc2Kzo+5Ag", "OutSystemsCharts", "SetHighchartsChartConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:fdoIHzNYbE6Qp37Ti9i2iQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:PeGDVh8UP0uNLnHrAjLIpA", callContext.id);
// JSON Serialize: JSONSerialize
jSONSerializeVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.propertyValueListInLocal, false, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:qMOi9hfSwkaAOmWE0F+eyw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SetHighchartsChartConfigs_SetHighchartsChartConfigsJS, "SetHighchartsChartConfigs", "SetHighchartsChartConfigs", {
chartId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeVar.value.jSONOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3tfG7TZbWk6xS6cB5ZZq3g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:vOD63RWVY0a6cYMwwzm4Og", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SetHighchartsChartConfigs$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PropertyValueList",
attrName: "propertyValueListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.PropertyValueList();
},
complexType: OutSystemsChartsModel.PropertyValueList
}]);
OutSystemsChartsController.default.clientActionProxies.setHighchartsChartConfigs$Action = function (widgetIdIn, propertyValueListIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
propertyValueListIn = (propertyValueListIn === undefined) ? new OutSystemsChartsModel.PropertyValueList() : propertyValueListIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.setHighchartsChartConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), propertyValueListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SetHighchartsChartConfigs.SetHighchartsChartConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.SetHighchartsChartConfigs(
    $parameters.chartId,
    $parameters.configs
);
};
});

define("OutSystemsCharts.controller$SetHighchartsSeriesConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SetHighchartsSeriesConfigs.SetHighchartsSeriesConfigsJS", "OutSystemsCharts.model$PropertyValueList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SetHighchartsSeriesConfigs_SetHighchartsSeriesConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.setHighchartsSeriesConfigs$Action = function (widgetIdIn, serieNameIn, propertyValueListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SetHighchartsSeriesConfigs$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.serieNameInLocal = serieNameIn;
vars.value.propertyValueListInLocal = propertyValueListIn.clone();
var jSONSerializeVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerializeVar = jSONSerializeVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:wnIEoIUBeUakdUoprQ8gRg:/ClientActionFlows.wnIEoIUBeUakdUoprQ8gRg:GYjnAbjlxphG2oR80PeWtg", "OutSystemsCharts", "SetHighchartsSeriesConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pY6AFrjZzEG4P_w6oB1sQQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3Pj5Ak_XnkCucgUrKACySQ", callContext.id);
// JSON Serialize: JSONSerialize
jSONSerializeVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.propertyValueListInLocal, false, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vSN_8g2cYUyMzI9a6NhbvA", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SetHighchartsSeriesConfigs_SetHighchartsSeriesConfigsJS, "SetHighchartsSeriesConfigs", "SetHighchartsSeriesConfigs", {
chartId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
serieName: OS.DataConversion.JSNodeParamConverter.to(vars.value.serieNameInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeVar.value.jSONOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0hlydQT6jkW2FcD_5F4v4w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:wnIEoIUBeUakdUoprQ8gRg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SetHighchartsSeriesConfigs$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SerieName",
attrName: "serieNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PropertyValueList",
attrName: "propertyValueListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.PropertyValueList();
},
complexType: OutSystemsChartsModel.PropertyValueList
}]);
OutSystemsChartsController.default.clientActionProxies.setHighchartsSeriesConfigs$Action = function (widgetIdIn, serieNameIn, propertyValueListIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
serieNameIn = (serieNameIn === undefined) ? "" : serieNameIn;
propertyValueListIn = (propertyValueListIn === undefined) ? new OutSystemsChartsModel.PropertyValueList() : propertyValueListIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.setHighchartsSeriesConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(serieNameIn, OS.Types.Text), propertyValueListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SetHighchartsSeriesConfigs.SetHighchartsSeriesConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.SetHighchartsSeriesConfigs(
    $parameters.chartId,
    $parameters.serieName,
    $parameters.configs
);
};
});

define("OutSystemsCharts.controller$SetHighchartsXAxisConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SetHighchartsXAxisConfigs.SetHighchartsAxisConfigsJS", "OutSystemsCharts.model$PropertyValueList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SetHighchartsXAxisConfigs_SetHighchartsAxisConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.setHighchartsXAxisConfigs$Action = function (widgetIdIn, propertyValueListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SetHighchartsXAxisConfigs$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.propertyValueListInLocal = propertyValueListIn.clone();
var jSONSerializeVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerializeVar = jSONSerializeVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:XUWrww4o40ikzSwAw7fPuA:/ClientActionFlows.XUWrww4o40ikzSwAw7fPuA:vIxmEAC2pB_Xe4OOvEhkYA", "OutSystemsCharts", "SetHighchartsXAxisConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:1k0SX6bAH0C0YQ0MTTkU5g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:_mvEWTDOEkidV8KjKUhjUw", callContext.id);
// JSON Serialize: JSONSerialize
jSONSerializeVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.propertyValueListInLocal, false, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diI5FPCa9UqJJ56AKlPaJQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SetHighchartsXAxisConfigs_SetHighchartsAxisConfigsJS, "SetHighchartsAxisConfigs", "SetHighchartsXAxisConfigs", {
configs: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeVar.value.jSONOut, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:jvBL38OgGES9z5wR88bMNg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:XUWrww4o40ikzSwAw7fPuA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SetHighchartsXAxisConfigs$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PropertyValueList",
attrName: "propertyValueListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.PropertyValueList();
},
complexType: OutSystemsChartsModel.PropertyValueList
}]);
OutSystemsChartsController.default.clientActionProxies.setHighchartsXAxisConfigs$Action = function (widgetIdIn, propertyValueListIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
propertyValueListIn = (propertyValueListIn === undefined) ? new OutSystemsChartsModel.PropertyValueList() : propertyValueListIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.setHighchartsXAxisConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), propertyValueListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SetHighchartsXAxisConfigs.SetHighchartsAxisConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.AxisManager.SetHighchartsAxisConfigs(
    $parameters.uniqueId,
    $parameters.configs
);
};
});

define("OutSystemsCharts.controller$SetHighchartsYAxisConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$SetHighchartsYAxisConfigs.SetHighchartsAxisConfigsJS", "OutSystemsCharts.model$PropertyValueList"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_SetHighchartsYAxisConfigs_SetHighchartsAxisConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.setHighchartsYAxisConfigs$Action = function (widgetIdIn, propertyValueListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.SetHighchartsYAxisConfigs$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.propertyValueListInLocal = propertyValueListIn.clone();
var jSONSerializeVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONSerializeVar = jSONSerializeVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:HH3w3LTKVUGTFBBHM1rkXA:/ClientActionFlows.HH3w3LTKVUGTFBBHM1rkXA:53gbLNgcjKVVDykNOrBqHg", "OutSystemsCharts", "SetHighchartsYAxisConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:hGtZh3P01U6JEFQlJJbOwg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:PjEARjx+TUaHijmehQkzGw", callContext.id);
// JSON Serialize: JSONSerialize
jSONSerializeVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.propertyValueListInLocal, false, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ltErpG+Cckmbv5J03GAHug", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_SetHighchartsYAxisConfigs_SetHighchartsAxisConfigsJS, "SetHighchartsAxisConfigs", "SetHighchartsYAxisConfigs", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeVar.value.jSONOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:nDn3NZrx+USzV7RGh_PDbA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:HH3w3LTKVUGTFBBHM1rkXA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.SetHighchartsYAxisConfigs$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PropertyValueList",
attrName: "propertyValueListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsChartsModel.PropertyValueList();
},
complexType: OutSystemsChartsModel.PropertyValueList
}]);
OutSystemsChartsController.default.clientActionProxies.setHighchartsYAxisConfigs$Action = function (widgetIdIn, propertyValueListIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
propertyValueListIn = (propertyValueListIn === undefined) ? new OutSystemsChartsModel.PropertyValueList() : propertyValueListIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.setHighchartsYAxisConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), propertyValueListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$SetHighchartsYAxisConfigs.SetHighchartsAxisConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.AxisManager.SetHighchartsAxisConfigs(
    $parameters.uniqueId,
    $parameters.configs
);
};
});

define("OutSystemsCharts.controller$ShowLoading", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$ShowLoading.ShowLoadingJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_ShowLoading_ShowLoadingJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.showLoading$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.ShowLoading$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:I1CptRzNgUCzAACr8A_1dg:/ClientActionFlows.I1CptRzNgUCzAACr8A_1dg:oZXoovDJ0MHo5lXe6nWIXQ", "OutSystemsCharts", "ShowLoading", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:sJfPAVRqrEaXStvY2fnnQQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pE11ZPsvjU6jXSPr8CxSJQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_ShowLoading_ShowLoadingJS, "ShowLoading", "ShowLoading", {
widgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:PYJ36H_Qu0qLhv_OhJcoUg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:I1CptRzNgUCzAACr8A_1dg", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.ShowLoading$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.showLoading$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.showLoading$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$ShowLoading.ShowLoadingJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.ShowEmptyState($parameters.widgetId);
};
});

define("OutSystemsCharts.controller$UpdateAxisConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateAxisConfigs.UpdateConfigsJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateAxisConfigs_UpdateConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateAxisConfigs$Action = function (uniqueIdIn, configsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
var updateConfigsJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateConfigsJSResult = updateConfigsJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:BSfVFQ1MGE2gkCETy08HVA:/ClientActionFlows.BSfVFQ1MGE2gkCETy08HVA:BYYTMYODVjIU8XHlfmWVgQ", "OutSystemsCharts", "UpdateAxisConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:QoOv0FxJgUiCSiv8MWeTbQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ONJfiVL2Y0iw1pg9mCDt5Q", callContext.id);
updateConfigsJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateAxisConfigs_UpdateConfigsJS, "UpdateConfigs", "UpdateAxisConfigs", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$updateConfigsJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:yRRxoo5Zb0a1FgNfsvfoqw", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(updateConfigsJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Filw1Snz20KA1DBc7Rqorw", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Filw1Snz20KA1DBc7Rqorw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Filw1Snz20KA1DBc7Rqorw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:h_1k+LZeWUK4mvK6YS6gGQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:BSfVFQ1MGE2gkCETy08HVA", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$vars", [{
name: "uniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$updateConfigsJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateAxisConfigs$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.updateAxisConfigs$Action = function (uniqueIdIn, configsIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateAxisConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$UpdateAxisConfigs.UpdateConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.AxisManager.UpdateConfigs(
    $parameters.uniqueId,
    $parameters.configs
)
};
});

define("OutSystemsCharts.controller$UpdateChartColorScheme", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateChartColorScheme.UpdateColorSchemeJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateChartColorScheme_UpdateColorSchemeJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateChartColorScheme$Action = function (chartIdIn, colorSchemeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$vars"))());
vars.value.chartIdInLocal = chartIdIn;
vars.value.colorSchemeInLocal = colorSchemeIn.clone();
var updateColorSchemeJSResult = new OS.DataTypes.VariableHolder();
var jSONSerializeColorsSchemeVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateColorSchemeJSResult = updateColorSchemeJSResult;
varBag.jSONSerializeColorsSchemeVar = jSONSerializeColorsSchemeVar;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:LvNZI1+DeEOSzO4HFzg0FQ:/ClientActionFlows.LvNZI1+DeEOSzO4HFzg0FQ:cqVA6PJlSywkUhHPd+UfDA", "OutSystemsCharts", "UpdateChartColorScheme", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:LjDQD9izlky5It8Tmbr_Kg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:noh_FiBamkeDWwxe7wrdtg", callContext.id);
// JSON Serialize: JSONSerializeColorsScheme
jSONSerializeColorsSchemeVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.colorSchemeInLocal, false, false, OS.Types.Text);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:e0wFquSeVUGeuAOWohUFQw", callContext.id);
updateColorSchemeJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateChartColorScheme_UpdateColorSchemeJS, "UpdateColorScheme", "UpdateChartColorScheme", {
ChartId: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartIdInLocal, OS.Types.Text),
ColorsScheme: OS.DataConversion.JSNodeParamConverter.to(jSONSerializeColorsSchemeVar.value.jSONOut, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$updateColorSchemeJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:zEWs7QohWUOy8hhGHsWTdg", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(updateColorSchemeJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:WQyai8yKNka3P5cy6btigw", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:WQyai8yKNka3P5cy6btigw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:WQyai8yKNka3P5cy6btigw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:upYL0Ku18UWKbY_YZtwE7A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:LvNZI1+DeEOSzO4HFzg0FQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$vars", [{
name: "ChartId",
attrName: "chartIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ColorScheme",
attrName: "colorSchemeInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$updateColorSchemeJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateChartColorScheme$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.updateChartColorScheme$Action = function (chartIdIn, colorSchemeIn) {
chartIdIn = (chartIdIn === undefined) ? "" : chartIdIn;
colorSchemeIn = (colorSchemeIn === undefined) ? new OS.DataTypes.TextList() : colorSchemeIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateChartColorScheme$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartIdIn, OS.Types.Text), colorSchemeIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$UpdateChartColorScheme.UpdateColorSchemeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.ChartManager.UpdateColorScheme(
    $parameters.ChartId,
    $parameters.ColorsScheme
);
};
});

define("OutSystemsCharts.controller$UpdateConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateConfigs.UpdateConfigsJS"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateConfigs_UpdateConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateConfigs$Action = function (chartIDIn, configsIn, sourceDataPointListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateConfigs$vars"))());
vars.value.chartIDInLocal = chartIDIn;
vars.value.configsInLocal = configsIn;
vars.value.sourceDataPointListInLocal = sourceDataPointListIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:dcxEWHpxAEuNBBhYPFRSaQ:/ClientActionFlows.dcxEWHpxAEuNBBhYPFRSaQ:PZq1hGjBdCm4Q8A5DMrFPA", "OutSystemsCharts", "UpdateConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:iqVi75ZwFUyxwbnHhbzARA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:+xF7WwvOwkqdIVP4SmgoAQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateConfigs_UpdateConfigsJS, "UpdateConfigs", "UpdateConfigs", {
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
chartID: OS.DataConversion.JSNodeParamConverter.to(vars.value.chartIDInLocal, OS.Types.Text),
SourceDataPointList: OS.DataConversion.JSNodeParamConverter.to(vars.value.sourceDataPointListInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Fb89EgmrHUGUtG9Z8+XS5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:dcxEWHpxAEuNBBhYPFRSaQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateConfigs$vars", [{
name: "chartID",
attrName: "chartIDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SourceDataPointList",
attrName: "sourceDataPointListInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.clientActionProxies.updateConfigs$Action = function (chartIDIn, configsIn, sourceDataPointListIn) {
chartIDIn = (chartIDIn === undefined) ? "" : chartIDIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
sourceDataPointListIn = (sourceDataPointListIn === undefined) ? "" : sourceDataPointListIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartIDIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(sourceDataPointListIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsCharts.controller$UpdateConfigs.UpdateConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.UpdateConfigs(
    $parameters.chartID,
    $parameters.configs,
    $parameters.SourceDataPointList
)
};
});

define("OutSystemsCharts.controller$UpdateExportConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateExportConfigs.UpdateConfigsJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateExportConfigs_UpdateConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateExportConfigs$Action = function (uniqueIdIn, configsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateExportConfigs$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
var updateConfigsJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateExportConfigs$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateConfigsJSResult = updateConfigsJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:GAhWoL6xNEWOBrFCujpYdQ:/ClientActionFlows.GAhWoL6xNEWOBrFCujpYdQ:gZ4PRhG4ZIoD+aKj+CgJAQ", "OutSystemsCharts", "UpdateExportConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:TXcbdVdf0UC6fAzrUMjVBw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:oRNqIm1D702W2JB9j0pIEw", callContext.id);
updateConfigsJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateExportConfigs_UpdateConfigsJS, "UpdateConfigs", "UpdateExportConfigs", {
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateExportConfigs$updateConfigsJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:a+5GNeDnXUW7r8n7AOvgKQ", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(updateConfigsJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
// Set output
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:HrB1oQMXUEK_6zYg0vo9AQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:HrB1oQMXUEK_6zYg0vo9AQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:HrB1oQMXUEK_6zYg0vo9AQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:5zvCl32F_0Kb4oQIFG0rqQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:GAhWoL6xNEWOBrFCujpYdQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateExportConfigs$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateExportConfigs$updateConfigsJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateExportConfigs$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.updateExportConfigs$Action = function (uniqueIdIn, configsIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateExportConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$UpdateExportConfigs.UpdateConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.ExportManager.UpdateConfigs(
    $parameters.uniqueId,
    $parameters.configs
)
};
});

define("OutSystemsCharts.controller$UpdateLegendConfigs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateLegendConfigs.UpdateConfigsJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateLegendConfigs_UpdateConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateLegendConfigs$Action = function (uniqueIdIn, configsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
var updateConfigsJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateConfigsJSResult = updateConfigsJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:XDIm7_fM00qG5f6Q41r3bQ:/ClientActionFlows.XDIm7_fM00qG5f6Q41r3bQ:zS2cEoC+1dZNfn7dfou7lA", "OutSystemsCharts", "UpdateLegendConfigs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:HyJqDw5YN0i3ZEVPmHzlTQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:c8HQie0GbE6ERD6F4UFFQw", callContext.id);
updateConfigsJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateLegendConfigs_UpdateConfigsJS, "UpdateConfigs", "UpdateLegendConfigs", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$updateConfigsJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3UFYu_UMhUavy9RJvC3n7Q", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(updateConfigsJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0YXt3l4d7kGlIZZ5WtoUdQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0YXt3l4d7kGlIZZ5WtoUdQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:0YXt3l4d7kGlIZZ5WtoUdQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:ugBH5EnLw0C1OJo_RxqsjQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:XDIm7_fM00qG5f6Q41r3bQ", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$vars", [{
name: "UniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$updateConfigsJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateLegendConfigs$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.updateLegendConfigs$Action = function (uniqueIdIn, configsIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateLegendConfigs$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$UpdateLegendConfigs.UpdateConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.LegendManager.UpdateConfigs(
    $parameters.uniqueId,
    $parameters.configs
)
};
});

define("OutSystemsCharts.controller$UpdateSeriesStyling", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.controller$UpdateSeriesStyling.UpdateConfigsJS", "OutSystemsCharts.model$ErrorMessageRec", "OutSystemsCharts.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsCharts_controller_UpdateSeriesStyling_UpdateConfigsJS) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.updateSeriesStyling$Action = function (uniqueIdIn, configsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$vars"))());
vars.value.uniqueIdInLocal = uniqueIdIn;
vars.value.configsInLocal = configsIn;
var updateConfigsJSResult = new OS.DataTypes.VariableHolder();
var jSONDeserializeErrorMessageVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.ReturnMessageRec))());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateConfigsJSResult = updateConfigsJSResult;
varBag.jSONDeserializeErrorMessageVar = jSONDeserializeErrorMessageVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:Vwprv2dAHUeYRQT7q1qY+Q:/ClientActionFlows.Vwprv2dAHUeYRQT7q1qY+Q:Co4qVqFlx2j1Bpa7ldTehg", "OutSystemsCharts", "UpdateSeriesStyling", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:78HALna6+UCulM7kQqz4Ww", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3POjxH6JbEWld8jHeSDB7A", callContext.id);
updateConfigsJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_controller_UpdateSeriesStyling_UpdateConfigsJS, "UpdateConfigs", "UpdateSeriesStyling", {
uniqueId: OS.DataConversion.JSNodeParamConverter.to(vars.value.uniqueIdInLocal, OS.Types.Text),
configs: OS.DataConversion.JSNodeParamConverter.to(vars.value.configsInLocal, OS.Types.Text),
ResponseJSON: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$updateConfigsJSResult"))();
jsNodeResult.responseJSONOut = OS.DataConversion.JSNodeParamConverter.from($parameters.ResponseJSON, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Xcu5oO3gpECWNurIS4JAew", callContext.id);
// JSON Deserialize: JSONDeserializeErrorMessage
jSONDeserializeErrorMessageVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(updateConfigsJSResult.value.responseJSONOut, OutSystemsChartsModel.ReturnMessageRec, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vFhFovUYVkCPuqr1FM2RNQ", callContext.id);
// Success = JSONDeserializeErrorMessage.Data.IsSuccess
outVars.value.successOut = jSONDeserializeErrorMessageVar.value.dataOut.isSuccessAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vFhFovUYVkCPuqr1FM2RNQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ErrorMessage.Code = JSONDeserializeErrorMessage.Data.Code
outVars.value.errorMessageOut.codeAttr = jSONDeserializeErrorMessageVar.value.dataOut.codeAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vFhFovUYVkCPuqr1FM2RNQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage.Message = JSONDeserializeErrorMessage.Data.Message
outVars.value.errorMessageOut.messageAttr = jSONDeserializeErrorMessageVar.value.dataOut.messageAttr;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:VFJ37x4uQU+4U3T_BtoyPg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:Vwprv2dAHUeYRQT7q1qY+Q", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$vars", [{
name: "uniqueId",
attrName: "uniqueIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "configs",
attrName: "configsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$updateConfigsJSResult", [{
name: "ResponseJSON",
attrName: "responseJSONOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.UpdateSeriesStyling$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.ErrorMessageRec();
},
complexType: OutSystemsChartsModel.ErrorMessageRec
}]);
OutSystemsChartsController.default.clientActionProxies.updateSeriesStyling$Action = function (uniqueIdIn, configsIn) {
uniqueIdIn = (uniqueIdIn === undefined) ? "" : uniqueIdIn;
configsIn = (configsIn === undefined) ? "" : configsIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.updateSeriesStyling$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uniqueIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(configsIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
ErrorMessage: actionResults.errorMessageOut
};
});
};
});
define("OutSystemsCharts.controller$UpdateSeriesStyling.UpdateConfigsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.ResponseJSON = OutSystems.ChartAPI.SeriesManager.UpdateConfigs(
    $parameters.uniqueId,
    $parameters.configs
)
};
});

define("OutSystemsCharts.controller$XAxisFormat_Init_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_XAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.xAxisFormat_Init_v1$Action = function (titleIn, labelsRotationIn, minValueIn, maxValueIn, valuesTypeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.XAxisFormat_Init_v1$vars"))());
vars.value.titleInLocal = titleIn;
vars.value.labelsRotationInLocal = labelsRotationIn;
vars.value.minValueInLocal = minValueIn;
vars.value.maxValueInLocal = maxValueIn;
vars.value.valuesTypeInLocal = valuesTypeIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.XAxisFormat_Init_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:J8JNuk_Ct0mnfsNFRMefAw:/ClientActionFlows.J8JNuk_Ct0mnfsNFRMefAw:aQQS2w7YYrxgjpPs1BzGkQ", "OutSystemsCharts", "XAxisFormat_Init_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:38DgtBTSM0+0jgKETox5rg", callContext.id);
// Set XAxisFormat
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:69RK6e9PVUiAyfYxG16gpw", callContext.id);
// XAxisFormat.Title = Title
outVars.value.xAxisFormatOut.titleAttr = vars.value.titleInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:69RK6e9PVUiAyfYxG16gpw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// XAxisFormat.LabelsRotation = LabelsRotation
outVars.value.xAxisFormatOut.labelsRotationAttr = vars.value.labelsRotationInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:69RK6e9PVUiAyfYxG16gpw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// XAxisFormat.MinValue = MinValue
outVars.value.xAxisFormatOut.minValueAttr = vars.value.minValueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:69RK6e9PVUiAyfYxG16gpw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// XAxisFormat.MaxValue = MaxValue
outVars.value.xAxisFormatOut.maxValueAttr = vars.value.maxValueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:69RK6e9PVUiAyfYxG16gpw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// XAxisFormat.ValuesType = ValuesType
outVars.value.xAxisFormatOut.valuesTypeAttr = vars.value.valuesTypeInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:T5xQ0dsgp0CZoO9SVLFIrA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:J8JNuk_Ct0mnfsNFRMefAw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.XAxisFormat_Init_v1$vars", [{
name: "Title",
attrName: "titleInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "LabelsRotation",
attrName: "labelsRotationInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "MinValue",
attrName: "minValueInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MaxValue",
attrName: "maxValueInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ValuesType",
attrName: "valuesTypeInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return OutSystemsChartsModel.staticEntities.xAxisValuesType_v1.auto;
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.XAxisFormat_Init_v1$outVars", [{
name: "XAxisFormat",
attrName: "xAxisFormatOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_XAxisFormatRec();
},
complexType: OutSystemsChartsModel.Legacy_XAxisFormatRec
}]);
OutSystemsChartsController.default.clientActionProxies.xAxisFormat_Init_v1$Action = function (titleIn, labelsRotationIn, minValueIn, maxValueIn, valuesTypeIn) {
titleIn = (titleIn === undefined) ? "" : titleIn;
labelsRotationIn = (labelsRotationIn === undefined) ? 0 : labelsRotationIn;
minValueIn = (minValueIn === undefined) ? "" : minValueIn;
maxValueIn = (maxValueIn === undefined) ? "" : maxValueIn;
valuesTypeIn = (valuesTypeIn === undefined) ? OutSystemsChartsModel.staticEntities.xAxisValuesType_v1.auto : valuesTypeIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.xAxisFormat_Init_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(titleIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(labelsRotationIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(minValueIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(maxValueIn, OS.Types.Text), valuesTypeIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
XAxisFormat: actionResults.xAxisFormatOut
};
});
};
});

define("OutSystemsCharts.controller$YAxisFormat_Init_v1", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_YAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;
OutSystemsChartsController.default.yAxisFormat_Init_v1$Action = function (titleIn, minValueIn, maxValueIn, valuesPrefixIn, valuesSufixIn, gridLineStepIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.YAxisFormat_Init_v1$vars"))());
vars.value.titleInLocal = titleIn;
vars.value.minValueInLocal = minValueIn;
vars.value.maxValueInLocal = maxValueIn;
vars.value.valuesPrefixInLocal = valuesPrefixIn;
vars.value.valuesSufixInLocal = valuesSufixIn;
vars.value.gridLineStepInLocal = gridLineStepIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.YAxisFormat_Init_v1$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:02at77m3d0KcLkJhdubojw:/ClientActionFlows.02at77m3d0KcLkJhdubojw:4mp4aBMMNKhz6X9I5Blcmg", "OutSystemsCharts", "YAxisFormat_Init_v1", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:35twQSYQMUWFaGqpxjC9RQ", callContext.id);
// Set YAxisFormat
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id);
// YAxisFormat.Title = Title
outVars.value.yAxisFormatOut.titleAttr = vars.value.titleInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// YAxisFormat.MinValue = MinValue
outVars.value.yAxisFormatOut.minValueAttr = vars.value.minValueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// YAxisFormat.MaxValue = MaxValue
outVars.value.yAxisFormatOut.maxValueAttr = vars.value.maxValueInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// YAxisFormat.ValuesPrefix = ValuesPrefix
outVars.value.yAxisFormatOut.valuesPrefixAttr = vars.value.valuesPrefixInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// YAxisFormat.ValuesSuffix = ValuesSufix
outVars.value.yAxisFormatOut.valuesSuffixAttr = vars.value.valuesSufixInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ktf7WRO9402q8kM8z1NcaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// YAxisFormat.GridLineStep = GridLineStep
outVars.value.yAxisFormatOut.gridLineStepAttr = vars.value.gridLineStepInLocal;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:1uqbTAASmke6rm+3LTXjPg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:02at77m3d0KcLkJhdubojw", callContext.id);
}

};
var controller = OutSystemsChartsController.default;
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.YAxisFormat_Init_v1$vars", [{
name: "Title",
attrName: "titleInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MinValue",
attrName: "minValueInLocal",
mandatory: false,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}
}, {
name: "MaxValue",
attrName: "maxValueInLocal",
mandatory: false,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}
}, {
name: "ValuesPrefix",
attrName: "valuesPrefixInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ValuesSufix",
attrName: "valuesSufixInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "GridLineStep",
attrName: "gridLineStepInLocal",
mandatory: false,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}
}]);
OutSystemsChartsController.default.constructor.registerVariableGroupType("OutSystemsCharts.YAxisFormat_Init_v1$outVars", [{
name: "YAxisFormat",
attrName: "yAxisFormatOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_YAxisFormatRec();
},
complexType: OutSystemsChartsModel.Legacy_YAxisFormatRec
}]);
OutSystemsChartsController.default.clientActionProxies.yAxisFormat_Init_v1$Action = function (titleIn, minValueIn, maxValueIn, valuesPrefixIn, valuesSufixIn, gridLineStepIn) {
titleIn = (titleIn === undefined) ? "" : titleIn;
minValueIn = (minValueIn === undefined) ? -2147483647 : minValueIn;
maxValueIn = (maxValueIn === undefined) ? -2147483647 : maxValueIn;
valuesPrefixIn = (valuesPrefixIn === undefined) ? "" : valuesPrefixIn;
valuesSufixIn = (valuesSufixIn === undefined) ? "" : valuesSufixIn;
gridLineStepIn = (gridLineStepIn === undefined) ? -2147483647 : gridLineStepIn;
return controller.executeActionInsideJSNode(OutSystemsChartsController.default.yAxisFormat_Init_v1$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(titleIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(minValueIn, OS.Types.Decimal), OS.DataConversion.JSNodeParamConverter.from(maxValueIn, OS.Types.Decimal), OS.DataConversion.JSNodeParamConverter.from(valuesPrefixIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(valuesSufixIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(gridLineStepIn, OS.Types.Decimal)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
YAxisFormat: actionResults.yAxisFormatOut
};
});
};
});

define("OutSystemsCharts.controller", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller$debugger"], function (exports, OutSystems, OutSystemsChartsModel, OutSystemsCharts_Controller_debugger) {
var OS = OutSystems.Internal;
var OutSystemsChartsController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsChartsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
OutSystemsChartsController.default = new Controller(null, "OutSystemsCharts");
});
define("OutSystemsCharts.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"U5FfnFfVAk+hc_uS+Es2BA": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"skiJvHe210KXSuYSCHULfw": {
getter: function (varBag, idService) {
return varBag.vars.value.sourceDataPointListInLocal;
}
},
"6ut9P01fBUqpppKEDnnYjA": {
getter: function (varBag, idService) {
return varBag.vars.value.xAxisTypeInLocal;
},
dataType: OS.Types.Text
},
"ncmg3ZobxUq6C9NcjL71NA": {
getter: function (varBag, idService) {
return varBag.jSONSerialize_SourceDataPoint_ListVar.value;
}
},
"rIIABPAmxECqGVYKYK9t7w": {
getter: function (varBag, idService) {
return varBag.initChartJSResult.value;
}
},
"uKBX6D0LQUekdou5LG5aCw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"y2MXJuzvxkGTkTwX0wVIZA": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"zJAzx+avEEGeTRKYURJxrQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"0PylM60Hf02VPaJM_8OL2g": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"yRRxoo5Zb0a1FgNfsvfoqw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"ONJfiVL2Y0iw1pg9mCDt5Q": {
getter: function (varBag, idService) {
return varBag.updateConfigsJSResult.value;
}
},
"bWjVnVjUnEaX90UVKn1GQw": {
getter: function (varBag, idService) {
return varBag.vars.value.dataPointFormatsInLocal;
}
},
"ceZau78cAUmz4QFTyc5PxA": {
getter: function (varBag, idService) {
return varBag.vars.value.dataSeriesFormatsInLocal;
}
},
"VNbTHnPlrEiU1x2HSVHFPg": {
getter: function (varBag, idService) {
return varBag.vars.value.xAxisJSONInLocal;
},
dataType: OS.Types.Text
},
"BVnuUzq31EWCvCHjPL7xRg": {
getter: function (varBag, idService) {
return varBag.vars.value.yAxisJSONInLocal;
},
dataType: OS.Types.Text
},
"fRmD4tIQPUqxo8olNYo7Mw": {
getter: function (varBag, idService) {
return varBag.vars.value.highchartsJSONInLocal;
},
dataType: OS.Types.Text
},
"WWEyfgmHgkW6ddkOxcH0KQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.advancedFormatOut;
}
},
"t5bxqdY9Bkil4KLXkNLcNA": {
getter: function (varBag, idService) {
return varBag.vars.value.labelInLocal;
},
dataType: OS.Types.Text
},
"ZycxuNw0NU6zT_hbkd+H7Q": {
getter: function (varBag, idService) {
return varBag.vars.value.dataSeriesNameInLocal;
},
dataType: OS.Types.Text
},
"lH05ONRh1kCy72lsAsgA6w": {
getter: function (varBag, idService) {
return varBag.outVars.value.dataPointOut;
}
},
"9Wqq+B5l60OBCZbam1ggwA": {
getter: function (varBag, idService) {
return varBag.vars.value.chartIdInLocal;
},
dataType: OS.Types.Text
},
"G0tdst0gjU+eHhVPORgdyw": {
getter: function (varBag, idService) {
return varBag.vars.value.colorSchemeInLocal;
}
},
"3ENgmwAYDEC71NKyx4QMUQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"bYXP6C5HBkWljQgqzVlqIw": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"noh_FiBamkeDWwxe7wrdtg": {
getter: function (varBag, idService) {
return varBag.jSONSerializeColorsSchemeVar.value;
}
},
"zEWs7QohWUOy8hhGHsWTdg": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"e0wFquSeVUGeuAOWohUFQw": {
getter: function (varBag, idService) {
return varBag.updateColorSchemeJSResult.value;
}
},
"jy5a06E6DEijh2bY8y8IMA": {
getter: function (varBag, idService) {
return varBag.vars.value.labelInLocal;
},
dataType: OS.Types.Text
},
"sQgLYIF92k+rWUPzaAqMMw": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInLocal;
},
dataType: OS.Types.Decimal
},
"mgm+glVk2kOulC_5d7BdUQ": {
getter: function (varBag, idService) {
return varBag.vars.value.dataSeriesNameInLocal;
},
dataType: OS.Types.Text
},
"4YSYE3M6mkOjFA8jM70lxA": {
getter: function (varBag, idService) {
return varBag.vars.value.tooltipInLocal;
},
dataType: OS.Types.Text
},
"0urWbjw8_UevlInMwbq5zQ": {
getter: function (varBag, idService) {
return varBag.vars.value.colorInLocal;
},
dataType: OS.Types.Text
},
"JEHtvePu+ky4R6PwAv1NFg": {
getter: function (varBag, idService) {
return varBag.outVars.value.dataPointOut;
}
},
"vOgdTrnUYUiIyoEDKORscg": {
getter: function (varBag, idService) {
return varBag.vars.value.current_Unique_IDInLocal;
},
dataType: OS.Types.Text
},
"sEFuGz34FkGyJSgypDliRw": {
getter: function (varBag, idService) {
return varBag.outVars.value.unique_IDOut;
},
dataType: OS.Types.Text
},
"xdNIo_chiUW2yJFGrEEHMw": {
getter: function (varBag, idService) {
return varBag.randomStringJSResult.value;
}
},
"fzVFrbpy2EmrCNXHe4xvsw": {
getter: function (varBag, idService) {
return varBag.vars.value.chartWidgetIdInLocal;
},
dataType: OS.Types.Text
},
"knSQQPbPr0STAM98TS5pvw": {
getter: function (varBag, idService) {
return varBag.vars.value.chartEventIdInLocal;
},
dataType: OS.Types.Text
},
"6IexGopE5E2jJ5IxVlRGuA": {
getter: function (varBag, idService) {
return varBag.vars.value.callbackInLocal;
},
dataType: OS.Types.Object
},
"aXNWKuMVqk2mGc8AUKG1Ig": {
getter: function (varBag, idService) {
return varBag.chartEventRegisterJSResult.value;
}
},
"I6swFln5H0iz6WoVxjdngA": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"twVU0oelEEagVNQepXeBrQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"bXtGAeJK8UiO1+9J29WZnA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"lT0+YVCc9EKuf+OWHijsYQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"hVdyn6ZQ3kGS3FAttW4G8w": {
getter: function (varBag, idService) {
return varBag.disposeJSResult.value;
}
},
"pZy9rgUGdk6yyKfTwmpfFw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"1OBbZuvpAkmX4uvFNGefew": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"XUGGZSigd0mnujVI6VgR+w": {
getter: function (varBag, idService) {
return varBag.vars.value.providerInLocal;
},
dataType: OS.Types.Text
},
"cBuKy23MG0OIZMxHC+Pv7A": {
getter: function (varBag, idService) {
return varBag.createLegendJSResult.value;
}
},
"8AZqmOhgf0OBWQHQM9l77Q": {
getter: function (varBag, idService) {
return varBag.vars.value.chartIDInLocal;
},
dataType: OS.Types.Text
},
"4KeN5lfjIkStkCpmuNKfTQ": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"bmAAWnPEKEGyIeLHYR85Vg": {
getter: function (varBag, idService) {
return varBag.vars.value.sourceDataPointListInLocal;
},
dataType: OS.Types.Text
},
"+xF7WwvOwkqdIVP4SmgoAQ": {
getter: function (varBag, idService) {
return varBag.updateConfigsJSResult.value;
}
},
"CP0dyi5jikOpMCI6DI_Xiw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"ZGjEWV0U_0ex9nIsAXR_Cw": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"E3mt5yrvzkyOqs86suMLUQ": {
getter: function (varBag, idService) {
return varBag.vars.value.chartWidgetIdInLocal;
},
dataType: OS.Types.Text
},
"Fq8fNHQ51Em6D2Y4x0F8cg": {
getter: function (varBag, idService) {
return varBag.vars.value.chartEventIdInLocal;
},
dataType: OS.Types.Text
},
"f6ULIdcGc0yEoe4NCl0+fA": {
getter: function (varBag, idService) {
return varBag.vars.value.callbackInLocal;
},
dataType: OS.Types.Object
},
"qPa8VN0qmUK_xhJcwScpVA": {
getter: function (varBag, idService) {
return varBag.seriesEventUnregisterJSResult.value;
}
},
"I7N1tWI5EEukK_wIxybUig": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"aDLvjXoIrkqDhnldntLF8w": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"UE82aR0vHE2iC2E3GVe4Ig": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"h0BTxm85SUu_AG+OQOhSEQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"ZntvemRI+UmMEI8uDvPnHw": {
getter: function (varBag, idService) {
return varBag.disposeJSResult.value;
}
},
"unx8_kt8VEiG6mw2GwVhpw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"fu4yAIK77kGTpRNVDKTRtw": {
getter: function (varBag, idService) {
return varBag.initializeJSResult.value;
}
},
"a1SVZS6Zw0iyto0ILESE+Q": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"6_1vjNezgk+91xOOttgYAA": {
getter: function (varBag, idService) {
return varBag.initializeAxisJSResult.value;
}
},
"2QKmi4pjhUWCenxcy9s2fg": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"TK0IEWhI8Uqs5ZZuJvqpRg": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"adLpZpRyckiu35V6wECJYQ": {
getter: function (varBag, idService) {
return varBag.vars.value.providerInLocal;
},
dataType: OS.Types.Text
},
"im7Q_pDvAU+kxH+v2h0szg": {
getter: function (varBag, idService) {
return varBag.createSeriesStylingJSResult.value;
}
},
"SFZNvDLVjEOe_nSQ3yi2nA": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"qqPAfufciUqT8mCYnz5qZw": {
getter: function (varBag, idService) {
return varBag.vars.value.typeInLocal;
},
dataType: OS.Types.Text
},
"X6CcNarXSkOjfpnxrWfV7w": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"mbVOLocKnku3551ZtJh0TQ": {
getter: function (varBag, idService) {
return varBag.vars.value.versionInLocal;
},
dataType: OS.Types.Text
},
"mK2xYAi6_0S9jKlHlFX_vA": {
getter: function (varBag, idService) {
return varBag.vars.value.providerInLocal;
},
dataType: OS.Types.Text
},
"lG2n0UxFe0uo8VH+2gxmYA": {
getter: function (varBag, idService) {
return varBag.createChartJSResult.value;
}
},
"git4kKVCOkOFNPIMDUUGmQ": {
getter: function (varBag, idService) {
return varBag.vars.value.chartWidgetIdInLocal;
},
dataType: OS.Types.Text
},
"FPuFf012Sk+Kq97K+GUmcA": {
getter: function (varBag, idService) {
return varBag.removeChartJSResult.value;
}
},
"89jmZRBYlUSlXKcc7Cx+4g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"kml1hynqxEmmgzJfGdOn7Q": {
getter: function (varBag, idService) {
return varBag.vars.value.serieNameInLocal;
},
dataType: OS.Types.Text
},
"_ZY5g_0qJ0+3Q4qHbM0biw": {
getter: function (varBag, idService) {
return varBag.vars.value.propertyValueListInLocal;
}
},
"3Pj5Ak_XnkCucgUrKACySQ": {
getter: function (varBag, idService) {
return varBag.jSONSerializeVar.value;
}
},
"vSN_8g2cYUyMzI9a6NhbvA": {
getter: function (varBag, idService) {
return varBag.setHighchartsSeriesConfigsJSResult.value;
}
},
"kw9qKF3XD0OY0c+8TDDokw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"N0znugwJdU+dqvHm4FV5gQ": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"fLjwC51jAkCVUOEbHKZBcQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"wIzMGG5ldE+3PLJPaa4DFA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"a+5GNeDnXUW7r8n7AOvgKQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"oRNqIm1D702W2JB9j0pIEw": {
getter: function (varBag, idService) {
return varBag.updateConfigsJSResult.value;
}
},
"VHp3cQ81WkabX4BH__uLwQ": {
getter: function (varBag, idService) {
return varBag.vars.value.moduleURLVar;
},
dataType: OS.Types.Text
},
"JmAY5zHjSUiFtAB2clcXWw": {
getter: function (varBag, idService) {
return varBag.vars.value.highchartModulesIdentifierInLocal;
},
dataType: OS.Types.Text
},
"To_U18m+jEmPZlQNUJIdaA": {
getter: function (varBag, idService) {
return varBag.addModuleJSResult.value;
}
},
"AROJGBw6H0+zJ8PjfE_jZQ": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"ruxvsFZMw0Kb8ZJgG42Uxw": {
getter: function (varBag, idService) {
return varBag.vars.value.sourceDataPointListInLocal;
}
},
"Ah5_fO_KQUm3Gk2REQY_xQ": {
getter: function (varBag, idService) {
return varBag.vars.value.xAxisTypeInLocal;
},
dataType: OS.Types.Text
},
"qJjJVn6x30KxKQCbsrorKA": {
getter: function (varBag, idService) {
return varBag.jSONSerialize_SourceDataPoint_ListVar.value;
}
},
"fGpphqry6kisbR18rhsxPw": {
getter: function (varBag, idService) {
return varBag.initChartJSResult.value;
}
},
"HYsTDj03c0auJdItW6shyA": {
getter: function (varBag, idService) {
return varBag.vars.value.chartWidgetIdInLocal;
},
dataType: OS.Types.Text
},
"LkJMPr28Ek2yIhTNY2Ky9A": {
getter: function (varBag, idService) {
return varBag.vars.value.seriesEventIdInLocal;
},
dataType: OS.Types.Text
},
"XzNveXOZ1EKFpz2S3kMruA": {
getter: function (varBag, idService) {
return varBag.vars.value.callbackInLocal;
},
dataType: OS.Types.Object
},
"O4fHn6ImmEi9KbpWIhOxsA": {
getter: function (varBag, idService) {
return varBag.seriesEventUnregisterJSResult.value;
}
},
"K2Z2PePz5UO+58YkE+Crtw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"pE11ZPsvjU6jXSPr8CxSJQ": {
getter: function (varBag, idService) {
return varBag.showLoadingJSResult.value;
}
},
"Vx6CcbU1Bk652vj6blMkFg": {
getter: function (varBag, idService) {
return varBag.vars.value.titleInLocal;
},
dataType: OS.Types.Text
},
"qiFMwww5k0WF6bB19lSlTA": {
getter: function (varBag, idService) {
return varBag.vars.value.labelsRotationInLocal;
},
dataType: OS.Types.Integer
},
"5GKVvoEPXU6I0QxIyvF4zA": {
getter: function (varBag, idService) {
return varBag.vars.value.minValueInLocal;
},
dataType: OS.Types.Text
},
"IbUYGWI+uUqKAwH94j8Opg": {
getter: function (varBag, idService) {
return varBag.vars.value.maxValueInLocal;
},
dataType: OS.Types.Text
},
"jwDqxXpT+06962TLVGdWOQ": {
getter: function (varBag, idService) {
return varBag.vars.value.valuesTypeInLocal;
},
dataType: OS.Types.Integer
},
"hr7V9xdKSEamVUz9f_1sEw": {
getter: function (varBag, idService) {
return varBag.outVars.value.xAxisFormatOut;
}
},
"dG1RkhGJp0OIYlvuVxTyDA": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"Yy_TfBMBGkyQb3yhUklrwQ": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"K+J_ZpUH+E+a7XA61KPOfQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"ZDHffWQk1Uu4nWM0rNd6pw": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"Xcu5oO3gpECWNurIS4JAew": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"3POjxH6JbEWld8jHeSDB7A": {
getter: function (varBag, idService) {
return varBag.updateConfigsJSResult.value;
}
},
"6JAMPHsIQEG97jEO2GzlUQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"cNzu36YITUOnOoRZmswgEQ": {
getter: function (varBag, idService) {
return varBag.vars.value.propertyValueListInLocal;
}
},
"_mvEWTDOEkidV8KjKUhjUw": {
getter: function (varBag, idService) {
return varBag.jSONSerializeVar.value;
}
},
"diI5FPCa9UqJJ56AKlPaJQ": {
getter: function (varBag, idService) {
return varBag.setHighchartsAxisConfigsJSResult.value;
}
},
"QxCz5fZhW0ShwrOpDiKrKw": {
getter: function (varBag, idService) {
return varBag.vars.value.tempDateTimeVar;
},
dataType: OS.Types.DateTime
},
"yiKQLwPksUy36uZnWOEcPQ": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInLocal;
},
dataType: OS.Types.Text
},
"H2LRRVOmC0ydlwY+TvNwNQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.outputOut;
},
dataType: OS.Types.Text
},
"nVgk1z8mW0yPVuN2WVhEgA": {
getter: function (varBag, idService) {
return varBag.vars.value.showDataPointValuesInLocal;
},
dataType: OS.Types.Boolean
},
"svFD5MtHC0ONxLlBnn+c5A": {
getter: function (varBag, idService) {
return varBag.vars.value.useAnimationInLocal;
},
dataType: OS.Types.Boolean
},
"8tw_O2X1V0icajU2zOu+7A": {
getter: function (varBag, idService) {
return varBag.outVars.value.chartFormatOut;
}
},
"t9tw+J5mxkSQlRXwmEPyQQ": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"z0vxX66_cE6iLoSGcKjXuQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"1TiPH2Yy7Eu9Omeu5wVbkA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"L463BFcfgEyWycGOc+EStQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"YYIMOBQRmEq_zomaYisz1A": {
getter: function (varBag, idService) {
return varBag.disposeJSResult.value;
}
},
"WNjfQswuaEK6oLaOKIBbjw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"_bkGzP0SAU2uU0NblfF9Pw": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"j5PfTyjiVUW9VaBgFbFJWg": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"H1UucT4gpU2AV0Vc4T4DbQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"El6JEIgwwUiad8qYbC+pCw": {
getter: function (varBag, idService) {
return varBag.disposeJSResult.value;
}
},
"m7IOqo7HYE+ZIeUXNhv+ow": {
getter: function (varBag, idService) {
return varBag.vars.value.chartWidgetIdInLocal;
},
dataType: OS.Types.Text
},
"Es4PKWqeT0KGChZReCs0gw": {
getter: function (varBag, idService) {
return varBag.vars.value.seriesEventIdInLocal;
},
dataType: OS.Types.Text
},
"lx2e2cZTQki7kPVH3B2S1Q": {
getter: function (varBag, idService) {
return varBag.vars.value.callbackInLocal;
},
dataType: OS.Types.Object
},
"dgNYw+O7_0iuR+GkDYuUmQ": {
getter: function (varBag, idService) {
return varBag.seriesEventRegisterJSResult.value;
}
},
"wt3Dfo3XwkSnEovqwYDOBA": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"MF77rD1wIUaorR18RXPG0g": {
getter: function (varBag, idService) {
return varBag.vars.value.propertyValueListInLocal;
}
},
"PjEARjx+TUaHijmehQkzGw": {
getter: function (varBag, idService) {
return varBag.jSONSerializeVar.value;
}
},
"ltErpG+Cckmbv5J03GAHug": {
getter: function (varBag, idService) {
return varBag.setHighchartsAxisConfigsJSResult.value;
}
},
"FIz_lundLE+opI6uw3iVNA": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"mvXWioPIzU69bmDJTBNzdg": {
getter: function (varBag, idService) {
return varBag.vars.value.propertyValueListInLocal;
}
},
"PeGDVh8UP0uNLnHrAjLIpA": {
getter: function (varBag, idService) {
return varBag.jSONSerializeVar.value;
}
},
"qMOi9hfSwkaAOmWE0F+eyw": {
getter: function (varBag, idService) {
return varBag.setHighchartsChartConfigsJSResult.value;
}
},
"1ytCFZQqIES74qQ2PqVG_w": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"05uEsUbFHkSz5kuU+jx0gg": {
getter: function (varBag, idService) {
return varBag.initializeSeriesStylingJSResult.value;
}
},
"13tGKdn6d0Cgc4lcQcnu5w": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"ixawfXjgIUaQk5abK74MLg": {
getter: function (varBag, idService) {
return varBag.outVars.value.didSomethingOut;
},
dataType: OS.Types.Boolean
},
"dqVc130Uj0CThrz+22Z51A": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"SjJdWZ33T0qUN+Vjb4RBAQ": {
getter: function (varBag, idService) {
return varBag.deserializeErrorsVar.value;
}
},
"fAulriwF30uk6n6i6ySFvg": {
getter: function (varBag, idService) {
return varBag.forceReloadJSResult.value;
}
},
"iL4gdYubDkCQJdsghomMcg": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"sdkwbIGGNEGSFkiuXePoGg": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"UadsqdgVcUSefeOnEu5zFQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.successOut;
},
dataType: OS.Types.Boolean
},
"J71ONJ_TBkqqGaWalY52Eg": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
}
},
"3UFYu_UMhUavy9RJvC3n7Q": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeErrorMessageVar.value;
}
},
"c8HQie0GbE6ERD6F4UFFQw": {
getter: function (varBag, idService) {
return varBag.updateConfigsJSResult.value;
}
},
"n7QfKnicFEmlhbjdQ_Yalw": {
getter: function (varBag, idService) {
return varBag.vars.value.titleInLocal;
},
dataType: OS.Types.Text
},
"YM0OU5YtcUu5yk3aXFEy+w": {
getter: function (varBag, idService) {
return varBag.vars.value.minValueInLocal;
},
dataType: OS.Types.Decimal
},
"TIFKTnrYOUWVrpVMWKbbXA": {
getter: function (varBag, idService) {
return varBag.vars.value.maxValueInLocal;
},
dataType: OS.Types.Decimal
},
"A5FCvT02FkCXhhn4XSozAA": {
getter: function (varBag, idService) {
return varBag.vars.value.valuesPrefixInLocal;
},
dataType: OS.Types.Text
},
"_FvKV_zHL02cGn_YKLjGtQ": {
getter: function (varBag, idService) {
return varBag.vars.value.valuesSufixInLocal;
},
dataType: OS.Types.Text
},
"gImG7ASFzEmmYp8xE8trnQ": {
getter: function (varBag, idService) {
return varBag.vars.value.gridLineStepInLocal;
},
dataType: OS.Types.Decimal
},
"3PfFk2TR60m92cZShShN8A": {
getter: function (varBag, idService) {
return varBag.outVars.value.yAxisFormatOut;
}
},
"GPf6VUZY2UWhek0IyfnqgQ": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"_eZj475cMkq3Z4NX_CV7pg": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"Z_8UihH8V0aB0YPbKE1ReQ": {
getter: function (varBag, idService) {
return varBag.vars.value.providerInLocal;
},
dataType: OS.Types.Text
},
"tO4gGQlBNkKYIQ72ZCX8jA": {
getter: function (varBag, idService) {
return varBag.createExportJSResult.value;
}
},
"0yF9by6eC0eTfRxG053aWw": {
getter: function (varBag, idService) {
return varBag.vars.value.uniqueIdInLocal;
},
dataType: OS.Types.Text
},
"nUPOiWlOr0Sxf4ikbKAUhg": {
getter: function (varBag, idService) {
return varBag.vars.value.configsInLocal;
},
dataType: OS.Types.Text
},
"lYzF1UkYBU+j_Orwfrjcwg": {
getter: function (varBag, idService) {
return varBag.vars.value.typeInLocal;
},
dataType: OS.Types.Text
},
"E89Cs_2jdkW7Gy55LEvxHA": {
getter: function (varBag, idService) {
return varBag.vars.value.providerInLocal;
},
dataType: OS.Types.Text
},
"qEFFsHDywEWP12REQYxnAw": {
getter: function (varBag, idService) {
return varBag.createAxisJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
