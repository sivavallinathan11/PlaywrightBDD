define("PHICore.appDefinition", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
return {
environmentKey: "17076cf3-e014-41d0-ae7b-25d9803daca6",
environmentName: "Development",
applicationKey: "412e9b89-17be-4a18-8e5c-6aa466ec4fa5",
applicationName: "PHI Core UI",
userProviderName: "Users",
debugEnabled: true,
homeModuleName: "PHICore",
homeModuleKey: "d32ceb8b-e4e4-4452-bb12-dd3ccde6df62",
homeModuleControllerName: "PHICore.controller",
homeModuleLanguageResourcesName: "PHICore.languageResources",
defaultTransition: "Fade",
errorPageConfig: {
showExceptionStack: false
},
isWeb: true,
personalArea: null,
showWatermark: false
};
});
