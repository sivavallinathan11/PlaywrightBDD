define("PHICore.Exceptions.controller", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.Exceptions.controller$debugger", "PHICore.controller$ServerAction.User_GetUnifiedLoginUrl"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables, PHICore_Exceptions_Controller_debugger) {
var OS = OutSystems.Internal;
var PHICore_ExceptionsController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
var securityExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var communicationExceptionVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var user_GetUnifiedLoginUrlVar = new OS.DataTypes.VariableHolder();
varBag.securityExceptionVar = securityExceptionVar;
varBag.allExceptionsVar = allExceptionsVar;
varBag.communicationExceptionVar = communicationExceptionVar;
varBag.user_GetUnifiedLoginUrlVar = user_GetUnifiedLoginUrlVar;
OS.Logger.trace("Exceptions.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(OS.ErrorHandling.ignoreError(ex, callContext)) {
return OS.ErrorHandling.IGNORED_ERROR_RESULT;
}

return OS.Flow.tryCatchFinally(function () {
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:B4kRGvrnOEmQonA8ir4Pyg.#FlowExceptionHandler:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/FlowExceptionHandler:bbZMb_OKSYM0ZsPGPIPMoQ", "PHICore", "OnException", "NRFlows.FlowExceptionHandlingFlow", callContext.id, varBag);
OS.Logger.trace("Exceptions.OnException", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: SecurityException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.SecurityException)) {
securityExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+tKwHaommkeVIJmjpddaOg", callContext.id);
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:u5PSnLcsSUijuLk3FxAP_w", callContext.id) && ((OS.BuiltinFunctions.getUserId()) !== (OS.BuiltinFunctions.nullIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iuqnjT7CNkK0qYSFI+8CZA", callContext.id);
// Destination: /PHICore/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore_TH/InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5MrtZVVVTEGgluVB4R0Vqg", callContext.id);
// Execute Action: User_GetUnifiedLoginUrl
return controller.user_GetUnifiedLoginUrl$ServerAction(OS.BuiltinFunctions.getBookmarkableURL(), "", callContext).then(function (value) {
user_GetUnifiedLoginUrlVar.value = value;
}).then(function () {
// Found Unified Login URL
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eFR3RS9re0+r1_PHPHgETQ", callContext.id) && ((user_GetUnifiedLoginUrlVar.value.urlOut) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lbJGpaEQnE2rZZgyKcLjGw", callContext.id);
// Destination: /PHICore/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(user_GetUnifiedLoginUrlVar.value.urlOut, {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
// LastRequest
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yCJzTyHZ306_5j1iw6zLeg", callContext.id);
// LastURL = GetBookmarkableURL
PHICoreClientVariables.setLastURL(OS.BuiltinFunctions.getBookmarkableURL());
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Vetk1g46bUKbM+70jg35ag", callContext.id);
// Destination: /PHICore/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/SandboxLogin/Login", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}

});
});
}

// Handle Error: CommunicationException
if(OS.Exceptions.isInstanceOf(ex, OS.Exceptions.Exceptions.CommunicationException)) {
OS.Logger.error(null, ex);
communicationExceptionVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UEw6n9qWe06ZuSWntFQS4w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZW2tO1gq9ke3K4B8INEM6w", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(communicationExceptionVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4qeSJUNPsU2eKIm6gj0sdw", callContext.id);
return OS.Flow.returnAsync();

});
}

// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YJDpIiqj+kystnvSyst84Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hd35JhN3zEmey3w4Y9h7LQ", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(allExceptionsVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lR4WVBAPvki5mxBvHbkoEg", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}, function (unhandledEx) {
OS.Logger.trace("Exceptions.OnException", OS.Exceptions.getMessage(ex), ex.name);
if(!(OS.ErrorHandling.ignoreError(unhandledEx, callContext))) {
OS.ErrorHandling.handleError(unhandledEx, callContext);
OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.UNHANDLED_ERROR_RESULT;

}

OutSystemsDebugger.handleException(unhandledEx, callContext.id);
return OS.ErrorHandling.IGNORED_ERROR_RESULT;

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:B4kRGvrnOEmQonA8ir4Pyg.#FlowExceptionHandler", callContext.id);
});


};
Controller.prototype.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/PHICore/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore.Exceptions$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore.Exceptions$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
return Controller;
})(OS.Controller.BaseController);
PHICore_ExceptionsController.default = new Controller();
});

define("PHICore.Exceptions.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"+tKwHaommkeVIJmjpddaOg": {
getter: function (varBag, idService) {
return varBag.securityExceptionVar.value;
}
},
"YJDpIiqj+kystnvSyst84Q": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"UEw6n9qWe06ZuSWntFQS4w": {
getter: function (varBag, idService) {
return varBag.communicationExceptionVar.value;
}
},
"5MrtZVVVTEGgluVB4R0Vqg": {
getter: function (varBag, idService) {
return varBag.user_GetUnifiedLoginUrlVar.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
