define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "OutSystemsUI.model", "OutSystemsUI.controller", "PHICore_TH.Common.TabStart.mvc$model", "PHICore_TH.Common.MenuIcon.mvc$model", "PHICore_TH.Common.TabEnd.mvc$model", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, OutSystemsUIModel, OutSystemsUIController, PHICore_TH_Common_TabStart_mvcModel, PHICore_TH_Common_MenuIcon_mvcModel, PHICore_TH_Common_TabEnd_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("EventFunction", "eventFunctionVar", "EventFunction", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("ResizeObserver", "resizeObserverVar", "ResizeObserver", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("HasFixedHeader", "hasFixedHeaderIn", "HasFixedHeader", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_hasFixedHeaderInDataFetchStatus", "_hasFixedHeaderInDataFetchStatus", "_hasFixedHeaderInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("EnableAccessibilityFeatures", "enableAccessibilityFeaturesIn", "EnableAccessibilityFeatures", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_enableAccessibilityFeaturesInDataFetchStatus", "_enableAccessibilityFeaturesInDataFetchStatus", "_enableAccessibilityFeaturesInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasBottomActions", "hasBottomActionsIn", "HasBottomActions", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasBottomActionsInDataFetchStatus", "_hasBottomActionsInDataFetchStatus", "_hasBottomActionsInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((PHICore_TH_Common_TabStart_mvcModel.hasValidationWidgets || PHICore_TH_Common_MenuIcon_mvcModel.hasValidationWidgets) || PHICore_TH_Common_TabEnd_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("HasFixedHeader" in inputs) {
this.variables.hasFixedHeaderIn = inputs.HasFixedHeader;
if("_hasFixedHeaderInDataFetchStatus" in inputs) {
this.variables._hasFixedHeaderInDataFetchStatus = inputs._hasFixedHeaderInDataFetchStatus;
}

}

if("EnableAccessibilityFeatures" in inputs) {
this.variables.enableAccessibilityFeaturesIn = inputs.EnableAccessibilityFeatures;
if("_enableAccessibilityFeaturesInDataFetchStatus" in inputs) {
this.variables._enableAccessibilityFeaturesInDataFetchStatus = inputs._enableAccessibilityFeaturesInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

if("HasBottomActions" in inputs) {
this.variables.hasBottomActionsIn = inputs.HasBottomActions;
if("_hasBottomActionsInDataFetchStatus" in inputs) {
this.variables._hasBottomActionsInDataFetchStatus = inputs._hasBottomActionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Layouts.HAMBS_BaseLayout");
});
define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$model", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller", "PHICore_TH.clientVariables", "PHICore_TH.Common.TabStart.mvc$view", "OutSystems/ReactWidgets/Main", "PHICore_TH.Common.MenuIcon.mvc$view", "PHICore_TH.Common.TabEnd.mvc$view", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, React, OSView, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_model, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller, PHICore_THClientVariables, PHICore_TH_Common_TabStart_mvc_view, OSWidgets, PHICore_TH_Common_MenuIcon_mvc_view, PHICore_TH_Common_TabEnd_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Layouts.HAMBS_BaseLayout";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/OutSystemsUI.OutSystemsUI.js", "scripts/PHICore_TH.JQuery.js"];
        };
        View.getBlocks = function() {
            return [PHICore_TH_Common_TabStart_mvc_view, PHICore_TH_Common_MenuIcon_mvc_view, PHICore_TH_Common_TabEnd_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(PHICore_TH_Common_TabStart_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("LayoutWrapper.Style"), function () {
return ((("layout layout-top" + ((model.variables.hasFixedHeaderIn) ? (" fixed-header") : (""))) + ((!(model.variables.enableAccessibilityFeaturesIn)) ? ("") : (" has-accessible-features"))) + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.hasFixedHeaderIn;
}, function () {
return model.variables.enableAccessibilityFeaturesIn;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "LayoutWrapper"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasFixedHeaderInDataFetchStatus, model.variables._enableAccessibilityFeaturesInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "main",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
role: "banner",
className: "header"
},
tag: "header",
_idProps: {
service: idService,
name: "Header2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "header-top ThemeGrid_Container",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "header-content display-flex ",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(PHICore_TH_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "application-name display-flex align-items-center full-height",
visible: true,
_idProps: {
service: idService,
name: "ApplicationTitleWrapper"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.branding,
_idProps: {
service: idService,
name: "Branding"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.header,
gridProperties: {
classes: "OSInline"
},
style: "header-navigation",
_idProps: {
service: idService,
name: "Header"
},
_widgetRecordProvider: widgetsRecordProvider
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "header-blue-ribbon background-primary",
visible: true,
_idProps: {
service: idService,
name: "UnderHeader"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "under-header-inner",
visible: true,
_idProps: {
service: idService,
name: "UnderHeaderInner"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width8"
},
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.underHeaderTitle,
style: "font-roboto",
_idProps: {
service: idService,
name: "UnderHeaderTitle"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width4 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.underHeaderAction,
_idProps: {
service: idService,
name: "UnderHeaderAction"
},
_widgetRecordProvider: widgetsRecordProvider
})))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "content",
visible: true,
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "main"
},
style: model.getCachedValue(idService.getId("MainContentWrapper.Style"), function () {
return ("main-content ThemeGrid_Container padding-top-xm" + ((model.variables.hasBottomActionsIn) ? (" padding-bottom-none") : ("")));
}, function () {
return model.variables.hasBottomActionsIn;
}),
visible: true,
_idProps: {
service: idService,
name: "MainContentWrapper"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasBottomActionsInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.breadcrumbs,
style: "content-breadcrumbs ph",
_idProps: {
service: idService,
name: "Breadcrumbs"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "content-top display-flex align-items-center ph",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "content-top-title heading1 ph",
visible: true,
_idProps: {
service: idService,
name: "TitleHeader"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.AdvancedHtml, {
tag: "h1",
_idProps: {
service: idService,
name: "Heading"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.title,
_idProps: {
service: idService,
name: "Title"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.actions,
style: "content-top-actions ph",
_idProps: {
service: idService,
name: "Actions"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.mainContent,
style: "content-middle",
_idProps: {
service: idService,
name: "MainContent"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
role: "contentinfo",
className: "content-bottom"
},
tag: "footer",
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.footer,
style: "footer ThemeGrid_Container ph",
_idProps: {
service: idService,
name: "Footer"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Text, {
extendedProperties: {
role: "alert",
"alertholder": ""
},
style: "absolute-bottom hidden",
text: [],
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
gridProperties: {
classes: "OSInline"
},
style: "sticky-bottom-actions-container",
visible: model.variables.hasBottomActionsIn,
_idProps: {
service: idService,
name: "BottomActions"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasBottomActionsInDataFetchStatus)
}))), React.createElement(PHICore_TH_Common_TabEnd_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "29",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "PHICore_TH.languageResources", "PHICore_TH.clientVariables", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$debugger", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.SetEventListeners.AddEventListenerJS", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.SetEventListeners.RemoveEventListenerJS", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.StartMutationObserver.StartMutationObserverJS", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, PHICore_THLanguageResources, PHICore_THClientVariables, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_Debugger, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_SetEventListeners_AddEventListenerJS, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_SetEventListeners_RemoveEventListenerJS, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_StartMutationObserver_StartMutationObserverJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:iIwDa+DW20KCk0Yn+m4svA:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg/ClientActions.iIwDa+DW20KCk0Yn+m4svA:VBJ7et7XRUsRCgQk0s9URQ", "PHICore_TH", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:1SscdyGHukmWl8SEx6cA6g", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:1o9cMsXE4kuGDYhqI66AHg", callContext.id);
// Execute Action: SetEventListeners
controller._setEventListeners$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:qVjy43z8EkSW31kOlCXauA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:iIwDa+DW20KCk0Yn+m4svA", callContext.id);
}

};
Controller.prototype._setEventListeners$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetEventListeners");
callContext = controller.callContext(callContext);
var addEventListenerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.addEventListenerJSResult = addEventListenerJSResult;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:ohUXikgCqEC4D7_QNYfq+A:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg/ClientActions.ohUXikgCqEC4D7_QNYfq+A:j9BX+fpZevZKQTHTx_GEZg", "PHICore_TH", "SetEventListeners", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:UwJfWqDi+EaPbHnP7CW8bg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:4XwdfShbIU6RGCCwEz5pFA", callContext.id) && model.variables.hasBottomActionsIn)) {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:FO9PZTNm70eBm3yMmVlSXA", callContext.id);
addEventListenerJSResult.value = controller.safeExecuteJSNode(PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_SetEventListeners_AddEventListenerJS, "AddEventListener", "SetEventListeners", {
BottomActionsId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("BottomActions"), OS.Types.Text),
ResizeObserver: OS.DataConversion.JSNodeParamConverter.to(model.variables.resizeObserverVar, OS.Types.Object),
EventFunction: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object),
NewResizeObserver: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("PHICore_TH.Layouts.HAMBS_BaseLayout.SetEventListeners$addEventListenerJSResult"))();
jsNodeResult.eventFunctionOut = OS.DataConversion.JSNodeParamConverter.from($parameters.EventFunction, OS.Types.Object);
jsNodeResult.newResizeObserverOut = OS.DataConversion.JSNodeParamConverter.from($parameters.NewResizeObserver, OS.Types.Object);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:ixchGZMEGEC_+82EU0_Kvg", callContext.id);
// EventFunction = AddEventListener.EventFunction
model.variables.eventFunctionVar = addEventListenerJSResult.value.eventFunctionOut;
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:ixchGZMEGEC_+82EU0_Kvg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ResizeObserver = AddEventListener.NewResizeObserver
model.variables.resizeObserverVar = addEventListenerJSResult.value.newResizeObserverOut;
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:vsJIAU_LuUCm+SJOBaSomg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:+suwZkf8NkG19gpQHuNBCw", callContext.id);
controller.safeExecuteJSNode(PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_SetEventListeners_RemoveEventListenerJS, "RemoveEventListener", "SetEventListeners", {
EventFunction: OS.DataConversion.JSNodeParamConverter.to(model.variables.eventFunctionVar, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:vsJIAU_LuUCm+SJOBaSomg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:ohUXikgCqEC4D7_QNYfq+A", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore_TH.Layouts.HAMBS_BaseLayout.SetEventListeners$addEventListenerJSResult", [{
name: "EventFunction",
attrName: "eventFunctionOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}, {
name: "NewResizeObserver",
attrName: "newResizeObserverOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._startMutationObserver$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("StartMutationObserver");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:BIVawDPek0itqtKJkEYJAA:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg/ClientActions.BIVawDPek0itqtKJkEYJAA:6v9D4HuT4m66mWhb9GEllg", "PHICore_TH", "StartMutationObserver", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:CZovGqVCk0etV+HKIJq4lg", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:vZCeRw8qIUuv9CDncNo0Vg", callContext.id);
controller.safeExecuteJSNode(PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_controller_StartMutationObserver_StartMutationObserverJS, "StartMutationObserver", "StartMutationObserver", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:eIFv9gvKHECYoUVDdWbHGw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:BIVawDPek0itqtKJkEYJAA", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var addFaviconVar = new OS.DataTypes.VariableHolder();
var setLangVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.addFaviconVar = addFaviconVar;
varBag.setLangVar = setLangVar;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:OSGi7r15zUiAl2AsMHGWOw:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg/ClientActions.OSGi7r15zUiAl2AsMHGWOw:fRAozuQo1cBJlio+STz27A", "PHICore_TH", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:Oj8unPOz6EiHQlJLfRQXWw", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:ztfs6UglCkCt2qpwS6pePg", callContext.id);
// Execute Action: LayoutReady
OutSystemsUIController.default.layoutReady$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:gPcB3dVAwkuEaR9RjyW5DA", callContext.id);
// Execute Action: SetLang
setLangVar.value = OutSystemsUIController.default.setLang$Action("", callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:oVqhVyHezEi2InKqQwDvsw", callContext.id);
// Execute Action: AddFavicon
addFaviconVar.value = OutSystemsUIController.default.addFavicon$Action("favicon.png", callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:z5GMofaRbEKA647QGm_Fag", callContext.id);
// Execute Action: StartMutationObserver
controller._startMutationObserver$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:TW50NM3QwkuJn9AJCnNSlw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:OSGi7r15zUiAl2AsMHGWOw", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:StrK_Nqe5k2rNSpqhYKiNg:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg/ClientActions.StrK_Nqe5k2rNSpqhYKiNg:9V1sIGhVyzLEfdnXBjy9kg", "PHICore_TH", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:tIWkTsKXjk+Eq1gEH1vrDA", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:LN9U7FnroEGNXm7WH7prFg", callContext.id);
// Execute Action: LayoutDestroy
OutSystemsUIController.default.layoutDestroy$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:opgN5T7myUi3oKdD5KutHA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:StrK_Nqe5k2rNSpqhYKiNg", callContext.id);
}

};

Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.setEventListeners$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setEventListeners$Action, callContext);

};
Controller.prototype.startMutationObserver$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._startMutationObserver$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.event$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:h5vDTMuLX06AWEdKRweFvA:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA:lwBqpM5MEmNYSGKQjqDzFw", "PHICore_TH", "Layouts", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:TKLCLOMOTkq37zLH_v8Zgg:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.TKLCLOMOTkq37zLH_v8Zgg:6QTL+5CaOsbPYACQrdRsRw", "PHICore_TH", "HAMBS_BaseLayout", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:TKLCLOMOTkq37zLH_v8Zgg", callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:h5vDTMuLX06AWEdKRweFvA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/HAMBS_BaseLayout On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/HAMBS_BaseLayout On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/HAMBS_BaseLayout On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICore_THLanguageResources);
});
define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.SetEventListeners.AddEventListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
 if(document.querySelector('.screen-container').scrollTop + document.querySelector('.screen-container').clientHeight + 72 >= document.documentElement.clientHeight) {
    document.querySelector('#' + $parameters.BottomActionsId).classList.add('hidden');
}

$parameters.EventFunction = function() {
    if(document.querySelector('.screen-container').scrollTop + document.querySelector('.screen-container').clientHeight + 72 >= document.querySelector('.layout').clientHeight) {
        document.querySelector('#' + $parameters.BottomActionsId).classList.add('hidden');
    } else {
        document.querySelector('#' + $parameters.BottomActionsId).classList.remove('hidden');
    }
}

if (!$parameters.ResizeObserver) {
    $parameters.ResizeObserver = new ResizeObserver($parameters.EventFunction);
}
$parameters.NewResizeObserver = $parameters.ResizeObserver;

document.querySelector('.screen-container').addEventListener('scroll', $parameters.EventFunction);
$parameters.NewResizeObserver.observe(document.querySelector('.layout'));
};
});
define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.SetEventListeners.RemoveEventListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
document.querySelector('.screen-container').removeEventListener('scroll', $parameters.EventFunction);
};
});
define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$controller.StartMutationObserver.StartMutationObserverJS", [], function () {
return function ($actions, $roles, $public) {
var mutationObserver = new MutationObserver(function() {
    mutationObserver.disconnect();
    document.querySelectorAll('input[type=text]:not([autocomplete=one-time-code]),input[type=search]:not([autocomplete=one-time-code])').forEach((element) => {element.setAttribute('autocomplete', 'one-time-code')});
    document.querySelectorAll('[aria-label=\'Trigger the balloon\'').forEach((element) => {element.setAttribute('aria-label', element.innerText)});
    document.querySelectorAll('th[tabindex=\'-1\'],button[role=\'tab\'][tabindex=\'-1\']').forEach((element) => {element.setAttribute('tabindex', 0)});
    document.querySelectorAll('a[disabled],input[disabled],select[disabled],textarea[disabled]').forEach((element) => {element.removeAttribute('disabled'); element.setAttribute('aria-disabled', 'true');});
    document.querySelectorAll('.feedback-message').forEach((element) => {
        element.querySelector('.feedback-message-text').setAttribute('role', 'alert');
        if(element.getAttribute('class').includes('feedback-message-error')) {
            setTimeout(function() {
                if(document.querySelector('input.not-valid, .not-valid select')) {
                    document.querySelector('input.not-valid, .not-valid select').focus();
                }
            }, 4000);
        }
    });
    mutationObserver.observe(document.querySelector('body'), {childList: true, subtree: true});
});

mutationObserver.observe(document.querySelector('body'), {childList: true, subtree: true});
};
});

define("PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"FO9PZTNm70eBm3yMmVlSXA": {
getter: function (varBag, idService) {
return varBag.addEventListenerJSResult.value;
}
},
"+suwZkf8NkG19gpQHuNBCw": {
getter: function (varBag, idService) {
return varBag.removeEventListenerJSResult.value;
}
},
"vZCeRw8qIUuv9CDncNo0Vg": {
getter: function (varBag, idService) {
return varBag.startMutationObserverJSResult.value;
}
},
"oVqhVyHezEi2InKqQwDvsw": {
getter: function (varBag, idService) {
return varBag.addFaviconVar.value;
}
},
"gPcB3dVAwkuEaR9RjyW5DA": {
getter: function (varBag, idService) {
return varBag.setLangVar.value;
}
},
"Y+l48uHZkEmiP_tq34fGmw": {
getter: function (varBag, idService) {
return varBag.model.variables.eventFunctionVar;
},
dataType: OS.Types.Object
},
"T89iMxmy+kWXMCfIfCLr4A": {
getter: function (varBag, idService) {
return varBag.model.variables.resizeObserverVar;
},
dataType: OS.Types.Object
},
"EdeaCWXSMUSxzqpiE0KKYA": {
getter: function (varBag, idService) {
return varBag.model.variables.hasFixedHeaderIn;
},
dataType: OS.Types.Boolean
},
"hiO1kfQPD0ivEA7mXgB6WA": {
getter: function (varBag, idService) {
return varBag.model.variables.enableAccessibilityFeaturesIn;
},
dataType: OS.Types.Boolean
},
"u9W2rnlGP0SyqYsRYv5aFQ": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"ZKQwP1fs+UGFMwEpHEUpXg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasBottomActionsIn;
},
dataType: OS.Types.Boolean
},
"Cl4xDCSPeUu46PS2xRdpQA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LayoutWrapper"));
})(varBag.model, idService);
}
},
"QB7o3VQ8r0iqckcdvcFJoQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Header2"));
})(varBag.model, idService);
}
},
"wl9EzUTk3kubM1T6kyQjRw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApplicationTitleWrapper"));
})(varBag.model, idService);
}
},
"DX_G2QAuGUCVby3red2BsA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Branding"));
})(varBag.model, idService);
}
},
"hmzA_Z1NVE2MXyL6PBXTpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Header"));
})(varBag.model, idService);
}
},
"ViupPrEFckuUw8curpyqLg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeader"));
})(varBag.model, idService);
}
},
"x_Ze+qD8pkusinyKaGQyZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderInner"));
})(varBag.model, idService);
}
},
"bXNbK8ijO0C+SJgMWf3zxg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderTitle"));
})(varBag.model, idService);
}
},
"Uubg0UwRJ0+H14lZWT9tgQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderAction"));
})(varBag.model, idService);
}
},
"CThrxmwytUqBUMe6cuomTQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"8jPKj1Gz1kmwmJenIQ7IUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContentWrapper"));
})(varBag.model, idService);
}
},
"k5gq3WPozUiolHKME4ir0A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Breadcrumbs"));
})(varBag.model, idService);
}
},
"RHkyNjTE0ES+c4UWzJSiEA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TitleHeader"));
})(varBag.model, idService);
}
},
"dVu73lMPIkemoSMSe2NJXg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Heading"));
})(varBag.model, idService);
}
},
"xFZzEwQy3ECwBYwGKzASXw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"IumMX7DATEifX7xg9qjMJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"XZ537vTjXk2QOLWwTSRfiw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContent"));
})(varBag.model, idService);
}
},
"dnl1d_92VkS1jshhy33r8g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
},
"KS_ybyBs6EKR7b6BtNk_7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("BottomActions"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
