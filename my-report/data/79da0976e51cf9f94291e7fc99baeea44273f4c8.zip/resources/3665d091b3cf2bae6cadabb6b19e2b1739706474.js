define("Common_CS.model$KeyValueStringPairRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var KeyValueStringPairRec = (function (_super) {
__extends(KeyValueStringPairRec, _super);
function KeyValueStringPairRec(defaults) {
_super.apply(this, arguments);
}
KeyValueStringPairRec.attributesToDeclare = function () {
return [
this.attr("Key", "keyAttr", "Key", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
KeyValueStringPairRec.init();
return KeyValueStringPairRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.KeyValueStringPairRec = KeyValueStringPairRec;

});
define("Common_CS.model$EntityActionMessageRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var EntityActionMessageRec = (function (_super) {
__extends(EntityActionMessageRec, _super);
function EntityActionMessageRec(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageRec.attributesToDeclare = function () {
return [
this.attr("FieldId", "fieldIdAttr", "FieldId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MessageText", "messageTextAttr", "MessageText", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MessageTypeId", "messageTypeIdAttr", "MessageTypeId", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionMessageRec.init();
return EntityActionMessageRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.EntityActionMessageRec = EntityActionMessageRec;

});
define("Common_CS.model$EntityActionMessageList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CS.model$EntityActionMessageRec"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var EntityActionMessageList = (function (_super) {
__extends(EntityActionMessageList, _super);
function EntityActionMessageList(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageList.itemType = Common_CSModel.EntityActionMessageRec;
return EntityActionMessageList;
})(OS.DataTypes.GenericRecordList);
Common_CSModel.EntityActionMessageList = EntityActionMessageList;

});
define("Common_CS.model$EntityActionResultRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CS.model$EntityActionMessageList"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var EntityActionResultRec = (function (_super) {
__extends(EntityActionResultRec, _super);
function EntityActionResultRec(defaults) {
_super.apply(this, arguments);
}
EntityActionResultRec.attributesToDeclare = function () {
return [
this.attr("IsSuccess", "isSuccessAttr", "IsSuccess", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CombinedEntityMessageText", "combinedEntityMessageTextAttr", "CombinedEntityMessageText", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CombinedEntityActionMessageTypeId", "combinedEntityActionMessageTypeIdAttr", "CombinedEntityActionMessageTypeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("EntityActionMessages", "entityActionMessagesAttr", "EntityActionMessages", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CSModel.EntityActionMessageList());
}, true, Common_CSModel.EntityActionMessageList)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionResultRec.init();
return EntityActionResultRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.EntityActionResultRec = EntityActionResultRec;

});
define("Common_CS.model$TimeZoneRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var TimeZoneRec = (function (_super) {
__extends(TimeZoneRec, _super);
function TimeZoneRec(defaults) {
_super.apply(this, arguments);
}
TimeZoneRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("UTC_StandardOffset", "uTC_StandardOffsetAttr", "UTC_StandardOffset", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("UTC_DSTOffset", "uTC_DSTOffsetAttr", "UTC_DSTOffset", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TimeZoneRec.init();
return TimeZoneRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.TimeZoneRec = TimeZoneRec;

});
define("Common_CS.model$ChangesRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var ChangesRec = (function (_super) {
__extends(ChangesRec, _super);
function ChangesRec(defaults) {
_super.apply(this, arguments);
}
ChangesRec.attributesToDeclare = function () {
return [
this.attr("Before", "beforeAttr", "Before", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("After", "afterAttr", "After", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ChangesRec.init();
return ChangesRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.ChangesRec = ChangesRec;

});
define("Common_CS.model$KeyValuePairRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model"], function (exports, OutSystems, Common_CSModel) {
var OS = OutSystems.Internal;
var KeyValuePairRec = (function (_super) {
__extends(KeyValuePairRec, _super);
function KeyValuePairRec(defaults) {
_super.apply(this, arguments);
}
KeyValuePairRec.attributesToDeclare = function () {
return [
this.attr("Key", "keyAttr", "Key", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
KeyValuePairRec.init();
return KeyValuePairRec;
})(OS.DataTypes.GenericRecord);
Common_CSModel.KeyValuePairRec = KeyValuePairRec;

});
define("Common_CS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Common_CSModel = exports;
});
