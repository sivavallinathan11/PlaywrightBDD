define("SandBoxLogin.controller$ServerAction.User_GetUnifiedLoginUrl", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.controller"], function (exports, OutSystems, SandBoxLoginModel, SandBoxLoginController) {
var OS = OutSystems.Internal;
SandBoxLoginController.default.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/SandBoxLogin/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("SandBoxLogin$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
SandBoxLoginController.default.constructor.registerVariableGroupType("SandBoxLogin$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("SandBoxLogin.controller", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.controller$debugger"], function (exports, OutSystems, SandBoxLoginModel, SandBoxLogin_Controller_debugger) {
var OS = OutSystems.Internal;
var SandBoxLoginController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {
HAMBSAdmin: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pTbfUvhMMEq0Im8nv1GeQg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotHAMBSAdmin", "HAMBSAdmin role required")
},
SystemAdministrator: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*eGpqnKatjECYBG4l+F4pYA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSystemAdministrator", "SystemAdministrator role required")
},
OA_6_ManageFundSetupAndBranding: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*SgSQq7k8qkC9DtiSVCHwYQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_6_ManageFundSetupAndBranding", "OA_6_ManageFundSetupAndBranding role required")
}
};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return SandBoxLoginController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
SandBoxLoginController.default = new Controller(null, "SandBoxLogin");
});
define("SandBoxLogin.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main", "SandBoxLogin.clientVariables"], function (exports, Debugger, OutSystems, SandBoxLoginClientVariables) {
var OS = OutSystems.Internal;
var metaInfo = {
"4BcWEWvHTk2h3psxeZoyng": {
getter: function (varBag, idService) {
return SandBoxLoginClientVariables.getLastURL();
},
dataType: OS.Types.Text
},
"l1CSc5x1O0awp_WWouahoQ": {
getter: function (varBag, idService) {
return SandBoxLoginClientVariables.getUsername();
},
dataType: OS.Types.Text
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
