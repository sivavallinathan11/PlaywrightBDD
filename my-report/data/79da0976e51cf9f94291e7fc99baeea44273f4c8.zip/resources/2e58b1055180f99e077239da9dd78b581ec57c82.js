define("OutSystemsUI.Navigation.Tabs.mvc$model", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$Tabs_InternalConfigRec", "OutSystemsUI.model$TabsOptionalConfigsRec", "OutSystemsUI.controller$TabsRegisterCallback", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsCreate", "OutSystemsUI.controller$TabsInitialize", "OutSystemsUI.controller$TabsDestroy", "OutSystemsUI.controller$TabsChangeTextProperty", "OutSystemsUI.controller$TabsChangeBooleanProperty", "OutSystemsUI.controller$TabsChangeIntegerProperty"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("InternalConfigs", "internalConfigsVar", "InternalConfigs", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.Tabs_InternalConfigRec());
}, false, OutSystemsUIModel.Tabs_InternalConfigRec), 
this.attr("TabsOrientation", "tabsOrientationIn", "TabsOrientation", true, false, OS.Types.Text, function () {
return OutSystemsUIModel.staticEntities.orientation.horizontal;
}, false), 
this.attr("_tabsOrientationInDataFetchStatus", "_tabsOrientationInDataFetchStatus", "_tabsOrientationInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("StartingTab", "startingTabIn", "StartingTab", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_startingTabInDataFetchStatus", "_startingTabInDataFetchStatus", "_startingTabInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Height", "heightIn", "Height", true, false, OS.Types.Text, function () {
return "auto";
}, false), 
this.attr("_heightInDataFetchStatus", "_heightInDataFetchStatus", "_heightInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("TabsVerticalPosition", "tabsVerticalPositionIn", "TabsVerticalPosition", true, false, OS.Types.Text, function () {
return OutSystemsUIModel.staticEntities.direction.left;
}, false), 
this.attr("_tabsVerticalPositionInDataFetchStatus", "_tabsVerticalPositionInDataFetchStatus", "_tabsVerticalPositionInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("OptionalConfigs", "optionalConfigsIn", "OptionalConfigs", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.TabsOptionalConfigsRec());
}, false, OutSystemsUIModel.TabsOptionalConfigsRec), 
this.attr("_optionalConfigsInDataFetchStatus", "_optionalConfigsInDataFetchStatus", "_optionalConfigsInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("TabsOrientation" in inputs) {
this.variables.tabsOrientationIn = inputs.TabsOrientation;
if("_tabsOrientationInDataFetchStatus" in inputs) {
this.variables._tabsOrientationInDataFetchStatus = inputs._tabsOrientationInDataFetchStatus;
}

}

if("StartingTab" in inputs) {
this.variables.startingTabIn = inputs.StartingTab;
if("_startingTabInDataFetchStatus" in inputs) {
this.variables._startingTabInDataFetchStatus = inputs._startingTabInDataFetchStatus;
}

}

if("Height" in inputs) {
this.variables.heightIn = inputs.Height;
if("_heightInDataFetchStatus" in inputs) {
this.variables._heightInDataFetchStatus = inputs._heightInDataFetchStatus;
}

}

if("TabsVerticalPosition" in inputs) {
this.variables.tabsVerticalPositionIn = inputs.TabsVerticalPosition;
if("_tabsVerticalPositionInDataFetchStatus" in inputs) {
this.variables._tabsVerticalPositionInDataFetchStatus = inputs._tabsVerticalPositionInDataFetchStatus;
}

}

if("OptionalConfigs" in inputs) {
this.variables.optionalConfigsIn = inputs.OptionalConfigs;
if("_optionalConfigsInDataFetchStatus" in inputs) {
this.variables._optionalConfigsInDataFetchStatus = inputs._optionalConfigsInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Navigation.Tabs");
});
define("OutSystemsUI.Navigation.Tabs.mvc$view", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "OutSystemsUI.Navigation.Tabs.mvc$model", "OutSystemsUI.Navigation.Tabs.mvc$controller", "OutSystems/ReactWidgets/Main", "OutSystemsUI.model$Tabs_InternalConfigRec", "OutSystemsUI.model$TabsOptionalConfigsRec", "OutSystemsUI.controller$TabsRegisterCallback", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsCreate", "OutSystemsUI.controller$TabsInitialize", "OutSystemsUI.controller$TabsDestroy", "OutSystemsUI.controller$TabsChangeTextProperty", "OutSystemsUI.controller$TabsChangeBooleanProperty", "OutSystemsUI.controller$TabsChangeIntegerProperty"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, React, OSView, OutSystemsUI_Navigation_Tabs_mvc_model, OutSystemsUI_Navigation_Tabs_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Navigation.Tabs";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/OutSystemsUI.OutSystemsUI.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return OutSystemsUI_Navigation_Tabs_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return OutSystemsUI_Navigation_Tabs_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "osui-tabs",
name: model.variables.internalConfigsVar.uniqueIdAttr
},
tag: "section",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "osui-tabs__header"
},
tag: "header",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.header,
style: "display-contents ph",
_idProps: {
service: idService,
name: "Header"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "osui-tabs__header__indicator",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "osui-tabs__content"
},
tag: "section",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.content,
style: "display-contents ph",
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("OutSystemsUI.Navigation.Tabs.mvc$controller", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.languageResources", "OutSystemsUI.Navigation.Tabs.mvc$translationsResources", "OutSystemsUI.Navigation.Tabs.mvc$debugger", "OutSystemsUI.Navigation.Tabs.mvc$controller.RegisterCallback.GetCallbackHandlerJS", "OutSystemsUI.model$Tabs_InternalConfigRec", "OutSystemsUI.model$TabsOptionalConfigsRec", "OutSystemsUI.controller$TabsRegisterCallback", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsCreate", "OutSystemsUI.controller$TabsInitialize", "OutSystemsUI.controller$TabsDestroy", "OutSystemsUI.controller$TabsChangeTextProperty", "OutSystemsUI.controller$TabsChangeBooleanProperty", "OutSystemsUI.controller$TabsChangeIntegerProperty"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUILanguageResources, OutSystemsUI_Navigation_Tabs_mvc_TranslationsResources, OutSystemsUI_Navigation_Tabs_mvc_Debugger, OutSystemsUI_Navigation_Tabs_mvc_controller_RegisterCallback_GetCallbackHandlerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
initializedHandler$Action: function (tabsIdIn) {
tabsIdIn = (tabsIdIn === undefined) ? "" : tabsIdIn;
return controller.executeActionInsideJSNode(controller._initializedHandler$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tabsIdIn, OS.Types.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "InitializedHandler");
},
onTabChangeHandler$Action: function (tabsIdIn, currentActiveTabIn) {
tabsIdIn = (tabsIdIn === undefined) ? "" : tabsIdIn;
currentActiveTabIn = (currentActiveTabIn === undefined) ? 0 : currentActiveTabIn;
return controller.executeActionInsideJSNode(controller._onTabChangeHandler$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tabsIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(currentActiveTabIn, OS.Types.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnTabChangeHandler");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
Controller.prototype.translationResources = OutSystemsUI_Navigation_Tabs_mvc_TranslationsResources;
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._registerCallback$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RegisterCallback");
callContext = controller.callContext(callContext);
var getCallbackHandlerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getCallbackHandlerJSResult = getCallbackHandlerJSResult;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qmrpEahwaEaN9D1+JbOnXg:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.qmrpEahwaEaN9D1+JbOnXg:+d9AcIJYSEGdqxKjak728A", "OutSystemsUI", "RegisterCallback", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:26xp9J0NKkWzZZplviMAQA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rZ6EZn4Q5Uiit34kLDCmaw", callContext.id);
getCallbackHandlerJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_Navigation_Tabs_mvc_controller_RegisterCallback_GetCallbackHandlerJS, "GetCallbackHandler", "RegisterCallback", {
IntializedHandler: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object),
OnChange: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Tabs.RegisterCallback$getCallbackHandlerJSResult"))();
jsNodeResult.intializedHandlerOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IntializedHandler, OS.Types.Object);
jsNodeResult.onChangeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.OnChange, OS.Types.Object);
return jsNodeResult;
}, {
InitializedHandler: controller.clientActionProxies.initializedHandler$Action,
OnTabChangeHandler: controller.clientActionProxies.onTabChangeHandler$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:01E9Ft9J7UaRe9cI2s4PaA", callContext.id);
// Execute Action: TabsRegisterInitializedCallback
OutSystemsUIController.default.tabsRegisterCallback$Action(model.variables.internalConfigsVar.uniqueIdAttr, OutSystemsUIModel.staticEntities.registeredCallbackEvents.initialized, getCallbackHandlerJSResult.value.intializedHandlerOut, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:IFzy0Z_i4k2s7p+P9yAMhw", callContext.id);
// Execute Action: TabsRegisterOnChangeCallback
OutSystemsUIController.default.tabsRegisterCallback$Action(model.variables.internalConfigsVar.uniqueIdAttr, OutSystemsUIModel.staticEntities.registeredCallbackEvents.onChange, getCallbackHandlerJSResult.value.onChangeOut, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MDadDZdT6UWnOpnPDb090w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qmrpEahwaEaN9D1+JbOnXg", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Tabs.RegisterCallback$getCallbackHandlerJSResult", [{
name: "IntializedHandler",
attrName: "intializedHandlerOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}, {
name: "OnChange",
attrName: "onChangeOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._initializedHandler$Action = function (tabsIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InitializedHandler");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Tabs.InitializedHandler$vars"))());
vars.value.tabsIdInLocal = tabsIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:zgwoJ9z030qfus8UguA4VA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.zgwoJ9z030qfus8UguA4VA:xYcxlrJzZP6bQDdfNp0i+Q", "OutSystemsUI", "InitializedHandler", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:KBJrK_HPvEaTZBeYTfutDA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VpedY9pYrkmK2oQYZs_6wQ", callContext.id);
// Trigger Event: Initialized
return controller.initialized$Action(vars.value.tabsIdInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5D6A5rLThU2k3rf3Tm4jLQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:zgwoJ9z030qfus8UguA4VA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:zgwoJ9z030qfus8UguA4VA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Tabs.InitializedHandler$vars", [{
name: "TabsId",
attrName: "tabsIdInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var generateUniqueIdVar = new OS.DataTypes.VariableHolder();
var serialize_configsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.generateUniqueIdVar = generateUniqueIdVar;
varBag.serialize_configsVar = serialize_configsVar;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:b9rMQrNBYEaYb7NBUKTYXA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.b9rMQrNBYEaYb7NBUKTYXA:rJ4xlElZp3bSQsptpgB_yw", "OutSystemsUI", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tqgEqYZx6Ua9O073yjdypg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:zptoQ9wozUuOEO3TWvM44w", callContext.id);
// Execute Action: LogStart
OutSystemsUIController.default.logEvent$Action(OutSystemsUIModel.staticEntities.logType.general, "Going to create Tabs", callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iQlgSEM+8UKEwwy7rNx1fQ", callContext.id);
// Execute Action: GenerateUniqueId
generateUniqueIdVar.value = OutSystemsUIController.default.generateUniqueId$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);

// Set Initial Configs
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id);
// InternalConfigs.UniqueId = GenerateUniqueId.Unique_ID
model.variables.internalConfigsVar.uniqueIdAttr = generateUniqueIdVar.value.unique_IDOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// InternalConfigs.ExtendedClass = ExtendedClass
model.variables.internalConfigsVar.extendedClassAttr = model.variables.extendedClassIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// InternalConfigs.StartingTab = StartingTab
model.variables.internalConfigsVar.startingTabAttr = model.variables.startingTabIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// InternalConfigs.TabsOrientation = TabsOrientation
model.variables.internalConfigsVar.tabsOrientationAttr = model.variables.tabsOrientationIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// InternalConfigs.TabsVerticalPosition = TabsVerticalPosition
model.variables.internalConfigsVar.tabsVerticalPositionAttr = model.variables.tabsVerticalPositionIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// InternalConfigs.Height = Height
model.variables.internalConfigsVar.heightAttr = model.variables.heightIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// InternalConfigs.JustifyHeaders = OptionalConfigs.JustifyHeaders
model.variables.internalConfigsVar.justifyHeadersAttr = model.variables.optionalConfigsIn.justifyHeadersAttr;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bzWqUwxx5Ui5VFdwPdZ_tg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// InternalConfigs.ContentAutoHeight = OptionalConfigs.ContentAutoHeight
model.variables.internalConfigsVar.contentAutoHeightAttr = model.variables.optionalConfigsIn.contentAutoHeightAttr;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:_zBeuc5uyES6ZceYQKbSKw", callContext.id);
// JSON Serialize: Serialize_configs
serialize_configsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.internalConfigsVar, true, false);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:_8hH0nQ17Uq10XbmfiXa3A", callContext.id);
// Execute Action: TabsCreate
OutSystemsUIController.default.tabsCreate$Action(model.variables.internalConfigsVar.uniqueIdAttr, serialize_configsVar.value.jSONOut, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Gh5nSM2pQECkbGoY_B4zew", callContext.id);
// Execute Action: RegisterCallback
controller._registerCallback$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3XcpNsIZw0KhRRI7nG86IQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:b9rMQrNBYEaYb7NBUKTYXA", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:gbYUfQR1QUWuNvVAbt+O_g:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.gbYUfQR1QUWuNvVAbt+O_g:B8ymmaZZqU7KsROhsLX7IA", "OutSystemsUI", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yWzA0Qul80+js5t_xfXYVw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eS_G7abyoUmGrzd_57l5TA", callContext.id);
// Execute Action: TabsInitialize
OutSystemsUIController.default.tabsInitialize$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QeNXyL5I5k6TXpdGmJGDzQ", callContext.id);
// Execute Action: LogEnd
OutSystemsUIController.default.logEvent$Action(OutSystemsUIModel.staticEntities.logType.general, "Tabs created", callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hkrninNwgkaoMm0kKqGtoQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:gbYUfQR1QUWuNvVAbt+O_g", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:4kYDiTn2ZkKw1R2y6mgWMQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.4kYDiTn2ZkKw1R2y6mgWMQ:6dbFFTQgAWWp5XPS503VTA", "OutSystemsUI", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:asvZRjegh0KUzv22Ne1BwA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QjPbnCnPYU2EeWL80JdNwQ", callContext.id);
// Execute Action: TabsDestroy
OutSystemsUIController.default.tabsDestroy$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tsfYnNFHlkq8ZVHs+DLH_g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:4kYDiTn2ZkKw1R2y6mgWMQ", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:zBbU8MDmMkO_TkH4TRdnaQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.zBbU8MDmMkO_TkH4TRdnaQ:48rRQhnk+ksilKIEBtoDtA", "OutSystemsUI", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:uiK4ckXiRUSLtaR8ICMBww", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+iz+cAaUQ0q6tigZY7aqdw", callContext.id) && ((model.variables.startingTabIn) !== (model.variables.internalConfigsVar.startingTabAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:fm0HoYVb+0qA56uY7izDeQ", callContext.id);
// InternalConfigs.StartingTab = StartingTab
model.variables.internalConfigsVar.startingTabAttr = model.variables.startingTabIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BRiN8iqZZEqzddQlYIP+dA", callContext.id);
// Execute Action: Update_StartingTab
OutSystemsUIController.default.tabsChangeIntegerProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "StartingTab", model.variables.internalConfigsVar.startingTabAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:zyj6rh4Sh0CXnSRxIH2OVg", callContext.id) && ((model.variables.tabsOrientationIn) !== (model.variables.internalConfigsVar.tabsOrientationAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0zU6wNVMvE6x+1r9M6iLzA", callContext.id);
// InternalConfigs.TabsOrientation = TabsOrientation
model.variables.internalConfigsVar.tabsOrientationAttr = model.variables.tabsOrientationIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:OCdUWYzt2Um_RN5pQ3P+WA", callContext.id);
// Execute Action: Update_TabsOrientation
OutSystemsUIController.default.tabsChangeTextProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "TabsOrientation", model.variables.internalConfigsVar.tabsOrientationAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Zj_M6Tv_Xk+cIlhqCFziyw", callContext.id) && ((model.variables.tabsVerticalPositionIn) !== (model.variables.internalConfigsVar.tabsVerticalPositionAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:d8dYMnenTEmvfVtWIkTTMQ", callContext.id);
// InternalConfigs.TabsVerticalPosition = TabsVerticalPosition
model.variables.internalConfigsVar.tabsVerticalPositionAttr = model.variables.tabsVerticalPositionIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:fJIjQ_5_6kGuRtMIG13a0g", callContext.id);
// Execute Action: Update_TabsVerticalPosition
OutSystemsUIController.default.tabsChangeTextProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "TabsVerticalPosition", model.variables.internalConfigsVar.tabsVerticalPositionAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:w4vW1yxFr0268E0U2FHGfg", callContext.id) && ((model.variables.heightIn) !== (model.variables.internalConfigsVar.heightAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:B+XKqYqEF0yS5V9yAcwWAg", callContext.id);
// InternalConfigs.Height = Height
model.variables.internalConfigsVar.heightAttr = model.variables.heightIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UFSkOJdzUUOYmX8TzfW1zQ", callContext.id);
// Execute Action: Update_Height
OutSystemsUIController.default.tabsChangeTextProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "Height", model.variables.internalConfigsVar.heightAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BH26xp66p0Kbz5M0_ckZvw", callContext.id) && ((model.variables.optionalConfigsIn.contentAutoHeightAttr) !== (model.variables.internalConfigsVar.contentAutoHeightAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ThGBzYBNLU+iS+Lr50p9lw", callContext.id);
// InternalConfigs.ContentAutoHeight = OptionalConfigs.ContentAutoHeight
model.variables.internalConfigsVar.contentAutoHeightAttr = model.variables.optionalConfigsIn.contentAutoHeightAttr;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:A4+_W_prsUaaNi7unVItpA", callContext.id);
// Execute Action: Update_ContentAutoHeight
OutSystemsUIController.default.tabsChangeBooleanProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "ContentAutoHeight", model.variables.internalConfigsVar.contentAutoHeightAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yYVkh6M60UC63yGMq6J8Fw", callContext.id) && ((model.variables.optionalConfigsIn.justifyHeadersAttr) !== (model.variables.internalConfigsVar.justifyHeadersAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:aNKKL+ka+0GlW4q+8eaoxA", callContext.id);
// InternalConfigs.JustifyHeaders = OptionalConfigs.JustifyHeaders
model.variables.internalConfigsVar.justifyHeadersAttr = model.variables.optionalConfigsIn.justifyHeadersAttr;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:d8cv8tfap0yydnKb7ZAXoA", callContext.id);
// Execute Action: Update_JustifyHeaders
OutSystemsUIController.default.tabsChangeBooleanProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "JustifyHeaders", model.variables.internalConfigsVar.justifyHeadersAttr, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pfbmbZcatkibvPJUyRWLfg", callContext.id) && ((model.variables.extendedClassIn) !== (model.variables.internalConfigsVar.extendedClassAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0USqtCDFN0aOHXP8YbnGMg", callContext.id);
// InternalConfigs.ExtendedClass = ExtendedClass
model.variables.internalConfigsVar.extendedClassAttr = model.variables.extendedClassIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xMEAbpMZZEOeP5hZRUx6mg", callContext.id);
// Execute Action: Update_ExtendedClass
OutSystemsUIController.default.tabsChangeTextProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "ExtendedClass", model.variables.extendedClassIn, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ee3rbctrl06cLM76Y4ZOpw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ee3rbctrl06cLM76Y4ZOpw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:zBbU8MDmMkO_TkH4TRdnaQ", callContext.id);
}

};
Controller.prototype._onTabChangeHandler$Action = function (tabsIdIn, currentActiveTabIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnTabChangeHandler");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Tabs.OnTabChangeHandler$vars"))());
vars.value.tabsIdInLocal = tabsIdIn;
vars.value.currentActiveTabInLocal = currentActiveTabIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:RuRf9hoyQUGSWG69cEzEBg:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g/ClientActions.RuRf9hoyQUGSWG69cEzEBg:cpTXfUWuFQNd+K7b2SEbAA", "OutSystemsUI", "OnTabChangeHandler", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:XgsNjoKpL0Wp8F8RYbqP1Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5fAJeQw24ESAby7Uuuokow", callContext.id);
// InternalConfigs.StartingTab = CurrentActiveTab
model.variables.internalConfigsVar.startingTabAttr = vars.value.currentActiveTabInLocal;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tEf5Qr6_gEuEIfREGE0hLQ", callContext.id);
// Trigger Event: OnSelectValue
return controller.onTabChange$Action(vars.value.tabsIdInLocal, vars.value.currentActiveTabInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VwFO_IHl2keKPJ25q8QOUg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RuRf9hoyQUGSWG69cEzEBg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RuRf9hoyQUGSWG69cEzEBg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Tabs.OnTabChangeHandler$vars", [{
name: "TabsId",
attrName: "tabsIdInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "CurrentActiveTab",
attrName: "currentActiveTabInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);

Controller.prototype.registerCallback$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._registerCallback$Action, callContext);

};
Controller.prototype.initializedHandler$Action = function (tabsIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._initializedHandler$Action, callContext, tabsIdIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onTabChangeHandler$Action = function (tabsIdIn, currentActiveTabIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onTabChangeHandler$Action, callContext, tabsIdIn, currentActiveTabIn);

};
Controller.prototype.onTabChange$Action = function () {
return Promise.resolve();
};
Controller.prototype.initialized$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ:OIzPV+L_8TrNS0PFWhhjcg", "OutSystemsUI", "Navigation", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:WcwlMEQepkaw0OwaM5821g:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.WcwlMEQepkaw0OwaM5821g:K3I4wim803YDJjtXgZ5Q9Q", "OutSystemsUI", "Tabs", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:WcwlMEQepkaw0OwaM5821g", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Tabs On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Tabs On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Tabs On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Tabs On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, OutSystemsUILanguageResources);
});
define("OutSystemsUI.Navigation.Tabs.mvc$controller.RegisterCallback.GetCallbackHandlerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.IntializedHandler = $actions.InitializedHandler;
$parameters.OnChange = $actions.OnTabChangeHandler;
};
});

define("OutSystemsUI.Navigation.Tabs.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"rZ6EZn4Q5Uiit34kLDCmaw": {
getter: function (varBag, idService) {
return varBag.getCallbackHandlerJSResult.value;
}
},
"dYb_liyIE0+gyLBuEE7tRA": {
getter: function (varBag, idService) {
return varBag.vars.value.tabsIdInLocal;
},
dataType: OS.Types.Text
},
"iQlgSEM+8UKEwwy7rNx1fQ": {
getter: function (varBag, idService) {
return varBag.generateUniqueIdVar.value;
}
},
"_zBeuc5uyES6ZceYQKbSKw": {
getter: function (varBag, idService) {
return varBag.serialize_configsVar.value;
}
},
"qN00sYqvbE2YKQcNfZ5ieA": {
getter: function (varBag, idService) {
return varBag.vars.value.tabsIdInLocal;
},
dataType: OS.Types.Text
},
"LTekmbamnECC1gSOl3KnFQ": {
getter: function (varBag, idService) {
return varBag.vars.value.currentActiveTabInLocal;
},
dataType: OS.Types.Integer
},
"6SSD9zUqZ0CyYpOXiqic1A": {
getter: function (varBag, idService) {
return varBag.model.variables.internalConfigsVar;
}
},
"ukwgfilDv0iVGXK7mf+2AQ": {
getter: function (varBag, idService) {
return varBag.model.variables.tabsOrientationIn;
},
dataType: OS.Types.Text
},
"akmlo1KS702iiqiv8lfEww": {
getter: function (varBag, idService) {
return varBag.model.variables.startingTabIn;
},
dataType: OS.Types.Integer
},
"YCjB3tT1T06acDHUC0KYgw": {
getter: function (varBag, idService) {
return varBag.model.variables.heightIn;
},
dataType: OS.Types.Text
},
"FdhX4ICmGEaamXUqzO+ehQ": {
getter: function (varBag, idService) {
return varBag.model.variables.tabsVerticalPositionIn;
},
dataType: OS.Types.Text
},
"UCMUf61gtkqhswbFAbXx4g": {
getter: function (varBag, idService) {
return varBag.model.variables.optionalConfigsIn;
}
},
"m5XbZGjL8kyTfiK5yhTJ4Q": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"t4a8C9gX3EOdpfbsZj8+pA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Header"));
})(varBag.model, idService);
}
},
"CfklpA5MeUKjvtVPhPwtcQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TogglePreview"));
})(varBag.model, idService);
}
},
"HIUA1dJAokeLi7aQUkH9pA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
define("OutSystemsUI.Navigation.Tabs.mvc$translationsResources", ["exports"], function (exports) {
return {};
});
