define("Common_CW.PHICore_CW.Flag_Pill.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "OutSystemsUI.Content.Tag.mvc$model", "Common_CW.PHICore_CW.Count_Pill.mvc$model"], function (OutSystems, Common_CWModel, OutSystemsUI_Content_Tag_mvcModel, Common_CW_PHICore_CW_Count_Pill_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Flag", "flagIn", "Flag", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_flagInDataFetchStatus", "_flagInDataFetchStatus", "_flagInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Count", "countIn", "Count", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_countInDataFetchStatus", "_countInDataFetchStatus", "_countInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (OutSystemsUI_Content_Tag_mvcModel.hasValidationWidgets || Common_CW_PHICore_CW_Count_Pill_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Flag" in inputs) {
this.variables.flagIn = inputs.Flag;
if("_flagInDataFetchStatus" in inputs) {
this.variables._flagInDataFetchStatus = inputs._flagInDataFetchStatus;
}

}

if("Count" in inputs) {
this.variables.countIn = inputs.Count;
if("_countInDataFetchStatus" in inputs) {
this.variables._countInDataFetchStatus = inputs._countInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.Flag_Pill");
});
define("Common_CW.PHICore_CW.Flag_Pill.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.Flag_Pill.mvc$model", "Common_CW.PHICore_CW.Flag_Pill.mvc$controller", "Common_CW.clientVariables", "OutSystemsUI.Content.Tag.mvc$view", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.Count_Pill.mvc$view"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_Flag_Pill_mvc_model, Common_CW_PHICore_CW_Flag_Pill_mvc_controller, Common_CWClientVariables, OutSystemsUI_Content_Tag_mvc_view, OSWidgets, Common_CW_PHICore_CW_Count_Pill_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.Flag_Pill";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Content_Tag_mvc_view, Common_CW_PHICore_CW_Count_Pill_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Flag_Pill_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Flag_Pill_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(((model.variables.flagIn) !== ("")), false, this, function () {
return [React.createElement(OutSystemsUI_Content_Tag_mvc_view, {
inputs: {
ExtendedClass: "tag-hollow-vulnerable-person"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
tag: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
style: "white-space-nowrap",
value: model.variables.flagIn,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._flagInDataFetchStatus)
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._flagInDataFetchStatus), asPrimitiveValue(model.variables.flagIn)]
}), React.createElement(Common_CW_PHICore_CW_Count_Pill_mvc_view, {
inputs: {
Count: model.variables.countIn,
_countInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._countInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.Flag_Pill.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.Flag_Pill.mvc$debugger"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_Flag_Pill_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:6yg6zn+OXkqZnI8bupXAkg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.6yg6zn+OXkqZnI8bupXAkg:ocAaWwhgzP6mPgR7XDD8+g", "Common_CW", "Flag_Pill", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:6yg6zn+OXkqZnI8bupXAkg", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.Flag_Pill.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"2QWXzru8m06qhG++T2eQwg": {
getter: function (varBag, idService) {
return varBag.model.variables.flagIn;
},
dataType: OS.Types.Text
},
"qHU_AgZbX0SQRKgHfn15QA": {
getter: function (varBag, idService) {
return varBag.model.variables.countIn;
},
dataType: OS.Types.Integer
},
"2FWnDqPVe0CjGZs_gyh+Vw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tag"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
