define("SandBoxLogin.appDefinition", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
return {
environmentKey: "17076cf3-e014-41d0-ae7b-25d9803daca6",
environmentName: "Development",
applicationKey: "bc31e8ab-c8de-4ce0-a7a0-19a972ceb61e",
applicationName: "SandBox Login",
userProviderName: "Users",
debugEnabled: true,
homeModuleName: "SandBoxLogin",
homeModuleKey: "be608e72-db92-43fb-9c12-44767fa877dd",
homeModuleControllerName: "SandBoxLogin.controller",
homeModuleLanguageResourcesName: "SandBoxLogin.languageResources",
defaultTransition: "Fade",
errorPageConfig: {
showExceptionStack: false
},
isWeb: true,
personalArea: null,
showWatermark: false
};
});
