define("PHICore_Notification.model$ReadReceiptRec", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model"], function (exports, OutSystems, PHICore_NotificationModel) {
var OS = OutSystems.Internal;
var ReadReceiptRec = (function (_super) {
__extends(ReadReceiptRec, _super);
function ReadReceiptRec(defaults) {
_super.apply(this, arguments);
}
ReadReceiptRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("NotificationId", "notificationIdAttr", "NotificationId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UserId", "userIdAttr", "UserId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReadOn", "readOnAttr", "ReadOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReadReceiptRec.init();
return ReadReceiptRec;
})(OS.DataTypes.GenericRecord);
PHICore_NotificationModel.ReadReceiptRec = ReadReceiptRec;

});
define("PHICore_Notification.model$NotificationRec", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model"], function (exports, OutSystems, PHICore_NotificationModel) {
var OS = OutSystems.Internal;
var NotificationRec = (function (_super) {
__extends(NotificationRec, _super);
function NotificationRec(defaults) {
_super.apply(this, arguments);
}
NotificationRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiresOn", "expiresOnAttr", "ExpiresOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TeamId", "teamIdAttr", "TeamId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UserId", "userIdAttr", "UserId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsRequestAccess", "isRequestAccessAttr", "IsRequestAccess", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("UpdatedOn", "updatedOnAttr", "UpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("UpdatedBy", "updatedByAttr", "UpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
NotificationRec.init();
return NotificationRec;
})(OS.DataTypes.GenericRecord);
PHICore_NotificationModel.NotificationRec = NotificationRec;

});
define("PHICore_Notification.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var PHICore_NotificationModel = exports;
});
