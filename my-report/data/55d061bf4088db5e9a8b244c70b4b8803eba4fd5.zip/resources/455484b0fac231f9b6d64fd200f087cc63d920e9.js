define("InputMaskReactive.controller$UpdateMaskValue", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.controller", "InputMaskReactive.controller$UpdateMaskValue.JavaScript1JS"], function (exports, OutSystems, InputMaskReactiveModel, InputMaskReactiveController, InputMaskReactive_controller_UpdateMaskValue_JavaScript1JS) {
var OS = OutSystems.Internal;
InputMaskReactiveController.default.updateMaskValue$Action = function (maskIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InputMaskReactive.UpdateMaskValue$vars"))());
vars.value.maskInLocal = maskIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:6guM15baakm5B_E7Aj2_rg:/ClientActionFlows.6guM15baakm5B_E7Aj2_rg:2Dj1idjwxDKgzIUSHX2n+Q", "InputMaskReactive", "UpdateMaskValue", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:fkbNprbd9U2AAUafn7lUdQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:RBoL6yIHZ0u0lgcAhghZYQ", callContext.id);
controller.safeExecuteJSNode(InputMaskReactive_controller_UpdateMaskValue_JavaScript1JS, "JavaScript1", "UpdateMaskValue", {
Mask: OS.DataConversion.JSNodeParamConverter.to(vars.value.maskInLocal, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:0kLbYedjLE6OBbf2c0JC1Q", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:6guM15baakm5B_E7Aj2_rg", callContext.id);
}

};
var controller = InputMaskReactiveController.default;
InputMaskReactiveController.default.constructor.registerVariableGroupType("InputMaskReactive.UpdateMaskValue$vars", [{
name: "Mask",
attrName: "maskInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
InputMaskReactiveController.default.clientActionProxies.updateMaskValue$Action = function (maskIn) {
maskIn = (maskIn === undefined) ? null : maskIn;
return controller.executeActionInsideJSNode(InputMaskReactiveController.default.updateMaskValue$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(maskIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("InputMaskReactive.controller$UpdateMaskValue.JavaScript1JS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Mask.updateValue()
};
});

define("InputMaskReactive.controller", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.controller$debugger"], function (exports, OutSystems, InputMaskReactiveModel, InputMaskReactive_Controller_debugger) {
var OS = OutSystems.Internal;
var InputMaskReactiveController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return InputMaskReactiveController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
InputMaskReactiveController.default = new Controller(null, "InputMaskReactive");
});
define("InputMaskReactive.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Prua0+o_YUWnsy7w7Ip2fA": {
getter: function (varBag, idService) {
return varBag.vars.value.maskInLocal;
},
dataType: OS.Types.Object
},
"RBoL6yIHZ0u0lgcAhghZYQ": {
getter: function (varBag, idService) {
return varBag.javaScript1JSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
