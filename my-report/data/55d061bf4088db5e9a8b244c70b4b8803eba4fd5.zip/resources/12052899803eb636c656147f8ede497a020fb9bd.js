define("Stakeholder_CS.model$CalculationTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var CalculationTypeRec = (function (_super) {
__extends(CalculationTypeRec, _super);
function CalculationTypeRec(defaults) {
_super.apply(this, arguments);
}
CalculationTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CalculationTypeRec.init();
return CalculationTypeRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.CalculationTypeRec = CalculationTypeRec;

});
define("Stakeholder_CS.model$ReferenceDataBasicStrucRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var ReferenceDataBasicStrucRec = (function (_super) {
__extends(ReferenceDataBasicStrucRec, _super);
function ReferenceDataBasicStrucRec(defaults) {
_super.apply(this, arguments);
}
ReferenceDataBasicStrucRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataBasicStrucRec.init();
return ReferenceDataBasicStrucRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.ReferenceDataBasicStrucRec = ReferenceDataBasicStrucRec;

});
define("Stakeholder_CS.model$ReferenceDataBasicStrucList", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model", "Stakeholder_CS.model$ReferenceDataBasicStrucRec"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var ReferenceDataBasicStrucList = (function (_super) {
__extends(ReferenceDataBasicStrucList, _super);
function ReferenceDataBasicStrucList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataBasicStrucList.itemType = Stakeholder_CSModel.ReferenceDataBasicStrucRec;
return ReferenceDataBasicStrucList;
})(OS.DataTypes.GenericRecordList);
Stakeholder_CSModel.ReferenceDataBasicStrucList = ReferenceDataBasicStrucList;

});
define("Stakeholder_CS.model$ReferenceDataLocationRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model", "Stakeholder_CS.model$ReferenceDataBasicStrucList"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var ReferenceDataLocationRec = (function (_super) {
__extends(ReferenceDataLocationRec, _super);
function ReferenceDataLocationRec(defaults) {
_super.apply(this, arguments);
}
ReferenceDataLocationRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Site", "siteAttr", "Site", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Stakeholder_CSModel.ReferenceDataBasicStrucList());
}, true, Stakeholder_CSModel.ReferenceDataBasicStrucList)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataLocationRec.init();
return ReferenceDataLocationRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.ReferenceDataLocationRec = ReferenceDataLocationRec;

});
define("Stakeholder_CS.model$ReferenceDataWithPrioRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var ReferenceDataWithPrioRec = (function (_super) {
__extends(ReferenceDataWithPrioRec, _super);
function ReferenceDataWithPrioRec(defaults) {
_super.apply(this, arguments);
}
ReferenceDataWithPrioRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Priority", "priorityAttr", "Priority", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataWithPrioRec.init();
return ReferenceDataWithPrioRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.ReferenceDataWithPrioRec = ReferenceDataWithPrioRec;

});
define("Stakeholder_CS.model$EntityTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var EntityTypeRec = (function (_super) {
__extends(EntityTypeRec, _super);
function EntityTypeRec(defaults) {
_super.apply(this, arguments);
}
EntityTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityTypeRec.init();
return EntityTypeRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.EntityTypeRec = EntityTypeRec;

});
define("Stakeholder_CS.model$StakeholderTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "Stakeholder_CS.model"], function (exports, OutSystems, Stakeholder_CSModel) {
var OS = OutSystems.Internal;
var StakeholderTypeRec = (function (_super) {
__extends(StakeholderTypeRec, _super);
function StakeholderTypeRec(defaults) {
_super.apply(this, arguments);
}
StakeholderTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Code", "codeAttr", "Code", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("APICode", "aPICodeAttr", "APICode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StakeholderTypeRec.init();
return StakeholderTypeRec;
})(OS.DataTypes.GenericRecord);
Stakeholder_CSModel.StakeholderTypeRec = StakeholderTypeRec;

});
define("Stakeholder_CS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Stakeholder_CSModel = exports;
});
