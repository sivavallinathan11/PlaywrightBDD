define("PHICore_TH.model$SpaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SpaceRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SpaceRecord = (function (_super) {
__extends(SpaceRecord, _super);
function SpaceRecord(defaults) {
_super.apply(this, arguments);
}
SpaceRecord.attributesToDeclare = function () {
return [
this.attr("Space", "spaceAttr", "Space", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SpaceRec());
}, true, OutSystemsUIModel.SpaceRec)
].concat(_super.attributesToDeclare.call(this));
};
SpaceRecord.fromStructure = function (str) {
return new SpaceRecord(new SpaceRecord.RecordClass({
spaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpaceRecord._isAnonymousRecord = true;
SpaceRecord.UniqueId = "9589ecc0-6297-88c2-aca6-b47bcbae782c";
SpaceRecord.init();
return SpaceRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SpaceRecord = SpaceRecord;

});
define("PHICore_TH.model$SpaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SpaceRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SpaceRecordList = (function (_super) {
__extends(SpaceRecordList, _super);
function SpaceRecordList(defaults) {
_super.apply(this, arguments);
}
SpaceRecordList.itemType = PHICore_THModel.SpaceRecord;
return SpaceRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SpaceRecordList = SpaceRecordList;

});
define("PHICore_TH.model$LegendPositionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$LegendPositionRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendPositionRecord = (function (_super) {
__extends(LegendPositionRecord, _super);
function LegendPositionRecord(defaults) {
_super.apply(this, arguments);
}
LegendPositionRecord.attributesToDeclare = function () {
return [
this.attr("LegendPosition", "legendPositionAttr", "LegendPosition", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.LegendPositionRec());
}, true, OutSystemsChartsModel.LegendPositionRec)
].concat(_super.attributesToDeclare.call(this));
};
LegendPositionRecord.fromStructure = function (str) {
return new LegendPositionRecord(new LegendPositionRecord.RecordClass({
legendPositionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LegendPositionRecord._isAnonymousRecord = true;
LegendPositionRecord.UniqueId = "054139ee-1b4e-118a-0de0-bda9edde9b3e";
LegendPositionRecord.init();
return LegendPositionRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.LegendPositionRecord = LegendPositionRecord;

});
define("PHICore_TH.model$ShapeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ShapeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ShapeRecord = (function (_super) {
__extends(ShapeRecord, _super);
function ShapeRecord(defaults) {
_super.apply(this, arguments);
}
ShapeRecord.attributesToDeclare = function () {
return [
this.attr("Shape", "shapeAttr", "Shape", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ShapeRec());
}, true, OutSystemsUIModel.ShapeRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeRecord.fromStructure = function (str) {
return new ShapeRecord(new ShapeRecord.RecordClass({
shapeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeRecord._isAnonymousRecord = true;
ShapeRecord.UniqueId = "0a89eeb6-0fa1-f44b-6316-ca69b462007b";
ShapeRecord.init();
return ShapeRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.ShapeRecord = ShapeRecord;

});
define("PHICore_TH.model$ChartLegendOptionalConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$ChartLegendOptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendOptionalConfigsRecord = (function (_super) {
__extends(ChartLegendOptionalConfigsRecord, _super);
function ChartLegendOptionalConfigsRecord(defaults) {
_super.apply(this, arguments);
}
ChartLegendOptionalConfigsRecord.attributesToDeclare = function () {
return [
this.attr("ChartLegendOptionalConfigs", "chartLegendOptionalConfigsAttr", "ChartLegendOptionalConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.ChartLegendOptionalConfigsRec());
}, true, OutSystemsChartsModel.ChartLegendOptionalConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
ChartLegendOptionalConfigsRecord.fromStructure = function (str) {
return new ChartLegendOptionalConfigsRecord(new ChartLegendOptionalConfigsRecord.RecordClass({
chartLegendOptionalConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ChartLegendOptionalConfigsRecord._isAnonymousRecord = true;
ChartLegendOptionalConfigsRecord.UniqueId = "c38769c4-e3f5-3c55-790e-6a4b2c81b7ff";
ChartLegendOptionalConfigsRecord.init();
return ChartLegendOptionalConfigsRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.ChartLegendOptionalConfigsRecord = ChartLegendOptionalConfigsRecord;

});
define("PHICore_TH.model$ChartLegendOptionalConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$ChartLegendOptionalConfigsRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendOptionalConfigsRecordList = (function (_super) {
__extends(ChartLegendOptionalConfigsRecordList, _super);
function ChartLegendOptionalConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
ChartLegendOptionalConfigsRecordList.itemType = PHICore_THModel.ChartLegendOptionalConfigsRecord;
return ChartLegendOptionalConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ChartLegendOptionalConfigsRecordList = ChartLegendOptionalConfigsRecordList;

});
define("PHICore_TH.model$TenantRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$TenantRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var TenantRecord = (function (_super) {
__extends(TenantRecord, _super);
function TenantRecord(defaults) {
_super.apply(this, arguments);
}
TenantRecord.attributesToDeclare = function () {
return [
this.attr("Tenant", "tenantAttr", "Tenant", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.TenantRec());
}, true, ServiceCenterModel.TenantRec)
].concat(_super.attributesToDeclare.call(this));
};
TenantRecord.fromStructure = function (str) {
return new TenantRecord(new TenantRecord.RecordClass({
tenantAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TenantRecord._isAnonymousRecord = true;
TenantRecord.UniqueId = "40d0f5c5-ba63-0b10-5850-cead15ae2223";
TenantRecord.init();
return TenantRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.TenantRecord = TenantRecord;

});
define("PHICore_TH.model$TenantRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$TenantRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var TenantRecordList = (function (_super) {
__extends(TenantRecordList, _super);
function TenantRecordList(defaults) {
_super.apply(this, arguments);
}
TenantRecordList.itemType = PHICore_THModel.TenantRecord;
return TenantRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.TenantRecordList = TenantRecordList;

});
define("PHICore_TH.model$ChartLegendStylingRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$ChartLegendStylingRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendStylingRecord = (function (_super) {
__extends(ChartLegendStylingRecord, _super);
function ChartLegendStylingRecord(defaults) {
_super.apply(this, arguments);
}
ChartLegendStylingRecord.attributesToDeclare = function () {
return [
this.attr("ChartLegendStyling", "chartLegendStylingAttr", "ChartLegendStyling", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.ChartLegendStylingRec());
}, true, OutSystemsChartsModel.ChartLegendStylingRec)
].concat(_super.attributesToDeclare.call(this));
};
ChartLegendStylingRecord.fromStructure = function (str) {
return new ChartLegendStylingRecord(new ChartLegendStylingRecord.RecordClass({
chartLegendStylingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ChartLegendStylingRecord._isAnonymousRecord = true;
ChartLegendStylingRecord.UniqueId = "11e12158-254e-5be6-bde5-f4ba88bacb32";
ChartLegendStylingRecord.init();
return ChartLegendStylingRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.ChartLegendStylingRecord = ChartLegendStylingRecord;

});
define("PHICore_TH.model$SpaceList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SpaceRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SpaceList = (function (_super) {
__extends(SpaceList, _super);
function SpaceList(defaults) {
_super.apply(this, arguments);
}
SpaceList.itemType = OutSystemsUIModel.SpaceRec;
return SpaceList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SpaceList = SpaceList;

});
define("PHICore_TH.model$LegendPositionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$LegendPositionRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendPositionList = (function (_super) {
__extends(LegendPositionList, _super);
function LegendPositionList(defaults) {
_super.apply(this, arguments);
}
LegendPositionList.itemType = OutSystemsChartsModel.LegendPositionRec;
return LegendPositionList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.LegendPositionList = LegendPositionList;

});
define("PHICore_TH.model$SeriesStylingMarkerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingMarkerRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingMarkerRecord = (function (_super) {
__extends(SeriesStylingMarkerRecord, _super);
function SeriesStylingMarkerRecord(defaults) {
_super.apply(this, arguments);
}
SeriesStylingMarkerRecord.attributesToDeclare = function () {
return [
this.attr("SeriesStylingMarker", "seriesStylingMarkerAttr", "SeriesStylingMarker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesStylingMarkerRec());
}, true, OutSystemsChartsModel.SeriesStylingMarkerRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesStylingMarkerRecord.fromStructure = function (str) {
return new SeriesStylingMarkerRecord(new SeriesStylingMarkerRecord.RecordClass({
seriesStylingMarkerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SeriesStylingMarkerRecord._isAnonymousRecord = true;
SeriesStylingMarkerRecord.UniqueId = "23f04252-aed9-962b-8ebd-b251db000b96";
SeriesStylingMarkerRecord.init();
return SeriesStylingMarkerRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SeriesStylingMarkerRecord = SeriesStylingMarkerRecord;

});
define("PHICore_TH.model$LegendLayoutRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$LegendLayoutRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendLayoutRecord = (function (_super) {
__extends(LegendLayoutRecord, _super);
function LegendLayoutRecord(defaults) {
_super.apply(this, arguments);
}
LegendLayoutRecord.attributesToDeclare = function () {
return [
this.attr("LegendLayout", "legendLayoutAttr", "LegendLayout", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.LegendLayoutRec());
}, true, OutSystemsChartsModel.LegendLayoutRec)
].concat(_super.attributesToDeclare.call(this));
};
LegendLayoutRecord.fromStructure = function (str) {
return new LegendLayoutRecord(new LegendLayoutRecord.RecordClass({
legendLayoutAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LegendLayoutRecord._isAnonymousRecord = true;
LegendLayoutRecord.UniqueId = "250abb78-0612-7d6d-6c56-5bcd6bd8fd6f";
LegendLayoutRecord.init();
return LegendLayoutRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.LegendLayoutRecord = LegendLayoutRecord;

});
define("PHICore_TH.model$SizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SizeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SizeRecord = (function (_super) {
__extends(SizeRecord, _super);
function SizeRecord(defaults) {
_super.apply(this, arguments);
}
SizeRecord.attributesToDeclare = function () {
return [
this.attr("Size", "sizeAttr", "Size", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SizeRec());
}, true, OutSystemsUIModel.SizeRec)
].concat(_super.attributesToDeclare.call(this));
};
SizeRecord.fromStructure = function (str) {
return new SizeRecord(new SizeRecord.RecordClass({
sizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SizeRecord._isAnonymousRecord = true;
SizeRecord.UniqueId = "ca426fec-0751-e5b6-dcf0-15e9fdc2120e";
SizeRecord.init();
return SizeRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SizeRecord = SizeRecord;

});
define("PHICore_TH.model$SizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SizeRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SizeRecordList = (function (_super) {
__extends(SizeRecordList, _super);
function SizeRecordList(defaults) {
_super.apply(this, arguments);
}
SizeRecordList.itemType = PHICore_THModel.SizeRecord;
return SizeRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SizeRecordList = SizeRecordList;

});
define("PHICore_TH.model$ErrorMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecord = (function (_super) {
__extends(ErrorMessageRecord, _super);
function ErrorMessageRecord(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecord.attributesToDeclare = function () {
return [
this.attr("ErrorMessage", "errorMessageAttr", "ErrorMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ErrorMessageRec());
}, true, OutSystemsUIModel.ErrorMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorMessageRecord.fromStructure = function (str) {
return new ErrorMessageRecord(new ErrorMessageRecord.RecordClass({
errorMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorMessageRecord._isAnonymousRecord = true;
ErrorMessageRecord.UniqueId = "27b5a164-e828-de9b-9068-6831c7908b4a";
ErrorMessageRecord.init();
return ErrorMessageRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.ErrorMessageRecord = ErrorMessageRecord;

});
define("PHICore_TH.model$LegendLayoutRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$LegendLayoutRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendLayoutRecordList = (function (_super) {
__extends(LegendLayoutRecordList, _super);
function LegendLayoutRecordList(defaults) {
_super.apply(this, arguments);
}
LegendLayoutRecordList.itemType = PHICore_THModel.LegendLayoutRecord;
return LegendLayoutRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.LegendLayoutRecordList = LegendLayoutRecordList;

});
define("PHICore_TH.model$SeriesStylingOptionalConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingOptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingOptionalConfigsRecord = (function (_super) {
__extends(SeriesStylingOptionalConfigsRecord, _super);
function SeriesStylingOptionalConfigsRecord(defaults) {
_super.apply(this, arguments);
}
SeriesStylingOptionalConfigsRecord.attributesToDeclare = function () {
return [
this.attr("SeriesStylingOptionalConfigs", "seriesStylingOptionalConfigsAttr", "SeriesStylingOptionalConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesStylingOptionalConfigsRec());
}, true, OutSystemsChartsModel.SeriesStylingOptionalConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesStylingOptionalConfigsRecord.fromStructure = function (str) {
return new SeriesStylingOptionalConfigsRecord(new SeriesStylingOptionalConfigsRecord.RecordClass({
seriesStylingOptionalConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SeriesStylingOptionalConfigsRecord._isAnonymousRecord = true;
SeriesStylingOptionalConfigsRecord.UniqueId = "34d5d5ab-5565-b38a-57ae-5f2563a8c466";
SeriesStylingOptionalConfigsRecord.init();
return SeriesStylingOptionalConfigsRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SeriesStylingOptionalConfigsRecord = SeriesStylingOptionalConfigsRecord;

});
define("PHICore_TH.model$ErrorMessageList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ErrorMessageList = (function (_super) {
__extends(ErrorMessageList, _super);
function ErrorMessageList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageList.itemType = OutSystemsUIModel.ErrorMessageRec;
return ErrorMessageList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ErrorMessageList = ErrorMessageList;

});
define("PHICore_TH.model$SeriesStylingList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingList = (function (_super) {
__extends(SeriesStylingList, _super);
function SeriesStylingList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingList.itemType = OutSystemsChartsModel.SeriesStylingRec;
return SeriesStylingList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingList = SeriesStylingList;

});
define("PHICore_TH.model$SeriesTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesTypeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesTypeRecord = (function (_super) {
__extends(SeriesTypeRecord, _super);
function SeriesTypeRecord(defaults) {
_super.apply(this, arguments);
}
SeriesTypeRecord.attributesToDeclare = function () {
return [
this.attr("SeriesType", "seriesTypeAttr", "SeriesType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesTypeRec());
}, true, OutSystemsChartsModel.SeriesTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesTypeRecord.fromStructure = function (str) {
return new SeriesTypeRecord(new SeriesTypeRecord.RecordClass({
seriesTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SeriesTypeRecord._isAnonymousRecord = true;
SeriesTypeRecord.UniqueId = "8bfcc1d3-81d1-0495-3fbf-01fd54a56e45";
SeriesTypeRecord.init();
return SeriesTypeRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SeriesTypeRecord = SeriesTypeRecord;

});
define("PHICore_TH.model$SeriesTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SeriesTypeRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesTypeRecordList = (function (_super) {
__extends(SeriesTypeRecordList, _super);
function SeriesTypeRecordList(defaults) {
_super.apply(this, arguments);
}
SeriesTypeRecordList.itemType = PHICore_THModel.SeriesTypeRecord;
return SeriesTypeRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesTypeRecordList = SeriesTypeRecordList;

});
define("PHICore_TH.model$ShapeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ShapeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ShapeList = (function (_super) {
__extends(ShapeList, _super);
function ShapeList(defaults) {
_super.apply(this, arguments);
}
ShapeList.itemType = OutSystemsUIModel.ShapeRec;
return ShapeList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ShapeList = ShapeList;

});
define("PHICore_TH.model$SeriesStylingRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingRecord = (function (_super) {
__extends(SeriesStylingRecord, _super);
function SeriesStylingRecord(defaults) {
_super.apply(this, arguments);
}
SeriesStylingRecord.attributesToDeclare = function () {
return [
this.attr("SeriesStyling", "seriesStylingAttr", "SeriesStyling", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesStylingRec());
}, true, OutSystemsChartsModel.SeriesStylingRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesStylingRecord.fromStructure = function (str) {
return new SeriesStylingRecord(new SeriesStylingRecord.RecordClass({
seriesStylingAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SeriesStylingRecord._isAnonymousRecord = true;
SeriesStylingRecord.UniqueId = "b433f1b3-ae72-f9da-85b2-0eb8b0abb0e8";
SeriesStylingRecord.init();
return SeriesStylingRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SeriesStylingRecord = SeriesStylingRecord;

});
define("PHICore_TH.model$SeriesStylingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SeriesStylingRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingRecordList = (function (_super) {
__extends(SeriesStylingRecordList, _super);
function SeriesStylingRecordList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingRecordList.itemType = PHICore_THModel.SeriesStylingRecord;
return SeriesStylingRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingRecordList = SeriesStylingRecordList;

});
define("PHICore_TH.model$LegendLayoutList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$LegendLayoutRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendLayoutList = (function (_super) {
__extends(LegendLayoutList, _super);
function LegendLayoutList(defaults) {
_super.apply(this, arguments);
}
LegendLayoutList.itemType = OutSystemsChartsModel.LegendLayoutRec;
return LegendLayoutList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.LegendLayoutList = LegendLayoutList;

});
define("PHICore_TH.model$EspaceList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$EspaceRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var EspaceList = (function (_super) {
__extends(EspaceList, _super);
function EspaceList(defaults) {
_super.apply(this, arguments);
}
EspaceList.itemType = ServiceCenterModel.EspaceRec;
return EspaceList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.EspaceList = EspaceList;

});
define("PHICore_TH.model$ShapeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$ShapeRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var ShapeRecordList = (function (_super) {
__extends(ShapeRecordList, _super);
function ShapeRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeRecordList.itemType = PHICore_THModel.ShapeRecord;
return ShapeRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ShapeRecordList = ShapeRecordList;

});
define("PHICore_TH.model$DataPointRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$DataPointRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var DataPointRecord = (function (_super) {
__extends(DataPointRecord, _super);
function DataPointRecord(defaults) {
_super.apply(this, arguments);
}
DataPointRecord.attributesToDeclare = function () {
return [
this.attr("DataPoint", "dataPointAttr", "DataPoint", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataPointRec());
}, true, OutSystemsChartsModel.DataPointRec)
].concat(_super.attributesToDeclare.call(this));
};
DataPointRecord.fromStructure = function (str) {
return new DataPointRecord(new DataPointRecord.RecordClass({
dataPointAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DataPointRecord._isAnonymousRecord = true;
DataPointRecord.UniqueId = "87ab3d0b-8093-8e4e-95dc-b616c8a9232e";
DataPointRecord.init();
return DataPointRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.DataPointRecord = DataPointRecord;

});
define("PHICore_TH.model$DataPointRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DataPointRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DataPointRecordList = (function (_super) {
__extends(DataPointRecordList, _super);
function DataPointRecordList(defaults) {
_super.apply(this, arguments);
}
DataPointRecordList.itemType = PHICore_THModel.DataPointRecord;
return DataPointRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DataPointRecordList = DataPointRecordList;

});
define("PHICore_TH.model$DummyPointListDattaRec", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyPointListDattaRec = (function (_super) {
__extends(DummyPointListDattaRec, _super);
function DummyPointListDattaRec(defaults) {
_super.apply(this, arguments);
}
DummyPointListDattaRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SeriesName", "seriesNameAttr", "SeriesName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ToolTip", "toolTipAttr", "ToolTip", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DummyPointListDattaRec.init();
return DummyPointListDattaRec;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.DummyPointListDattaRec = DummyPointListDattaRec;

});
define("PHICore_TH.model$DummyPointListDattaRecord", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyPointListDattaRec"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyPointListDattaRecord = (function (_super) {
__extends(DummyPointListDattaRecord, _super);
function DummyPointListDattaRecord(defaults) {
_super.apply(this, arguments);
}
DummyPointListDattaRecord.attributesToDeclare = function () {
return [
this.attr("DummyPointListDatta", "dummyPointListDattaAttr", "DummyPointListDatta", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_THModel.DummyPointListDattaRec());
}, true, PHICore_THModel.DummyPointListDattaRec)
].concat(_super.attributesToDeclare.call(this));
};
DummyPointListDattaRecord.fromStructure = function (str) {
return new DummyPointListDattaRecord(new DummyPointListDattaRecord.RecordClass({
dummyPointListDattaAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DummyPointListDattaRecord._isAnonymousRecord = true;
DummyPointListDattaRecord.UniqueId = "7095090c-6509-619e-1d4a-d6062922afd0";
DummyPointListDattaRecord.init();
return DummyPointListDattaRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.DummyPointListDattaRecord = DummyPointListDattaRecord;

});
define("PHICore_TH.model$EspaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$EspaceRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var EspaceRecord = (function (_super) {
__extends(EspaceRecord, _super);
function EspaceRecord(defaults) {
_super.apply(this, arguments);
}
EspaceRecord.attributesToDeclare = function () {
return [
this.attr("Espace", "espaceAttr", "Espace", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, true, ServiceCenterModel.EspaceRec)
].concat(_super.attributesToDeclare.call(this));
};
EspaceRecord.fromStructure = function (str) {
return new EspaceRecord(new EspaceRecord.RecordClass({
espaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EspaceRecord._isAnonymousRecord = true;
EspaceRecord.UniqueId = "a702e171-772a-9b89-c17e-2544ab6d1d29";
EspaceRecord.init();
return EspaceRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.EspaceRecord = EspaceRecord;

});
define("PHICore_TH.model$EspaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$EspaceRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var EspaceRecordList = (function (_super) {
__extends(EspaceRecordList, _super);
function EspaceRecordList(defaults) {
_super.apply(this, arguments);
}
EspaceRecordList.itemType = PHICore_THModel.EspaceRecord;
return EspaceRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.EspaceRecordList = EspaceRecordList;

});
define("PHICore_TH.model$OptionalConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$OptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var OptionalConfigsRecord = (function (_super) {
__extends(OptionalConfigsRecord, _super);
function OptionalConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalConfigs", "optionalConfigsAttr", "OptionalConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.OptionalConfigsRec());
}, true, OutSystemsChartsModel.OptionalConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalConfigsRecord.fromStructure = function (str) {
return new OptionalConfigsRecord(new OptionalConfigsRecord.RecordClass({
optionalConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalConfigsRecord._isAnonymousRecord = true;
OptionalConfigsRecord.UniqueId = "83bc3ae4-c5fe-c64b-fa52-8e6320384107";
OptionalConfigsRecord.init();
return OptionalConfigsRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.OptionalConfigsRecord = OptionalConfigsRecord;

});
define("PHICore_TH.model$OptionalConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$OptionalConfigsRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var OptionalConfigsRecordList = (function (_super) {
__extends(OptionalConfigsRecordList, _super);
function OptionalConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalConfigsRecordList.itemType = PHICore_THModel.OptionalConfigsRecord;
return OptionalConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.OptionalConfigsRecordList = OptionalConfigsRecordList;

});
define("PHICore_TH.model$DataPointList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$DataPointRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var DataPointList = (function (_super) {
__extends(DataPointList, _super);
function DataPointList(defaults) {
_super.apply(this, arguments);
}
DataPointList.itemType = OutSystemsChartsModel.DataPointRec;
return DataPointList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DataPointList = DataPointList;

});
define("PHICore_TH.model$UserRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$UserRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var UserRecord = (function (_super) {
__extends(UserRecord, _super);
function UserRecord(defaults) {
_super.apply(this, arguments);
}
UserRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec)
].concat(_super.attributesToDeclare.call(this));
};
UserRecord.fromStructure = function (str) {
return new UserRecord(new UserRecord.RecordClass({
userAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UserRecord._isAnonymousRecord = true;
UserRecord.UniqueId = "ced01335-8a82-a813-f1d9-a5108f17ce79";
UserRecord.init();
return UserRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.UserRecord = UserRecord;

});
define("PHICore_TH.model$UserRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$UserRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var UserRecordList = (function (_super) {
__extends(UserRecordList, _super);
function UserRecordList(defaults) {
_super.apply(this, arguments);
}
UserRecordList.itemType = PHICore_THModel.UserRecord;
return UserRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.UserRecordList = UserRecordList;

});
define("PHICore_TH.model$DummyMonthsRec", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyMonthsRec = (function (_super) {
__extends(DummyMonthsRec, _super);
function DummyMonthsRec(defaults) {
_super.apply(this, arguments);
}
DummyMonthsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DummyMonthsRec.init();
return DummyMonthsRec;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.DummyMonthsRec = DummyMonthsRec;

});
define("PHICore_TH.model$DummyMonthsRecord", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyMonthsRec"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyMonthsRecord = (function (_super) {
__extends(DummyMonthsRecord, _super);
function DummyMonthsRecord(defaults) {
_super.apply(this, arguments);
}
DummyMonthsRecord.attributesToDeclare = function () {
return [
this.attr("DummyMonths", "dummyMonthsAttr", "DummyMonths", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_THModel.DummyMonthsRec());
}, true, PHICore_THModel.DummyMonthsRec)
].concat(_super.attributesToDeclare.call(this));
};
DummyMonthsRecord.fromStructure = function (str) {
return new DummyMonthsRecord(new DummyMonthsRecord.RecordClass({
dummyMonthsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DummyMonthsRecord._isAnonymousRecord = true;
DummyMonthsRecord.UniqueId = "d123536d-fca3-940d-fe44-d3c94be28029";
DummyMonthsRecord.init();
return DummyMonthsRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.DummyMonthsRecord = DummyMonthsRecord;

});
define("PHICore_TH.model$DummyMonthsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyMonthsRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyMonthsRecordList = (function (_super) {
__extends(DummyMonthsRecordList, _super);
function DummyMonthsRecordList(defaults) {
_super.apply(this, arguments);
}
DummyMonthsRecordList.itemType = PHICore_THModel.DummyMonthsRecord;
return DummyMonthsRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DummyMonthsRecordList = DummyMonthsRecordList;

});
define("PHICore_TH.model$ColorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ColorRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ColorRecord = (function (_super) {
__extends(ColorRecord, _super);
function ColorRecord(defaults) {
_super.apply(this, arguments);
}
ColorRecord.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColorRec());
}, true, OutSystemsUIModel.ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
ColorRecord.fromStructure = function (str) {
return new ColorRecord(new ColorRecord.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRecord._isAnonymousRecord = true;
ColorRecord.UniqueId = "87351e3b-0fa2-ca59-cf6c-6749c6405006";
ColorRecord.init();
return ColorRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.ColorRecord = ColorRecord;

});
define("PHICore_TH.model$ChartLegendStylingList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$ChartLegendStylingRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendStylingList = (function (_super) {
__extends(ChartLegendStylingList, _super);
function ChartLegendStylingList(defaults) {
_super.apply(this, arguments);
}
ChartLegendStylingList.itemType = OutSystemsChartsModel.ChartLegendStylingRec;
return ChartLegendStylingList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ChartLegendStylingList = ChartLegendStylingList;

});
define("PHICore_TH.model$SeriesTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesTypeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesTypeList = (function (_super) {
__extends(SeriesTypeList, _super);
function SeriesTypeList(defaults) {
_super.apply(this, arguments);
}
SeriesTypeList.itemType = OutSystemsChartsModel.SeriesTypeRec;
return SeriesTypeList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesTypeList = SeriesTypeList;

});
define("PHICore_TH.model$SizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SizeRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SizeList = (function (_super) {
__extends(SizeList, _super);
function SizeList(defaults) {
_super.apply(this, arguments);
}
SizeList.itemType = OutSystemsUIModel.SizeRec;
return SizeList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SizeList = SizeList;

});
define("PHICore_TH.model$ChartLegendOptionalConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$ChartLegendOptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendOptionalConfigsList = (function (_super) {
__extends(ChartLegendOptionalConfigsList, _super);
function ChartLegendOptionalConfigsList(defaults) {
_super.apply(this, arguments);
}
ChartLegendOptionalConfigsList.itemType = OutSystemsChartsModel.ChartLegendOptionalConfigsRec;
return ChartLegendOptionalConfigsList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ChartLegendOptionalConfigsList = ChartLegendOptionalConfigsList;

});
define("PHICore_TH.model$SeriesStylingMarkerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SeriesStylingMarkerRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingMarkerRecordList = (function (_super) {
__extends(SeriesStylingMarkerRecordList, _super);
function SeriesStylingMarkerRecordList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingMarkerRecordList.itemType = PHICore_THModel.SeriesStylingMarkerRecord;
return SeriesStylingMarkerRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingMarkerRecordList = SeriesStylingMarkerRecordList;

});
define("PHICore_TH.model$ChartLegendStylingRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$ChartLegendStylingRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var ChartLegendStylingRecordList = (function (_super) {
__extends(ChartLegendStylingRecordList, _super);
function ChartLegendStylingRecordList(defaults) {
_super.apply(this, arguments);
}
ChartLegendStylingRecordList.itemType = PHICore_THModel.ChartLegendStylingRecord;
return ChartLegendStylingRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ChartLegendStylingRecordList = ChartLegendStylingRecordList;

});
define("PHICore_TH.model$ColorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$ColorRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var ColorRecordList = (function (_super) {
__extends(ColorRecordList, _super);
function ColorRecordList(defaults) {
_super.apply(this, arguments);
}
ColorRecordList.itemType = PHICore_THModel.ColorRecord;
return ColorRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ColorRecordList = ColorRecordList;

});
define("PHICore_TH.model$DummyPointListDattaRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyPointListDattaRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyPointListDattaRecordList = (function (_super) {
__extends(DummyPointListDattaRecordList, _super);
function DummyPointListDattaRecordList(defaults) {
_super.apply(this, arguments);
}
DummyPointListDattaRecordList.itemType = PHICore_THModel.DummyPointListDattaRecord;
return DummyPointListDattaRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DummyPointListDattaRecordList = DummyPointListDattaRecordList;

});
define("PHICore_TH.model$SeriesStylingOptionalConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingOptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingOptionalConfigsList = (function (_super) {
__extends(SeriesStylingOptionalConfigsList, _super);
function SeriesStylingOptionalConfigsList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingOptionalConfigsList.itemType = OutSystemsChartsModel.SeriesStylingOptionalConfigsRec;
return SeriesStylingOptionalConfigsList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingOptionalConfigsList = SeriesStylingOptionalConfigsList;

});
define("PHICore_TH.model$ErrorMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$ErrorMessageRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecordList = (function (_super) {
__extends(ErrorMessageRecordList, _super);
function ErrorMessageRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecordList.itemType = PHICore_THModel.ErrorMessageRecord;
return ErrorMessageRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ErrorMessageRecordList = ErrorMessageRecordList;

});
define("PHICore_TH.model$SeriesStylingOptionalConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SeriesStylingOptionalConfigsRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingOptionalConfigsRecordList = (function (_super) {
__extends(SeriesStylingOptionalConfigsRecordList, _super);
function SeriesStylingOptionalConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingOptionalConfigsRecordList.itemType = PHICore_THModel.SeriesStylingOptionalConfigsRecord;
return SeriesStylingOptionalConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingOptionalConfigsRecordList = SeriesStylingOptionalConfigsRecordList;

});
define("PHICore_TH.model$LegendPositionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$LegendPositionRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var LegendPositionRecordList = (function (_super) {
__extends(LegendPositionRecordList, _super);
function LegendPositionRecordList(defaults) {
_super.apply(this, arguments);
}
LegendPositionRecordList.itemType = PHICore_THModel.LegendPositionRecord;
return LegendPositionRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.LegendPositionRecordList = LegendPositionRecordList;

});
define("PHICore_TH.model$DummyPointListDattaList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyPointListDattaRec"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyPointListDattaList = (function (_super) {
__extends(DummyPointListDattaList, _super);
function DummyPointListDattaList(defaults) {
_super.apply(this, arguments);
}
DummyPointListDattaList.itemType = PHICore_THModel.DummyPointListDattaRec;
return DummyPointListDattaList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DummyPointListDattaList = DummyPointListDattaList;

});
define("PHICore_TH.model$SideMenuBehaviorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SideMenuBehaviorRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorList = (function (_super) {
__extends(SideMenuBehaviorList, _super);
function SideMenuBehaviorList(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorList.itemType = OutSystemsUIModel.SideMenuBehaviorRec;
return SideMenuBehaviorList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SideMenuBehaviorList = SideMenuBehaviorList;

});
define("PHICore_TH.model$ColorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$ColorRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var ColorList = (function (_super) {
__extends(ColorList, _super);
function ColorList(defaults) {
_super.apply(this, arguments);
}
ColorList.itemType = OutSystemsUIModel.ColorRec;
return ColorList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.ColorList = ColorList;

});
define("PHICore_TH.model$DummyMonthsList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$DummyMonthsRec"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var DummyMonthsList = (function (_super) {
__extends(DummyMonthsList, _super);
function DummyMonthsList(defaults) {
_super.apply(this, arguments);
}
DummyMonthsList.itemType = PHICore_THModel.DummyMonthsRec;
return DummyMonthsList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.DummyMonthsList = DummyMonthsList;

});
define("PHICore_TH.model$TenantList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$TenantRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var TenantList = (function (_super) {
__extends(TenantList, _super);
function TenantList(defaults) {
_super.apply(this, arguments);
}
TenantList.itemType = ServiceCenterModel.TenantRec;
return TenantList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.TenantList = TenantList;

});
define("PHICore_TH.model$OptionalConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$OptionalConfigsRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var OptionalConfigsList = (function (_super) {
__extends(OptionalConfigsList, _super);
function OptionalConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalConfigsList.itemType = OutSystemsChartsModel.OptionalConfigsRec;
return OptionalConfigsList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.OptionalConfigsList = OptionalConfigsList;

});
define("PHICore_TH.model$SideMenuBehaviorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "PHICore_TH.model", "OutSystemsUI.model$SideMenuBehaviorRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorRecord = (function (_super) {
__extends(SideMenuBehaviorRecord, _super);
function SideMenuBehaviorRecord(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorRecord.attributesToDeclare = function () {
return [
this.attr("SideMenuBehavior", "sideMenuBehaviorAttr", "SideMenuBehavior", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SideMenuBehaviorRec());
}, true, OutSystemsUIModel.SideMenuBehaviorRec)
].concat(_super.attributesToDeclare.call(this));
};
SideMenuBehaviorRecord.fromStructure = function (str) {
return new SideMenuBehaviorRecord(new SideMenuBehaviorRecord.RecordClass({
sideMenuBehaviorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SideMenuBehaviorRecord._isAnonymousRecord = true;
SideMenuBehaviorRecord.UniqueId = "e3607d6b-9254-5e57-93fb-eb99fc16b7e7";
SideMenuBehaviorRecord.init();
return SideMenuBehaviorRecord;
})(OS.DataTypes.GenericRecord);
PHICore_THModel.SideMenuBehaviorRecord = SideMenuBehaviorRecord;

});
define("PHICore_TH.model$SideMenuBehaviorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.model$SideMenuBehaviorRecord"], function (exports, OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorRecordList = (function (_super) {
__extends(SideMenuBehaviorRecordList, _super);
function SideMenuBehaviorRecordList(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorRecordList.itemType = PHICore_THModel.SideMenuBehaviorRecord;
return SideMenuBehaviorRecordList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SideMenuBehaviorRecordList = SideMenuBehaviorRecordList;

});
define("PHICore_TH.model$UserList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "PHICore_TH.model", "ServiceCenter.model$UserRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var UserList = (function (_super) {
__extends(UserList, _super);
function UserList(defaults) {
_super.apply(this, arguments);
}
UserList.itemType = ServiceCenterModel.UserRec;
return UserList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.UserList = UserList;

});
define("PHICore_TH.model$SeriesStylingMarkerList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "PHICore_TH.model", "OutSystemsCharts.model$SeriesStylingMarkerRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsCharts"], function (exports, OutSystems, OutSystemsChartsModel, PHICore_THModel) {
var OS = OutSystems.Internal;
var SeriesStylingMarkerList = (function (_super) {
__extends(SeriesStylingMarkerList, _super);
function SeriesStylingMarkerList(defaults) {
_super.apply(this, arguments);
}
SeriesStylingMarkerList.itemType = OutSystemsChartsModel.SeriesStylingMarkerRec;
return SeriesStylingMarkerList;
})(OS.DataTypes.GenericRecordList);
PHICore_THModel.SeriesStylingMarkerList = SeriesStylingMarkerList;

});
define("PHICore_TH.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var PHICore_THModel = exports;
Object.defineProperty(PHICore_THModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["a5d0b7c6-1960-4c91-b1b7-edac840eb0e0"];
}
});

PHICore_THModel.staticEntities = {};
PHICore_THModel.staticEntities.dummyMonths = {};
var getDummyMonthsRecord = function (record) {
return PHICore_THModel.module.staticEntities["d8853ca0-b4b5-46f9-a270-8fbda3c020d3"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.dummyMonths, "record1", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getDummyMonthsRecord("73eccb3a-1783-4450-8d74-dbffd1aedb32"));
}
});

Object.defineProperty(PHICore_THModel.staticEntities.dummyMonths, "record2", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getDummyMonthsRecord("8190f03a-a147-47cf-8955-48460a937551"));
}
});

Object.defineProperty(PHICore_THModel.staticEntities.dummyMonths, "record3", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getDummyMonthsRecord("c43b2954-7e26-4659-a7c4-330123b0301e"));
}
});

PHICore_THModel.staticEntities.seriesType = {};
var getSeriesTypeRecord = function (record) {
return OS.ApplicationInfo.getModules()["38b70e23-50fc-4710-80cf-3682a9dc998a"].staticEntities["a9c663e8-6354-4f02-931c-636fc58b7d51"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "lineSpline", {
get: function () {
return getSeriesTypeRecord("3f7ae828-19cb-41e5-ae17-9532fe55db17");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "pie", {
get: function () {
return getSeriesTypeRecord("444a575c-b641-498a-9920-deba8125d6cd");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "column", {
get: function () {
return getSeriesTypeRecord("725167e0-349e-4d49-ab03-abb973474c3a");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "area", {
get: function () {
return getSeriesTypeRecord("ae810189-6c25-4616-b3d7-9bf355ab45a9");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "line", {
get: function () {
return getSeriesTypeRecord("b8357127-bd9e-4388-ba14-414d253820a8");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "areaSpline", {
get: function () {
return getSeriesTypeRecord("f5f641fb-62a9-4991-b1ef-0ad3e0c09eb2");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.seriesType, "bar", {
get: function () {
return getSeriesTypeRecord("f9a89332-5bd2-4960-85f2-41f70df5566d");
}
});

PHICore_THModel.staticEntities.legendPosition = {};
var getLegendPositionRecord = function (record) {
return OS.ApplicationInfo.getModules()["38b70e23-50fc-4710-80cf-3682a9dc998a"].staticEntities["aae17a97-3f0a-41cb-8937-e49d737a9771"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "bottom", {
get: function () {
return getLegendPositionRecord("03026d1b-9c13-4584-9295-671a1586c89a");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "right", {
get: function () {
return getLegendPositionRecord("4e71bff0-a68c-4905-aa02-46ae2986e6fb");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "center", {
get: function () {
return getLegendPositionRecord("5686b31a-ba9b-46ca-9282-2f767adc12a4");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "bottomRight", {
get: function () {
return getLegendPositionRecord("6d4187a9-2b5a-45b6-809c-e3b2284f2d47");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "left", {
get: function () {
return getLegendPositionRecord("74b2b300-d6d2-4812-ba28-ddeae94869ca");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "top", {
get: function () {
return getLegendPositionRecord("9da3e0d2-6f98-455b-bea1-5661b75da917");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "topLeft", {
get: function () {
return getLegendPositionRecord("aeae77ad-7167-40a1-af0d-02b40615709c");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "topRight", {
get: function () {
return getLegendPositionRecord("ec7543e7-5324-4ffe-8bbf-2c4a0f2dccbb");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendPosition, "bottomLeft", {
get: function () {
return getLegendPositionRecord("f08c54cf-074d-4052-8438-7bfdf027eb8b");
}
});

PHICore_THModel.staticEntities.legendLayout = {};
var getLegendLayoutRecord = function (record) {
return OS.ApplicationInfo.getModules()["38b70e23-50fc-4710-80cf-3682a9dc998a"].staticEntities["f3006da5-223f-4057-894a-8966e01ba39f"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.legendLayout, "proximate", {
get: function () {
return getLegendLayoutRecord("3936b711-b22b-4e51-ac3a-a8dfae908d39");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendLayout, "horizontal", {
get: function () {
return getLegendLayoutRecord("39e35bd8-6ab1-475f-8e44-22ab6a1b0af8");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.legendLayout, "vertical", {
get: function () {
return getLegendLayoutRecord("75c7fcee-0e1f-4392-b359-fa5646dd2236");
}
});

PHICore_THModel.staticEntities.sideMenuBehavior = {};
var getSideMenuBehaviorRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["11a5937b-e94d-4250-99a8-9c8358d3d965"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.sideMenuBehavior, "visible", {
get: function () {
return getSideMenuBehaviorRecord("25b95337-61e5-4cc7-95a0-fb2bee22c75f");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.sideMenuBehavior, "expandable", {
get: function () {
return getSideMenuBehaviorRecord("db935269-7a37-40aa-898b-e17e546a932a");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.sideMenuBehavior, "overlay", {
get: function () {
return getSideMenuBehaviorRecord("f194be06-0135-4afc-9be2-3f9a7ecd107c");
}
});

PHICore_THModel.staticEntities.size = {};
var getSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["1ac110b4-8964-470b-a6b2-81ae4a6b5bde"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.size, "medium", {
get: function () {
return getSizeRecord("0f4cba2c-32d2-4bef-b0e8-0ecd7eadbffa");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.size, "small", {
get: function () {
return getSizeRecord("9133cb8a-ca17-4e39-a9fd-4a07cf123c82");
}
});

PHICore_THModel.staticEntities.shape = {};
var getShapeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["6fe168a9-c16d-4cdb-9b6f-a9e6c6b79326"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.shape, "sharp", {
get: function () {
return getShapeRecord("94deb1f5-6153-4438-92ad-cedea3c1f6f0");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.shape, "softRounded", {
get: function () {
return getShapeRecord("d1093539-d77d-439d-8d53-03d2e0053a52");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.shape, "rounded", {
get: function () {
return getShapeRecord("f20c2269-270a-43b2-ba29-bd8fbff2519f");
}
});

PHICore_THModel.staticEntities.space = {};
var getSpaceRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["8fb3d471-82a4-439c-9cc1-0555dfa91451"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.space, "large", {
get: function () {
return getSpaceRecord("51b55067-e608-49ed-9f00-1faf9e4a694a");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "medium", {
get: function () {
return getSpaceRecord("7340e97f-de64-4337-ad0d-1defcab8adb2");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "xXLarge", {
get: function () {
return getSpaceRecord("823213f8-9df9-4de0-8aba-2b5566e6f87d");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "extraSmall", {
get: function () {
return getSpaceRecord("83adf9ba-fbcf-4ce0-b4a4-bc6330956b89");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "small", {
get: function () {
return getSpaceRecord("919210a5-6b3b-40c9-9a28-b4e2c28a46f8");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "base", {
get: function () {
return getSpaceRecord("f0572ad3-54ac-4755-8c8e-a9004171fcb1");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "extraLarge", {
get: function () {
return getSpaceRecord("f8dafab9-63b9-40b2-9755-f2f8fa3d6e84");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.space, "none", {
get: function () {
return getSpaceRecord("fb937b97-bd94-4ba4-80ff-446cb3bdf6ae");
}
});

PHICore_THModel.staticEntities.color = {};
var getColorRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["cb6d1da7-26d4-45d9-bc22-9a4c482e6ce2"][record];
};
Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral9", {
get: function () {
return getColorRecord("04a6c700-0ae5-44d5-81ce-34ec81d72c1c");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "grape", {
get: function () {
return getColorRecord("0d81324f-81ae-44eb-b81e-cd27ebce7460");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral7", {
get: function () {
return getColorRecord("1434454b-4d44-4ec7-a9ee-8353529b1621");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral10", {
get: function () {
return getColorRecord("1566893e-a30d-405f-878b-e64efdab7f7b");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "teal", {
get: function () {
return getColorRecord("19254415-08b2-4887-a6cf-36433bb1ade0");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "primary", {
get: function () {
return getColorRecord("1df261bf-454e-49a0-951e-87f6077cbbc1");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral4", {
get: function () {
return getColorRecord("20d4e7d1-c296-4853-b584-d2b004ddf9f5");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral8", {
get: function () {
return getColorRecord("31cd8495-438d-4825-8a93-c083bf6f016a");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "indigo", {
get: function () {
return getColorRecord("47b9565a-4f82-4a9d-a543-4aaa707853ac");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "orange", {
get: function () {
return getColorRecord("4d20d5b8-5570-4e18-9345-55772434a9ad");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "lime", {
get: function () {
return getColorRecord("50b20d51-09a6-43df-aa5d-6ae3c99f31e8");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "cyan", {
get: function () {
return getColorRecord("59edafdd-089e-409e-a2d2-78298e55e0f2");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "secondary", {
get: function () {
return getColorRecord("61f545b9-e074-40ee-a884-8102a56d9ee7");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral6", {
get: function () {
return getColorRecord("69c65fbc-5ddc-4e41-afcf-03acff40e7a8");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "yellow", {
get: function () {
return getColorRecord("80145099-0e84-4301-902b-2bd6a933e319");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral2", {
get: function () {
return getColorRecord("8577e423-4296-434f-9ca1-9a18b91e0c29");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral1", {
get: function () {
return getColorRecord("9946980c-176a-4345-90ff-312523579ef0");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral3", {
get: function () {
return getColorRecord("b7447296-c2b5-4d01-883b-b49d25b1c8a6");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "transparent", {
get: function () {
return getColorRecord("b87c59d9-4a95-4567-876d-b978ca413429");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "violet", {
get: function () {
return getColorRecord("bb39306e-ce82-47a7-9c0f-a78f92ff53c6");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "blue", {
get: function () {
return getColorRecord("c1bb8b1b-2f09-4fe9-bec9-eeb243b903d5");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral5", {
get: function () {
return getColorRecord("c1d63249-fde7-4438-b4c9-d445bcfc9257");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "red", {
get: function () {
return getColorRecord("d6c564f5-847a-4155-ba84-91b826bd676f");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "pink", {
get: function () {
return getColorRecord("e9991560-a98c-431e-a583-b707840dc2f3");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "green", {
get: function () {
return getColorRecord("ede4099b-595f-47f0-98ed-583414f4f6bd");
}
});

Object.defineProperty(PHICore_THModel.staticEntities.color, "neutral0", {
get: function () {
return getColorRecord("fb934ce5-6b33-4c96-8d40-b06352706a8d");
}
});

});
