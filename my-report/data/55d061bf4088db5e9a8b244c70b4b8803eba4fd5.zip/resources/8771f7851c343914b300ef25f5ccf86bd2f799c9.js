define("OutSystemsUI.languageResources", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.languageResources.translationsResources"], function (OutSystems, OutSystemsUILanguageResources_translationsResources) {
var OS = OutSystems.Internal;
var MessagesProvider = (function (_super) {
__extends(MessagesProvider, _super);
function MessagesProvider(translationResources) {
_super.apply(this, arguments);
this.setMessage("Validation.Mandatory", "Required field!");
this.setMessage("Validation.Integer", "Integer expected!");
this.setMessage("Validation.LongInteger", "Integer expected!");
this.setMessage("Validation.Decimal", "Decimal expected!");
this.setMessage("Validation.Currency", "Currency expected!");
this.setMessage("Validation.Date", "Date expected!");
this.setMessage("Validation.Time", "Time expected!");
this.setMessage("Validation.DateTime", "DateTime expected!");
this.setMessage("Validation.Text", "Text expected!");
this.setMessage("Validation.PhoneNumber", "Phone Number expected!");
this.setMessage("Validation.Email", "Email expected!");
this.setMessage("UpgradeComplete", "Your application has been updated to the latest version.");
this.setMessage("AppInitError.Generic", "An error occurred while trying to update the app. If you want to retry the update, restart the app.");
this.setMessage("AppInitError.Resources", "An error occurred while trying to update the app. If you want to retry the update, restart the app.");
this.setMessage("AppInitError.DataModel", "An error occurred while trying to update the app. If you want to retry the update, restart the app. If the problem persists you can reinstall, but all local data will be lost.");
this.setMessage("UpgradeRequired", "Your application needs to be updated. Tap here to update.");
this.setMessage("UpgradeRequiredDataLoss", "Your application needs to be updated. Unsaved data will be lost. Tap here to update.");
}
return MessagesProvider;
})(OS.LanguageResources.BaseMessagesProvider);
return new MessagesProvider(OutSystemsUILanguageResources_translationsResources);
});
define("OutSystemsUI.languageResources.translationsResources", ["exports", "OutSystemsUI.languageResources.translationsResources.ar", "OutSystemsUI.languageResources.translationsResources.de-DE", "OutSystemsUI.languageResources.translationsResources.en", "OutSystemsUI.languageResources.translationsResources.es", "OutSystemsUI.languageResources.translationsResources.fr-CA", "OutSystemsUI.languageResources.translationsResources.fr-FR", "OutSystemsUI.languageResources.translationsResources.it-IT", "OutSystemsUI.languageResources.translationsResources.ja-JP", "OutSystemsUI.languageResources.translationsResources.ko-KR", "OutSystemsUI.languageResources.translationsResources.nl", "OutSystemsUI.languageResources.translationsResources.pt", "OutSystemsUI.languageResources.translationsResources.pt-BR", "OutSystemsUI.languageResources.translationsResources.zh-CN", "OutSystemsUI.languageResources.translationsResources.zh-Hans", "OutSystemsUI.languageResources.translationsResources.zh-Hant"], function (exports, OutSystemsUI_languageResources_translationsResources_ar, OutSystemsUI_languageResources_translationsResources_deDE, OutSystemsUI_languageResources_translationsResources_en, OutSystemsUI_languageResources_translationsResources_es, OutSystemsUI_languageResources_translationsResources_frCA, OutSystemsUI_languageResources_translationsResources_frFR, OutSystemsUI_languageResources_translationsResources_itIT, OutSystemsUI_languageResources_translationsResources_jaJP, OutSystemsUI_languageResources_translationsResources_koKR, OutSystemsUI_languageResources_translationsResources_nl, OutSystemsUI_languageResources_translationsResources_pt, OutSystemsUI_languageResources_translationsResources_ptBR, OutSystemsUI_languageResources_translationsResources_zhCN, OutSystemsUI_languageResources_translationsResources_zhHans, OutSystemsUI_languageResources_translationsResources_zhHant) {
return {
"ar": {
"translations": OutSystemsUI_languageResources_translationsResources_ar,
"isRTL": true
},
"de-DE": {
"translations": OutSystemsUI_languageResources_translationsResources_deDE,
"isRTL": false
},
"en": {
"translations": OutSystemsUI_languageResources_translationsResources_en,
"isRTL": false
},
"es": {
"translations": OutSystemsUI_languageResources_translationsResources_es,
"isRTL": false
},
"fr-CA": {
"translations": OutSystemsUI_languageResources_translationsResources_frCA,
"isRTL": false
},
"fr-FR": {
"translations": OutSystemsUI_languageResources_translationsResources_frFR,
"isRTL": false
},
"it-IT": {
"translations": OutSystemsUI_languageResources_translationsResources_itIT,
"isRTL": false
},
"ja-JP": {
"translations": OutSystemsUI_languageResources_translationsResources_jaJP,
"isRTL": false
},
"ko-KR": {
"translations": OutSystemsUI_languageResources_translationsResources_koKR,
"isRTL": false
},
"nl": {
"translations": OutSystemsUI_languageResources_translationsResources_nl,
"isRTL": false
},
"pt": {
"translations": OutSystemsUI_languageResources_translationsResources_pt,
"isRTL": false
},
"pt-BR": {
"translations": OutSystemsUI_languageResources_translationsResources_ptBR,
"isRTL": false
},
"zh-CN": {
"translations": OutSystemsUI_languageResources_translationsResources_zhCN,
"isRTL": false
},
"zh-Hans": {
"translations": OutSystemsUI_languageResources_translationsResources_zhHans,
"isRTL": false
},
"zh-Hant": {
"translations": OutSystemsUI_languageResources_translationsResources_zhHant,
"isRTL": false
}
};
});
define("OutSystemsUI.languageResources.translationsResources.ar", [], function () {
return {
"Validation.Currency": "الرجاء إدخال عملة صحيحة!",
"Validation.DateTime": "الرجاء إدخال تاريخ و وقت صحيحين!",
"Validation.Date": "الرجاء إدخال تاريخ صحيح!",
"Validation.Decimal": "الرجاء إدخال رقم عشري صحيح!",
"Validation.Email": "الرجاء إدخال عنوان بريد إلكتروني صحيح!",
"Validation.Integer": "الرجاء إدخال رقم صحيح!",
"Validation.LongInteger": "الرجاء إدخال رقم صحيح!",
"Validation.Mandatory": "حقل إلزامي!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "الرجاء إدخال كلمة مرور رقمية!",
"Validation.PhoneNumber": "الرجاء إدخال رقم هاتف صحيح!",
"Validation.Text": "الرجاء إدخال نص صحيح!",
"Validation.Time": "الرجاء إدخال وقت صحيح!",
"UpgradeComplete": "تم تحديث التطبيق الخاص بك إلى أحدث إصدار.",
"AppInitError.Generic": "حدث خطأ أثناء محاولة تحديث التطبيق. إذا كنت تريد إعادة محاولة التحديث ، فأعد تشغيل التطبيق.",
"AppInitError.DataModel": "حدث خطأ أثناء محاولة تحديث التطبيق. إذا كنت تريد إعادة محاولة التحديث ، فأعد تشغيل التطبيق. إذا استمرت المشكلة ، يمكنك إعادة التثبيت ، ولكن ستفقد جميع البيانات المحلية.",
"AppInitError.Resources": "حدث خطأ أثناء محاولة تحديث التطبيق. إذا كنت تريد إعادة محاولة التحديث ، فأعد تشغيل التطبيق.",
"UpgradeRequiredDataLoss": "يحتاج تطبيقك إلى التحديث. سيتم فقد البيانات الغير محفوظة. انقر هنا للتحديث.",
"UpgradeRequired": "يحتاج تطبيقك إلى التحديث. انقر هنا للتحديث."
};
});
define("OutSystemsUI.languageResources.translationsResources.de-DE", [], function () {
return {
"Validation.Currency": "Währung wird erwartet!",
"Validation.DateTime": "Datum und Uhrzeit wird erwartet!",
"Validation.Date": "Datum wird erwartet!",
"Validation.Decimal": "Dezimal wird erwartet!",
"Validation.Email": "Email wird erwartet!",
"Validation.Integer": "Ganze Zahl wird erwartet!",
"Validation.LongInteger": "Ganze Zahl wird erwartet!",
"Validation.Mandatory": "Pflichtfeld!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Numerisches Passwort wird erwartet!",
"Validation.PhoneNumber": "Telefonnummer wird erwartet!",
"Validation.Text": "Text wird erwartet!",
"Validation.Time": "Uhrzeit wird erwartet!",
"UpgradeComplete": "Ihre Anwendung wurde auf die neueste Version aktualisiert.",
"AppInitError.Generic": "Beim Versuch, die App zu aktualisieren, ist ein Fehler aufgetreten. Wenn Sie die Aktualisierung erneut versuchen möchten, starten Sie die App neu.",
"AppInitError.DataModel": "Beim Versuch, die App zu aktualisieren, ist ein Fehler aufgetreten. Wenn Sie die Aktualisierung erneut versuchen möchten, starten Sie die App neu. Wenn das Problem weiterhin besteht, können Sie die App neu installieren, dabei gehen jedoch alle lokalen Daten verloren.",
"AppInitError.Resources": "Beim Versuch, die App zu aktualisieren, ist ein Fehler aufgetreten. Wenn Sie die Aktualisierung erneut versuchen möchten, starten Sie die App neu.",
"UpgradeRequiredDataLoss": "Ihre Anwendung muss aktualisiert werden. Nicht gespeicherte Daten gehen verloren. Tippen Sie hier, um sie zu aktualisieren.",
"UpgradeRequired": "Ihre Anwendung muss aktualisiert werden. Tippen Sie hier, um sie zu aktualisieren."
};
});
define("OutSystemsUI.languageResources.translationsResources.en", [], function () {
return {
"Validation.Currency": "Currency expected!",
"Validation.DateTime": "DateTime expected!",
"Validation.Date": "Date expected!",
"Validation.Decimal": "Decimal expected!",
"Validation.Email": "Email expected!",
"Validation.Integer": "Integer expected!",
"Validation.LongInteger": "Integer expected!",
"Validation.Mandatory": "Required field!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Numeric Password expected!",
"Validation.PhoneNumber": "Phone Number expected!",
"Validation.Text": "Text expected!",
"Validation.Time": "Time expected!",
"UpgradeComplete": "Your application has been updated to the latest version.",
"AppInitError.Generic": "An error occurred while trying to update the app. If you want to retry the update, restart the app.",
"AppInitError.DataModel": "An error occurred while trying to update the app. If you want to retry the update, restart the app. If the problem persists you can reinstall, but all local data will be lost.",
"AppInitError.Resources": "An error occurred while trying to update the app. If you want to retry the update, restart the app.",
"UpgradeRequiredDataLoss": "Your application needs to be updated. Unsaved data will be lost. Tap here to update.",
"UpgradeRequired": "Your application needs to be updated. Tap here to update."
};
});
define("OutSystemsUI.languageResources.translationsResources.es", [], function () {
return {
"Validation.Currency": "¡Moneda esperada!",
"Validation.DateTime": "¡Fecha y hora esperada!",
"Validation.Date": "¡Fecha esperada!",
"Validation.Decimal": "¡Decimal esperado!",
"Validation.Email": "¡Correo electrónico esperado!",
"Validation.Integer": "¡Entero esperado!",
"Validation.LongInteger": "¡Entero esperado!",
"Validation.Mandatory": "¡Campo requerido!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "¡Contraseña numérica esperada!",
"Validation.PhoneNumber": "¡Número de teléfono esperado!",
"Validation.Text": "¡Texto esperado!",
"Validation.Time": "¡Tiempo esperado!",
"UpgradeComplete": "Su aplicación ha sido actualizada a la última versión.",
"AppInitError.Generic": "Ocurrió un error al intentar actualizar la aplicación. Si desea volver a intentar la actualización, reinicie la aplicación.",
"AppInitError.DataModel": "Ocurrió un error al intentar actualizar la aplicación. Si desea volver a intentar la actualización, reinicie la aplicación. Si el problema persiste, puede volver a instalarlo, pero se perderán todos los datos locales.",
"AppInitError.Resources": "Ocurrió un error al intentar actualizar la aplicación. Si desea volver a intentar la actualización, reinicie la aplicación.",
"UpgradeRequiredDataLoss": "Su aplicación necesita ser actualizada. Los datos no guardados se perderan. Toque aquí para actualizar.",
"UpgradeRequired": "Su aplicación necesita ser actualizada. Toque aquí para actualizar."
};
});
define("OutSystemsUI.languageResources.translationsResources.fr-CA", [], function () {
return {
"Validation.Currency": "Veuillez entrer une valeur monétaire!",
"Validation.DateTime": "Veuillez entrer une date et heure spécifique!",
"Validation.Date": "Veuillez entrer une date!",
"Validation.Decimal": "Veuillez entrer un décimal!",
"Validation.Email": "Veuillez entrer un courriel!",
"Validation.Integer": "Veuillez entrer un entier!",
"Validation.LongInteger": "Veuillez entrer un entier!",
"Validation.Mandatory": "Champs requis!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Veuillez entrer un mot de passe numérique!",
"Validation.PhoneNumber": "Veuillez entrer un numéro de téléphone!",
"Validation.Text": "Veuillez entrer un texte!",
"Validation.Time": "Veuillez entrer une heure spécifique!",
"UpgradeComplete": "Votre application a été mise à jour avec la dernière version.",
"AppInitError.Generic": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application.",
"AppInitError.DataModel": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application. Si le problème persiste, vous pouvez réinstaller, mais toutes les données locales seront perdues.",
"AppInitError.Resources": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application.",
"UpgradeRequiredDataLoss": "Votre application doit être mise à jour. Les données non enregistrées seront perdues. Appuyez ici pour mettre à jour.",
"UpgradeRequired": "Votre application doit être mise à jour. Appuyez ici pour mettre à jour."
};
});
define("OutSystemsUI.languageResources.translationsResources.fr-FR", [], function () {
return {
"Validation.Currency": "Veuillez entrer une valeur monétaire!",
"Validation.DateTime": "Veuillez entrer une date et heure spécifique!",
"Validation.Date": "Veuillez entrer une date!",
"Validation.Decimal": "Veuillez entrer un décimal!",
"Validation.Email": "Veuillez entrer un courriel!",
"Validation.Integer": "Veuillez entrer un entier!",
"Validation.LongInteger": "Veuillez entrer un entier!",
"Validation.Mandatory": "Champs requis!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Veuillez entrer un mot de passe numérique!",
"Validation.PhoneNumber": "Veuillez entrer un numéro de téléphone!",
"Validation.Text": "Veuillez entrer un texte!",
"Validation.Time": "Veuillez entrer une heure spécifique!",
"UpgradeComplete": "Votre application a été mise à jour avec la dernière version.",
"AppInitError.Generic": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application.",
"AppInitError.DataModel": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application. Si le problème persiste, vous pouvez réinstaller, mais toutes les données locales seront perdues.",
"AppInitError.Resources": "Une erreur s\'est produite lors de la tentative de mise à jour de l\'application. Si vous souhaitez réessayer la mise à jour, redémarrez l\'application.",
"UpgradeRequiredDataLoss": "Votre application doit être mise à jour. Les données non enregistrées seront perdues. Appuyez ici pour mettre à jour.",
"UpgradeRequired": "Votre application doit être mise à jour. Appuyez ici pour mettre à jour."
};
});
define("OutSystemsUI.languageResources.translationsResources.it-IT", [], function () {
return {
"Validation.Currency": "Inserire un valore monerario!",
"Validation.DateTime": "Inserire una data e un\'ora!",
"Validation.Date": "Inserire una data!",
"Validation.Decimal": "Inserire un valore di tipo decimale!",
"Validation.Email": "Inserire un\'email!",
"Validation.Integer": "Inserire un valore intero!",
"Validation.LongInteger": "Inserire un valore intero!",
"Validation.Mandatory": "Campo obbligatorio!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Inserire una password numerica!",
"Validation.PhoneNumber": "Inserire un numero di telefono!",
"Validation.Text": "Inserire un valore testuale!",
"Validation.Time": "Inserire un\'ora specifica!",
"UpgradeComplete": "La tua applicazione è stata aggiornata all\'ultima versione.",
"AppInitError.Generic": "Si è verificato un errore durante il tentativo di aggiornare l\'app. Se vuoi riprovare ad aggiornare, riavvia l\'app.",
"AppInitError.DataModel": "Si è verificato un errore durante il tentativo di aggiornare l\'app. Se si desidera riprovare l\'aggiornamento, riavvia l\'app. Se il problema persiste che puoi reinstallare, ma tutti i dati locali andranno persi.",
"AppInitError.Resources": "Si è verificato un errore durante il tentativo di aggiornare l\'app. Se vuoi riprovare ad aggiornare, riavvia l\'app.",
"UpgradeRequiredDataLoss": "La tua applicazione deve essere aggiornata. I dati non salvati andranno persi. Tocca qui per aggiornare.",
"UpgradeRequired": "La tua applicazione deve essere aggiornata. Tocca qui per aggiornare."
};
});
define("OutSystemsUI.languageResources.translationsResources.ja-JP", [], function () {
return {
"Validation.Currency": "通貨が期待されています!",
"Validation.DateTime": "日時が期待されています!",
"Validation.Date": "日付が期待されています！",
"Validation.Decimal": "10 進数が期待されています!",
"Validation.Email": "Eメールが期待されています!",
"Validation.Integer": "整数が期待されています!",
"Validation.LongInteger": "整数が期待されています!",
"Validation.Mandatory": "必須フィールドです!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "数値のパスワードが期待されています!",
"Validation.PhoneNumber": "電話番号が期待されています!",
"Validation.Text": "テキストが期待されています!",
"Validation.Time": "時間が期待されています!",
"UpgradeComplete": "アプリケーションは最新バージョンに更新されました。",
"AppInitError.Generic": "アプリを更新しようとしたときにエラーが発生しました。 アップデートを再試行する場合は、アプリを再起動してください。",
"AppInitError.DataModel": "アプリを更新しようとしたときにエラーが発生しました。 アップデートを再試行する場合は、アプリを再起動してください。 問題が解決しない場合は再インストールできますが、ローカル データはすべて失われます。",
"AppInitError.Resources": "アプリを更新しようとしたときにエラーが発生しました。 アップデートを再試行する場合は、アプリを再起動してください。",
"UpgradeRequiredDataLoss": "アプリケーションを更新する必要があります。 保存されていないデータは失われます。 更新するにはここをタップしてください。",
"UpgradeRequired": "アプリケーションを更新する必要があります。 更新するにはここをタップしてください。"
};
});
define("OutSystemsUI.languageResources.translationsResources.ko-KR", [], function () {
return {
"Validation.Currency": "통화을 입력하세요!",
"Validation.DateTime": "DateTime을 입력하세요!",
"Validation.Date": "날짜를 입력하세요!",
"Validation.Decimal": "소수를 입력하세요!",
"Validation.Email": "이메일을 입력하세요!",
"Validation.Integer": "정수를 입력하세요!",
"Validation.LongInteger": "정수를 입력하세요!",
"Validation.Mandatory": "필수 항목입니다!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "숫자 암호를 입력하세요!",
"Validation.PhoneNumber": "전화번호를 입력하세요!",
"Validation.Text": "텍스트를 입력하세요!",
"Validation.Time": "시간을 입력하세요!",
"UpgradeComplete": "애플리케이션이 최신 버전으로 업데이트되었습니다.",
"AppInitError.Generic": "앱을 업데이트하는 중에 오류가 발생했습니다. 업데이트를 다시 시도하려면 앱을 다시 시작하세요.",
"AppInitError.DataModel": "앱을 업데이트하는 중에 오류가 발생했습니다. 업데이트를 다시 시도하려면 앱을 다시 시작하세요. 문제가 지속되면 다시 설치할 수 있지만 모든 로컬 데이터가 손실됩니다.",
"AppInitError.Resources": "앱을 업데이트하는 중에 오류가 발생했습니다. 업데이트를 다시 시도하려면 앱을 다시 시작하세요.",
"UpgradeRequiredDataLoss": "애플리케이션을 업데이트해야 합니다. 저장하지 않은 데이터는 손실됩니다. 업데이트하려면 여기를 탭하세요.",
"UpgradeRequired": "애플리케이션을 업데이트해야 합니다. 업데이트하려면 여기를 탭하세요."
};
});
define("OutSystemsUI.languageResources.translationsResources.nl", [], function () {
return {
"Validation.Currency": "Valuta verwacht!",
"Validation.DateTime": "DateTime verwacht!",
"Validation.Date": "Datum verwacht!",
"Validation.Decimal": "Decimal verwacht!",
"Validation.Email": "E -mail verwacht!",
"Validation.Integer": "Integer verwacht!",
"Validation.LongInteger": "Integer verwacht!",
"Validation.Mandatory": "Verplicht veld!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Numeriek wachtwoord verwacht!",
"Validation.PhoneNumber": "Telefoonnummer verwacht!",
"Validation.Text": "Tekst verwacht!",
"Validation.Time": "Tijd verwacht!",
"UpgradeComplete": "Uw applicatie is bijgewerkt naar de nieuwste versie.",
"AppInitError.Generic": "Er is een fout opgetreden tijdens het updaten van de app. Herstart de app om het opnieuw te proberen.",
"AppInitError.DataModel": "Er is een fout opgetreden tijdens het updaten van de app. Herstart de app om het opnieuw te proberen. Als het probleem aanhoudt, kunt u het opnieuw installeren, maar dan zullen wel alle lokale gegevens verloren gaan.",
"AppInitError.Resources": "Er is een fout opgetreden tijdens het updaten van de app. Herstart de app om het opnieuw te proberen.",
"UpgradeRequiredDataLoss": "Uw aanvraag moet worden bijgewerkt. Niet-opgeslagen gegevens gaan verloren. Tik hier om te updaten.",
"UpgradeRequired": "Uw aanvraag moet worden bijgewerkt. Tik hier om te updaten."
};
});
define("OutSystemsUI.languageResources.translationsResources.pt", [], function () {
return {
"Validation.Currency": "Formato de moeda esperado!",
"Validation.DateTime": "Formato de data e hora esperado!",
"Validation.Date": "Formato de Data esperada!",
"Validation.Decimal": "Formato decimal esperado!",
"Validation.Email": "Formato de email esperado!",
"Validation.Integer": "Formato de número esperado!",
"Validation.LongInteger": "Formato de número esperado!",
"Validation.Mandatory": "Campo obrigatório!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Formato password numérica esperado!",
"Validation.PhoneNumber": "Formato de número de telefone esperado!",
"Validation.Text": "Formato de texto esperado!",
"Validation.Time": "Formato de hora esperado!",
"UpgradeComplete": "A sua aplicação foi actualizada para a versão mais recente.",
"AppInitError.Generic": "Ocorreu um erro ao tentar actualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação.",
"AppInitError.DataModel": "Ocorreu um erro ao tentar actualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação. Se o problema persistir, você pode reinstalar a aplicação, mas os dados locais serão apagados.",
"AppInitError.Resources": "Ocorreu um erro ao tentar actualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação.",
"UpgradeRequiredDataLoss": "A sua aplicação precisa de ser actualizada (os seus dados não salvos, serão perdidos). Toque aqui para actualizar.",
"UpgradeRequired": "A sua aplicação necessita de actualizar. Toque aqui para actualizar."
};
});
define("OutSystemsUI.languageResources.translationsResources.pt-BR", [], function () {
return {
"Validation.Currency": "Formato de moeda esperado!",
"Validation.DateTime": "Formato de data e hora esperado!",
"Validation.Date": "Formato de Data esperada!",
"Validation.Decimal": "Formato decimal esperado!",
"Validation.Email": "Formato de email esperado!",
"Validation.Integer": "Formato de número esperado!",
"Validation.LongInteger": "Formato de número esperado!",
"Validation.Mandatory": "Campo obrigatório!",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "Formato senha numérica esperado!",
"Validation.PhoneNumber": "Formato de número de telefone esperado!",
"Validation.Text": "Formato de texto esperado!",
"Validation.Time": "Formato de hora esperado!",
"UpgradeComplete": "A sua aplicação foi atualizada para a versão mais recente.",
"AppInitError.Generic": "Ocorreu um erro ao tentar atualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação.",
"AppInitError.DataModel": "Ocorreu um erro ao tentar atualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação. Se o problema persistir, você pode reinstalar a aplicação, mas os dados locais serão apagados.",
"AppInitError.Resources": "Ocorreu um erro ao tentar atualizar a sua aplicação. Se quiser tentar novamente, reinicie a aplicação.",
"UpgradeRequiredDataLoss": "A sua aplicação precisa de ser atualizada (os seus dados não salvos, serão perdidos). Toque aqui para atualizar.",
"UpgradeRequired": "A sua aplicação precisa ser atualizada. Toque aqui para atualizar."
};
});
define("OutSystemsUI.languageResources.translationsResources.zh-CN", [], function () {
return {
"Validation.Currency": "应为货币！",
"Validation.DateTime": "应为日期时间！",
"Validation.Date": "应为日期！",
"Validation.Decimal": "应为小数！",
"Validation.Email": "应为电邮地址！",
"Validation.Integer": "应为整数！",
"Validation.LongInteger": "应为整数！",
"Validation.Mandatory": "必填项目！",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "应为数字密码！",
"Validation.PhoneNumber": "应为电话号码！",
"Validation.Text": "应为文字！",
"Validation.Time": "应为时间！",
"UpgradeComplete": "您的应用程序已更新为最新版本。",
"AppInitError.Generic": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。",
"AppInitError.DataModel": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。如果问题持续存在，您可以重新安装，但是所有本地数据将丢失。",
"AppInitError.Resources": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。",
"UpgradeRequiredDataLoss": "您的应用程序需要更新。未保存的数据将丢失。点击此处进行更新。",
"UpgradeRequired": "您的应用程序需要更新。点击此处进行更新。"
};
});
define("OutSystemsUI.languageResources.translationsResources.zh-Hans", [], function () {
return {
"Validation.Currency": "应为货币！",
"Validation.DateTime": "应为日期时间！",
"Validation.Date": "应为日期！",
"Validation.Decimal": "应为小数！",
"Validation.Email": "应为电邮地址！",
"Validation.Integer": "应为整数！",
"Validation.LongInteger": "应为整数！",
"Validation.Mandatory": "必填项目！",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "应为数字密码！",
"Validation.PhoneNumber": "应为电话号码！",
"Validation.Text": "应为文字！",
"Validation.Time": "应为时间！",
"UpgradeComplete": "您的应用程序已更新为最新版本。",
"AppInitError.Generic": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。",
"AppInitError.DataModel": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。如果问题持续存在，您可以重新安装，但是所有本地数据将丢失。",
"AppInitError.Resources": "尝试更新应用程序时发生了错误。如果要重试更新，请重新启动应用程序。",
"UpgradeRequiredDataLoss": "您的应用程序需要更新。未保存的数据将丢失。点击此处进行更新。",
"UpgradeRequired": "您的应用程序需要更新。点击此处进行更新。"
};
});
define("OutSystemsUI.languageResources.translationsResources.zh-Hant", [], function () {
return {
"Validation.Currency": "應爲貨幣！",
"Validation.DateTime": "應爲日期時間！",
"Validation.Date": "應爲日期！",
"Validation.Decimal": "應爲小數！",
"Validation.Email": "應爲電郵地址！",
"Validation.Integer": "應爲整數！",
"Validation.LongInteger": "應爲整數！",
"Validation.Mandatory": "必填項目！",
"Kn_hixxDWEm4lMd7mIpycQ#NumericPasswordValidatorMsg": "應爲數字密碼！",
"Validation.PhoneNumber": "應爲電話號碼！",
"Validation.Text": "應爲文字！",
"Validation.Time": "應爲時間！",
"UpgradeComplete": "您的應用程序已更新為最新版本。",
"AppInitError.Generic": "嘗試更新應用程序時發生了錯誤。如果要重試更新，請重新啟動應用程序。",
"AppInitError.DataModel": "嘗試更新應用程序時發生了錯誤。如果要重試更新，請重新啟動應用程序。如果問題持續存在，您可以重新安裝，但是所有本地數據將丟失。",
"AppInitError.Resources": "嘗試更新應用程序時發生了錯誤。如果要重試更新，請重新啟動應用程序。",
"UpgradeRequiredDataLoss": "您的應用程序需要更新。未保存的數據將丟失。點擊此處進行更新。",
"UpgradeRequired": "您的應用程序需要更新。點擊此處進行更新。"
};
});
