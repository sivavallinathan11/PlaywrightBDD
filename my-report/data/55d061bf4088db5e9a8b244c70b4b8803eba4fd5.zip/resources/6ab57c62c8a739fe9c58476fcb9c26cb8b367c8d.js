define("PHICore_TH.controller$GetLastValidURL", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "PHICore_TH.controller$GetLastValidURL.JavaScript_getLastValidURLJS", "PHICore_TH.clientVariables"], function (exports, OutSystems, PHICore_THModel, PHICore_THController, PHICore_TH_controller_GetLastValidURL_JavaScript_getLastValidURLJS, PHICore_THClientVariables) {
var OS = OutSystems.Internal;
PHICore_THController.default.getLastValidURL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScript_getLastValidURLJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore_TH.GetLastValidURL$outVars"))());
varBag.callContext = callContext;
varBag.javaScript_getLastValidURLJSResult = javaScript_getLastValidURLJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:2rNEH+f1V06a0cIv05wVZw:/ClientActionFlows.2rNEH+f1V06a0cIv05wVZw:_cJgDrYTLZbfA2fu2_gg7g", "PHICore_TH", "GetLastValidURL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:1pbgV7eAik+330U7ejZXtQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:FjstNSdxpkW+NtU+PJKhWA", callContext.id);
javaScript_getLastValidURLJSResult.value = controller.safeExecuteJSNode(PHICore_TH_controller_GetLastValidURL_JavaScript_getLastValidURLJS, "JavaScript_getLastValidURL", "GetLastValidURL", {
URL: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("PHICore_TH.GetLastValidURL$javaScript_getLastValidURLJSResult"))();
jsNodeResult.uRLOut = OS.DataConversion.JSNodeParamConverter.from($parameters.URL, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:WXRa5mmPvUirEQ+NNT4ufw", callContext.id);
// URL = JavaScript_getLastValidURL.URL
outVars.value.uRLOut = javaScript_getLastValidURLJSResult.value.uRLOut;
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:FQkLAHfvzUWM+sZG9m26YA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:2rNEH+f1V06a0cIv05wVZw", callContext.id);
}

};
var controller = PHICore_THController.default;
PHICore_THController.default.constructor.registerVariableGroupType("PHICore_TH.GetLastValidURL$javaScript_getLastValidURLJSResult", [{
name: "URL",
attrName: "uRLOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICore_THController.default.constructor.registerVariableGroupType("PHICore_TH.GetLastValidURL$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICore_THController.default.clientActionProxies.getLastValidURL$Action = function () {
return controller.executeActionInsideJSNode(PHICore_THController.default.getLastValidURL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.Types.Text)
};
});
};
});
define("PHICore_TH.controller$GetLastValidURL.JavaScript_getLastValidURLJS", [], function () {
return function ($parameters, $actions, $roles, $public) {

$parameters.URL = localStorage.getItem("PhiValidURL");
};
});

define("PHICore_TH.controller$SetClientPrimaryColor", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "PHICore_TH.clientVariables"], function (exports, OutSystems, PHICore_THModel, PHICore_THController, PHICore_THClientVariables) {
var OS = OutSystems.Internal;
PHICore_THController.default.setClientPrimaryColor$Action = function (primaryColorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore_TH.SetClientPrimaryColor$vars"))());
vars.value.primaryColorInLocal = primaryColorIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:GlHRJfnX40e3mtx_lT7HDw:/ClientActionFlows.GlHRJfnX40e3mtx_lT7HDw:_keWo21RuzWLXb4QIMqQxQ", "PHICore_TH", "SetClientPrimaryColor", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:gxZEnkudKEu0NAPsDofKXA", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:+cv1yBLh00OX9DEf19wthg", callContext.id);
// PrimaryColor = PrimaryColor
PHICore_THClientVariables.setPrimaryColor(vars.value.primaryColorInLocal);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:GLMUxJequ0CPOfrrOS8qzg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:GlHRJfnX40e3mtx_lT7HDw", callContext.id);
}

};
var controller = PHICore_THController.default;
PHICore_THController.default.constructor.registerVariableGroupType("PHICore_TH.SetClientPrimaryColor$vars", [{
name: "PrimaryColor",
attrName: "primaryColorInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICore_THController.default.clientActionProxies.setClientPrimaryColor$Action = function (primaryColorIn) {
primaryColorIn = (primaryColorIn === undefined) ? "" : primaryColorIn;
return controller.executeActionInsideJSNode(PHICore_THController.default.setClientPrimaryColor$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(primaryColorIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("PHICore_TH.controller$ServerAction.User_GetUnifiedLoginUrl", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller"], function (exports, OutSystems, PHICore_THModel, PHICore_THController) {
var OS = OutSystems.Internal;
PHICore_THController.default.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/PHICore_TH/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore_TH$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
PHICore_THController.default.constructor.registerVariableGroupType("PHICore_TH$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("PHICore_TH.controller", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller$debugger"], function (exports, OutSystems, PHICore_THModel, PHICore_TH_Controller_debugger) {
var OS = OutSystems.Internal;
var PHICore_THController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
PHICore_THController.default = new Controller(null, "PHICore_TH");
});
define("PHICore_TH.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main", "PHICore_TH.clientVariables"], function (exports, Debugger, OutSystems, PHICore_THClientVariables) {
var OS = OutSystems.Internal;
var metaInfo = {
"oUPSa7SVOUGd8UU+iy1QyQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.Types.Text
},
"FjstNSdxpkW+NtU+PJKhWA": {
getter: function (varBag, idService) {
return varBag.javaScript_getLastValidURLJSResult.value;
}
},
"ZXHf_sNLpE+Ms2rtwLiN4A": {
getter: function (varBag, idService) {
return varBag.vars.value.primaryColorInLocal;
},
dataType: OS.Types.Text
},
"bT3ZDPGZ6UadmUikue_New": {
getter: function (varBag, idService) {
return PHICore_THClientVariables.getPrimaryColor();
},
dataType: OS.Types.Text
},
"4BcWEWvHTk2h3psxeZoyng": {
getter: function (varBag, idService) {
return PHICore_THClientVariables.getLastURL();
},
dataType: OS.Types.Text
},
"l1CSc5x1O0awp_WWouahoQ": {
getter: function (varBag, idService) {
return PHICore_THClientVariables.getUsername();
},
dataType: OS.Types.Text
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
