define("PHICore.Common_Widgets.GraphFilter.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "PHICore.controller", "OutSystemsUI.model", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$DropdownItemRecordList", "PHICore.model$MSD_ItemList", "PHICore.model$GraphFilterStrucRec", "Common_CW.controller$Set_Focus", "PHICore.controller$AddAriaLabel", "PHICore.model$DropdownItemRecord", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TeamTeamUserRecordList"], function (OutSystems, PHICoreModel, Common_CWController, PHICoreController, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var GetTeamsAggrRec = (function (_super) {
__extends(GetTeamsAggrRec, _super);
function GetTeamsAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamsAggrRec.RecordListType = PHICoreModel.TeamTeamUserRecordList;
GetTeamsAggrRec.init();
return GetTeamsAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("EntryDateDropdownList", "entryDateDropdownListVar", "EntryDateDropdownList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.DropdownItemRecordList());
}, false, PHICoreModel.DropdownItemRecordList), 
this.attr("TempTeams", "tempTeamsVar", "TempTeams", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.MSD_ItemList());
}, false, PHICoreModel.MSD_ItemList), 
this.attr("ShowTeamsError", "showTeamsErrorVar", "ShowTeamsError", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("TeamWidgetId", "teamWidgetIdVar", "TeamWidgetId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("ShowPopup", "showPopupIn", "ShowPopup", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showPopupInDataFetchStatus", "_showPopupInDataFetchStatus", "_showPopupInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GraphFilterStruc", "graphFilterStrucIn", "GraphFilterStruc", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.GraphFilterStrucRec());
}, false, PHICoreModel.GraphFilterStrucRec), 
this.attr("_graphFilterStrucInDataFetchStatus", "_graphFilterStrucInDataFetchStatus", "_graphFilterStrucInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CallToRefresh", "callToRefreshIn", "CallToRefresh", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_callToRefreshInDataFetchStatus", "_callToRefreshInDataFetchStatus", "_callToRefreshInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetTeams", "getTeamsAggr", "getTeamsAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamsAggrRec());
}, true, GetTeamsAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Dropdown_TimePeriod: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("ShowPopup" in inputs) {
this.variables.showPopupIn = inputs.ShowPopup;
if("_showPopupInDataFetchStatus" in inputs) {
this.variables._showPopupInDataFetchStatus = inputs._showPopupInDataFetchStatus;
}

}

if("GraphFilterStruc" in inputs) {
this.variables.graphFilterStrucIn = inputs.GraphFilterStruc;
if("_graphFilterStrucInDataFetchStatus" in inputs) {
this.variables._graphFilterStrucInDataFetchStatus = inputs._graphFilterStrucInDataFetchStatus;
}

}

if("CallToRefresh" in inputs) {
this.variables.callToRefreshIn = inputs.CallToRefresh;
if("_callToRefreshInDataFetchStatus" in inputs) {
this.variables._callToRefreshInDataFetchStatus = inputs._callToRefreshInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.GraphFilter");
});
define("PHICore.Common_Widgets.GraphFilter.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.GraphFilter.mvc$model", "PHICore.Common_Widgets.GraphFilter.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "MSD.MSD.MSD.mvc$view", "Common_CW.PHICore_CW.PreviousFocus.mvc$view", "Common_CW.PHICore_CW.NextFocus.mvc$view", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$DropdownItemRecordList", "PHICore.model$MSD_ItemList", "PHICore.model$GraphFilterStrucRec", "Common_CW.controller$Set_Focus", "PHICore.controller$AddAriaLabel", "PHICore.model$DropdownItemRecord", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TeamTeamUserRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, React, OSView, PHICore_Common_Widgets_GraphFilter_mvc_model, PHICore_Common_Widgets_GraphFilter_mvc_controller, PHICoreClientVariables, OSWidgets, MSD_MSD_MSD_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.GraphFilter";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [MSD_MSD_MSD_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_GraphFilter_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_GraphFilter_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showPopupIn,
style: "popup-dialog show-overflow",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
showPopup_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showPopupInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 18px;"
},
text: ["Filter"],
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-base",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
style: "mandatory",
_idProps: {
service: idService,
name: "Team_Label"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Team"), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Ux51WKOXh0qcPAPNAJisYg.Style"), function () {
return ((model.variables.showTeamsErrorVar) ? ("validated-dev not-valid") : (""));
}, function () {
return model.variables.showTeamsErrorVar;
}),
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(MSD_MSD_MSD_mvc_view, {
inputs: {
MaxCharBeforeEllipsis: 20,
SelectAllEnabled: true,
EmptySearchText: "Select",
DisplayList: model.getCachedValue(idService.getId("MSD_Team.DisplayList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getTeamsAggr.listOut, new PHICoreModel.MSD_ItemList(), function (source, target) {
target.isSelectedAttr = false;
target.itemIdAttr = OS.BuiltinFunctions.longIntegerToText(source.teamAttr.idAttr);
target.descriptionAttr = source.teamAttr.nameAttr;
return target;
});
}, function () {
return model.variables.getTeamsAggr.listOut;
}),
_displayListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsAggr.dataFetchStatusAttr),
ItemList: model.variables.graphFilterStrucIn.selectedTeamAttr,
_itemListInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._graphFilterStrucInDataFetchStatus),
SearchEnabled: false,
AriaLabel: "Team"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
sendSelectedList$Action: function (selectedItemListIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD SendSelectedList");
controller.onChange_Teams$Action(selectedItemListIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onInitialized$Action: function (widgetIdIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD OnInitialized");
controller.onInitialized_MSD_Team$Action(widgetIdIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "MSD_Team",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
optionsDescription: PlaceholderContent.Empty
},
_dependencies: []
})), $if(model.variables.showTeamsErrorVar, false, this, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: model.getCachedValue(idService.getId("AfjRtj3iA0OzuYe0flsSCw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}),
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Dropdown_TimePeriod",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Time Period"), React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService
},
dropdownMode: /*Text*/ 0,
enabled: true,
labels: function (elem) {
return elem.dropdownItemAttr.textAttr;
},
list: model.variables.entryDateDropdownListVar,
mandatory: true,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter/Dropdown_TimePeriod OnChange");
controller.onChange_TimePeriod$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "dropdown",
values: function (elem) {
return elem.dropdownItemAttr.valueAttr;
},
variable: model.createVariable(OS.Types.Text, model.variables.graphFilterStrucIn.timePeriodAttr, function (value) {
model.variables.graphFilterStrucIn.timePeriodAttr = value;
}),
_idProps: {
service: idService,
name: "Dropdown_TimePeriod"
},
_widgetRecordProvider: widgetsRecordProvider,
variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._graphFilterStrucInDataFetchStatus),
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter/Button_Cancel OnClick");
return controller.onClick_Cancel$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
name: "Button_Cancel"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Cancel")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter/Button_Clear OnClick");
return controller.onClick_Clear$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
name: "Button_Clear"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Clear"), React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter/Button_Apply OnClick");
return controller.onClick_Apply$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "Button_Apply"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Apply"))), $if(((model.variables.teamWidgetIdVar) !== ("")), false, this, function () {
return [React.createElement(Common_CW_PHICore_CW_PreviousFocus_mvc_view, {
inputs: {
CurrentElement: ("#" + model.variables.teamWidgetIdVar),
CurrentWidgetId: idService.getId("PreviousFocus"),
PreviousElement: ("#" + idService.getId("Button_Apply"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "PreviousFocus",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_NextFocus_mvc_view, {
inputs: {
NextElement: ("#" + model.variables.teamWidgetIdVar),
CurrentElement: ("#" + idService.getId("Button_Apply")),
CurrentWidgetId: idService.getId("NextFocus")
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "NextFocus",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.GraphFilter.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.GraphFilter.mvc$debugger", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$DropdownItemRecordList", "PHICore.model$MSD_ItemList", "PHICore.model$GraphFilterStrucRec", "Common_CW.controller$Set_Focus", "PHICore.controller$AddAriaLabel", "PHICore.model$DropdownItemRecord", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TeamTeamUserRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_GraphFilter_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getTeams$AggrRefresh: 0
};
this.dataFetchDependentsGraph = {
getTeams$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getTeams$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:7w4sh30S+Ume+9tKkxZNuQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ScreenDataSets.7w4sh30S+Ume+9tKkxZNuQ:E_11h0meRjzX57wBvi50Tw", "PHICore", "GetTeams", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/GraphFilter/GetTeams");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeams", "screenservices/PHICore/Common_Widgets/GraphFilter/ScreenDataSetGetTeams", "7HsCFYxVu9IaYXzw8g21ww", maxRecords, startIndex, function (b) {
model.variables.getTeamsAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamsAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:7w4sh30S+Ume+9tKkxZNuQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTeams$AggrRefresh"];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:qs25Wz1na0+JfqBnwsNaUQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.qs25Wz1na0+JfqBnwsNaUQ:fM3ruyJJEj6IPO02T4RO4Q", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MtKNpEl9rU+LdRF3aIcQkQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gwzgLJXTnESy1r3NOeWgAg", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.showPopupIn, model.variables.teamWidgetIdVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1zd2WIieEWO6FyUKQBPgg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:qs25Wz1na0+JfqBnwsNaUQ", callContext.id);
}

};
Controller.prototype._onClick_Cancel$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Cancel");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:M6+cbv4mQUC0TVTRVVtAoQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.M6+cbv4mQUC0TVTRVVtAoQ:USELvxJD1lhYayIkM4l5KQ", "PHICore", "OnClick_Cancel", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2c5nsLrS0k6x8fwrmy3o0Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oXaVZMXMkkWoKf3a2jJ4Ng", callContext.id);
// Trigger Event: Event_Filter
return controller.event_Filter$Action(model.variables.graphFilterStrucIn, true, false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:X9BY0J0STEm289acAhbDKg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:M6+cbv4mQUC0TVTRVVtAoQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:M6+cbv4mQUC0TVTRVVtAoQ", callContext.id);
throw ex;

});
};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:cYwjetDZl0CiiIbK4hkP9w:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.cYwjetDZl0CiiIbK4hkP9w:O2_opOIH6pY8JeladUgb4g", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WuVjFP5WgE2FxE2Lmsjsng", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e927Wp2da0uj8jfkzQXpQg", callContext.id);
// TempTeams = GraphFilterStruc.SelectedTeam
model.variables.tempTeamsVar = model.variables.graphFilterStrucIn.selectedTeamAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e927Wp2da0uj8jfkzQXpQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CallToRefresh = CallToRefresh
model.variables.callToRefreshIn = model.variables.callToRefreshIn;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Tu_3l1GcZkSvLyazKftk5Q", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.showPopupIn, model.variables.teamWidgetIdVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Yin7p2GJ+ky3if_cclo1Zg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:cYwjetDZl0CiiIbK4hkP9w", callContext.id);
}

};
Controller.prototype._onInitialized_MSD_Team$Action = function (widgetIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialized_MSD_Team");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.GraphFilter.OnInitialized_MSD_Team$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:q4dElKwnKUid4ro54jFlfQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.q4dElKwnKUid4ro54jFlfQ:1iwK2wbEzLwAakLoq5O6kw", "PHICore", "OnInitialized_MSD_Team", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wjuhEDj_SUewa2U5LpIZMQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ih6XfY5P10+NmvNRO+cNKA", callContext.id);
// TeamWidgetId = WidgetId
model.variables.teamWidgetIdVar = vars.value.widgetIdInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o9i7kK_XtEK_Qit7NVIv4A", callContext.id);
// Execute Action: AddAriaLabel
PHICoreController.default.addAriaLabel$Action(vars.value.widgetIdInLocal, "Team", callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eG7sPYW+8UaUMt63iCsE6w", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.showPopupIn, model.variables.teamWidgetIdVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3zYVxyYbj06kfYieYAHkzg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:q4dElKwnKUid4ro54jFlfQ", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.GraphFilter.OnInitialized_MSD_Team$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onClick_Apply$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Apply");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:yJDDnFmnX02C8BalxWJHVg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.yJDDnFmnX02C8BalxWJHVg:GqxbgZrD2WyDanj_3LkmLA", "PHICore", "OnClick_Apply", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pNG8arnAqUCCy67FHx5c7g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bRckfYHd3EufyKo0VNiVig", callContext.id);
// GraphFilterStruc.SelectedTeam = TempTeams
model.variables.graphFilterStrucIn.selectedTeamAttr = model.variables.tempTeamsVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kA1e_Ite1k2vZl2yRpZ6QQ", callContext.id);
// Execute Action: Validate
controller._validate$Action(callContext);
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:44hpKybqgUiBXo+Q7lnrqQ", callContext.id) && (!(model.widgets.get(idService.getId("Dropdown_TimePeriod")).validAttr) || model.variables.showTeamsErrorVar))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nZXu1pgg1kSprxukLcDHvQ", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Errors have occurred, please review highlighted fields", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XUC07TfFfUudvAuirSBLYw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FACFsYhWLk2_R6jRUz45SQ", callContext.id);
// Trigger Event: Event_Filter
return controller.event_Filter$Action(model.variables.graphFilterStrucIn, true, true, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O81xQBsVUE633XVpWXA9ow", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:yJDDnFmnX02C8BalxWJHVg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:yJDDnFmnX02C8BalxWJHVg", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:JzGfr1BKcUCVBc3ewwrqJg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.JzGfr1BKcUCVBc3ewwrqJg:2VXk0kw_h3HIo2V4NIanVQ", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CfKw38QLH0iJ_MsX84qchg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ariRUKxo+ka7vPZ+bxoAKA", callContext.id);
// Execute Action: EntryDateInitialization
OS.SystemActions.listAppendAll(model.variables.entryDateDropdownListVar, function () {
var list = new PHICoreModel.DropdownItemRecordList();
list.pushAll([function () {
var rec = new PHICoreModel.DropdownItemRecord();
rec.dropdownItemAttr = function () {
var rec = new OutSystemsUIModel.DropdownItemRec();
rec.valueAttr = "1";
rec.textAttr = "Last 24 hrs";
return rec;
}();
return rec;
}(), function () {
var rec = new PHICoreModel.DropdownItemRecord();
rec.dropdownItemAttr = function () {
var rec = new OutSystemsUIModel.DropdownItemRec();
rec.valueAttr = "7";
rec.textAttr = "Last 7 days";
return rec;
}();
return rec;
}(), function () {
var rec = new PHICoreModel.DropdownItemRecord();
rec.dropdownItemAttr = function () {
var rec = new OutSystemsUIModel.DropdownItemRec();
rec.valueAttr = "30";
rec.textAttr = "Last 30 days";
return rec;
}();
return rec;
}()]);
return list;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y4vZoo4fikSjmSDBWrnSfQ", callContext.id);
// TempTeams = GraphFilterStruc.SelectedTeam
model.variables.tempTeamsVar = model.variables.graphFilterStrucIn.selectedTeamAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3cLOMwXyrEKzIhz616Gv+A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JzGfr1BKcUCVBc3ewwrqJg", callContext.id);
}

};
Controller.prototype._validate$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Validate");
callContext = controller.callContext(callContext);
var listAnyVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listAnyVar = listAnyVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:S7kYti70U0KWc3D_TovcKA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.S7kYti70U0KWc3D_TovcKA:ejMb+ajYshXrp_n55juLzw", "PHICore", "Validate", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LhLFnmADUEOKAbUfhA9T+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Gth_V8rLqE+kk47asD0bGg", callContext.id);
// Execute Action: ListAny
listAnyVar.value = OS.SystemActions.listAny(model.variables.tempTeamsVar, function (p) {
return p.isSelectedAttr;
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ru6jIRoqKUuEc6KlsGybSg", callContext.id) && !(listAnyVar.value.resultOut))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f6Op6US0tU2jeNbPpAfHiA", callContext.id);
// ShowTeamsError = True
model.variables.showTeamsErrorVar = true;
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Lfb0PNvdP02lCEloD9nMSA", callContext.id) && (model.variables.graphFilterStrucIn.timePeriodAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PMoe2ajx70S7ZMgRG8z2bQ", callContext.id);
// Dropdown_TimePeriod.Valid = False
model.widgets.get(idService.getId("Dropdown_TimePeriod")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PMoe2ajx70S7ZMgRG8z2bQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Dropdown_TimePeriod.ValidationMessage = GetRequiredFieldMsg()
model.widgets.get(idService.getId("Dropdown_TimePeriod")).validationMessageAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UEOQRj+rCU26Pxe14WOVeg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UEOQRj+rCU26Pxe14WOVeg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:S7kYti70U0KWc3D_TovcKA", callContext.id);
}

};
Controller.prototype._onChange_TimePeriod$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_TimePeriod");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:JeFxvFYOBkSxsfS+lpWNWA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.JeFxvFYOBkSxsfS+lpWNWA:7683HE8k4JaWyWo12hjGBg", "PHICore", "OnChange_TimePeriod", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bcSrV1MBYUOwpBj_LM_jcw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vocix_GGMEqMyk0Tw+b2rA", callContext.id);
// Dropdown_TimePeriod.Valid = True
model.widgets.get(idService.getId("Dropdown_TimePeriod")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vocix_GGMEqMyk0Tw+b2rA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Dropdown_TimePeriod.ValidationMessage = ""
model.widgets.get(idService.getId("Dropdown_TimePeriod")).validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7XD_bTPMH0ORzRUIWcxlmA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JeFxvFYOBkSxsfS+lpWNWA", callContext.id);
}

};
Controller.prototype._onClick_Clear$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Clear");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:92VG1UO0EkiVDAZxjJMycg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.92VG1UO0EkiVDAZxjJMycg:w31efFXPnXAUvhOH+5RPjA", "PHICore", "OnClick_Clear", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1umslzkiG0Kutw9FTrnJmw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hc3NGjjhrUCBw9Q7wgWW7Q", callContext.id);
// ShowTeamsError = False
model.variables.showTeamsErrorVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lSM_b2AgZkCaY8XFJT0pww", callContext.id);
// Trigger Event: Event_Filter
return controller.event_Filter$Action(model.variables.graphFilterStrucIn, false, true, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_+cUC5Ef50mphLLijxQDbw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:92VG1UO0EkiVDAZxjJMycg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:92VG1UO0EkiVDAZxjJMycg", callContext.id);
throw ex;

});
};
Controller.prototype._onChange_Teams$Action = function (selectedItemListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_Teams");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.GraphFilter.OnChange_Teams$vars"))());
vars.value.selectedItemListInLocal = selectedItemListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:hUuY8kKnjkiW6WTKzB5jtw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg/ClientActions.hUuY8kKnjkiW6WTKzB5jtw:zVaOaVDaUAWiq3hXjVfxAg", "PHICore", "OnChange_Teams", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bcYuGzuJAUSeHNy6C4Jdqw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M12sgth5ZEe9Ut+Hl0ZzRw", callContext.id);
// TempTeams = SelectedItemList
model.variables.tempTeamsVar = vars.value.selectedItemListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M12sgth5ZEe9Ut+Hl0ZzRw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShowTeamsError = False
model.variables.showTeamsErrorVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M12sgth5ZEe9Ut+Hl0ZzRw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// GraphFilterStruc.SelectedTeam = TempTeams
model.variables.graphFilterStrucIn.selectedTeamAttr = model.variables.tempTeamsVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4jwxnCkiakqREIyja7HUkQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:hUuY8kKnjkiW6WTKzB5jtw", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.GraphFilter.OnChange_Teams$vars", [{
name: "SelectedItemList",
attrName: "selectedItemListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MSD_ItemList();
},
complexType: PHICoreModel.MSD_ItemList
}]);

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onClick_Cancel$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Cancel$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onInitialized_MSD_Team$Action = function (widgetIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialized_MSD_Team$Action, callContext, widgetIdIn);

};
Controller.prototype.onClick_Apply$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Apply$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.validate$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._validate$Action, callContext);

};
Controller.prototype.onChange_TimePeriod$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_TimePeriod$Action, callContext);

};
Controller.prototype.onClick_Clear$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Clear$Action, callContext);

};
Controller.prototype.onChange_Teams$Action = function (selectedItemListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_Teams$Action, callContext, selectedItemListIn);

};
Controller.prototype.event_Filter$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:3DeU8ohDU0+slKbTrM8CPg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.3DeU8ohDU0+slKbTrM8CPg:3MeIeawHWQDcfOmqGJuk0A", "PHICore", "GraphFilter", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:3DeU8ohDU0+slKbTrM8CPg", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/GraphFilter On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/GraphFilter On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/GraphFilter On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.GraphFilter.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"hvVql9lSqUeRZSIWmOmA5w": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Gth_V8rLqE+kk47asD0bGg": {
getter: function (varBag, idService) {
return varBag.listAnyVar.value;
}
},
"5bbrCBShv0SgTM2BLphaRg": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedItemListInLocal;
}
},
"tmMxtup79E+4Astzb+i9xQ": {
getter: function (varBag, idService) {
return varBag.model.variables.entryDateDropdownListVar;
}
},
"c6J7cc1U+06CYR1Mtsna8g": {
getter: function (varBag, idService) {
return varBag.model.variables.tempTeamsVar;
}
},
"A3pBhG4rjUKOkEhercLr0Q": {
getter: function (varBag, idService) {
return varBag.model.variables.showTeamsErrorVar;
},
dataType: OS.Types.Boolean
},
"0L7xd632HEaDpZ03wEwHLA": {
getter: function (varBag, idService) {
return varBag.model.variables.teamWidgetIdVar;
},
dataType: OS.Types.Text
},
"2qbYF+lb002fNAClFrTl1w": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopupIn;
},
dataType: OS.Types.Boolean
},
"6Sk+YsvnZEGrCETI5O4weQ": {
getter: function (varBag, idService) {
return varBag.model.variables.graphFilterStrucIn;
}
},
"7dOP5RJTM0+Xtf_7BzDILg": {
getter: function (varBag, idService) {
return varBag.model.variables.callToRefreshIn;
},
dataType: OS.Types.Text
},
"7w4sh30S+Ume+9tKkxZNuQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamsAggr;
}
},
"p35GDl__0UyFpy9jhzPdHQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Team_Label"));
})(varBag.model, idService);
}
},
"jAjeLRfyIkKafWg9ViGk_g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MSD_Team"));
})(varBag.model, idService);
}
},
"kVI9vw75k02CBiDqeih3Qw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("OptionsDescription"));
})(varBag.model, idService);
}
},
"D4rvGKoU20OKlI9gn6DBLw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_TimePeriod"));
})(varBag.model, idService);
}
},
"rctCYm6TZ0a0IN_QDvnALQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button_Cancel"));
})(varBag.model, idService);
}
},
"sd_cmDmIl0+6j7SWatpisA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button_Clear"));
})(varBag.model, idService);
}
},
"DKLN5kr2kEi5vr58dJ0Oaw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button_Apply"));
})(varBag.model, idService);
}
},
"SjYL56Rh_kqAuQpbIUQTPQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreviousFocus"));
})(varBag.model, idService);
}
},
"k3SvTW1_LE6zN8yRyMhlxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NextFocus"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
