define("MSD.model$SpaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "MSD.model", "OutSystemsUI.model$SpaceRec", "MSD.referencesHealth", "MSD.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, MSDModel) {
var OS = OutSystems.Internal;
var SpaceRecord = (function (_super) {
__extends(SpaceRecord, _super);
function SpaceRecord(defaults) {
_super.apply(this, arguments);
}
SpaceRecord.attributesToDeclare = function () {
return [
this.attr("Space", "spaceAttr", "Space", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SpaceRec());
}, true, OutSystemsUIModel.SpaceRec)
].concat(_super.attributesToDeclare.call(this));
};
SpaceRecord.fromStructure = function (str) {
return new SpaceRecord(new SpaceRecord.RecordClass({
spaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpaceRecord._isAnonymousRecord = true;
SpaceRecord.UniqueId = "9589ecc0-6297-88c2-aca6-b47bcbae782c";
SpaceRecord.init();
return SpaceRecord;
})(OS.DataTypes.GenericRecord);
MSDModel.SpaceRecord = SpaceRecord;

});
define("MSD.model$SpaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.model$SpaceRecord"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var SpaceRecordList = (function (_super) {
__extends(SpaceRecordList, _super);
function SpaceRecordList(defaults) {
_super.apply(this, arguments);
}
SpaceRecordList.itemType = MSDModel.SpaceRecord;
return SpaceRecordList;
})(OS.DataTypes.GenericRecordList);
MSDModel.SpaceRecordList = SpaceRecordList;

});
define("MSD.model$SpaceList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "MSD.model", "OutSystemsUI.model$SpaceRec", "MSD.referencesHealth", "MSD.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, MSDModel) {
var OS = OutSystems.Internal;
var SpaceList = (function (_super) {
__extends(SpaceList, _super);
function SpaceList(defaults) {
_super.apply(this, arguments);
}
SpaceList.itemType = OutSystemsUIModel.SpaceRec;
return SpaceList;
})(OS.DataTypes.GenericRecordList);
MSDModel.SpaceList = SpaceList;

});
define("MSD.model$MSD_ItemRec", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var MSD_ItemRec = (function (_super) {
__extends(MSD_ItemRec, _super);
function MSD_ItemRec(defaults) {
_super.apply(this, arguments);
}
MSD_ItemRec.attributesToDeclare = function () {
return [
this.attr("IsSelected", "isSelectedAttr", "IsSelected", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ItemId", "itemIdAttr", "ItemId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsDisabled", "isDisabledAttr", "IsDisabled", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MSD_ItemRec.init();
return MSD_ItemRec;
})(OS.DataTypes.GenericRecord);
MSDModel.MSD_ItemRec = MSD_ItemRec;

});
define("MSD.model$MSD_ItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.model$MSD_ItemRec"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var MSD_ItemRecord = (function (_super) {
__extends(MSD_ItemRecord, _super);
function MSD_ItemRecord(defaults) {
_super.apply(this, arguments);
}
MSD_ItemRecord.attributesToDeclare = function () {
return [
this.attr("MSD_Item", "mSD_ItemAttr", "MSD_Item", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemRec());
}, true, MSDModel.MSD_ItemRec)
].concat(_super.attributesToDeclare.call(this));
};
MSD_ItemRecord.fromStructure = function (str) {
return new MSD_ItemRecord(new MSD_ItemRecord.RecordClass({
mSD_ItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MSD_ItemRecord._isAnonymousRecord = true;
MSD_ItemRecord.UniqueId = "77876896-9ddf-f445-2c03-3e03578bf347";
MSD_ItemRecord.init();
return MSD_ItemRecord;
})(OS.DataTypes.GenericRecord);
MSDModel.MSD_ItemRecord = MSD_ItemRecord;

});
define("MSD.model$MSD_ItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.model$MSD_ItemRecord"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var MSD_ItemRecordList = (function (_super) {
__extends(MSD_ItemRecordList, _super);
function MSD_ItemRecordList(defaults) {
_super.apply(this, arguments);
}
MSD_ItemRecordList.itemType = MSDModel.MSD_ItemRecord;
return MSD_ItemRecordList;
})(OS.DataTypes.GenericRecordList);
MSDModel.MSD_ItemRecordList = MSD_ItemRecordList;

});
define("MSD.model$ColorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "MSD.model", "OutSystemsUI.model$ColorRec", "MSD.referencesHealth", "MSD.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, MSDModel) {
var OS = OutSystems.Internal;
var ColorRecord = (function (_super) {
__extends(ColorRecord, _super);
function ColorRecord(defaults) {
_super.apply(this, arguments);
}
ColorRecord.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColorRec());
}, true, OutSystemsUIModel.ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
ColorRecord.fromStructure = function (str) {
return new ColorRecord(new ColorRecord.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRecord._isAnonymousRecord = true;
ColorRecord.UniqueId = "87351e3b-0fa2-ca59-cf6c-6749c6405006";
ColorRecord.init();
return ColorRecord;
})(OS.DataTypes.GenericRecord);
MSDModel.ColorRecord = ColorRecord;

});
define("MSD.model$MSD_ItemList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.model$MSD_ItemRec"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var MSD_ItemList = (function (_super) {
__extends(MSD_ItemList, _super);
function MSD_ItemList(defaults) {
_super.apply(this, arguments);
}
MSD_ItemList.itemType = MSDModel.MSD_ItemRec;
return MSD_ItemList;
})(OS.DataTypes.GenericRecordList);
MSDModel.MSD_ItemList = MSD_ItemList;

});
define("MSD.model$ColorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.model$ColorRecord"], function (exports, OutSystems, MSDModel) {
var OS = OutSystems.Internal;
var ColorRecordList = (function (_super) {
__extends(ColorRecordList, _super);
function ColorRecordList(defaults) {
_super.apply(this, arguments);
}
ColorRecordList.itemType = MSDModel.ColorRecord;
return ColorRecordList;
})(OS.DataTypes.GenericRecordList);
MSDModel.ColorRecordList = ColorRecordList;

});
define("MSD.model$ColorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "MSD.model", "OutSystemsUI.model$ColorRec", "MSD.referencesHealth", "MSD.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, MSDModel) {
var OS = OutSystems.Internal;
var ColorList = (function (_super) {
__extends(ColorList, _super);
function ColorList(defaults) {
_super.apply(this, arguments);
}
ColorList.itemType = OutSystemsUIModel.ColorRec;
return ColorList;
})(OS.DataTypes.GenericRecordList);
MSDModel.ColorList = ColorList;

});
define("MSD.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var MSDModel = exports;
Object.defineProperty(MSDModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["9366b308-80ba-42de-9c91-159237a93907"];
}
});

MSDModel.staticEntities = {};
MSDModel.staticEntities.space = {};
var getSpaceRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["8fb3d471-82a4-439c-9cc1-0555dfa91451"][record];
};
Object.defineProperty(MSDModel.staticEntities.space, "large", {
get: function () {
return getSpaceRecord("51b55067-e608-49ed-9f00-1faf9e4a694a");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "medium", {
get: function () {
return getSpaceRecord("7340e97f-de64-4337-ad0d-1defcab8adb2");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "xXLarge", {
get: function () {
return getSpaceRecord("823213f8-9df9-4de0-8aba-2b5566e6f87d");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "extraSmall", {
get: function () {
return getSpaceRecord("83adf9ba-fbcf-4ce0-b4a4-bc6330956b89");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "small", {
get: function () {
return getSpaceRecord("919210a5-6b3b-40c9-9a28-b4e2c28a46f8");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "base", {
get: function () {
return getSpaceRecord("f0572ad3-54ac-4755-8c8e-a9004171fcb1");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "extraLarge", {
get: function () {
return getSpaceRecord("f8dafab9-63b9-40b2-9755-f2f8fa3d6e84");
}
});

Object.defineProperty(MSDModel.staticEntities.space, "none", {
get: function () {
return getSpaceRecord("fb937b97-bd94-4ba4-80ff-446cb3bdf6ae");
}
});

MSDModel.staticEntities.color = {};
var getColorRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["cb6d1da7-26d4-45d9-bc22-9a4c482e6ce2"][record];
};
Object.defineProperty(MSDModel.staticEntities.color, "neutral9", {
get: function () {
return getColorRecord("04a6c700-0ae5-44d5-81ce-34ec81d72c1c");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "grape", {
get: function () {
return getColorRecord("0d81324f-81ae-44eb-b81e-cd27ebce7460");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral7", {
get: function () {
return getColorRecord("1434454b-4d44-4ec7-a9ee-8353529b1621");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral10", {
get: function () {
return getColorRecord("1566893e-a30d-405f-878b-e64efdab7f7b");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "teal", {
get: function () {
return getColorRecord("19254415-08b2-4887-a6cf-36433bb1ade0");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "primary", {
get: function () {
return getColorRecord("1df261bf-454e-49a0-951e-87f6077cbbc1");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral4", {
get: function () {
return getColorRecord("20d4e7d1-c296-4853-b584-d2b004ddf9f5");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral8", {
get: function () {
return getColorRecord("31cd8495-438d-4825-8a93-c083bf6f016a");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "indigo", {
get: function () {
return getColorRecord("47b9565a-4f82-4a9d-a543-4aaa707853ac");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "orange", {
get: function () {
return getColorRecord("4d20d5b8-5570-4e18-9345-55772434a9ad");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "lime", {
get: function () {
return getColorRecord("50b20d51-09a6-43df-aa5d-6ae3c99f31e8");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "cyan", {
get: function () {
return getColorRecord("59edafdd-089e-409e-a2d2-78298e55e0f2");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "secondary", {
get: function () {
return getColorRecord("61f545b9-e074-40ee-a884-8102a56d9ee7");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral6", {
get: function () {
return getColorRecord("69c65fbc-5ddc-4e41-afcf-03acff40e7a8");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "yellow", {
get: function () {
return getColorRecord("80145099-0e84-4301-902b-2bd6a933e319");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral2", {
get: function () {
return getColorRecord("8577e423-4296-434f-9ca1-9a18b91e0c29");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral1", {
get: function () {
return getColorRecord("9946980c-176a-4345-90ff-312523579ef0");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral3", {
get: function () {
return getColorRecord("b7447296-c2b5-4d01-883b-b49d25b1c8a6");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "transparent", {
get: function () {
return getColorRecord("b87c59d9-4a95-4567-876d-b978ca413429");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "violet", {
get: function () {
return getColorRecord("bb39306e-ce82-47a7-9c0f-a78f92ff53c6");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "blue", {
get: function () {
return getColorRecord("c1bb8b1b-2f09-4fe9-bec9-eeb243b903d5");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral5", {
get: function () {
return getColorRecord("c1d63249-fde7-4438-b4c9-d445bcfc9257");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "red", {
get: function () {
return getColorRecord("d6c564f5-847a-4155-ba84-91b826bd676f");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "pink", {
get: function () {
return getColorRecord("e9991560-a98c-431e-a583-b707840dc2f3");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "green", {
get: function () {
return getColorRecord("ede4099b-595f-47f0-98ed-583414f4f6bd");
}
});

Object.defineProperty(MSDModel.staticEntities.color, "neutral0", {
get: function () {
return getColorRecord("fb934ce5-6b33-4c96-8d40-b06352706a8d");
}
});

});
