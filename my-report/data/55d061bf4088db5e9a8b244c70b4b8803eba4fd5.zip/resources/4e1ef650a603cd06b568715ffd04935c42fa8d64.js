define("InputMaskReactive.model$OptionalLongIntegerRec", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var OptionalLongIntegerRec = (function (_super) {
__extends(OptionalLongIntegerRec, _super);
function OptionalLongIntegerRec(defaults) {
_super.apply(this, arguments);
}
OptionalLongIntegerRec.attributesToDeclare = function () {
return [
this.attr("IsEmpty", "isEmptyAttr", "IsEmpty", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LongInteger", "longIntegerAttr", "LongInteger", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OptionalLongIntegerRec.init();
return OptionalLongIntegerRec;
})(OS.DataTypes.GenericRecord);
InputMaskReactiveModel.OptionalLongIntegerRec = OptionalLongIntegerRec;

});
define("InputMaskReactive.model$", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.Types.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
InputMaskReactiveModel.TextList = TextList;

});
define("InputMaskReactive.model$NumberMaskConfigRec", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$OptionalLongIntegerRec"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var NumberMaskConfigRec = (function (_super) {
__extends(NumberMaskConfigRec, _super);
function NumberMaskConfigRec(defaults) {
_super.apply(this, arguments);
}
NumberMaskConfigRec.attributesToDeclare = function () {
return [
this.attr("Scale", "scaleAttr", "Scale", false, false, OS.Types.Integer, function () {
return 2;
}, true), 
this.attr("Signed", "signedAttr", "Signed", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ThousandsSeparator", "thousandsSeparatorAttr", "ThousandsSeparator", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PadFractionalZeros", "padFractionalZerosAttr", "PadFractionalZeros", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("NormalizeZeros", "normalizeZerosAttr", "NormalizeZeros", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("Radix", "radixAttr", "Radix", false, false, OS.Types.Text, function () {
return ",";
}, true), 
this.attr("MapToRadix", "mapToRadixAttr", "MapToRadix", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList), 
this.attr("Min", "minAttr", "Min", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InputMaskReactiveModel.OptionalLongIntegerRec());
}, true, InputMaskReactiveModel.OptionalLongIntegerRec), 
this.attr("Max", "maxAttr", "Max", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InputMaskReactiveModel.OptionalLongIntegerRec());
}, true, InputMaskReactiveModel.OptionalLongIntegerRec)
].concat(_super.attributesToDeclare.call(this));
};
NumberMaskConfigRec.init();
return NumberMaskConfigRec;
})(OS.DataTypes.GenericRecord);
InputMaskReactiveModel.NumberMaskConfigRec = NumberMaskConfigRec;

});
define("InputMaskReactive.model$NumberMaskConfigList", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$NumberMaskConfigRec"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var NumberMaskConfigList = (function (_super) {
__extends(NumberMaskConfigList, _super);
function NumberMaskConfigList(defaults) {
_super.apply(this, arguments);
}
NumberMaskConfigList.itemType = InputMaskReactiveModel.NumberMaskConfigRec;
return NumberMaskConfigList;
})(OS.DataTypes.GenericRecordList);
InputMaskReactiveModel.NumberMaskConfigList = NumberMaskConfigList;

});
define("InputMaskReactive.model$NumberMaskConfigRecord", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$NumberMaskConfigRec"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var NumberMaskConfigRecord = (function (_super) {
__extends(NumberMaskConfigRecord, _super);
function NumberMaskConfigRecord(defaults) {
_super.apply(this, arguments);
}
NumberMaskConfigRecord.attributesToDeclare = function () {
return [
this.attr("NumberMaskConfig", "numberMaskConfigAttr", "NumberMaskConfig", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InputMaskReactiveModel.NumberMaskConfigRec());
}, true, InputMaskReactiveModel.NumberMaskConfigRec)
].concat(_super.attributesToDeclare.call(this));
};
NumberMaskConfigRecord.fromStructure = function (str) {
return new NumberMaskConfigRecord(new NumberMaskConfigRecord.RecordClass({
numberMaskConfigAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
NumberMaskConfigRecord._isAnonymousRecord = true;
NumberMaskConfigRecord.UniqueId = "45d8ed9e-33bf-3e08-ca4b-7905b9146bd3";
NumberMaskConfigRecord.init();
return NumberMaskConfigRecord;
})(OS.DataTypes.GenericRecord);
InputMaskReactiveModel.NumberMaskConfigRecord = NumberMaskConfigRecord;

});
define("InputMaskReactive.model$OptionalLongIntegerRecord", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$OptionalLongIntegerRec"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var OptionalLongIntegerRecord = (function (_super) {
__extends(OptionalLongIntegerRecord, _super);
function OptionalLongIntegerRecord(defaults) {
_super.apply(this, arguments);
}
OptionalLongIntegerRecord.attributesToDeclare = function () {
return [
this.attr("OptionalLongInteger", "optionalLongIntegerAttr", "OptionalLongInteger", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InputMaskReactiveModel.OptionalLongIntegerRec());
}, true, InputMaskReactiveModel.OptionalLongIntegerRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalLongIntegerRecord.fromStructure = function (str) {
return new OptionalLongIntegerRecord(new OptionalLongIntegerRecord.RecordClass({
optionalLongIntegerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalLongIntegerRecord._isAnonymousRecord = true;
OptionalLongIntegerRecord.UniqueId = "791662ae-92f2-8c55-ff36-81cd0ee4845b";
OptionalLongIntegerRecord.init();
return OptionalLongIntegerRecord;
})(OS.DataTypes.GenericRecord);
InputMaskReactiveModel.OptionalLongIntegerRecord = OptionalLongIntegerRecord;

});
define("InputMaskReactive.model$OptionalLongIntegerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$OptionalLongIntegerRecord"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var OptionalLongIntegerRecordList = (function (_super) {
__extends(OptionalLongIntegerRecordList, _super);
function OptionalLongIntegerRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalLongIntegerRecordList.itemType = InputMaskReactiveModel.OptionalLongIntegerRecord;
return OptionalLongIntegerRecordList;
})(OS.DataTypes.GenericRecordList);
InputMaskReactiveModel.OptionalLongIntegerRecordList = OptionalLongIntegerRecordList;

});
define("InputMaskReactive.model$NumberMaskConfigRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$NumberMaskConfigRecord"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var NumberMaskConfigRecordList = (function (_super) {
__extends(NumberMaskConfigRecordList, _super);
function NumberMaskConfigRecordList(defaults) {
_super.apply(this, arguments);
}
NumberMaskConfigRecordList.itemType = InputMaskReactiveModel.NumberMaskConfigRecord;
return NumberMaskConfigRecordList;
})(OS.DataTypes.GenericRecordList);
InputMaskReactiveModel.NumberMaskConfigRecordList = NumberMaskConfigRecordList;

});
define("InputMaskReactive.model$OptionalLongIntegerList", ["exports", "OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.model$OptionalLongIntegerRec"], function (exports, OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;
var OptionalLongIntegerList = (function (_super) {
__extends(OptionalLongIntegerList, _super);
function OptionalLongIntegerList(defaults) {
_super.apply(this, arguments);
}
OptionalLongIntegerList.itemType = InputMaskReactiveModel.OptionalLongIntegerRec;
return OptionalLongIntegerList;
})(OS.DataTypes.GenericRecordList);
InputMaskReactiveModel.OptionalLongIntegerList = OptionalLongIntegerList;

});
define("InputMaskReactive.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var InputMaskReactiveModel = exports;
Object.defineProperty(InputMaskReactiveModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["f7531ce2-7082-45fa-950d-0d01c86643d8"];
}
});

InputMaskReactiveModel.staticEntities = {};
});
