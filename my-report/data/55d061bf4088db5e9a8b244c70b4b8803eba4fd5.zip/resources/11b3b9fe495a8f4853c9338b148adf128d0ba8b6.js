define("PHICore_TH.Common.UserInfo.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "OutSystemsUI.Navigation.Submenu.mvc$model"], function (OutSystems, PHICore_THModel, OutSystemsUI_Navigation_Submenu_mvcModel) {
var OS = OutSystems.Internal;

var GetUserByIdDataActRec = (function (_super) {
__extends(GetUserByIdDataActRec, _super);
function GetUserByIdDataActRec(defaults) {
_super.apply(this, arguments);
}
GetUserByIdDataActRec.attributesToDeclare = function () {
return [
this.attr("IdUsername", "idUsernameOut", "IdUsername", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetUserByIdDataActRec.fromStructure = function (str) {
return new GetUserByIdDataActRec(new GetUserByIdDataActRec.RecordClass({
idUsernameOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetUserByIdDataActRec.init();
return GetUserByIdDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowExitFundView", "showExitFundViewIn", "ShowExitFundView", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showExitFundViewInDataFetchStatus", "_showExitFundViewInDataFetchStatus", "_showExitFundViewInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetUserById", "getUserByIdDataAct", "getUserByIdDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetUserByIdDataActRec());
}, true, GetUserByIdDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = OutSystemsUI_Navigation_Submenu_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("ShowExitFundView" in inputs) {
this.variables.showExitFundViewIn = inputs.ShowExitFundView;
if("_showExitFundViewInDataFetchStatus" in inputs) {
this.variables._showExitFundViewInDataFetchStatus = inputs._showExitFundViewInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common.UserInfo");
});
define("PHICore_TH.Common.UserInfo.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "react", "OutSystems/ReactView/Main", "PHICore_TH.Common.UserInfo.mvc$model", "PHICore_TH.Common.UserInfo.mvc$controller", "PHICore_TH.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Navigation.Submenu.mvc$view"], function (OutSystems, PHICore_THModel, PHICore_THController, React, OSView, PHICore_TH_Common_UserInfo_mvc_model, PHICore_TH_Common_UserInfo_mvc_controller, PHICore_THClientVariables, OSWidgets, OutSystemsUI_Navigation_Submenu_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.UserInfo";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/PHICore_TH.Common.UserInfo.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Navigation_Submenu_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_TH_Common_UserInfo_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_TH_Common_UserInfo_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "user-info",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(((OS.BuiltinFunctions.getUserId()) !== (OS.BuiltinFunctions.nullIdentifier())), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Navigation_Submenu_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
menu: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
style: "white-space-nowrap",
value: PHICore_THClientVariables.getUsername(),
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
items: new PlaceholderContent(function () {
return [$if(model.variables.showExitFundViewIn, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "user-logout border-bottom-separator white-space-nowrap",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/UserInfo/Link OnClick");
controller.event_ExitFundView$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "user-info-link",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Exit Fund View"))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "user-logout white-space-nowrap",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/UserInfo/Link OnClick");
return controller.clientLogout$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "user-info-link",
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Log Out"))];
})
},
_dependencies: [asPrimitiveValue(model.variables._showExitFundViewInDataFetchStatus), asPrimitiveValue(model.variables.showExitFundViewIn), asPrimitiveValue(PHICore_THClientVariables.getUsername())]
}))];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
tabIndex: (-1).toString()
},
gridProperties: {
classes: "OSFillParent"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/UserInfo/Link OnClick");
return controller.clientLogin$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "skiptab",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "sign-in",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
name: "Icon4"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
style: "margin-left-s",
text: ["Login"],
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore_TH.Common.UserInfo.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "PHICore_TH.languageResources", "PHICore_TH.clientVariables", "PHICore_TH.Common.UserInfo.mvc$debugger"], function (OutSystems, PHICore_THModel, PHICore_THController, PHICore_THLanguageResources, PHICore_THClientVariables, PHICore_TH_Common_UserInfo_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getUserById$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getUserById$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions
Controller.prototype.doLogout$ServerAction = function (callContext) {
var controller = this.controller;
return controller.callServerAction("DoLogout", "screenservices/PHICore_TH/Common/UserInfo/ActionDoLogout", "8aHDGzSbCv1JiS3LscJ2zg", {}, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore_TH.Common.UserInfo$ActionDoLogout"))();
executeServerActionResult.redirectURLOut = OS.DataConversion.ServerDataConverter.from(outputs.RedirectURL, OS.Types.Text);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore_TH.Common.UserInfo$ActionDoLogout", [{
name: "RedirectURL",
attrName: "redirectURLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/PHICore_TH/Common/UserInfo/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore_TH.Common.UserInfo$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore_TH.Common.UserInfo$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);

// Aggregates and Data Actions
Controller.prototype.getUserById$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:QfQhOoa1hEK_7BZuJhCljg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.vo71rygvQUmkrIMvkMjkPg/DataActions.QfQhOoa1hEK_7BZuJhCljg:5cQbFvQP2JpfU1CDpTwLRA", "PHICore_TH", "GetUserById", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common/UserInfo/GetUserById");
return controller.callDataAction("DataActionGetUserById", "screenservices/PHICore_TH/Common/UserInfo/DataActionGetUserById", "T2JFk+_UwacflSdoeJcwKw", function (b) {
model.variables.getUserByIdDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getUserByIdDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getUserByIdDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, undefined, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common/UserInfo/GetUserById On After Fetch");
controller._onAfterFetch_GetUserById$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:QfQhOoa1hEK_7BZuJhCljg", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getUserById$DataActRefresh"];
// Client Actions
Controller.prototype._clientLogout$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClientLogout");
callContext = controller.callContext(callContext);
var doLogoutVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.doLogoutVar = doLogoutVar;
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:Lru4FgYtSkSe_OsWTFcn2A:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.vo71rygvQUmkrIMvkMjkPg/ClientActions.Lru4FgYtSkSe_OsWTFcn2A:o_97AVms9Fu_QjPP5Or+WQ", "PHICore_TH", "ClientLogout", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:oLuy3+NM40a+accSsjXKMQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:hymWtCkreEy+gkrJK6RcVg", callContext.id);
// Execute Action: DoLogout
model.flush();
return controller.doLogout$ServerAction(callContext).then(function (value) {
doLogoutVar.value = value;
}).then(function () {
// Found Logout URL
if((OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:sjKFc1RW10moXWT5H7AUlQ", callContext.id) && ((doLogoutVar.value.redirectURLOut) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:UD4SrpvHJ0mTwmIS0bIKkA", callContext.id);
// Destination: /PHICore_TH/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(doLogoutVar.value.redirectURLOut, {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:I2VLtOS4g0qX1ZFfIs87NA", callContext.id);
// Destination: /PHICore_TH/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/SandboxLogin/Login", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:Lru4FgYtSkSe_OsWTFcn2A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:Lru4FgYtSkSe_OsWTFcn2A", callContext.id);
throw ex;

});
};
Controller.prototype._clientLogin$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClientLogin");
callContext = controller.callContext(callContext);
var user_GetUnifiedLoginUrlVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.user_GetUnifiedLoginUrlVar = user_GetUnifiedLoginUrlVar;
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:wmCWGfzsrEK_0TT+0UsDqw:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.vo71rygvQUmkrIMvkMjkPg/ClientActions.wmCWGfzsrEK_0TT+0UsDqw:_PtdF4KAwDg8iy50vCF4Pw", "PHICore_TH", "ClientLogin", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:2qaurKesSUeIjb3eTg69UA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:O65euThy1UCPSUqJoS5aYg", callContext.id);
// Execute Action: User_GetUnifiedLoginUrl
model.flush();
return controller.user_GetUnifiedLoginUrl$ServerAction(OS.BuiltinFunctions.getBookmarkableURL(), "", callContext).then(function (value) {
user_GetUnifiedLoginUrlVar.value = value;
}).then(function () {
// Found Unified Login URL
if((OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:_4Vo0AHot0erA3OidVXkbw", callContext.id) && ((user_GetUnifiedLoginUrlVar.value.urlOut) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:p83HNXl0Z0Wz_Rxc7t7yVg", callContext.id);
// Destination: /PHICore_TH/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(user_GetUnifiedLoginUrlVar.value.urlOut, {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:XhrsA631NUy0tjsGlzBtXA", callContext.id);
// Destination: /PHICore_TH/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/SandboxLogin/Login", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:wmCWGfzsrEK_0TT+0UsDqw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:wmCWGfzsrEK_0TT+0UsDqw", callContext.id);
throw ex;

});
};
Controller.prototype._onAfterFetch_GetUserById$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch_GetUserById");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:EqHdSuL_40SnKSG8NKabxw:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.vo71rygvQUmkrIMvkMjkPg/ClientActions.EqHdSuL_40SnKSG8NKabxw:EmQwnhVAtL9ZnPyY+21Clg", "PHICore_TH", "OnAfterFetch_GetUserById", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:uTBjllFwz0C4zXUtH0_JLQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:LFNE3VvOCEOPoh61ezbogA", callContext.id);
// Username = GetUserById.IdUsername
PHICore_THClientVariables.setUsername(model.variables.getUserByIdDataAct.idUsernameOut);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:yNo+WF+4qUungpb+ZiMy2g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:EqHdSuL_40SnKSG8NKabxw", callContext.id);
}

};

Controller.prototype.clientLogout$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clientLogout$Action, callContext);

};
Controller.prototype.clientLogin$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clientLogin$Action, callContext);

};
Controller.prototype.onAfterFetch_GetUserById$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch_GetUserById$Action, callContext);

};
Controller.prototype.event_ExitFundView$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:Rg+NpK+sWb0P2hWAO+Ex6A", "PHICore_TH", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:vo71rygvQUmkrIMvkMjkPg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.vo71rygvQUmkrIMvkMjkPg:x53AZFDJhDbfFEIJtfveeA", "PHICore_TH", "UserInfo", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:vo71rygvQUmkrIMvkMjkPg", callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICore_THLanguageResources);
});

define("PHICore_TH.Common.UserInfo.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"hymWtCkreEy+gkrJK6RcVg": {
getter: function (varBag, idService) {
return varBag.doLogoutVar.value;
}
},
"O65euThy1UCPSUqJoS5aYg": {
getter: function (varBag, idService) {
return varBag.user_GetUnifiedLoginUrlVar.value;
}
},
"WczFYTwnC0SnqC1_0EL8sg": {
getter: function (varBag, idService) {
return varBag.model.variables.showExitFundViewIn;
},
dataType: OS.Types.Boolean
},
"QfQhOoa1hEK_7BZuJhCljg": {
getter: function (varBag, idService) {
return varBag.model.variables.getUserByIdDataAct;
}
},
"tVgT_xyTRE6+jsSlanWtbw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Menu"));
})(varBag.model, idService);
}
},
"n5JO66eTFUGGDaHsZ+z82g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Items"));
})(varBag.model, idService);
}
},
"juM6dpLhaUyFB57EYLZQbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon4"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
