define("PHICore.referencesHealth$AccessControl_CS", [], function () {
// Reference to producer 'AccessControl_CS' is OK.
});
define("PHICore.referencesHealth$APIGateway_IS", [], function () {
// Reference to producer 'APIGateway_IS' is OK.
});
define("PHICore.referencesHealth$Common_CS", [], function () {
// Reference to producer 'Common_CS' is OK.
});
define("PHICore.referencesHealth$Common_CW", [], function () {
// Reference to producer 'Common_CW' is OK.
});
define("PHICore.referencesHealth$Config_CS", [], function () {
// Reference to producer 'Config_CS' is OK.
});
define("PHICore.referencesHealth$CSVUtilExtension", [], function () {
// Reference to producer 'CSVUtilExtension' is OK.
});
define("PHICore.referencesHealth$DroppableFileUpload", [], function () {
// Reference to producer 'DroppableFileUpload' is OK.
});
define("PHICore.referencesHealth$HAMBSAudit_CS", [], function () {
// Reference to producer 'HAMBSAudit_CS' is OK.
});
define("PHICore.referencesHealth$InputMaskReactive", [], function () {
// Reference to producer 'InputMaskReactive' is OK.
});
define("PHICore.referencesHealth$JSONPatch", [], function () {
// Reference to producer 'JSONPatch' is OK.
});
define("PHICore.referencesHealth$LazyDropdownSearch", [], function () {
// Reference to producer 'LazyDropdownSearch' is OK.
});
define("PHICore.referencesHealth$MSD", [], function () {
// Reference to producer 'MSD' is OK.
});
define("PHICore.referencesHealth$OutSystemsCharts", [], function () {
// Reference to producer 'OutSystemsCharts' is OK.
});
define("PHICore.referencesHealth$OutSystemsUI", [], function () {
// Reference to producer 'OutSystemsUI' is OK.
});
define("PHICore.referencesHealth$PHICore_Notification", [], function () {
// Reference to producer 'PHICore_Notification' is OK.
});
define("PHICore.referencesHealth$PHICore_TH", [], function () {
// Reference to producer 'PHICore_TH' is OK.
});
define("PHICore.referencesHealth$Policy_CS", [], function () {
// Reference to producer 'Policy_CS' is OK.
});
define("PHICore.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("PHICore.referencesHealth$Stakeholder_CS", [], function () {
// Reference to producer 'Stakeholder_CS' is OK.
});
define("PHICore.referencesHealth$StateMachine_Calendar_CS", [], function () {
// Reference to producer 'StateMachine_Calendar_CS' is OK.
});
define("PHICore.referencesHealth$StateMachineCaseService", [], function () {
// Reference to producer 'StateMachineCaseService' is OK.
});
define("PHICore.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("PHICore.referencesHealth$TimeZone_Lib", [], function () {
// Reference to producer 'TimeZone_Lib' is OK.
});
define("PHICore.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("PHICore.referencesHealth", [], function () {
});
