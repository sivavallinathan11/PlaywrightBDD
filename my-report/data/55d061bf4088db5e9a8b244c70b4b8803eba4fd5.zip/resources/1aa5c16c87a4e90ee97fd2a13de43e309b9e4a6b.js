define("Common_CW.PHICore_CW.Pagination.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "OutSystemsUI.controller", "Common_CW.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "Common_CW.model$ListNavigationRec"], function (OutSystems, Common_CWModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MiddleNavigationPages", "middleNavigationPagesVar", "MiddleNavigationPages", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.ListNavigationList());
}, false, Common_CWModel.ListNavigationList), 
this.attr("SelectedPageButton", "selectedPageButtonVar", "SelectedPageButton", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("TotalPages", "totalPagesVar", "TotalPages", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("LastPageNumber", "lastPageNumberVar", "LastPageNumber", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("IsVisible", "isVisibleVar", "IsVisible", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsPhone", "isPhoneVar", "IsPhone", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GoToValue", "goToValueVar", "GoToValue", true, false, OS.Types.Integer, function () {
return 1;
}, false), 
this.attr("KeypressCallback", "keypressCallbackVar", "KeypressCallback", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("StartIndex", "startIndexIn", "StartIndex", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_startIndexInDataFetchStatus", "_startIndexInDataFetchStatus", "_startIndexInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("MaxRecords", "maxRecordsIn", "MaxRecords", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_maxRecordsInDataFetchStatus", "_maxRecordsInDataFetchStatus", "_maxRecordsInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("TotalCount", "totalCountIn", "TotalCount", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, false), 
this.attr("_totalCountInDataFetchStatus", "_totalCountInDataFetchStatus", "_totalCountInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ShowGoToPage", "showGoToPageIn", "ShowGoToPage", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showGoToPageInDataFetchStatus", "_showGoToPageInDataFetchStatus", "_showGoToPageInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_SelectedPageButton: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("StartIndex" in inputs) {
this.variables.startIndexIn = inputs.StartIndex;
if("_startIndexInDataFetchStatus" in inputs) {
this.variables._startIndexInDataFetchStatus = inputs._startIndexInDataFetchStatus;
}

}

if("MaxRecords" in inputs) {
this.variables.maxRecordsIn = inputs.MaxRecords;
if("_maxRecordsInDataFetchStatus" in inputs) {
this.variables._maxRecordsInDataFetchStatus = inputs._maxRecordsInDataFetchStatus;
}

}

if("TotalCount" in inputs) {
this.variables.totalCountIn = inputs.TotalCount;
if("_totalCountInDataFetchStatus" in inputs) {
this.variables._totalCountInDataFetchStatus = inputs._totalCountInDataFetchStatus;
}

}

if("ShowGoToPage" in inputs) {
this.variables.showGoToPageIn = inputs.ShowGoToPage;
if("_showGoToPageInDataFetchStatus" in inputs) {
this.variables._showGoToPageInDataFetchStatus = inputs._showGoToPageInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.Pagination");
});
define("Common_CW.PHICore_CW.Pagination.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.Pagination.mvc$model", "Common_CW.PHICore_CW.Pagination.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main", "Common_CW.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "Common_CW.model$ListNavigationRec"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUIController, React, OSView, Common_CW_PHICore_CW_Pagination_mvc_model, Common_CW_PHICore_CW_Pagination_mvc_controller, Common_CWClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.Pagination";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Pagination_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Pagination_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-maxrecords": (model.variables.maxRecordsIn).toString(),
"data-selectedpage": (model.variables.selectedPageButtonVar).toString(),
"data-totalpages": (model.variables.totalPagesVar).toString()
},
style: ("pagination " + model.variables.extendedClassIn),
visible: model.variables.isVisibleVar,
_idProps: {
service: idService,
name: "PaginationWrapper"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "status",
"aria-live": "polite",
"aria-atomic": "true"
},
gridProperties: {
classes: "OSInline"
},
style: "pagination-counter",
visible: true,
_idProps: {
service: idService,
name: "PaginationRecords"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Pagination.RecordNumberFrom"
},
value: ((model.variables.startIndexIn + 1)).toString(),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._startIndexInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": "6c08ff2e-126f-45fe-9737-83cf5de0970f"
},
text: [" to "],
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Pagination.RecordNumberTo"
},
value: model.getCachedValue(idService.getId("EQepqWfb1EO8mn3+8vyrCQ.Value"), function () {
return OS.BuiltinFunctions.longIntegerToText(((OS.BuiltinFunctions.integerToLongInteger((model.variables.maxRecordsIn + model.variables.startIndexIn)).gte(model.variables.totalCountIn)) ? (model.variables.totalCountIn) : (OS.BuiltinFunctions.integerToLongInteger((model.variables.maxRecordsIn + model.variables.startIndexIn)))));
}, function () {
return model.variables.maxRecordsIn;
}, function () {
return model.variables.startIndexIn;
}, function () {
return model.variables.totalCountIn;
}),
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._maxRecordsInDataFetchStatus, model.variables._startIndexInDataFetchStatus, model.variables._totalCountInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": "f3606a4b-4ae9-4147-bbb5-1f016314d425"
},
text: [" of "],
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
extendedProperties: {
"data-testid": "Pagination.RecordsNumber"
},
value: OS.BuiltinFunctions.longIntegerToText(model.variables.totalCountIn),
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._totalCountInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": "7daeb8e1-4b0e-4831-b7ad-c9895d4f2d60"
},
text: [" Records"],
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "navigation",
"aria-label": "Pagination"
},
gridProperties: {
classes: "OSInline"
},
style: "pagination-container",
visible: true,
_idProps: {
service: idService,
name: "PaginationContainer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: (model.variables.startIndexIn > 0),
extendedProperties: {
"aria-label": "go to previous page"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.startIndexIn - model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "pagination-button",
visible: (model.variables.totalPagesVar > 0),
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._startIndexInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.previous,
gridProperties: {
classes: "OSInline"
},
style: "pagination-previous",
_idProps: {
service: idService,
name: "Previous"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "display-flex",
visible: !(model.variables.showGoToPageIn),
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showGoToPageInDataFetchStatus)
}, React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("H85tOcRXe0aaKaUzTjhxig.aria-label"), function () {
return (((model.variables.selectedPageButtonVar > 1)) ? ("go to page 1") : ("page 1, current page"));
}, function () {
return model.variables.selectedPageButtonVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Button OnClick");
return controller.goTo$Action(0, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("H85tOcRXe0aaKaUzTjhxig.Style"), function () {
return (((model.variables.selectedPageButtonVar > 1)) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.selectedPageButtonVar;
}),
visible: (model.variables.totalPagesVar >= 1),
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "1",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-button is--ellipsis",
visible: model.getCachedValue(idService.getId("aYSCMy7DykOx0qdtoH13ag.Visible"), function () {
return ((model.variables.isPhoneVar) ? (((model.variables.selectedPageButtonVar > 2) && (model.variables.totalPagesVar >= 5))) : (((model.variables.selectedPageButtonVar > 3) && (model.variables.totalPagesVar >= 5))));
}, function () {
return model.variables.isPhoneVar;
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.totalPagesVar;
}),
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, "..."), React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
mode: /*Default*/ 0,
source: model.variables.middleNavigationPagesVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "PaginationList"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("IGtri1xDGUyylvxjibutFg.aria-label"), function () {
return (((model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr === model.variables.selectedPageButtonVar)) ? ((("page " + (model.variables.selectedPageButtonVar).toString()) + " current page")) : (("go to page " + (model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr).toString())));
}, function () {
return model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr;
}, function () {
return model.variables.selectedPageButtonVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Button OnClick");
return controller.goTo$Action(model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).startIndexAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("IGtri1xDGUyylvxjibutFg.Style"), function () {
return ((((model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr) !== (model.variables.selectedPageButtonVar))) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr;
}, function () {
return model.variables.selectedPageButtonVar;
}),
visible: model.getCachedValue(idService.getId("IGtri1xDGUyylvxjibutFg.Visible"), function () {
return (((model.variables.selectedPageButtonVar >= 3)) ? ((model.variables.middleNavigationPagesVar.getCurrentRowNumber(callContext.iterationContext) <= 3)) : (true));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.middleNavigationPagesVar.getCurrentRowNumber(callContext.iterationContext);
}),
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr)]
}, React.createElement(OSWidgets.Expression, {
value: (model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr).toString(),
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.selectedPageButtonVar)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-button is--ellipsis hide-on-service-studio",
visible: model.getCachedValue(idService.getId("Kb3lkEzJ0kanpNhUrYqj5w.Visible"), function () {
return ((model.variables.isPhoneVar) ? (((model.variables.totalPagesVar > model.variables.selectedPageButtonVar) && (model.variables.totalPagesVar >= 5))) : (((model.variables.totalPagesVar > (model.variables.selectedPageButtonVar + 1)) && (model.variables.totalPagesVar >= 5))));
}, function () {
return model.variables.isPhoneVar;
}, function () {
return model.variables.totalPagesVar;
}, function () {
return model.variables.selectedPageButtonVar;
}),
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, "..."), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("WHxXmgDNAkusfTJNTTtj_Q.aria-label"), function () {
return (((model.variables.selectedPageButtonVar === model.variables.lastPageNumberVar)) ? ((("page " + (model.variables.lastPageNumberVar).toString()) + ", current page, is last page")) : ((("page " + (model.variables.lastPageNumberVar).toString()) + ", is last page")));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.lastPageNumberVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.totalPagesVar * model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("WHxXmgDNAkusfTJNTTtj_Q.Style"), function () {
return ((((model.variables.selectedPageButtonVar) !== (model.variables.lastPageNumberVar))) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.lastPageNumberVar;
}),
visible: (model.variables.totalPagesVar > 3),
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: (model.variables.lastPageNumberVar).toString(),
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "pagination-input",
visible: model.variables.showGoToPageIn,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showGoToPageInDataFetchStatus)
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
style: "wcag-hide-text ",
targetWidget: "Input_SelectedPageButton",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Insert the page number to go to..."), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedEvents: {
onBlur: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Input_SelectedPageButton onblur");
controller.inputOnChange$Action(true, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
inputType: /*Number*/ 2,
mandatory: false,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Input_SelectedPageButton OnChange");
controller.inputOnChange$Action(false, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "form-control",
variable: model.createVariable(OS.Types.Integer, model.variables.goToValueVar, function (value) {
model.variables.goToValueVar = value;
}),
_idProps: {
service: idService,
name: "Input_SelectedPageButton"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-counter",
visible: true,
_idProps: {
service: idService,
name: "TotalPagesCounter"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": "b207f5ee-aead-4d0c-bbbd-2bc9a6361e2c"
},
text: ["of "],
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
value: ((model.variables.totalPagesVar + 1)).toString(),
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": "04fc28b2-d8a4-409b-847f-ebf28e962f60"
},
text: [" pages"],
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Button, {
enabled: (model.variables.selectedPageButtonVar < (model.variables.totalPagesVar + 1)),
extendedProperties: {
"aria-label": "go to next page"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.startIndexIn + model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "pagination-button",
visible: (model.variables.totalPagesVar > 0),
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.next,
gridProperties: {
classes: "OSInline"
},
style: "pagination-next",
_idProps: {
service: idService,
name: "Next"
},
_widgetRecordProvider: widgetsRecordProvider
})))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.Pagination.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.Pagination.mvc$debugger", "Common_CW.PHICore_CW.Pagination.mvc$controller.OnDestroy.RemoveListenerJS", "Common_CW.PHICore_CW.Pagination.mvc$controller.InitPagination.JsCalculateGoToValueJS", "Common_CW.PHICore_CW.Pagination.mvc$controller.InitPagination.JsGetTotalPagesJS", "Common_CW.PHICore_CW.Pagination.mvc$controller.InputOnChange.SetListenerJS", "Common_CW.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "Common_CW.model$ListNavigationRec"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUIController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_Pagination_mvc_Debugger, Common_CW_PHICore_CW_Pagination_mvc_controller_OnDestroy_RemoveListenerJS, Common_CW_PHICore_CW_Pagination_mvc_controller_InitPagination_JsCalculateGoToValueJS, Common_CW_PHICore_CW_Pagination_mvc_controller_InitPagination_JsGetTotalPagesJS, Common_CW_PHICore_CW_Pagination_mvc_controller_InputOnChange_SetListenerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
goTo$Action: function (newStartIndexIn) {
newStartIndexIn = (newStartIndexIn === undefined) ? 0 : newStartIndexIn;
return controller.executeActionInsideJSNode(controller._goTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(newStartIndexIn, OS.Types.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "GoTo");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Bl9pgd11+0qpFhC90Plbuw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.3UKvGYomq0yDOJdGxkB5Rg/ClientActions.Bl9pgd11+0qpFhC90Plbuw:MgCF5AeviI_6o9eyd+AsIA", "Common_CW", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:w7YcR5pbQ0Gn+COm6oebmw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:p8D+1vs9WEiQpE8IlvF5Zg", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_Pagination_mvc_controller_OnDestroy_RemoveListenerJS, "RemoveListener", "OnDestroy", {
KeypressCallback: OS.DataConversion.JSNodeParamConverter.to(model.variables.keypressCallbackVar, OS.Types.Object),
InputElemId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input_SelectedPageButton"), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0ab53Gza2E2yuVO+krZASA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Bl9pgd11+0qpFhC90Plbuw", callContext.id);
}

};
Controller.prototype._initPagination$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InitPagination");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$vars"))());
var jsCalculateGoToValueJSResult = new OS.DataTypes.VariableHolder();
var jsGetTotalPagesJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jsCalculateGoToValueJSResult = jsCalculateGoToValueJSResult;
varBag.jsGetTotalPagesJSResult = jsGetTotalPagesJSResult;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:orbPwBJHoECLT1lUUAGThw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.3UKvGYomq0yDOJdGxkB5Rg/ClientActions.orbPwBJHoECLT1lUUAGThw:jZk4C6oWKEOyNQGXwBo66w", "Common_CW", "InitPagination", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XUqFyndwrUOJhYPBcGapZQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:UDhZrVIJtkG2POf06gIebg", callContext.id) && (model.variables.maxRecordsIn >= 1))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:f8hXxhVCyUOLbVOre+lrzg", callContext.id);
// Script to get the total number of pages.
jsGetTotalPagesJSResult.value = controller.safeExecuteJSNode(Common_CW_PHICore_CW_Pagination_mvc_controller_InitPagination_JsGetTotalPagesJS, "JsGetTotalPages", "InitPagination", {
MaxRecords: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.integerToLongInteger(model.variables.maxRecordsIn), OS.Types.LongInteger),
TotalCount: OS.DataConversion.JSNodeParamConverter.to(model.variables.totalCountIn, OS.Types.LongInteger),
TotalPages: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$jsGetTotalPagesJSResult"))();
jsNodeResult.totalPagesOut = OS.DataConversion.JSNodeParamConverter.from($parameters.TotalPages, OS.Types.Integer);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tDG9x9l0pkWv3p16_XtymQ", callContext.id);
// SelectedPageButton = StartIndex / MaxRecords + 1
model.variables.selectedPageButtonVar = OS.BuiltinFunctions.decimalToInteger(OS.BuiltinFunctions.trunc(OS.BuiltinFunctions.integerToDecimal(model.variables.startIndexIn).div(OS.BuiltinFunctions.integerToDecimal(model.variables.maxRecordsIn)).plus(OS.BuiltinFunctions.integerToDecimal(1))));
// Is Phone?
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HWI2MTuFH02Cnt+E3IJHew", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isPhone$Action(callContext).isPhoneOut;
}, OS.Types.Boolean, callContext.id))) {
// Set Phone
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:35ZENl8Y1kqcwQX+8oGj2Q", callContext.id);
// MaxPagesToShow = 1
vars.value.maxPagesToShowVar = 1;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:35ZENl8Y1kqcwQX+8oGj2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsPhone = True
model.variables.isPhoneVar = true;
}

// Set Defaults
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dLN1F7SrukS0BxgEEUBNKA", callContext.id);
// TotalPages = JsGetTotalPages.TotalPages
model.variables.totalPagesVar = jsGetTotalPagesJSResult.value.totalPagesOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dLN1F7SrukS0BxgEEUBNKA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// LastPageNumber = JsGetTotalPages.TotalPages + 1
model.variables.lastPageNumberVar = (jsGetTotalPagesJSResult.value.totalPagesOut + 1);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dLN1F7SrukS0BxgEEUBNKA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PagesToCreate = If
vars.value.pagesToCreateVar = (((model.variables.totalPagesVar === 4)) ? (3) : (((((model.variables.totalPagesVar - 2) > vars.value.maxPagesToShowVar)) ? (vars.value.maxPagesToShowVar) : ((((model.variables.totalPagesVar > 3)) ? ((model.variables.totalPagesVar - 2)) : (model.variables.totalPagesVar))))));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dLN1F7SrukS0BxgEEUBNKA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// CurrentPage = If
vars.value.currentPageVar = ((((vars.value.maxPagesToShowVar === 1) && (model.variables.totalPagesVar > 4))) ? ((((model.variables.selectedPageButtonVar <= 1)) ? (model.variables.selectedPageButtonVar) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 1)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))) : ((((model.variables.totalPagesVar === 3)) ? ((((model.variables.selectedPageButtonVar <= 4)) ? (1) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 2)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))) : ((((model.variables.selectedPageButtonVar <= 3)) ? (1) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 2)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))))));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:n+4IpCPZnky8T2SxTlz4lg", callContext.id);
// Script to calculate the initial go to value.
jsCalculateGoToValueJSResult.value = controller.safeExecuteJSNode(Common_CW_PHICore_CW_Pagination_mvc_controller_InitPagination_JsCalculateGoToValueJS, "JsCalculateGoToValue", "InitPagination", {
StartIndex: OS.DataConversion.JSNodeParamConverter.to(model.variables.startIndexIn, OS.Types.Integer),
TotalPages: OS.DataConversion.JSNodeParamConverter.to(model.variables.totalPagesVar, OS.Types.Integer),
MaxRecords: OS.DataConversion.JSNodeParamConverter.to(model.variables.maxRecordsIn, OS.Types.Integer),
Value: OS.DataConversion.JSNodeParamConverter.to(model.variables.goToValueVar, OS.Types.Integer),
GotoValue: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$jsCalculateGoToValueJSResult"))();
jsNodeResult.gotoValueOut = OS.DataConversion.JSNodeParamConverter.from($parameters.GotoValue, OS.Types.Integer);
return jsNodeResult;
}, {}, {});
// Set GoToValue
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1lCVzRs3PEeZ_8v_sX1B_w", callContext.id);
// GoToValue = JsCalculateGoToValue.GotoValue
model.variables.goToValueVar = jsCalculateGoToValueJSResult.value.gotoValueOut;
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:K3vOLyGan0yrp+NKfSdDuw", callContext.id) && model.variables.totalCountIn.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) {
// Hide
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_d_GltHgaU2puIstNPrgog", callContext.id);
// IsVisible = False
model.variables.isVisibleVar = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7hE_4xICfkWh2hJ8SZN05g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:I_T9qrzk3kmOQ9Av5G1gNA", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.middleNavigationPagesVar, callContext);
// MiddleNav.Length < PagesToCreate
while ((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:CzGxUzzflEG9q_dT9YkfoA", callContext.id) && (model.variables.middleNavigationPagesVar.length < vars.value.pagesToCreateVar))) {
// AddPagesToList
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KFxmbvtTxUW3RoNh0YXH_Q", callContext.id);
// ListNavigationPage.Page = CurrentPage + 1
vars.value.listNavigationPageVar.pageAttr = (vars.value.currentPageVar + 1);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KFxmbvtTxUW3RoNh0YXH_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ListNavigationPage.StartIndex = CurrentPage * MaxRecords
vars.value.listNavigationPageVar.startIndexAttr = (vars.value.currentPageVar * model.variables.maxRecordsIn);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:44cW0B6tLkeec2CD_ExhIw", callContext.id);
// Execute Action: AppendPage
OS.SystemActions.listAppend(model.variables.middleNavigationPagesVar, vars.value.listNavigationPageVar, callContext);
// CurrentPage +=1
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:CZ+qGMbeoUuRkfH874Cmfg", callContext.id);
// CurrentPage = CurrentPage + 1
vars.value.currentPageVar = (vars.value.currentPageVar + 1);
}

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tP+MQ1nqmkCbw8_UYa5d9g", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(model.variables.middleNavigationPagesVar, function (p) {
return p.pageAttr;
}, true, callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:87Qnkq0urEC+7pnE0qzrnw", callContext.id);
// IsVisible = True
model.variables.isVisibleVar = true;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7hE_4xICfkWh2hJ8SZN05g", callContext.id);
}

} else {
// Hide
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:l_Ha+gipBEC+EADAHzIkjw", callContext.id);
// IsVisible = False
model.variables.isVisibleVar = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7Mhg50WlhkGVuNAcFLmCTQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:orbPwBJHoECLT1lUUAGThw", callContext.id);
}

};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$vars", [{
name: "PagesToCreate",
attrName: "pagesToCreateVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "CurrentPage",
attrName: "currentPageVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "ListNavigationPage",
attrName: "listNavigationPageVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CWModel.ListNavigationRec();
},
complexType: Common_CWModel.ListNavigationRec
}, {
name: "MaxPagesToShow",
attrName: "maxPagesToShowVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 3;
}
}]);
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$jsCalculateGoToValueJSResult", [{
name: "GotoValue",
attrName: "gotoValueOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.InitPagination$jsGetTotalPagesJSResult", [{
name: "TotalPages",
attrName: "totalPagesOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._inputOnChange$Action = function (isBlurIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InputOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.InputOnChange$vars"))());
vars.value.isBlurInLocal = isBlurIn;
var setListenerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.setListenerJSResult = setListenerJSResult;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:sM5syRH1u0yjsHwtgcD6sA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.3UKvGYomq0yDOJdGxkB5Rg/ClientActions.sM5syRH1u0yjsHwtgcD6sA:odzeACN8iiMB4KajEUrbsQ", "Common_CW", "InputOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PTINrXYNZ0eEN0MWHIIXfA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bEuAmlTxw06AW4Oy6SXxdA", callContext.id);
setListenerJSResult.value = controller.safeExecuteJSNode(Common_CW_PHICore_CW_Pagination_mvc_controller_InputOnChange_SetListenerJS, "SetListener", "InputOnChange", {
IsBlur: OS.DataConversion.JSNodeParamConverter.to(vars.value.isBlurInLocal, OS.Types.Boolean),
MaxRecords: OS.DataConversion.JSNodeParamConverter.to(model.variables.maxRecordsIn, OS.Types.Integer),
Value: OS.DataConversion.JSNodeParamConverter.to(model.variables.goToValueVar, OS.Types.Integer),
InputElementId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input_SelectedPageButton"), OS.Types.Text),
TotalPages: OS.DataConversion.JSNodeParamConverter.to(model.variables.totalPagesVar, OS.Types.Integer),
GotoValue: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer),
KeypressCallbackObj: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.InputOnChange$setListenerJSResult"))();
jsNodeResult.gotoValueOut = OS.DataConversion.JSNodeParamConverter.from($parameters.GotoValue, OS.Types.Integer);
jsNodeResult.keypressCallbackObjOut = OS.DataConversion.JSNodeParamConverter.from($parameters.KeypressCallbackObj, OS.Types.Object);
return jsNodeResult;
}, {
GoTo: controller.clientActionProxies.goTo$Action
}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+LCVSlkbtkqCOcRg7FAJZA", callContext.id);
// GoToValue = SetListener.GotoValue
model.variables.goToValueVar = setListenerJSResult.value.gotoValueOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+LCVSlkbtkqCOcRg7FAJZA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// KeypressCallback = SetListener.KeypressCallbackObj
model.variables.keypressCallbackVar = setListenerJSResult.value.keypressCallbackObjOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:WS6N6UuHJUWFfagZqhqjhg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:sM5syRH1u0yjsHwtgcD6sA", callContext.id);
}

};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.InputOnChange$vars", [{
name: "IsBlur",
attrName: "isBlurInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.InputOnChange$setListenerJSResult", [{
name: "GotoValue",
attrName: "gotoValueOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "KeypressCallbackObj",
attrName: "keypressCallbackObjOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._goTo$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GoTo");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Pagination.GoTo$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8voL38mhjUC3s+I5NrSf6A:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.3UKvGYomq0yDOJdGxkB5Rg/ClientActions.8voL38mhjUC3s+I5NrSf6A:p1qOKc7STaXWSUDVwrnZ9g", "Common_CW", "GoTo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2JhgLp2ePEWZY8wAdy_vzg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HoezZ+bcVU2A1hFJ5qfF1Q", callContext.id);
// Trigger Event: OnNavigate
return controller.onNavigate$Action(vars.value.newStartIndexInLocal, callContext).then(function () {
// Set GoToValue
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FCqumCWTlU+0bmcUt7sUAg", callContext.id);
// GoToValue = SelectedPageButton
model.variables.goToValueVar = model.variables.selectedPageButtonVar;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:QhIXONRN4k2EgBw3U6BHww", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8voL38mhjUC3s+I5NrSf6A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8voL38mhjUC3s+I5NrSf6A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Pagination.GoTo$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);

Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.initPagination$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._initPagination$Action, callContext);

};
Controller.prototype.inputOnChange$Action = function (isBlurIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._inputOnChange$Action, callContext, isBlurIn);

};
Controller.prototype.goTo$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._goTo$Action, callContext, newStartIndexIn);

};
Controller.prototype.onNavigate$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:3UKvGYomq0yDOJdGxkB5Rg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.3UKvGYomq0yDOJdGxkB5Rg:28lnSFaqWaCwSXSyxPfPYA", "Common_CW", "Pagination", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:3UKvGYomq0yDOJdGxkB5Rg", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Pagination On Ready");
return controller.initPagination$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Pagination On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Pagination On Parameters Changed");
return controller.initPagination$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});
define("Common_CW.PHICore_CW.Pagination.mvc$controller.OnDestroy.RemoveListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var inputElem = document.getElementById($parameters.InputElemId);

if(inputElem) {
    inputElem.removeEventListener('keydown', $parameters.KeypressCallback);
}
};
});
define("Common_CW.PHICore_CW.Pagination.mvc$controller.InitPagination.JsCalculateGoToValueJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var value = $parameters.Value;

if(value >= 1 && value <= $parameters.TotalPages) 
{
    // Go to Selected Page
    value = ($parameters.StartIndex + $parameters.MaxRecords) / $parameters.MaxRecords;
} 
else if(value > $parameters.TotalPages) {
    // Go to Last Page
    value = $parameters.TotalPages + 1;
} 
else {
    // Go to First page
    value = 1;
}

$parameters.GotoValue = value;
};
});
define("Common_CW.PHICore_CW.Pagination.mvc$controller.InitPagination.JsGetTotalPagesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var getTotalPages = $parameters.TotalCount / $parameters.MaxRecords;

if (getTotalPages == Math.floor(getTotalPages)) {
    $parameters.TotalPages = (getTotalPages - 1);
} else {
    $parameters.TotalPages = (getTotalPages);
}





};
});
define("Common_CW.PHICore_CW.Pagination.mvc$controller.InputOnChange.SetListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var value = $parameters.Value;
var totalPages = $parameters.TotalPages;
var enterPressed = 13; // enter-key
var inputElem = document.getElementById($parameters.InputElementId);

var checkValue = function() {
    if(value > 0 && value <= totalPages) {
    // Go to Selected Page
    value = (value - 1) * $parameters.MaxRecords;
    } else if(value > totalPages) {
        // Go to Last Page
        value = totalPages * $parameters.MaxRecords;
    } else {
        // Go to First page
        value = 0;
    }
};

var inputOnKeypress = function(e){
    if (e.keyCode === enterPressed) {
        checkValue();
        $actions.GoTo(value);
    }
    inputElem.removeEventListener('keydown', inputOnKeypress); 
};

if($parameters.IsBlur === false) {
    inputElem.addEventListener('keydown', inputOnKeypress);
    $parameters.KeypressCallbackObj = inputOnKeypress;
} else {
    checkValue();
    $actions.GoTo(value);
}

$parameters.GotoValue = value;
};
});

define("Common_CW.PHICore_CW.Pagination.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"p8D+1vs9WEiQpE8IlvF5Zg": {
getter: function (varBag, idService) {
return varBag.removeListenerJSResult.value;
}
},
"w+kCestpXk2e8fOtyEsMJw": {
getter: function (varBag, idService) {
return varBag.vars.value.pagesToCreateVar;
},
dataType: OS.Types.Integer
},
"hD6ne9v760CspQEn73f2cg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentPageVar;
},
dataType: OS.Types.Integer
},
"Z57ZlzG2B061MShgZKHWVA": {
getter: function (varBag, idService) {
return varBag.vars.value.listNavigationPageVar;
}
},
"YVfKq4e3j0uGMtBN1hFMEg": {
getter: function (varBag, idService) {
return varBag.vars.value.maxPagesToShowVar;
},
dataType: OS.Types.Integer
},
"n+4IpCPZnky8T2SxTlz4lg": {
getter: function (varBag, idService) {
return varBag.jsCalculateGoToValueJSResult.value;
}
},
"f8hXxhVCyUOLbVOre+lrzg": {
getter: function (varBag, idService) {
return varBag.jsGetTotalPagesJSResult.value;
}
},
"PNIH4Edr402oBGVA3POiUA": {
getter: function (varBag, idService) {
return varBag.vars.value.isBlurInLocal;
},
dataType: OS.Types.Boolean
},
"bEuAmlTxw06AW4Oy6SXxdA": {
getter: function (varBag, idService) {
return varBag.setListenerJSResult.value;
}
},
"siZJCeDZEEuB8nRt_rEOFw": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"sGmkawhsKkytPCadGcBrXQ": {
getter: function (varBag, idService) {
return varBag.model.variables.middleNavigationPagesVar;
}
},
"LoLtxw936UuKWWzCWDylXg": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedPageButtonVar;
},
dataType: OS.Types.Integer
},
"4_CKANm7XUe5FLKBw6UAeA": {
getter: function (varBag, idService) {
return varBag.model.variables.totalPagesVar;
},
dataType: OS.Types.Integer
},
"YjZbIzkYgkWl7O9lHhIA4g": {
getter: function (varBag, idService) {
return varBag.model.variables.lastPageNumberVar;
},
dataType: OS.Types.Integer
},
"umvvMWk+RUmvF3Bb6uigDg": {
getter: function (varBag, idService) {
return varBag.model.variables.isVisibleVar;
},
dataType: OS.Types.Boolean
},
"yiI5Qe2WVEOHuA8_TEY0rA": {
getter: function (varBag, idService) {
return varBag.model.variables.isPhoneVar;
},
dataType: OS.Types.Boolean
},
"gqKQX1TyckqPv5ZOK02tyA": {
getter: function (varBag, idService) {
return varBag.model.variables.goToValueVar;
},
dataType: OS.Types.Integer
},
"PDRTn1qGAU6JCzUgA4pSaA": {
getter: function (varBag, idService) {
return varBag.model.variables.keypressCallbackVar;
},
dataType: OS.Types.Object
},
"wYSHiUOdOU2opX_r2Lat3Q": {
getter: function (varBag, idService) {
return varBag.model.variables.startIndexIn;
},
dataType: OS.Types.Integer
},
"14_NCVdKqEmB6geNXOBnbw": {
getter: function (varBag, idService) {
return varBag.model.variables.maxRecordsIn;
},
dataType: OS.Types.Integer
},
"14ppGGAfY0Set7328MZhMA": {
getter: function (varBag, idService) {
return varBag.model.variables.totalCountIn;
},
dataType: OS.Types.LongInteger
},
"045R1KQE_UmekkssKDvYqA": {
getter: function (varBag, idService) {
return varBag.model.variables.showGoToPageIn;
},
dataType: OS.Types.Boolean
},
"8pNIIqVTGk23ktFh5lZ7+A": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"gs1_5r2gwkGectHSBH9Uig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationWrapper"));
})(varBag.model, idService);
}
},
"_xPwwRh0z0e464io5Z+e5w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationRecords"));
})(varBag.model, idService);
}
},
"_pQgakm1WEOPQmUtAniTqg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationContainer"));
})(varBag.model, idService);
}
},
"AdaZmVfdcU6MKX3L0UbqKw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"83XZ6wr5PkiVgZcy0lYWqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationList"));
})(varBag.model, idService);
}
},
"9w5htni770ezCUs3tPpTkQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_SelectedPageButton"));
})(varBag.model, idService);
}
},
"qh4W2lCKg0ejcDpz9A2M7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TotalPagesCounter"));
})(varBag.model, idService);
}
},
"o+qiyq2gKEqtL_x6erQv9w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
