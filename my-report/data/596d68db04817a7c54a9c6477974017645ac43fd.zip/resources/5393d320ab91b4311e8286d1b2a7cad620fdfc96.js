﻿define("Common_CW.clientVariables", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
var ClientVariables = (function (_super) {
var clientVarsService;
function ClientVariables() {
clientVarsService = OS.Injector.resolve(OS.ServiceNames.ClientVariablesService);
}
ClientVariables.prototype.getLastURL = function () {
return clientVarsService.getVariable("LastURL", "Common_CW", OS.Types.Text);
};
ClientVariables.prototype.setLastURL = function (value) {
return clientVarsService.setVariable("LastURL", "Common_CW", OS.Types.Text, value);
};
ClientVariables.prototype.getPrimaryColor = function () {
return clientVarsService.getVariable("PrimaryColor", "Common_CW", OS.Types.Text);
};
ClientVariables.prototype.setPrimaryColor = function (value) {
return clientVarsService.setVariable("PrimaryColor", "Common_CW", OS.Types.Text, value);
};
ClientVariables.prototype.getGlobalBasicSearch = function () {
return clientVarsService.getVariable("GlobalBasicSearch", "Common_CW", OS.Types.Text);
};
ClientVariables.prototype.setGlobalBasicSearch = function (value) {
return clientVarsService.setVariable("GlobalBasicSearch", "Common_CW", OS.Types.Text, value);
};
ClientVariables.prototype.getTenantLogo = function () {
return clientVarsService.getVariable("TenantLogo", "Common_CW", OS.Types.Text);
};
ClientVariables.prototype.setTenantLogo = function (value) {
return clientVarsService.setVariable("TenantLogo", "Common_CW", OS.Types.Text, value);
};
ClientVariables.prototype.getLogoFileName = function () {
return clientVarsService.getVariable("LogoFileName", "Common_CW", OS.Types.Text);
};
ClientVariables.prototype.setLogoFileName = function (value) {
return clientVarsService.setVariable("LogoFileName", "Common_CW", OS.Types.Text, value);
};
ClientVariables.prototype.serialize = function () {
return {
LastURL: OS.DataConversion.ServerDataConverter.to(this.getLastURL(), OS.Types.Text),
PrimaryColor: OS.DataConversion.ServerDataConverter.to(this.getPrimaryColor(), OS.Types.Text),
GlobalBasicSearch: OS.DataConversion.ServerDataConverter.to(this.getGlobalBasicSearch(), OS.Types.Text),
TenantLogo: OS.DataConversion.ServerDataConverter.to(this.getTenantLogo(), OS.Types.Text),
LogoFileName: OS.DataConversion.ServerDataConverter.to(this.getLogoFileName(), OS.Types.Text)
};
};
return ClientVariables;
})();
return new ClientVariables();
});
