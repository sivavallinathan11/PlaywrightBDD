﻿define("PHICore.Common_Widgets.SLAPill.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "OutSystemsUI.Content.Tag.mvc$model"], function (OutSystems, PHICoreModel, OutSystemsUI_Content_Tag_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SLAId", "sLAIdIn", "SLAId", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_sLAIdInDataFetchStatus", "_sLAIdInDataFetchStatus", "_sLAIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SLAText", "sLATextIn", "SLAText", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_sLATextInDataFetchStatus", "_sLATextInDataFetchStatus", "_sLATextInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsSmall", "isSmallIn", "IsSmall", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isSmallInDataFetchStatus", "_isSmallInDataFetchStatus", "_isSmallInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = OutSystemsUI_Content_Tag_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("SLAId" in inputs) {
this.variables.sLAIdIn = inputs.SLAId;
if("_sLAIdInDataFetchStatus" in inputs) {
this.variables._sLAIdInDataFetchStatus = inputs._sLAIdInDataFetchStatus;
}

}

if("SLAText" in inputs) {
this.variables.sLATextIn = inputs.SLAText;
if("_sLATextInDataFetchStatus" in inputs) {
this.variables._sLATextInDataFetchStatus = inputs._sLATextInDataFetchStatus;
}

}

if("IsSmall" in inputs) {
this.variables.isSmallIn = inputs.IsSmall;
if("_isSmallInDataFetchStatus" in inputs) {
this.variables._isSmallInDataFetchStatus = inputs._isSmallInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.SLAPill");
});
define("PHICore.Common_Widgets.SLAPill.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.SLAPill.mvc$model", "PHICore.Common_Widgets.SLAPill.mvc$controller", "PHICore.clientVariables", "OutSystemsUI.Content.Tag.mvc$view", "OutSystems/ReactWidgets/Main"], function (OutSystems, PHICoreModel, PHICoreController, React, OSView, PHICore_Common_Widgets_SLAPill_mvc_model, PHICore_Common_Widgets_SLAPill_mvc_controller, PHICoreClientVariables, OutSystemsUI_Content_Tag_mvc_view, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.SLAPill";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Content_Tag_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_SLAPill_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_SLAPill_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if((model.variables.sLAIdIn === PHICoreModel.staticEntities.sLA.needsAttention), false, this, function () {
return [React.createElement(OutSystemsUI_Content_Tag_mvc_view, {
inputs: {
ExtendedClass: "background-warning",
Size: model.getCachedValue(idService.getId("D1+Uv+sU0EWAomRz6i+spw.Size"), function () {
return ((model.variables.isSmallIn) ? (PHICoreModel.staticEntities.size.small) : (PHICoreModel.staticEntities.size.medium));
}, function () {
return model.variables.isSmallIn;
}),
_sizeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isSmallInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
tag: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.sLATextIn,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._sLATextInDataFetchStatus)
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._sLATextInDataFetchStatus), asPrimitiveValue(model.variables.sLATextIn)]
})];
}, function () {
return [$if((model.variables.sLAIdIn === PHICoreModel.staticEntities.sLA.onTrack), false, this, function () {
return [React.createElement(OutSystemsUI_Content_Tag_mvc_view, {
inputs: {
ExtendedClass: "background-success",
Size: model.getCachedValue(idService.getId("9T5lm2w99kyPe8Yb7_fKiw.Size"), function () {
return ((model.variables.isSmallIn) ? (PHICoreModel.staticEntities.size.small) : (PHICoreModel.staticEntities.size.medium));
}, function () {
return model.variables.isSmallIn;
}),
_sizeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isSmallInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
tag: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.sLATextIn,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._sLATextInDataFetchStatus)
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._sLATextInDataFetchStatus), asPrimitiveValue(model.variables.sLATextIn)]
})];
}, function () {
return [$if((model.variables.sLAIdIn === PHICoreModel.staticEntities.sLA.offTrack), false, this, function () {
return [React.createElement(OutSystemsUI_Content_Tag_mvc_view, {
inputs: {
Size: model.getCachedValue(idService.getId("AihmD8kOYUahuWvEQURj3w.Size"), function () {
return ((model.variables.isSmallIn) ? (PHICoreModel.staticEntities.size.small) : (PHICoreModel.staticEntities.size.medium));
}, function () {
return model.variables.isSmallIn;
}),
_sizeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isSmallInDataFetchStatus),
ExtendedClass: "background-error"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
tag: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.sLATextIn,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._sLATextInDataFetchStatus)
})];
})
},
_dependencies: [asPrimitiveValue(model.variables._sLATextInDataFetchStatus), asPrimitiveValue(model.variables.sLATextIn)]
})];
}, function () {
return [];
})];
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.SLAPill.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.SLAPill.mvc$debugger"], function (OutSystems, PHICoreModel, PHICoreController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_SLAPill_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:M53PpcyZqEOEbS8bW6YiHQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.M53PpcyZqEOEbS8bW6YiHQ:15vYbxlTiAARg4w9JWAeIw", "PHICore", "SLAPill", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:M53PpcyZqEOEbS8bW6YiHQ", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.SLAPill.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"KWFImU1CCkKX3ewvdJ5bXg": {
getter: function (varBag, idService) {
return varBag.model.variables.sLAIdIn;
},
dataType: OS.Types.Integer
},
"WSWPcciwd0eP6ypiPnBfrw": {
getter: function (varBag, idService) {
return varBag.model.variables.sLATextIn;
},
dataType: OS.Types.Text
},
"20JfcqvLekupcu6mshpp6A": {
getter: function (varBag, idService) {
return varBag.model.variables.isSmallIn;
},
dataType: OS.Types.Boolean
},
"xN_F7gBrVU2r34kHMZ7XKA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tag"));
})(varBag.model, idService);
}
},
"09wXVIId1EmSmDZpfgWR_Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tag"));
})(varBag.model, idService);
}
},
"9PZ+aDTKRk6MO63o+R73Dw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tag"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
