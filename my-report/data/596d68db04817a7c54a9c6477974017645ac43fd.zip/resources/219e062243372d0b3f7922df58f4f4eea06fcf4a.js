﻿define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$model", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$TabsHeaderItem_InternalConfigRec", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$TabsHeaderItemCreate", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsHeaderItemChangeTextProperty", "OutSystemsUI.controller$TabsHeaderItemDestroy", "OutSystemsUI.controller$TabsHeaderItemRegisterCallback", "OutSystemsUI.controller$TabsHeaderItemInitialize", "OutSystemsUI.controller$TabsHeaderItemUpdateOnRender"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("InternalConfigs", "internalConfigsVar", "InternalConfigs", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.TabsHeaderItem_InternalConfigRec());
}, false, OutSystemsUIModel.TabsHeaderItem_InternalConfigRec), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Navigation.TabsHeaderItem");
});
define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$view", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$model", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$controller", "OutSystems/ReactWidgets/Main", "OutSystemsUI.model$TabsHeaderItem_InternalConfigRec", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$TabsHeaderItemCreate", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsHeaderItemChangeTextProperty", "OutSystemsUI.controller$TabsHeaderItemDestroy", "OutSystemsUI.controller$TabsHeaderItemRegisterCallback", "OutSystemsUI.controller$TabsHeaderItemInitialize", "OutSystemsUI.controller$TabsHeaderItemUpdateOnRender"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, React, OSView, OutSystemsUI_Navigation_TabsHeaderItem_mvc_model, OutSystemsUI_Navigation_TabsHeaderItem_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Navigation.TabsHeaderItem";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return OutSystemsUI_Navigation_TabsHeaderItem_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return OutSystemsUI_Navigation_TabsHeaderItem_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "osui-tabs__header-item",
name: model.variables.internalConfigsVar.uniqueIdAttr
},
tag: "button",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.title,
style: "display-contents ph",
_idProps: {
service: idService,
name: "Title"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$controller", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.languageResources", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$translationsResources", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$debugger", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$controller.RegisterCallbacks.GetCallbackHandlersJS", "OutSystemsUI.model$TabsHeaderItem_InternalConfigRec", "OutSystemsUI.controller$LogEvent", "OutSystemsUI.controller$TabsHeaderItemCreate", "OutSystemsUI.controller$GenerateUniqueId", "OutSystemsUI.controller$TabsHeaderItemChangeTextProperty", "OutSystemsUI.controller$TabsHeaderItemDestroy", "OutSystemsUI.controller$TabsHeaderItemRegisterCallback", "OutSystemsUI.controller$TabsHeaderItemInitialize", "OutSystemsUI.controller$TabsHeaderItemUpdateOnRender"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUILanguageResources, OutSystemsUI_Navigation_TabsHeaderItem_mvc_TranslationsResources, OutSystemsUI_Navigation_TabsHeaderItem_mvc_Debugger, OutSystemsUI_Navigation_TabsHeaderItem_mvc_controller_RegisterCallbacks_GetCallbackHandlersJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
initializedHandler$Action: function (tabsHeaderItemIdIn) {
tabsHeaderItemIdIn = (tabsHeaderItemIdIn === undefined) ? "" : tabsHeaderItemIdIn;
return controller.executeActionInsideJSNode(controller._initializedHandler$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tabsHeaderItemIdIn, OS.Types.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "InitializedHandler");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
Controller.prototype.translationResources = OutSystemsUI_Navigation_TabsHeaderItem_mvc_TranslationsResources;
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var generateUniqueIdVar = new OS.DataTypes.VariableHolder();
var serialize_configsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.generateUniqueIdVar = generateUniqueIdVar;
varBag.serialize_configsVar = serialize_configsVar;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:w3fIFvrMrUiUN95v_ghjmw:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.w3fIFvrMrUiUN95v_ghjmw:ZvyjRQX+GpVIMIVdtuLtTQ", "OutSystemsUI", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TAkHrxIoNESVOXIcHwElAg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0AT+MV1cGE6OE1qh1vLcAw", callContext.id);
// Execute Action: LogStart
OutSystemsUIController.default.logEvent$Action(OutSystemsUIModel.staticEntities.logType.general, "Going to create TabsHeaderItem", callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ftnkhl3d8UqRhtB+tT4z1A", callContext.id);
// Execute Action: GenerateUniqueId
generateUniqueIdVar.value = OutSystemsUIController.default.generateUniqueId$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);

// Set Initial Configs
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+jT_k_cdNUWIgH4e_fUicQ", callContext.id);
// InternalConfigs.UniqueId = GenerateUniqueId.Unique_ID
model.variables.internalConfigsVar.uniqueIdAttr = generateUniqueIdVar.value.unique_IDOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+jT_k_cdNUWIgH4e_fUicQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// InternalConfigs.ExtendedClass = ExtendedClass
model.variables.internalConfigsVar.extendedClassAttr = model.variables.extendedClassIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:E5hVm2mcc0WJwLSUOv6fhQ", callContext.id);
// JSON Serialize: Serialize_configs
serialize_configsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.internalConfigsVar, true, false);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:a+Xif0MECUWACqtgjN96RQ", callContext.id);
// Execute Action: TabsHeaderItemCreate
OutSystemsUIController.default.tabsHeaderItemCreate$Action(model.variables.internalConfigsVar.uniqueIdAttr, serialize_configsVar.value.jSONOut, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ncuTPtca6EGwPq7FqtRqAQ", callContext.id);
// Execute Action: RegisterCallbacks
controller._registerCallbacks$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rW12im+Al0Sr0O2Md8WWuQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:w3fIFvrMrUiUN95v_ghjmw", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:vpaSNdRlrE+e9ZuXotO9Rw:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.vpaSNdRlrE+e9ZuXotO9Rw:aC5AdLdJuvvwz4e0F8dzLA", "OutSystemsUI", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mVrG9w9ASUuVsZiNspXnPg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xSGxM0TtMU2X32OMSzJoKg", callContext.id) && ((model.variables.extendedClassIn) !== (model.variables.internalConfigsVar.extendedClassAttr)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Rdfb3JfMXUu+yTvnzVmg7g", callContext.id);
// InternalConfigs.ExtendedClass = ExtendedClass
model.variables.internalConfigsVar.extendedClassAttr = model.variables.extendedClassIn;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xArLtBnKq0KtBP54F5T_sg", callContext.id);
// Execute Action: Update_ExtendedClass
OutSystemsUIController.default.tabsHeaderItemChangeTextProperty$Action(model.variables.internalConfigsVar.uniqueIdAttr, "ExtendedClass", model.variables.internalConfigsVar.extendedClassAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YCIA_VMPmUyepbG05jJeDA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YCIA_VMPmUyepbG05jJeDA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:vpaSNdRlrE+e9ZuXotO9Rw", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:iNBUO_M0lEuNMBPr3TVgMQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.iNBUO_M0lEuNMBPr3TVgMQ:mGWNrQZ2Rs4fuhZViXtVDg", "OutSystemsUI", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X5u5jkWgkUGWo8ra_RJ1OQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:10q0Eod+kEyBxeXzx6ahBQ", callContext.id);
// Execute Action: TabsHeaderItemDestroy
OutSystemsUIController.default.tabsHeaderItemDestroy$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:shQ3Z74kJUSWQh186305lw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:iNBUO_M0lEuNMBPr3TVgMQ", callContext.id);
}

};
Controller.prototype._registerCallbacks$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RegisterCallbacks");
callContext = controller.callContext(callContext);
var getCallbackHandlersJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getCallbackHandlersJSResult = getCallbackHandlersJSResult;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:kNf5cnraa0SnT+enVbfiSw:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.kNf5cnraa0SnT+enVbfiSw:aSB3b+Pdha76hMs2knXspw", "OutSystemsUI", "RegisterCallbacks", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:A1TMd37JfEiydlydQI+TcA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nEpIMIdhZkCV0Hm6j7NQBA", callContext.id);
getCallbackHandlersJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_Navigation_TabsHeaderItem_mvc_controller_RegisterCallbacks_GetCallbackHandlersJS, "GetCallbackHandlers", "RegisterCallbacks", {
Initialized: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.TabsHeaderItem.RegisterCallbacks$getCallbackHandlersJSResult"))();
jsNodeResult.initializedOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Initialized, OS.Types.Object);
return jsNodeResult;
}, {
InitializedHandler: controller.clientActionProxies.initializedHandler$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:r5oDaPcnT0mEoVGWI+F6Wg", callContext.id);
// Execute Action: RegisterOnInitialize
OutSystemsUIController.default.tabsHeaderItemRegisterCallback$Action(model.variables.internalConfigsVar.uniqueIdAttr, OutSystemsUIModel.staticEntities.registeredCallbackEvents.initialized, getCallbackHandlersJSResult.value.initializedOut, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rKsRQiXwUk+AXVFFURwkEg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:kNf5cnraa0SnT+enVbfiSw", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.TabsHeaderItem.RegisterCallbacks$getCallbackHandlersJSResult", [{
name: "Initialized",
attrName: "initializedOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:cXoLdoTNdUKYJos_fzm_CA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.cXoLdoTNdUKYJos_fzm_CA:zniB4maz4NQ9275pCNbSzQ", "OutSystemsUI", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:z14TZP0TA0aaFxXvNexMyg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DCxotxa+lECO1+vq_4MBhA", callContext.id);
// Execute Action: TabsHeaderItemInitialize
OutSystemsUIController.default.tabsHeaderItemInitialize$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hbIFvbJP+U2AWZDZpbUTpQ", callContext.id);
// Execute Action: LogEnd
OutSystemsUIController.default.logEvent$Action(OutSystemsUIModel.staticEntities.logType.general, "TabsHeaderItem created", callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jQlGi70k_EuebriJg7s83g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:cXoLdoTNdUKYJos_fzm_CA", callContext.id);
}

};
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:WttytB_Z1EC+Yu0m4QkGhw:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.WttytB_Z1EC+Yu0m4QkGhw:EzfgrYX9lMVXrGjUgy24Lw", "OutSystemsUI", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5gJpJm9ppUK2j4b0iCfHfw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UD0RV23t_EaxTKiXZUqaPg", callContext.id);
// Execute Action: TabsHeaderItemUpdateOnRender
OutSystemsUIController.default.tabsHeaderItemUpdateOnRender$Action(model.variables.internalConfigsVar.uniqueIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:__BW6AXPHUGZ6_wQaNbebg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:WttytB_Z1EC+Yu0m4QkGhw", callContext.id);
}

};
Controller.prototype._initializedHandler$Action = function (tabsHeaderItemIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InitializedHandler");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.TabsHeaderItem.InitializedHandler$vars"))());
vars.value.tabsHeaderItemIdInLocal = tabsHeaderItemIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:uCClyvRqTkWZ5DlVultndg:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw/ClientActions.uCClyvRqTkWZ5DlVultndg:ntk7FEX1fAC0SIntmK3v2A", "OutSystemsUI", "InitializedHandler", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QcVut1NJC0SsNaC1xbPZUA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jR6hHmQtk0uAFElTC84f4g", callContext.id);
// Trigger Event: Initialized
return controller.initialized$Action(vars.value.tabsHeaderItemIdInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gn+t21jY1U6M7++CwPz82w", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uCClyvRqTkWZ5DlVultndg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uCClyvRqTkWZ5DlVultndg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.TabsHeaderItem.InitializedHandler$vars", [{
name: "TabsHeaderItemId",
attrName: "tabsHeaderItemIdInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.registerCallbacks$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._registerCallbacks$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.initializedHandler$Action = function (tabsHeaderItemIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._initializedHandler$Action, callContext, tabsHeaderItemIdIn);

};
Controller.prototype.initialized$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ:OIzPV+L_8TrNS0PFWhhjcg", "OutSystemsUI", "Navigation", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:rcOb52hNEUef0ucmnNLshw:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.rcOb52hNEUef0ucmnNLshw:BExNlCfD85xjUiwVMLwrHQ", "OutSystemsUI", "TabsHeaderItem", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:rcOb52hNEUef0ucmnNLshw", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/TabsHeaderItem On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/TabsHeaderItem On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/TabsHeaderItem On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/TabsHeaderItem On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/TabsHeaderItem On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, OutSystemsUILanguageResources);
});
define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$controller.RegisterCallbacks.GetCallbackHandlersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Initialized = $actions.InitializedHandler;
};
});

define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ftnkhl3d8UqRhtB+tT4z1A": {
getter: function (varBag, idService) {
return varBag.generateUniqueIdVar.value;
}
},
"E5hVm2mcc0WJwLSUOv6fhQ": {
getter: function (varBag, idService) {
return varBag.serialize_configsVar.value;
}
},
"nEpIMIdhZkCV0Hm6j7NQBA": {
getter: function (varBag, idService) {
return varBag.getCallbackHandlersJSResult.value;
}
},
"wsDNyC1FKkS1vqjoq5T9zw": {
getter: function (varBag, idService) {
return varBag.vars.value.tabsHeaderItemIdInLocal;
},
dataType: OS.Types.Text
},
"blt3kPhkpUuMT98YJ8ASaA": {
getter: function (varBag, idService) {
return varBag.model.variables.internalConfigsVar;
}
},
"dMEh3g1cZkWP85n1w8IoTQ": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"m4SJ6zzDiEmFa1Lft1r0vQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
define("OutSystemsUI.Navigation.TabsHeaderItem.mvc$translationsResources", ["exports"], function (exports) {
return {};
});
