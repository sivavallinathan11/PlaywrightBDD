﻿define("PHICore_TH.Common.MenuIcon.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuIconListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, PHICore_THModel, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "Common.MenuIcon");
});
define("PHICore_TH.Common.MenuIcon.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "PHICore_TH.Common.MenuIcon.mvc$model", "PHICore_TH.Common.MenuIcon.mvc$controller", "PHICore_TH.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuIconListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, React, OSView, PHICore_TH_Common_MenuIcon_mvc_model, PHICore_TH_Common_MenuIcon_mvc_controller, PHICore_THClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.MenuIcon";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_TH_Common_MenuIcon_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_TH_Common_MenuIcon_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/MenuIcon/Container_MenuIcon onclick");
controller.onClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
"aria-label": "Toggle the Menu",
role: "button",
tabIndex: "0",
"aria-haspopup": "true"
},
style: "menu-icon",
visible: true,
_idProps: {
service: idService,
name: "Container_MenuIcon"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-hidden": "true"
},
style: "menu-icon-line",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-hidden": "true"
},
style: "menu-icon-line",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-hidden": "true"
},
style: "menu-icon-line",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore_TH.Common.MenuIcon.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "PHICore_TH.languageResources", "PHICore_TH.clientVariables", "PHICore_TH.Common.MenuIcon.mvc$debugger", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuIconListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, PHICore_THLanguageResources, PHICore_THClientVariables, PHICore_TH_Common_MenuIcon_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var setMenuIconListenersVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.setMenuIconListenersVar = setMenuIconListenersVar;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:FXArT0AZu0iVnbEAJQ4_IA:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.f5P6ln_BbUOEXW8abHQ4Ag/ClientActions.FXArT0AZu0iVnbEAJQ4_IA:zfSwAZid1y7o1eUy5vGxng", "PHICore_TH", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:HE85vU1dA0SNwemhcOEIrg", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:lfhhWePqfES5u6cGhRJd2A", callContext.id);
// Execute Action: SetMenuIconListeners
setMenuIconListenersVar.value = OutSystemsUIController.default.setMenuIconListeners$Action(callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:J8bQIJyU1kmTait3GUob_g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:FXArT0AZu0iVnbEAJQ4_IA", callContext.id);
}

};
Controller.prototype._onClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick");
callContext = controller.callContext(callContext);
var toggleSideMenuVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.toggleSideMenuVar = toggleSideMenuVar;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:HeR087G45kOeTJcXQpW3sA:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.f5P6ln_BbUOEXW8abHQ4Ag/ClientActions.HeR087G45kOeTJcXQpW3sA:ncIRMWbY0e4twMtdW4TGoA", "PHICore_TH", "OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:DWGDbIFyZk+zyRLoRk2B6A", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:KtXyQW3dYkKxu+vEWYXYVQ", callContext.id);
// Execute Action: ToggleSideMenu
toggleSideMenuVar.value = OutSystemsUIController.default.toggleSideMenu$Action(callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:Oof+fqNQzk+MFOHv7nhdMg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:HeR087G45kOeTJcXQpW3sA", callContext.id);
}

};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:Rg+NpK+sWb0P2hWAO+Ex6A", "PHICore_TH", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:f5P6ln_BbUOEXW8abHQ4Ag:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.f5P6ln_BbUOEXW8abHQ4Ag:ujSkO15EloqAPOozmoI9ew", "PHICore_TH", "MenuIcon", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:f5P6ln_BbUOEXW8abHQ4Ag", callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/MenuIcon On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common/MenuIcon On Parameters Changed");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICore_THLanguageResources);
});

define("PHICore_TH.Common.MenuIcon.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"lfhhWePqfES5u6cGhRJd2A": {
getter: function (varBag, idService) {
return varBag.setMenuIconListenersVar.value;
}
},
"KtXyQW3dYkKxu+vEWYXYVQ": {
getter: function (varBag, idService) {
return varBag.toggleSideMenuVar.value;
}
},
"z1NODhddX0e3bPUtZWmUeA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Container_MenuIcon"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
