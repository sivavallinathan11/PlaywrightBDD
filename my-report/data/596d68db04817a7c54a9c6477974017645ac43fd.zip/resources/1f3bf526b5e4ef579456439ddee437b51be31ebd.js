﻿define("Common_CW.PHICore_CW.NotificationDetail.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model"], function (OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("NotificationDescription", "notificationDescriptionIn", "NotificationDescription", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_notificationDescriptionInDataFetchStatus", "_notificationDescriptionInDataFetchStatus", "_notificationDescriptionInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("EnablePopup", "enablePopupIn", "EnablePopup", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_enablePopupInDataFetchStatus", "_enablePopupInDataFetchStatus", "_enablePopupInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("NotificationDescription" in inputs) {
this.variables.notificationDescriptionIn = inputs.NotificationDescription;
if("_notificationDescriptionInDataFetchStatus" in inputs) {
this.variables._notificationDescriptionInDataFetchStatus = inputs._notificationDescriptionInDataFetchStatus;
}

}

if("EnablePopup" in inputs) {
this.variables.enablePopupIn = inputs.EnablePopup;
if("_enablePopupInDataFetchStatus" in inputs) {
this.variables._enablePopupInDataFetchStatus = inputs._enablePopupInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.NotificationDetail");
});
define("Common_CW.PHICore_CW.NotificationDetail.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.NotificationDetail.mvc$model", "Common_CW.PHICore_CW.NotificationDetail.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_NotificationDetail_mvc_model, Common_CW_PHICore_CW_NotificationDetail_mvc_controller, Common_CWClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.NotificationDetail";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NotificationDetail_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NotificationDetail_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.enablePopupIn,
style: "popup-dialog",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
showPopup_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._enablePopupInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width11"
},
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 24px; font-weight: bold;"
},
text: ["Notification"],
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width1 ThemeGrid_MarginGutter"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "close notification",
role: "button"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/NotificationDetail/Link OnClick");
return controller.onClickClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon text-neutral-6",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 24px; font-weight: bold;"
},
text: [React.createElement("br"), React.createElement("br")],
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
value: model.variables.notificationDescriptionIn,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._notificationDescriptionInDataFetchStatus)
}), React.createElement("br"), React.createElement("br"), React.createElement("br"), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/NotificationDetail/Button OnClick");
return controller.onClickClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Close"))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.NotificationDetail.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.NotificationDetail.mvc$debugger"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_NotificationDetail_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClickClose$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickClose");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:umeYrZlqvUG+1RDgmhHPJw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.NW3kdgjGgUiPGifaMY8DCw/ClientActions.umeYrZlqvUG+1RDgmhHPJw:Lz2imSpV0SzH+5Z1fub6uw", "Common_CW", "OnClickClose", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:CUveBhviSEOI7ZjmkK07Og", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ciVOg3+Rb0aHsyHbJVgx3w", callContext.id);
// EnablePopup = False
model.variables.enablePopupIn = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ciVOg3+Rb0aHsyHbJVgx3w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// NotificationDescription = ""
model.variables.notificationDescriptionIn = "";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:EG_VMHevFUG6dWRjrBQUqQ", callContext.id);
// Trigger Event: EnableNotification
return controller.enableNotification$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7vMLYZDdsEqd7h9KPRCO8Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:umeYrZlqvUG+1RDgmhHPJw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:umeYrZlqvUG+1RDgmhHPJw", callContext.id);
throw ex;

});
};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:l3413DBp6U2zkXB7xCNf3w:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.NW3kdgjGgUiPGifaMY8DCw/ClientActions.l3413DBp6U2zkXB7xCNf3w:zYO0WfHtWHDaEsnVy9xzfA", "Common_CW", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MVeUnW7ibUizM0l2g_llgw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MHIznHuqQkCyEj5i4A3V+w", callContext.id);
// NotificationDescription = NotificationDescription
model.variables.notificationDescriptionIn = model.variables.notificationDescriptionIn;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kvZPvRtUwEONraRu6WsSAg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:l3413DBp6U2zkXB7xCNf3w", callContext.id);
}

};

Controller.prototype.onClickClose$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickClose$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.enableNotification$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:NW3kdgjGgUiPGifaMY8DCw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.NW3kdgjGgUiPGifaMY8DCw:z+w9gyvpw3tAf6pSahAE9Q", "Common_CW", "NotificationDetail", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:NW3kdgjGgUiPGifaMY8DCw", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/NotificationDetail On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.NotificationDetail.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"3bKOo2_cGkOUkFlSEmBMsg": {
getter: function (varBag, idService) {
return varBag.model.variables.notificationDescriptionIn;
},
dataType: OS.Types.Text
},
"pQo_5F2qeEKyyonbZbt1rA": {
getter: function (varBag, idService) {
return varBag.model.variables.enablePopupIn;
},
dataType: OS.Types.Boolean
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
