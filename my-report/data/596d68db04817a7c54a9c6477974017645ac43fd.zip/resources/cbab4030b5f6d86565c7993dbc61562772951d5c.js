﻿define("PHICore_TH.Common.TabEnd.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model"], function (OutSystems, PHICore_THModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "Common.TabEnd");
});
define("PHICore_TH.Common.TabEnd.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "react", "OutSystems/ReactView/Main", "PHICore_TH.Common.TabEnd.mvc$model", "PHICore_TH.Common.TabEnd.mvc$controller", "PHICore_TH.clientVariables", "OutSystems/ReactWidgets/Main"], function (OutSystems, PHICore_THModel, PHICore_THController, React, OSView, PHICore_TH_Common_TabEnd_mvc_model, PHICore_TH_Common_TabEnd_mvc_controller, PHICore_THClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.TabEnd";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_TH_Common_TabEnd_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_TH_Common_TabEnd_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onFocus: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/TabEnd/Container onfocus");
controller.onFocus$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
tabIndex: "0"
},
style: "tab-reset-ignore",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore_TH.Common.TabEnd.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "PHICore_TH.languageResources", "PHICore_TH.clientVariables", "PHICore_TH.Common.TabEnd.mvc$debugger", "PHICore_TH.Common.TabEnd.mvc$controller.OnFocus.FocusLastJS"], function (OutSystems, PHICore_THModel, PHICore_THController, PHICore_THLanguageResources, PHICore_THClientVariables, PHICore_TH_Common_TabEnd_mvc_Debugger, PHICore_TH_Common_TabEnd_mvc_controller_OnFocus_FocusLastJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onFocus$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnFocus");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:OzmPcX4O6ESVjhHUA8UAfQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.NvhGhB8K5UKYzyROLxhAIQ/ClientActions.OzmPcX4O6ESVjhHUA8UAfQ:YaddAxu3d0C_5YX42Ia9jg", "PHICore_TH", "OnFocus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:bzHkuLRkSkWijLLdBHwjfg", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:uY8679cmAkmwQZqgHtZ7jg", callContext.id);
controller.safeExecuteJSNode(PHICore_TH_Common_TabEnd_mvc_controller_OnFocus_FocusLastJS, "FocusLast", "OnFocus", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:4YAQ9ouIOEuA3GVgzBqkGw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:OzmPcX4O6ESVjhHUA8UAfQ", callContext.id);
}

};

Controller.prototype.onFocus$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onFocus$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:_8ZSWAN9BGe5YVnjHfQHoA", "PHICore_TH", "Common", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:NvhGhB8K5UKYzyROLxhAIQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.NvhGhB8K5UKYzyROLxhAIQ:v_2_kiO+_wBvl+o+faogvg", "PHICore_TH", "TabEnd", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:NvhGhB8K5UKYzyROLxhAIQ", callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICore_THLanguageResources);
});
define("PHICore_TH.Common.TabEnd.mvc$controller.OnFocus.FocusLastJS", [], function () {
return function ($actions, $roles, $public) {
document.querySelector('a[href]:not(.tab-reset-ignore), button:not([tabindex="-1"]):not(.tab-reset-ignore), input:not(.tab-reset-ignore), textarea:not(.tab-reset-ignore), select:not(.tab-reset-ignore), details:not(.tab-reset-ignore), [tabindex]:not([tabindex="-1"],article,th,.menu-icon):not(.tab-reset-ignore)').focus();
};
});

define("PHICore_TH.Common.TabEnd.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"uY8679cmAkmwQZqgHtZ7jg": {
getter: function (varBag, idService) {
return varBag.focusLastJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
