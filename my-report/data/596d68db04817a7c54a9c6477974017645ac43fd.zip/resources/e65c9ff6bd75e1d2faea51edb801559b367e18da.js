﻿define("Common_CW.Layout.Menu.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.Numbers.IconBadge.mvc$model", "PHICore_TH.Common.UserInfo.mvc$model", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund", "Common_CW.controller$Check_OA_4_ViewUserAuditLog", "Common_CW.controller$Check_SystemAdmin", "OutSystemsUI.model$ErrorMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_Numbers_IconBadge_mvcModel, PHICore_TH_Common_UserInfo_mvcModel) {
var OS = OutSystems.Internal;

var DataActionShowExitFundViewDataActRec = (function (_super) {
__extends(DataActionShowExitFundViewDataActRec, _super);
function DataActionShowExitFundViewDataActRec(defaults) {
_super.apply(this, arguments);
}
DataActionShowExitFundViewDataActRec.attributesToDeclare = function () {
return [
this.attr("CanExitFundView", "canExitFundViewOut", "CanExitFundView", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DataActionShowExitFundViewDataActRec.fromStructure = function (str) {
return new DataActionShowExitFundViewDataActRec(new DataActionShowExitFundViewDataActRec.RecordClass({
canExitFundViewOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DataActionShowExitFundViewDataActRec.init();
return DataActionShowExitFundViewDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ActiveItem", "activeItemVar", "ActiveItem", true, false, OS.Types.Integer, function () {
return -1;
}, false), 
this.attr("ActiveMenu", "activeMenuIn", "ActiveMenu", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_activeMenuInDataFetchStatus", "_activeMenuInDataFetchStatus", "_activeMenuInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("NotificationCounter", "notificationCounterIn", "NotificationCounter", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_notificationCounterInDataFetchStatus", "_notificationCounterInDataFetchStatus", "_notificationCounterInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("StaffAccessNotifCounter", "staffAccessNotifCounterIn", "StaffAccessNotifCounter", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_staffAccessNotifCounterInDataFetchStatus", "_staffAccessNotifCounterInDataFetchStatus", "_staffAccessNotifCounterInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasChange", "hasChangeIn", "HasChange", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("DataActionShowExitFundView", "dataActionShowExitFundViewDataAct", "dataActionShowExitFundViewDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new DataActionShowExitFundViewDataActRec());
}, true, DataActionShowExitFundViewDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (OutSystemsUI_Numbers_IconBadge_mvcModel.hasValidationWidgets || PHICore_TH_Common_UserInfo_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("ActiveMenu" in inputs) {
this.variables.activeMenuIn = inputs.ActiveMenu;
if("_activeMenuInDataFetchStatus" in inputs) {
this.variables._activeMenuInDataFetchStatus = inputs._activeMenuInDataFetchStatus;
}

}

if("NotificationCounter" in inputs) {
this.variables.notificationCounterIn = inputs.NotificationCounter;
if("_notificationCounterInDataFetchStatus" in inputs) {
this.variables._notificationCounterInDataFetchStatus = inputs._notificationCounterInDataFetchStatus;
}

}

if("StaffAccessNotifCounter" in inputs) {
this.variables.staffAccessNotifCounterIn = inputs.StaffAccessNotifCounter;
if("_staffAccessNotifCounterInDataFetchStatus" in inputs) {
this.variables._staffAccessNotifCounterInDataFetchStatus = inputs._staffAccessNotifCounterInDataFetchStatus;
}

}

if("HasChange" in inputs) {
this.variables.hasChangeIn = inputs.HasChange;
if("_hasChangeInDataFetchStatus" in inputs) {
this.variables._hasChangeInDataFetchStatus = inputs._hasChangeInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Layout.Menu");
});
define("Common_CW.Layout.Menu.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "Common_CW.Layout.Menu.mvc$model", "Common_CW.Layout.Menu.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Numbers.IconBadge.mvc$view", "PHICore_TH.Common.UserInfo.mvc$view", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund", "Common_CW.controller$Check_OA_4_ViewUserAuditLog", "Common_CW.controller$Check_SystemAdmin", "OutSystemsUI.model$ErrorMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUIModel, OutSystemsUIController, React, OSView, Common_CW_Layout_Menu_mvc_model, Common_CW_Layout_Menu_mvc_controller, Common_CWClientVariables, OSWidgets, OutSystemsUI_Numbers_IconBadge_mvc_view, PHICore_TH_Common_UserInfo_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Layout.Menu";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Numbers_IconBadge_mvc_view, PHICore_TH_Common_UserInfo_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_Layout_Menu_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_Layout_Menu_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.AdvancedHtml, {
extendedProperties: {
className: "app-menu-content display-flex",
role: "navigation"
},
tag: "nav",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "menubar"
},
gridProperties: {
classes: "ThemeGrid_Width10"
},
style: "app-menu-links",
visible: true,
_idProps: {
service: idService,
name: "PageLinks"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(false, false, this, function () {
return [];
}, function () {
return [];
}), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/LinkDashboard OnClick");
return controller.onClick_Dashboard$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("LinkDashboard.Style"), function () {
return (((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.dashboard)) ? (" active") : (""));
}, function () {
return model.variables.activeMenuIn;
}),
visible: model.getCachedValue(idService.getId("LinkDashboard.Visible"), function () {
return !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_HAMBSAdmin$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id));
}),
_idProps: {
service: idService,
name: "LinkDashboard"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._activeMenuInDataFetchStatus)
}, "Dashboard"), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
style: model.getCachedValue(idService.getId("LinkFunds.Style"), function () {
return (((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.fundsHAMBS)) ? (" active") : (""));
}, function () {
return model.variables.activeMenuIn;
}),
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("/Configurations/", {}),
visible: model.getCachedValue(idService.getId("LinkFunds.Visible"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_HAMBSAdmin$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
_idProps: {
service: idService,
name: "LinkFunds"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._activeMenuInDataFetchStatus)
}, "Funds"), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/Link OnClick");
return controller.onClick_MyFund$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("uUKKlsn+Ikq3DfeK5mVL0g.Style"), function () {
return (((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.fundAdministration)) ? (" active") : (""));
}, function () {
return model.variables.activeMenuIn;
}),
visible: model.getCachedValue(idService.getId("uUKKlsn+Ikq3DfeK5mVL0g.Visible"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ConfigureFund$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._activeMenuInDataFetchStatus)
}, "My Fund"), React.createElement(OSWidgets.Link, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/Menu_Audit OnClick");
return controller.onClick_Audit$Action("/FundAdministration/Audit", controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("Menu_Audit.Style"), function () {
return (((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.audit)) ? (" active") : (""));
}, function () {
return model.variables.activeMenuIn;
}),
visible: model.getCachedValue(idService.getId("Menu_Audit.Visible"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_OA_4_ViewUserAuditLog$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
_idProps: {
service: idService,
name: "Menu_Audit"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._activeMenuInDataFetchStatus)
}, "Audit")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width2"
},
style: "margin-right-base align-self-center",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(false, false, this, function () {
return [];
}, function () {
return [];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "align-self-center margin-right-m",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.notificationCounterIn > 0), false, this, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "Notification"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/NotificationWithCounterLink OnClick");
controller.event_NotificationClicked$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
name: "NotificationWithCounterLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Numbers_IconBadge_mvc_view, {
inputs: {
Color: Common_CWModel.staticEntities.color.red,
Number: OS.BuiltinFunctions.integerToLongInteger(model.variables.notificationCounterIn),
_numberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._notificationCounterInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "bell",
iconSize: /*Twotimes*/ 1,
style: "top_navigator_icon addtab",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "Notification"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/NotificationWithoutCounterLink OnClick");
controller.event_NotificationClicked$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
name: "NotificationWithoutCounterLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "bell",
iconSize: /*Twotimes*/ 1,
style: "top_navigator_icon addtab",
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "ph margin-right-m align-self-center",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SystemAdmin$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right margin-right-base",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": ("Request Access Notification " + (model.variables.staffAccessNotifCounterIn).toString())
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/RequestAccessNotification OnClick");
controller.event_RequestAccessClicked$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
name: "RequestAccessNotification"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.staffAccessNotifCounterIn > 0), false, this, function () {
return [React.createElement(OutSystemsUI_Numbers_IconBadge_mvc_view, {
inputs: {
Color: Common_CWModel.staticEntities.color.red,
Number: OS.BuiltinFunctions.integerToLongInteger(model.variables.staffAccessNotifCounterIn),
_numberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._staffAccessNotifCounterInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "key",
iconSize: /*Twotimes*/ 1,
style: "top_navigator_icon addtab",
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
})];
}, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "key",
iconSize: /*Twotimes*/ 1,
style: "top_navigator_icon addtab",
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})))];
}, function () {
return [];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "app-login-info ph",
visible: true,
_idProps: {
service: idService,
name: "LoginInfo"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(PHICore_TH_Common_UserInfo_mvc_view, {
inputs: {
ShowExitFundView: model.variables.dataActionShowExitFundViewDataAct.canExitFundViewOut,
_showExitFundViewInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.dataActionShowExitFundViewDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_ExitFundView$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/UserInfo Event_ExitFundView");
return controller.userInfoEvent_ExitFundView$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu/Container onclick");
controller.hideMenu$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
role: "button"
},
style: "app-menu-overlay",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.Layout.Menu.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.Layout.Menu.mvc$debugger", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund", "Common_CW.controller$Check_OA_4_ViewUserAuditLog", "Common_CW.controller$Check_SystemAdmin", "OutSystemsUI.model$ErrorMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetMenuListeners", "OutSystemsUI.controller$ToggleSideMenu"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUIModel, OutSystemsUIController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_Layout_Menu_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
dataActionShowExitFundView$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
dataActionShowExitFundView$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions
Controller.prototype.returnToHAMBS$ServerAction = function (callContext) {
var controller = this.controller;
return controller.callServerAction("ReturnToHAMBS", "screenservices/Common_CW/Layout/Menu/ActionReturnToHAMBS", "hQycj00egGnOBH8gn+SXCQ", {}, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
});
};

// Aggregates and Data Actions
Controller.prototype.dataActionShowExitFundView$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:84rslNUkBk2ZwWnHCY+76A:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/DataActions.84rslNUkBk2ZwWnHCY+76A:LWCvTrENxLkKAKxvGf2epg", "Common_CW", "DataActionShowExitFundView", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Layout/Menu/DataActionShowExitFundView");
return controller.callDataAction("DataActionDataActionShowExitFundView", "screenservices/Common_CW/Layout/Menu/DataActionDataActionShowExitFundView", "5CIPXflsSgqGHk2WVxnxVw", function (b) {
model.variables.dataActionShowExitFundViewDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.dataActionShowExitFundViewDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.dataActionShowExitFundViewDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, undefined, false);

}, function () {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:84rslNUkBk2ZwWnHCY+76A", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["dataActionShowExitFundView$DataActRefresh"];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:epc5DdT08Eu7lnrWNw0S1Q:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.epc5DdT08Eu7lnrWNw0S1Q:Q0gvdSuthMTuj02Lk_ZJiQ", "Common_CW", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+Spj3_9+Ikqja55v5PdyqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ASpFyXvir06xVwDfLG8fLw", callContext.id);
// ActiveItem = If
model.variables.activeItemVar = (((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.dashboard)) ? (1) : ((((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.cases)) ? (1) : ((((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.batchProcess)) ? (2) : ((((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.fundsHAMBS)) ? (3) : ((((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.fundAdministration)) ? (4) : ((((model.variables.activeMenuIn === Common_CWModel.staticEntities.menuItems.audit)) ? (6) : (5))))))))))));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:v3NF11RaB0meI5hNI+QB8Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:epc5DdT08Eu7lnrWNw0S1Q", callContext.id);
}

};
Controller.prototype._onClick_MyFund$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_MyFund");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Obb9I7rdKU6H8zaRjPZOpg:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.Obb9I7rdKU6H8zaRjPZOpg:t4t5_zvgNaHmZEQaDD9g5Q", "Common_CW", "OnClick_MyFund", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:4RQY9ZIuqk+QVzV_7iNBnQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:a8Ck38b4f0OeA846jKxxNw", callContext.id) && (model.variables.hasChangeIn === true))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:og7D80qwcUq6undgc7AU0w", callContext.id);
// Trigger Event: Event_AuditClicked
return controller.event_MenuClicked$Action(Common_CWModel.staticEntities.menuItems.fundAdministration, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Xc5zzrSYY06v3MuttuK5Sw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kYFGoeCxgk2XhSif5wGg8g", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/FundAdministration/", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Obb9I7rdKU6H8zaRjPZOpg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Obb9I7rdKU6H8zaRjPZOpg", callContext.id);
throw ex;

});
};
Controller.prototype._onClick_Audit$Action = function (uRLIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Audit");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Layout.Menu.OnClick_Audit$vars"))());
vars.value.uRLInLocal = uRLIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:MBUUKnG9m0WemftRaFnoTQ:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.MBUUKnG9m0WemftRaFnoTQ:H_EpdHZsMnRCAVg4XAAdPg", "Common_CW", "OnClick_Audit", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cP4gTWrr8UWwM7C_KjggXA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:eVOQa1FabEqhOWY4HbkROQ", callContext.id) && (model.variables.hasChangeIn === true))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Wpahq+GDSE2lmS_RL43KxA", callContext.id);
// Trigger Event: Event_AuditClicked
return controller.event_MenuClicked$Action(Common_CWModel.staticEntities.menuItems.audit, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:no7cCJCbAkmqn2YUjbrTTQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FZjPeMWHEUW4GwG7PzqjVA", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(vars.value.uRLInLocal, {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:MBUUKnG9m0WemftRaFnoTQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:MBUUKnG9m0WemftRaFnoTQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("Common_CW.Layout.Menu.OnClick_Audit$vars", [{
name: "URL",
attrName: "uRLInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
var setMenuListenersVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.setMenuListenersVar = setMenuListenersVar;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8PeLRqE78kuCuO5IibOuUg:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.8PeLRqE78kuCuO5IibOuUg:VIdCODdFnSKWZwpqX+Ennw", "Common_CW", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LwTf6U5EUky63meUMd3kSg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:UqnDUbp95ka1QJmvMpvXUQ", callContext.id);
// Execute Action: SetMenuListeners
setMenuListenersVar.value = OutSystemsUIController.default.setMenuListeners$Action("", callContext);

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tY5Q2koYnE+xi5y+F7c+PQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8PeLRqE78kuCuO5IibOuUg", callContext.id);
}

};
Controller.prototype._userInfoEvent_ExitFundView$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("UserInfoEvent_ExitFundView");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:wtJXhZvGeEGjh74whMS4CQ:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.wtJXhZvGeEGjh74whMS4CQ:Ukta4akAZoBUylYSnV9GOg", "Common_CW", "UserInfoEvent_ExitFundView", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gv8vZqH0A0OquNeVcni2bg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NPhB05ED10aFxdqnE0nonQ", callContext.id);
// Execute Action: ReturnToHAMBS
model.flush();
return controller.returnToHAMBS$ServerAction(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9nytex5XU0yliVfRt16jOQ", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Logged out successfully", /*Success*/ 1);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gCNuigYyTkeuzII9JVP0Qw", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/Configurations", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:wtJXhZvGeEGjh74whMS4CQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:wtJXhZvGeEGjh74whMS4CQ", callContext.id);
throw ex;

});
};
Controller.prototype._placeholderOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("placeholderOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:hTWmjFbjTkGs2aM6gI4GwA:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.hTWmjFbjTkGs2aM6gI4GwA:jUkT9lmXOC9caq6lbC8NTw", "Common_CW", "placeholderOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cnJPz44d9Ey+RWuQoWODEw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ED5meUaKIkqqD2RflMVXrw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:hTWmjFbjTkGs2aM6gI4GwA", callContext.id);
}

};
Controller.prototype._hideMenu$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("HideMenu");
callContext = controller.callContext(callContext);
var toggleSideMenuVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.toggleSideMenuVar = toggleSideMenuVar;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:awhXpboqykuxRz2IQEILUQ:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.awhXpboqykuxRz2IQEILUQ:EdtKWGiIF7RrzWMxEY73wA", "Common_CW", "HideMenu", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:w1kRlq2JikCJOOPGWPMjlg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ufsg4pTO1kGyBWB2Vk0cHQ", callContext.id);
// Execute Action: ToggleSideMenu
toggleSideMenuVar.value = OutSystemsUIController.default.toggleSideMenu$Action(callContext);

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:chau1MRa7UKGNad_JvBAkQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:awhXpboqykuxRz2IQEILUQ", callContext.id);
}

};
Controller.prototype._onClick_Dashboard$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Dashboard");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:JRCQzchKpkihOBe23+uS4A:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg/ClientActions.JRCQzchKpkihOBe23+uS4A:_OTQC3dBOjPmxQu5oAoFHw", "Common_CW", "OnClick_Dashboard", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:U197JJ1ooUSFNy5wIofsRw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pUkeYLSYQEu52s2MsH3kWg", callContext.id) && (model.variables.hasChangeIn === true))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5KKTAbbPTEiMmarcUgnDzA", callContext.id);
// Trigger Event: Event_MenuClicked
return controller.event_MenuClicked$Action(Common_CWModel.staticEntities.menuItems.dashboard, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wL9_zBzG6k+uFYlDulDINQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7nMfYitQ6UewhYpRtpD3Ig", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore/Dashboard", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:JRCQzchKpkihOBe23+uS4A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:JRCQzchKpkihOBe23+uS4A", callContext.id);
throw ex;

});
};

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onClick_MyFund$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_MyFund$Action, callContext);

};
Controller.prototype.onClick_Audit$Action = function (uRLIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Audit$Action, callContext, uRLIn);

};
Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.userInfoEvent_ExitFundView$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._userInfoEvent_ExitFundView$Action, callContext);

};
Controller.prototype.placeholderOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._placeholderOnClick$Action, callContext);

};
Controller.prototype.hideMenu$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._hideMenu$Action, callContext);

};
Controller.prototype.onClick_Dashboard$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Dashboard$Action, callContext);

};
Controller.prototype.event_MenuClicked$Action = function () {
return Promise.resolve();
};
Controller.prototype.event_RequestAccessClicked$Action = function () {
return Promise.resolve();
};
Controller.prototype.event_NotificationClicked$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:CXKDJBIxPU+BualzHyV1Tw:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw:+ip67PF_zEBMA1phPsC2+Q", "Common_CW", "Layout", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:PExKGt9RxkSBSXAB_V4xdg:/NRWebFlows.CXKDJBIxPU+BualzHyV1Tw/NodesShownInESpaceTree.PExKGt9RxkSBSXAB_V4xdg:CCVNiiHr45ZsHXetDhSfvQ", "Common_CW", "Menu", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:PExKGt9RxkSBSXAB_V4xdg", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:CXKDJBIxPU+BualzHyV1Tw", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layout/Menu On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layout/Menu On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.Layout.Menu.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Bbk20SV7+ESRsnMrl4UZ3A": {
getter: function (varBag, idService) {
return varBag.vars.value.uRLInLocal;
},
dataType: OS.Types.Text
},
"UqnDUbp95ka1QJmvMpvXUQ": {
getter: function (varBag, idService) {
return varBag.setMenuListenersVar.value;
}
},
"Ufsg4pTO1kGyBWB2Vk0cHQ": {
getter: function (varBag, idService) {
return varBag.toggleSideMenuVar.value;
}
},
"gYptRPNgDUqZ416vS72rFw": {
getter: function (varBag, idService) {
return varBag.model.variables.activeItemVar;
},
dataType: OS.Types.Integer
},
"CT2UrS6YDEmaXvsoMQ2ufA": {
getter: function (varBag, idService) {
return varBag.model.variables.activeMenuIn;
},
dataType: OS.Types.Integer
},
"+MvC6xTMW0q2xOy20KlKhA": {
getter: function (varBag, idService) {
return varBag.model.variables.notificationCounterIn;
},
dataType: OS.Types.Integer
},
"M3J1HmJxoUSnqKEVH527Qg": {
getter: function (varBag, idService) {
return varBag.model.variables.staffAccessNotifCounterIn;
},
dataType: OS.Types.Integer
},
"kQ234xb9bU6q7DadyUXsGg": {
getter: function (varBag, idService) {
return varBag.model.variables.hasChangeIn;
},
dataType: OS.Types.Boolean
},
"84rslNUkBk2ZwWnHCY+76A": {
getter: function (varBag, idService) {
return varBag.model.variables.dataActionShowExitFundViewDataAct;
}
},
"4NgBDh1Fl0OLsIk3uHu5kA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PageLinks"));
})(varBag.model, idService);
}
},
"0kl4T0AImkeCLZJYIrnxWQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LinkDashboard"));
})(varBag.model, idService);
}
},
"o63otNeHsEW5riO+0aSe4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LinkFunds"));
})(varBag.model, idService);
}
},
"rZXWR+hWJ0yhwyGf4psqBw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Menu_Audit"));
})(varBag.model, idService);
}
},
"+3TttowTAkeIpHMqAebDgw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NotificationWithCounterLink"));
})(varBag.model, idService);
}
},
"FpD08bJO8k+mjc11u4wgaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"QDMENPbmkEyYUmJVf7k4AA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NotificationWithoutCounterLink"));
})(varBag.model, idService);
}
},
"idsl4r15Vkud8co9lJuweQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("RequestAccessNotification"));
})(varBag.model, idService);
}
},
"OZ4NlTp0Kkuk6WKH9CxXGw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"ODYuJlgxP0CSStVgUPJklA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LoginInfo"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
