﻿define("LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$model", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model"], function (OutSystems, LazyDropdownSearchModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model, "LazyDropdownSearch.EventSwallowingOnClickContainer");
});
define("LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$view", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "react", "OutSystems/ReactView/Main", "LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$model", "LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$controller", "OutSystems/ReactWidgets/Main"], function (OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, React, OSView, LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_model, LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "LazyDropdownSearch.EventSwallowingOnClickContainer";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.content,
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$controller", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "LazyDropdownSearch.languageResources", "LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$debugger", "LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$controller.OnReady.AddOnClick_PreventDefaultJS"], function (OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, LazyDropdownSearchLanguageResources, LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_Debugger, LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_controller_OnReady_AddOnClick_PreventDefaultJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
throwOnClick$Action: function () {
return controller.executeActionInsideJSNode(controller._throwOnClick$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ThrowOnClick");
},
throwOnTouchStart$Action: function () {
return controller.executeActionInsideJSNode(controller._throwOnTouchStart$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ThrowOnTouchStart");
},
throwOnTouchMove$Action: function () {
return controller.executeActionInsideJSNode(controller._throwOnTouchMove$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ThrowOnTouchMove");
},
throwOnTouchEnd$Action: function () {
return controller.executeActionInsideJSNode(controller._throwOnTouchEnd$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ThrowOnTouchEnd");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._throwOnTouchStart$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ThrowOnTouchStart");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:8_HRSNCAkUG8Hm_WhHoR7g:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig/ClientActions.8_HRSNCAkUG8Hm_WhHoR7g:27Gfd5Y_soi3engGLogIsg", "LazyDropdownSearch", "ThrowOnTouchStart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:odJkytUlCEux+uRYQU09VA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:P4hYyPxYfEOGS9Bjm8JliA", callContext.id);
// Trigger Event: OnTouchStart
return controller.onTouchStart$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:05hAmF4VcUKxjmZwdnnEtA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:8_HRSNCAkUG8Hm_WhHoR7g", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:8_HRSNCAkUG8Hm_WhHoR7g", callContext.id);
throw ex;

});
};
Controller.prototype._throwOnTouchEnd$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ThrowOnTouchEnd");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:U8EicJxymEyPUMkANov1fA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig/ClientActions.U8EicJxymEyPUMkANov1fA:pamlmzp7MpTu4q8+5BS3Og", "LazyDropdownSearch", "ThrowOnTouchEnd", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:T7FS3nJYYUaU+0CY4NxiXw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:M9lgqND4l0Wh5h0FIumWTw", callContext.id);
// Trigger Event: OnTouchEnd
return controller.onTouchEnd$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:xmuaQqcosESaxPABkqAtpw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:U8EicJxymEyPUMkANov1fA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:U8EicJxymEyPUMkANov1fA", callContext.id);
throw ex;

});
};
Controller.prototype._throwOnTouchMove$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ThrowOnTouchMove");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:0zFy35Hf6EyU7h93IfS3rA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig/ClientActions.0zFy35Hf6EyU7h93IfS3rA:bCiheaS+Sca21ew0QS61wQ", "LazyDropdownSearch", "ThrowOnTouchMove", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:iHo88tJB50WriqjKu8DhXg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:o2MjU5D4sUCK2EuZjbg0gQ", callContext.id);
// Trigger Event: OnTouchMove
return controller.onTouchMove$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:A5m24G8ls0+umisAVKh5rA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:0zFy35Hf6EyU7h93IfS3rA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:0zFy35Hf6EyU7h93IfS3rA", callContext.id);
throw ex;

});
};
Controller.prototype._throwOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ThrowOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:Bqlj6CD+qEOaumpmWHmSWw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig/ClientActions.Bqlj6CD+qEOaumpmWHmSWw:GUpU1QB4ShJT7YzLp+S+jA", "LazyDropdownSearch", "ThrowOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:3faIyvCMY0qwsb5+inaCbg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:XbNZzY_FkU2WnODg+X87TA", callContext.id);
// Trigger Event: OnClick
return controller.onClick$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Vo4J9iOYekKXgLBfdxFtlQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:Bqlj6CD+qEOaumpmWHmSWw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:Bqlj6CD+qEOaumpmWHmSWw", callContext.id);
throw ex;

});
};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:m86A_emY0UuHNHBOOInyPg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig/ClientActions.m86A_emY0UuHNHBOOInyPg:A1CX2IIanR+qx_I+cyvLXQ", "LazyDropdownSearch", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:xrKKvztW1U+tUOIdyRqbZg", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:WfkygBQEKkO4nq80g6jsKQ", callContext.id);
controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_controller_OnReady_AddOnClick_PreventDefaultJS, "AddOnClick_PreventDefault", "OnReady", {
ContentId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Content"), OS.Types.Text)
}, function ($parameters) {
}, {
ThrowOnClick: controller.clientActionProxies.throwOnClick$Action,
ThrowOnTouchStart: controller.clientActionProxies.throwOnTouchStart$Action,
ThrowOnTouchMove: controller.clientActionProxies.throwOnTouchMove$Action,
ThrowOnTouchEnd: controller.clientActionProxies.throwOnTouchEnd$Action
}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:iKHutf+D3keI+UoYhUrejg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:m86A_emY0UuHNHBOOInyPg", callContext.id);
}

};

Controller.prototype.throwOnTouchStart$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._throwOnTouchStart$Action, callContext);

};
Controller.prototype.throwOnTouchEnd$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._throwOnTouchEnd$Action, callContext);

};
Controller.prototype.throwOnTouchMove$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._throwOnTouchMove$Action, callContext);

};
Controller.prototype.throwOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._throwOnClick$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onTouchMove$Action = function () {
return Promise.resolve();
};
Controller.prototype.onClick$Action = function () {
return Promise.resolve();
};
Controller.prototype.onTouchEnd$Action = function () {
return Promise.resolve();
};
Controller.prototype.onTouchStart$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:gAB2YSYp1WGF5W4ME5QXJg", "LazyDropdownSearch", "LazyDropdownSearch", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:SE2sZu46I0S3oIl8cvJ2Ig:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.SE2sZu46I0S3oIl8cvJ2Ig:SLPICDLsloGXxsyM3fKitA", "LazyDropdownSearch", "EventSwallowingOnClickContainer", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:SE2sZu46I0S3oIl8cvJ2Ig", callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LazyDropdownSearch/EventSwallowingOnClickContainer On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return LazyDropdownSearchController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, LazyDropdownSearchLanguageResources);
});
define("LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$controller.OnReady.AddOnClick_PreventDefaultJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
const contentDiv = document.getElementById($parameters.ContentId);

contentDiv.addEventListener("click", (e) => {
        $actions.ThrowOnClick();
        e.preventDefault(); 
});
contentDiv.addEventListener("touchstart", (e) => {
        $actions.ThrowOnTouchStart();
});
contentDiv.addEventListener("touchmove", (e) => {
        $actions.ThrowOnTouchMove();
});
contentDiv.addEventListener("touchend", (e) => {
        $actions.ThrowOnTouchEnd();
        e.preventDefault(); 
});

};
});

define("LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"WfkygBQEKkO4nq80g6jsKQ": {
getter: function (varBag, idService) {
return varBag.addOnClick_PreventDefaultJSResult.value;
}
},
"N8jQTf4mokSIWvBvM+7jRg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
