﻿define("PHICore.Common_Widgets.CaseStatusGraphCard.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsUI.Utilities.AlignCenter.mvc$model", "Common_CW.PHICore_CW.Filter.mvc$model", "OutSystemsCharts.Version1.DonutChart_v1.mvc$model", "PHICore.Common_Widgets.GraphFilter.mvc$model", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsUI_Utilities_AlignCenter_mvcModel, Common_CW_PHICore_CW_Filter_mvcModel, OutSystemsCharts_Version1_DonutChart_v1_mvcModel, PHICore_Common_Widgets_GraphFilter_mvcModel) {
var OS = OutSystems.Internal;
var GetTeamUsersByUserIdAggrRec = (function (_super) {
__extends(GetTeamUsersByUserIdAggrRec, _super);
function GetTeamUsersByUserIdAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamUsersByUserIdAggrRec.RecordListType = PHICoreModel.TeamTeamUserRecordList;
GetTeamUsersByUserIdAggrRec.init();
return GetTeamUsersByUserIdAggrRec;
})(OS.Model.AggregateRecord);
var GetCasesAggrRec = (function (_super) {
__extends(GetCasesAggrRec, _super);
function GetCasesAggrRec(defaults) {
_super.apply(this, arguments);
}
GetCasesAggrRec.RecordListType = PHICoreModel.StatusIdentifierTextTextLongIntegerRecordList;
GetCasesAggrRec.init();
return GetCasesAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SelectedMonthInt", "selectedMonthIntVar", "SelectedMonthInt", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("DataPointList", "dataPointListVar", "DataPointList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.Legacy_DataPointList());
}, false, PHICoreModel.Legacy_DataPointList), 
this.attr("ShowFilter", "showFilterVar", "ShowFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GraphFilter", "graphFilterVar", "GraphFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.GraphFilterStrucRec());
}, false, PHICoreModel.GraphFilterStrucRec), 
this.attr("SelectedTeams", "selectedTeamsVar", "SelectedTeams", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("GraphFilter_Original", "graphFilter_OriginalVar", "GraphFilter_Original", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.GraphFilterStrucRec());
}, false, PHICoreModel.GraphFilterStrucRec), 
this.attr("RefreshFilter", "refreshFilterVar", "RefreshFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GetTeamUsersByUserId", "getTeamUsersByUserIdAggr", "getTeamUsersByUserIdAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamUsersByUserIdAggrRec());
}, true, GetTeamUsersByUserIdAggrRec), 
this.attr("GetCases", "getCasesAggr", "getCasesAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCasesAggrRec());
}, true, GetCasesAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((OutSystemsUI_Utilities_AlignCenter_mvcModel.hasValidationWidgets || Common_CW_PHICore_CW_Filter_mvcModel.hasValidationWidgets) || OutSystemsCharts_Version1_DonutChart_v1_mvcModel.hasValidationWidgets) || PHICore_Common_Widgets_GraphFilter_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.CaseStatusGraphCard");
});
define("PHICore.Common_Widgets.CaseStatusGraphCard.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.CaseStatusGraphCard.mvc$model", "PHICore.Common_Widgets.CaseStatusGraphCard.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "Common_CW.PHICore_CW.Filter.mvc$view", "OutSystemsCharts.Version1.DonutChart_v1.mvc$view", "PHICore.Common_Widgets.GraphFilter.mvc$view", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, React, OSView, PHICore_Common_Widgets_CaseStatusGraphCard_mvc_model, PHICore_Common_Widgets_CaseStatusGraphCard_mvc_controller, PHICoreClientVariables, OSWidgets, OutSystemsUI_Utilities_AlignCenter_mvc_view, Common_CW_PHICore_CW_Filter_mvc_view, OutSystemsCharts_Version1_DonutChart_v1_mvc_view, PHICore_Common_Widgets_GraphFilter_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.CaseStatusGraphCard";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Utilities_AlignCenter_mvc_view, Common_CW_PHICore_CW_Filter_mvc_view, OutSystemsCharts_Version1_DonutChart_v1_mvc_view, PHICore_Common_Widgets_GraphFilter_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_CaseStatusGraphCard_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_CaseStatusGraphCard_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Container_CaseGraph.Style"), function () {
return ("dashboard-card" + ((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) ? ("") : (" disabled")));
}),
visible: true,
_idProps: {
service: idService,
name: "Container_CaseGraph"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
extendedProperties: {
style: "font-size: 22px;"
},
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Case Status"), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: model.getCachedValue(idService.getId("bSB1Mstm20q+_NdHooAlRg.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/CaseStatusGraphCard/Link OnClick");
controller.onToggle_GraphFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_Filter_mvc_view, {
inputs: {
ShowAsEnabled: model.getCachedValue(idService.getId("Kz6Hr32pH02PzlzTzhYfUw.ShowAsEnabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))];
})
},
_dependencies: []
})), React.createElement(OutSystemsCharts_Version1_DonutChart_v1_mvc_view, {
inputs: {
SourceDataPointList: model.variables.dataPointListVar,
AdvancedFormat: model.getCachedValue(idService.getId("QTm+YI0F7UCc0VOwaLE9Qw.AdvancedFormat"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsChartsController.default.advancedFormat_Init_v1$Action(new PHICoreModel.Legacy_AdvancedDataPointFormatList(), new PHICoreModel.Legacy_AdvancedDataSeriesFormatList(), "", "", (("    plotOptions: {\r\n        pie:{\r\n            size: \'90%\',\r\n            innerSize: \'80%\',\r\n            borderWidth: 3\r\n        }\r\n    },\r\n    legend: {\r\n        enabled: " + ((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) ? ("true") : ("false"))) + "\r\n    }"), callContext).advancedFormatOut;
}, OS.Types.Record, callContext.id);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(PHICore_Common_Widgets_GraphFilter_mvc_view, {
inputs: {
CallToRefresh: (model.variables.refreshFilterVar ? "True" : "False"),
GraphFilterStruc: model.variables.graphFilterVar,
ShowPopup: model.variables.showFilterVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_Filter$Action: function (graphFilterOutIn, closePopUpIn, isProceedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter Event_Filter");
return controller.onEvent_GraphFilter$Action(graphFilterOutIn, closePopUpIn, isProceedIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.CaseStatusGraphCard.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.CaseStatusGraphCard.mvc$debugger", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$StatusIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_CaseStatusGraphCard_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getTeamUsersByUserId$AggrRefresh: 0,
getCases$AggrRefresh: -1
};
this.dataFetchDependentsGraph = {
getTeamUsersByUserId$AggrRefresh: [],
getCases$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getTeamUsersByUserId$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:deJ_FnDt+kiWktWp8WUXAg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ScreenDataSets.deJ_FnDt+kiWktWp8WUXAg:5XLmRDJTjW+vPJSo_kjtBw", "PHICore", "GetTeamUsersByUserId", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard/GetTeamUsersByUserId");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeamUsersByUserId", "screenservices/PHICore/Common_Widgets/CaseStatusGraphCard/ScreenDataSetGetTeamUsersByUserId", "mbQgRut1VxIL+ABqUg5WJA", maxRecords, startIndex, function (b) {
model.variables.getTeamUsersByUserIdAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamUsersByUserIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamUsersByUserIdAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard/GetTeamUsersByUserId On After Fetch");
return controller._onAfterFetch_GetTeamUsersByUserId$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:deJ_FnDt+kiWktWp8WUXAg", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getCases$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:gFd31KGfFkGEMtLcHGi+uQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ScreenDataSets.gFd31KGfFkGEMtLcHGi+uQ:KiiGuXDOjfOrWWBXx5HaMg", "PHICore", "GetCases", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard/GetCases");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetCases", "screenservices/PHICore/Common_Widgets/CaseStatusGraphCard/ScreenDataSetGetCases", "KRe7zlBV7MX_mI_KRFCIig", maxRecords, startIndex, function (b) {
model.variables.getCasesAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCasesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCasesAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard/GetCases On After Fetch");
controller._onAfterFetch_GetCases$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:gFd31KGfFkGEMtLcHGi+uQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTeamUsersByUserId$AggrRefresh", "getCases$AggrRefresh"];
// Client Actions
Controller.prototype._onRender$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRender");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:sb09JXBqtEaR_9YArDeOnA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.sb09JXBqtEaR_9YArDeOnA:VKOtMIdFvC+hjd9lzZitxw", "PHICore", "OnRender", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iBVmjTR5Q0u7BMoi4yyunA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EnV+lWIFUEWk8hHg2vLkVQ", callContext.id);
// Trigger Event: OnInitialized
return controller.onInitialized$Action(idService.getId("Container_CaseGraph"), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:N17+af4A1kuYnaVC6_QpVg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:sb09JXBqtEaR_9YArDeOnA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:sb09JXBqtEaR_9YArDeOnA", callContext.id);
throw ex;

});
};
Controller.prototype._onToggle_GraphFilter$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnToggle_GraphFilter");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:gOGHWXvm40WmgSKm9yxTDQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.gOGHWXvm40WmgSKm9yxTDQ:rbJvXEUJWmTsVhWXZPHqPQ", "PHICore", "OnToggle_GraphFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tA1R_62rkUWPB7GidHEjKQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d2M0VWEUNkqcMf5Z3OehOQ", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uBOfiANnhEW4E+AZV96OHQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bK6zvLG7_UG8WCP54T+tzA", callContext.id);
// ShowFilter = notShowFilter
model.variables.showFilterVar = !(model.variables.showFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NOv1AvjXrkCrH2YQzzgMeA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:gOGHWXvm40WmgSKm9yxTDQ", callContext.id);
}

};
Controller.prototype._onAfterFetch_GetTeamUsersByUserId$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch_GetTeamUsersByUserId");
callContext = controller.callContext(callContext);
var mSD_JoinIDsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.mSD_JoinIDsVar = mSD_JoinIDsVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:fLEwaWVgTki+f9AE_kNIng:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.fLEwaWVgTki+f9AE_kNIng:VjIg06LJ8xbLKLbUTQUHIA", "PHICore", "OnAfterFetch_GetTeamUsersByUserId", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tp9oeMLST0Gia9c6lmujBA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oC47SiN30EGQL0k1R6ZYHg", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.graphFilterVar.selectedTeamAttr, OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getTeamUsersByUserIdAggr.listOut, new PHICoreModel.MSD_ItemList(), function (source, target) {
target.isSelectedAttr = true;
target.itemIdAttr = OS.BuiltinFunctions.longIntegerToText(source.teamAttr.idAttr);
target.descriptionAttr = source.teamAttr.nameAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9WDsATxFgUOOq6ojgKmVEw", callContext.id);
// Execute Action: MSD_JoinIDs
mSD_JoinIDsVar.value = Common_CWController.default.mSD_JoinIDs$Action(model.variables.graphFilterVar.selectedTeamAttr, "|", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p3PBX+um_kWJtrKw_Mn7kA", callContext.id);
// SelectedTeams = MSD_JoinIDs.JoinedStrings
model.variables.selectedTeamsVar = mSD_JoinIDsVar.value.joinedStringsOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p3PBX+um_kWJtrKw_Mn7kA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// GraphFilter_Original = GraphFilter
model.variables.graphFilter_OriginalVar = model.variables.graphFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w1ySBdWhUkycf__Knw0b8w", callContext.id);
// Refresh Query: GetCases
var result = controller.getCases$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L4F+pcWpAEOzMARnGDLxfQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fLEwaWVgTki+f9AE_kNIng", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fLEwaWVgTki+f9AE_kNIng", callContext.id);
throw ex;

});
};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:tkNrwnTn2UCHnsPi+YV8HA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.tkNrwnTn2UCHnsPi+YV8HA:80Z4FKEBcxPOakIsiSk3kA", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:R5oJ_HpeqUOsjbu9JiY5zg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:m0mV0RCeWEOSPR+c9PxKCA", callContext.id);
// Trigger Event: OnInitialized
return controller.onInitialized$Action(idService.getId("Container_CaseGraph"), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:olRvihZSnUqqJf5eS5PXGA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:tkNrwnTn2UCHnsPi+YV8HA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:tkNrwnTn2UCHnsPi+YV8HA", callContext.id);
throw ex;

});
};
Controller.prototype._onAfterFetch_GetCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch_GetCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.CaseStatusGraphCard.OnAfterFetch_GetCases$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:diTy3MNuLkqKitx0WBX3Zw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.diTy3MNuLkqKitx0WBX3Zw:uOrGRuD0o7kbSekFHmDdng", "PHICore", "OnAfterFetch_GetCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n2zviDFBqk+DUxP5BuYVTQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hzNVZZ7Ep0C9Ewm47RUvNw", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.dataPointListVar, callContext);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NjxfkAckU0S_5UyI3Rj3Yg", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
// Foreach GetCases.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesAggr.listOut);
try {var getCasesIterator = callContext.iterationContext.getIterator(model.variables.getCasesAggr.listOut);
var getCasesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DfeNF365dEeBXw_rTww3cw", callContext.id) && (getCasesIndex < model.variables.getCasesAggr.listOut.length))) {
getCasesIterator.currentRowNumber = getCasesIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rl_bYW0DHkmJBPbLwV62fw", callContext.id);
// TempTotal = TempTotal + GetCases.List.Current.Count
vars.value.tempTotalVar = vars.value.tempTotalVar.add(model.variables.getCasesAggr.listOut.getItem(getCasesIndex.valueOf()).countAttr);
getCasesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesAggr.listOut);
}

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_QXfEmRK2U6NLwddn_AprA", callContext.id);
// TempTotal = 0
vars.value.tempTotalVar = OS.BuiltinFunctions.integerToLongInteger(0);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bQMtJsl_aEKo7ZDBDMwMgA", callContext.id);
// DataPointList = GetCases.List
model.variables.dataPointListVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getCasesAggr.listOut, new PHICoreModel.Legacy_DataPointList(), function (source, target) {
target.labelAttr = source.labelAttr;
target.valueAttr = OS.BuiltinFunctions.longIntegerToDecimal(((!(vars.value.tempTotalVar.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) ? (source.countAttr) : (OS.BuiltinFunctions.integerToLongInteger(0))));
target.seriesNameAttr = source.labelAttr;
target.tooltipAttr = ((source.labelAttr + " - ") + OS.BuiltinFunctions.longIntegerToText(((!(vars.value.tempTotalVar.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) ? (source.countAttr) : (OS.BuiltinFunctions.integerToLongInteger(0)))));
target.colorAttr = source.graphColorAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t1TPdD1Tk0CyA6H+RROnGw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:diTy3MNuLkqKitx0WBX3Zw", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.CaseStatusGraphCard.OnAfterFetch_GetCases$vars", [{
name: "TempTotal",
attrName: "tempTotalVar",
mandatory: false,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Bgbv8R7e4kKpJvxOqiQvUg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.Bgbv8R7e4kKpJvxOqiQvUg:_xETusghKAqXLbq4lmxEZA", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:llgMgzbG00SNUzJFefODkA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YmpDSsvFzU+TYl6fdPAeww", callContext.id);
// SelectedMonthInt = IntegerToIdentifier
model.variables.selectedMonthIntVar = OS.BuiltinFunctions.integerToIdentifier(OS.BuiltinFunctions.month(OS.BuiltinFunctions.currDate()));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YmpDSsvFzU+TYl6fdPAeww", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// GraphFilter.TimePeriod = 7
model.variables.graphFilterVar.timePeriodAttr = "7";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nXEW_gXiZ0WNvqhn9lHVjw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Bgbv8R7e4kKpJvxOqiQvUg", callContext.id);
}

};
Controller.prototype._onEvent_GraphFilter$Action = function (graphFilterOutIn, closePopUpIn, isProceedIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnEvent_GraphFilter");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.CaseStatusGraphCard.OnEvent_GraphFilter$vars"))());
vars.value.graphFilterOutInLocal = graphFilterOutIn.clone();
vars.value.closePopUpInLocal = closePopUpIn;
vars.value.isProceedInLocal = isProceedIn;
var mSD_JoinIDsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.mSD_JoinIDsVar = mSD_JoinIDsVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:o0OJ+CCrikGP7Zy9ewxvhA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug/ClientActions.o0OJ+CCrikGP7Zy9ewxvhA:o3rMZwKBXRCZMnzyLfEbxg", "PHICore", "OnEvent_GraphFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Tj63oQh2rE2o6_CO2b8bOA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Spazv2Ckr0GcKZqJtoMG3Q", callContext.id) && vars.value.isProceedInLocal)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kKqnFJZVEUO4Hg9GS1ZYrw", callContext.id) && !(vars.value.closePopUpInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y+SUcvhp20ekdV53OQpsTQ", callContext.id);
// GraphFilter = GraphFilter_Original
model.variables.graphFilterVar = model.variables.graphFilter_OriginalVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y+SUcvhp20ekdV53OQpsTQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefreshFilter = notRefreshFilter
model.variables.refreshFilterVar = !(model.variables.refreshFilterVar);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:afdkO+wi7E2ZukpYdfGb3g", callContext.id);
// GraphFilter = GraphFilterOut
model.variables.graphFilterVar = vars.value.graphFilterOutInLocal;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:k_9aqkaBnEqPTTdIJe+2SQ", callContext.id);
// Execute Action: MSD_JoinIDs
mSD_JoinIDsVar.value = Common_CWController.default.mSD_JoinIDs$Action(model.variables.graphFilterVar.selectedTeamAttr, "|", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d6EXRPCuRUmiCmSwSs7aag", callContext.id);
// SelectedTeams = MSD_JoinIDs.JoinedStrings
model.variables.selectedTeamsVar = mSD_JoinIDsVar.value.joinedStringsOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YbMPgPSTAkaOAsx8+82GeQ", callContext.id);
// Refresh Query: GetCases
var result = controller.getCases$AggrRefresh(50, 0, callContext);
model.flush();
return result;
}

}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZAAecPFoyE22xNCTrJqabw", callContext.id) && vars.value.closePopUpInLocal)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XSXI0j_b_Eutmn4FvdgvqQ", callContext.id);
// Execute Action: OnToggle_GraphFilter
controller._onToggle_GraphFilter$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gCDc1bmh4kqAc7bHRRcqPg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gCDc1bmh4kqAc7bHRRcqPg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:o0OJ+CCrikGP7Zy9ewxvhA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:o0OJ+CCrikGP7Zy9ewxvhA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.CaseStatusGraphCard.OnEvent_GraphFilter$vars", [{
name: "GraphFilterOut",
attrName: "graphFilterOutInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.GraphFilterStrucRec();
},
complexType: PHICoreModel.GraphFilterStrucRec
}, {
name: "ClosePopUp",
attrName: "closePopUpInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsProceed",
attrName: "isProceedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);

Controller.prototype.onRender$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRender$Action, callContext);

};
Controller.prototype.onToggle_GraphFilter$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onToggle_GraphFilter$Action, callContext);

};
Controller.prototype.onAfterFetch_GetTeamUsersByUserId$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch_GetTeamUsersByUserId$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onAfterFetch_GetCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch_GetCases$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.onEvent_GraphFilter$Action = function (graphFilterOutIn, closePopUpIn, isProceedIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onEvent_GraphFilter$Action, callContext, graphFilterOutIn, closePopUpIn, isProceedIn);

};
Controller.prototype.onInitialized$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:z0UaJypxLEmLldrxPn7Zug:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.z0UaJypxLEmLldrxPn7Zug:PCVklZx5zLgIBxI_v3YrvQ", "PHICore", "CaseStatusGraphCard", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:z0UaJypxLEmLldrxPn7Zug", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/CaseStatusGraphCard On Render");
return controller.onRender$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.CaseStatusGraphCard.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"9WDsATxFgUOOq6ojgKmVEw": {
getter: function (varBag, idService) {
return varBag.mSD_JoinIDsVar.value;
}
},
"eXhcmrIGzUO0aN5NuoRknw": {
getter: function (varBag, idService) {
return varBag.vars.value.tempTotalVar;
},
dataType: OS.Types.LongInteger
},
"RStsPHoBuEWa4OgYQnSsaQ": {
getter: function (varBag, idService) {
return varBag.vars.value.graphFilterOutInLocal;
}
},
"ijLUmTV370y8ykc_KjAo9Q": {
getter: function (varBag, idService) {
return varBag.vars.value.closePopUpInLocal;
},
dataType: OS.Types.Boolean
},
"ud73hdFji06dFoJkR8t_pA": {
getter: function (varBag, idService) {
return varBag.vars.value.isProceedInLocal;
},
dataType: OS.Types.Boolean
},
"k_9aqkaBnEqPTTdIJe+2SQ": {
getter: function (varBag, idService) {
return varBag.mSD_JoinIDsVar.value;
}
},
"+ngWnJeECE6PKjDDtxJ4SA": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedMonthIntVar;
},
dataType: OS.Types.Integer
},
"Zb3KC97DMEOKc1XRtGudtg": {
getter: function (varBag, idService) {
return varBag.model.variables.dataPointListVar;
}
},
"ID4jKc4LeU6xKEIPM+Xt1A": {
getter: function (varBag, idService) {
return varBag.model.variables.showFilterVar;
},
dataType: OS.Types.Boolean
},
"NzKdPqE90ECDvDKR79kBMA": {
getter: function (varBag, idService) {
return varBag.model.variables.graphFilterVar;
}
},
"KMuJDojF2EaXjydpekoR2w": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedTeamsVar;
},
dataType: OS.Types.Text
},
"jZO0dnihxU2xOVltWrceqg": {
getter: function (varBag, idService) {
return varBag.model.variables.graphFilter_OriginalVar;
}
},
"a+hIskW8Pk2e_SNiZOMpjA": {
getter: function (varBag, idService) {
return varBag.model.variables.refreshFilterVar;
},
dataType: OS.Types.Boolean
},
"deJ_FnDt+kiWktWp8WUXAg": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamUsersByUserIdAggr;
}
},
"gFd31KGfFkGEMtLcHGi+uQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getCasesAggr;
}
},
"dhesk__8rUOFHl+AUxR4VQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Container_CaseGraph"));
})(varBag.model, idService);
}
},
"Qlvsz1gFwEKIWdZTqDHNnA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
