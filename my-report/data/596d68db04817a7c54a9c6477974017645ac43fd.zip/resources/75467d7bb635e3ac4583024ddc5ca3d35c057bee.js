﻿define("PHICore.Common_Widgets.BaseLayout.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.model$LongIntegerRecordList"], function (OutSystems, PHICoreModel) {
var OS = OutSystems.Internal;
var GetRequestAccessNotificationsByUserIdAggrRec = (function (_super) {
__extends(GetRequestAccessNotificationsByUserIdAggrRec, _super);
function GetRequestAccessNotificationsByUserIdAggrRec(defaults) {
_super.apply(this, arguments);
}
GetRequestAccessNotificationsByUserIdAggrRec.RecordListType = PHICoreModel.LongIntegerRecordList;
GetRequestAccessNotificationsByUserIdAggrRec.init();
return GetRequestAccessNotificationsByUserIdAggrRec;
})(OS.Model.AggregateRecord);

var GetNotificationsCountDataActRec = (function (_super) {
__extends(GetNotificationsCountDataActRec, _super);
function GetNotificationsCountDataActRec(defaults) {
_super.apply(this, arguments);
}
GetNotificationsCountDataActRec.attributesToDeclare = function () {
return [
this.attr("NoOfNotifications", "noOfNotificationsOut", "NoOfNotifications", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetNotificationsCountDataActRec.fromStructure = function (str) {
return new GetNotificationsCountDataActRec(new GetNotificationsCountDataActRec.RecordClass({
noOfNotificationsOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetNotificationsCountDataActRec.init();
return GetNotificationsCountDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MenuId", "menuIdIn", "MenuId", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_menuIdInDataFetchStatus", "_menuIdInDataFetchStatus", "_menuIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("OnRefreshMenu", "onRefreshMenuIn", "OnRefreshMenu", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_onRefreshMenuInDataFetchStatus", "_onRefreshMenuInDataFetchStatus", "_onRefreshMenuInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasChange", "hasChangeIn", "HasChange", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasBottomActions", "hasBottomActionsIn", "HasBottomActions", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasBottomActionsInDataFetchStatus", "_hasBottomActionsInDataFetchStatus", "_hasBottomActionsInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetRequestAccessNotificationsByUserId", "getRequestAccessNotificationsByUserIdAggr", "getRequestAccessNotificationsByUserIdAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetRequestAccessNotificationsByUserIdAggrRec());
}, true, GetRequestAccessNotificationsByUserIdAggrRec), 
this.attr("GetNotificationsCount", "getNotificationsCountDataAct", "getNotificationsCountDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetNotificationsCountDataActRec());
}, true, GetNotificationsCountDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("MenuId" in inputs) {
this.variables.menuIdIn = inputs.MenuId;
if("_menuIdInDataFetchStatus" in inputs) {
this.variables._menuIdInDataFetchStatus = inputs._menuIdInDataFetchStatus;
}

}

if("OnRefreshMenu" in inputs) {
this.variables.onRefreshMenuIn = inputs.OnRefreshMenu;
if("_onRefreshMenuInDataFetchStatus" in inputs) {
this.variables._onRefreshMenuInDataFetchStatus = inputs._onRefreshMenuInDataFetchStatus;
}

}

if("HasChange" in inputs) {
this.variables.hasChangeIn = inputs.HasChange;
if("_hasChangeInDataFetchStatus" in inputs) {
this.variables._hasChangeInDataFetchStatus = inputs._hasChangeInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

if("HasBottomActions" in inputs) {
this.variables.hasBottomActionsIn = inputs.HasBottomActions;
if("_hasBottomActionsInDataFetchStatus" in inputs) {
this.variables._hasBottomActionsInDataFetchStatus = inputs._hasBottomActionsInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.BaseLayout");
});
define("PHICore.Common_Widgets.BaseLayout.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.BaseLayout.mvc$model", "PHICore.Common_Widgets.BaseLayout.mvc$controller", "PHICore.clientVariables", "PHICore_TH.Layouts.HAMBS_BaseLayout.mvc$view", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.Branding.mvc$view", "Common_CW.Layout.Menu.mvc$view", "PHICore.model$LongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, React, OSView, PHICore_Common_Widgets_BaseLayout_mvc_model, PHICore_Common_Widgets_BaseLayout_mvc_controller, PHICoreClientVariables, PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_view, OSWidgets, Common_CW_PHICore_CW_Branding_mvc_view, Common_CW_Layout_Menu_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.BaseLayout";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_view, Common_CW_PHICore_CW_Branding_mvc_view, Common_CW_Layout_Menu_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_BaseLayout_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_BaseLayout_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(PHICore_TH_Layouts_HAMBS_BaseLayout_mvc_view, {
inputs: {
HasBottomActions: model.variables.hasBottomActionsIn,
_hasBottomActionsInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasBottomActionsInDataFetchStatus),
ExtendedClass: model.variables.extendedClassIn,
_extendedClassInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
branding: new PlaceholderContent(function () {
return [React.createElement(Common_CW_PHICore_CW_Branding_mvc_view, {
inputs: {
HasChange: model.variables.hasChangeIn,
_hasChangeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasChangeInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_DashboardClicked$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Branding Event_DashboardClicked");
return controller.menuEvent_MenuClicked$Action(PHICoreModel.staticEntities.menuItems.dashboard, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
header: new PlaceholderContent(function () {
return [React.createElement(Common_CW_Layout_Menu_mvc_view, {
inputs: {
StaffAccessNotifCounter: model.getCachedValue(idService.getId("QH0f8CWJ2Um_BtOL4fG_Hw.StaffAccessNotifCounter"), function () {
return OS.BuiltinFunctions.longIntegerToInteger(model.variables.getRequestAccessNotificationsByUserIdAggr.listOut.getCurrent(callContext.iterationContext).countAttr);
}, function () {
return model.variables.getRequestAccessNotificationsByUserIdAggr.listOut.getCurrent(callContext.iterationContext).countAttr;
}),
_staffAccessNotifCounterInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getRequestAccessNotificationsByUserIdAggr.dataFetchStatusAttr),
HasChange: model.variables.hasChangeIn,
_hasChangeInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hasChangeInDataFetchStatus),
ActiveMenu: model.variables.menuIdIn,
_activeMenuInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._menuIdInDataFetchStatus),
NotificationCounter: model.variables.getNotificationsCountDataAct.noOfNotificationsOut,
_notificationCounterInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getNotificationsCountDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_NotificationClicked$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu Event_NotificationClicked");
controller.menuEvent_NotificationClicked$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
event_RequestAccessClicked$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu Event_RequestAccessClicked");
controller.onClickRequestNotification$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
event_MenuClicked$Action: function (menuItemsIdIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Layout/Menu Event_MenuClicked");
return controller.menuEvent_MenuClicked$Action(menuItemsIdIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
underHeaderTitle: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.underHeaderTitle,
_idProps: {
service: idService,
name: "UnderHeaderTitle"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
underHeaderAction: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.underHeaderAction,
_idProps: {
service: idService,
name: "UnderHeaderAction"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
breadcrumbs: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.breadcrumbs,
_idProps: {
service: idService,
name: "Breadcrumbs"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
title: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.title,
_idProps: {
service: idService,
name: "Title"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
actions: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.actions,
_idProps: {
service: idService,
name: "Actions"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
mainContent: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
extendedProperties: {
autoComplete: "off"
},
gridProperties: {
classes: "OSFillParent"
},
style: "\"form card\"",
_idProps: {
service: idService,
name: "Form"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.mainContent,
_idProps: {
service: idService,
name: "MainContent"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
footer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.footer,
_idProps: {
service: idService,
name: "Footer"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
}
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.BaseLayout.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.BaseLayout.mvc$debugger", "PHICore.model$LongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_BaseLayout_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getRequestAccessNotificationsByUserId$AggrRefresh: 0,
getNotificationsCount$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getRequestAccessNotificationsByUserId$AggrRefresh: [],
getNotificationsCount$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getRequestAccessNotificationsByUserId$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:i4ibyAbutEOASBiMH0e3yw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/ScreenDataSets.i4ibyAbutEOASBiMH0e3yw:3eypiZ8E_Garh_QPEWuhnQ", "PHICore", "GetRequestAccessNotificationsByUserId", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/BaseLayout/GetRequestAccessNotificationsByUserId");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetRequestAccessNotificationsByUserId", "screenservices/PHICore/Common_Widgets/BaseLayout/ScreenDataSetGetRequestAccessNotificationsByUserId", "PwJRpuQV7zeXDmkfGBAyww", maxRecords, startIndex, function (b) {
model.variables.getRequestAccessNotificationsByUserIdAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getRequestAccessNotificationsByUserIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getRequestAccessNotificationsByUserIdAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:i4ibyAbutEOASBiMH0e3yw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getNotificationsCount$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:QbfwrGpbcEqS5KsFsFmR+g:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/DataActions.QbfwrGpbcEqS5KsFsFmR+g:N7YuW5qrlzWaaKAqr8c81A", "PHICore", "GetNotificationsCount", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/BaseLayout/GetNotificationsCount");
return controller.callDataAction("DataActionGetNotificationsCount", "screenservices/PHICore/Common_Widgets/BaseLayout/DataActionGetNotificationsCount", "jkPQf9y08lV_6u22q+R92w", function (b) {
model.variables.getNotificationsCountDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getNotificationsCountDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getNotificationsCountDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:QbfwrGpbcEqS5KsFsFmR+g", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getRequestAccessNotificationsByUserId$AggrRefresh", "getNotificationsCount$DataActRefresh"];
// Client Actions
Controller.prototype._menuEvent_NotificationClicked$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("MenuEvent_NotificationClicked");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:MtRklCVAz0+984S+KYEiLg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/ClientActions.MtRklCVAz0+984S+KYEiLg:wWtpIGJjQvPpaE0mhNwwUg", "PHICore", "MenuEvent_NotificationClicked", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:q+WfYFnbl0m2IBC0iZOtHQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GkkfZB8XFEOoVXwTgj2P6Q", callContext.id);
// Destination: /PHICore/Notification
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Notification", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:MtRklCVAz0+984S+KYEiLg", callContext.id);
}

};
Controller.prototype._menuEvent_MenuClicked$Action = function (menuItemsIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("MenuEvent_MenuClicked");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.BaseLayout.MenuEvent_MenuClicked$vars"))());
vars.value.menuItemsIdInLocal = menuItemsIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:K1qHmUDoq0u+eSvK2hjcVQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/ClientActions.K1qHmUDoq0u+eSvK2hjcVQ:1Ad1YUntW5wkLoLDBpGNCg", "PHICore", "MenuEvent_MenuClicked", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TczFDQlsyEaJSBwmNcT3OQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+1Sacv+FSkGkGH6MTKUzPw", callContext.id) && (model.variables.hasChangeIn === true))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iXpIQVD50EuZBFt5k+96hA", callContext.id);
// Trigger Event: Event_MenuClicked
return controller.event_MenuClicked$Action(vars.value.menuItemsIdInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n6tQG2ILSE6KLLo+sNF0mQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q8vFdosZZUa2POD9xUMCDg", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:K1qHmUDoq0u+eSvK2hjcVQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:K1qHmUDoq0u+eSvK2hjcVQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.BaseLayout.MenuEvent_MenuClicked$vars", [{
name: "MenuItemsId",
attrName: "menuItemsIdInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onClickRequestNotification$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickRequestNotification");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:SMsfvjx7OkKG9ZrRHnpZBA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/ClientActions.SMsfvjx7OkKG9ZrRHnpZBA:dOO_WRBq_9pG0nf6pfjKfQ", "PHICore", "OnClickRequestNotification", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YVMTVIOQfE6x+eTFe6vASA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+RGztbVXpkOt4n7HQaripQ", callContext.id);
// Destination: /PHICore/
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/FundAdministration/AccessRequests", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:SMsfvjx7OkKG9ZrRHnpZBA", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:LB116bS3g0i6wWoc_m7NHg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw/ClientActions.LB116bS3g0i6wWoc_m7NHg:1QIwhsPqdJa87H_xqd1bvw", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kqP+i6fAT0u+7nrIfDvfpA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wkBYvmULg02mMLlzzx+Okg", callContext.id);
// OnRefreshMenu = OnRefreshMenu
model.variables.onRefreshMenuIn = model.variables.onRefreshMenuIn;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OUOyGFL4Ok+RT+XIKe0o5w", callContext.id);
// Refresh Query: GetNotificationsCount
var result = controller.getNotificationsCount$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w+yUW4eY802Y9OvaPtcrFg", callContext.id);
// Refresh Query: GetRequestAccessNotificationsByUserId
var result = controller.getRequestAccessNotificationsByUserId$AggrRefresh(1, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iW1oMJw+YE6nOWXypXCWjQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:LB116bS3g0i6wWoc_m7NHg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:LB116bS3g0i6wWoc_m7NHg", callContext.id);
throw ex;

});
};

Controller.prototype.menuEvent_NotificationClicked$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._menuEvent_NotificationClicked$Action, callContext);

};
Controller.prototype.menuEvent_MenuClicked$Action = function (menuItemsIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._menuEvent_MenuClicked$Action, callContext, menuItemsIdIn);

};
Controller.prototype.onClickRequestNotification$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickRequestNotification$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.event_MenuClicked$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:iYdEXGz0fUyXX7bMxFu1sw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.iYdEXGz0fUyXX7bMxFu1sw:ikwiQ2xZtUrfe0GgQDyQRw", "PHICore", "BaseLayout", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:iYdEXGz0fUyXX7bMxFu1sw", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/BaseLayout On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.BaseLayout.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"qmxWFcGXgkG7X8KJJP1ZkQ": {
getter: function (varBag, idService) {
return varBag.vars.value.menuItemsIdInLocal;
},
dataType: OS.Types.Integer
},
"LeylvaU5dEWOmLRywBl94w": {
getter: function (varBag, idService) {
return varBag.model.variables.menuIdIn;
},
dataType: OS.Types.Integer
},
"E2ka2HgmPEi+fpfR2XPyzA": {
getter: function (varBag, idService) {
return varBag.model.variables.onRefreshMenuIn;
},
dataType: OS.Types.Boolean
},
"HS7Dj9ViZ0WG5Dd1iqdPuw": {
getter: function (varBag, idService) {
return varBag.model.variables.hasChangeIn;
},
dataType: OS.Types.Boolean
},
"iB4GxGFmFkuqx_lq8z3awQ": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"ktPpSN6420Gucxy8G42_mQ": {
getter: function (varBag, idService) {
return varBag.model.variables.hasBottomActionsIn;
},
dataType: OS.Types.Boolean
},
"QbfwrGpbcEqS5KsFsFmR+g": {
getter: function (varBag, idService) {
return varBag.model.variables.getNotificationsCountDataAct;
}
},
"i4ibyAbutEOASBiMH0e3yw": {
getter: function (varBag, idService) {
return varBag.model.variables.getRequestAccessNotificationsByUserIdAggr;
}
},
"3IE02vpXqkyrL01JCO_k_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Branding"));
})(varBag.model, idService);
}
},
"JNeqBYDo1EWNNpyPiGC+SQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Header"));
})(varBag.model, idService);
}
},
"lLaBaLsQvUWhzJtwGYXY6g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderTitle"));
})(varBag.model, idService);
}
},
"d2mZXcjZPUCQyBZp3Lo5Kw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderTitle"));
})(varBag.model, idService);
}
},
"YVrVuVgNeE6c0nqYhh8l9w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderAction"));
})(varBag.model, idService);
}
},
"f+XwUt4r0UypjuK37phDig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderAction"));
})(varBag.model, idService);
}
},
"XS3aYVk_0EqO0Vj1vzoiGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Breadcrumbs"));
})(varBag.model, idService);
}
},
"JIVVBsCITkWnORnzlDwZ4A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Breadcrumbs"));
})(varBag.model, idService);
}
},
"4snwoS476USfUu+hosQuQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"vH9CK9ZmVUm2pZw7Fw4sIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"lGt6CmcuYkK55r90VpuqzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"tSEcZBGElE2J4kexLe0y4w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"9razzlFv90Gmp6WPzBshfA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContent"));
})(varBag.model, idService);
}
},
"ddOs_q_7QEevx9hZP3m8bg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form"));
})(varBag.model, idService);
}
},
"1O0luyxGZUO4xS7TCpfV6Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContent"));
})(varBag.model, idService);
}
},
"QPB+H9B_GEe57VdbXhZgMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
},
"Wt4goA3eW0SHwUamq1MCYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
