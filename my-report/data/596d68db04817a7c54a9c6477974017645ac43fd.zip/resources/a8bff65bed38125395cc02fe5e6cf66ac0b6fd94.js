﻿define("Common_CW.referencesHealth$AccessControl_CS", [], function () {
// Reference to producer 'AccessControl_CS' is OK.
});
define("Common_CW.referencesHealth$APIGateway_IS", [], function () {
// Reference to producer 'APIGateway_IS' is OK.
});
define("Common_CW.referencesHealth$BinaryData", [], function () {
// Reference to producer 'BinaryData' is OK.
});
define("Common_CW.referencesHealth$Common_CS", [], function () {
// Reference to producer 'Common_CS' is OK.
});
define("Common_CW.referencesHealth$Config_CS", [], function () {
// Reference to producer 'Config_CS' is OK.
});
define("Common_CW.referencesHealth$MSD", [], function () {
// Reference to producer 'MSD' is OK.
});
define("Common_CW.referencesHealth$OutSystemsUI", [], function () {
// Reference to producer 'OutSystemsUI' is OK.
});
define("Common_CW.referencesHealth$PHICore_Notification", [], function () {
// Reference to producer 'PHICore_Notification' is OK.
});
define("Common_CW.referencesHealth$PHICore_TH", [], function () {
// Reference to producer 'PHICore_TH' is OK.
});
define("Common_CW.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("Common_CW.referencesHealth$Stakeholder_CS", [], function () {
// Reference to producer 'Stakeholder_CS' is OK.
});
define("Common_CW.referencesHealth$StateMachineCaseService", [], function () {
// Reference to producer 'StateMachineCaseService' is OK.
});
define("Common_CW.referencesHealth$TenantProvisioning_CS", [], function () {
// Reference to producer 'TenantProvisioning_CS' is OK.
});
define("Common_CW.referencesHealth$Text", [], function () {
// Reference to producer 'Text' is OK.
});
define("Common_CW.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("Common_CW.referencesHealth", [], function () {
});
