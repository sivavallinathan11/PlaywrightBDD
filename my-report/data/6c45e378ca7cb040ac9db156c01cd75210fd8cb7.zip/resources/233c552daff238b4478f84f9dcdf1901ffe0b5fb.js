define("Common_CW.PHICore_CW.TabExport.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model"], function (OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowDropdown", "showDropdownVar", "ShowDropdown", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("isEnabled", "isEnabledIn", "isEnabled", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isEnabledInDataFetchStatus", "_isEnabledInDataFetchStatus", "_isEnabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsRightAlign", "isRightAlignIn", "IsRightAlign", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isRightAlignInDataFetchStatus", "_isRightAlignInDataFetchStatus", "_isRightAlignInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsLoading", "isLoadingIn", "IsLoading", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isLoadingInDataFetchStatus", "_isLoadingInDataFetchStatus", "_isLoadingInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("isEnabled" in inputs) {
this.variables.isEnabledIn = inputs.isEnabled;
if("_isEnabledInDataFetchStatus" in inputs) {
this.variables._isEnabledInDataFetchStatus = inputs._isEnabledInDataFetchStatus;
}

}

if("IsRightAlign" in inputs) {
this.variables.isRightAlignIn = inputs.IsRightAlign;
if("_isRightAlignInDataFetchStatus" in inputs) {
this.variables._isRightAlignInDataFetchStatus = inputs._isRightAlignInDataFetchStatus;
}

}

if("IsLoading" in inputs) {
this.variables.isLoadingIn = inputs.IsLoading;
if("_isLoadingInDataFetchStatus" in inputs) {
this.variables._isLoadingInDataFetchStatus = inputs._isLoadingInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.TabExport");
});
define("Common_CW.PHICore_CW.TabExport.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.TabExport.mvc$model", "Common_CW.PHICore_CW.TabExport.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_TabExport_mvc_model, Common_CW_PHICore_CW_TabExport_mvc_controller, Common_CWClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.TabExport";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_TabExport_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_TabExport_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "DBWrapper-Container",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "tab-assign-btn CustomSpinner-loading",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-haspopup": "dialog",
"aria-label": "Export"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/TabExport/Link OnClick");
controller.onClick_ExportDropdown$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "display-flex assign-btn DBWrapper-export-dropdown loading-widget",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.isLoadingIn, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "CustomSpinner",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: model.getCachedValue(idService.getId("CJ+XSQBmP0KaCM7dh6pQeA.Style"), function () {
return ("padding-s text-primary " + ((model.variables.isEnabledIn) ? ("") : ("text-neutral-8")));
}, function () {
return model.variables.isEnabledIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isEnabledInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "margin-right-s",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "download",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Text, {
style: "bold",
text: ["Export"],
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})))), $if((model.variables.showDropdownVar && model.variables.isEnabledIn), true, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("DBDropdown.Style"), function () {
return ("DBWrapperDropdown ph DBWrapper-export" + ((model.variables.isRightAlignIn) ? (" justify-content-flex-end") : (" justify-content-flex-start")));
}, function () {
return model.variables.isRightAlignIn;
}),
visible: true,
_idProps: {
service: idService,
name: "DBDropdown"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isRightAlignInDataFetchStatus)
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/TabExport/Button OnClick");
return controller.onClick_Export$Action(false, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn text-neutral-9 DBWrapper-export",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Export Excel"), React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/TabExport/Button OnClick");
return controller.onClick_Export$Action(true, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn text-neutral-9",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Export CSV"))];
}, function () {
return [];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.TabExport.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.TabExport.mvc$debugger", "Common_CW.PHICore_CW.TabExport.mvc$controller.OnOpen_Export.CloseOnOutsideClickJS", "Common_CW.PHICore_CW.TabExport.mvc$controller.OnDestroy.RemoveListenerJS"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_TabExport_mvc_Debugger, Common_CW_PHICore_CW_TabExport_mvc_controller_OnOpen_Export_CloseOnOutsideClickJS, Common_CW_PHICore_CW_TabExport_mvc_controller_OnDestroy_RemoveListenerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
onClose_Export$Action: function () {
return controller.executeActionInsideJSNode(controller._onClose_Export$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnClose_Export");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClick_ExportDropdown$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_ExportDropdown");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:iQDSLDjN7kOiECDjIXX_Hw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw/ClientActions.iQDSLDjN7kOiECDjIXX_Hw:zKB4Og4GNw+bzxI9cLFQKg", "Common_CW", "OnClick_ExportDropdown", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XjSlp8EhtUmNIbMJ6X_KXw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vPUybz2dYEmu+zStdz+5cg", callContext.id) && model.variables.isLoadingIn)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wjL8tU91jEaI9hd15gul9g", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sR4yZdxbpkOK4PCS6wCBpQ", callContext.id) && model.variables.showDropdownVar)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XFiSoAhWxkq1a+TlY50zsw", callContext.id);
// Execute Action: OnClose_Export
controller._onClose_Export$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:6vpaa1NzbEKoSmHjXORG7A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fS_SdCxnzU63moe7_A8vxQ", callContext.id);
// Execute Action: OnOpen_Export
controller._onOpen_Export$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:6vpaa1NzbEKoSmHjXORG7A", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:iQDSLDjN7kOiECDjIXX_Hw", callContext.id);
}

};
Controller.prototype._onOpen_Export$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnOpen_Export");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:lllsWGtAWkG7xUWaNQcc5w:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw/ClientActions.lllsWGtAWkG7xUWaNQcc5w:7wMTab_LwMTEPkEQq8wqGQ", "Common_CW", "OnOpen_Export", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3juG4TdSXUefh3w+XY7f3w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:RzGnrY_inEmBwCTl7ENoFQ", callContext.id);
// ShowDropdown = notShowDropdown
model.variables.showDropdownVar = !(model.variables.showDropdownVar);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3FwzoYkJOUe8KPSme0D4pA", callContext.id);
// Adds an event to close the drop when clicked outside
controller.safeExecuteJSNode(Common_CW_PHICore_CW_TabExport_mvc_controller_OnOpen_Export_CloseOnOutsideClickJS, "CloseOnOutsideClick", "OnOpen_Export", null, function ($parameters) {
}, {
OnClose_Export: controller.clientActionProxies.onClose_Export$Action
}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rrx4T5T5JUWTzRzD3n3B1g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:lllsWGtAWkG7xUWaNQcc5w", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:e+Rlcg4AAEy8e+2NYmsrlg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw/ClientActions.e+Rlcg4AAEy8e+2NYmsrlg:34Qjyjq8qlvWJlYJgnYRIw", "Common_CW", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xMLD6fxvHEe+MKhI5nja9w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gieL1+WTn0CM7xCOZ5yd7w", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_TabExport_mvc_controller_OnDestroy_RemoveListenerJS, "RemoveListener", "OnDestroy", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:mXx6SxY64E+CW6O9xKnyAg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:e+Rlcg4AAEy8e+2NYmsrlg", callContext.id);
}

};
Controller.prototype._onClick_Export$Action = function (isCSVIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Export");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.TabExport.OnClick_Export$vars"))());
vars.value.isCSVInLocal = isCSVIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:yu15raZ1W0yz1ZfWxrW7uw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw/ClientActions.yu15raZ1W0yz1ZfWxrW7uw:zI+37DCGfMmds+Pw1AnS2A", "Common_CW", "OnClick_Export", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:uvqrDhDsdUaOOqd7hr_OcQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PvHZHXg+DE+_rRCe6ne3+Q", callContext.id);
// Execute Action: OnClose_Export
controller._onClose_Export$Action(callContext);
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:U0kUsgp9dkK280En5tpS+A", callContext.id) && vars.value.isCSVInLocal)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:d_W+sJDMQEOvGz7fdm_99g", callContext.id);
// Trigger Event: ExportCSV
return controller.exportCSV$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nj8JtQr6pkWaaLEsQ+NKPQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+dd42EEbFEicWrhtfxrzgQ", callContext.id);
// Trigger Event: ExportExcel
return controller.exportExcel$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nj8JtQr6pkWaaLEsQ+NKPQ", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:yu15raZ1W0yz1ZfWxrW7uw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:yu15raZ1W0yz1ZfWxrW7uw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.TabExport.OnClick_Export$vars", [{
name: "IsCSV",
attrName: "isCSVInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onClose_Export$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClose_Export");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:GH+F0V5da06xWPU+M68NdQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw/ClientActions.GH+F0V5da06xWPU+M68NdQ:mK2s6Jbxz74awPncmB8Zeg", "Common_CW", "OnClose_Export", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qfYInmatAUeJXzxHOb+g9A", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:e9Duiao3k0CEDxVTetmW9w", callContext.id);
// ShowDropdown = False
model.variables.showDropdownVar = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tYb+fPkuvUihz6wkyMdQGg", callContext.id);
// Execute Action: OnDestroy
controller._onDestroy$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hXZoK2DYd0qxT4_JxN7cnQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:GH+F0V5da06xWPU+M68NdQ", callContext.id);
}

};

Controller.prototype.onClick_ExportDropdown$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_ExportDropdown$Action, callContext);

};
Controller.prototype.onOpen_Export$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onOpen_Export$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onClick_Export$Action = function (isCSVIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Export$Action, callContext, isCSVIn);

};
Controller.prototype.onClose_Export$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClose_Export$Action, callContext);

};
Controller.prototype.exportCSV$Action = function () {
return Promise.resolve();
};
Controller.prototype.exportExcel$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:757yN5S23U27LS5v6Qq2Tw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.757yN5S23U27LS5v6Qq2Tw:QVDFre+_mEXuwaFRfFgRkw", "Common_CW", "TabExport", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:757yN5S23U27LS5v6Qq2Tw", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/TabExport On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});
define("Common_CW.PHICore_CW.TabExport.mvc$controller.OnOpen_Export.CloseOnOutsideClickJS", [], function () {
return function ($actions, $roles, $public) {
 // Close the dropdown if the user clicks outside of it
var controller = new AbortController();
var _signal = controller.signal;

 document.addEventListener("click", function(event){
     if(event.target.matches('.popup-backdrop')){
        $actions.OnClose_Export();
        console.log("1");
        controller.abort();
    }
    if (!event.target.matches('.DBWrapper-Container')){
        $actions.OnClose_Export();
        console.log("2");
        controller.abort();
    }
 }, { signal: _signal });
};
});
define("Common_CW.PHICore_CW.TabExport.mvc$controller.OnDestroy.RemoveListenerJS", [], function () {
return function ($actions, $roles, $public) {
function _listener() {}

document.removeEventListener('click', _listener)
};
});

define("Common_CW.PHICore_CW.TabExport.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"3FwzoYkJOUe8KPSme0D4pA": {
getter: function (varBag, idService) {
return varBag.closeOnOutsideClickJSResult.value;
}
},
"gieL1+WTn0CM7xCOZ5yd7w": {
getter: function (varBag, idService) {
return varBag.removeListenerJSResult.value;
}
},
"XsIOtHp2fUivpVAQE3G_Ag": {
getter: function (varBag, idService) {
return varBag.vars.value.isCSVInLocal;
},
dataType: OS.Types.Boolean
},
"XOZjIFwMe0C6GrF+j2vHzQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showDropdownVar;
},
dataType: OS.Types.Boolean
},
"x+7vqQPu_kSYIec+8QLLEw": {
getter: function (varBag, idService) {
return varBag.model.variables.isEnabledIn;
},
dataType: OS.Types.Boolean
},
"a8DJGKtZo06JQRPfKDNAaA": {
getter: function (varBag, idService) {
return varBag.model.variables.isRightAlignIn;
},
dataType: OS.Types.Boolean
},
"IwY3l9ptVEyvNux1uj6s_A": {
getter: function (varBag, idService) {
return varBag.model.variables.isLoadingIn;
},
dataType: OS.Types.Boolean
},
"3rDbFy+WmUCvBt5VPNKqhg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DBDropdown"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
