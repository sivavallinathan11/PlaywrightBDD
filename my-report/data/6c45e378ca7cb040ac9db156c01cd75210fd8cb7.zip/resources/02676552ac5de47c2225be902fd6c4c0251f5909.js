define("SandBoxLogin.model$TenantEspaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$TenantRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter", "ServiceCenter.model$EspaceRec"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var TenantEspaceRecord = (function (_super) {
__extends(TenantEspaceRecord, _super);
function TenantEspaceRecord(defaults) {
_super.apply(this, arguments);
}
TenantEspaceRecord.attributesToDeclare = function () {
return [
this.attr("Tenant", "tenantAttr", "Tenant", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.TenantRec());
}, true, ServiceCenterModel.TenantRec), 
this.attr("Espace", "espaceAttr", "Espace", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, true, ServiceCenterModel.EspaceRec)
].concat(_super.attributesToDeclare.call(this));
};
TenantEspaceRecord._isAnonymousRecord = true;
TenantEspaceRecord.UniqueId = "07cf5498-ccfb-bc51-29d8-031090bac430";
TenantEspaceRecord.init();
return TenantEspaceRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.TenantEspaceRecord = TenantEspaceRecord;

});
define("SandBoxLogin.model$User_RoleList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$User_RoleRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var User_RoleList = (function (_super) {
__extends(User_RoleList, _super);
function User_RoleList(defaults) {
_super.apply(this, arguments);
}
User_RoleList.itemType = ServiceCenterModel.User_RoleRec;
return User_RoleList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.User_RoleList = User_RoleList;

});
define("SandBoxLogin.model$TenantRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$TenantRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var TenantRecord = (function (_super) {
__extends(TenantRecord, _super);
function TenantRecord(defaults) {
_super.apply(this, arguments);
}
TenantRecord.attributesToDeclare = function () {
return [
this.attr("Tenant", "tenantAttr", "Tenant", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.TenantRec());
}, true, ServiceCenterModel.TenantRec)
].concat(_super.attributesToDeclare.call(this));
};
TenantRecord.fromStructure = function (str) {
return new TenantRecord(new TenantRecord.RecordClass({
tenantAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TenantRecord._isAnonymousRecord = true;
TenantRecord.UniqueId = "40d0f5c5-ba63-0b10-5850-cead15ae2223";
TenantRecord.init();
return TenantRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.TenantRecord = TenantRecord;

});
define("SandBoxLogin.model$TenantRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$TenantRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var TenantRecordList = (function (_super) {
__extends(TenantRecordList, _super);
function TenantRecordList(defaults) {
_super.apply(this, arguments);
}
TenantRecordList.itemType = SandBoxLoginModel.TenantRecord;
return TenantRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.TenantRecordList = TenantRecordList;

});
define("SandBoxLogin.model$TenantEspaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$TenantEspaceRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var TenantEspaceRecordList = (function (_super) {
__extends(TenantEspaceRecordList, _super);
function TenantEspaceRecordList(defaults) {
_super.apply(this, arguments);
}
TenantEspaceRecordList.itemType = SandBoxLoginModel.TenantEspaceRecord;
return TenantEspaceRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.TenantEspaceRecordList = TenantEspaceRecordList;

});
define("SandBoxLogin.model$DateRec", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var DateRec = (function (_super) {
__extends(DateRec, _super);
function DateRec(defaults) {
_super.apply(this, arguments);
}
DateRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DateTime1", "dateTime1Attr", "DateTime1", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DateTime2", "dateTime2Attr", "DateTime2", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("From", "fromAttr", "From", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DateRec.init();
return DateRec;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.DateRec = DateRec;

});
define("SandBoxLogin.model$DateList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$DateRec"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var DateList = (function (_super) {
__extends(DateList, _super);
function DateList(defaults) {
_super.apply(this, arguments);
}
DateList.itemType = SandBoxLoginModel.DateRec;
return DateList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.DateList = DateList;

});
define("SandBoxLogin.model$BreakColumnsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "SandBoxLogin.model", "OutSystemsUI.model$BreakColumnsRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecord = (function (_super) {
__extends(BreakColumnsRecord, _super);
function BreakColumnsRecord(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecord.attributesToDeclare = function () {
return [
this.attr("BreakColumns", "breakColumnsAttr", "BreakColumns", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.BreakColumnsRec());
}, true, OutSystemsUIModel.BreakColumnsRec)
].concat(_super.attributesToDeclare.call(this));
};
BreakColumnsRecord.fromStructure = function (str) {
return new BreakColumnsRecord(new BreakColumnsRecord.RecordClass({
breakColumnsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BreakColumnsRecord._isAnonymousRecord = true;
BreakColumnsRecord.UniqueId = "261685da-2c79-9bcc-3b48-73485e008694";
BreakColumnsRecord.init();
return BreakColumnsRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.BreakColumnsRecord = BreakColumnsRecord;

});
define("SandBoxLogin.model$EntityActionMessageList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "SandBoxLogin.model", "Common_CS.model$EntityActionMessageRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionMessageList = (function (_super) {
__extends(EntityActionMessageList, _super);
function EntityActionMessageList(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageList.itemType = Common_CSModel.EntityActionMessageRec;
return EntityActionMessageList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EntityActionMessageList = EntityActionMessageList;

});
define("SandBoxLogin.model$EntityActionMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "SandBoxLogin.model", "Common_CS.model$EntityActionMessageRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionMessageRecord = (function (_super) {
__extends(EntityActionMessageRecord, _super);
function EntityActionMessageRecord(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageRecord.attributesToDeclare = function () {
return [
this.attr("EntityActionMessage", "entityActionMessageAttr", "EntityActionMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CSModel.EntityActionMessageRec());
}, true, Common_CSModel.EntityActionMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionMessageRecord.fromStructure = function (str) {
return new EntityActionMessageRecord(new EntityActionMessageRecord.RecordClass({
entityActionMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EntityActionMessageRecord._isAnonymousRecord = true;
EntityActionMessageRecord.UniqueId = "7c3ebb2f-1f8a-e07a-62f7-36f460c8e4b8";
EntityActionMessageRecord.init();
return EntityActionMessageRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.EntityActionMessageRecord = EntityActionMessageRecord;

});
define("SandBoxLogin.model$EntityActionMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$EntityActionMessageRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionMessageRecordList = (function (_super) {
__extends(EntityActionMessageRecordList, _super);
function EntityActionMessageRecordList(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageRecordList.itemType = SandBoxLoginModel.EntityActionMessageRecord;
return EntityActionMessageRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EntityActionMessageRecordList = EntityActionMessageRecordList;

});
define("SandBoxLogin.model$BreakColumnsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$BreakColumnsRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecordList = (function (_super) {
__extends(BreakColumnsRecordList, _super);
function BreakColumnsRecordList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecordList.itemType = SandBoxLoginModel.BreakColumnsRecord;
return BreakColumnsRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.BreakColumnsRecordList = BreakColumnsRecordList;

});
define("SandBoxLogin.model$EspaceList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$EspaceRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EspaceList = (function (_super) {
__extends(EspaceList, _super);
function EspaceList(defaults) {
_super.apply(this, arguments);
}
EspaceList.itemType = ServiceCenterModel.EspaceRec;
return EspaceList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EspaceList = EspaceList;

});
define("SandBoxLogin.model$BreakColumnsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "SandBoxLogin.model", "OutSystemsUI.model$BreakColumnsRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var BreakColumnsList = (function (_super) {
__extends(BreakColumnsList, _super);
function BreakColumnsList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsList.itemType = OutSystemsUIModel.BreakColumnsRec;
return BreakColumnsList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.BreakColumnsList = BreakColumnsList;

});
define("SandBoxLogin.model$EntityActionResultRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "SandBoxLogin.model", "Common_CS.model$EntityActionResultRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionResultRecord = (function (_super) {
__extends(EntityActionResultRecord, _super);
function EntityActionResultRecord(defaults) {
_super.apply(this, arguments);
}
EntityActionResultRecord.attributesToDeclare = function () {
return [
this.attr("EntityActionResult", "entityActionResultAttr", "EntityActionResult", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CSModel.EntityActionResultRec());
}, true, Common_CSModel.EntityActionResultRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionResultRecord.fromStructure = function (str) {
return new EntityActionResultRecord(new EntityActionResultRecord.RecordClass({
entityActionResultAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EntityActionResultRecord._isAnonymousRecord = true;
EntityActionResultRecord.UniqueId = "71775667-ce43-fc5f-99a9-c6e1ecc450a4";
EntityActionResultRecord.init();
return EntityActionResultRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.EntityActionResultRecord = EntityActionResultRecord;

});
define("SandBoxLogin.model$EspaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$EspaceRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EspaceRecord = (function (_super) {
__extends(EspaceRecord, _super);
function EspaceRecord(defaults) {
_super.apply(this, arguments);
}
EspaceRecord.attributesToDeclare = function () {
return [
this.attr("Espace", "espaceAttr", "Espace", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, true, ServiceCenterModel.EspaceRec)
].concat(_super.attributesToDeclare.call(this));
};
EspaceRecord.fromStructure = function (str) {
return new EspaceRecord(new EspaceRecord.RecordClass({
espaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EspaceRecord._isAnonymousRecord = true;
EspaceRecord.UniqueId = "a702e171-772a-9b89-c17e-2544ab6d1d29";
EspaceRecord.init();
return EspaceRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.EspaceRecord = EspaceRecord;

});
define("SandBoxLogin.model$EspaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$EspaceRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EspaceRecordList = (function (_super) {
__extends(EspaceRecordList, _super);
function EspaceRecordList(defaults) {
_super.apply(this, arguments);
}
EspaceRecordList.itemType = SandBoxLoginModel.EspaceRecord;
return EspaceRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EspaceRecordList = EspaceRecordList;

});
define("SandBoxLogin.model$User_RoleRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$User_RoleRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var User_RoleRecord = (function (_super) {
__extends(User_RoleRecord, _super);
function User_RoleRecord(defaults) {
_super.apply(this, arguments);
}
User_RoleRecord.attributesToDeclare = function () {
return [
this.attr("User_Role", "user_RoleAttr", "User_Role", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.User_RoleRec());
}, true, ServiceCenterModel.User_RoleRec)
].concat(_super.attributesToDeclare.call(this));
};
User_RoleRecord.fromStructure = function (str) {
return new User_RoleRecord(new User_RoleRecord.RecordClass({
user_RoleAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
User_RoleRecord._isAnonymousRecord = true;
User_RoleRecord.UniqueId = "d97f6462-a678-c8b1-1d19-b3f1e75ed4cb";
User_RoleRecord.init();
return User_RoleRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.User_RoleRecord = User_RoleRecord;

});
define("SandBoxLogin.model$User_RoleRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$User_RoleRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var User_RoleRecordList = (function (_super) {
__extends(User_RoleRecordList, _super);
function User_RoleRecordList(defaults) {
_super.apply(this, arguments);
}
User_RoleRecordList.itemType = SandBoxLoginModel.User_RoleRecord;
return User_RoleRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.User_RoleRecordList = User_RoleRecordList;

});
define("SandBoxLogin.model$DateRecord", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$DateRec"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var DateRecord = (function (_super) {
__extends(DateRecord, _super);
function DateRecord(defaults) {
_super.apply(this, arguments);
}
DateRecord.attributesToDeclare = function () {
return [
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new SandBoxLoginModel.DateRec());
}, true, SandBoxLoginModel.DateRec)
].concat(_super.attributesToDeclare.call(this));
};
DateRecord.fromStructure = function (str) {
return new DateRecord(new DateRecord.RecordClass({
dateAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DateRecord._isAnonymousRecord = true;
DateRecord.UniqueId = "b0f82db1-7aff-8917-e74d-c17dc0419fd9";
DateRecord.init();
return DateRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.DateRecord = DateRecord;

});
define("SandBoxLogin.model$DateRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$DateRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var DateRecordList = (function (_super) {
__extends(DateRecordList, _super);
function DateRecordList(defaults) {
_super.apply(this, arguments);
}
DateRecordList.itemType = SandBoxLoginModel.DateRecord;
return DateRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.DateRecordList = DateRecordList;

});
define("SandBoxLogin.model$UserRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$UserRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var UserRecord = (function (_super) {
__extends(UserRecord, _super);
function UserRecord(defaults) {
_super.apply(this, arguments);
}
UserRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec)
].concat(_super.attributesToDeclare.call(this));
};
UserRecord.fromStructure = function (str) {
return new UserRecord(new UserRecord.RecordClass({
userAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UserRecord._isAnonymousRecord = true;
UserRecord.UniqueId = "ced01335-8a82-a813-f1d9-a5108f17ce79";
UserRecord.init();
return UserRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.UserRecord = UserRecord;

});
define("SandBoxLogin.model$UserRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$UserRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var UserRecordList = (function (_super) {
__extends(UserRecordList, _super);
function UserRecordList(defaults) {
_super.apply(this, arguments);
}
UserRecordList.itemType = SandBoxLoginModel.UserRecord;
return UserRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.UserRecordList = UserRecordList;

});
define("SandBoxLogin.model$GutterSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "SandBoxLogin.model", "OutSystemsUI.model$GutterSizeRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var GutterSizeRecord = (function (_super) {
__extends(GutterSizeRecord, _super);
function GutterSizeRecord(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecord.attributesToDeclare = function () {
return [
this.attr("GutterSize", "gutterSizeAttr", "GutterSize", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.GutterSizeRec());
}, true, OutSystemsUIModel.GutterSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
GutterSizeRecord.fromStructure = function (str) {
return new GutterSizeRecord(new GutterSizeRecord.RecordClass({
gutterSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GutterSizeRecord._isAnonymousRecord = true;
GutterSizeRecord.UniqueId = "a5018402-fa6c-90c5-e826-e54b2748cedc";
GutterSizeRecord.init();
return GutterSizeRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.GutterSizeRecord = GutterSizeRecord;

});
define("SandBoxLogin.model$User_RoleUserRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$User_RoleRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter", "ServiceCenter.model$UserRec"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var User_RoleUserRecord = (function (_super) {
__extends(User_RoleUserRecord, _super);
function User_RoleUserRecord(defaults) {
_super.apply(this, arguments);
}
User_RoleUserRecord.attributesToDeclare = function () {
return [
this.attr("User_Role", "user_RoleAttr", "User_Role", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.User_RoleRec());
}, true, ServiceCenterModel.User_RoleRec), 
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec)
].concat(_super.attributesToDeclare.call(this));
};
User_RoleUserRecord._isAnonymousRecord = true;
User_RoleUserRecord.UniqueId = "b4574be1-dc83-2959-1ccf-c53ed127b400";
User_RoleUserRecord.init();
return User_RoleUserRecord;
})(OS.DataTypes.GenericRecord);
SandBoxLoginModel.User_RoleUserRecord = User_RoleUserRecord;

});
define("SandBoxLogin.model$EntityActionResultList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "SandBoxLogin.model", "Common_CS.model$EntityActionResultRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionResultList = (function (_super) {
__extends(EntityActionResultList, _super);
function EntityActionResultList(defaults) {
_super.apply(this, arguments);
}
EntityActionResultList.itemType = Common_CSModel.EntityActionResultRec;
return EntityActionResultList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EntityActionResultList = EntityActionResultList;

});
define("SandBoxLogin.model$EntityActionResultRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$EntityActionResultRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var EntityActionResultRecordList = (function (_super) {
__extends(EntityActionResultRecordList, _super);
function EntityActionResultRecordList(defaults) {
_super.apply(this, arguments);
}
EntityActionResultRecordList.itemType = SandBoxLoginModel.EntityActionResultRecord;
return EntityActionResultRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.EntityActionResultRecordList = EntityActionResultRecordList;

});
define("SandBoxLogin.model$GutterSizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "SandBoxLogin.model", "OutSystemsUI.model$GutterSizeRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var GutterSizeList = (function (_super) {
__extends(GutterSizeList, _super);
function GutterSizeList(defaults) {
_super.apply(this, arguments);
}
GutterSizeList.itemType = OutSystemsUIModel.GutterSizeRec;
return GutterSizeList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.GutterSizeList = GutterSizeList;

});
define("SandBoxLogin.model$TenantList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$TenantRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var TenantList = (function (_super) {
__extends(TenantList, _super);
function TenantList(defaults) {
_super.apply(this, arguments);
}
TenantList.itemType = ServiceCenterModel.TenantRec;
return TenantList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.TenantList = TenantList;

});
define("SandBoxLogin.model$User_RoleUserRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$User_RoleUserRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var User_RoleUserRecordList = (function (_super) {
__extends(User_RoleUserRecordList, _super);
function User_RoleUserRecordList(defaults) {
_super.apply(this, arguments);
}
User_RoleUserRecordList.itemType = SandBoxLoginModel.User_RoleUserRecord;
return User_RoleUserRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.User_RoleUserRecordList = User_RoleUserRecordList;

});
define("SandBoxLogin.model$GutterSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.model$GutterSizeRecord"], function (exports, OutSystems, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var GutterSizeRecordList = (function (_super) {
__extends(GutterSizeRecordList, _super);
function GutterSizeRecordList(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecordList.itemType = SandBoxLoginModel.GutterSizeRecord;
return GutterSizeRecordList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.GutterSizeRecordList = GutterSizeRecordList;

});
define("SandBoxLogin.model$UserList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "SandBoxLogin.model", "ServiceCenter.model$UserRec", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, SandBoxLoginModel) {
var OS = OutSystems.Internal;
var UserList = (function (_super) {
__extends(UserList, _super);
function UserList(defaults) {
_super.apply(this, arguments);
}
UserList.itemType = ServiceCenterModel.UserRec;
return UserList;
})(OS.DataTypes.GenericRecordList);
SandBoxLoginModel.UserList = UserList;

});
define("SandBoxLogin.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var SandBoxLoginModel = exports;
Object.defineProperty(SandBoxLoginModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["be608e72-db92-43fb-9c12-44767fa877dd"];
}
});

SandBoxLoginModel.staticEntities = {};
SandBoxLoginModel.staticEntities.gutterSize = {};
var getGutterSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["2e81a1e8-4fa4-4bd0-a945-65352999b0be"][record];
};
Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "xXLarge", {
get: function () {
return getGutterSizeRecord("087ea4c4-96ff-4fc5-87c9-70e35c61fe6e");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "medium", {
get: function () {
return getGutterSizeRecord("12874371-fb77-4707-afda-cdddbba81173");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "none", {
get: function () {
return getGutterSizeRecord("1a6cb2a2-b448-4f08-ba92-5bd24d30a422");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "extraLarge", {
get: function () {
return getGutterSizeRecord("8d669ecd-b220-4b80-b57b-4700987734dd");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "small", {
get: function () {
return getGutterSizeRecord("96f816b9-2511-49f9-8e9c-c6ab4ff8683e");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "large", {
get: function () {
return getGutterSizeRecord("a9dce78b-0487-49ef-b5c0-d3054293816b");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "base", {
get: function () {
return getGutterSizeRecord("b7549354-102c-45e6-8c2e-b171c6f589c5");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.gutterSize, "extraSmall", {
get: function () {
return getGutterSizeRecord("b8734df5-7557-4609-a566-cf5c35a6dade");
}
});

SandBoxLoginModel.staticEntities.breakColumns = {};
var getBreakColumnsRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["68f74593-a5c4-4e65-858b-f44211eaf122"][record];
};
Object.defineProperty(SandBoxLoginModel.staticEntities.breakColumns, "none", {
get: function () {
return getBreakColumnsRecord("0712904e-03be-4b5f-9b9e-ecc640f84913");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.breakColumns, "first", {
get: function () {
return getBreakColumnsRecord("3d55ca44-9c70-4bd4-bf96-7d0a7ec1c3b6");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.breakColumns, "all", {
get: function () {
return getBreakColumnsRecord("63e0af38-8b6c-4970-b96a-acd8c6d863e4");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.breakColumns, "middle", {
get: function () {
return getBreakColumnsRecord("694d423c-ce17-45a1-9993-cb57c30ec674");
}
});

Object.defineProperty(SandBoxLoginModel.staticEntities.breakColumns, "last", {
get: function () {
return getBreakColumnsRecord("6c98320a-c178-4925-b42b-7165ed805ea0");
}
});

});
