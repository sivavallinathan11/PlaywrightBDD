define("StateMachineCaseService.model$CaseSummaryRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseSummaryRec = (function (_super) {
__extends(CaseSummaryRec, _super);
function CaseSummaryRec(defaults) {
_super.apply(this, arguments);
}
CaseSummaryRec.attributesToDeclare = function () {
return [
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ParentCase", "parentCaseAttr", "ParentCase", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CaseNumber", "caseNumberAttr", "CaseNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssignedTeam", "assignedTeamAttr", "AssignedTeam", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssignedUser", "assignedUserAttr", "AssignedUser", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReferenceLabel", "referenceLabelAttr", "ReferenceLabel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReferenceId", "referenceIdAttr", "ReferenceId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StatusLabel", "statusLabelAttr", "StatusLabel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StatusId", "statusIdAttr", "StatusId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CaseId", "caseIdAttr", "CaseId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseSummaryRec.init();
return CaseSummaryRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseSummaryRec = CaseSummaryRec;

});
define("StateMachineCaseService.model$CancellationReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CancellationReasonRec = (function (_super) {
__extends(CancellationReasonRec, _super);
function CancellationReasonRec(defaults) {
_super.apply(this, arguments);
}
CancellationReasonRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CancellationReasonRec.init();
return CancellationReasonRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CancellationReasonRec = CancellationReasonRec;

});
define("StateMachineCaseService.model$CaseStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseStatusRec = (function (_super) {
__extends(CaseStatusRec, _super);
function CaseStatusRec(defaults) {
_super.apply(this, arguments);
}
CaseStatusRec.attributesToDeclare = function () {
return [
this.attr("StatusId", "statusIdAttr", "StatusId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseStatusRec.init();
return CaseStatusRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseStatusRec = CaseStatusRec;

});
define("StateMachineCaseService.model$SLAReferenceDataRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var SLAReferenceDataRec = (function (_super) {
__extends(SLAReferenceDataRec, _super);
function SLAReferenceDataRec(defaults) {
_super.apply(this, arguments);
}
SLAReferenceDataRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PriorityId", "priorityIdAttr", "PriorityId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("HrsUntilDue", "hrsUntilDueAttr", "HrsUntilDue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("HrsUntilNeedsAttention", "hrsUntilNeedsAttentionAttr", "HrsUntilNeedsAttention", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LasUpdatedOn", "lasUpdatedOnAttr", "LasUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SLAReferenceDataRec.init();
return SLAReferenceDataRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.SLAReferenceDataRec = SLAReferenceDataRec;

});
define("StateMachineCaseService.model$CaseRejectReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseRejectReasonRec = (function (_super) {
__extends(CaseRejectReasonRec, _super);
function CaseRejectReasonRec(defaults) {
_super.apply(this, arguments);
}
CaseRejectReasonRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseRejectReasonRec.init();
return CaseRejectReasonRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseRejectReasonRec = CaseRejectReasonRec;

});
define("StateMachineCaseService.model$PriorityRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var PriorityRec = (function (_super) {
__extends(PriorityRec, _super);
function PriorityRec(defaults) {
_super.apply(this, arguments);
}
PriorityRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Priority", "priorityAttr", "Priority", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PriorityRec.init();
return PriorityRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.PriorityRec = PriorityRec;

});
define("StateMachineCaseService.model$TeamUserRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var TeamUserRec = (function (_super) {
__extends(TeamUserRec, _super);
function TeamUserRec(defaults) {
_super.apply(this, arguments);
}
TeamUserRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TeamId", "teamIdAttr", "TeamId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UserId", "userIdAttr", "UserId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("HasApprovalPermissions", "hasApprovalPermissionsAttr", "HasApprovalPermissions", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TeamUserRec.init();
return TeamUserRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.TeamUserRec = TeamUserRec;

});
define("StateMachineCaseService.model$CaseSLARec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseSLARec = (function (_super) {
__extends(CaseSLARec, _super);
function CaseSLARec(defaults) {
_super.apply(this, arguments);
}
CaseSLARec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CaseId", "caseIdAttr", "CaseId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AssignedOn", "assignedOnAttr", "AssignedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DueOn", "dueOnAttr", "DueOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("NeedsAttentionOn", "needsAttentionOnAttr", "NeedsAttentionOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DaysOpen", "daysOpenAttr", "DaysOpen", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastSycDateTime", "lastSycDateTimeAttr", "LastSycDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SLAID", "sLAIDAttr", "SLAID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("SLADate", "sLADateAttr", "SLADate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsCustomDueDate", "isCustomDueDateAttr", "IsCustomDueDate", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("TimezoneID", "timezoneIDAttr", "TimezoneID", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseSLARec.init();
return CaseSLARec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseSLARec = CaseSLARec;

});
define("StateMachineCaseService.model$EscalationReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var EscalationReasonRec = (function (_super) {
__extends(EscalationReasonRec, _super);
function EscalationReasonRec(defaults) {
_super.apply(this, arguments);
}
EscalationReasonRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EscalationReasonRec.init();
return EscalationReasonRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.EscalationReasonRec = EscalationReasonRec;

});
define("StateMachineCaseService.model$SuccessStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var SuccessStatusRec = (function (_super) {
__extends(SuccessStatusRec, _super);
function SuccessStatusRec(defaults) {
_super.apply(this, arguments);
}
SuccessStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SuccessStatusRec.init();
return SuccessStatusRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.SuccessStatusRec = SuccessStatusRec;

});
define("StateMachineCaseService.model$CaseAssignmentChangeSummaryRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseAssignmentChangeSummaryRec = (function (_super) {
__extends(CaseAssignmentChangeSummaryRec, _super);
function CaseAssignmentChangeSummaryRec(defaults) {
_super.apply(this, arguments);
}
CaseAssignmentChangeSummaryRec.attributesToDeclare = function () {
return [
this.attr("AssignmentChange", "assignmentChangeAttr", "AssignmentChange", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateTime", "dateTimeAttr", "DateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseAssignmentChangeSummaryRec.init();
return CaseAssignmentChangeSummaryRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseAssignmentChangeSummaryRec = CaseAssignmentChangeSummaryRec;

});
define("StateMachineCaseService.model$SLARec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var SLARec = (function (_super) {
__extends(SLARec, _super);
function SLARec(defaults) {
_super.apply(this, arguments);
}
SLARec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SLARec.init();
return SLARec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.SLARec = SLARec;

});
define("StateMachineCaseService.model$ApprovalStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var ApprovalStatusRec = (function (_super) {
__extends(ApprovalStatusRec, _super);
function ApprovalStatusRec(defaults) {
_super.apply(this, arguments);
}
ApprovalStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ApprovalStatusRec.init();
return ApprovalStatusRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.ApprovalStatusRec = ApprovalStatusRec;

});
define("StateMachineCaseService.model$CaseInfoRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseInfoRec = (function (_super) {
__extends(CaseInfoRec, _super);
function CaseInfoRec(defaults) {
_super.apply(this, arguments);
}
CaseInfoRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CaseId", "caseIdAttr", "CaseId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "StakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyId", "policyIdAttr", "PolicyId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderTypeCode", "stakeholderTypeCodeAttr", "StakeholderTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("InteractionId", "interactionIdAttr", "InteractionId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StatusReason", "statusReasonAttr", "StatusReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ApprovalStatusId", "approvalStatusIdAttr", "ApprovalStatusId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RejectionReasonCode", "rejectionReasonCodeAttr", "RejectionReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RejectionReasonDesc", "rejectionReasonDescAttr", "RejectionReasonDesc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CaseRejectReasonId", "caseRejectReasonIdAttr", "CaseRejectReasonId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EscalationReasonCode", "escalationReasonCodeAttr", "EscalationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EscalationReason", "escalationReasonAttr", "EscalationReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EscalationReasonId", "escalationReasonIdAttr", "EscalationReasonId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OnHoldReasonCode", "onHoldReasonCodeAttr", "OnHoldReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OnHoldReasonDesc", "onHoldReasonDescAttr", "OnHoldReasonDesc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OnHoldReasonId", "onHoldReasonIdAttr", "OnHoldReasonId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CancellationReasonCode", "cancellationReasonCodeAttr", "CancellationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CancellationReasonDesc", "cancellationReasonDescAttr", "CancellationReasonDesc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CancellationReasonId", "cancellationReasonIdAttr", "CancellationReasonId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("QuoteId", "quoteIdAttr", "QuoteId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CaseStatusPurposeId", "caseStatusPurposeIdAttr", "CaseStatusPurposeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("AffectedMember", "affectedMemberAttr", "AffectedMember", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseInfoRec.init();
return CaseInfoRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseInfoRec = CaseInfoRec;

});
define("StateMachineCaseService.model$CaseRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseRec = (function (_super) {
__extends(CaseRec, _super);
function CaseRec(defaults) {
_super.apply(this, arguments);
}
CaseRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CaseNumber", "caseNumberAttr", "CaseNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ParentCaseId", "parentCaseIdAttr", "ParentCaseId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CaseStatusId", "caseStatusIdAttr", "CaseStatusId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CaseStatusDate", "caseStatusDateAttr", "CaseStatusDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("OwnerTeamId", "ownerTeamIdAttr", "OwnerTeamId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OwnerUserID", "ownerUserIDAttr", "OwnerUserID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RequiredRoleId", "requiredRoleIdAttr", "RequiredRoleId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ExternalID", "externalIDAttr", "ExternalID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "EffectiveDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("IsFromApi", "isFromApiAttr", "IsFromApi", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CategoryId", "categoryIdAttr", "CategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SubCategoryId", "subCategoryIdAttr", "SubCategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PriorityId", "priorityIdAttr", "PriorityId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "IsRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AlternativeContactDetail", "alternativeContactDetailAttr", "AlternativeContactDetail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsEscalateCase", "isEscalateCaseAttr", "IsEscalateCase", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseRec.init();
return CaseRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseRec = CaseRec;

});
define("StateMachineCaseService.model$CaseStatusPurposeRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CaseStatusPurposeRec = (function (_super) {
__extends(CaseStatusPurposeRec, _super);
function CaseStatusPurposeRec(defaults) {
_super.apply(this, arguments);
}
CaseStatusPurposeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CaseStatusPurposeRec.init();
return CaseStatusPurposeRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CaseStatusPurposeRec = CaseStatusPurposeRec;

});
define("StateMachineCaseService.model$CategoryRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CategoryRec = (function (_super) {
__extends(CategoryRec, _super);
function CategoryRec(defaults) {
_super.apply(this, arguments);
}
CategoryRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DefaultTeamId", "defaultTeamIdAttr", "DefaultTeamId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DefaultPriorityId", "defaultPriorityIdAttr", "DefaultPriorityId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsApprovalNeeded", "isApprovalNeededAttr", "IsApprovalNeeded", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsCaseTrigger", "isCaseTriggerAttr", "IsCaseTrigger", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CategoryRec.init();
return CategoryRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CategoryRec = CategoryRec;

});
define("StateMachineCaseService.model$OnHoldReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var OnHoldReasonRec = (function (_super) {
__extends(OnHoldReasonRec, _super);
function OnHoldReasonRec(defaults) {
_super.apply(this, arguments);
}
OnHoldReasonRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OnHoldReasonRec.init();
return OnHoldReasonRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.OnHoldReasonRec = OnHoldReasonRec;

});
define("StateMachineCaseService.model$StatusRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var StatusRec = (function (_super) {
__extends(StatusRec, _super);
function StatusRec(defaults) {
_super.apply(this, arguments);
}
StatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsUnassigned", "isUnassignedAttr", "IsUnassigned", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("GraphColor", "graphColorAttr", "GraphColor", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DashboardOrder", "dashboardOrderAttr", "DashboardOrder", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StatusRec.init();
return StatusRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.StatusRec = StatusRec;

});
define("StateMachineCaseService.model$Case_StructRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var Case_StructRec = (function (_super) {
__extends(Case_StructRec, _super);
function Case_StructRec(defaults) {
_super.apply(this, arguments);
}
Case_StructRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CaseNumber", "caseNumberAttr", "CaseNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ParentCaseId", "parentCaseIdAttr", "ParentCaseId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CaseStatusId", "caseStatusIdAttr", "CaseStatusId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("OwnerTeamId", "ownerTeamIdAttr", "OwnerTeamId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OwnerUserID", "ownerUserIDAttr", "OwnerUserID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RequiredRoleId", "requiredRoleIdAttr", "RequiredRoleId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExternalID", "externalIDAttr", "ExternalID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "EffectiveDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("IsFromApi", "isFromApiAttr", "IsFromApi", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CategoryId", "categoryIdAttr", "CategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SubCategoryId", "subCategoryIdAttr", "SubCategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PriorityId", "priorityIdAttr", "PriorityId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "IsRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AlternativeContactDetail", "alternativeContactDetailAttr", "AlternativeContactDetail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsEscalateCase", "isEscalateCaseAttr", "IsEscalateCase", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Case_StructRec.init();
return Case_StructRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.Case_StructRec = Case_StructRec;

});
define("StateMachineCaseService.model$CategoryStructureRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var CategoryStructureRec = (function (_super) {
__extends(CategoryStructureRec, _super);
function CategoryStructureRec(defaults) {
_super.apply(this, arguments);
}
CategoryStructureRec.attributesToDeclare = function () {
return [
this.attr("CategoryId", "categoryIdAttr", "CategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DefaultTeamId", "defaultTeamIdAttr", "DefaultTeamId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DefaultPriorityId", "defaultPriorityIdAttr", "DefaultPriorityId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Status", "statusAttr", "Status", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RequiresApproval", "requiresApprovalAttr", "RequiresApproval", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsCaseTrigger", "isCaseTriggerAttr", "IsCaseTrigger", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CategoryStructureRec.init();
return CategoryStructureRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.CategoryStructureRec = CategoryStructureRec;

});
define("StateMachineCaseService.model$TeamRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var TeamRec = (function (_super) {
__extends(TeamRec, _super);
function TeamRec(defaults) {
_super.apply(this, arguments);
}
TeamRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsCaseTrigger", "isCaseTriggerAttr", "IsCaseTrigger", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TeamRec.init();
return TeamRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.TeamRec = TeamRec;

});
define("StateMachineCaseService.model$SubCategoryRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var SubCategoryRec = (function (_super) {
__extends(SubCategoryRec, _super);
function SubCategoryRec(defaults) {
_super.apply(this, arguments);
}
SubCategoryRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Code", "codeAttr", "Code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CategoryId", "categoryIdAttr", "CategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LastUpdatedOn", "lastUpdatedOnAttr", "LastUpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastUpdatedBy", "lastUpdatedByAttr", "LastUpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDeleted", "isDeletedAttr", "IsDeleted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsCaseTrigger", "isCaseTriggerAttr", "IsCaseTrigger", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SubCategoryRec.init();
return SubCategoryRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.SubCategoryRec = SubCategoryRec;

});
define("StateMachineCaseService.model$TriggerCodeMappingRec", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model"], function (exports, OutSystems, StateMachineCaseServiceModel) {
var OS = OutSystems.Internal;
var TriggerCodeMappingRec = (function (_super) {
__extends(TriggerCodeMappingRec, _super);
function TriggerCodeMappingRec(defaults) {
_super.apply(this, arguments);
}
TriggerCodeMappingRec.attributesToDeclare = function () {
return [
this.attr("Tenant_Id", "tenant_IdAttr", "Tenant_Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TriggerCode", "triggerCodeAttr", "TriggerCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubCategoryId", "subCategoryIdAttr", "SubCategoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TriggerCodeMappingRec.init();
return TriggerCodeMappingRec;
})(OS.DataTypes.GenericRecord);
StateMachineCaseServiceModel.TriggerCodeMappingRec = TriggerCodeMappingRec;

});
define("StateMachineCaseService.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var StateMachineCaseServiceModel = exports;
});
