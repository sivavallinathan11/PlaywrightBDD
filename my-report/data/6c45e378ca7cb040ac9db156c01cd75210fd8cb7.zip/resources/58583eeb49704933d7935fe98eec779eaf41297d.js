define("PHICore.controller$AddAriaLabel", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.controller$AddAriaLabel.SetAriaLabelJS", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICore_controller_AddAriaLabel_SetAriaLabelJS, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.addAriaLabel$Action = function (widgetIdIn, valueIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.AddAriaLabel$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.valueInLocal = valueIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:YZUqYTgXb0+D1VF13uyLQQ:/ClientActionFlows.YZUqYTgXb0+D1VF13uyLQQ:uAWkfto35lXulkaOU70eJQ", "PHICore", "AddAriaLabel", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iYjqF0geekuF6gnQxNWQpg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:z1oJcsr0Mku+PRcS3kvKaQ", callContext.id);
controller.safeExecuteJSNode(PHICore_controller_AddAriaLabel_SetAriaLabelJS, "SetAriaLabel", "AddAriaLabel", {
Value: OS.DataConversion.JSNodeParamConverter.to(vars.value.valueInLocal, OS.Types.Text),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hZATZH4YfkShIEBn3eEn_w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:YZUqYTgXb0+D1VF13uyLQQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.AddAriaLabel$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Value",
attrName: "valueInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.addAriaLabel$Action = function (widgetIdIn, valueIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
valueIn = (valueIn === undefined) ? "" : valueIn;
return controller.executeActionInsideJSNode(PHICoreController.default.addAriaLabel$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(valueIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("PHICore.controller$AddAriaLabel.SetAriaLabelJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
const el = document.getElementById($parameters.WidgetId);
el.setAttribute('aria-label', $parameters.Value);
};
});

define("PHICore.controller$AllowSuccess", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.controller$ServerAction.IsAllowSuccess"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.allowSuccess$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var isAllowSuccessVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.AllowSuccess$outVars"))());
varBag.callContext = callContext;
varBag.isAllowSuccessVar = isAllowSuccessVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:FApULAKWDEuEqkhYtJOz6Q:/ClientActionFlows.FApULAKWDEuEqkhYtJOz6Q:iIvtfFNloR5EU0DZpObUQw", "PHICore", "AllowSuccess", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:klAszhuivEKLrntriBCiow", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WhE6e8XQS0yWa8X5+Kughg", callContext.id);
// Execute Action: IsAllowSuccess
return controller.isAllowSuccess$ServerAction(callContext).then(function (value) {
isAllowSuccessVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7jJ6WErRkkWCEFCkj1LeYA", callContext.id);
// IsAllow = IsAllowSuccess.IsAllow
outVars.value.isAllowOut = isAllowSuccessVar.value.isAllowOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iq6BJS4rmUWUkiHCD_9r7A", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:FApULAKWDEuEqkhYtJOz6Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:FApULAKWDEuEqkhYtJOz6Q", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.AllowSuccess$outVars", [{
name: "IsAllow",
attrName: "isAllowOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.allowSuccess$Action = function () {
return controller.executeActionInsideJSNode(PHICoreController.default.allowSuccess$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsAllow: OS.DataConversion.JSNodeParamConverter.to(actionResults.isAllowOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$BuildAddress", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.buildAddress$Action = function (line1In, line2In, suburbIn, stateTerritoryCodeIn, postcodeIn, countryIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildAddress$vars"))());
vars.value.line1InLocal = line1In;
vars.value.line2InLocal = line2In;
vars.value.suburbInLocal = suburbIn;
vars.value.stateTerritoryCodeInLocal = stateTerritoryCodeIn;
vars.value.postcodeInLocal = postcodeIn;
vars.value.countryInLocal = countryIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildAddress$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ybMYGNRgqE6SQN2OiAtEtg:/ClientActionFlows.ybMYGNRgqE6SQN2OiAtEtg:eiU8ZQ3Mo6SJohkSSLCSWQ", "PHICore", "BuildAddress", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8jEnQczGb0WH8+4EFDZhZw", callContext.id);
// SetLine1
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mcogL0ho+EmS1G2AtHpVfQ", callContext.id);
// Address = Trim
outVars.value.addressOut = OS.BuiltinFunctions.trim(vars.value.line1InLocal);
// HasLine2?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aLgkSI7oIU2GWfHbv2HNvg", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.line2InLocal)) !== ("")))) {
// AppendLine2
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YaOBgniNm0m913rDxtT+Rw", callContext.id);
// Address = Address + " " + Trim
outVars.value.addressOut = ((outVars.value.addressOut + " ") + OS.BuiltinFunctions.trim(vars.value.line2InLocal));
}

// HasSuburb?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SmNaH5JNBEOAot9O2rqo1w", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.suburbInLocal)) !== ("")))) {
// AppendSuburb
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9Q0KCIVFYE6YMhe6cRg7CA", callContext.id);
// Address = Address + ", " + Trim
outVars.value.addressOut = ((outVars.value.addressOut + ", ") + OS.BuiltinFunctions.trim(vars.value.suburbInLocal));
}

// HasStateTerritoryCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ORIBUGOqIU6WAtgc07OIVg", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.stateTerritoryCodeInLocal)) !== ("")))) {
// AppendStateTerritoryCode
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r4a6yuwYjUGxhHxiJMZWTg", callContext.id);
// Address = Address + ", " + Trim
outVars.value.addressOut = ((outVars.value.addressOut + ", ") + OS.BuiltinFunctions.trim(vars.value.stateTerritoryCodeInLocal));
}

// HasPostCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Z199yAjVcESNwH9W+JwKHw", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.postcodeInLocal)) !== ("")))) {
// AppendPostcode
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:P_zr7kf5CEeRuDQ6gYG+aQ", callContext.id);
// Address = Address + " " + Trim
outVars.value.addressOut = ((outVars.value.addressOut + " ") + OS.BuiltinFunctions.trim(vars.value.postcodeInLocal));
}

// OverseasAndHasCountry?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lASr4dUUW0WC6VBSnC_H4w", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.countryInLocal)) !== ("")))) {
// AppendCountry
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NC4GN0+HAkqmT3ooQgFgjg", callContext.id);
// Address = Address + ", " + Trim
outVars.value.addressOut = ((outVars.value.addressOut + ", ") + OS.BuiltinFunctions.trim(vars.value.countryInLocal));
}

// Trim
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oI+b1USjJEWjtD4Ia_Pb7g", callContext.id);
// Address = Trim
outVars.value.addressOut = OS.BuiltinFunctions.trim(outVars.value.addressOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QTzAf_NyyUqm8AdSb1DxoA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ybMYGNRgqE6SQN2OiAtEtg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildAddress$vars", [{
name: "Line1",
attrName: "line1InLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Line2",
attrName: "line2InLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Suburb",
attrName: "suburbInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "StateTerritoryCode",
attrName: "stateTerritoryCodeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Postcode",
attrName: "postcodeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Country",
attrName: "countryInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildAddress$outVars", [{
name: "Address",
attrName: "addressOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.buildAddress$Action = function (line1In, line2In, suburbIn, stateTerritoryCodeIn, postcodeIn, countryIn) {
line1In = (line1In === undefined) ? "" : line1In;
line2In = (line2In === undefined) ? "" : line2In;
suburbIn = (suburbIn === undefined) ? "" : suburbIn;
stateTerritoryCodeIn = (stateTerritoryCodeIn === undefined) ? "" : stateTerritoryCodeIn;
postcodeIn = (postcodeIn === undefined) ? "" : postcodeIn;
countryIn = (countryIn === undefined) ? "" : countryIn;
return controller.executeActionInsideJSNode(PHICoreController.default.buildAddress$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(line1In, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(line2In, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(suburbIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(stateTerritoryCodeIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(postcodeIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(countryIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Address: OS.DataConversion.JSNodeParamConverter.to(actionResults.addressOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$BuildMemberAdditional", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Text3Record", "PHICore.model$Text3RecordList", "PHICore.model$PolicyMemberRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.buildMemberAdditional$Action = function (policyMemberIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildMemberAdditional$vars"))());
vars.value.policyMemberInLocal = policyMemberIn.clone();
var string_JoinVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildMemberAdditional$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.string_JoinVar = string_JoinVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Lz0xlbUskku1TNBiXjIL2w:/ClientActionFlows.Lz0xlbUskku1TNBiXjIL2w:3l5pNLhRPZnYfyypRMJ6ww", "PHICore", "BuildMemberAdditional", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kKUcMpaE_Ua1WQybvlZ2TQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g_vQU6IABkilLYxpJkkpdw", callContext.id) && vars.value.policyMemberInLocal.addtionalDetailsAttr.disabilityOverrideAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5tHBRQvxyEKrtVjfdgX0NQ", callContext.id);
// Record.Text = "Disability Override"
vars.value.recordVar.textAttr = "Disability Override";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:y_yhzEbF+0GNfryfGB4QjQ", callContext.id);
// Execute Action: ListAppend_DisabilityOverride
OS.SystemActions.listAppend(vars.value.listVar, vars.value.recordVar, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fwDdv5g02EKUmtUtMeK07Q", callContext.id) && vars.value.policyMemberInLocal.addtionalDetailsAttr.dependentOverrideAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DZ2loJmtPU2Ws+maib_DLQ", callContext.id);
// Record.Text = "Dependent Override"
vars.value.recordVar.textAttr = "Dependent Override";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H6ZbtBeaqEif8uIOXz1LgA", callContext.id);
// Execute Action: ListAppend_DependentOVerride
OS.SystemActions.listAppend(vars.value.listVar, vars.value.recordVar, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LS4qmE7Mz0a8WEnYyas+4A", callContext.id) && vars.value.policyMemberInLocal.addtionalDetailsAttr.peaOverrideAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5qX+vvBiDEClzkgSP+Uq9g", callContext.id);
// Record.Text = "PEA Override"
vars.value.recordVar.textAttr = "PEA Override";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YrroWlRKY0e7XrYI937E5A", callContext.id);
// Execute Action: ListAppend_PEAOverride
OS.SystemActions.listAppend(vars.value.listVar, vars.value.recordVar, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0tesoc4geEOpx84wLRSHaQ", callContext.id) && vars.value.policyMemberInLocal.addtionalDetailsAttr.studentAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:siGabGdiTESYgkIDa_gs5Q", callContext.id);
// Record.Text = "Student"
vars.value.recordVar.textAttr = "Student";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CyEy9iyuwUOj4+DpRz4K4Q", callContext.id);
// Execute Action: ListAppend_Student
OS.SystemActions.listAppend(vars.value.listVar, vars.value.recordVar, callContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FqUXjZf+h0uaevscZAUegw", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.listVar, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = source.textAttr;
return target;
}), ", ", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:brEVhEtCTkSDOQqLBsyJQQ", callContext.id);
// Additional = String_Join.Text
outVars.value.additionalOut = string_JoinVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2diwC307NkmEYBeqwwnSiA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Lz0xlbUskku1TNBiXjIL2w", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildMemberAdditional$vars", [{
name: "PolicyMember",
attrName: "policyMemberInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyMemberRec();
},
complexType: PHICoreModel.PolicyMemberRec
}, {
name: "List",
attrName: "listVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.Text3RecordList();
},
complexType: PHICoreModel.Text3RecordList
}, {
name: "Record",
attrName: "recordVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Text3Record();
},
complexType: PHICoreModel.Text3Record
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildMemberAdditional$outVars", [{
name: "Additional",
attrName: "additionalOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.buildMemberAdditional$Action = function (policyMemberIn) {
policyMemberIn = (policyMemberIn === undefined) ? new PHICoreModel.PolicyMemberRec() : policyMemberIn;
return controller.executeActionInsideJSNode(PHICoreController.default.buildMemberAdditional$Action.bind(controller, policyMemberIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Additional: OS.DataConversion.JSNodeParamConverter.to(actionResults.additionalOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$BuildName", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.buildName$Action = function (titleIn, firstNameIn, middleNameIn, lastNameIn, preferredNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildName$vars"))());
vars.value.titleInLocal = titleIn;
vars.value.firstNameInLocal = firstNameIn;
vars.value.middleNameInLocal = middleNameIn;
vars.value.lastNameInLocal = lastNameIn;
vars.value.preferredNameInLocal = preferredNameIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.BuildName$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:WRywIky_0EyTxH9cLqy1RQ:/ClientActionFlows.WRywIky_0EyTxH9cLqy1RQ:FSbtFZYywS2AqD7AacpavQ", "PHICore", "BuildName", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b5iJbt5VGE+CWOzs8rrAsQ", callContext.id);
// SetTitle
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d_YI1byNYEOjEEWWbVA9hw", callContext.id);
// Name = Title
outVars.value.nameOut = vars.value.titleInLocal;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XbTahP8b_kSsImooriOg7Q", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.firstNameInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1UjTkz_Z9kiQDUlSvBQ0mA", callContext.id);
// Name = Name + " " + Trim
outVars.value.nameOut = ((outVars.value.nameOut + " ") + OS.BuiltinFunctions.trim(vars.value.firstNameInLocal));
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U3WsLzp6tUesg0I4_k+faw", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.middleNameInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DOV9cACk50aUc+4BzNZoww", callContext.id);
// Name = Name + " " + Trim
outVars.value.nameOut = ((outVars.value.nameOut + " ") + OS.BuiltinFunctions.trim(vars.value.middleNameInLocal));
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:B4Mm7xHYdkWcViWRLrjLCQ", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.lastNameInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WmYH95MWBECrtoniKuB2zw", callContext.id);
// Name = Name + " " + Trim
outVars.value.nameOut = ((outVars.value.nameOut + " ") + OS.BuiltinFunctions.trim(vars.value.lastNameInLocal));
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kF8IfPpzwk+iDcGkYXm1iA", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.preferredNameInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_o5T9pEFEkGhYhdRtXjpjA", callContext.id);
// Name = Name + " (" + Trim + ")"
outVars.value.nameOut = (((outVars.value.nameOut + " (") + OS.BuiltinFunctions.trim(vars.value.preferredNameInLocal)) + ")");
}

// Trim
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9NJOf7pl5UifBbHh_VrWsg", callContext.id);
// Name = Trim
outVars.value.nameOut = OS.BuiltinFunctions.trim(outVars.value.nameOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VAh3IC0BfkijQtE6mgFAzg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:WRywIky_0EyTxH9cLqy1RQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildName$vars", [{
name: "Title",
attrName: "titleInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "FirstName",
attrName: "firstNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MiddleName",
attrName: "middleNameInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "LastName",
attrName: "lastNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PreferredName",
attrName: "preferredNameInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.BuildName$outVars", [{
name: "Name",
attrName: "nameOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.buildName$Action = function (titleIn, firstNameIn, middleNameIn, lastNameIn, preferredNameIn) {
titleIn = (titleIn === undefined) ? "" : titleIn;
firstNameIn = (firstNameIn === undefined) ? "" : firstNameIn;
middleNameIn = (middleNameIn === undefined) ? "" : middleNameIn;
lastNameIn = (lastNameIn === undefined) ? "" : lastNameIn;
preferredNameIn = (preferredNameIn === undefined) ? "" : preferredNameIn;
return controller.executeActionInsideJSNode(PHICoreController.default.buildName$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(titleIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(firstNameIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(middleNameIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(lastNameIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(preferredNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Name: OS.DataConversion.JSNodeParamConverter.to(actionResults.nameOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$Check_Additional_Details", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Stakeholder_AdditionalDetailsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Additional_Details$Action = function (stakeholder_AdditionalDetailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Additional_Details$vars"))());
vars.value.stakeholder_AdditionalDetailsInLocal = stakeholder_AdditionalDetailsIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Additional_Details$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:_myMf4w2FUKFjuVBu4dLtA:/ClientActionFlows._myMf4w2FUKFjuVBu4dLtA:skZInaJkQX2CIrI62_yCUg", "PHICore", "Check_Additional_Details", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ITp_ijQKWkWmyAiuGlGKgw", callContext.id);
// Location is Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TOCWqkl5OUOwjzEq9qQZTg", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholder_AdditionalDetailsInLocal.locationAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4wdFtltbpEOvusKKLIE8Vw", callContext.id);
// LocationError = GetRequiredFieldMsg()
outVars.value.locationErrorOut = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4wdFtltbpEOvusKKLIE8Vw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
}

// Site is Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zIhTQSReHUShVjTCJQsD7w", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholder_AdditionalDetailsInLocal.siteAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BBFz6P0rvEiZvOnpc_qrDQ", callContext.id);
// SiteError = GetRequiredFieldMsg()
outVars.value.siteErrorOut = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BBFz6P0rvEiZvOnpc_qrDQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mWD3Hazi7kGr_Z1IruCcNA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mWD3Hazi7kGr_Z1IruCcNA", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_myMf4w2FUKFjuVBu4dLtA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Additional_Details$vars", [{
name: "Stakeholder_AdditionalDetails",
attrName: "stakeholder_AdditionalDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_AdditionalDetailsRec();
},
complexType: PHICoreModel.Stakeholder_AdditionalDetailsRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Additional_Details$outVars", [{
name: "LocationError",
attrName: "locationErrorOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SiteError",
attrName: "siteErrorOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "HasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.check_Additional_Details$Action = function (stakeholder_AdditionalDetailsIn) {
stakeholder_AdditionalDetailsIn = (stakeholder_AdditionalDetailsIn === undefined) ? new PHICoreModel.Stakeholder_AdditionalDetailsRec() : stakeholder_AdditionalDetailsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Additional_Details$Action.bind(controller, stakeholder_AdditionalDetailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
LocationError: OS.DataConversion.JSNodeParamConverter.to(actionResults.locationErrorOut, OS.Types.Text),
SiteError: OS.DataConversion.JSNodeParamConverter.to(actionResults.siteErrorOut, OS.Types.Text),
HasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$Check_Contact_Details", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$StakeholderEmailList", "PHICore.model$ContactDetail_CountRec", "PHICore.controller$FullValidation_EmailList", "PHICore.model$StakeholderPhoneList", "PHICore.model$ContactDetails_SettingsRec", "PHICore.controller$FullValidation_PhoneList", "PHICore.model$StakeholderAddressList", "PHICore.controller$FullValidation_AddressList", "PHICore.model$ContactDetails_ValidationRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Contact_Details$Action = function (addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn, isLeadIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Contact_Details$vars"))());
vars.value.addressList_HandlerInLocal = addressList_HandlerIn.clone();
vars.value.emailList_HandlerInLocal = emailList_HandlerIn.clone();
vars.value.phoneList_HandlerInLocal = phoneList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
vars.value.contactDetailSettingInLocal = contactDetailSettingIn.clone();
vars.value.stakeholderTypeIdInLocal = stakeholderTypeIdIn;
vars.value.isContributorInLocal = isContributorIn;
vars.value.isLeadInLocal = isLeadIn;
var fullValidation_EmailListVar = new OS.DataTypes.VariableHolder();
var fullValidation_PhoneListVar = new OS.DataTypes.VariableHolder();
var fullValidation_AddressListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Contact_Details$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.fullValidation_EmailListVar = fullValidation_EmailListVar;
varBag.fullValidation_PhoneListVar = fullValidation_PhoneListVar;
varBag.fullValidation_AddressListVar = fullValidation_AddressListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:SGN1CKjT+EyH659Hq08QBg:/ClientActionFlows.SGN1CKjT+EyH659Hq08QBg:9x2xr1WRpMwvEZ2g4rzofA", "PHICore", "Check_Contact_Details", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GgsVkaTssUqeNjxS6aIHdw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3a3fGaBAEkuBI3EEOD0Zlg", callContext.id) && ((vars.value.addressList_HandlerInLocal.isEmpty && vars.value.emailList_HandlerInLocal.isEmpty) && vars.value.phoneList_HandlerInLocal.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id);
// AddressList_Handler_Out = AddressList_Handler
outVars.value.addressList_Handler_OutOut = vars.value.addressList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// EmailList_Handler_Out = EmailList_Handler
outVars.value.emailList_Handler_OutOut = vars.value.emailList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PhoneList_Handler_Out = PhoneList_Handler
outVars.value.phoneList_Handler_OutOut = vars.value.phoneList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// CountRecord_Handler_Out = CountRecord_Handler
outVars.value.countRecord_Handler_OutOut = vars.value.countRecord_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// hasError = True
outVars.value.hasErrorOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// ErrorFeedbackMessage = "You must add at least one contact method."
outVars.value.errorFeedbackMessageOut = "You must add at least one contact method.";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// ContactDetails_Validation.InvalidAddress = AddressList_Handler.Empty
outVars.value.contactDetails_ValidationOut.invalidAddressAttr = vars.value.addressList_HandlerInLocal.isEmpty;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// ContactDetails_Validation.InvalidPhone = PhoneList_Handler.Empty
outVars.value.contactDetails_ValidationOut.invalidPhoneAttr = vars.value.phoneList_HandlerInLocal.isEmpty;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// ContactDetails_Validation.InvalidEmail = If
outVars.value.contactDetails_ValidationOut.invalidEmailAttr = ((vars.value.isLeadInLocal) ? (((((vars.value.addressList_HandlerInLocal.isEmpty && vars.value.emailList_HandlerInLocal.isEmpty) && vars.value.phoneList_HandlerInLocal.isEmpty)) ? (true) : (false))) : (false));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xp7H4RDI0E257yyQPQZEMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// ContactDetails_Validation.ValidationMessage = "Required field"
outVars.value.contactDetails_ValidationOut.validationMessageAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+lyfeBW5m0+CXLb2ktvYIw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TYEdY5ohXUGX5tRVlwqSFg", callContext.id);
// Execute Action: FullValidation_PhoneList
fullValidation_PhoneListVar.value = PHICoreController.default.fullValidation_PhoneList$Action(vars.value.phoneList_HandlerInLocal, vars.value.countRecord_HandlerInLocal, vars.value.contactDetailSettingInLocal, vars.value.stakeholderTypeIdInLocal, vars.value.isContributorInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U3qTBpGsjkiKQvvjdwIapQ", callContext.id);
// CountRecord_Handler = FullValidation_PhoneList.CountRecord_Handler_Out
vars.value.countRecord_HandlerInLocal = fullValidation_PhoneListVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U3qTBpGsjkiKQvvjdwIapQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ContactDetails_Validation.InvalidPhone = FullValidation_PhoneList.hasError_PhoneList
outVars.value.contactDetails_ValidationOut.invalidPhoneAttr = fullValidation_PhoneListVar.value.hasError_PhoneListOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U3qTBpGsjkiKQvvjdwIapQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ContactDetails_Validation.ValidationMessage = FullValidation_PhoneList.ErrorMessage
outVars.value.contactDetails_ValidationOut.validationMessageAttr = fullValidation_PhoneListVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Z2_mR5DqXkS6SEMvxAHy1g", callContext.id);
// Execute Action: FullValidation_EmailList
fullValidation_EmailListVar.value = PHICoreController.default.fullValidation_EmailList$Action(vars.value.emailList_HandlerInLocal, vars.value.countRecord_HandlerInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_8TahK3LT0Gt8X1k7IjFyA", callContext.id);
// CountRecord_Handler = FullValidation_EmailList.CountRecord_Handler_Out
vars.value.countRecord_HandlerInLocal = fullValidation_EmailListVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_8TahK3LT0Gt8X1k7IjFyA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ContactDetails_Validation.InvalidEmail = False
outVars.value.contactDetails_ValidationOut.invalidEmailAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xRlH3S9oFUyzguK+jrcz9A", callContext.id);
// Execute Action: FullValidation_AddressList
fullValidation_AddressListVar.value = PHICoreController.default.fullValidation_AddressList$Action(vars.value.addressList_HandlerInLocal, vars.value.countRecord_HandlerInLocal, vars.value.contactDetailSettingInLocal, vars.value.stakeholderTypeIdInLocal, vars.value.isContributorInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wDNulxven0KLVZwTpo5eIg", callContext.id);
// CountRecord_Handler = FullValidation_AddressList.CountRecord_Handler_Out
vars.value.countRecord_HandlerInLocal = fullValidation_AddressListVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id);
// AddressList_Handler_Out = FullValidation_AddressList.AddressList_Handler_Out
outVars.value.addressList_Handler_OutOut = fullValidation_AddressListVar.value.addressList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// EmailList_Handler_Out = FullValidation_EmailList.EmailList_Handler_Out
outVars.value.emailList_Handler_OutOut = fullValidation_EmailListVar.value.emailList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PhoneList_Handler_Out = FullValidation_PhoneList.PhoneList_Handler_Out
outVars.value.phoneList_Handler_OutOut = fullValidation_PhoneListVar.value.phoneList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// CountRecord_Handler_Out = CountRecord_Handler
outVars.value.countRecord_Handler_OutOut = vars.value.countRecord_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// hasError = FullValidation_PhoneList.hasError_PhoneList or FullValidation_EmailList.hasError_EmailList or FullValidation_AddressList.hasError_AddressList
outVars.value.hasErrorOut = ((fullValidation_PhoneListVar.value.hasError_PhoneListOut || fullValidation_EmailListVar.value.hasError_EmailListOut) || fullValidation_AddressListVar.value.hasError_AddressListOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// ErrorFeedbackMessage = If
outVars.value.errorFeedbackMessageOut = ((((outVars.value.hasErrorOut && (fullValidation_PhoneListVar.value.errorMessageOut === "")) && (fullValidation_AddressListVar.value.errorMessageOut === ""))) ? ("Errors have occurred, please review highlighted fields") : (((((fullValidation_PhoneListVar.value.errorMessageOut) !== (""))) ? (fullValidation_PhoneListVar.value.errorMessageOut) : (((((fullValidation_AddressListVar.value.errorMessageOut) !== (""))) ? (fullValidation_AddressListVar.value.errorMessageOut) : (""))))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// ContactDetails_Validation.ValidationMessage = FullValidation_AddressList.ErrorMessage
outVars.value.contactDetails_ValidationOut.validationMessageAttr = fullValidation_AddressListVar.value.errorMessageOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c66mbNRvq0uJ2cE1HIMXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// ContactDetails_Validation.InvalidAddress = FullValidation_AddressList.hasError_AddressList
outVars.value.contactDetails_ValidationOut.invalidAddressAttr = fullValidation_AddressListVar.value.hasError_AddressListOut;
// Lead or Non-Insured-Contributor
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Kh5rpATuJEWR+_SPVltCDg", callContext.id) && ((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.lead) || ((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.nonInsured) && vars.value.isContributorInLocal)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qo4qWR3xoEyDOQWUebh_rw", callContext.id);
// CountRecord_Handler = FullValidation_PhoneList.CountRecord_Handler_Out
vars.value.countRecord_HandlerInLocal = fullValidation_PhoneListVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qo4qWR3xoEyDOQWUebh_rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ContactDetails_Validation.InvalidPhone = False
outVars.value.contactDetails_ValidationOut.invalidPhoneAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qo4qWR3xoEyDOQWUebh_rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ContactDetails_Validation.InvalidAddress = False
outVars.value.contactDetails_ValidationOut.invalidAddressAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qo4qWR3xoEyDOQWUebh_rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ContactDetails_Validation.InvalidEmail = False
outVars.value.contactDetails_ValidationOut.invalidEmailAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qo4qWR3xoEyDOQWUebh_rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// ContactDetails_Validation.ValidationMessage = ""
outVars.value.contactDetails_ValidationOut.validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o4VA1gTsY0mr3qxwcEZl1A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o4VA1gTsY0mr3qxwcEZl1A", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:SGN1CKjT+EyH659Hq08QBg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Contact_Details$vars", [{
name: "AddressList_Handler",
attrName: "addressList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler",
attrName: "emailList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler",
attrName: "phoneList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "ContactDetailSetting",
attrName: "contactDetailSettingInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_SettingsRec();
},
complexType: PHICoreModel.ContactDetails_SettingsRec
}, {
name: "StakeholderTypeId",
attrName: "stakeholderTypeIdInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsContributor",
attrName: "isContributorInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsLead",
attrName: "isLeadInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Contact_Details$outVars", [{
name: "AddressList_Handler_Out",
attrName: "addressList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler_Out",
attrName: "emailList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler_Out",
attrName: "phoneList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ContactDetails_Validation",
attrName: "contactDetails_ValidationOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_ValidationRec();
},
complexType: PHICoreModel.ContactDetails_ValidationRec
}]);
PHICoreController.default.clientActionProxies.check_Contact_Details$Action = function (addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn, isLeadIn) {
addressList_HandlerIn = (addressList_HandlerIn === undefined) ? new PHICoreModel.StakeholderAddressList() : addressList_HandlerIn;
emailList_HandlerIn = (emailList_HandlerIn === undefined) ? new PHICoreModel.StakeholderEmailList() : emailList_HandlerIn;
phoneList_HandlerIn = (phoneList_HandlerIn === undefined) ? new PHICoreModel.StakeholderPhoneList() : phoneList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
contactDetailSettingIn = (contactDetailSettingIn === undefined) ? new PHICoreModel.ContactDetails_SettingsRec() : contactDetailSettingIn;
stakeholderTypeIdIn = (stakeholderTypeIdIn === undefined) ? 0 : stakeholderTypeIdIn;
isContributorIn = (isContributorIn === undefined) ? false : isContributorIn;
isLeadIn = (isLeadIn === undefined) ? false : isLeadIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Contact_Details$Action.bind(controller, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, OS.DataConversion.JSNodeParamConverter.from(isContributorIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(isLeadIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AddressList_Handler_Out: actionResults.addressList_Handler_OutOut,
EmailList_Handler_Out: actionResults.emailList_Handler_OutOut,
PhoneList_Handler_Out: actionResults.phoneList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
ContactDetails_Validation: actionResults.contactDetails_ValidationOut
};
});
};
});

define("PHICore.controller$Check_Eligibility", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Eligibility_StructRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Eligibility$Action = function (eligibility_StructIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Eligibility$vars"))());
vars.value.eligibility_StructInLocal = eligibility_StructIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Eligibility$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:dMfhUZQXlEKFIBWFTczUPQ:/ClientActionFlows.dMfhUZQXlEKFIBWFTczUPQ:Z2Xp5NeaUlwuiOixmjzvnw", "PHICore", "Check_Eligibility", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UOyDKQz0r0KWbVFshMQ6ig", callContext.id);
// no reason
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kmjAAx2xF0iRP0hPxXuiRw", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.eligibility_StructInLocal.reasonAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JSvlguR_bUy3qcUK5q1ayQ", callContext.id);
// Eligibility_Struct.Reason.Error = GetRequiredFieldMsg()
vars.value.eligibility_StructInLocal.reasonAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JSvlguR_bUy3qcUK5q1ayQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no subreason code
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7WYl5RgFOU+2nOmvpnvJ8Q", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.eligibility_StructInLocal.subReasonAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ReUE1pSKYUawhGjQLP7uTg", callContext.id);
// Eligibility_Struct.SubReason.Error = GetRequiredFieldMsg()
vars.value.eligibility_StructInLocal.subReasonAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ReUE1pSKYUawhGjQLP7uTg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no effective date
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F7I8FDMbm06mngmZDgMJ8A", callContext.id) && vars.value.eligibility_StructInLocal.effectiveDateAttr.valueAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+9sEd_JLqU+iqte1vB7ltw", callContext.id);
// Eligibility_Struct.EffectiveDate.Error = GetRequiredFieldMsg()
vars.value.eligibility_StructInLocal.effectiveDateAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+9sEd_JLqU+iqte1vB7ltw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PTGsRLO96k6G5U24R1CLtA", callContext.id) && outVars.value.hasErrorOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iosI+PQnE0ecwDMI94IoeA", callContext.id);
// ErrorFeedbackMessage = "Errors have occurred, please review highlighted fields"
outVars.value.errorFeedbackMessageOut = "Errors have occurred, please review highlighted fields";
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G36CLsvdHEmVsJPqGtInDg", callContext.id);
// Eligibility_Handler_Out = Eligibility_Struct
outVars.value.eligibility_Handler_OutOut = vars.value.eligibility_StructInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JaF0EbPQvkyedcI6HKlCyg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:dMfhUZQXlEKFIBWFTczUPQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Eligibility$vars", [{
name: "Eligibility_Struct",
attrName: "eligibility_StructInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Eligibility_StructRec();
},
complexType: PHICoreModel.Eligibility_StructRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Eligibility$outVars", [{
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Eligibility_Handler_Out",
attrName: "eligibility_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Eligibility_StructRec();
},
complexType: PHICoreModel.Eligibility_StructRec
}]);
PHICoreController.default.clientActionProxies.check_Eligibility$Action = function (eligibility_StructIn) {
eligibility_StructIn = (eligibility_StructIn === undefined) ? new PHICoreModel.Eligibility_StructRec() : eligibility_StructIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Eligibility$Action.bind(controller, eligibility_StructIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
Eligibility_Handler_Out: actionResults.eligibility_Handler_OutOut
};
});
};
});

define("PHICore.controller$Check_Level_Of_Interest", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$InterestLevel_StructRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Level_Of_Interest$Action = function (interestLevel_HandlerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Level_Of_Interest$vars"))());
vars.value.interestLevel_HandlerInLocal = interestLevel_HandlerIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Level_Of_Interest$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:k4gcYevJHUiyHVtdtr9bjA:/ClientActionFlows.k4gcYevJHUiyHVtdtr9bjA:W_LxGuPOKdoLa6RihHt8fQ", "PHICore", "Check_Level_Of_Interest", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqcRDQoXc0a_7muV8nW0wQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ITMTt6kLbUujXoMmVUCrKQ", callContext.id);
// hasError = False
outVars.value.hasErrorOut = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ITMTt6kLbUujXoMmVUCrKQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// InterestLevel_Handler.interestLevelCode_Error = ""
vars.value.interestLevel_HandlerInLocal.interestLevelCode_ErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ITMTt6kLbUujXoMmVUCrKQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// InterestLevel_Handler.followUpDueDate_Error = ""
vars.value.interestLevel_HandlerInLocal.followUpDueDate_ErrorAttr = "";
// no interest level
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CXt_nplmQUyR3r1pJBnTUQ", callContext.id) && (vars.value.interestLevel_HandlerInLocal.interestLevelCodeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IP23iQibMUavrPlbXbkrow", callContext.id);
// InterestLevel_Handler.interestLevelCode = "na"
vars.value.interestLevel_HandlerInLocal.interestLevelCodeAttr = "na";
}

// no follow up
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7fYW+cx+Ukmet9_1JTFibw", callContext.id) && (vars.value.interestLevel_HandlerInLocal.followUpDueDateAttr.equals(OS.BuiltinFunctions.nullDate()) && vars.value.interestLevel_HandlerInLocal.isFollowUpAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YE3c_XkQek6HBHLHaWgfEg", callContext.id);
// InterestLevel_Handler.followUpDueDate_Error = GetRequiredFieldMsg()
vars.value.interestLevel_HandlerInLocal.followUpDueDate_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YE3c_XkQek6HBHLHaWgfEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// hasError
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zMotOBFc5k+q0tpsWVNZAA", callContext.id) && outVars.value.hasErrorOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HcIj08+M30CpGl88ZStlPQ", callContext.id);
// ErrorFeedbackMessage = "Errors have occurred, please review highlighted fields"
outVars.value.errorFeedbackMessageOut = "Errors have occurred, please review highlighted fields";
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DYxatIkafEGdw5k4TpEncw", callContext.id);
// InterestLevel_Handler_Out = InterestLevel_Handler
outVars.value.interestLevel_Handler_OutOut = vars.value.interestLevel_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ePU4kLdtTkKXy4ZMWCRocA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:k4gcYevJHUiyHVtdtr9bjA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Level_Of_Interest$vars", [{
name: "InterestLevel_Handler",
attrName: "interestLevel_HandlerInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.InterestLevel_StructRec();
},
complexType: PHICoreModel.InterestLevel_StructRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Level_Of_Interest$outVars", [{
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "InterestLevel_Handler_Out",
attrName: "interestLevel_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.InterestLevel_StructRec();
},
complexType: PHICoreModel.InterestLevel_StructRec
}]);
PHICoreController.default.clientActionProxies.check_Level_Of_Interest$Action = function (interestLevel_HandlerIn) {
interestLevel_HandlerIn = (interestLevel_HandlerIn === undefined) ? new PHICoreModel.InterestLevel_StructRec() : interestLevel_HandlerIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Level_Of_Interest$Action.bind(controller, interestLevel_HandlerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
InterestLevel_Handler_Out: actionResults.interestLevel_Handler_OutOut
};
});
};
});

define("PHICore.controller$Check_Personal_Details", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "PHICore.model$Stakeholder_AdditionalDetailsRec", "PHICore.controller$Check_Additional_Details", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$PersonalDetails_StructRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Personal_Details$Action = function (personalDetails_HandlerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Personal_Details$vars"))());
vars.value.personalDetails_HandlerInLocal = personalDetails_HandlerIn.clone();
var check_Additional_DetailsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Personal_Details$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.check_Additional_DetailsVar = check_Additional_DetailsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:VMULoZseWUWZJlVsHJt+Gg:/ClientActionFlows.VMULoZseWUWZJlVsHJt+Gg:d5dWn1pmrEE+uavXtNbRRA", "PHICore", "Check_Personal_Details", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LIMzkhm2fE6icG+++3GA9g", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fQaTSlz3C0GgFDC8fwWKrg", callContext.id);
// Execute Action: Check_Additional_Details
check_Additional_DetailsVar.value = PHICoreController.default.check_Additional_Details$Action(vars.value.personalDetails_HandlerInLocal.stakeholder_AdditionalDetailsAttr, callContext);

// trim
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SX4ghwLHJEOx1vmahT2oJg", callContext.id);
// PersonalDetails_Handler.firstName = Trim
vars.value.personalDetails_HandlerInLocal.firstNameAttr = OS.BuiltinFunctions.trim(vars.value.personalDetails_HandlerInLocal.firstNameAttr);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SX4ghwLHJEOx1vmahT2oJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PersonalDetails_Handler.lastName = Trim
vars.value.personalDetails_HandlerInLocal.lastNameAttr = OS.BuiltinFunctions.trim(vars.value.personalDetails_HandlerInLocal.lastNameAttr);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SX4ghwLHJEOx1vmahT2oJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PersonalDetails_Handler.firstName_Error = ""
vars.value.personalDetails_HandlerInLocal.firstName_ErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SX4ghwLHJEOx1vmahT2oJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PersonalDetails_Handler.lastName_Error = ""
vars.value.personalDetails_HandlerInLocal.lastName_ErrorAttr = "";
// no firstname
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ztIg4IvxOUGG0eIJ1wqEZQ", callContext.id) && (vars.value.personalDetails_HandlerInLocal.firstNameAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lCtz4Nns1k+UwmgiUkeRjw", callContext.id);
// PersonalDetails_Handler.firstName_Error = GetRequiredFieldMsg()
vars.value.personalDetails_HandlerInLocal.firstName_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lCtz4Nns1k+UwmgiUkeRjw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no lastname
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bU+yOecKHkKCvfxh0KEVvg", callContext.id) && (vars.value.personalDetails_HandlerInLocal.lastNameAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sWAmpp6vrUSQzXJng5KouA", callContext.id);
// PersonalDetails_Handler.lastName_Error = GetRequiredFieldMsg()
vars.value.personalDetails_HandlerInLocal.lastName_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sWAmpp6vrUSQzXJng5KouA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// other pronoun error
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rx32EaohX0O5Gzvfntwxxg", callContext.id) && ((vars.value.personalDetails_HandlerInLocal.otherPronounValueAttr === "") && (vars.value.personalDetails_HandlerInLocal.pronounsCodeAttr === "Other")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9LAqhWyz5U273mfiXD3eMg", callContext.id);
// PersonalDetails_Handler.OtherPronounValue_Error = GetRequiredFieldMsg()
vars.value.personalDetails_HandlerInLocal.otherPronounValue_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9LAqhWyz5U273mfiXD3eMg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YgzJwXBAfECciO43kI3Lwg", callContext.id) && check_Additional_DetailsVar.value.hasErrorOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ebc6pDib4EKTcOjXjWQoLg", callContext.id);
// hasError = True
outVars.value.hasErrorOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ebc6pDib4EKTcOjXjWQoLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PersonalDetails_Handler.LocationError = Check_Additional_Details.LocationError
vars.value.personalDetails_HandlerInLocal.locationErrorAttr = check_Additional_DetailsVar.value.locationErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ebc6pDib4EKTcOjXjWQoLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PersonalDetails_Handler.SiteError = Check_Additional_Details.SiteError
vars.value.personalDetails_HandlerInLocal.siteErrorAttr = check_Additional_DetailsVar.value.siteErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ebc6pDib4EKTcOjXjWQoLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PersonalDetails_Handler.Stakeholder_AdditionalDetails.Location.Error = Check_Additional_Details.LocationError
vars.value.personalDetails_HandlerInLocal.stakeholder_AdditionalDetailsAttr.locationAttr.errorAttr = check_Additional_DetailsVar.value.locationErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ebc6pDib4EKTcOjXjWQoLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PersonalDetails_Handler.Stakeholder_AdditionalDetails.Site.Error = Check_Additional_Details.SiteError
vars.value.personalDetails_HandlerInLocal.stakeholder_AdditionalDetailsAttr.siteAttr.errorAttr = check_Additional_DetailsVar.value.siteErrorOut;
}

// hasError
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:74Erd+vTZkaB_52+WvaFsQ", callContext.id) && outVars.value.hasErrorOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O3hgjrSVqUS+1M7WK8qBCw", callContext.id);
// ErrorFeedbackMessage = "Errors have occurred, please review highlighted fields"
outVars.value.errorFeedbackMessageOut = "Errors have occurred, please review highlighted fields";
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p3JYOJ6HX0etXx1jr9p8sQ", callContext.id);
// PersonalDetails_Handler_Out = PersonalDetails_Handler
outVars.value.personalDetails_Handler_OutOut = vars.value.personalDetails_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7M9BO0pAf0S0Jz65ek7rxg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:VMULoZseWUWZJlVsHJt+Gg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Personal_Details$vars", [{
name: "PersonalDetails_Handler",
attrName: "personalDetails_HandlerInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PersonalDetails_StructRec();
},
complexType: PHICoreModel.PersonalDetails_StructRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Personal_Details$outVars", [{
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PersonalDetails_Handler_Out",
attrName: "personalDetails_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PersonalDetails_StructRec();
},
complexType: PHICoreModel.PersonalDetails_StructRec
}]);
PHICoreController.default.clientActionProxies.check_Personal_Details$Action = function (personalDetails_HandlerIn) {
personalDetails_HandlerIn = (personalDetails_HandlerIn === undefined) ? new PHICoreModel.PersonalDetails_StructRec() : personalDetails_HandlerIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Personal_Details$Action.bind(controller, personalDetails_HandlerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
PersonalDetails_Handler_Out: actionResults.personalDetails_Handler_OutOut
};
});
};
});

define("PHICore.controller$Check_Product_Options", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$ProductOptionsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.check_Product_Options$Action = function (productOptionsInIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Product_Options$vars"))());
vars.value.productOptionsInInLocal = productOptionsInIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Check_Product_Options$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Zmyaz_D7rEWC4i2qV+Ht9Q:/ClientActionFlows.Zmyaz_D7rEWC4i2qV+Ht9Q:fTDQ9CJvHYWH7soasEF3Lw", "PHICore", "Check_Product_Options", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:THEYMjc_Dkea06rCfQgnRg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:taWQiQ+gc0mMsxtXqrNDZg", callContext.id);
// ProductOptionsIn.ProductTierCodeError = ""
vars.value.productOptionsInInLocal.productTierCodeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:taWQiQ+gc0mMsxtXqrNDZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ProductOptionsIn.ProductCodeError = ""
vars.value.productOptionsInInLocal.productCodeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:taWQiQ+gc0mMsxtXqrNDZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ProductOptionsIn.RateScaleCodeError = ""
vars.value.productOptionsInInLocal.rateScaleCodeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:taWQiQ+gc0mMsxtXqrNDZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ProductOptionsIn.OtherRateScaleCodeError = ""
vars.value.productOptionsInInLocal.otherRateScaleCodeErrorAttr = "";
// Is Other
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g1sjttPdm0imMc1fknIu1Q", callContext.id) && !((OS.BuiltinFunctions.toLower(vars.value.productOptionsInInLocal.productTypeAttr) === OS.BuiltinFunctions.toLower("Other"))))) {
// NoProductTierCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XnD7_5LCTUaA1sryvQdjTQ", callContext.id) && (((OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.productTypeAttr)) !== ("")) && (OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.productTierCodeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_gIHLMqghEKQ+Io3D8phJQ", callContext.id);
// ProductOptionsIn.ProductTierCodeError = GetRequiredFieldMsg()
vars.value.productOptionsInInLocal.productTierCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_gIHLMqghEKQ+Io3D8phJQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
}

// NoProductCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ydVPmC4rr0OwFihvNwiWBw", callContext.id) && (((OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.productTypeAttr)) !== ("")) && (OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.productCodeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rXg1kYwxgkm_Waml9o2tAg", callContext.id);
// ProductOptionsIn.ProductCodeError = GetRequiredFieldMsg()
vars.value.productOptionsInInLocal.productCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rXg1kYwxgkm_Waml9o2tAg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
}

// NoRateScaleCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tuR0t8TDNUWYdJgJPjDWOg", callContext.id) && (((OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.productTypeAttr)) !== ("")) && (OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.rateScaleCodeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HVbMhGpqYU2i9GHxBQU6zw", callContext.id);
// ProductOptionsIn.RateScaleCodeError = GetRequiredFieldMsg()
vars.value.productOptionsInInLocal.rateScaleCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HVbMhGpqYU2i9GHxBQU6zw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
}

}

// NoOtherRateScaleCode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2kmzgffr4UajfRWpG_r2DQ", callContext.id) && (((vars.value.productOptionsInInLocal.otherProductCodeAttr) !== ("")) && (OS.BuiltinFunctions.trim(vars.value.productOptionsInInLocal.otherRateScaleCodeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ucDEF6CyM0SrUt5IIig4WA", callContext.id);
// ProductOptionsIn.OtherRateScaleCodeError = GetRequiredFieldMsg()
vars.value.productOptionsInInLocal.otherRateScaleCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ucDEF6CyM0SrUt5IIig4WA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
outVars.value.hasErrorOut = true;
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Nv1LmbvxEkGW758KNwHaNQ", callContext.id) && outVars.value.hasErrorOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AuYcjIjTn0qarMpHnXgvsQ", callContext.id);
// ErrorFeedbackMessage = "Errors have occurred, please review highlighted fields"
outVars.value.errorFeedbackMessageOut = "Errors have occurred, please review highlighted fields";
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HwHrM2F5+k6iMvFdfi8PVQ", callContext.id);
// ProductOptionsOut = ProductOptionsIn
outVars.value.productOptionsOutOut = vars.value.productOptionsInInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aaCGvAVUcUWJrKs6HeQ7dA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Zmyaz_D7rEWC4i2qV+Ht9Q", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Product_Options$vars", [{
name: "ProductOptionsIn",
attrName: "productOptionsInInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ProductOptionsRec();
},
complexType: PHICoreModel.ProductOptionsRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Check_Product_Options$outVars", [{
name: "ProductOptionsOut",
attrName: "productOptionsOutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ProductOptionsRec();
},
complexType: PHICoreModel.ProductOptionsRec
}, {
name: "HasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.check_Product_Options$Action = function (productOptionsInIn) {
productOptionsInIn = (productOptionsInIn === undefined) ? new PHICoreModel.ProductOptionsRec() : productOptionsInIn;
return controller.executeActionInsideJSNode(PHICoreController.default.check_Product_Options$Action.bind(controller, productOptionsInIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ProductOptionsOut: actionResults.productOptionsOutOut,
HasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$CheckChange_CaseSummary", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$Changes1RecordList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.checkChange_CaseSummary$Action = function (changesRecordListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckChange_CaseSummary$vars"))());
vars.value.changesRecordListInLocal = changesRecordListIn.clone();
var listAnyVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckChange_CaseSummary$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listAnyVar = listAnyVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:zCwQuqrRkUOEu86z8Dxtng:/ClientActionFlows.zCwQuqrRkUOEu86z8Dxtng:Qzs2KahTO5v+4APJyD6mQQ", "PHICore", "CheckChange_CaseSummary", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1IGD0pCCvE2xChQdeoGR6A", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Znj7zcAleEWjVXuIIjNfOw", callContext.id);
// Execute Action: ListAny
listAnyVar.value = OS.SystemActions.listAny(vars.value.changesRecordListInLocal, function (p) {
return ((p.changesAttr.beforeAttr) !== (p.changesAttr.afterAttr));
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xP6jc08Mq0KcCe+Hc+QQmQ", callContext.id);
// hasChanges = ListAny.Result
outVars.value.hasChangesOut = listAnyVar.value.resultOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_QzUjZiSOUeg8N_ZVmPaTw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:zCwQuqrRkUOEu86z8Dxtng", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckChange_CaseSummary$vars", [{
name: "ChangesRecordList",
attrName: "changesRecordListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.Changes1RecordList();
},
complexType: PHICoreModel.Changes1RecordList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckChange_CaseSummary$outVars", [{
name: "hasChanges",
attrName: "hasChangesOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.checkChange_CaseSummary$Action = function (changesRecordListIn) {
changesRecordListIn = (changesRecordListIn === undefined) ? new PHICoreModel.Changes1RecordList() : changesRecordListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.checkChange_CaseSummary$Action.bind(controller, changesRecordListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
hasChanges: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasChangesOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$CheckIfStakeholderSelected", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.checkIfStakeholderSelected$Action = function (currentStakeholderIdIn, selectedStakeholderIdsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckIfStakeholderSelected$vars"))());
vars.value.currentStakeholderIdInLocal = currentStakeholderIdIn;
vars.value.selectedStakeholderIdsInLocal = selectedStakeholderIdsIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckIfStakeholderSelected$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:GS850oNC5UG01JqaRoZeew:/ClientActionFlows.GS850oNC5UG01JqaRoZeew:DpcI0B5NFLgJwUu0ECTAWA", "PHICore", "CheckIfStakeholderSelected", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:51UOl5lHfkS3BVSiX1fdhw", callContext.id);
// Foreach SelectedStakeholderIds
callContext.iterationContext.registerIterationStart(vars.value.selectedStakeholderIdsInLocal);
try {var selectedStakeholderIdsIterator = callContext.iterationContext.getIterator(vars.value.selectedStakeholderIdsInLocal);
var selectedStakeholderIdsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DpnkG7pASEuWdTXWMm8pCQ", callContext.id) && (selectedStakeholderIdsIndex < vars.value.selectedStakeholderIdsInLocal.length))) {
selectedStakeholderIdsIterator.currentRowNumber = selectedStakeholderIdsIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:USQ3s0me3UmQYLmXAp2DgA", callContext.id) && (vars.value.selectedStakeholderIdsInLocal.getItem(selectedStakeholderIdsIndex.valueOf()) === vars.value.currentStakeholderIdInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ng+NEu0+Vkq7UCmkdmj9bQ", callContext.id);
// IsSelected = True
outVars.value.isSelectedOut = true;
}

selectedStakeholderIdsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.selectedStakeholderIdsInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soYmwpCc4EqPY_VGif4W+g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:GS850oNC5UG01JqaRoZeew", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckIfStakeholderSelected$vars", [{
name: "CurrentStakeholderId",
attrName: "currentStakeholderIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SelectedStakeholderIds",
attrName: "selectedStakeholderIdsInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckIfStakeholderSelected$outVars", [{
name: "IsSelected",
attrName: "isSelectedOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.checkIfStakeholderSelected$Action = function (currentStakeholderIdIn, selectedStakeholderIdsIn) {
currentStakeholderIdIn = (currentStakeholderIdIn === undefined) ? "" : currentStakeholderIdIn;
selectedStakeholderIdsIn = (selectedStakeholderIdsIn === undefined) ? new OS.DataTypes.TextList() : selectedStakeholderIdsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.checkIfStakeholderSelected$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(currentStakeholderIdIn, OS.Types.Text), selectedStakeholderIdsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsSelected: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSelectedOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$CheckNotesPermission", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$Check_PM_MaintainNotes", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_CreateNotes", "Common_CW.controller$Check_SM_7_MaintainNotes", "Common_CW.controller$Check_SM_6_CreateNotes", "PHICore.model$BooleanBoolean1Record"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.checkNotesPermission$Action = function (entityTypeIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckNotesPermission$vars"))());
vars.value.entityTypeIdInLocal = entityTypeIdIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.CheckNotesPermission$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:tQq6Ek_9zUeswFVHywE70Q:/ClientActionFlows.tQq6Ek_9zUeswFVHywE70Q:oDs4DMN7QYi7B7rr7uWV2w", "PHICore", "CheckNotesPermission", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yCLDbBoXNU2KdVq9dmhlcA", callContext.id);
// Note Entity Type
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+s25+Z5ysE6yvAlFgnQs9g", callContext.id) && (vars.value.entityTypeIdInLocal === PHICoreModel.staticEntities.entityType.individual))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WccxrqZnNUuikzLpKE7u4g", callContext.id);
// Permissions.HasCreateNotes = Check_SM_6_CreateNotes()
outVars.value.permissionsOut.hasCreateNotesAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_6_CreateNotes$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WccxrqZnNUuikzLpKE7u4g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Permissions.HasMaintainNotes = Check_SM_7_MaintainNotes()
outVars.value.permissionsOut.hasMaintainNotesAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_7_MaintainNotes$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:acyaEXmgJUqtBT7Et9bWdQ", callContext.id);
} else {
if((vars.value.entityTypeIdInLocal === PHICoreModel.staticEntities.entityType.policy)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JJnMA4YAZUO0MaWY68rJpA", callContext.id);
// Permissions.HasCreateNotes = Check_PM_CreateNotes()
outVars.value.permissionsOut.hasCreateNotesAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_CreateNotes$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JJnMA4YAZUO0MaWY68rJpA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Permissions.HasMaintainNotes = Check_PM_MaintainNotes()
outVars.value.permissionsOut.hasMaintainNotesAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_MaintainNotes$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q4crs57A9kuZYBDUVs79Xg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NTgz5vdPqkCwe5Rf8SYrLg", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:tQq6Ek_9zUeswFVHywE70Q", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckNotesPermission$vars", [{
name: "EntityTypeId",
attrName: "entityTypeIdInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.CheckNotesPermission$outVars", [{
name: "Permissions",
attrName: "permissionsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.BooleanBoolean1Record();
},
complexType: PHICoreModel.BooleanBoolean1Record
}]);
PHICoreController.default.clientActionProxies.checkNotesPermission$Action = function (entityTypeIdIn) {
entityTypeIdIn = (entityTypeIdIn === undefined) ? 0 : entityTypeIdIn;
return controller.executeActionInsideJSNode(PHICoreController.default.checkNotesPermission$Action.bind(controller, entityTypeIdIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Permissions: actionResults.permissionsOut
};
});
};
});

define("PHICore.controller$ConvertDateToMonthYear", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.convertDateToMonthYear$Action = function (monthDateInIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ConvertDateToMonthYear$vars"))());
vars.value.monthDateInInLocal = monthDateInIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ConvertDateToMonthYear$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:NCO6NiyLDESLDJxMWebmKA:/ClientActionFlows.NCO6NiyLDESLDJxMWebmKA:gcMHDrPoN0zresBXvYgOXQ", "PHICore", "ConvertDateToMonthYear", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:86sUq2LX5kqz8O7MrTSWIg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G8fewG3kBkCNJLCe9tjIkg", callContext.id);
// TextDateOut = Substr + "/" + Substr
outVars.value.textDateOutOut = ((OS.BuiltinFunctions.substr(OS.BuiltinFunctions.dateToText(vars.value.monthDateInInLocal), (OS.BuiltinFunctions.index(OS.BuiltinFunctions.dateToText(vars.value.monthDateInInLocal), "-", 0, false, false) + 1), 2) + "/") + OS.BuiltinFunctions.substr(OS.BuiltinFunctions.dateToText(vars.value.monthDateInInLocal), 0, OS.BuiltinFunctions.index(OS.BuiltinFunctions.dateToText(vars.value.monthDateInInLocal), "-", 0, false, false)));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:X0PAJ+5ZukKNSK4_6fyVgQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:NCO6NiyLDESLDJxMWebmKA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ConvertDateToMonthYear$vars", [{
name: "MonthDateIn",
attrName: "monthDateInInLocal",
mandatory: true,
dataType: OS.Types.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ConvertDateToMonthYear$outVars", [{
name: "TextDateOut",
attrName: "textDateOutOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.convertDateToMonthYear$Action = function (monthDateInIn) {
monthDateInIn = (monthDateInIn === undefined) ? OS.DataTypes.DateTime.defaultValue : monthDateInIn;
return controller.executeActionInsideJSNode(PHICoreController.default.convertDateToMonthYear$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(monthDateInIn, OS.Types.Date)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
TextDateOut: OS.DataConversion.JSNodeParamConverter.to(actionResults.textDateOutOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$ConvertMonthYearToDate", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.convertMonthYearToDate$Action = function (textDateInIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ConvertMonthYearToDate$vars"))());
vars.value.textDateInInLocal = textDateInIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ConvertMonthYearToDate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Ctz7d4CSKE+mbqPS2HpHVg:/ClientActionFlows.Ctz7d4CSKE+mbqPS2HpHVg:MQz+J7MZGknXHUFfalEU_Q", "PHICore", "ConvertMonthYearToDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EtEeq4S1_kK6Nw5SHbF7Vg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cC+jQMy6V0GOWo6LaeB8fQ", callContext.id);
// DateOut = TextToDate
outVars.value.dateOutOut = OS.BuiltinFunctions.textToDate((((OS.BuiltinFunctions.substr(vars.value.textDateInInLocal, (OS.BuiltinFunctions.index(vars.value.textDateInInLocal, "/", 0, false, false) + 1), ((OS.BuiltinFunctions.length(vars.value.textDateInInLocal) - OS.BuiltinFunctions.index(vars.value.textDateInInLocal, "/", 0, false, false)) - 1)) + "/") + OS.BuiltinFunctions.substr(vars.value.textDateInInLocal, 0, OS.BuiltinFunctions.index(vars.value.textDateInInLocal, "/", 0, false, false))) + "/01"));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tbk5cq7fIkGqBqcLQ51uTA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Ctz7d4CSKE+mbqPS2HpHVg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ConvertMonthYearToDate$vars", [{
name: "TextDateIn",
attrName: "textDateInInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ConvertMonthYearToDate$outVars", [{
name: "DateOut",
attrName: "dateOutOut",
mandatory: false,
dataType: OS.Types.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
PHICoreController.default.clientActionProxies.convertMonthYearToDate$Action = function (textDateInIn) {
textDateInIn = (textDateInIn === undefined) ? "" : textDateInIn;
return controller.executeActionInsideJSNode(PHICoreController.default.convertMonthYearToDate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(textDateInIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
DateOut: OS.DataConversion.JSNodeParamConverter.to(actionResults.dateOutOut, OS.Types.Date)
};
});
};
});

define("PHICore.controller$Count_ContactDetails_Total", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$StakeholderAddressList", "PHICore.model$StakeholderPhoneList", "PHICore.model$IndividualStakeholder_StructRec", "PHICore.model$ContactDetail_CountRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.count_ContactDetails_Total$Action = function (individualStakeholder_NewIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Count_ContactDetails_Total$vars"))());
vars.value.individualStakeholder_NewInLocal = individualStakeholder_NewIn.clone();
var listFilter_Addr_HomeVar = new OS.DataTypes.VariableHolder();
var listFilter_Phone_MobileVar = new OS.DataTypes.VariableHolder();
var listFilter_Phone_HomeVar = new OS.DataTypes.VariableHolder();
var listFilter_Addr_BusinessVar = new OS.DataTypes.VariableHolder();
var listFilter_Phone_BusinessVar = new OS.DataTypes.VariableHolder();
var listFilter_Addr_MailingVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Count_ContactDetails_Total$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_Addr_HomeVar = listFilter_Addr_HomeVar;
varBag.listFilter_Phone_MobileVar = listFilter_Phone_MobileVar;
varBag.listFilter_Phone_HomeVar = listFilter_Phone_HomeVar;
varBag.listFilter_Addr_BusinessVar = listFilter_Addr_BusinessVar;
varBag.listFilter_Phone_BusinessVar = listFilter_Phone_BusinessVar;
varBag.listFilter_Addr_MailingVar = listFilter_Addr_MailingVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:K7kmnuKTi0ah4zdhwUKMHg:/ClientActionFlows.K7kmnuKTi0ah4zdhwUKMHg:ngD9hCfTP88z0xlKa58pXQ", "PHICore", "Count_ContactDetails_Total", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lo0SSmY5hkSRO9fg0EME9w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rTs5ygatM0+B5mAHRUh24g", callContext.id);
// Execute Action: ListFilter_Phone_Business
listFilter_Phone_BusinessVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderPhoneAttr, function (p) {
return (p.typeAttr === "Business");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cBLSFAWKX0eHQE0vdO57_w", callContext.id);
// Execute Action: ListFilter_Phone_Home
listFilter_Phone_HomeVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderPhoneAttr, function (p) {
return (p.typeAttr === "Home");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bdbgD_up_0iSkocWntzVXw", callContext.id);
// Execute Action: ListFilter_Phone_Mobile
listFilter_Phone_MobileVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderPhoneAttr, function (p) {
return (p.typeAttr === "Mobile");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F9J7i8pSyUKrQyZcp1d1QQ", callContext.id);
// Execute Action: ListFilter_Addr_Business
listFilter_Addr_BusinessVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderAddressAttr, function (p) {
return (p.typeAttr === "Business");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Za+iBWSv9kSPw_ElRn54Jw", callContext.id);
// Execute Action: ListFilter_Addr_Home
listFilter_Addr_HomeVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderAddressAttr, function (p) {
return (p.typeAttr === "Home");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cygAy1GaQUCG2gaEvm6sfg", callContext.id);
// Execute Action: ListFilter_Addr_Mailing
listFilter_Addr_MailingVar.value = OS.SystemActions.listFilter(vars.value.individualStakeholder_NewInLocal.stakeholderAddressAttr, function (p) {
return (p.typeAttr === "Mailing");
}, callContext);

// CountRecord
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id);
// CountRecord.AddrBusinessCount = ListFilter_Addr_Business.FilteredList.Length
outVars.value.countRecordOut.addrBusinessCountAttr = listFilter_Addr_BusinessVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord.AddrHomeCount = ListFilter_Addr_Home.FilteredList.Length
outVars.value.countRecordOut.addrHomeCountAttr = listFilter_Addr_HomeVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountRecord.AddrMailingCount = ListFilter_Addr_Mailing.FilteredList.Length
outVars.value.countRecordOut.addrMailingCountAttr = listFilter_Addr_MailingVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// CountRecord.PhoneBusinessCount = ListFilter_Phone_Business.FilteredList.Length
outVars.value.countRecordOut.phoneBusinessCountAttr = listFilter_Phone_BusinessVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// CountRecord.PhoneHomeCount = ListFilter_Phone_Home.FilteredList.Length
outVars.value.countRecordOut.phoneHomeCountAttr = listFilter_Phone_HomeVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// CountRecord.PhoneMobileCount = ListFilter_Phone_Mobile.FilteredList.Length
outVars.value.countRecordOut.phoneMobileCountAttr = listFilter_Phone_MobileVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b8nVKy+lvkmcyIeZoaQK0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// CountRecord.EmailCount = IndividualStakeholder_New.StakeholderEmail.Length
outVars.value.countRecordOut.emailCountAttr = vars.value.individualStakeholder_NewInLocal.stakeholderEmailAttr.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nNlqcLWJ+kuCRhI3SnNq_A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:K7kmnuKTi0ah4zdhwUKMHg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Count_ContactDetails_Total$vars", [{
name: "IndividualStakeholder_New",
attrName: "individualStakeholder_NewInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.IndividualStakeholder_StructRec();
},
complexType: PHICoreModel.IndividualStakeholder_StructRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Count_ContactDetails_Total$outVars", [{
name: "CountRecord",
attrName: "countRecordOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}]);
PHICoreController.default.clientActionProxies.count_ContactDetails_Total$Action = function (individualStakeholder_NewIn) {
individualStakeholder_NewIn = (individualStakeholder_NewIn === undefined) ? new PHICoreModel.IndividualStakeholder_StructRec() : individualStakeholder_NewIn;
return controller.executeActionInsideJSNode(PHICoreController.default.count_ContactDetails_Total$Action.bind(controller, individualStakeholder_NewIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
CountRecord: actionResults.countRecordOut
};
});
};
});

define("PHICore.controller$DateFormatvalidation_MM_YYYY", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.controller$DateFormatvalidation_MM_YYYY.JavaScript_CheckPatternJS", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICore_controller_DateFormatvalidation_MM_YYYY_JavaScript_CheckPatternJS, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.dateFormatvalidation_MM_YYYY$Action = function (dateIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$vars"))());
vars.value.dateInLocal = dateIn;
var javaScript_CheckPatternJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.javaScript_CheckPatternJSResult = javaScript_CheckPatternJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:FnrQWrsKzkiSmk4fFYaA6Q:/ClientActionFlows.FnrQWrsKzkiSmk4fFYaA6Q:nr9tyDL+5ph28BWAzeKenw", "PHICore", "DateFormatvalidation_MM_YYYY", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3LIsydLFVEa2iF8if8Beow", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ict+VR5DuEWLRluO5UgQeQ", callContext.id);
javaScript_CheckPatternJSResult.value = controller.safeExecuteJSNode(PHICore_controller_DateFormatvalidation_MM_YYYY_JavaScript_CheckPatternJS, "JavaScript_CheckPattern", "DateFormatvalidation_MM_YYYY", {
Date: OS.DataConversion.JSNodeParamConverter.to(vars.value.dateInLocal, OS.Types.Text),
IsValid: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$javaScript_CheckPatternJSResult"))();
jsNodeResult.isValidOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsValid, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:et7M1o6IVEme5tAgRuCSIw", callContext.id);
// IsValid = JavaScript_CheckPattern.IsValid
outVars.value.isValidOut = javaScript_CheckPatternJSResult.value.isValidOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tuZC8OTPCkGQdv51w9u6zw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:FnrQWrsKzkiSmk4fFYaA6Q", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$vars", [{
name: "Date",
attrName: "dateInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$javaScript_CheckPatternJSResult", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.DateFormatvalidation_MM_YYYY$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.dateFormatvalidation_MM_YYYY$Action = function (dateIn) {
dateIn = (dateIn === undefined) ? "" : dateIn;
return controller.executeActionInsideJSNode(PHICoreController.default.dateFormatvalidation_MM_YYYY$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dateIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});
define("PHICore.controller$DateFormatvalidation_MM_YYYY.JavaScript_CheckPatternJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var validator=/(0[1-9]|1[0-2])\/([12]\d{3})/

$parameters.IsValid = validator.test($parameters.Date);

};
});

define("PHICore.controller$FullValidation_AddressList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$ContactDetail_CountRec", "PHICore.model$StakeholderAddressList", "PHICore.model$ContactDetails_SettingsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.fullValidation_AddressList$Action = function (addressList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_AddressList$vars"))());
vars.value.addressList_HandlerInLocal = addressList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
vars.value.contactDetailSettingInLocal = contactDetailSettingIn.clone();
vars.value.stakeholderTypeIdInLocal = stakeholderTypeIdIn;
vars.value.isContributorInLocal = isContributorIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_AddressList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:2uqy0VcYgEeWFVpfPMdKhA:/ClientActionFlows.2uqy0VcYgEeWFVpfPMdKhA:zqVq_Qw4QUgZtz8XQNguyA", "PHICore", "FullValidation_AddressList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oZETYcCsikuvj1tsOC38qA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4QHn+N9be0ivRWU5orTUbw", callContext.id);
// CountRecord_Handler.AddrBusinessCount = 0
vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4QHn+N9be0ivRWU5orTUbw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler.AddrHomeCount = 0
vars.value.countRecord_HandlerInLocal.addrHomeCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4QHn+N9be0ivRWU5orTUbw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountRecord_Handler.AddrMailingCount = 0
vars.value.countRecord_HandlerInLocal.addrMailingCountAttr = 0;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VtR_nWv0GEuhkusKy3YVqA", callContext.id) && vars.value.addressList_HandlerInLocal.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CkZ80E+KOUm0Yma9Kc8gBQ", callContext.id);
// hasError_AddressList = If
outVars.value.hasError_AddressListOut = ((((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.lead) || ((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.nonInsured) && vars.value.isContributorInLocal))) ? (false) : (true));
} else {
// Foreach AddressList_Handler
callContext.iterationContext.registerIterationStart(vars.value.addressList_HandlerInLocal);
try {var addressList_HandlerIterator = callContext.iterationContext.getIterator(vars.value.addressList_HandlerInLocal);
var addressList_HandlerIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EzXsYm+AW0S7b8F8fQ0Aig", callContext.id) && (addressList_HandlerIndex < vars.value.addressList_HandlerInLocal.length))) {
addressList_HandlerIterator.currentRowNumber = addressList_HandlerIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id);
// AddressList_Handler.Current.isActiveError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).isActiveErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AddressList_Handler.Current.countryError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).countryErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// AddressList_Handler.Current.line1Error = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).line1ErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddressList_Handler.Current.line2Error = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).line2ErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// AddressList_Handler.Current.suburbError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).suburbErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// AddressList_Handler.Current.cityError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).cityErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// AddressList_Handler.Current.postalCodeError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).postalCodeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// AddressList_Handler.Current.zippostalCodeError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).zippostalCodeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// AddressList_Handler.Current.stateTerritoryError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).stateTerritoryErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// AddressList_Handler.Current.stateProvinceError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).stateProvinceErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// AddressList_Handler.Current.type_Error = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).type_ErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4fhAy1XQC0WtvRzPsq7kQg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// AddressList_Handler.Current.effectiveDateError = ""
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).effectiveDateErrorAttr = "";
// no type
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_GTXf1sM2kSXYM+yxIQMDA", callContext.id) && (vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O_V5BDTuckSHVB+8WK_vGA", callContext.id);
// AddressList_Handler.Current.type_Error = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).type_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O_V5BDTuckSHVB+8WK_vGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O_V5BDTuckSHVB+8WK_vGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FEv2AFY5B0e0+5iiu8en6Q", callContext.id);
// CountRecord_Handler.AddrBusinessCount = If
vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr = (((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Business")) ? ((vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FEv2AFY5B0e0+5iiu8en6Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler.AddrHomeCount = If
vars.value.countRecord_HandlerInLocal.addrHomeCountAttr = (((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Home")) ? ((vars.value.countRecord_HandlerInLocal.addrHomeCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.addrHomeCountAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FEv2AFY5B0e0+5iiu8en6Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountRecord_Handler.AddrMailingCount = If
vars.value.countRecord_HandlerInLocal.addrMailingCountAttr = (((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Mailing")) ? ((vars.value.countRecord_HandlerInLocal.addrMailingCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.addrMailingCountAttr));
// count check business
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dqi8OdJupU2d5cedZnwYTA", callContext.id) && ((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Business") && (vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr > vars.value.contactDetailSettingInLocal.addrBusinessAttr)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AXy7b2OLAUai34DAbkE+og", callContext.id);
// AddressList_Handler.Current.type_Error = "Max of 1 " + ToLower + " address type is allowed"
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).type_ErrorAttr = (("Max of 1 " + OS.BuiltinFunctions.toLower(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr)) + " address type is allowed");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AXy7b2OLAUai34DAbkE+og", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
} else {
// count check home
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iopremHf0kSOdDGSwebx7w", callContext.id) && ((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Home") && (vars.value.countRecord_HandlerInLocal.addrHomeCountAttr > vars.value.contactDetailSettingInLocal.addrHomeAttr)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uItzx7aAL0ShNKkp2M6yPw", callContext.id);
// AddressList_Handler.Current.type_Error = "Max of 1 " + ToLower + " address type is allowed"
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).type_ErrorAttr = (("Max of 1 " + OS.BuiltinFunctions.toLower(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr)) + " address type is allowed");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uItzx7aAL0ShNKkp2M6yPw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
} else {
// count check mailing
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:stcFkKz4pEODvyoasq3QfA", callContext.id) && ((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr === "Mailing") && (vars.value.countRecord_HandlerInLocal.addrMailingCountAttr > vars.value.contactDetailSettingInLocal.addrMailingAttr)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sxGmbOUrIU+PRCwOSh4jfQ", callContext.id);
// AddressList_Handler.Current.type_Error = "Max of 1 " + ToLower + " address type is allowed"
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).type_ErrorAttr = (("Max of 1 " + OS.BuiltinFunctions.toLower(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).typeAttr)) + " address type is allowed");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sxGmbOUrIU+PRCwOSh4jfQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
}

}

}

// no address
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7U5ll2AZJUqxPiEDP6bD_g", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).line1Attr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EhPl141sqkWh6+fLuBJnZg", callContext.id);
// AddressList_Handler.Current.line1Error = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).line1ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EhPl141sqkWh6+fLuBJnZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EhPl141sqkWh6+fLuBJnZg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// No EffectiveDate?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VvQ+RbVGVkqjPwXiztNqjQ", callContext.id) && vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).effectiveDateAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EqFs1D6xQU+ZTFxJHiNwuw", callContext.id);
// AddressList_Handler.Current.effectiveDateError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).effectiveDateErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EqFs1D6xQU+ZTFxJHiNwuw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EqFs1D6xQU+ZTFxJHiNwuw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// isOverseas
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FfeqEUsQHUO0408l7ldBQQ", callContext.id) && vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).isOverseasAttr)) {
// no city
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U8Y2DvEgwECoi8KSVN9IPQ", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).cityAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:owEXy+SGAUGZhwzp4oERjw", callContext.id);
// AddressList_Handler.Current.cityError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).cityErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:owEXy+SGAUGZhwzp4oERjw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:owEXy+SGAUGZhwzp4oERjw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// no zip postal code
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oir8vg6aOEKlDe9fP0qBvQ", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).zipPostalCodeAttr) === "") || (vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).zipPostalCodeAttr === "0")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MpmqZVqJyEuNKoFt5M9H_Q", callContext.id);
// AddressList_Handler.Current.zippostalCodeError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).zippostalCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MpmqZVqJyEuNKoFt5M9H_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MpmqZVqJyEuNKoFt5M9H_Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// no country
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+e2kOs5h7EutxXkhscPKQA", callContext.id) && (vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).countryCodeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AMK5malru0O9S0zzFsTEqw", callContext.id);
// AddressList_Handler.Current.countryError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).countryErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AMK5malru0O9S0zzFsTEqw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AMK5malru0O9S0zzFsTEqw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

} else {
// no suburb
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gl0P9LxKM0COXkS0NNQsKA", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).suburbAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HLK6mZiZlE+ByyY_ptzqUQ", callContext.id);
// AddressList_Handler.Current.suburbError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).suburbErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HLK6mZiZlE+ByyY_ptzqUQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HLK6mZiZlE+ByyY_ptzqUQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// no stateterritory
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5XOxRZ4Ji0i7TwMN3KGlJA", callContext.id) && (vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).stateTerritoryCodeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JYGSJPf4skaUGp4Wz2Jv+g", callContext.id);
// AddressList_Handler.Current.stateTerritoryError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).stateTerritoryErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JYGSJPf4skaUGp4Wz2Jv+g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JYGSJPf4skaUGp4Wz2Jv+g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// no postcode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Vl_geVy0rEaWjLqnicamTQ", callContext.id) && ((vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).postcodeAttr === "") || (vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).postcodeAttr === "0")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Etgcp786_EqzXjoDxujOuw", callContext.id);
// AddressList_Handler.Current.postalCodeError = GetRequiredFieldMsg()
vars.value.addressList_HandlerInLocal.getItem(addressList_HandlerIndex.valueOf()).postalCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Etgcp786_EqzXjoDxujOuw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_AddressList = True
outVars.value.hasError_AddressListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Etgcp786_EqzXjoDxujOuw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

// -
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mBG_sQzHAkqtd_UkZW_Uhg", callContext.id);
}

}

addressList_HandlerIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.addressList_HandlerInLocal);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jIPUCCNAr02pQbnFDFrR5Q", callContext.id);
// AddressList_Handler_Out = AddressList_Handler
outVars.value.addressList_Handler_OutOut = vars.value.addressList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jIPUCCNAr02pQbnFDFrR5Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler_Out = CountRecord_Handler
outVars.value.countRecord_Handler_OutOut = vars.value.countRecord_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jIPUCCNAr02pQbnFDFrR5Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage = If
outVars.value.errorMessageOut = ((vars.value.hasMandatoryFieldErrorVar) ? ("") : ((((vars.value.countRecord_HandlerInLocal.addrBusinessCountAttr > vars.value.contactDetailSettingInLocal.addrBusinessAttr)) ? ("Max of one business address types are allowed") : ((((vars.value.countRecord_HandlerInLocal.addrHomeCountAttr > vars.value.contactDetailSettingInLocal.addrHomeAttr)) ? ("Max of one home address types are allowed") : ((((vars.value.countRecord_HandlerInLocal.addrMailingCountAttr > vars.value.contactDetailSettingInLocal.addrMailingAttr)) ? ("Max of one mailing address types are allowed") : (((outVars.value.hasError_AddressListOut) ? ("Required field") : (""))))))))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZC_4Ed_OgEu1TB3FyI7RGg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:2uqy0VcYgEeWFVpfPMdKhA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_AddressList$vars", [{
name: "AddressList_Handler",
attrName: "addressList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "ContactDetailSetting",
attrName: "contactDetailSettingInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_SettingsRec();
},
complexType: PHICoreModel.ContactDetails_SettingsRec
}, {
name: "StakeholderTypeId",
attrName: "stakeholderTypeIdInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsContributor",
attrName: "isContributorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "hasMandatoryFieldError",
attrName: "hasMandatoryFieldErrorVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_AddressList$outVars", [{
name: "AddressList_Handler_Out",
attrName: "addressList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "hasError_AddressList",
attrName: "hasError_AddressListOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.fullValidation_AddressList$Action = function (addressList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn) {
addressList_HandlerIn = (addressList_HandlerIn === undefined) ? new PHICoreModel.StakeholderAddressList() : addressList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
contactDetailSettingIn = (contactDetailSettingIn === undefined) ? new PHICoreModel.ContactDetails_SettingsRec() : contactDetailSettingIn;
stakeholderTypeIdIn = (stakeholderTypeIdIn === undefined) ? 0 : stakeholderTypeIdIn;
isContributorIn = (isContributorIn === undefined) ? false : isContributorIn;
return controller.executeActionInsideJSNode(PHICoreController.default.fullValidation_AddressList$Action.bind(controller, addressList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, OS.DataConversion.JSNodeParamConverter.from(isContributorIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AddressList_Handler_Out: actionResults.addressList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
hasError_AddressList: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasError_AddressListOut, OS.Types.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$FullValidation_EmailList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$ValidateEmail", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.model$ContactDetail_CountRec", "PHICore.model$StakeholderEmailList"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.fullValidation_EmailList$Action = function (emailList_HandlerIn, countRecord_HandlerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_EmailList$vars"))());
vars.value.emailList_HandlerInLocal = emailList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
var validateEmailVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_EmailList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateEmailVar = validateEmailVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:NqB9bSSeakGBnQYOjTCrGA:/ClientActionFlows.NqB9bSSeakGBnQYOjTCrGA:Ue78VSC_LYedaxdwGGaV1g", "PHICore", "FullValidation_EmailList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HSUTaFX36k6rxkRHjGOfCw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uHoONXwybEOtShm12nbLRA", callContext.id);
// CountRecord_Handler.EmailCount = 0
vars.value.countRecord_HandlerInLocal.emailCountAttr = 0;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MxKeuTwFxkmKn7FkcQ+hig", callContext.id) && !(vars.value.emailList_HandlerInLocal.isEmpty))) {
// Foreach EmailList_Handler
callContext.iterationContext.registerIterationStart(vars.value.emailList_HandlerInLocal);
try {var emailList_HandlerIterator = callContext.iterationContext.getIterator(vars.value.emailList_HandlerInLocal);
var emailList_HandlerIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tX8N4BwEhkGcPwV21ePpgA", callContext.id) && (emailList_HandlerIndex < vars.value.emailList_HandlerInLocal.length))) {
emailList_HandlerIterator.currentRowNumber = emailList_HandlerIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uKZJ1xJN4UGSnreo4JRIdQ", callContext.id);
// EmailList_Handler.Current.emailAddressError = ""
vars.value.emailList_HandlerInLocal.getItem(emailList_HandlerIndex.valueOf()).emailAddressErrorAttr = "";
// no email
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WZIblFnaUE+WQxU+jNx9Hg", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.emailList_HandlerInLocal.getItem(emailList_HandlerIndex.valueOf()).emailAddressAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4OHskkyiVE+_u3MfJot0oA", callContext.id);
// EmailList_Handler.Current.emailAddressError = GetRequiredFieldMsg()
vars.value.emailList_HandlerInLocal.getItem(emailList_HandlerIndex.valueOf()).emailAddressErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Email, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4OHskkyiVE+_u3MfJot0oA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_EmailList = True
outVars.value.hasError_EmailListOut = true;
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VXTv1x+YWkKq625s9MR12Q", callContext.id);
// Execute Action: ValidateEmail
validateEmailVar.value = Common_CWController.default.validateEmail$Action(vars.value.emailList_HandlerInLocal.getItem(emailList_HandlerIndex.valueOf()).emailAddressAttr, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hGi0Yu2SM06g9IqbwRP1rQ", callContext.id) && !(validateEmailVar.value.isValidOut))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yPrafFTFPUeWukNI01SXGQ", callContext.id);
// EmailList_Handler.Current.emailAddressError = "Email must be in a valid format e.g. username@domain.com"
vars.value.emailList_HandlerInLocal.getItem(emailList_HandlerIndex.valueOf()).emailAddressErrorAttr = "Email must be in a valid format e.g. username@domain.com";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yPrafFTFPUeWukNI01SXGQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_EmailList = True
outVars.value.hasError_EmailListOut = true;
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Wx6BsbvhOUSm6tTn8OR88Q", callContext.id);
// CountRecord_Handler.EmailCount = CountRecord_Handler.EmailCount + 1
vars.value.countRecord_HandlerInLocal.emailCountAttr = (vars.value.countRecord_HandlerInLocal.emailCountAttr + 1);
emailList_HandlerIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.emailList_HandlerInLocal);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TOh4hUfRSEamJx4H3vh0lw", callContext.id);
// EmailList_Handler_Out = EmailList_Handler
outVars.value.emailList_Handler_OutOut = vars.value.emailList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TOh4hUfRSEamJx4H3vh0lw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler_Out = CountRecord_Handler
outVars.value.countRecord_Handler_OutOut = vars.value.countRecord_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:avr4yzR1Q0mcBfeCPeP9oQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:NqB9bSSeakGBnQYOjTCrGA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_EmailList$vars", [{
name: "EmailList_Handler",
attrName: "emailList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_EmailList$outVars", [{
name: "EmailList_Handler_Out",
attrName: "emailList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "hasError_EmailList",
attrName: "hasError_EmailListOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.fullValidation_EmailList$Action = function (emailList_HandlerIn, countRecord_HandlerIn) {
emailList_HandlerIn = (emailList_HandlerIn === undefined) ? new PHICoreModel.StakeholderEmailList() : emailList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
return controller.executeActionInsideJSNode(PHICoreController.default.fullValidation_EmailList$Action.bind(controller, emailList_HandlerIn, countRecord_HandlerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
EmailList_Handler_Out: actionResults.emailList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
hasError_EmailList: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasError_EmailListOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$FullValidation_PhoneList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$StakeholderPhoneList", "PHICore.model$ContactDetail_CountRec", "PHICore.model$ContactDetails_SettingsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.fullValidation_PhoneList$Action = function (phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_PhoneList$vars"))());
vars.value.phoneList_HandlerInLocal = phoneList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
vars.value.contactDetailSettingInLocal = contactDetailSettingIn.clone();
vars.value.stakeholderTypeIdInLocal = stakeholderTypeIdIn;
vars.value.isContributorInLocal = isContributorIn;
var listFilterVar = new OS.DataTypes.VariableHolder();
var listDuplicate_isPreferredVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.FullValidation_PhoneList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilterVar = listFilterVar;
varBag.listDuplicate_isPreferredVar = listDuplicate_isPreferredVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:wWQwmsVFo0ec_sBGjb8Z+w:/ClientActionFlows.wWQwmsVFo0ec_sBGjb8Z+w:y8y2wvRZa_qSh1a4mJp7_A", "PHICore", "FullValidation_PhoneList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CMReav6u80ue2SqKPfcbIA", callContext.id);
// CountRecord_Handler
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5mGggf2UoE+2tDrOAkkmJg", callContext.id);
// CountRecord_Handler.PhoneBusinessCount = 0
vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5mGggf2UoE+2tDrOAkkmJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler.PhoneHomeCount = 0
vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5mGggf2UoE+2tDrOAkkmJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountRecord_Handler.PhoneMobileCount = 0
vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5mGggf2UoE+2tDrOAkkmJg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// ErrorMessage = ""
outVars.value.errorMessageOut = "";
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WT8TlDY5NUWyj6kgphR2Kg", callContext.id) && vars.value.phoneList_HandlerInLocal.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BUgaX+LnHUq+XXNvcdwPBg", callContext.id);
// hasError_PhoneList = If
outVars.value.hasError_PhoneListOut = ((((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.lead) || ((vars.value.stakeholderTypeIdInLocal === PHICoreModel.staticEntities.stakeholderType.nonInsured) && vars.value.isContributorInLocal))) ? (false) : (true));
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kwUU42XVW0q4VUigpYEt2Q", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(vars.value.phoneList_HandlerInLocal, function (p) {
return p.isPreferredAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j6f55avy4E2Br1t5XpGP7g", callContext.id);
// Execute Action: ListDuplicate_isPreferred
listDuplicate_isPreferredVar.value = OS.SystemActions.listDuplicate(listFilterVar.value.filteredListOut, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dvyoaaxCTkqSk4sFqH5xAw", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(listDuplicate_isPreferredVar.value.duplicatedListOut, function (p) {
return p.lastUpdatedOnAttr;
}, false, callContext);
// Foreach PhoneList_Handler
callContext.iterationContext.registerIterationStart(vars.value.phoneList_HandlerInLocal);
try {var phoneList_HandlerIterator = callContext.iterationContext.getIterator(vars.value.phoneList_HandlerInLocal);
var phoneList_HandlerIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nO6vPTOcs0+sS6W397VpRw", callContext.id) && (phoneList_HandlerIndex < vars.value.phoneList_HandlerInLocal.length))) {
phoneList_HandlerIterator.currentRowNumber = phoneList_HandlerIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XRHTI+OHvUGOqOE_Utd8vg", callContext.id);
// PhoneList_Handler.Current.typeError = ""
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XRHTI+OHvUGOqOE_Utd8vg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PhoneList_Handler.Current.phoneNumberError = ""
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).phoneNumberErrorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XRHTI+OHvUGOqOE_Utd8vg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PhoneList_Handler.Current.isPreferred_Error = ""
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).isPreferred_ErrorAttr = "";
// no phone type
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G4tSrk6x8kSdkO2WHWtuoQ", callContext.id) && (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gEE+fRLJw0qmn_GyIsujGg", callContext.id);
// PhoneList_Handler.Current.typeError = GetRequiredFieldMsg()
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gEE+fRLJw0qmn_GyIsujGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = True
outVars.value.hasError_PhoneListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gEE+fRLJw0qmn_GyIsujGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
} else {
// no phone number
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dcdjPg9ePEWthQE8qg_b8g", callContext.id) && (((OS.BuiltinFunctions.trim(vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).phoneNumberAttr) === "") || (OS.BuiltinFunctions.length(vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).phoneNumberAttr) === 0)) || (OS.BuiltinFunctions.trim(vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).phoneNumberAttr) === "0")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dGAWk71xWUmSycYITeD_Xg", callContext.id);
// PhoneList_Handler.Current.phoneNumberError = GetRequiredFieldMsg()
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).phoneNumberErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.PhoneNumber, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dGAWk71xWUmSycYITeD_Xg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = True
outVars.value.hasError_PhoneListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dGAWk71xWUmSycYITeD_Xg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cBl77iGShUarG5RrcAwW7w", callContext.id) && listFilterVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Yu3Mc6Xx0ayyjKmtZYCIQ", callContext.id);
// PhoneList_Handler.Current.isPreferred_Error = "One preferred should be selected."
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).isPreferred_ErrorAttr = "One preferred should be selected.";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Yu3Mc6Xx0ayyjKmtZYCIQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = True
outVars.value.hasError_PhoneListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Yu3Mc6Xx0ayyjKmtZYCIQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PhoneList_Handler.Current.isPreferred = False
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).isPreferredAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Yu3Mc6Xx0ayyjKmtZYCIQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
} else {
// if isPreferred and is more than 1
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hP8D4HDjYEuZyeGKieuF4Q", callContext.id) && (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).isPreferredAttr && (listFilterVar.value.filteredListOut.length > 1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vHWp5VXBFkmEQ41uoHh1bw", callContext.id);
// PhoneList_Handler.Current.isPreferred_Error = "Only one preferred should be selected."
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).isPreferred_ErrorAttr = "Only one preferred should be selected.";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vHWp5VXBFkmEQ41uoHh1bw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = True
outVars.value.hasError_PhoneListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vHWp5VXBFkmEQ41uoHh1bw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

}

// No Country Code
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gaq+QBGnuUWhuCITCGGUyw", callContext.id) && vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).countryCodeAttr.idAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h_H2X7hLV0K_vgTan4O9cg", callContext.id);
// PhoneList_Handler.Current.CountryCode.Error = GetRequiredFieldMsg()
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).countryCodeAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h_H2X7hLV0K_vgTan4O9cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = True
outVars.value.hasError_PhoneListOut = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h_H2X7hLV0K_vgTan4O9cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// hasMandatoryFieldError = True
vars.value.hasMandatoryFieldErrorVar = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sH64Soo32UaruRLkR22gww", callContext.id);
// CountRecord_Handler.PhoneBusinessCount = If
vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr = (((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Business")) ? ((vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sH64Soo32UaruRLkR22gww", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler.PhoneHomeCount = If
vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr = (((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Home")) ? ((vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sH64Soo32UaruRLkR22gww", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CountRecord_Handler.PhoneMobileCount = If
vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr = (((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Mobile")) ? ((vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr + 1)) : (vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VmnHIJmQi023XlUu2HS3pA", callContext.id);
// PhoneList_Handler.Current.typeError = If
vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr = (((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Business")) ? ((((vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr > vars.value.contactDetailSettingInLocal.phoneBusinessAttr)) ? ((("Max of " + (vars.value.contactDetailSettingInLocal.phoneBusinessAttr).toString()) + " business phone types are allowed")) : (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr))) : ((((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Home")) ? ((((vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr > vars.value.contactDetailSettingInLocal.phoneHomeAttr)) ? ((("Max of " + (vars.value.contactDetailSettingInLocal.phoneHomeAttr).toString()) + " home phone type is allowed")) : (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr))) : ((((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeAttr === "Mobile")) ? ((((vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr > vars.value.contactDetailSettingInLocal.phoneMobileAttr)) ? ((("Max of " + (vars.value.contactDetailSettingInLocal.phoneMobileAttr).toString()) + " mobile phone types are allowed")) : (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr))) : (vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr))))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VmnHIJmQi023XlUu2HS3pA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError_PhoneList = If
outVars.value.hasError_PhoneListOut = ((outVars.value.hasError_PhoneListOut) ? (outVars.value.hasError_PhoneListOut) : (((vars.value.phoneList_HandlerInLocal.getItem(phoneList_HandlerIndex.valueOf()).typeErrorAttr) !== (""))));
}

phoneList_HandlerIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.phoneList_HandlerInLocal);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5zSj5C60lE26JPqlosNMhA", callContext.id);
// PhoneList_Handler_Out = PhoneList_Handler
outVars.value.phoneList_Handler_OutOut = vars.value.phoneList_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5zSj5C60lE26JPqlosNMhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CountRecord_Handler_Out = CountRecord_Handler
outVars.value.countRecord_Handler_OutOut = vars.value.countRecord_HandlerInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5zSj5C60lE26JPqlosNMhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// ErrorMessage = If
outVars.value.errorMessageOut = ((vars.value.hasMandatoryFieldErrorVar) ? ("") : ((((vars.value.countRecord_HandlerInLocal.phoneBusinessCountAttr > vars.value.contactDetailSettingInLocal.phoneBusinessAttr)) ? ("Max of two business phone types are allowed") : ((((vars.value.countRecord_HandlerInLocal.phoneHomeCountAttr > vars.value.contactDetailSettingInLocal.phoneHomeAttr)) ? ("Max of one home phone type is allowed") : ((((vars.value.countRecord_HandlerInLocal.phoneMobileCountAttr > vars.value.contactDetailSettingInLocal.phoneMobileAttr)) ? ("Max of two mobile phone types are allowed") : (((outVars.value.hasError_PhoneListOut) ? ("Required field") : (""))))))))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zfBzRcunZEe+mk1V+cub+Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:wWQwmsVFo0ec_sBGjb8Z+w", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_PhoneList$vars", [{
name: "PhoneList_Handler",
attrName: "phoneList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "ContactDetailSetting",
attrName: "contactDetailSettingInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_SettingsRec();
},
complexType: PHICoreModel.ContactDetails_SettingsRec
}, {
name: "StakeholderTypeId",
attrName: "stakeholderTypeIdInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsContributor",
attrName: "isContributorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "hasMandatoryFieldError",
attrName: "hasMandatoryFieldErrorVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.FullValidation_PhoneList$outVars", [{
name: "PhoneList_Handler_Out",
attrName: "phoneList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "hasError_PhoneList",
attrName: "hasError_PhoneListOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.fullValidation_PhoneList$Action = function (phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, isContributorIn) {
phoneList_HandlerIn = (phoneList_HandlerIn === undefined) ? new PHICoreModel.StakeholderPhoneList() : phoneList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
contactDetailSettingIn = (contactDetailSettingIn === undefined) ? new PHICoreModel.ContactDetails_SettingsRec() : contactDetailSettingIn;
stakeholderTypeIdIn = (stakeholderTypeIdIn === undefined) ? 0 : stakeholderTypeIdIn;
isContributorIn = (isContributorIn === undefined) ? false : isContributorIn;
return controller.executeActionInsideJSNode(PHICoreController.default.fullValidation_PhoneList$Action.bind(controller, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, stakeholderTypeIdIn, OS.DataConversion.JSNodeParamConverter.from(isContributorIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PhoneList_Handler_Out: actionResults.phoneList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
hasError_PhoneList: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasError_PhoneListOut, OS.Types.Boolean),
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$Get_StakeholderType", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.controller$ServerAction.GetStakeholder_Type"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.get_StakeholderType$Action = function (stakeholderType_NameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Get_StakeholderType$vars"))());
vars.value.stakeholderType_NameInLocal = stakeholderType_NameIn;
var getStakeholder_TypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Get_StakeholderType$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getStakeholder_TypeVar = getStakeholder_TypeVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:7moeA7iKk0Sp8nfooPpXAQ:/ClientActionFlows.7moeA7iKk0Sp8nfooPpXAQ:S1U6cB4iIUy39bBZn59VRQ", "PHICore", "Get_StakeholderType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WY+cDy_s0ke8dIT3I3HdcA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zl4MSosTyEyEIqmWG68kaw", callContext.id);
// Execute Action: GetStakeholder_Type
return controller.getStakeholder_Type$ServerAction(vars.value.stakeholderType_NameInLocal, callContext).then(function (value) {
getStakeholder_TypeVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o9UCz_A4JkuoSN0bo896Pg", callContext.id);
// StakeholderTypeId = GetStakeholder_Type.StakeholderTypeId
outVars.value.stakeholderTypeIdOut = getStakeholder_TypeVar.value.stakeholderTypeIdOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rU1WPBbthEKiaa7fOwV5iw", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:7moeA7iKk0Sp8nfooPpXAQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:7moeA7iKk0Sp8nfooPpXAQ", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Get_StakeholderType$vars", [{
name: "StakeholderType_Name",
attrName: "stakeholderType_NameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Get_StakeholderType$outVars", [{
name: "StakeholderTypeId",
attrName: "stakeholderTypeIdOut",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
PHICoreController.default.clientActionProxies.get_StakeholderType$Action = function (stakeholderType_NameIn) {
stakeholderType_NameIn = (stakeholderType_NameIn === undefined) ? "" : stakeholderType_NameIn;
return controller.executeActionInsideJSNode(PHICoreController.default.get_StakeholderType$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stakeholderType_NameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
StakeholderTypeId: actionResults.stakeholderTypeIdOut
};
});
};
});

define("PHICore.controller$GetAge", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getAge$Action = function (dOBIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetAge$vars"))());
vars.value.dOBInLocal = dOBIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetAge$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:QSMYY2HPjUG66ng7IS_lLA:/ClientActionFlows.QSMYY2HPjUG66ng7IS_lLA:yIS+AIDiQFYOwrYNQd+zEw", "PHICore", "GetAge", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ejz0qe+2ykqe+Bg41tat3Q", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mct+AIXRVUqaaBNm9+XnnQ", callContext.id) && vars.value.dOBInLocal.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Mdlv+2HOXUq1wbpA3MWrHA", callContext.id);
} else {
// SetAgeAsYearDiff
do {
// SetAgeAsYearDiff
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1pSA2dlsUkaOjCH091rq4A", callContext.id);
// Age = Year - Year
outVars.value.ageOut = (OS.BuiltinFunctions.year(OS.BuiltinFunctions.currDate()) - OS.BuiltinFunctions.year(vars.value.dOBInLocal));
// MonthsAway?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7w0m6e3VsEO47CQCj_j09A", callContext.id) && !((OS.BuiltinFunctions.month(OS.BuiltinFunctions.currDate()) < OS.BuiltinFunctions.month(vars.value.dOBInLocal))))) {
// DaysAway?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_TZhSKxVI0uRc5uZqlcDqg", callContext.id) && !(((OS.BuiltinFunctions.month(OS.BuiltinFunctions.currDate()) === OS.BuiltinFunctions.month(vars.value.dOBInLocal)) && (OS.BuiltinFunctions.day(OS.BuiltinFunctions.currDate()) < OS.BuiltinFunctions.day(vars.value.dOBInLocal)))))) {
break;
}

}

// DescrementAge
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+5f4lVn7MEWO+7O6o+tB+A", callContext.id);
// Age = Age - 1
outVars.value.ageOut = (outVars.value.ageOut - 1);
} while(false)
;
// Negative?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S+EvroURnUebpLTR+0_A2g", callContext.id) && (outVars.value.ageOut < 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MhO4JvVxpUSakF1DBH3suA", callContext.id);
// Age = 0
outVars.value.ageOut = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C1eMIYsMFUqX8PS6jjQswQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C1eMIYsMFUqX8PS6jjQswQ", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:QSMYY2HPjUG66ng7IS_lLA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetAge$vars", [{
name: "DOB",
attrName: "dOBInLocal",
mandatory: true,
dataType: OS.Types.Date,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetAge$outVars", [{
name: "Age",
attrName: "ageOut",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
PHICoreController.default.clientActionProxies.getAge$Action = function (dOBIn) {
dOBIn = (dOBIn === undefined) ? OS.DataTypes.DateTime.defaultValue : dOBIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getAge$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dOBIn, OS.Types.Date)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Age: OS.DataConversion.JSNodeParamConverter.to(actionResults.ageOut, OS.Types.Integer)
};
});
};
});

define("PHICore.controller$GetBasicDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "Stakeholder_CS.model", "APIGateway_IS.model", "PHICore.clientVariables", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$SearchResultItemList", "PHICore.model$ReferenceDataList", "Stakeholder_CS.model$ReferenceDataBasicStrucRec", "PHICore.referencesHealth$Stakeholder_CS", "APIGateway_IS.model$SearchResultItemRec", "PHICore.referencesHealth$APIGateway_IS", "PHICore.model$BasicDetailsRec", "APIGateway_IS.model$SearchIndividuals_APIResponseRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, Stakeholder_CSModel, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getBasicDetails$Action = function (policyBasicDetailsIn, eligibilityReasonListIn, eligibilitySubReasonListIn, coverListIn, classListIn, stateListIn, residencyListIn, groupListIn, branchListIn, agentListIn, locationListIn, siteListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetBasicDetails$vars"))());
vars.value.policyBasicDetailsInLocal = policyBasicDetailsIn.clone();
vars.value.eligibilityReasonListInLocal = eligibilityReasonListIn.clone();
vars.value.eligibilitySubReasonListInLocal = eligibilitySubReasonListIn.clone();
vars.value.coverListInLocal = coverListIn.clone();
vars.value.classListInLocal = classListIn.clone();
vars.value.stateListInLocal = stateListIn.clone();
vars.value.residencyListInLocal = residencyListIn.clone();
vars.value.groupListInLocal = groupListIn.clone();
vars.value.branchListInLocal = branchListIn.clone();
vars.value.agentListInLocal = agentListIn.clone();
vars.value.locationListInLocal = locationListIn.clone();
vars.value.siteListInLocal = siteListIn.clone();
var group_ListVar = new OS.DataTypes.VariableHolder();
var getClassListVar = new OS.DataTypes.VariableHolder();
var locationVar = new OS.DataTypes.VariableHolder();
var agent_ListVar = new OS.DataTypes.VariableHolder();
var site_ListVar = new OS.DataTypes.VariableHolder();
var class_ListVar = new OS.DataTypes.VariableHolder();
var eligibilityReasonVar = new OS.DataTypes.VariableHolder();
var eligibilitySubReasonVar = new OS.DataTypes.VariableHolder();
var getCover_ByClassParentCodeVar = new OS.DataTypes.VariableHolder();
var residency_ListVar = new OS.DataTypes.VariableHolder();
var branch_ListVar = new OS.DataTypes.VariableHolder();
var cover_ListVar = new OS.DataTypes.VariableHolder();
var state_ListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetBasicDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.group_ListVar = group_ListVar;
varBag.getClassListVar = getClassListVar;
varBag.locationVar = locationVar;
varBag.agent_ListVar = agent_ListVar;
varBag.site_ListVar = site_ListVar;
varBag.class_ListVar = class_ListVar;
varBag.eligibilityReasonVar = eligibilityReasonVar;
varBag.eligibilitySubReasonVar = eligibilitySubReasonVar;
varBag.getCover_ByClassParentCodeVar = getCover_ByClassParentCodeVar;
varBag.residency_ListVar = residency_ListVar;
varBag.branch_ListVar = branch_ListVar;
varBag.cover_ListVar = cover_ListVar;
varBag.state_ListVar = state_ListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:eRMhc2581kWG_tSiXhmPAQ:/ClientActionFlows.eRMhc2581kWG_tSiXhmPAQ:QRQJAMmcj_bTW8vMHVALmw", "PHICore", "GetBasicDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4DaOACMwC0+vA8TP4k0www", callContext.id);
do {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BD+hvxaCZEWFisQqydSh3g", callContext.id);
// Execute Action: EligibilityReason
eligibilityReasonVar.value = OS.SystemActions.listFilter(vars.value.eligibilityReasonListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.eligibilityReasonAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o+C7hxkru0CAOGx1WRrcYw", callContext.id) && !(eligibilityReasonVar.value.filteredListOut.isEmpty))) {
// EligibilityReason
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zmsNZC2f90GNQB+dyQMR0g", callContext.id);
// PolicyBasicDetails.EligibilityReason = EligibilityReason.FilteredList.Current
vars.value.policyBasicDetailsInLocal.eligibilityReasonAttr = eligibilityReasonVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:P6Oqz4vgPU+LZWE6VIFoqg", callContext.id);
// Execute Action: EligibilitySubReason
eligibilitySubReasonVar.value = OS.SystemActions.listFilter(vars.value.eligibilitySubReasonListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.eligibilitySubReasonAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lTqnOB08qkyOuDol8SYuPg", callContext.id) && !(eligibilitySubReasonVar.value.filteredListOut.isEmpty))) {
// EligibilitySubReason
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6RlzrVr2nUeVffjrBo33oQ", callContext.id);
// PolicyBasicDetails.EligibilitySubReason = EligibilitySubReason.FilteredList.Current
vars.value.policyBasicDetailsInLocal.eligibilitySubReasonAttr = eligibilitySubReasonVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// Not Null Class Id
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+Y3Ovj56sUyyc3gIL7nDjg", callContext.id) && ((vars.value.policyBasicDetailsInLocal.classAttr.codeAttr) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3bzFML6wikGhTvMi+CwVAA", callContext.id);
// Execute Action: GetClassList
getClassListVar.value = OS.SystemActions.listFilter(vars.value.classListInLocal, function (p) {
return ((p.codeAttr === vars.value.policyBasicDetailsInLocal.classAttr.codeAttr) || (p.nameAttr === vars.value.policyBasicDetailsInLocal.classAttr.codeAttr));
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CMvJamZc1k6u3oRJJTbD_w", callContext.id) && !(getClassListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NlG840O8zkKgnpB0CAU5tQ", callContext.id);
// Execute Action: GetCover_ByClassParentCode
getCover_ByClassParentCodeVar.value = OS.SystemActions.listFilter(vars.value.coverListInLocal, function (p) {
return (p.codeAttr === getClassListVar.value.filteredListOut.getCurrent(callContext.iterationContext).parentEntityCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BaxdiNQT90K_k1Obr8wHeA", callContext.id) && !(getCover_ByClassParentCodeVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cVJmfTZzvUSXl3nuoBG9fg", callContext.id);
// PolicyBasicDetails.Cover = GetCover_ByClassParentCode.FilteredList.Current
vars.value.policyBasicDetailsInLocal.coverAttr = getCover_ByClassParentCodeVar.value.filteredListOut.getCurrent(callContext.iterationContext);
break;
}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ak6g+ICm10ywY3hJtJ_2zA", callContext.id);
// Execute Action: Cover_List
cover_ListVar.value = OS.SystemActions.listFilter(vars.value.coverListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.coverAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lLfcQMUzvEGT_KR+fhQfcQ", callContext.id) && !(cover_ListVar.value.filteredListOut.isEmpty))) {
// Cover
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sAwEa5OoP0KVJPKwYEsd6w", callContext.id);
// PolicyBasicDetails.Cover = Cover_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.coverAttr = cover_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

} while(false)
;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XKrrubCOvk6bakktxdI6sg", callContext.id);
// Execute Action: Class_List
class_ListVar.value = OS.SystemActions.listFilter(vars.value.classListInLocal, function (p) {
return ((p.codeAttr === vars.value.policyBasicDetailsInLocal.classAttr.codeAttr) || (p.nameAttr === vars.value.policyBasicDetailsInLocal.classAttr.codeAttr));
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cDiCGyLA0ESS72Ki7xub4g", callContext.id) && !(class_ListVar.value.filteredListOut.isEmpty))) {
// Class
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gErni+Wye0mRuO+EyuslPw", callContext.id);
// PolicyBasicDetails.Class = Class_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.classAttr = class_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G3Pt+ugsyEqO3tgERQoiEg", callContext.id);
// Execute Action: State_List
state_ListVar.value = OS.SystemActions.listFilter(vars.value.stateListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.stateAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MUsEJ4CImkSy0RCisWyyow", callContext.id) && !(state_ListVar.value.filteredListOut.isEmpty))) {
// State
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zLmrmix2DkuR5pEJlFFP2g", callContext.id);
// PolicyBasicDetails.State = State_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.stateAttr = state_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QIQE6BzE4U2eWhnZEL4B_g", callContext.id);
// Execute Action: Residency_List
residency_ListVar.value = OS.SystemActions.listFilter(vars.value.residencyListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.residencyAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j0GDezb1_0mwKvtc6AhX5w", callContext.id) && !(residency_ListVar.value.filteredListOut.isEmpty))) {
// Residency
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vn6nIcVfo0SNm2hmR5F2Mg", callContext.id);
// PolicyBasicDetails.Residency = Residency_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.residencyAttr = residency_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Xz9xLEWoTUOqlEHcgKQMxA", callContext.id);
// Execute Action: Group_List
group_ListVar.value = OS.SystemActions.listFilter(vars.value.groupListInLocal.resultAttr, function (p) {
return (p.stakeholderIdAttr === vars.value.policyBasicDetailsInLocal.groupAttr.stakeholderIdAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aOUba1v+3E+1BNBW4Yjp2w", callContext.id) && !(group_ListVar.value.filteredListOut.isEmpty))) {
// Group
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DMYj+uO4lUyYLNqtoq2PSQ", callContext.id);
// PolicyBasicDetails.Group = Group_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.groupAttr = group_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7WmI6fSEEUiKYZP_8GSI5Q", callContext.id);
// Execute Action: Branch_List
branch_ListVar.value = OS.SystemActions.listFilter(vars.value.branchListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.branchAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3Luwsl1kM0COO3xnN+nU+w", callContext.id) && !(branch_ListVar.value.filteredListOut.isEmpty))) {
// Branch
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XDubs9CcoUWP2dKdRjFbig", callContext.id);
// PolicyBasicDetails.Branch = Branch_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.branchAttr = OS.DataConversion.JSConversions.typeConvertRecord(branch_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext), new Stakeholder_CSModel.ReferenceDataBasicStrucRec(), function (source, target) {
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JdECUqEfQUGRmbGFfLdXIA", callContext.id);
// Execute Action: Agent_List
agent_ListVar.value = OS.SystemActions.listFilter(vars.value.agentListInLocal.resultAttr, function (p) {
return (p.stakeholderIdAttr === vars.value.policyBasicDetailsInLocal.agentAttr.stakeholderIdAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3j8KR7ft70K4Hh4+0kcRtA", callContext.id) && !(agent_ListVar.value.filteredListOut.isEmpty))) {
// Agent
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hLiaqVdFeEOfrhCUnPdaCQ", callContext.id);
// PolicyBasicDetails.Agent = Agent_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.agentAttr = agent_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eHh5OJoLZEuKPbtctJaSDA", callContext.id);
// Execute Action: Location
locationVar.value = OS.SystemActions.listFilter(vars.value.locationListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.locationAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vL+l9sSBDkuRNrtkWS0vOQ", callContext.id) && !(locationVar.value.filteredListOut.isEmpty))) {
// Location
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9PxUMqppak+B8Y81WshZnA", callContext.id);
// PolicyBasicDetails.Location = Location.FilteredList.Current
vars.value.policyBasicDetailsInLocal.locationAttr = OS.DataConversion.JSConversions.typeConvertRecord(locationVar.value.filteredListOut.getCurrent(callContext.iterationContext), new Stakeholder_CSModel.ReferenceDataBasicStrucRec(), function (source, target) {
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ha8GkdlfaEqHyjMQ5k65AA", callContext.id);
// Execute Action: Site_List
site_ListVar.value = OS.SystemActions.listFilter(vars.value.siteListInLocal, function (p) {
return (p.codeAttr === vars.value.policyBasicDetailsInLocal.siteAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kI_fcGi6VUq8eieFckNAkg", callContext.id) && !(site_ListVar.value.filteredListOut.isEmpty))) {
// Site
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iguzltIM7ESTiXV8e47l3w", callContext.id);
// PolicyBasicDetails.Site = Site_List.FilteredList.Current
vars.value.policyBasicDetailsInLocal.siteAttr = OS.DataConversion.JSConversions.typeConvertRecord(site_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext), new Stakeholder_CSModel.ReferenceDataBasicStrucRec(), function (source, target) {
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pNrT0MbVn06Oa3uK0iIKwQ", callContext.id);
// BasicDetails = PolicyBasicDetails
outVars.value.basicDetailsOut = vars.value.policyBasicDetailsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Kqh5Km0XgEuzxKYvhuat7w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:eRMhc2581kWG_tSiXhmPAQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetBasicDetails$vars", [{
name: "PolicyBasicDetails",
attrName: "policyBasicDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.BasicDetailsRec();
},
complexType: PHICoreModel.BasicDetailsRec
}, {
name: "EligibilityReasonList",
attrName: "eligibilityReasonListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "EligibilitySubReasonList",
attrName: "eligibilitySubReasonListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "CoverList",
attrName: "coverListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "ClassList",
attrName: "classListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "StateList",
attrName: "stateListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "ResidencyList",
attrName: "residencyListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GroupList",
attrName: "groupListInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.SearchIndividuals_APIResponseRec();
},
complexType: APIGateway_ISModel.SearchIndividuals_APIResponseRec
}, {
name: "BranchList",
attrName: "branchListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "AgentList",
attrName: "agentListInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.SearchIndividuals_APIResponseRec();
},
complexType: APIGateway_ISModel.SearchIndividuals_APIResponseRec
}, {
name: "LocationList",
attrName: "locationListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "SiteList",
attrName: "siteListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetBasicDetails$outVars", [{
name: "BasicDetails",
attrName: "basicDetailsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.BasicDetailsRec();
},
complexType: PHICoreModel.BasicDetailsRec
}]);
PHICoreController.default.clientActionProxies.getBasicDetails$Action = function (policyBasicDetailsIn, eligibilityReasonListIn, eligibilitySubReasonListIn, coverListIn, classListIn, stateListIn, residencyListIn, groupListIn, branchListIn, agentListIn, locationListIn, siteListIn) {
policyBasicDetailsIn = (policyBasicDetailsIn === undefined) ? new PHICoreModel.BasicDetailsRec() : policyBasicDetailsIn;
eligibilityReasonListIn = (eligibilityReasonListIn === undefined) ? new PHICoreModel.ReferenceDataList() : eligibilityReasonListIn;
eligibilitySubReasonListIn = (eligibilitySubReasonListIn === undefined) ? new PHICoreModel.ReferenceDataList() : eligibilitySubReasonListIn;
coverListIn = (coverListIn === undefined) ? new PHICoreModel.ReferenceDataList() : coverListIn;
classListIn = (classListIn === undefined) ? new PHICoreModel.ReferenceDataList() : classListIn;
stateListIn = (stateListIn === undefined) ? new PHICoreModel.ReferenceDataList() : stateListIn;
residencyListIn = (residencyListIn === undefined) ? new PHICoreModel.ReferenceDataList() : residencyListIn;
groupListIn = (groupListIn === undefined) ? new APIGateway_ISModel.SearchIndividuals_APIResponseRec() : groupListIn;
branchListIn = (branchListIn === undefined) ? new PHICoreModel.ReferenceDataList() : branchListIn;
agentListIn = (agentListIn === undefined) ? new APIGateway_ISModel.SearchIndividuals_APIResponseRec() : agentListIn;
locationListIn = (locationListIn === undefined) ? new PHICoreModel.ReferenceDataList() : locationListIn;
siteListIn = (siteListIn === undefined) ? new PHICoreModel.ReferenceDataList() : siteListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getBasicDetails$Action.bind(controller, policyBasicDetailsIn, eligibilityReasonListIn, eligibilitySubReasonListIn, coverListIn, classListIn, stateListIn, residencyListIn, groupListIn, branchListIn, agentListIn, locationListIn, siteListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
BasicDetails: actionResults.basicDetailsOut
};
});
};
});

define("PHICore.controller$GetCommunicationPreferenceDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "PHICore.clientVariables", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$ReferenceDataList", "PHICore.model$PolicyCommunicationPreferenceDetailsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getCommunicationPreferenceDetails$Action = function (communicationPreferenceListIn, communicationPreferenceDetailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetCommunicationPreferenceDetails$vars"))());
vars.value.communicationPreferenceListInLocal = communicationPreferenceListIn.clone();
vars.value.communicationPreferenceDetailsInLocal = communicationPreferenceDetailsIn.clone();
var legislativeCommunicationsVar = new OS.DataTypes.VariableHolder();
var claimsInformationVar = new OS.DataTypes.VariableHolder();
var fundInformationVar = new OS.DataTypes.VariableHolder();
var stakeholderPolicyUpdateVar = new OS.DataTypes.VariableHolder();
var marketingVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetCommunicationPreferenceDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.legislativeCommunicationsVar = legislativeCommunicationsVar;
varBag.claimsInformationVar = claimsInformationVar;
varBag.fundInformationVar = fundInformationVar;
varBag.stakeholderPolicyUpdateVar = stakeholderPolicyUpdateVar;
varBag.marketingVar = marketingVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:i5iociq_kE6VAsJGxv01Ag:/ClientActionFlows.i5iociq_kE6VAsJGxv01Ag:OPGRi1M4BzOHaJoRKpvBvQ", "PHICore", "GetCommunicationPreferenceDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pw7338EcdEGlVvj0ieRC7w", callContext.id);
// StakeholderPolicyUpdate = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ck932MNUVE6w4OP_uzgGYw", callContext.id) && !((vars.value.communicationPreferenceDetailsInLocal.stakeholderPolicyUpdateAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qV+jsFpqL02I_2AFeriMeQ", callContext.id);
// Execute Action: StakeholderPolicyUpdate
stakeholderPolicyUpdateVar.value = OS.SystemActions.listFilter(vars.value.communicationPreferenceListInLocal, function (p) {
return (OS.BuiltinFunctions.toLower(p.codeAttr) === OS.BuiltinFunctions.toLower(vars.value.communicationPreferenceDetailsInLocal.stakeholderPolicyUpdateAttr.codeAttr));
}, callContext);

// StakeholderPolicyUpdate
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1clkPqmvTkqnD6Txubwahg", callContext.id);
// Details.StakeholderPolicyUpdate = StakeholderPolicyUpdate.FilteredList.Current
outVars.value.detailsOut.stakeholderPolicyUpdateAttr = stakeholderPolicyUpdateVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// ClaimsInformation = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gOJJtXAfJU+fJZpo5GJrfg", callContext.id) && !((vars.value.communicationPreferenceDetailsInLocal.claimsInformationAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nvwxixfQCUKw49TR+uD9FQ", callContext.id);
// Execute Action: ClaimsInformation
claimsInformationVar.value = OS.SystemActions.listFilter(vars.value.communicationPreferenceListInLocal, function (p) {
return (OS.BuiltinFunctions.toLower(p.codeAttr) === OS.BuiltinFunctions.toLower(vars.value.communicationPreferenceDetailsInLocal.claimsInformationAttr.codeAttr));
}, callContext);

// ClaimsInformation
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BXaXq78FAESw54DqE2Hyuw", callContext.id);
// Details.ClaimsInformation = ClaimsInformation.FilteredList.Current
outVars.value.detailsOut.claimsInformationAttr = claimsInformationVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// FundInformation = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rFbwJ9UJZUeHsMlnHtMGgQ", callContext.id) && !((vars.value.communicationPreferenceDetailsInLocal.fundInformationAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:agrYjTiitUWMXFLhSn8bRg", callContext.id);
// Execute Action: FundInformation
fundInformationVar.value = OS.SystemActions.listFilter(vars.value.communicationPreferenceListInLocal, function (p) {
return (OS.BuiltinFunctions.toLower(p.codeAttr) === OS.BuiltinFunctions.toLower(vars.value.communicationPreferenceDetailsInLocal.fundInformationAttr.codeAttr));
}, callContext);

// FundInformation
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:66UJJs9fEEO500s3rfmgwg", callContext.id);
// Details.FundInformation = FundInformation.FilteredList.Current
outVars.value.detailsOut.fundInformationAttr = fundInformationVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// LegislativeCommunications = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RfjE4zOjMkyfeIhwQRWd+Q", callContext.id) && !((vars.value.communicationPreferenceDetailsInLocal.legislativeCommunicationsAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:linjaCkSNk6XtOUPK+3Kbg", callContext.id);
// Execute Action: LegislativeCommunications
legislativeCommunicationsVar.value = OS.SystemActions.listFilter(vars.value.communicationPreferenceListInLocal, function (p) {
return (OS.BuiltinFunctions.toLower(p.codeAttr) === OS.BuiltinFunctions.toLower(vars.value.communicationPreferenceDetailsInLocal.legislativeCommunicationsAttr.codeAttr));
}, callContext);

// LegislativeCommunications
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VdLz5de0DkGLn9ZXqGm4Wg", callContext.id);
// Details.LegislativeCommunications = LegislativeCommunications.FilteredList.Current
outVars.value.detailsOut.legislativeCommunicationsAttr = legislativeCommunicationsVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// Marketing = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aY_f4UEmZUqRHXgRJmRlVA", callContext.id) && (vars.value.communicationPreferenceDetailsInLocal.marketingAttr.codeAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EVexGnwu6kafotREVsi6Kg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q4xD_IfLN0C6sG241gl4vA", callContext.id);
// Execute Action: Marketing
marketingVar.value = OS.SystemActions.listFilter(vars.value.communicationPreferenceListInLocal, function (p) {
return (OS.BuiltinFunctions.toLower(p.codeAttr) === OS.BuiltinFunctions.toLower(vars.value.communicationPreferenceDetailsInLocal.marketingAttr.codeAttr));
}, callContext);

// Marketing
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zgM70RycpE2ieQtGz+e1OQ", callContext.id);
// Details.Marketing = Marketing.FilteredList.Current
outVars.value.detailsOut.marketingAttr = marketingVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DRvK5zKW3UamrLi_rXH_TA", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:i5iociq_kE6VAsJGxv01Ag", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetCommunicationPreferenceDetails$vars", [{
name: "CommunicationPreferenceList",
attrName: "communicationPreferenceListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "CommunicationPreferenceDetails",
attrName: "communicationPreferenceDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyCommunicationPreferenceDetailsRec();
},
complexType: PHICoreModel.PolicyCommunicationPreferenceDetailsRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetCommunicationPreferenceDetails$outVars", [{
name: "Details",
attrName: "detailsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyCommunicationPreferenceDetailsRec();
},
complexType: PHICoreModel.PolicyCommunicationPreferenceDetailsRec
}]);
PHICoreController.default.clientActionProxies.getCommunicationPreferenceDetails$Action = function (communicationPreferenceListIn, communicationPreferenceDetailsIn) {
communicationPreferenceListIn = (communicationPreferenceListIn === undefined) ? new PHICoreModel.ReferenceDataList() : communicationPreferenceListIn;
communicationPreferenceDetailsIn = (communicationPreferenceDetailsIn === undefined) ? new PHICoreModel.PolicyCommunicationPreferenceDetailsRec() : communicationPreferenceDetailsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getCommunicationPreferenceDetails$Action.bind(controller, communicationPreferenceListIn, communicationPreferenceDetailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Details: actionResults.detailsOut
};
});
};
});

define("PHICore.controller$GetContactDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "PHICore.clientVariables", "PHICore.model$PolicyPhoneList", "PHICore.model$ReferenceDataList", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$ReferenceDataValidationRec", "PHICore.model$PolicyAddressList"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getContactDetails$Action = function (policyPhoneListIn, phoneTypeListIn, policyAddressListIn, addressTypeListIn, stateListIn, countryListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetContactDetails$vars"))());
vars.value.policyPhoneListInLocal = policyPhoneListIn.clone();
vars.value.phoneTypeListInLocal = phoneTypeListIn.clone();
vars.value.policyAddressListInLocal = policyAddressListIn.clone();
vars.value.addressTypeListInLocal = addressTypeListIn.clone();
vars.value.stateListInLocal = stateListIn.clone();
vars.value.countryListInLocal = countryListIn.clone();
var addressTypeVar = new OS.DataTypes.VariableHolder();
var countryVar = new OS.DataTypes.VariableHolder();
var stateVar = new OS.DataTypes.VariableHolder();
var phoneTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetContactDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.addressTypeVar = addressTypeVar;
varBag.countryVar = countryVar;
varBag.stateVar = stateVar;
varBag.phoneTypeVar = phoneTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:yEf1tfoPH0ml9XMC4zh_IQ:/ClientActionFlows.yEf1tfoPH0ml9XMC4zh_IQ:G0L4TWyrf0vrSGZkttfKpA", "PHICore", "GetContactDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4kRqaohfjEiINF_I+GkhtA", callContext.id);
// PrimaryMember_PhoneList
// Foreach PolicyPhoneList
callContext.iterationContext.registerIterationStart(vars.value.policyPhoneListInLocal);
try {var policyPhoneListIterator = callContext.iterationContext.getIterator(vars.value.policyPhoneListInLocal);
var policyPhoneListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p38FefUuU0ufGMAT2x3+tQ", callContext.id) && (policyPhoneListIndex < vars.value.policyPhoneListInLocal.length))) {
policyPhoneListIterator.currentRowNumber = policyPhoneListIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wNFo+09vj0O7xfad89YEsA", callContext.id);
// Execute Action: PhoneType
phoneTypeVar.value = OS.SystemActions.listFilter(vars.value.phoneTypeListInLocal, function (p) {
return (OS.BuiltinFunctions.index(vars.value.policyPhoneListInLocal.getItem(policyPhoneListIndex.valueOf()).phoneTypeAttr.codeAttr, p.codeAttr, 0, false, false) >= 0);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5DXrVeSdy0GhnSrUF93C6w", callContext.id);
// PolicyPhoneList.Current.PhoneType = PhoneType.FilteredList.Current
vars.value.policyPhoneListInLocal.getItem(policyPhoneListIndex.valueOf()).phoneTypeAttr = OS.DataConversion.JSConversions.typeConvertRecord(phoneTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
policyPhoneListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyPhoneListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6rCdEskJoUe4c68INAhuVw", callContext.id);
// PhoneList = PolicyPhoneList
outVars.value.phoneListOut = vars.value.policyPhoneListInLocal;
// PrimaryMember_AddressList
// Foreach PolicyAddressList
callContext.iterationContext.registerIterationStart(vars.value.policyAddressListInLocal);
try {var policyAddressListIterator = callContext.iterationContext.getIterator(vars.value.policyAddressListInLocal);
var policyAddressListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XOhTwxozyU6Vr5igil65kg", callContext.id) && (policyAddressListIndex < vars.value.policyAddressListInLocal.length))) {
policyAddressListIterator.currentRowNumber = policyAddressListIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:q_MTHIrQz0SZxDcohw1vfg", callContext.id);
// Execute Action: AddressType
addressTypeVar.value = OS.SystemActions.listFilter(vars.value.addressTypeListInLocal, function (p) {
return (OS.BuiltinFunctions.index(vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).addressTypeAttr.codeAttr, p.codeAttr, 0, false, false) >= 0);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:brAvU8bHqkCGD8lNuPZ7nQ", callContext.id);
// Execute Action: State
stateVar.value = OS.SystemActions.listFilter(vars.value.stateListInLocal, function (p) {
return (p.codeAttr === vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).stateAttr.codeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJYNRaAQMUaAP_kdkjhV1g", callContext.id);
// Execute Action: Country
countryVar.value = OS.SystemActions.listFilter(vars.value.countryListInLocal, function (p) {
return (p.codeAttr === vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).countryAttr.codeAttr);
}, callContext);

// Address
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id);
// PolicyAddressList.Current.AddressType.Id = AddressType.FilteredList.Current.Id
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).addressTypeAttr.idAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PolicyAddressList.Current.AddressType.Code = AddressType.FilteredList.Current.Code
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).addressTypeAttr.codeAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PolicyAddressList.Current.AddressType.Name = AddressType.FilteredList.Current.Name
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).addressTypeAttr.nameAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PolicyAddressList.Current.State.Id = State.FilteredList.Current.Id
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).stateAttr.idAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PolicyAddressList.Current.State.Code = State.FilteredList.Current.Code
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).stateAttr.codeAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PolicyAddressList.Current.State.Name = State.FilteredList.Current.Name
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).stateAttr.nameAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// PolicyAddressList.Current.Country.Id = Country.FilteredList.Current.Id
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).countryAttr.idAttr = countryVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// PolicyAddressList.Current.Country.Code = Country.FilteredList.Current.Code
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).countryAttr.codeAttr = countryVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e2zq_gaATE6kGli6ISss8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// PolicyAddressList.Current.Country.Name = Country.FilteredList.Current.Name
vars.value.policyAddressListInLocal.getItem(policyAddressListIndex.valueOf()).countryAttr.nameAttr = countryVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
policyAddressListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyAddressListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kcHq8bcFZUiwibJmI+koLA", callContext.id);
// AddressList = PolicyAddressList
outVars.value.addressListOut = vars.value.policyAddressListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AvdrhBRfakCvxKaMgBApNQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:yEf1tfoPH0ml9XMC4zh_IQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetContactDetails$vars", [{
name: "PolicyPhoneList",
attrName: "policyPhoneListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPhoneList();
},
complexType: PHICoreModel.PolicyPhoneList
}, {
name: "PhoneTypeList",
attrName: "phoneTypeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "PolicyAddressList",
attrName: "policyAddressListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyAddressList();
},
complexType: PHICoreModel.PolicyAddressList
}, {
name: "AddressTypeList",
attrName: "addressTypeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "StateList",
attrName: "stateListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "CountryList",
attrName: "countryListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetContactDetails$outVars", [{
name: "PhoneList",
attrName: "phoneListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPhoneList();
},
complexType: PHICoreModel.PolicyPhoneList
}, {
name: "AddressList",
attrName: "addressListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyAddressList();
},
complexType: PHICoreModel.PolicyAddressList
}]);
PHICoreController.default.clientActionProxies.getContactDetails$Action = function (policyPhoneListIn, phoneTypeListIn, policyAddressListIn, addressTypeListIn, stateListIn, countryListIn) {
policyPhoneListIn = (policyPhoneListIn === undefined) ? new PHICoreModel.PolicyPhoneList() : policyPhoneListIn;
phoneTypeListIn = (phoneTypeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : phoneTypeListIn;
policyAddressListIn = (policyAddressListIn === undefined) ? new PHICoreModel.PolicyAddressList() : policyAddressListIn;
addressTypeListIn = (addressTypeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : addressTypeListIn;
stateListIn = (stateListIn === undefined) ? new PHICoreModel.ReferenceDataList() : stateListIn;
countryListIn = (countryListIn === undefined) ? new PHICoreModel.ReferenceDataList() : countryListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getContactDetails$Action.bind(controller, policyPhoneListIn, phoneTypeListIn, policyAddressListIn, addressTypeListIn, stateListIn, countryListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PhoneList: actionResults.phoneListOut,
AddressList: actionResults.addressListOut
};
});
};
});

define("PHICore.controller$GetContactDetails_Stakeholder", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "APIGateway_IS.model", "PHICore.clientVariables", "PHICore.model$ReferenceDataList", "PHICore.model$AddressItemList", "PHICore.model$PhoneNumberItemList", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$ReferenceDataValidationRec", "APIGateway_IS.model$EmailItemRec", "PHICore.referencesHealth$APIGateway_IS", "PHICore.model$PolicyEmailList", "PHICore.model$PolicyAddressList", "PHICore.model$PolicyAddressRec", "PHICore.model$PolicyPhoneList", "PHICore.model$PolicyPhoneRec", "PHICore.model$Stakeholder_ReferenceRec", "APIGateway_IS.model$ContactDetailV2_ResponseRec", "PHICore.model$Stakeholder_InformationRec", "PHICore.model$Stakeholder_PersonalInformationRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getContactDetails_Stakeholder$Action = function (referencesIn, contactDetailsIn, stakeholder_InformationIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetContactDetails_Stakeholder$vars"))());
vars.value.referencesInLocal = referencesIn.clone();
vars.value.contactDetailsInLocal = contactDetailsIn.clone();
vars.value.stakeholder_InformationInLocal = stakeholder_InformationIn.clone();
var listFilter_RankVar = new OS.DataTypes.VariableHolder();
var listFilter_CountryCodeVar = new OS.DataTypes.VariableHolder();
var listFilter_SexVar = new OS.DataTypes.VariableHolder();
var listFilter_PhoneTypeVar = new OS.DataTypes.VariableHolder();
var listFilter_StateVar = new OS.DataTypes.VariableHolder();
var listFilter_PronounsVar = new OS.DataTypes.VariableHolder();
var listFilter_CountryVar = new OS.DataTypes.VariableHolder();
var listFilter_AddressTypeVar = new OS.DataTypes.VariableHolder();
var listFilter_TitleVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetContactDetails_Stakeholder$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_RankVar = listFilter_RankVar;
varBag.listFilter_CountryCodeVar = listFilter_CountryCodeVar;
varBag.listFilter_SexVar = listFilter_SexVar;
varBag.listFilter_PhoneTypeVar = listFilter_PhoneTypeVar;
varBag.listFilter_StateVar = listFilter_StateVar;
varBag.listFilter_PronounsVar = listFilter_PronounsVar;
varBag.listFilter_CountryVar = listFilter_CountryVar;
varBag.listFilter_AddressTypeVar = listFilter_AddressTypeVar;
varBag.listFilter_TitleVar = listFilter_TitleVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:BuY+JkdSMke7cze_UJkwzA:/ClientActionFlows.BuY+JkdSMke7cze_UJkwzA:glq0EsBhqE4RQEtALlHvNg", "PHICore", "GetContactDetails_Stakeholder", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6xXJznFSAEyiErgOQBuM_A", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:T+vfiwS_BUiHRRDgl+oM5g", callContext.id);
// Execute Action: ListFilter_Title
listFilter_TitleVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.personalDetailsAttr.titleListAttr, function (p) {
return (p.codeAttr === vars.value.stakeholder_InformationInLocal.titleCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+DA7EXdSmEWC02TcyzEL1Q", callContext.id);
// Execute Action: ListFilter_Rank
listFilter_RankVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.personalDetailsAttr.rankListAttr, function (p) {
return (p.codeAttr === vars.value.stakeholder_InformationInLocal.rankCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZH_3KPDyCEGCJTQPSCiO1A", callContext.id);
// Execute Action: ListFilter_Sex
listFilter_SexVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.personalDetailsAttr.sexListAttr, function (p) {
return (p.codeAttr === vars.value.stakeholder_InformationInLocal.sexCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AbsOZLZd6U6264Vwm5jLTA", callContext.id);
// Execute Action: ListFilter_Pronouns
listFilter_PronounsVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.personalDetailsAttr.pronounsListAttr, function (p) {
return (p.codeAttr === vars.value.stakeholder_InformationInLocal.pronounsCodeAttr);
}, callContext);

// PersonalInformation
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iQd721IkOUWmt8f2+3WNSw", callContext.id);
// PersonalInformation.Title = ListFilter_Title.FilteredList.Current
outVars.value.personalInformationOut.titleAttr = listFilter_TitleVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iQd721IkOUWmt8f2+3WNSw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PersonalInformation.Rank = ListFilter_Rank.FilteredList.Current
outVars.value.personalInformationOut.rankAttr = listFilter_RankVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iQd721IkOUWmt8f2+3WNSw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PersonalInformation.Sex = ListFilter_Sex.FilteredList.Current
outVars.value.personalInformationOut.sexAttr = listFilter_SexVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iQd721IkOUWmt8f2+3WNSw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PersonalInformation.Pronouns = ListFilter_Pronouns.FilteredList.Current
outVars.value.personalInformationOut.pronounsAttr = listFilter_PronounsVar.value.filteredListOut.getCurrent(callContext.iterationContext);
// Foreach ContactDetails.Phones
callContext.iterationContext.registerIterationStart(vars.value.contactDetailsInLocal.phonesAttr);
try {var phonesIterator = callContext.iterationContext.getIterator(vars.value.contactDetailsInLocal.phonesAttr);
var phonesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fuLBL3ooFE2CGJED9dmoxA", callContext.id) && (phonesIndex < vars.value.contactDetailsInLocal.phonesAttr.length))) {
phonesIterator.currentRowNumber = phonesIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Sc8cPw4i2UeI9Ru1o21cVw", callContext.id);
// Execute Action: ListFilter_PhoneType
listFilter_PhoneTypeVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.contactDetailsAttr.phoneTypeListAttr, function (p) {
return ((p.codeAttr === vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).typeAttr) || (p.nameAttr === vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).typeAttr));
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qc6pG6+F6Emmt5eXtP2gxA", callContext.id);
// Execute Action: ListFilter_CountryCode
listFilter_CountryCodeVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.contactDetailsAttr.countryCodeListAttr, function (p) {
return (p.codeAttr === OS.BuiltinFunctions.substr(vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr, 0, OS.BuiltinFunctions.length(p.codeAttr)));
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id);
// Phone.PhoneType = ListFilter_PhoneType.FilteredList.Current
vars.value.phoneVar.phoneTypeAttr = OS.DataConversion.JSConversions.typeConvertRecord(listFilter_PhoneTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Phone.CountryCode = ListFilter_CountryCode.FilteredList.Current
vars.value.phoneVar.countryCodeAttr = OS.DataConversion.JSConversions.typeConvertRecord(listFilter_CountryCodeVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Phone.Number.Value = If
vars.value.phoneVar.numberAttr.valueAttr = ((listFilter_CountryCodeVar.value.filteredListOut.isEmpty) ? (vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr) : (OS.BuiltinFunctions.substr(vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr, OS.BuiltinFunctions.length(listFilter_CountryCodeVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr), (OS.BuiltinFunctions.length(vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr) - OS.BuiltinFunctions.length(listFilter_CountryCodeVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr)))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Phone.IsActive = ContactDetails.Phones.Current.IsActive
vars.value.phoneVar.isActiveAttr = vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).isActiveAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Phone.IsPreferred.Value = ContactDetails.Phones.Current.IsPreferred
vars.value.phoneVar.isPreferredAttr.valueAttr = vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).isPreferredAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qyGRh7qRUq6oC971F6TOg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Phone.IsOverseas = ContactDetails.Phones.Current.IsOverseas
vars.value.phoneVar.isOverseasAttr = vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).isOverseasAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vlK09qx8tkSmWy0X3tXOcw", callContext.id);
// Execute Action: ListAppend_Phone
OS.SystemActions.listAppend(outVars.value.phoneListOut, vars.value.phoneVar, callContext);
phonesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.contactDetailsInLocal.phonesAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xuPX8gzYBkudWFwtPr9Wuw", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.emailListOut, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.contactDetailsInLocal.emailAttr, new PHICoreModel.PolicyEmailRec(), function (source, target) {
target.isActiveAttr = source.isActiveAttr;
return target;
}), callContext);
// Foreach ContactDetails.Addresses
callContext.iterationContext.registerIterationStart(vars.value.contactDetailsInLocal.addressesAttr);
try {var addressesIterator = callContext.iterationContext.getIterator(vars.value.contactDetailsInLocal.addressesAttr);
var addressesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vqryFxDG_EyP3wJKmdgxmA", callContext.id) && (addressesIndex < vars.value.contactDetailsInLocal.addressesAttr.length))) {
addressesIterator.currentRowNumber = addressesIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2bpagTFcTU6+5lvDpRBR2A", callContext.id);
// Execute Action: ListFilter_AddressType
listFilter_AddressTypeVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.contactDetailsAttr.addressTypeListAttr, function (p) {
return ((p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).typeAttr) || (p.nameAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).typeAttr));
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h66WRU517UOHbsX0pBHrJw", callContext.id);
// Execute Action: ListFilter_State
listFilter_StateVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.contactDetailsAttr.stateListAttr, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).stateTerritoryCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fKAccRYHJUya6gRGJf2BZA", callContext.id);
// Execute Action: ListFilter_Country
listFilter_CountryVar.value = OS.SystemActions.listFilter(vars.value.referencesInLocal.contactDetailsAttr.countryListAttr, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).countryCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id);
// Address.AddressType = ListFilter_AddressType.FilteredList.Current
vars.value.addressVar.addressTypeAttr = OS.DataConversion.JSConversions.typeConvertRecord(listFilter_AddressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Address.Line1 = If
vars.value.addressVar.line1Attr = (((vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).line2Attr === "")) ? ("") : (vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).line1Attr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Address.Line2.Value = If
vars.value.addressVar.line2Attr.valueAttr = (((vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).line2Attr === "")) ? (vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).line1Attr) : (vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).line2Attr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Address.Suburb.Value = ContactDetails.Addresses.Current.Suburb
vars.value.addressVar.suburbAttr.valueAttr = vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).suburbAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Address.Province.Value = ContactDetails.Addresses.Current.StateProvince
vars.value.addressVar.provinceAttr.valueAttr = vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).stateProvinceAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Address.State = ListFilter_State.FilteredList.Current
vars.value.addressVar.stateAttr = OS.DataConversion.JSConversions.typeConvertRecord(listFilter_StateVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Address.Postcode.Value = If
vars.value.addressVar.postcodeAttr.valueAttr = ((((vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).postcodeAttr) !== (""))) ? (vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).postcodeAttr) : (vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).zipPostalCodeAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Address.Country = ListFilter_Country.FilteredList.Current
vars.value.addressVar.countryAttr = OS.DataConversion.JSConversions.typeConvertRecord(listFilter_CountryVar.value.filteredListOut.getCurrent(callContext.iterationContext), new PHICoreModel.ReferenceDataValidationRec(), function (source, target) {
target.idAttr = source.idAttr;
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Address.IsActive = ContactDetails.Addresses.Current.IsActive
vars.value.addressVar.isActiveAttr = vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).isActiveAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8eD+nIppQkO+i+o_KgvMGA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Address.IsOverseas = ContactDetails.Addresses.Current.IsOverseas
vars.value.addressVar.isOverseasAttr = vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).isOverseasAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hThd9mBXGEGxuglzUwqtww", callContext.id);
// Execute Action: ListAppend_Address
OS.SystemActions.listAppend(outVars.value.addressListOut, vars.value.addressVar, callContext);
addressesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.contactDetailsInLocal.addressesAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BnTQFbOEq0aL9y5kdIeAdA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:BuY+JkdSMke7cze_UJkwzA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetContactDetails_Stakeholder$vars", [{
name: "References",
attrName: "referencesInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_ReferenceRec();
},
complexType: PHICoreModel.Stakeholder_ReferenceRec
}, {
name: "ContactDetails",
attrName: "contactDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.ContactDetailV2_ResponseRec();
},
complexType: APIGateway_ISModel.ContactDetailV2_ResponseRec
}, {
name: "Stakeholder_Information",
attrName: "stakeholder_InformationInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_InformationRec();
},
complexType: PHICoreModel.Stakeholder_InformationRec
}, {
name: "Phone",
attrName: "phoneVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyPhoneRec();
},
complexType: PHICoreModel.PolicyPhoneRec
}, {
name: "Address",
attrName: "addressVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyAddressRec();
},
complexType: PHICoreModel.PolicyAddressRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetContactDetails_Stakeholder$outVars", [{
name: "PhoneList",
attrName: "phoneListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPhoneList();
},
complexType: PHICoreModel.PolicyPhoneList
}, {
name: "EmailList",
attrName: "emailListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyEmailList();
},
complexType: PHICoreModel.PolicyEmailList
}, {
name: "AddressList",
attrName: "addressListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyAddressList();
},
complexType: PHICoreModel.PolicyAddressList
}, {
name: "PersonalInformation",
attrName: "personalInformationOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_PersonalInformationRec();
},
complexType: PHICoreModel.Stakeholder_PersonalInformationRec
}]);
PHICoreController.default.clientActionProxies.getContactDetails_Stakeholder$Action = function (referencesIn, contactDetailsIn, stakeholder_InformationIn) {
referencesIn = (referencesIn === undefined) ? new PHICoreModel.Stakeholder_ReferenceRec() : referencesIn;
contactDetailsIn = (contactDetailsIn === undefined) ? new APIGateway_ISModel.ContactDetailV2_ResponseRec() : contactDetailsIn;
stakeholder_InformationIn = (stakeholder_InformationIn === undefined) ? new PHICoreModel.Stakeholder_InformationRec() : stakeholder_InformationIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getContactDetails_Stakeholder$Action.bind(controller, referencesIn, contactDetailsIn, stakeholder_InformationIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PhoneList: actionResults.phoneListOut,
EmailList: actionResults.emailListOut,
AddressList: actionResults.addressListOut,
PersonalInformation: actionResults.personalInformationOut
};
});
};
});

define("PHICore.controller$GetCoverAndClass", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$ReferenceDataList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getCoverAndClass$Action = function (coverListIn, class_ListIn, classListIn, class_IdIn, cover_IdIn, classDropdown_ValidIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetCoverAndClass$vars"))());
vars.value.coverListInLocal = coverListIn.clone();
vars.value.class_ListInLocal = class_ListIn.clone();
vars.value.classListInLocal = classListIn.clone();
vars.value.class_IdInLocal = class_IdIn;
vars.value.cover_IdInLocal = cover_IdIn;
vars.value.classDropdown_ValidInLocal = classDropdown_ValidIn;
var getClassListDropdownVar = new OS.DataTypes.VariableHolder();
var listFilter_ClassVar = new OS.DataTypes.VariableHolder();
var listFilter_CoverVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetCoverAndClass$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getClassListDropdownVar = getClassListDropdownVar;
varBag.listFilter_ClassVar = listFilter_ClassVar;
varBag.listFilter_CoverVar = listFilter_CoverVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:DGkFSsA1rUW+57j2dyxYNQ:/ClientActionFlows.DGkFSsA1rUW+57j2dyxYNQ:CIE1eMLzoODDEq1XNrMeqw", "PHICore", "GetCoverAndClass", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dayHYgmkXUOVNSmwH_FFEg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+zoO+hVX0kOQniq1V0opBA", callContext.id);
// Execute Action: ListFilter_Cover
listFilter_CoverVar.value = OS.SystemActions.listFilter(vars.value.coverListInLocal, function (p) {
return p.idAttr.equals(vars.value.cover_IdInLocal);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+8MPXLdrOEi4SMEAI1u83w", callContext.id) && listFilter_CoverVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rq0L+A7jukWqsnBFNTqaHg", callContext.id);
// Class_List = ClassList
vars.value.class_ListInLocal = vars.value.classListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rq0L+A7jukWqsnBFNTqaHg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ClassDropdown_Valid = True
vars.value.classDropdown_ValidInLocal = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rq0L+A7jukWqsnBFNTqaHg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Class_Id = NullIdentifier
vars.value.class_IdInLocal = OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier());
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KnDjCz8jeE6mvyAnFlg1Ow", callContext.id);
// Execute Action: GetClassListDropdown
getClassListDropdownVar.value = OS.SystemActions.listFilter(vars.value.classListInLocal, function (p) {
return (p.parentEntityCodeAttr === listFilter_CoverVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6lmcpqU_N0mJJrK1AE62Ng", callContext.id);
// Class_List = GetClassListDropdown.FilteredList
vars.value.class_ListInLocal = getClassListDropdownVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XBnUU1l6lEu97FDaLnJZKA", callContext.id);
// Execute Action: ListFilter_Class
listFilter_ClassVar.value = OS.SystemActions.listFilter(vars.value.class_ListInLocal, function (p) {
return p.idAttr.equals(vars.value.class_IdInLocal);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hu8y3Bqhp0aVx08IOAdmIA", callContext.id) && listFilter_ClassVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BXOJEyxytE2HYOc0ekkdfQ", callContext.id);
// Class_Id = NullIdentifier
vars.value.class_IdInLocal = OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier());
}

}

// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id);
// Out_Class_List = Class_List
outVars.value.out_Class_ListOut = vars.value.class_ListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Out_Class_Id = Class_Id
outVars.value.out_Class_IdOut = vars.value.class_IdInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Out_ClassDropdown_Valid = ClassDropdown_Valid
outVars.value.out_ClassDropdown_ValidOut = vars.value.classDropdown_ValidInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Out_CoverList = CoverList
outVars.value.out_CoverListOut = vars.value.coverListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Out_ClassList = ClassList
outVars.value.out_ClassListOut = vars.value.classListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// CoverCode = ListFilter_Cover.FilteredList.Current.Code
outVars.value.coverCodeOut = listFilter_CoverVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n1l8sSr7R0awcPYuO0RMbg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// CoverName = ListFilter_Cover.FilteredList.Current.Name
outVars.value.coverNameOut = listFilter_CoverVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nZYAchyGkUqb_WwXlC6qlA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:DGkFSsA1rUW+57j2dyxYNQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetCoverAndClass$vars", [{
name: "CoverList",
attrName: "coverListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Class_List",
attrName: "class_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "ClassList",
attrName: "classListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Class_Id",
attrName: "class_IdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "Cover_Id",
attrName: "cover_IdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "ClassDropdown_Valid",
attrName: "classDropdown_ValidInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetCoverAndClass$outVars", [{
name: "Out_Class_List",
attrName: "out_Class_ListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Out_Class_Id",
attrName: "out_Class_IdOut",
mandatory: false,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "Out_ClassDropdown_Valid",
attrName: "out_ClassDropdown_ValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Out_CoverList",
attrName: "out_CoverListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Out_ClassList",
attrName: "out_ClassListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "CoverCode",
attrName: "coverCodeOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "CoverName",
attrName: "coverNameOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.getCoverAndClass$Action = function (coverListIn, class_ListIn, classListIn, class_IdIn, cover_IdIn, classDropdown_ValidIn) {
coverListIn = (coverListIn === undefined) ? new PHICoreModel.ReferenceDataList() : coverListIn;
class_ListIn = (class_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : class_ListIn;
classListIn = (classListIn === undefined) ? new PHICoreModel.ReferenceDataList() : classListIn;
class_IdIn = (class_IdIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : class_IdIn;
cover_IdIn = (cover_IdIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : cover_IdIn;
classDropdown_ValidIn = (classDropdown_ValidIn === undefined) ? false : classDropdown_ValidIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getCoverAndClass$Action.bind(controller, coverListIn, class_ListIn, classListIn, class_IdIn, cover_IdIn, OS.DataConversion.JSNodeParamConverter.from(classDropdown_ValidIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_Class_List: actionResults.out_Class_ListOut,
Out_Class_Id: actionResults.out_Class_IdOut,
Out_ClassDropdown_Valid: OS.DataConversion.JSNodeParamConverter.to(actionResults.out_ClassDropdown_ValidOut, OS.Types.Boolean),
Out_CoverList: actionResults.out_CoverListOut,
Out_ClassList: actionResults.out_ClassListOut,
CoverCode: OS.DataConversion.JSNodeParamConverter.to(actionResults.coverCodeOut, OS.Types.Text),
CoverName: OS.DataConversion.JSNodeParamConverter.to(actionResults.coverNameOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$GetFileExtension", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getFileExtension$Action = function (fileNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFileExtension$vars"))());
vars.value.fileNameInLocal = fileNameIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFileExtension$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Wtucle2ZoEilraJXEnrYjA:/ClientActionFlows.Wtucle2ZoEilraJXEnrYjA:G1xUG1CiGK+VFxAFsTzhuw", "PHICore", "GetFileExtension", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5_mWSZtdVEiuQhrbQewHjA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iHBDL+zRckCto+vLSoG+9w", callContext.id);
// Extension = Substr
outVars.value.extensionOut = OS.BuiltinFunctions.substr(vars.value.fileNameInLocal, OS.BuiltinFunctions.index(vars.value.fileNameInLocal, ".", 0, true, false), (OS.BuiltinFunctions.length(vars.value.fileNameInLocal) - OS.BuiltinFunctions.index(vars.value.fileNameInLocal, ".", 0, true, false)));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OQAt5+pZBk6tzzu7OudGUA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Wtucle2ZoEilraJXEnrYjA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFileExtension$vars", [{
name: "FileName",
attrName: "fileNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFileExtension$outVars", [{
name: "Extension",
attrName: "extensionOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.getFileExtension$Action = function (fileNameIn) {
fileNameIn = (fileNameIn === undefined) ? "" : fileNameIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getFileExtension$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(fileNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Extension: OS.DataConversion.JSNodeParamConverter.to(actionResults.extensionOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$GetFlagDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$ReferenceDataList", "PHICore.model$PolicyFlagDetailsList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getFlagDetails$Action = function (policyFlagDetailsListIn, flagListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFlagDetails$vars"))());
vars.value.policyFlagDetailsListInLocal = policyFlagDetailsListIn.clone();
vars.value.flagListInLocal = flagListIn.clone();
var flagTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFlagDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.flagTypeVar = flagTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:9TaHhMqeEkSNn9sAaEJaqw:/ClientActionFlows.9TaHhMqeEkSNn9sAaEJaqw:QZzPNgIqnlyKv8sz8T6UmQ", "PHICore", "GetFlagDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WGS7cDF2aEaKqFXffmYMfQ", callContext.id);
// Foreach PolicyFlagDetailsList
callContext.iterationContext.registerIterationStart(vars.value.policyFlagDetailsListInLocal);
try {var policyFlagDetailsListIterator = callContext.iterationContext.getIterator(vars.value.policyFlagDetailsListInLocal);
var policyFlagDetailsListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qLActL1ZCEi6678R8cIGnQ", callContext.id) && (policyFlagDetailsListIndex < vars.value.policyFlagDetailsListInLocal.length))) {
policyFlagDetailsListIterator.currentRowNumber = policyFlagDetailsListIndex;
// Flag Type = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gflEaqLUWkeDDNZEQ7n4zg", callContext.id) && !((vars.value.policyFlagDetailsListInLocal.getItem(policyFlagDetailsListIndex.valueOf()).nameAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ah8dOBOYgkqLvHgeYXjCpw", callContext.id);
// Execute Action: FlagType
flagTypeVar.value = OS.SystemActions.listFilter(vars.value.flagListInLocal, function (p) {
return ((OS.BuiltinFunctions.trim(OS.BuiltinFunctions.toLower(p.codeAttr)) === OS.BuiltinFunctions.trim(OS.BuiltinFunctions.toLower(vars.value.policyFlagDetailsListInLocal.getItem(policyFlagDetailsListIndex.valueOf()).nameAttr.codeAttr))) || (OS.BuiltinFunctions.trim(OS.BuiltinFunctions.toLower(p.nameAttr)) === OS.BuiltinFunctions.trim(OS.BuiltinFunctions.toLower(vars.value.policyFlagDetailsListInLocal.getItem(policyFlagDetailsListIndex.valueOf()).nameAttr.nameAttr))));
}, callContext);

// PreviousFundId
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SQT8JVxKKE6P3JvYn7RQjw", callContext.id);
// PolicyFlagDetailsList.Current.Name.Id = FlagType.FilteredList.Current.Id
vars.value.policyFlagDetailsListInLocal.getItem(policyFlagDetailsListIndex.valueOf()).nameAttr.idAttr = flagTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
}

policyFlagDetailsListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyFlagDetailsListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aJx3R9h2H0O4cazk+7Dwng", callContext.id);
// FlagDetailsList = PolicyFlagDetailsList
outVars.value.flagDetailsListOut = vars.value.policyFlagDetailsListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lxImhDRAU0+xldUIDd_6Rg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9TaHhMqeEkSNn9sAaEJaqw", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFlagDetails$vars", [{
name: "PolicyFlagDetailsList",
attrName: "policyFlagDetailsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyFlagDetailsList();
},
complexType: PHICoreModel.PolicyFlagDetailsList
}, {
name: "FlagList",
attrName: "flagListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFlagDetails$outVars", [{
name: "FlagDetailsList",
attrName: "flagDetailsListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyFlagDetailsList();
},
complexType: PHICoreModel.PolicyFlagDetailsList
}]);
PHICoreController.default.clientActionProxies.getFlagDetails$Action = function (policyFlagDetailsListIn, flagListIn) {
policyFlagDetailsListIn = (policyFlagDetailsListIn === undefined) ? new PHICoreModel.PolicyFlagDetailsList() : policyFlagDetailsListIn;
flagListIn = (flagListIn === undefined) ? new PHICoreModel.ReferenceDataList() : flagListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getFlagDetails$Action.bind(controller, policyFlagDetailsListIn, flagListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FlagDetailsList: actionResults.flagDetailsListOut
};
});
};
});

define("PHICore.controller$GetFrequncyShortName", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getFrequncyShortName$Action = function (codeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFrequncyShortName$vars"))());
vars.value.codeInLocal = codeIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetFrequncyShortName$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:BF3HoRDo4EqyvqceR9an3Q:/ClientActionFlows.BF3HoRDo4EqyvqceR9an3Q:_S6yz2IGYkRyFlXDj0sIVg", "PHICore", "GetFrequncyShortName", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ePbt7kr2GU+o9Aix91nZTg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:J9YP3uRRyEOQJEJK6hz5Ng", callContext.id) && (vars.value.codeInLocal === "Weekly"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Wf1EoXCAeEO5r2F6kyUoKg", callContext.id);
// ShortName = "wk"
outVars.value.shortNameOut = "wk";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
if((vars.value.codeInLocal === "Fortnightly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+q+mBc2SUESKK0RoTjbQ0Q", callContext.id);
// ShortName = "fortn"
outVars.value.shortNameOut = "fortn";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
if((vars.value.codeInLocal === "Monthly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QjQwCfvlqkWTEk0hGNA8Mg", callContext.id);
// ShortName = "mo"
outVars.value.shortNameOut = "mo";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
if((vars.value.codeInLocal === "Quarterly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6KOfyWmFykSCFO3U3NtHpg", callContext.id);
// ShortName = "qtr"
outVars.value.shortNameOut = "qtr";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
if((vars.value.codeInLocal === "HalfYearly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cH_GADCteU+Gvoabr1VUVQ", callContext.id);
// ShortName = "halfyr"
outVars.value.shortNameOut = "halfyr";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
if((vars.value.codeInLocal === "Yearly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OZqliaPP6EKTFZC43t2_iA", callContext.id);
// ShortName = "yr"
outVars.value.shortNameOut = "yr";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y1qXobAs4kqWlY+FleFbPw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v1bulCf5KkepN6bzhyLKYQ", callContext.id);
}

}

}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:BF3HoRDo4EqyvqceR9an3Q", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFrequncyShortName$vars", [{
name: "Code",
attrName: "codeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetFrequncyShortName$outVars", [{
name: "ShortName",
attrName: "shortNameOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.getFrequncyShortName$Action = function (codeIn) {
codeIn = (codeIn === undefined) ? "" : codeIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getFrequncyShortName$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(codeIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ShortName: OS.DataConversion.JSNodeParamConverter.to(actionResults.shortNameOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$GetIndividualFlags", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "Common_CS.model", "PHICore.clientVariables", "APIGateway_IS.model$GetEntityFlags_APIResponseRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore.controller$ServerAction.GetEntityFlags", "PHICore.model$FlagItemList", "PHICore.model$EntityFlagItemList"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, Common_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getIndividualFlags$Action = function (stakeholderIdIn, flags_ListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetIndividualFlags$vars"))());
vars.value.stakeholderIdInLocal = stakeholderIdIn;
vars.value.flags_ListInLocal = flags_ListIn.clone();
var getIndividual_EntityFlagsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetIndividualFlags$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getIndividual_EntityFlagsVar = getIndividual_EntityFlagsVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:STP7tNUNAk2VZK1j7oSpgg:/ClientActionFlows.STP7tNUNAk2VZK1j7oSpgg:gp98OMhlx8T1sXbQx3AhrA", "PHICore", "GetIndividualFlags", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yUndmvwHBEqluXb6lmkG0A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ckxmj5qhn0Kuw+05NoxadA", callContext.id);
// Execute Action: GetIndividual_EntityFlags
return controller.getEntityFlags$ServerAction(vars.value.stakeholderIdInLocal, "Individual", callContext).then(function (value) {
getIndividual_EntityFlagsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HDHTaNoEUE2p+MDoL8ZUnQ", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(vars.value.flags_ListInLocal, OS.DataConversion.JSConversions.typeConvertRecordList(getIndividual_EntityFlagsVar.value.responseOut.flagsAttr, new PHICoreModel.FlagItemList(), function (source, target) {
target.nameAttr = source.nameAttr;
target.commentAttr = source.commentAttr;
target.isRestrictedAttr = source.isRestrictedAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zH4i4YME90iEjEpLlEFqJw", callContext.id);
// Out_Flags_List = Flags_List
outVars.value.out_Flags_ListOut = vars.value.flags_ListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vI+B0acLyEmbODHY3UyjEA", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:STP7tNUNAk2VZK1j7oSpgg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:STP7tNUNAk2VZK1j7oSpgg", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetIndividualFlags$vars", [{
name: "StakeholderId",
attrName: "stakeholderIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Flags_List",
attrName: "flags_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.FlagItemList();
},
complexType: PHICoreModel.FlagItemList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetIndividualFlags$outVars", [{
name: "Out_Flags_List",
attrName: "out_Flags_ListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.FlagItemList();
},
complexType: PHICoreModel.FlagItemList
}]);
PHICoreController.default.clientActionProxies.getIndividualFlags$Action = function (stakeholderIdIn, flags_ListIn) {
stakeholderIdIn = (stakeholderIdIn === undefined) ? "" : stakeholderIdIn;
flags_ListIn = (flags_ListIn === undefined) ? new PHICoreModel.FlagItemList() : flags_ListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getIndividualFlags$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stakeholderIdIn, OS.Types.Text), flags_ListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_Flags_List: actionResults.out_Flags_ListOut
};
});
};
});

define("PHICore.controller$GetMembers_RebateDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "PHICore.clientVariables", "PHICore.model$PolicyMemberList", "PHICore.model$PolicyPersonalDetailsRec", "PHICore.model$PolicyPersonalDetailsList", "PHICore.model$PolicyMemberRec", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$Rebate_MedicareList", "PHICore.model$PolicyRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getMembers_RebateDetails$Action = function (rebateMedicareListIn, policyPersonalDetailsIn, policyIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetMembers_RebateDetails$vars"))());
vars.value.rebateMedicareListInLocal = rebateMedicareListIn.clone();
vars.value.policyPersonalDetailsInLocal = policyPersonalDetailsIn.clone();
vars.value.policyInLocal = policyIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetMembers_RebateDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:c13rxyBshkWW249U9lIhcA:/ClientActionFlows.c13rxyBshkWW249U9lIhcA:Oxeu8M5WBtis9tBxOvG2IQ", "PHICore", "GetMembers_RebateDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cg2C88+hRkqcdQP701wgrA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:geJ371Z4aEG66N9JAmkYXA", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(vars.value.policyPersonalDetailsInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nOCUxoeOX06kChshB7ZgCw", callContext.id);
// Execute Action: AppendPrimaryMember
OS.SystemActions.listAppend(vars.value.policyPersonalDetailsInLocal, vars.value.policyInLocal.primaryMemberAttr.personalDetailsAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cjnaRzRAZ0qC5sbePEWk7w", callContext.id);
// Execute Action: AppendAdditionalMembers
OS.SystemActions.listAppendAll(vars.value.policyPersonalDetailsInLocal, OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.policyInLocal.additionalMembersAttr, new PHICoreModel.PolicyPersonalDetailsList(), function (source, target) {
target = source.personalDetailsAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uRKbUHEILkiyKvJyB6+M2A", callContext.id);
// Execute Action: ClearMedicares
OS.SystemActions.listClear(vars.value.rebateMedicareListInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g5UnSv39CkG4fuZaM4bgZw", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(vars.value.rebateMedicareListInLocal, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.policyInLocal.primaryMemberAttr, new PHICoreModel.Rebate_MedicareRec(), function (source, target) {
target.medicareCardTypeAttr = source.policyCardsAssociationsDetailsAttr.medicareCardTypeAttr;
target.medicareCardNumberAttr = source.policyCardsAssociationsDetailsAttr.medicareCardNumberAttr;
target.medicareCardFirstNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardFirstNameAttr;
target.medicareCardMiddleNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardMiddleNameAttr;
target.medicareCardLastNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardLastNameAttr;
target.medicareCardIrnAttr = source.policyCardsAssociationsDetailsAttr.medicareCardIrnAttr;
target.medicareCardExpiryDateAttr = source.policyCardsAssociationsDetailsAttr.medicareCardExpiryDateAttr;
target.eclipseStatusAttr = source.policyCardsAssociationsDetailsAttr.eclipseStatusAttr;
target.lastPvmAttr = source.policyCardsAssociationsDetailsAttr.lastPvmAttr;
target.rebateApplicantAttr = (((source.personalDetailsAttr.firstNameAttr + " ") + source.personalDetailsAttr.lastNameAttr) + "[0]");
return target;
}), callContext);
// Foreach Policy.AdditionalMembers
callContext.iterationContext.registerIterationStart(vars.value.policyInLocal.additionalMembersAttr);
try {var additionalMembersIterator = callContext.iterationContext.getIterator(vars.value.policyInLocal.additionalMembersAttr);
var additionalMembersIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f4XSl9kR9k+hn4G3SZ__NQ", callContext.id) && (additionalMembersIndex < vars.value.policyInLocal.additionalMembersAttr.length))) {
additionalMembersIterator.currentRowNumber = additionalMembersIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ztcwZ4q9r0Kx2OZaG+v9rQ", callContext.id);
// Execute Action: ListAppend_AdditionalMembers_Rebate
OS.SystemActions.listAppend(vars.value.rebateMedicareListInLocal, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.policyInLocal.additionalMembersAttr.getItem(additionalMembersIndex.valueOf()), new PHICoreModel.Rebate_MedicareRec(), function (source, target) {
target.medicareCardTypeAttr = source.policyCardsAssociationsDetailsAttr.medicareCardTypeAttr;
target.medicareCardNumberAttr = source.policyCardsAssociationsDetailsAttr.medicareCardNumberAttr;
target.medicareCardFirstNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardFirstNameAttr;
target.medicareCardMiddleNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardMiddleNameAttr;
target.medicareCardLastNameAttr = source.policyCardsAssociationsDetailsAttr.medicareCardLastNameAttr;
target.medicareCardIrnAttr = source.policyCardsAssociationsDetailsAttr.medicareCardIrnAttr;
target.medicareCardExpiryDateAttr = source.policyCardsAssociationsDetailsAttr.medicareCardExpiryDateAttr;
target.eclipseStatusAttr = source.policyCardsAssociationsDetailsAttr.eclipseStatusAttr;
target.lastPvmAttr = source.policyCardsAssociationsDetailsAttr.lastPvmAttr;
target.rebateApplicantAttr = (((((source.personalDetailsAttr.firstNameAttr + " ") + source.personalDetailsAttr.lastNameAttr) + "[") + ((vars.value.policyInLocal.additionalMembersAttr.getCurrentRowNumber(callContext.iterationContext) + 1)).toString()) + "]");
target.hasValidatedAttr = source.policyCardsAssociationsDetailsAttr.hasValidatedAttr;
return target;
}), callContext);
additionalMembersIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyInLocal.additionalMembersAttr);
}

// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fZsIwGS33ESL2vNoRyCDFg", callContext.id);
// Out_RebateMedicareList = RebateMedicareList
outVars.value.out_RebateMedicareListOut = vars.value.rebateMedicareListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fZsIwGS33ESL2vNoRyCDFg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Out_PolicyPersonalDetails = PolicyPersonalDetails
outVars.value.out_PolicyPersonalDetailsOut = vars.value.policyPersonalDetailsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:whlYkrwJSkGTXd_4lSFxXQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:c13rxyBshkWW249U9lIhcA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetMembers_RebateDetails$vars", [{
name: "RebateMedicareList",
attrName: "rebateMedicareListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.Rebate_MedicareList();
},
complexType: PHICoreModel.Rebate_MedicareList
}, {
name: "PolicyPersonalDetails",
attrName: "policyPersonalDetailsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPersonalDetailsList();
},
complexType: PHICoreModel.PolicyPersonalDetailsList
}, {
name: "Policy",
attrName: "policyInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyRec();
},
complexType: PHICoreModel.PolicyRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetMembers_RebateDetails$outVars", [{
name: "Out_RebateMedicareList",
attrName: "out_RebateMedicareListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.Rebate_MedicareList();
},
complexType: PHICoreModel.Rebate_MedicareList
}, {
name: "Out_PolicyPersonalDetails",
attrName: "out_PolicyPersonalDetailsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPersonalDetailsList();
},
complexType: PHICoreModel.PolicyPersonalDetailsList
}]);
PHICoreController.default.clientActionProxies.getMembers_RebateDetails$Action = function (rebateMedicareListIn, policyPersonalDetailsIn, policyIn) {
rebateMedicareListIn = (rebateMedicareListIn === undefined) ? new PHICoreModel.Rebate_MedicareList() : rebateMedicareListIn;
policyPersonalDetailsIn = (policyPersonalDetailsIn === undefined) ? new PHICoreModel.PolicyPersonalDetailsList() : policyPersonalDetailsIn;
policyIn = (policyIn === undefined) ? new PHICoreModel.PolicyRec() : policyIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getMembers_RebateDetails$Action.bind(controller, rebateMedicareListIn, policyPersonalDetailsIn, policyIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_RebateMedicareList: actionResults.out_RebateMedicareListOut,
Out_PolicyPersonalDetails: actionResults.out_PolicyPersonalDetailsOut
};
});
};
});

define("PHICore.controller$GetNoteDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$PolicyNoteDetailsList", "PHICore.model$KeyValueValidationList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getNoteDetails$Action = function (policyNoteDetailsListIn, noteListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetNoteDetails$vars"))());
vars.value.policyNoteDetailsListInLocal = policyNoteDetailsListIn.clone();
vars.value.noteListInLocal = noteListIn.clone();
var noteTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetNoteDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.noteTypeVar = noteTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:GoEHqSkY102ZQiAbGS0MAQ:/ClientActionFlows.GoEHqSkY102ZQiAbGS0MAQ:CbLYGPw3ppkdXod92_MZVA", "PHICore", "GetNoteDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OLa+eWHHAEqGJm9HFay1eg", callContext.id);
// Foreach PolicyNoteDetailsList
callContext.iterationContext.registerIterationStart(vars.value.policyNoteDetailsListInLocal);
try {var policyNoteDetailsListIterator = callContext.iterationContext.getIterator(vars.value.policyNoteDetailsListInLocal);
var policyNoteDetailsListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:46DLYqNCI0q6Zgl2FeTE5g", callContext.id) && (policyNoteDetailsListIndex < vars.value.policyNoteDetailsListInLocal.length))) {
policyNoteDetailsListIterator.currentRowNumber = policyNoteDetailsListIndex;
// Note Type = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g4GRFWYAaka7UAtYikOM7A", callContext.id) && !((vars.value.policyNoteDetailsListInLocal.getItem(policyNoteDetailsListIndex.valueOf()).typeAttr.nameAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L9Z2z33ZtUGm1Jg4Dpeuww", callContext.id);
// Execute Action: NoteType
noteTypeVar.value = OS.SystemActions.listFilter(vars.value.noteListInLocal, function (p) {
return (p.nameAttr === vars.value.policyNoteDetailsListInLocal.getItem(policyNoteDetailsListIndex.valueOf()).typeAttr.nameAttr);
}, callContext);

// PreviousFundId
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pIMR1UdeLUK1Imo_xqL2GQ", callContext.id);
// PolicyNoteDetailsList.Current.Type.Id = NoteType.FilteredList.Current.Id
vars.value.policyNoteDetailsListInLocal.getItem(policyNoteDetailsListIndex.valueOf()).typeAttr.idAttr = noteTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
}

policyNoteDetailsListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyNoteDetailsListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jFyn_H1WV0m3jwRef7fOhg", callContext.id);
// NoteDetailsList = PolicyNoteDetailsList
outVars.value.noteDetailsListOut = vars.value.policyNoteDetailsListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lBoGf8G4PEyWTqkffI72kg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:GoEHqSkY102ZQiAbGS0MAQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetNoteDetails$vars", [{
name: "PolicyNoteDetailsList",
attrName: "policyNoteDetailsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyNoteDetailsList();
},
complexType: PHICoreModel.PolicyNoteDetailsList
}, {
name: "NoteList",
attrName: "noteListInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.KeyValueValidationList();
},
complexType: PHICoreModel.KeyValueValidationList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetNoteDetails$outVars", [{
name: "NoteDetailsList",
attrName: "noteDetailsListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyNoteDetailsList();
},
complexType: PHICoreModel.PolicyNoteDetailsList
}]);
PHICoreController.default.clientActionProxies.getNoteDetails$Action = function (policyNoteDetailsListIn, noteListIn) {
policyNoteDetailsListIn = (policyNoteDetailsListIn === undefined) ? new PHICoreModel.PolicyNoteDetailsList() : policyNoteDetailsListIn;
noteListIn = (noteListIn === undefined) ? new PHICoreModel.KeyValueValidationList() : noteListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getNoteDetails$Action.bind(controller, policyNoteDetailsListIn, noteListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
NoteDetailsList: actionResults.noteDetailsListOut
};
});
};
});

define("PHICore.controller$GetPersonalDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "PHICore.clientVariables", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "PHICore.model$ReferenceDataList", "PHICore.model$Member_PersonalDetailsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getPersonalDetails$Action = function (isPrimaryMemberIn, memberPersonalDetailsIn, roleListIn, relationshipListIn, titleListIn, rankListIn, sexListIn, pronounsListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetPersonalDetails$vars"))());
vars.value.isPrimaryMemberInLocal = isPrimaryMemberIn;
vars.value.memberPersonalDetailsInLocal = memberPersonalDetailsIn.clone();
vars.value.roleListInLocal = roleListIn.clone();
vars.value.relationshipListInLocal = relationshipListIn.clone();
vars.value.titleListInLocal = titleListIn.clone();
vars.value.rankListInLocal = rankListIn.clone();
vars.value.sexListInLocal = sexListIn.clone();
vars.value.pronounsListInLocal = pronounsListIn.clone();
var rank_ListVar = new OS.DataTypes.VariableHolder();
var memberRole_ListVar = new OS.DataTypes.VariableHolder();
var role_ListVar = new OS.DataTypes.VariableHolder();
var relationship_ListVar = new OS.DataTypes.VariableHolder();
var pronounsVar = new OS.DataTypes.VariableHolder();
var title_ListVar = new OS.DataTypes.VariableHolder();
var sex_ListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetPersonalDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.rank_ListVar = rank_ListVar;
varBag.memberRole_ListVar = memberRole_ListVar;
varBag.role_ListVar = role_ListVar;
varBag.relationship_ListVar = relationship_ListVar;
varBag.pronounsVar = pronounsVar;
varBag.title_ListVar = title_ListVar;
varBag.sex_ListVar = sex_ListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XCpGFFZqqkCHfF8NufO6nQ:/ClientActionFlows.XCpGFFZqqkCHfF8NufO6nQ:uKOVLiWEhpQeUCbgcL8bXg", "PHICore", "GetPersonalDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YZZ4do0YHkSCtb+aGMS5OQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mCA4Hhx0FEyU56gaNm8oYg", callContext.id) && vars.value.isPrimaryMemberInLocal)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cmndiEWa1EWXUWC6Kr4kTA", callContext.id);
// Execute Action: Role_List
role_ListVar.value = OS.SystemActions.listFilter(vars.value.roleListInLocal, function (p) {
return (p.codeAttr === "PrimaryMember");
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G4Q3zwIZgU+ltteKTRkAfQ", callContext.id) && !(role_ListVar.value.filteredListOut.isEmpty))) {
// PolicyRole
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UWH4du6Da0izGJeS9_afJg", callContext.id);
// PersonalDetails.PolicyRole = Role_List.FilteredList.Current
outVars.value.personalDetailsOut.policyRoleAttr = role_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f81ATyKpFE2WOXFiVFAsDQ", callContext.id);
// Execute Action: MemberRole_List
memberRole_ListVar.value = OS.SystemActions.listFilter(vars.value.roleListInLocal, function (p) {
return (p.codeAttr === "Member");
}, callContext);

// PolicyRole
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uqOmfOiP00eUisYOeKx7cA", callContext.id);
// PersonalDetails.PolicyRole = MemberRole_List.FilteredList.Current
outVars.value.personalDetailsOut.policyRoleAttr = memberRole_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:li23j460WEuwEnW9ynl_mw", callContext.id);
// Execute Action: Relationship_List
relationship_ListVar.value = OS.SystemActions.listFilter(vars.value.relationshipListInLocal, function (p) {
return (OS.BuiltinFunctions.trim(p.codeAttr) === OS.BuiltinFunctions.trim(vars.value.memberPersonalDetailsInLocal.relationshipAttr.codeAttr));
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Lz0m43YS+EyOe_DJ0r15_A", callContext.id) && !(relationship_ListVar.value.filteredListOut.isEmpty))) {
// Title
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uYstTIdeakebhdDSbZ++IA", callContext.id);
// PersonalDetails.Relationship = Relationship_List.FilteredList.Current
outVars.value.personalDetailsOut.relationshipAttr = relationship_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F6_R1lXrYU2HhtfqMaif2g", callContext.id);
// Execute Action: Title_List
title_ListVar.value = OS.SystemActions.listFilter(vars.value.titleListInLocal, function (p) {
return (OS.BuiltinFunctions.trim(p.codeAttr) === OS.BuiltinFunctions.trim(vars.value.memberPersonalDetailsInLocal.titleAttr.codeAttr));
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wUwU7EazV0a5UQFH2Ew59Q", callContext.id) && !(title_ListVar.value.filteredListOut.isEmpty))) {
// Title
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XoP8pjsvikysqDVdb_GHnA", callContext.id);
// PersonalDetails.Title = Title_List.FilteredList.Current
outVars.value.personalDetailsOut.titleAttr = title_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4yLmR49viE68zgkKvZdGpA", callContext.id);
// Execute Action: Rank_List
rank_ListVar.value = OS.SystemActions.listFilter(vars.value.rankListInLocal, function (p) {
return (p.codeAttr === vars.value.memberPersonalDetailsInLocal.rankAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M47YS+R4N0uNuhmfQIrb4A", callContext.id) && !(rank_ListVar.value.filteredListOut.isEmpty))) {
// Rank
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qjunMhPlXUS8rDgL7g8cGA", callContext.id);
// PersonalDetails.Rank = Rank_List.FilteredList.Current
outVars.value.personalDetailsOut.rankAttr = rank_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oWp4_qJ5702vdGGNfxufiQ", callContext.id);
// Execute Action: Sex_List
sex_ListVar.value = OS.SystemActions.listFilter(vars.value.sexListInLocal, function (p) {
return (p.nameAttr === vars.value.memberPersonalDetailsInLocal.sexAttr.nameAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ERMSRUx5W0i5IyACKgGB4w", callContext.id) && !(sex_ListVar.value.filteredListOut.isEmpty))) {
// Sex
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_j_Pk5TOg0aRAzgHBt7IRw", callContext.id);
// PersonalDetails.Sex = Sex_List.FilteredList.Current
outVars.value.personalDetailsOut.sexAttr = sex_ListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cXt9odgq90GhDMPg3yEbfg", callContext.id);
// Execute Action: Pronouns
pronounsVar.value = OS.SystemActions.listFilter(vars.value.pronounsListInLocal, function (p) {
return (p.codeAttr === vars.value.memberPersonalDetailsInLocal.pronounsAttr.codeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1NnE1k_9WEGcjLiaF6oijw", callContext.id) && pronounsVar.value.filteredListOut.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:txJ3uav4LEKS+B1TUJDWFA", callContext.id);
} else {
// Pronouns
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GksKTQ_7WkS3HZqQZj7Qgw", callContext.id);
// PersonalDetails.Pronouns = Pronouns.FilteredList.Current
outVars.value.personalDetailsOut.pronounsAttr = pronounsVar.value.filteredListOut.getCurrent(callContext.iterationContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:txJ3uav4LEKS+B1TUJDWFA", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XCpGFFZqqkCHfF8NufO6nQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetPersonalDetails$vars", [{
name: "IsPrimaryMember",
attrName: "isPrimaryMemberInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "MemberPersonalDetails",
attrName: "memberPersonalDetailsInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Member_PersonalDetailsRec();
},
complexType: PHICoreModel.Member_PersonalDetailsRec
}, {
name: "RoleList",
attrName: "roleListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "RelationshipList",
attrName: "relationshipListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "TitleList",
attrName: "titleListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "RankList",
attrName: "rankListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "SexList",
attrName: "sexListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "PronounsList",
attrName: "pronounsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetPersonalDetails$outVars", [{
name: "PersonalDetails",
attrName: "personalDetailsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Member_PersonalDetailsRec();
},
complexType: PHICoreModel.Member_PersonalDetailsRec
}]);
PHICoreController.default.clientActionProxies.getPersonalDetails$Action = function (isPrimaryMemberIn, memberPersonalDetailsIn, roleListIn, relationshipListIn, titleListIn, rankListIn, sexListIn, pronounsListIn) {
isPrimaryMemberIn = (isPrimaryMemberIn === undefined) ? false : isPrimaryMemberIn;
memberPersonalDetailsIn = (memberPersonalDetailsIn === undefined) ? new PHICoreModel.Member_PersonalDetailsRec() : memberPersonalDetailsIn;
roleListIn = (roleListIn === undefined) ? new PHICoreModel.ReferenceDataList() : roleListIn;
relationshipListIn = (relationshipListIn === undefined) ? new PHICoreModel.ReferenceDataList() : relationshipListIn;
titleListIn = (titleListIn === undefined) ? new PHICoreModel.ReferenceDataList() : titleListIn;
rankListIn = (rankListIn === undefined) ? new PHICoreModel.ReferenceDataList() : rankListIn;
sexListIn = (sexListIn === undefined) ? new PHICoreModel.ReferenceDataList() : sexListIn;
pronounsListIn = (pronounsListIn === undefined) ? new PHICoreModel.ReferenceDataList() : pronounsListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getPersonalDetails$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isPrimaryMemberIn, OS.Types.Boolean), memberPersonalDetailsIn, roleListIn, relationshipListIn, titleListIn, rankListIn, sexListIn, pronounsListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PersonalDetails: actionResults.personalDetailsOut
};
});
};
});

define("PHICore.controller$GetPreviousCoverDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "PHICore.clientVariables", "PHICore.model$PolicyPreviousCoverDetailsList", "PHICore.model$ProductList", "PHICore.model$ReferenceDataList", "APIGateway_IS.model$GetSearchProduct_APIResponseRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getPreviousCoverDetails$Action = function (fundListIn, healthScaleListIn, policyPreviousCoverDetailsListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetPreviousCoverDetails$vars"))());
vars.value.fundListInLocal = fundListIn.clone();
vars.value.healthScaleListInLocal = healthScaleListIn.clone();
vars.value.policyPreviousCoverDetailsListInLocal = policyPreviousCoverDetailsListIn.clone();
var healthScaleVar = new OS.DataTypes.VariableHolder();
var fundVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetPreviousCoverDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.healthScaleVar = healthScaleVar;
varBag.fundVar = fundVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:iyAXYEwNlUK3_nJI3Zc2XQ:/ClientActionFlows.iyAXYEwNlUK3_nJI3Zc2XQ:h52ztMW04cYMoGyuRlddDQ", "PHICore", "GetPreviousCoverDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:raYCpMpzg0Kq_jxRD54YBw", callContext.id);
// Foreach PolicyPreviousCoverDetailsList
callContext.iterationContext.registerIterationStart(vars.value.policyPreviousCoverDetailsListInLocal);
try {var policyPreviousCoverDetailsListIterator = callContext.iterationContext.getIterator(vars.value.policyPreviousCoverDetailsListInLocal);
var policyPreviousCoverDetailsListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NN8A9YjzhkKH8aXKCy0Xug", callContext.id) && (policyPreviousCoverDetailsListIndex < vars.value.policyPreviousCoverDetailsListInLocal.length))) {
policyPreviousCoverDetailsListIterator.currentRowNumber = policyPreviousCoverDetailsListIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KgW+0hg30km_2bTfrVlyOg", callContext.id);
// PolicyPreviousCoverDetailsList.Current.EnableFields = True
vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).enableFieldsAttr = true;
// PreviousFund = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:O4ruLnloaE2HIDBuY+eNtQ", callContext.id) && !((vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).previousFundAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2P46qJ+ObkKTJa_Ja60uJQ", callContext.id);
// Execute Action: Fund
fundVar.value = OS.SystemActions.listFilter(vars.value.fundListInLocal, function (p) {
return (p.codeAttr === vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).previousFundAttr.codeAttr);
}, callContext);

// PreviousFundId
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tpZTgCby40eJzcIx5ArkLg", callContext.id);
// PolicyPreviousCoverDetailsList.Current.PreviousFund.Id = Fund.FilteredList.Current.Id
vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).previousFundAttr.idAttr = fundVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
}

// ClaimsInformation = Null
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:s_Vo7rJMfEyf88_hpsiuEA", callContext.id) && !((vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).healthScaleAttr.codeAttr === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yVZeonkJ9USUwQBWtPlaGA", callContext.id);
// Execute Action: HealthScale
healthScaleVar.value = OS.SystemActions.listFilter(vars.value.healthScaleListInLocal.resultAttr, function (p) {
return (p.rateScaleCodeAttr === vars.value.policyPreviousCoverDetailsListInLocal.getItem(policyPreviousCoverDetailsListIndex.valueOf()).healthScaleAttr.codeAttr);
}, callContext);

// HealthScale
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o3ohrR2zMka_ZYx11zD_bg", callContext.id);
}

policyPreviousCoverDetailsListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.policyPreviousCoverDetailsListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:awo+Nuxv5kG6_rvs2lz_yg", callContext.id);
// PreviousCoverDetailsList = PolicyPreviousCoverDetailsList
outVars.value.previousCoverDetailsListOut = vars.value.policyPreviousCoverDetailsListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yynZsxiNLECOeWc5k+wkKA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:iyAXYEwNlUK3_nJI3Zc2XQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetPreviousCoverDetails$vars", [{
name: "FundList",
attrName: "fundListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "HealthScaleList",
attrName: "healthScaleListInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.GetSearchProduct_APIResponseRec();
},
complexType: APIGateway_ISModel.GetSearchProduct_APIResponseRec
}, {
name: "PolicyPreviousCoverDetailsList",
attrName: "policyPreviousCoverDetailsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPreviousCoverDetailsList();
},
complexType: PHICoreModel.PolicyPreviousCoverDetailsList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetPreviousCoverDetails$outVars", [{
name: "PreviousCoverDetailsList",
attrName: "previousCoverDetailsListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyPreviousCoverDetailsList();
},
complexType: PHICoreModel.PolicyPreviousCoverDetailsList
}]);
PHICoreController.default.clientActionProxies.getPreviousCoverDetails$Action = function (fundListIn, healthScaleListIn, policyPreviousCoverDetailsListIn) {
fundListIn = (fundListIn === undefined) ? new PHICoreModel.ReferenceDataList() : fundListIn;
healthScaleListIn = (healthScaleListIn === undefined) ? new APIGateway_ISModel.GetSearchProduct_APIResponseRec() : healthScaleListIn;
policyPreviousCoverDetailsListIn = (policyPreviousCoverDetailsListIn === undefined) ? new PHICoreModel.PolicyPreviousCoverDetailsList() : policyPreviousCoverDetailsListIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getPreviousCoverDetails$Action.bind(controller, fundListIn, healthScaleListIn, policyPreviousCoverDetailsListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PreviousCoverDetailsList: actionResults.previousCoverDetailsListOut
};
});
};
});

define("PHICore.controller$GetSelectedStakeholdeIds", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$PolicyMemberList", "PHICore.model$PolicyMemberRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.getSelectedStakeholdeIds$Action = function (primaryMemberIn, additionalMembersIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetSelectedStakeholdeIds$vars"))());
vars.value.primaryMemberInLocal = primaryMemberIn.clone();
vars.value.additionalMembersInLocal = additionalMembersIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.GetSelectedStakeholdeIds$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:IZOINu8ii0KM9GN1cK7_4A:/ClientActionFlows.IZOINu8ii0KM9GN1cK7_4A:8ENlN3iWTS9xm89vVfv8BQ", "PHICore", "GetSelectedStakeholdeIds", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lXQ_DmCx2UScB9V7HrTXng", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rJpZdFL2t0+gFqP70MaHqA", callContext.id);
// Execute Action: ListAppend_PrimaryMember
OS.SystemActions.listAppend(outVars.value.selectedStakeholderIdsOut, vars.value.primaryMemberInLocal.personalDetailsAttr.stakeholderIdAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q4KFPA24SkingRsgVZ7vUg", callContext.id);
// Execute Action: ListAppendAll_AdditionalMember
OS.SystemActions.listAppendAll(outVars.value.selectedStakeholderIdsOut, OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.additionalMembersInLocal, new OS.DataTypes.TextList(), function (source, target) {
target = source.personalDetailsAttr.stakeholderIdAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BJcbJAdoHEiu3yCFLQ2hYA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:IZOINu8ii0KM9GN1cK7_4A", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetSelectedStakeholdeIds$vars", [{
name: "PrimaryMember",
attrName: "primaryMemberInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyMemberRec();
},
complexType: PHICoreModel.PolicyMemberRec
}, {
name: "AdditionalMembers",
attrName: "additionalMembersInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberList();
},
complexType: PHICoreModel.PolicyMemberList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.GetSelectedStakeholdeIds$outVars", [{
name: "SelectedStakeholderIds",
attrName: "selectedStakeholderIdsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
PHICoreController.default.clientActionProxies.getSelectedStakeholdeIds$Action = function (primaryMemberIn, additionalMembersIn) {
primaryMemberIn = (primaryMemberIn === undefined) ? new PHICoreModel.PolicyMemberRec() : primaryMemberIn;
additionalMembersIn = (additionalMembersIn === undefined) ? new PHICoreModel.PolicyMemberList() : additionalMembersIn;
return controller.executeActionInsideJSNode(PHICoreController.default.getSelectedStakeholdeIds$Action.bind(controller, primaryMemberIn, additionalMembersIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
SelectedStakeholderIds: actionResults.selectedStakeholderIdsOut
};
});
};
});

define("PHICore.controller$IdentifyAuditSort", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.identifyAuditSort$Action = function (currentIn, addDescIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.IdentifyAuditSort$vars"))());
vars.value.currentInLocal = currentIn;
vars.value.addDescInLocal = addDescIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.IdentifyAuditSort$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Av0vUNYJSEiV3Vqe3Iy5gw:/ClientActionFlows.Av0vUNYJSEiV3Vqe3Iy5gw:cjsODJ2EZtD_zC3sMNORTg", "PHICore", "IdentifyAuditSort", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:i8D2M0ue7kCgnBt_AHOSpA", callContext.id);
// PerformedAt
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+602zA1unE6PANtl1hnpUQ", callContext.id) && (vars.value.currentInLocal === "AuditLog.PerformedAt"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9tai0UsziUWfVYRuZ9WFdw", callContext.id);
// New = "{AuditLog}.[PerformedAt]"
outVars.value.newOut = "{AuditLog}.[PerformedAt]";
}

// Name
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XGVhoGGRBE6_30sM8+Db8Q", callContext.id) && (vars.value.currentInLocal === "User.Name"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7RweBhl4Vka2WfSPIdO5SA", callContext.id);
// New = "{User}.[Name]"
outVars.value.newOut = "{User}.[Name]";
}

// EntityType_entityID
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HNUaNIh77kSfqd38vdTWsA", callContext.id) && (vars.value.currentInLocal === "{AuditLog}.[Entity],{AuditLog}.[EntityId]"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qSYKqsgMu028ZOk2tH7lEQ", callContext.id);
// New = "{AuditLog}.[Entity]" + If + ",{AuditLog}.[EntityId]"
outVars.value.newOut = (("{AuditLog}.[Entity]" + ((vars.value.addDescInLocal) ? (" DESC") : (""))) + ",{AuditLog}.[EntityId]");
}

// Field
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JyzvaaA53EGyNPEFP6tkdA", callContext.id) && (vars.value.currentInLocal === "AuditLogDetails.Field"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pxTLwfodLka2AS_ZmUMsSQ", callContext.id);
// New = "{AuditLogDetails}.[Field]"
outVars.value.newOut = "{AuditLogDetails}.[Field]";
}

// Label
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RJCMUYJAXUybxHqX+RvIGQ", callContext.id) && (vars.value.currentInLocal === "OperationType.Label"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NfHpH68qVEifyIgCitTl+g", callContext.id);
// New = "{OperationType}.[Label]"
outVars.value.newOut = "{OperationType}.[Label]";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d3Ieg7plN0ay9CbKaO6uIQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d3Ieg7plN0ay9CbKaO6uIQ", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Av0vUNYJSEiV3Vqe3Iy5gw", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.IdentifyAuditSort$vars", [{
name: "Current",
attrName: "currentInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "AddDesc",
attrName: "addDescInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.IdentifyAuditSort$outVars", [{
name: "New",
attrName: "newOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.identifyAuditSort$Action = function (currentIn, addDescIn) {
currentIn = (currentIn === undefined) ? "" : currentIn;
addDescIn = (addDescIn === undefined) ? false : addDescIn;
return controller.executeActionInsideJSNode(PHICoreController.default.identifyAuditSort$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(currentIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(addDescIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
New: OS.DataConversion.JSNodeParamConverter.to(actionResults.newOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$MaskCardNumber", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.controller$MaskCardNumber.MaskCardNumberJS", "PHICore.clientVariables"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICore_controller_MaskCardNumber_MaskCardNumberJS, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.maskCardNumber$Action = function (cardNumberIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MaskCardNumber$vars"))());
vars.value.cardNumberInLocal = cardNumberIn;
var maskCardNumberJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MaskCardNumber$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.maskCardNumberJSResult = maskCardNumberJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:KG1p2WUDkEGQYu5wls8+tg:/ClientActionFlows.KG1p2WUDkEGQYu5wls8+tg:uWY+N9HinX_iiGButUB4Dg", "PHICore", "MaskCardNumber", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ciqTzo8f202D4u5wc24VLg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7F0HifCTakO+GCa1g9T02g", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.cardNumberInLocal)) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wVkn7s9lYk6HilpmeVxk6w", callContext.id);
maskCardNumberJSResult.value = controller.safeExecuteJSNode(PHICore_controller_MaskCardNumber_MaskCardNumberJS, "MaskCardNumber", "MaskCardNumber", {
CardNumber: OS.DataConversion.JSNodeParamConverter.to(vars.value.cardNumberInLocal, OS.Types.Text),
MaskedCardNumber: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("PHICore.MaskCardNumber$maskCardNumberJSResult"))();
jsNodeResult.maskedCardNumberOut = OS.DataConversion.JSNodeParamConverter.from($parameters.MaskedCardNumber, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SljDf9STeUSQlTI4FBKoQg", callContext.id);
// MaskedCardNumber = MaskCardNumber.MaskedCardNumber
outVars.value.maskedCardNumberOut = maskCardNumberJSResult.value.maskedCardNumberOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZC_GGLvQi0G0_0hjHKnDDg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qk66a6zYDESOS4yMVcLTxw", callContext.id);
// MaskedCardNumber = CardNumber
outVars.value.maskedCardNumberOut = vars.value.cardNumberInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZC_GGLvQi0G0_0hjHKnDDg", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KG1p2WUDkEGQYu5wls8+tg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.MaskCardNumber$vars", [{
name: "CardNumber",
attrName: "cardNumberInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.MaskCardNumber$maskCardNumberJSResult", [{
name: "MaskedCardNumber",
attrName: "maskedCardNumberOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.MaskCardNumber$outVars", [{
name: "MaskedCardNumber",
attrName: "maskedCardNumberOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.maskCardNumber$Action = function (cardNumberIn) {
cardNumberIn = (cardNumberIn === undefined) ? "" : cardNumberIn;
return controller.executeActionInsideJSNode(PHICoreController.default.maskCardNumber$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(cardNumberIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MaskedCardNumber: OS.DataConversion.JSNodeParamConverter.to(actionResults.maskedCardNumberOut, OS.Types.Text)
};
});
};
});
define("PHICore.controller$MaskCardNumber.MaskCardNumberJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
const lastFour = $parameters.CardNumber.slice(-4);
const remaining = $parameters.CardNumber.slice(0, $parameters.CardNumber.length - 4);
const masked = "*".repeat(remaining.length) + lastFour;
$parameters.MaskedCardNumber = masked.split("").reverse().join("").match(/.{1,4}/g).reverse().join(" ");

};
});

define("PHICore.controller$OnChange_RebateAction", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$ReferenceDataList", "PHICore.model$RebateDetailsWithValidationList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.onChange_RebateAction$Action = function (rebateActionListIn, updated_RebateDetailsListIn, rowNumberIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnChange_RebateAction$vars"))());
vars.value.rebateActionListInLocal = rebateActionListIn.clone();
vars.value.updated_RebateDetailsListInLocal = updated_RebateDetailsListIn.clone();
vars.value.rowNumberInLocal = rowNumberIn;
var rebateAction2Var = new OS.DataTypes.VariableHolder();
var savingsProvisionsStartVar = new OS.DataTypes.VariableHolder();
var savingsProvisionsEndVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnChange_RebateAction$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.rebateAction2Var = rebateAction2Var;
varBag.savingsProvisionsStartVar = savingsProvisionsStartVar;
varBag.savingsProvisionsEndVar = savingsProvisionsEndVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:F1Y_b5gqjUmSEt_ZAPBVIw:/ClientActionFlows.F1Y_b5gqjUmSEt_ZAPBVIw:7UlyUMyHsF9vj7AgMf5D6Q", "PHICore", "OnChange_RebateAction", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2uDAMFrFyEG2+JT2awli6w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9MYkSw5EUKg7GpEIjfjGQ", callContext.id);
// Updated_RebateDetailsList.Current.RebateActionValidation.Error = ""
vars.value.updated_RebateDetailsListInLocal.getCurrent(callContext.iterationContext).rebateActionValidationAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9MYkSw5EUKg7GpEIjfjGQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Updated_RebateDetailsList.Current.PreviousFundNameValidation.Error = ""
vars.value.updated_RebateDetailsListInLocal.getCurrent(callContext.iterationContext).previousFundNameValidationAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9MYkSw5EUKg7GpEIjfjGQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Updated_RebateDetailsList.Current.PreviousPolicyNumValidation.Error = ""
vars.value.updated_RebateDetailsListInLocal.getCurrent(callContext.iterationContext).previousPolicyNumValidationAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f5My0SRqvUqQ2faIavBiAQ", callContext.id);
// Execute Action: RebateAction2
rebateAction2Var.value = OS.SystemActions.listFilter(vars.value.updated_RebateDetailsListInLocal, function (p) {
return (p.rebateActionAttr === vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateActionAttr);
}, callContext);

// Length = 2
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AqGauueUJk6H7jAnTe5TiQ", callContext.id) && (rebateAction2Var.value.filteredListOut.length === 2))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZCGheO9VEUmGFAxTNx_Frg", callContext.id);
// Updated_RebateDetailsList[RowNumber].RebateActionValidation.Error = "Rebate action already exists."
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateActionValidationAttr.errorAttr = "Rebate action already exists.";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZCGheO9VEUmGFAxTNx_Frg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Updated_RebateDetailsList[RowNumber].RebateAction = NullIdentifier
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateActionAttr = (OS.BuiltinFunctions.nullIdentifier()).toString();
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rz2a6G9XBESlbzqhPE87eg", callContext.id);
// Execute Action: SavingsProvisionsStart
savingsProvisionsStartVar.value = OS.SystemActions.listFilter(vars.value.rebateActionListInLocal, function (p) {
return (p.codeAttr === "SavingsProvisionsStart");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M4k48FA6jkaL6btds5H1SQ", callContext.id);
// Execute Action: SavingsProvisionsEnd
savingsProvisionsEndVar.value = OS.SystemActions.listFilter(vars.value.rebateActionListInLocal, function (p) {
return (p.codeAttr === "SavingsProvisionsEnd");
}, callContext);

// SavingsProvisionsStart
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xBdV_JRQlkKXaOiA8Tox2Q", callContext.id) && (vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateActionAttr === savingsProvisionsStartVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oJyZbdc9lkCMMMMrV8Lv6w", callContext.id);
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowRebateAge = True
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowRebateAgeAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oJyZbdc9lkCMMMMrV8Lv6w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowPreviousField = True
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowPreviousFieldAttr = true;
} else {
// SavingsProvisionsEnd
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wI23uMZQ1k+8PfCt1aexBg", callContext.id) && (vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateActionAttr === savingsProvisionsEndVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr))) {
// IsShowPreviousField
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GqynRGm+jE2TTZEkrgOrKg", callContext.id);
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowPreviousField = False
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowPreviousFieldAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GqynRGm+jE2TTZEkrgOrKg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowRebateAge = True
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowRebateAgeAttr = true;
} else {
// IsShowPreviousField
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VI+HvKdeFkuyc0VbiA8SpA", callContext.id);
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowPreviousField = False
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowPreviousFieldAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VI+HvKdeFkuyc0VbiA8SpA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Updated_RebateDetailsList[RowNumber].RebateFieldsBoolean.IsShowRebateAge = False
vars.value.updated_RebateDetailsListInLocal.getItem(vars.value.rowNumberInLocal).rebateFieldsBooleanAttr.isShowRebateAgeAttr = false;
}

}

}

// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g1sDXgJ3yE6uiwP7g0m_8w", callContext.id);
// Out_Updated_RebateDetailsList = Updated_RebateDetailsList
outVars.value.out_Updated_RebateDetailsListOut = vars.value.updated_RebateDetailsListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g1sDXgJ3yE6uiwP7g0m_8w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Out_RebateActionList = RebateActionList
outVars.value.out_RebateActionListOut = vars.value.rebateActionListInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PpwHkwyuB0Kwj4X8DxWz7w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:F1Y_b5gqjUmSEt_ZAPBVIw", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnChange_RebateAction$vars", [{
name: "RebateActionList",
attrName: "rebateActionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Updated_RebateDetailsList",
attrName: "updated_RebateDetailsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RebateDetailsWithValidationList();
},
complexType: PHICoreModel.RebateDetailsWithValidationList
}, {
name: "RowNumber",
attrName: "rowNumberInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnChange_RebateAction$outVars", [{
name: "Out_Updated_RebateDetailsList",
attrName: "out_Updated_RebateDetailsListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RebateDetailsWithValidationList();
},
complexType: PHICoreModel.RebateDetailsWithValidationList
}, {
name: "Out_RebateActionList",
attrName: "out_RebateActionListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}]);
PHICoreController.default.clientActionProxies.onChange_RebateAction$Action = function (rebateActionListIn, updated_RebateDetailsListIn, rowNumberIn) {
rebateActionListIn = (rebateActionListIn === undefined) ? new PHICoreModel.ReferenceDataList() : rebateActionListIn;
updated_RebateDetailsListIn = (updated_RebateDetailsListIn === undefined) ? new PHICoreModel.RebateDetailsWithValidationList() : updated_RebateDetailsListIn;
rowNumberIn = (rowNumberIn === undefined) ? 0 : rowNumberIn;
return controller.executeActionInsideJSNode(PHICoreController.default.onChange_RebateAction$Action.bind(controller, rebateActionListIn, updated_RebateDetailsListIn, OS.DataConversion.JSNodeParamConverter.from(rowNumberIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_Updated_RebateDetailsList: actionResults.out_Updated_RebateDetailsListOut,
Out_RebateActionList: actionResults.out_RebateActionListOut
};
});
};
});

define("PHICore.controller$OnSort_AssociatedRoles", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$PolicyRoleWithContactsList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.onSort_AssociatedRoles$Action = function (stakeholderListSortIn, policyMembersIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_AssociatedRoles$vars"))());
vars.value.stakeholderListSortInLocal = stakeholderListSortIn;
vars.value.policyMembersInLocal = policyMembersIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_AssociatedRoles$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:wc0s9PKwykqgOVdNIJgsHQ:/ClientActionFlows.wc0s9PKwykqgOVdNIJgsHQ:TWsL9XiDr7SdUXQkOHfPsg", "PHICore", "OnSort_AssociatedRoles", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9IpbIgsLpEqiBrnvCofZyg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VykqU451+0+ey9Dgcj57RQ", callContext.id);
// IsAscending = Index = -1
vars.value.isAscendingVar = (OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "DESC", 0, false, true) === -1);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:D6AN1wQD606TVmSfXx5+sg", callContext.id) && ((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "StakeholderId", 0, false, true)) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qgJHoL6EREGJfaSeFbEb6w", callContext.id);
// Execute Action: Sort_StakeholderNo
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.stakeholderIdAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "FullName", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JrrwP1LDm0CJD8G8yya+Aw", callContext.id);
// Execute Action: Sort_MemberName
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.fullNameAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "RoleCode", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aWV0cLlaw0+CEFEhZeHuiQ", callContext.id);
// Execute Action: Sort_RoleCode
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.roleCodeAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Status", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bn8oBZO20kmmbEm3i7eUzA", callContext.id);
// Execute Action: Sort_Status
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.statusAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Address", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:J6r2KHTQLU2s3CiYjb84eg", callContext.id);
// Execute Action: ListSort_Address
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.addressAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "DateOfBirth", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1zE9zYXGHkar0YH3bbU82w", callContext.id);
// Execute Action: ListSort_DateOfBirth
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.dateOfBirthAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Contact", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dDozFQpRRUimZz1h_GUSng", callContext.id);
// Execute Action: ListSort_Contact
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.contactAttr;
}, vars.value.isAscendingVar, callContext);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:msWG6IBXOkWbl2e2THXY_w", callContext.id);
return outVars.value;

}

}

}

}

}

}

}

// Out_PolicyMembers
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dKvf+EVN9EOM_2u3TAfWCg", callContext.id);
// Out_PolicyMembers = PolicyMembers
outVars.value.out_PolicyMembersOut = vars.value.policyMembersInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o9ZCtP0PqEy0Bf_fPhXxNw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:wc0s9PKwykqgOVdNIJgsHQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_AssociatedRoles$vars", [{
name: "StakeholderListSort",
attrName: "stakeholderListSortInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PolicyMembers",
attrName: "policyMembersInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyRoleWithContactsList();
},
complexType: PHICoreModel.PolicyRoleWithContactsList
}, {
name: "IsAscending",
attrName: "isAscendingVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_AssociatedRoles$outVars", [{
name: "Out_PolicyMembers",
attrName: "out_PolicyMembersOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyRoleWithContactsList();
},
complexType: PHICoreModel.PolicyRoleWithContactsList
}]);
PHICoreController.default.clientActionProxies.onSort_AssociatedRoles$Action = function (stakeholderListSortIn, policyMembersIn) {
stakeholderListSortIn = (stakeholderListSortIn === undefined) ? "" : stakeholderListSortIn;
policyMembersIn = (policyMembersIn === undefined) ? new PHICoreModel.PolicyRoleWithContactsList() : policyMembersIn;
return controller.executeActionInsideJSNode(PHICoreController.default.onSort_AssociatedRoles$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stakeholderListSortIn, OS.Types.Text), policyMembersIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_PolicyMembers: actionResults.out_PolicyMembersOut
};
});
};
});

define("PHICore.controller$OnSort_Stakeholders", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$PolicyMemberWithContactsList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.onSort_Stakeholders$Action = function (stakeholderListSortIn, policyMembersIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_Stakeholders$vars"))());
vars.value.stakeholderListSortInLocal = stakeholderListSortIn;
vars.value.policyMembersInLocal = policyMembersIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_Stakeholders$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Z13tDh0JD0inSFeB4tg3tA:/ClientActionFlows.Z13tDh0JD0inSFeB4tg3tA:ekorTMCFlnqL_TGpBCd+6A", "PHICore", "OnSort_Stakeholders", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:raA+CJN1hkeXP+DYM3g9VA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:koVNuUjku0yiK4BGNG6s7Q", callContext.id);
// IsAscending = Index = -1
vars.value.isAscendingVar = (OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "DESC", 0, false, true) === -1);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tW1miUKTdkaata0NuhyeCA", callContext.id) && ((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "StakeholderId", 0, false, true)) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+SsWarpd0G2m5_77heqkQ", callContext.id);
// Execute Action: Sort_StakeholderNo
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.stakeholderIdAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "FullName", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uGguZHmnNkqcFXRpBLA2uw", callContext.id);
// Execute Action: Sort_MemberName
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.fullNameAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Relationship", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f36Kxh_XLUOqvaXPhc5fbw", callContext.id);
// Execute Action: Sort_Relationship
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.relationshipAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "CoverVariation", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MFC0XEbd0kSrqm8QmyM8_w", callContext.id);
// Execute Action: Sort_CoverVariation
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.coverVariationAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Status", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dpc9f6Zt2kK_SaVyCe93tg", callContext.id);
// Execute Action: Sort_Status
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.statusAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "EffectiveDate", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5PC0aa4Ul02G+DToV3SadA", callContext.id);
// Execute Action: Sort_EffectiveDate
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.effectiveDateAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "DateOfBirth", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UhjF3fMcN0i4YV6tG2qW3Q", callContext.id);
// Execute Action: ListSort_DateOfBirth
OS.SystemActions.listSort(vars.value.policyMembersInLocal, function (p) {
return p.dateOfBirthAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(!(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "Contact", 0, false, true)) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VyuSLeRjV02QxTF5YWlvZQ", callContext.id);
return outVars.value;

}

}

}

}

}

}

}

}

// Out_PolicyMembers
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+_jl2EZPa06uwMiHUsmnpQ", callContext.id);
// Out_PolicyMembers = PolicyMembers
outVars.value.out_PolicyMembersOut = vars.value.policyMembersInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VghEYCR3Pk2KiqxvyXXJ7Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Z13tDh0JD0inSFeB4tg3tA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_Stakeholders$vars", [{
name: "StakeholderListSort",
attrName: "stakeholderListSortInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PolicyMembers",
attrName: "policyMembersInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberWithContactsList();
},
complexType: PHICoreModel.PolicyMemberWithContactsList
}, {
name: "IsAscending",
attrName: "isAscendingVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_Stakeholders$outVars", [{
name: "Out_PolicyMembers",
attrName: "out_PolicyMembersOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberWithContactsList();
},
complexType: PHICoreModel.PolicyMemberWithContactsList
}]);
PHICoreController.default.clientActionProxies.onSort_Stakeholders$Action = function (stakeholderListSortIn, policyMembersIn) {
stakeholderListSortIn = (stakeholderListSortIn === undefined) ? "" : stakeholderListSortIn;
policyMembersIn = (policyMembersIn === undefined) ? new PHICoreModel.PolicyMemberWithContactsList() : policyMembersIn;
return controller.executeActionInsideJSNode(PHICoreController.default.onSort_Stakeholders$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stakeholderListSortIn, OS.Types.Text), policyMembersIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_PolicyMembers: actionResults.out_PolicyMembersOut
};
});
};
});

define("PHICore.controller$OnSort_StakeholderTables", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$StakeholderCover_ListList", "PHICore.model$StakeholderCover_ListRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.onSort_StakeholderTables$Action = function (stakeholderListSortIn, processedCoverListIn, startIndexIn, maxRecordsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_StakeholderTables$vars"))());
vars.value.stakeholderListSortInLocal = stakeholderListSortIn;
vars.value.processedCoverListInLocal = processedCoverListIn.clone();
vars.value.startIndexInLocal = startIndexIn;
vars.value.maxRecordsInLocal = maxRecordsIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnSort_StakeholderTables$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:8lHF5+1LbUyVuYwG4x_Fsg:/ClientActionFlows.8lHF5+1LbUyVuYwG4x_Fsg:+v_7nCg6RI04dbkdXnwgMA", "PHICore", "OnSort_StakeholderTables", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kWD4rVEXV0aRlN6Cikc5Yg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U5QAoZCly0ajndGcLzT43w", callContext.id);
// IsAscending = Index = -1
vars.value.isAscendingVar = (OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "DESC", 0, false, true) === -1);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4Ch8kI+iLUSEVgM0_K2dNg", callContext.id) && ((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "policyNumber", 0, false, true)) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TtRPnfW+6kmxRLqA91gXUg", callContext.id);
// Execute Action: ListSort_policyNumber
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.policyNumberAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "class", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wbddFs4uAkC8noSBxOC2AQ", callContext.id);
// Execute Action: ListSort_class
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.classAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "productType", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Mzx+Px4+pkKW15x6zyiZzw", callContext.id);
// Execute Action: ListSort_productType
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.productTypeAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "isCoverVariation", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:u1NuShuxD0W0zOmiExM+9w", callContext.id);
// Execute Action: ListSort_isCoverVariation
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.isCoverVariationAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "role", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_W89FH1UNkiV26wARNKWFg", callContext.id);
// Execute Action: ListSort_role
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.roleAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "status", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5xQ2bhj_yE6RLLNsR9cueg", callContext.id);
// Execute Action: ListSort_status
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.statusAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "startdate", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:10_yThhB+Ua4AMIoLSp2dw", callContext.id);
// Execute Action: ListSort_StartDate
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.startDateAttr;
}, vars.value.isAscendingVar, callContext);
} else {
if(((OS.BuiltinFunctions.index(vars.value.stakeholderListSortInLocal, "productname", 0, false, true)) !== (-1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kdHBYlX4p0q+LOjpJzTWRw", callContext.id);
// Execute Action: ListSort_ProductName
OS.SystemActions.listSort(vars.value.processedCoverListInLocal, function (p) {
return p.coverAttr.productNameAttr;
}, vars.value.isAscendingVar, callContext);
}

}

}

}

}

}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LZZI1vv6FUiOkGTwRZD0Qg", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(outVars.value.displayCoverListOut, callContext);
// Foreach ProcessedCoverList
callContext.iterationContext.registerIterationStart(vars.value.processedCoverListInLocal);
try {var processedCoverListIterator = callContext.iterationContext.getIterator(vars.value.processedCoverListInLocal);
var processedCoverListIndexMax = vars.value.maxRecordsInLocal;
var processedCoverListIndex = vars.value.startIndexInLocal;
while (((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UOPeQGUMTEW+SEU5H5N3TQ", callContext.id) && (processedCoverListIndex < vars.value.processedCoverListInLocal.length)) && (processedCoverListIndexMax > 0))) {
processedCoverListIterator.currentRowNumber = processedCoverListIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dcIH3OUr+0+6FjF4Crj3jA", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.displayCoverListOut, vars.value.processedCoverListInLocal.getItem(processedCoverListIndex.valueOf()), callContext);
processedCoverListIndexMax--;
processedCoverListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.processedCoverListInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b3vu__E+T0aQVUaMCNl1JA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8lHF5+1LbUyVuYwG4x_Fsg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_StakeholderTables$vars", [{
name: "StakeholderListSort",
attrName: "stakeholderListSortInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ProcessedCoverList",
attrName: "processedCoverListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderCover_ListList();
},
complexType: PHICoreModel.StakeholderCover_ListList
}, {
name: "StartIndex",
attrName: "startIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "MaxRecords",
attrName: "maxRecordsInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsAscending",
attrName: "isAscendingVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnSort_StakeholderTables$outVars", [{
name: "DisplayCoverList",
attrName: "displayCoverListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderCover_ListList();
},
complexType: PHICoreModel.StakeholderCover_ListList
}]);
PHICoreController.default.clientActionProxies.onSort_StakeholderTables$Action = function (stakeholderListSortIn, processedCoverListIn, startIndexIn, maxRecordsIn) {
stakeholderListSortIn = (stakeholderListSortIn === undefined) ? "" : stakeholderListSortIn;
processedCoverListIn = (processedCoverListIn === undefined) ? new PHICoreModel.StakeholderCover_ListList() : processedCoverListIn;
startIndexIn = (startIndexIn === undefined) ? 0 : startIndexIn;
maxRecordsIn = (maxRecordsIn === undefined) ? 0 : maxRecordsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.onSort_StakeholderTables$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(stakeholderListSortIn, OS.Types.Text), processedCoverListIn, OS.DataConversion.JSNodeParamConverter.from(startIndexIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(maxRecordsIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
DisplayCoverList: actionResults.displayCoverListOut
};
});
};
});

define("PHICore.controller$OnUpdate_PremiumPayment", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$RatesQuoteBreakdownItemList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.onUpdate_PremiumPayment$Action = function (breakdownIn, premiumsIn, frequencyIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnUpdate_PremiumPayment$vars"))());
vars.value.breakdownInLocal = breakdownIn.clone();
vars.value.premiumsInLocal = premiumsIn.clone();
vars.value.frequencyInLocal = frequencyIn;
var listFilter_NextDueAmountVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.OnUpdate_PremiumPayment$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_NextDueAmountVar = listFilter_NextDueAmountVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Dp3NO2Q+jUyRiiRC+M7jVQ:/ClientActionFlows.Dp3NO2Q+jUyRiiRC+M7jVQ:uw2mX1oeqMwvT5AzcvR17w", "PHICore", "OnUpdate_PremiumPayment", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w28ntl4v6ECsKJLIiyCGtQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pAWZckLo70igRCBANzf31g", callContext.id);
// Execute Action: ListFilter_NextDueAmount
listFilter_NextDueAmountVar.value = OS.SystemActions.listFilter(vars.value.breakdownInLocal, function (p) {
return (p.labelAttr === "Gross");
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vpPdlLe8VUS5wvX55aj8OA", callContext.id) && (vars.value.frequencyInLocal === "Weekly"))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sw7ASSGCcU6yCcUzuwTAaQ", callContext.id);
// PremiumAmount = Premiums.Current.Weekly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).weeklyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
if((vars.value.frequencyInLocal === "Fortnightly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ExqLfW2JhUmq7hHN9ahRvA", callContext.id);
// PremiumAmount = Premiums.Current.Fortnightly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).fortnightlyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
if((vars.value.frequencyInLocal === "Monthly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y09E3pKiAEOdFfmi_7Dqwg", callContext.id);
// PremiumAmount = Premiums.Current.Monthly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).monthlyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
if((vars.value.frequencyInLocal === "Quarterly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:51ItZJzpCUC0HzZY5fonuw", callContext.id);
// PremiumAmount = Premiums.Current.Quarterly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).quarterlyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
if((vars.value.frequencyInLocal === "HalfYearly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tjTfHVpWOEK1mw_sTGIctQ", callContext.id);
// PremiumAmount = Premiums.Current.HalfYearly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).halfYearlyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
if((vars.value.frequencyInLocal === "Yearly")) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qOuaaYmXckSfxu5iEeNTlg", callContext.id);
// PremiumAmount = Premiums.Current.Yearly
outVars.value.premiumAmountOut = vars.value.premiumsInLocal.getCurrent(callContext.iterationContext).yearlyAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddtZIJoarEGYc0cxFoUmOw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:60I4S9OBwkq9TdR7x1K3ZQ", callContext.id);
// PremiumAmount = 0
outVars.value.premiumAmountOut = OS.BuiltinFunctions.integerToDecimal(0);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:m4nvD61zP0CcENkFxDtb3g", callContext.id);
}

}

}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Dp3NO2Q+jUyRiiRC+M7jVQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnUpdate_PremiumPayment$vars", [{
name: "Breakdown",
attrName: "breakdownInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemList();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemList
}, {
name: "Premiums",
attrName: "premiumsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemList();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemList
}, {
name: "Frequency",
attrName: "frequencyInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.OnUpdate_PremiumPayment$outVars", [{
name: "PremiumAmount",
attrName: "premiumAmountOut",
mandatory: false,
dataType: OS.Types.Currency,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
PHICoreController.default.clientActionProxies.onUpdate_PremiumPayment$Action = function (breakdownIn, premiumsIn, frequencyIn) {
breakdownIn = (breakdownIn === undefined) ? new PHICoreModel.RatesQuoteBreakdownItemList() : breakdownIn;
premiumsIn = (premiumsIn === undefined) ? new PHICoreModel.RatesQuoteBreakdownItemList() : premiumsIn;
frequencyIn = (frequencyIn === undefined) ? "" : frequencyIn;
return controller.executeActionInsideJSNode(PHICoreController.default.onUpdate_PremiumPayment$Action.bind(controller, breakdownIn, premiumsIn, OS.DataConversion.JSNodeParamConverter.from(frequencyIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PremiumAmount: OS.DataConversion.JSNodeParamConverter.to(actionResults.premiumAmountOut, OS.Types.Currency)
};
});
};
});

define("PHICore.controller$Parse_RatesQuotesCalculation", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$FrequencyQuoteItemList", "PHICore.model$RatesQuoteBreakdownItemRec", "PHICore.model$RatesQuoteBreakdownItemList", "PHICore.model$RatesQuoteDetailsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.parse_RatesQuotesCalculation$Action = function (productNameIn, ratesQuotesIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Parse_RatesQuotesCalculation$vars"))());
vars.value.productNameInLocal = productNameIn;
vars.value.ratesQuotesInLocal = ratesQuotesIn.clone();
var listFilterMonthlyVar = new OS.DataTypes.VariableHolder();
var listFilterQuarterlyVar = new OS.DataTypes.VariableHolder();
var listFilterHalfYearlyVar = new OS.DataTypes.VariableHolder();
var listFilterFortnightlyVar = new OS.DataTypes.VariableHolder();
var listFilterWeeklyVar = new OS.DataTypes.VariableHolder();
var listFilterYearlyVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Parse_RatesQuotesCalculation$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilterMonthlyVar = listFilterMonthlyVar;
varBag.listFilterQuarterlyVar = listFilterQuarterlyVar;
varBag.listFilterHalfYearlyVar = listFilterHalfYearlyVar;
varBag.listFilterFortnightlyVar = listFilterFortnightlyVar;
varBag.listFilterWeeklyVar = listFilterWeeklyVar;
varBag.listFilterYearlyVar = listFilterYearlyVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:SSZ2NnfrL0epiYK5QcgrFg:/ClientActionFlows.SSZ2NnfrL0epiYK5QcgrFg:sjVmiJdpTDBik1c+wpH+bA", "PHICore", "Parse_RatesQuotesCalculation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eAu9Qr+zKkiOIeRHxwxcQw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kkgqaPVGr02i6ux4dfU+KQ", callContext.id);
// Execute Action: ListFilterWeekly
listFilterWeeklyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "Weekly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:39IrR_gfr0SIFbtD2jQptA", callContext.id);
// Execute Action: ListFilterFortnightly
listFilterFortnightlyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "Fortnightly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ab76DRri7kamkKxUo4CINQ", callContext.id);
// Execute Action: ListFilterMonthly
listFilterMonthlyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "Monthly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3HCGL4q2okG1+jcL7RhkEQ", callContext.id);
// Execute Action: ListFilterQuarterly
listFilterQuarterlyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "Quarterly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y0JcO5hpLk6rMowjIC1K3A", callContext.id);
// Execute Action: ListFilterHalfYearly
listFilterHalfYearlyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "HalfYearly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o9cRkYKdMEa9Ey25I+VEsQ", callContext.id);
// Execute Action: ListFilterYearly
listFilterYearlyVar.value = OS.SystemActions.listFilter(vars.value.ratesQuotesInLocal, function (p) {
return (p.contributionFrequencyAttr === "Yearly");
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id);
// BreakdownItem.Label = ProductName
vars.value.breakdownItemVar.labelAttr = vars.value.productNameInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// BreakdownItem.Weekly = ListFilterWeekly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// BreakdownItem.Fortnightly = ListFilterFortnightly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// BreakdownItem.Monthly = ListFilterMonthly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// BreakdownItem.Quarterly = ListFilterQuarterly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// BreakdownItem.HalfYearly = ListFilterHalfYearly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// BreakdownItem.Yearly = ListFilterYearly.FilteredList.Current.PremiumAmount
vars.value.breakdownItemVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).premiumAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Details.LHCLoadingPercentage = RatesQuotes.Current.LhcLoadingPercentage
outVars.value.detailsOut.lHCLoadingPercentageAttr = vars.value.ratesQuotesInLocal.getCurrent(callContext.iterationContext).lhcLoadingPercentageAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Details.RebatePercentage = RatesQuotes.Current.RebatePercentage
outVars.value.detailsOut.rebatePercentageAttr = vars.value.ratesQuotesInLocal.getCurrent(callContext.iterationContext).rebatePercentageAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QnIaD1kmtE+8lvMU+IgRRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Details.AbdPercentage = RatesQuotes.Current.AbdPercentage
outVars.value.detailsOut.abdPercentageAttr = vars.value.ratesQuotesInLocal.getCurrent(callContext.iterationContext).abdPercentageAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4TjwHzd_JkaZR0JSfIBuDg", callContext.id);
// Execute Action: ListAppendPremium
OS.SystemActions.listAppend(outVars.value.premiumsOut, vars.value.breakdownItemVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id);
// Gross.Label = "Gross"
vars.value.grossVar.labelAttr = "Gross";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Gross.Weekly = ListFilterWeekly.FilteredList.Current.GrossAmount
vars.value.grossVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Gross.Fortnightly = ListFilterFortnightly.FilteredList.Current.GrossAmount
vars.value.grossVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Gross.Monthly = ListFilterMonthly.FilteredList.Current.GrossAmount
vars.value.grossVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Gross.Quarterly = ListFilterQuarterly.FilteredList.Current.GrossAmount
vars.value.grossVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Gross.HalfYearly = ListFilterHalfYearly.FilteredList.Current.GrossAmount
vars.value.grossVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Gross.Yearly = ListFilterYearly.FilteredList.Current.GrossAmount
vars.value.grossVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).grossAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Discount.Label = "Discount"
vars.value.discountVar.labelAttr = "Discount";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Discount.Weekly = ListFilterWeekly.FilteredList.Current.DiscountAmount
vars.value.discountVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Discount.Fortnightly = ListFilterFortnightly.FilteredList.Current.DiscountAmount
vars.value.discountVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Discount.Monthly = ListFilterMonthly.FilteredList.Current.DiscountAmount
vars.value.discountVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// Discount.Quarterly = ListFilterQuarterly.FilteredList.Current.DiscountAmount
vars.value.discountVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// Discount.HalfYearly = ListFilterHalfYearly.FilteredList.Current.DiscountAmount
vars.value.discountVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// Discount.Yearly = ListFilterYearly.FilteredList.Current.DiscountAmount
vars.value.discountVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).discountAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "15");
// ABD.Label = "Age Based Discount (ABD)"
vars.value.aBDVar.labelAttr = "Age Based Discount (ABD)";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "16");
// ABD.Weekly = ListFilterWeekly.FilteredList.Current.AbdAmount
vars.value.aBDVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "17");
// ABD.Fortnightly = ListFilterFortnightly.FilteredList.Current.AbdAmount
vars.value.aBDVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "18");
// ABD.Monthly = ListFilterMonthly.FilteredList.Current.AbdAmount
vars.value.aBDVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "19");
// ABD.Quarterly = ListFilterQuarterly.FilteredList.Current.AbdAmount
vars.value.aBDVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "20");
// ABD.HalfYearly = ListFilterHalfYearly.FilteredList.Current.AbdAmount
vars.value.aBDVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "21");
// ABD.Yearly = ListFilterYearly.FilteredList.Current.AbdAmount
vars.value.aBDVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).abdAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "22");
// LHCLoading.Label = "LHC Loading"
vars.value.lHCLoadingVar.labelAttr = "LHC Loading";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "23");
// LHCLoading.Weekly = ListFilterWeekly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "24");
// LHCLoading.Fortnightly = ListFilterFortnightly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "25");
// LHCLoading.Monthly = ListFilterMonthly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "26");
// LHCLoading.Quarterly = ListFilterQuarterly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "27");
// LHCLoading.HalfYearly = ListFilterHalfYearly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "28");
// LHCLoading.Yearly = ListFilterYearly.FilteredList.Current.LhcLoadingAmount
vars.value.lHCLoadingVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).lhcLoadingAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "29");
// Rebatable.Label = "Rebatable"
vars.value.rebatableVar.labelAttr = "Rebatable";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "30");
// Rebate.Label = "Rebate"
vars.value.rebateVar.labelAttr = "Rebate";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "31");
// Rebate.Weekly = ListFilterWeekly.FilteredList.Current.RebateAmount
vars.value.rebateVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "32");
// Rebate.Fortnightly = ListFilterFortnightly.FilteredList.Current.RebateAmount
vars.value.rebateVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "33");
// Rebate.Monthly = ListFilterMonthly.FilteredList.Current.RebateAmount
vars.value.rebateVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "34");
// Rebate.Quarterly = ListFilterQuarterly.FilteredList.Current.RebateAmount
vars.value.rebateVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "35");
// Rebate.HalfYearly = ListFilterHalfYearly.FilteredList.Current.RebateAmount
vars.value.rebateVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "36");
// Rebate.Yearly = ListFilterYearly.FilteredList.Current.RebateAmount
vars.value.rebateVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).rebateAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "37");
// Subsidy.Label = "Subsidy"
vars.value.subsidyVar.labelAttr = "Subsidy";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "38");
// Subsidy.Weekly = ListFilterWeekly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.weeklyAttr = listFilterWeeklyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "39");
// Subsidy.Fortnightly = ListFilterFortnightly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.fortnightlyAttr = listFilterFortnightlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "40");
// Subsidy.Monthly = ListFilterMonthly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.monthlyAttr = listFilterMonthlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "41");
// Subsidy.Quarterly = ListFilterQuarterly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.quarterlyAttr = listFilterQuarterlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "42");
// Subsidy.HalfYearly = ListFilterHalfYearly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.halfYearlyAttr = listFilterHalfYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:peaebr2c302n4AZ4VIKpWg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "43");
// Subsidy.Yearly = ListFilterYearly.FilteredList.Current.SubsidyAmount
vars.value.subsidyVar.yearlyAttr = listFilterYearlyVar.value.filteredListOut.getCurrent(callContext.iterationContext).subsidyAmountAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L5HwshLM6kGOp1uIIyFLNA", callContext.id);
// Execute Action: ListAppendGross
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.grossVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FYk3gHjLlUOpQw57FuoD4Q", callContext.id);
// Execute Action: ListAppendDiscount
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.discountVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sRWva6P1AEOKWJi8LS2qTQ", callContext.id);
// Execute Action: ListAppendABD
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.aBDVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5TXEdxkBKUa76AtF07ZjXQ", callContext.id);
// Execute Action: ListAppendLHCLoading
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.lHCLoadingVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SbeLySWy3kW7AlerVCRC0g", callContext.id);
// Execute Action: ListAppendRebatable
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.rebatableVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ddmu9iBntEOyYTCFlTU9Zg", callContext.id);
// Execute Action: ListAppendRebate
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.rebateVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TWJmv_6HYUeGgMmiyv42xw", callContext.id);
// Execute Action: ListAppendSubsidy
OS.SystemActions.listAppend(outVars.value.breakdownOut, vars.value.subsidyVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7PUNlIsACUC6_yKtroWSPg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:SSZ2NnfrL0epiYK5QcgrFg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Parse_RatesQuotesCalculation$vars", [{
name: "ProductName",
attrName: "productNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "RatesQuotes",
attrName: "ratesQuotesInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.FrequencyQuoteItemList();
},
complexType: PHICoreModel.FrequencyQuoteItemList
}, {
name: "BreakdownItem",
attrName: "breakdownItemVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "Gross",
attrName: "grossVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "Discount",
attrName: "discountVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "ABD",
attrName: "aBDVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "LHCLoading",
attrName: "lHCLoadingVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "Rebatable",
attrName: "rebatableVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "Rebate",
attrName: "rebateVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}, {
name: "Subsidy",
attrName: "subsidyVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemRec();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Parse_RatesQuotesCalculation$outVars", [{
name: "Premiums",
attrName: "premiumsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemList();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemList
}, {
name: "Details",
attrName: "detailsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RatesQuoteDetailsRec();
},
complexType: PHICoreModel.RatesQuoteDetailsRec
}, {
name: "Breakdown",
attrName: "breakdownOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RatesQuoteBreakdownItemList();
},
complexType: PHICoreModel.RatesQuoteBreakdownItemList
}]);
PHICoreController.default.clientActionProxies.parse_RatesQuotesCalculation$Action = function (productNameIn, ratesQuotesIn) {
productNameIn = (productNameIn === undefined) ? "" : productNameIn;
ratesQuotesIn = (ratesQuotesIn === undefined) ? new PHICoreModel.FrequencyQuoteItemList() : ratesQuotesIn;
return controller.executeActionInsideJSNode(PHICoreController.default.parse_RatesQuotesCalculation$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(productNameIn, OS.Types.Text), ratesQuotesIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Premiums: actionResults.premiumsOut,
Details: actionResults.detailsOut,
Breakdown: actionResults.breakdownOut
};
});
};
});

define("PHICore.controller$PatchPolicy", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "PHICore.clientVariables", "PHICore.model$PolicyPatchRec", "PHICore.model$PolicyMemberList", "PHICore.controller$ServerAction.Policy_Patch", "APIGateway_IS.model$AddPolicy_APIRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "APIGateway_IS.model$FrequencyQuoteItemRec", "APIGateway_IS.model$WaitingPeriodRec", "PHICore.model$PolicyRec", "PHICore.model$PolicyMemberRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.patchPolicy$Action = function (policyNumberIn, policyIn, requestIn, modifiedPrimaryMemberIn, modifiedAdditionalMembersIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.PatchPolicy$vars"))());
vars.value.policyNumberInLocal = policyNumberIn;
vars.value.policyInLocal = policyIn.clone();
vars.value.requestInLocal = requestIn.clone();
vars.value.modifiedPrimaryMemberInLocal = modifiedPrimaryMemberIn.clone();
vars.value.modifiedAdditionalMembersInLocal = modifiedAdditionalMembersIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:K8hSDTkKb0GVo1EVISx9bw:/ClientActionFlows.K8hSDTkKb0GVo1EVISx9bw:noCExGhx5XxnFqbceLGg1A", "PHICore", "PatchPolicy", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_04OXuB3+kye4oipVvKMYA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kBQK79HK9E2M52PcWZURXQ", callContext.id);
// Execute Action: ListAppend_ModifiedMembers
OS.SystemActions.listAppend(vars.value.originalMembersVar, vars.value.policyInLocal.primaryMemberAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C0NT8P9Qh0G4m+t6RS_Xxg", callContext.id);
// Execute Action: ListAppendAll_ModifiedMembers
OS.SystemActions.listAppendAll(vars.value.modifiedMembersVar, vars.value.policyInLocal.additionalMembersAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NXuhmm67HUasngZSI6AY_g", callContext.id);
// Execute Action: ListAppend_OriginalMembers
OS.SystemActions.listAppend(vars.value.modifiedMembersVar, vars.value.policyInLocal.primaryMemberAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:izwNRH21KEeQYxV5woOtQg", callContext.id);
// Execute Action: ListAppendAll_OriginalMembers
OS.SystemActions.listAppendAll(vars.value.originalMembersVar, vars.value.policyInLocal.additionalMembersAttr, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HyaKJuiRZUq+vEGCWXDPXQ", callContext.id);
// Execute Action: Policy_Patch
return controller.policy_Patch$ServerAction(OS.BuiltinFunctions.longIntegerToInteger(vars.value.policyNumberInLocal), OS.DataConversion.JSConversions.typeConvertRecord(vars.value.policyInLocal, new PHICoreModel.PolicyPatchRec(), function (source, target) {
target.startDateAttr = source.basicDetailsAttr.startDateAttr;
target.entryDateAttr = source.basicDetailsAttr.effectiveDateAttr;
target.startDateOtherAttr = source.basicDetailsAttr.startDateAttr;
target.entryDateOtherAttr = OS.BuiltinFunctions.currDate();
target.stateTerritoryCodeAttr = source.basicDetailsAttr.stateAttr.codeAttr;
target.privacyStatementAttr = source.basicDetailsAttr.hasAgreedToPrivacyStatementAttr;
target.groupCodeAttr = source.basicDetailsAttr.groupAttr.stakeholderIdAttr;
target.branchCodeAttr = source.basicDetailsAttr.branchAttr.codeAttr;
target.agentCodeAttr = source.basicDetailsAttr.agentAttr.stakeholderIdAttr;
target.locationCodeAttr = source.basicDetailsAttr.locationAttr.codeAttr;
target.siteCodeAttr = source.basicDetailsAttr.siteAttr.codeAttr;
target.productTierCodeAttr = source.productOptionsAttr.productTierAttr.keyAttr;
target.productNameAttr = source.productOptionsAttr.productNameAttr.keyAttr;
target.rateScaleCodeAttr = source.productOptionsAttr.rateScaleAttr.keyAttr;
target.otherProductNameAttr = source.productOptionsAttr.otherProductNameAttr.keyAttr;
target.otherRateScaleCodeAttr = source.productOptionsAttr.otherRateScaleAttr.keyAttr;
target.coverContinuityDateAttr = source.productOptionsAttr.coverContinuityDateAttr;
target.waitingPeriodAttr.applyVariationToAttr = source.premiumPaymentAttr.waitingPeriodListAttr.getCurrent(callContext.iterationContext).isWaivedAttr;
target.waitingPeriodAttr.waitingPeriodStatusAttr = source.premiumPaymentAttr.waitingPeriodListAttr.getCurrent(callContext.iterationContext).statusAttr;
target.waitingPeriodAttr.reasonForVariationCodeAttr = source.premiumPaymentAttr.variationReasonAttr.codeAttr;
target.eligibilityReasonAttr.effectiveDateAttr = source.basicDetailsAttr.effectiveDateAttr;
target.eligibilityReasonAttr.reasonCodeAttr = source.basicDetailsAttr.eligibilityReasonAttr.codeAttr;
target.eligibilityReasonAttr.subReasonCodeAttr = source.basicDetailsAttr.eligibilitySubReasonAttr.codeAttr;
target.premiumDetailsAttr.contributionFrequencyAttr = source.productOptionsAttr.contributionFrequencyAttr;
target.premiumDetailsAttr.paidToDateAttr = source.premiumPaymentAttr.paidToDateAttr;
target.premiumDetailsAttr.debitOnDateAttr = source.premiumPaymentAttr.debitOnDateAttr;
target.premiumDetailsAttr.billCycleDateAttr = source.premiumPaymentAttr.billCycleDateAttr;
target.premiumDetailsAttr.premiumDueDateAttr = source.premiumPaymentAttr.premiumDueDateAttr;
target.premiumDetailsAttr.rateFreezeDateAttr = source.productOptionsAttr.rateFreezeDateAttr;
target.premiumDetailsAttr.theoreticalPaidToDateAttr = source.premiumPaymentAttr.theoreticalPaidToDateAttr;
return target;
}), OS.DataConversion.JSConversions.typeConvertRecord(vars.value.requestInLocal, new PHICoreModel.PolicyPatchRec(), function (source, target) {
target.startDateAttr = source.startDateAttr;
target.entryDateAttr = source.entryDateAttr;
target.startDateOtherAttr = source.startDateOtherAttr;
target.entryDateOtherAttr = source.entryDateOtherAttr;
target.stateTerritoryCodeAttr = source.stateTerritoryCodeAttr;
target.privacyStatementAttr = source.privacyStatementAttr;
target.groupCodeAttr = source.groupCodeAttr;
target.branchCodeAttr = source.branchCodeAttr;
target.agentCodeAttr = source.agentCodeAttr;
target.locationCodeAttr = source.locationCodeAttr;
target.siteCodeAttr = source.siteCodeAttr;
target.productTierCodeAttr = source.productTierCodeAttr;
target.productNameAttr = source.productNameAttr;
target.rateScaleCodeAttr = source.rateScaleCodeAttr;
target.otherProductNameAttr = source.otherProductNameAttr;
target.otherRateScaleCodeAttr = source.otherRateScaleCodeAttr;
target.coverContinuityDateAttr = source.coverContinuityDateAttr;
target.waitingPeriodAttr = source.waitingPeriodAttr;
target.eligibilityReasonAttr.effectiveDateAttr = source.policyEligibilityReasonAttr.effectiveDateAttr;
target.eligibilityReasonAttr.reasonCodeAttr = source.policyEligibilityReasonAttr.reasonCodeAttr;
target.eligibilityReasonAttr.subReasonCodeAttr = source.policyEligibilityReasonAttr.subReasonCodeAttr;
target.eligibilityReasonAttr.commentAttr = source.policyEligibilityReasonAttr.commentAttr;
target.rebateAttr.rebateActionAttr = source.policyRebateAttr.rebateActionAttr;
target.rebateAttr.effectiveDateAttr = source.policyRebateAttr.effectiveDateAttr;
target.rebateAttr.previousFundCodeAttr = source.policyRebateAttr.previousFundCodeAttr;
target.premiumDetailsAttr = source.policyPremiumDetailsAttr;
target.immediatePaymentAttr.payNextPaymentAttr = source.policyImmediatePaymentAttr.payNextPaymentAttr;
target.immediatePaymentAttr.payOtherAmountAttr = source.policyImmediatePaymentAttr.payOtherAmountAttr;
target.immediatePaymentAttr.paymentMethodAttr = source.policyImmediatePaymentAttr.paymentMethodAttr;
target.immediatePaymentAttr.addAnotherCardAttr = source.policyImmediatePaymentAttr.addAnotherCardAttr;
target.immediatePaymentAttr.useCardForDirectDebitAttr = source.policyImmediatePaymentAttr.useCardForDirectDebitAttr;
return target;
}), vars.value.originalMembersVar, vars.value.modifiedMembersVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bflh0Q0GDkWSmV_l35i0Wg", callContext.id);
});
}).then(function () {
return ;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:K8hSDTkKb0GVo1EVISx9bw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:K8hSDTkKb0GVo1EVISx9bw", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.PatchPolicy$vars", [{
name: "PolicyNumber",
attrName: "policyNumberInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "Policy",
attrName: "policyInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyRec();
},
complexType: PHICoreModel.PolicyRec
}, {
name: "Request",
attrName: "requestInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.AddPolicy_APIRec();
},
complexType: APIGateway_ISModel.AddPolicy_APIRec
}, {
name: "ModifiedPrimaryMember",
attrName: "modifiedPrimaryMemberInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyMemberRec();
},
complexType: PHICoreModel.PolicyMemberRec
}, {
name: "ModifiedAdditionalMembers",
attrName: "modifiedAdditionalMembersInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberList();
},
complexType: PHICoreModel.PolicyMemberList
}, {
name: "OriginalMembers",
attrName: "originalMembersVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberList();
},
complexType: PHICoreModel.PolicyMemberList
}, {
name: "ModifiedMembers",
attrName: "modifiedMembersVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyMemberList();
},
complexType: PHICoreModel.PolicyMemberList
}]);
PHICoreController.default.clientActionProxies.patchPolicy$Action = function (policyNumberIn, policyIn, requestIn, modifiedPrimaryMemberIn, modifiedAdditionalMembersIn) {
policyNumberIn = (policyNumberIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : policyNumberIn;
policyIn = (policyIn === undefined) ? new PHICoreModel.PolicyRec() : policyIn;
requestIn = (requestIn === undefined) ? new APIGateway_ISModel.AddPolicy_APIRec() : requestIn;
modifiedPrimaryMemberIn = (modifiedPrimaryMemberIn === undefined) ? new PHICoreModel.PolicyMemberRec() : modifiedPrimaryMemberIn;
modifiedAdditionalMembersIn = (modifiedAdditionalMembersIn === undefined) ? new PHICoreModel.PolicyMemberList() : modifiedAdditionalMembersIn;
return controller.executeActionInsideJSNode(PHICoreController.default.patchPolicy$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(policyNumberIn, OS.Types.LongInteger), policyIn, requestIn, modifiedPrimaryMemberIn, modifiedAdditionalMembersIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("PHICore.controller$Policy_CreateCase", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CS.model", "PHICore.clientVariables", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CS", "PHICore.controller$ServerAction.CreateOrUpdate_PolicyWaitingPeriodsCase"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.policy_CreateCase$Action = function (isNewIn, policyIdIn, stakeholderIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Policy_CreateCase$vars"))());
vars.value.isNewInLocal = isNewIn;
vars.value.policyIdInLocal = policyIdIn;
vars.value.stakeholderIdInLocal = stakeholderIdIn;
var createOrUpdate_PolicyWaitingPeriodsCaseVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Policy_CreateCase$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.createOrUpdate_PolicyWaitingPeriodsCaseVar = createOrUpdate_PolicyWaitingPeriodsCaseVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:X76yK0n+pUKKmGYDtTiw9Q:/ClientActionFlows.X76yK0n+pUKKmGYDtTiw9Q:lqkSVa1gkqrgWyO6EPjDVQ", "PHICore", "Policy_CreateCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IFZzDvMKX0SC3w4kWKGKGA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RHmupiXFKUKIyNravvC8Jg", callContext.id);
// Execute Action: CreateOrUpdate_PolicyWaitingPeriodsCase
return controller.createOrUpdate_PolicyWaitingPeriodsCase$ServerAction(vars.value.policyIdInLocal, vars.value.stakeholderIdInLocal, "WPA", vars.value.isNewInLocal, callContext).then(function (value) {
createOrUpdate_PolicyWaitingPeriodsCaseVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JeUEkceByEmH0LzaMMsoRQ", callContext.id);
// CaseId = CreateOrUpdate_PolicyWaitingPeriodsCase.CaseId
outVars.value.caseIdOut = createOrUpdate_PolicyWaitingPeriodsCaseVar.value.caseIdOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C_OSpnKqI0iLmn6X6SbQCw", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:X76yK0n+pUKKmGYDtTiw9Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:X76yK0n+pUKKmGYDtTiw9Q", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Policy_CreateCase$vars", [{
name: "IsNew",
attrName: "isNewInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "PolicyId",
attrName: "policyIdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "StakeholderId",
attrName: "stakeholderIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Policy_CreateCase$outVars", [{
name: "CaseId",
attrName: "caseIdOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.policy_CreateCase$Action = function (isNewIn, policyIdIn, stakeholderIdIn) {
isNewIn = (isNewIn === undefined) ? false : isNewIn;
policyIdIn = (policyIdIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : policyIdIn;
stakeholderIdIn = (stakeholderIdIn === undefined) ? "" : stakeholderIdIn;
return controller.executeActionInsideJSNode(PHICoreController.default.policy_CreateCase$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isNewIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(policyIdIn, OS.Types.LongInteger), OS.DataConversion.JSNodeParamConverter.from(stakeholderIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
CaseId: OS.DataConversion.JSNodeParamConverter.to(actionResults.caseIdOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$Separate_PrimaryMember", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "PHICore.clientVariables", "PHICore.model$MemberItemList", "APIGateway_IS.model$MemberItemRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.separate_PrimaryMember$Action = function (membersIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Separate_PrimaryMember$vars"))());
vars.value.membersInLocal = membersIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Separate_PrimaryMember$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:eiWQjiHT0kSdPvMGPm0kVQ:/ClientActionFlows.eiWQjiHT0kSdPvMGPm0kVQ:kAonzzhUR+S3e9UzVHehHA", "PHICore", "Separate_PrimaryMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ttiK88UcIEW0I+BOV2jrpQ", callContext.id);
// Foreach Members
callContext.iterationContext.registerIterationStart(vars.value.membersInLocal);
try {var membersIterator = callContext.iterationContext.getIterator(vars.value.membersInLocal);
var membersIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4N3lev2n7k6QifTy+N6Nog", callContext.id) && (membersIndex < vars.value.membersInLocal.length))) {
membersIterator.currentRowNumber = membersIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:T1fMOPQ6u0u5_juxLg03XA", callContext.id) && (vars.value.membersInLocal.getCurrentRowNumber(callContext.iterationContext) === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wAJW0oSB40Sr+yw1i5PMZw", callContext.id);
// PrimaryMember = Members.Current
outVars.value.primaryMemberOut = vars.value.membersInLocal.getItem(membersIndex.valueOf());
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7SXw5C9xV0icDhKV6v3Mwg", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.otherMembersOut, vars.value.membersInLocal.getItem(membersIndex.valueOf()), callContext);
}

membersIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.membersInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qYPk7x9nhU6vreA35sth2g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:eiWQjiHT0kSdPvMGPm0kVQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Separate_PrimaryMember$vars", [{
name: "Members",
attrName: "membersInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberItemList();
},
complexType: PHICoreModel.MemberItemList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Separate_PrimaryMember$outVars", [{
name: "PrimaryMember",
attrName: "primaryMemberOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.MemberItemRec();
},
complexType: APIGateway_ISModel.MemberItemRec
}, {
name: "OtherMembers",
attrName: "otherMembersOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberItemList();
},
complexType: PHICoreModel.MemberItemList
}]);
PHICoreController.default.clientActionProxies.separate_PrimaryMember$Action = function (membersIn) {
membersIn = (membersIn === undefined) ? new PHICoreModel.MemberItemList() : membersIn;
return controller.executeActionInsideJSNode(PHICoreController.default.separate_PrimaryMember$Action.bind(controller, membersIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PrimaryMember: actionResults.primaryMemberOut,
OtherMembers: actionResults.otherMembersOut
};
});
};
});

define("PHICore.controller$Stakeholder_Success_Assign_Values", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "PHICore.clientVariables", "PHICore.model$StakeholderAddressList", "PHICore.model$AddressesList", "PHICore.model$StakeholderEmailList", "PHICore.model$StakeholderPhoneList", "PHICore.model$PhoneNumberItemList", "APIGateway_IS.model$PHILeadCommunicationPreferenceRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "APIGateway_IS.model$CommunicationPreferenceItemRec", "PHICore.model$InterestLevel_StructRec", "APIGateway_IS.model$LeadItemRec", "PHICore.model$EmailsList", "APIGateway_IS.model$AddLead_APIRequestRec", "PHICore.model$PersonalDetails_StructRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.stakeholder_Success_Assign_Values$Action = function (isUpdateIn, stakeholderRecordIn, phoneList_HandlerIn, emailList_HandlerIn, addressList_HandlerIn, personalDetails_HandlerIn, interestLevel_HandlerIn, communicationPreference_HandlerIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Stakeholder_Success_Assign_Values$vars"))());
vars.value.isUpdateInLocal = isUpdateIn;
vars.value.stakeholderRecordInLocal = stakeholderRecordIn.clone();
vars.value.phoneList_HandlerInLocal = phoneList_HandlerIn.clone();
vars.value.emailList_HandlerInLocal = emailList_HandlerIn.clone();
vars.value.addressList_HandlerInLocal = addressList_HandlerIn.clone();
vars.value.personalDetails_HandlerInLocal = personalDetails_HandlerIn.clone();
vars.value.interestLevel_HandlerInLocal = interestLevel_HandlerIn.clone();
vars.value.communicationPreference_HandlerInLocal = communicationPreference_HandlerIn.clone();
var activeAddressListVar = new OS.DataTypes.VariableHolder();
var activeEmailListVar = new OS.DataTypes.VariableHolder();
var activePhoneListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Stakeholder_Success_Assign_Values$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.activeAddressListVar = activeAddressListVar;
varBag.activeEmailListVar = activeEmailListVar;
varBag.activePhoneListVar = activePhoneListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:JneBcj+7AkyP_NoB8wCmcg:/ClientActionFlows.JneBcj+7AkyP_NoB8wCmcg:LlP0AFdL+fB1V4tTTxh_WA", "PHICore", "Stakeholder_Success_Assign_Values", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:89zJPFXTx0GS6VksIxZASg", callContext.id);
// Personal Details
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id);
// StakeholderRecord.FirstName = PersonalDetails_Handler.firstName
vars.value.stakeholderRecordInLocal.firstNameAttr = vars.value.personalDetails_HandlerInLocal.firstNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// StakeholderRecord.MiddleName = PersonalDetails_Handler.middleName
vars.value.stakeholderRecordInLocal.middleNameAttr = vars.value.personalDetails_HandlerInLocal.middleNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// StakeholderRecord.LastName = PersonalDetails_Handler.lastName
vars.value.stakeholderRecordInLocal.lastNameAttr = vars.value.personalDetails_HandlerInLocal.lastNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// StakeholderRecord.PreferredName = PersonalDetails_Handler.preferredName
vars.value.stakeholderRecordInLocal.preferredNameAttr = vars.value.personalDetails_HandlerInLocal.preferredNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// StakeholderRecord.PronounsCode = PersonalDetails_Handler.pronounsCode
vars.value.stakeholderRecordInLocal.pronounsCodeAttr = vars.value.personalDetails_HandlerInLocal.pronounsCodeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LaglL2WiIUmZ8+KM+OErvA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// StakeholderRecord.PronounsOther = PersonalDetails_Handler.OtherPronounValue
vars.value.stakeholderRecordInLocal.pronounsOtherAttr = vars.value.personalDetails_HandlerInLocal.otherPronounValueAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PZZTN3f7p0CP_XNsn1NqDw", callContext.id);
// Execute Action: ActiveEmailList
activeEmailListVar.value = OS.SystemActions.listFilter(vars.value.emailList_HandlerInLocal, function (p) {
return p.isActiveAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8cPh77fUP0GSBvJNLL8Z9w", callContext.id);
// StakeholderRecord.Emails = ActiveEmailList.FilteredList
vars.value.stakeholderRecordInLocal.emailsAttr = OS.DataConversion.JSConversions.typeConvertRecordList(activeEmailListVar.value.filteredListOut, new PHICoreModel.EmailsList(), function (source, target) {
target.emailAddressAttr = source.emailAddressAttr;
target.isActiveAttr = source.isActiveAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:E0o6dSoTjkmQDhxrTU4OlA", callContext.id);
// Execute Action: ActivePhoneList
activePhoneListVar.value = OS.SystemActions.listFilter(vars.value.phoneList_HandlerInLocal, function (p) {
return p.isActiveAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LCrL1PGImk2WlmLL87O7iA", callContext.id);
// StakeholderRecord.Phones = ActivePhoneList.FilteredList
vars.value.stakeholderRecordInLocal.phonesAttr = OS.DataConversion.JSConversions.typeConvertRecordList(activePhoneListVar.value.filteredListOut, new PHICoreModel.PhoneNumberItemList(), function (source, target) {
target.typeAttr = source.typeAttr;
target.isActiveAttr = source.isActiveAttr;
target.isOverseasAttr = source.isOverseasAttr;
target.isPreferredAttr = source.isPreferredAttr;
target.phoneNumberAttr = (source.countryCodeAttr.codeAttr + source.phoneNumberAttr);
return target;
});
// Foreach StakeholderRecord.Phones
callContext.iterationContext.registerIterationStart(vars.value.stakeholderRecordInLocal.phonesAttr);
try {var phonesIterator = callContext.iterationContext.getIterator(vars.value.stakeholderRecordInLocal.phonesAttr);
var phonesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3O7ziQaPxU2jx7S_TWqE5w", callContext.id) && (phonesIndex < vars.value.stakeholderRecordInLocal.phonesAttr.length))) {
phonesIterator.currentRowNumber = phonesIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MiHDtPXRFUmgK41W1WnKeg", callContext.id) && (OS.BuiltinFunctions.index(vars.value.stakeholderRecordInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr, "+", 0, false, false) < 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rvvJodDJFEW1nfHy3bfWcQ", callContext.id);
// StakeholderRecord.Phones.Current.PhoneNumber = "+" + StakeholderRecord.Phones.Current.PhoneNumber
vars.value.stakeholderRecordInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr = ("+" + vars.value.stakeholderRecordInLocal.phonesAttr.getItem(phonesIndex.valueOf()).phoneNumberAttr);
}

phonesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.stakeholderRecordInLocal.phonesAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WFaGGl7ohE+Iqty4UFMVRQ", callContext.id);
// Execute Action: ActiveAddressList
activeAddressListVar.value = OS.SystemActions.listFilter(vars.value.addressList_HandlerInLocal, function (p) {
return p.isActiveAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kntTFqxxREml_ivvwn+9qA", callContext.id);
// StakeholderRecord.Addresses = ActiveAddressList.FilteredList
vars.value.stakeholderRecordInLocal.addressesAttr = OS.DataConversion.JSConversions.typeConvertRecordList(activeAddressListVar.value.filteredListOut, new PHICoreModel.AddressesList(), function (source, target) {
target.countryCodeAttr = source.countryCodeAttr;
target.effectiveDateAttr = source.effectiveDateAttr;
target.line1Attr = source.line1Attr;
target.typeAttr = source.typeAttr;
target.line2Attr = source.line2Attr;
target.suburbAttr = source.suburbAttr;
target.stateTerritoryCodeAttr = source.stateTerritoryCodeAttr;
target.postcodeAttr = source.postcodeAttr;
target.isOverseasAttr = source.isOverseasAttr;
target.cityAttr = source.cityAttr;
target.stateProvinceAttr = source.stateProvinceAttr;
target.zipPostalCodeAttr = source.zipPostalCodeAttr;
return target;
});
// Interest Level
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xLc_5LUV9kuelWH4qd+QUw", callContext.id);
// StakeholderRecord.InterestLevel = InterestLevel_Handler
vars.value.stakeholderRecordInLocal.interestLevelAttr = OS.DataConversion.JSConversions.typeConvertRecord(vars.value.interestLevel_HandlerInLocal, new APIGateway_ISModel.LeadItemRec(), function (source, target) {
target.entryDateTimeAttr = source.entryDateTimeAttr;
target.interestLevelCodeAttr = source.interestLevelCodeAttr;
target.isFollowUpAttr = source.isFollowUpAttr;
target.followUpDueDateAttr = source.followUpDueDateAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xLc_5LUV9kuelWH4qd+QUw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// StakeholderRecord.InterestLevel.EntryDateTime = If
vars.value.stakeholderRecordInLocal.interestLevelAttr.entryDateTimeAttr = ((vars.value.isUpdateInLocal) ? (vars.value.stakeholderRecordInLocal.interestLevelAttr.entryDateTimeAttr) : (OS.BuiltinFunctions.currDateTime()));
// Communication Preference
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l5UT32EKDECDBXSwQb+NPA", callContext.id);
// StakeholderRecord.CommunicationPreference = CommunicationPreference_Handler
vars.value.stakeholderRecordInLocal.communicationPreferenceAttr = OS.DataConversion.JSConversions.typeConvertRecord(vars.value.communicationPreference_HandlerInLocal, new APIGateway_ISModel.CommunicationPreferenceItemRec(), function (source, target) {
target.isMandatoryAttr = source.isMandatoryAttr;
target.categoryCodeAttr = source.categoryCodeAttr;
target.preferredChannelAttr = source.preferredChannelAttr;
target.sendCommunicationsAttr = source.isSendCommunicationsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sugB_pnpfUSEq9yN5CiMsg", callContext.id);
// StakeholderRecord_Out = StakeholderRecord
outVars.value.stakeholderRecord_OutOut = vars.value.stakeholderRecordInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pcWictyYlkmUxEcHt7mJnA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JneBcj+7AkyP_NoB8wCmcg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Stakeholder_Success_Assign_Values$vars", [{
name: "isUpdate",
attrName: "isUpdateInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "StakeholderRecord",
attrName: "stakeholderRecordInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.AddLead_APIRequestRec();
},
complexType: APIGateway_ISModel.AddLead_APIRequestRec
}, {
name: "PhoneList_Handler",
attrName: "phoneList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "EmailList_Handler",
attrName: "emailList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "AddressList_Handler",
attrName: "addressList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "PersonalDetails_Handler",
attrName: "personalDetails_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PersonalDetails_StructRec();
},
complexType: PHICoreModel.PersonalDetails_StructRec
}, {
name: "InterestLevel_Handler",
attrName: "interestLevel_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.InterestLevel_StructRec();
},
complexType: PHICoreModel.InterestLevel_StructRec
}, {
name: "CommunicationPreference_Handler",
attrName: "communicationPreference_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.PHILeadCommunicationPreferenceRec();
},
complexType: APIGateway_ISModel.PHILeadCommunicationPreferenceRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Stakeholder_Success_Assign_Values$outVars", [{
name: "StakeholderRecord_Out",
attrName: "stakeholderRecord_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.AddLead_APIRequestRec();
},
complexType: APIGateway_ISModel.AddLead_APIRequestRec
}]);
PHICoreController.default.clientActionProxies.stakeholder_Success_Assign_Values$Action = function (isUpdateIn, stakeholderRecordIn, phoneList_HandlerIn, emailList_HandlerIn, addressList_HandlerIn, personalDetails_HandlerIn, interestLevel_HandlerIn, communicationPreference_HandlerIn) {
isUpdateIn = (isUpdateIn === undefined) ? false : isUpdateIn;
stakeholderRecordIn = (stakeholderRecordIn === undefined) ? new APIGateway_ISModel.AddLead_APIRequestRec() : stakeholderRecordIn;
phoneList_HandlerIn = (phoneList_HandlerIn === undefined) ? new PHICoreModel.StakeholderPhoneList() : phoneList_HandlerIn;
emailList_HandlerIn = (emailList_HandlerIn === undefined) ? new PHICoreModel.StakeholderEmailList() : emailList_HandlerIn;
addressList_HandlerIn = (addressList_HandlerIn === undefined) ? new PHICoreModel.StakeholderAddressList() : addressList_HandlerIn;
personalDetails_HandlerIn = (personalDetails_HandlerIn === undefined) ? new PHICoreModel.PersonalDetails_StructRec() : personalDetails_HandlerIn;
interestLevel_HandlerIn = (interestLevel_HandlerIn === undefined) ? new PHICoreModel.InterestLevel_StructRec() : interestLevel_HandlerIn;
communicationPreference_HandlerIn = (communicationPreference_HandlerIn === undefined) ? new APIGateway_ISModel.PHILeadCommunicationPreferenceRec() : communicationPreference_HandlerIn;
return controller.executeActionInsideJSNode(PHICoreController.default.stakeholder_Success_Assign_Values$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isUpdateIn, OS.Types.Boolean), stakeholderRecordIn, phoneList_HandlerIn, emailList_HandlerIn, addressList_HandlerIn, personalDetails_HandlerIn, interestLevel_HandlerIn, communicationPreference_HandlerIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
StakeholderRecord_Out: actionResults.stakeholderRecord_OutOut
};
});
};
});

define("PHICore.controller$Step1_BasicDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Config_CS.model", "Stakeholder_CS.model", "APIGateway_IS.model", "PHICore.clientVariables", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Config_CS", "Stakeholder_CS.model$ReferenceDataBasicStrucRec", "PHICore.referencesHealth$Stakeholder_CS", "PHICore.model$ReferenceDataList", "PHICore.model$CalculateRatesQuotes_APIList", "PHICore.model$SearchResultItemList", "APIGateway_IS.model$SearchResultItemRec", "PHICore.referencesHealth$APIGateway_IS", "APIGateway_IS.model$SearchIndividuals_APIResponseRec", "PHICore.model$PolicyBasicDetailsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Config_CSModel, Stakeholder_CSModel, APIGateway_ISModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.step1_BasicDetails$Action = function (eligibilityReason_ListIn, eligibilitySubReason_ListIn, cover_ListIn, class_ListIn, state_ListIn, residency_ListIn, group_ListIn, location_ListIn, site_ListIn, getQuote_RatesQuote_RevisionsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step1_BasicDetails$vars"))());
vars.value.eligibilityReason_ListInLocal = eligibilityReason_ListIn.clone();
vars.value.eligibilitySubReason_ListInLocal = eligibilitySubReason_ListIn.clone();
vars.value.cover_ListInLocal = cover_ListIn.clone();
vars.value.class_ListInLocal = class_ListIn.clone();
vars.value.state_ListInLocal = state_ListIn.clone();
vars.value.residency_ListInLocal = residency_ListIn.clone();
vars.value.group_ListInLocal = group_ListIn.clone();
vars.value.location_ListInLocal = location_ListIn.clone();
vars.value.site_ListInLocal = site_ListIn.clone();
vars.value.getQuote_RatesQuote_RevisionsInLocal = getQuote_RatesQuote_RevisionsIn.clone();
var residencyListVar = new OS.DataTypes.VariableHolder();
var classListVar = new OS.DataTypes.VariableHolder();
var groupListVar = new OS.DataTypes.VariableHolder();
var stateListVar = new OS.DataTypes.VariableHolder();
var coverListVar = new OS.DataTypes.VariableHolder();
var locationVar = new OS.DataTypes.VariableHolder();
var siteListVar = new OS.DataTypes.VariableHolder();
var eligibilitySubReasonListVar = new OS.DataTypes.VariableHolder();
var eligibilityReasonVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step1_BasicDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.residencyListVar = residencyListVar;
varBag.classListVar = classListVar;
varBag.groupListVar = groupListVar;
varBag.stateListVar = stateListVar;
varBag.coverListVar = coverListVar;
varBag.locationVar = locationVar;
varBag.siteListVar = siteListVar;
varBag.eligibilitySubReasonListVar = eligibilitySubReasonListVar;
varBag.eligibilityReasonVar = eligibilityReasonVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:INo9AK3oyEi1S53cmwdNOQ:/ClientActionFlows.INo9AK3oyEi1S53cmwdNOQ:Oc6LnTw0f9JItfGjjbX1qw", "PHICore", "Step1_BasicDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ryjKQISspkyMqxUY3WMvvA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9OsD0I1qv0qOaVb_qaAe2A", callContext.id);
// Execute Action: EligibilityReason
eligibilityReasonVar.value = OS.SystemActions.listFilter(vars.value.eligibilityReason_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).eligibilityReasonCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7gpL3UOtqE+2MthHjBH+vQ", callContext.id) && !(eligibilityReasonVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZUq1Lp4yPUiT_XCl4g+05Q", callContext.id);
// Policy_BasicDetails.EligibilityReason = EligibilityReason.FilteredList.Current
outVars.value.policy_BasicDetailsOut.eligibilityReasonAttr = eligibilityReasonVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:x9sWvUOUdUCWm0EB6HhHYA", callContext.id);
// Execute Action: EligibilitySubReasonList
eligibilitySubReasonListVar.value = OS.SystemActions.listFilter(vars.value.eligibilitySubReason_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).eligibilitySubReasonCodeAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jIoVKCcNp0q6ihQZL4V3ew", callContext.id) && !(eligibilitySubReasonListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Lnvrg1wZUung+WjT4wRmA", callContext.id);
// Policy_BasicDetails.EligibilitySubReason = EligibilitySubReasonList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.eligibilitySubReasonAttr = eligibilitySubReasonListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9DUGyZON6U+vHGvKrYrRyw", callContext.id);
// Policy_BasicDetails.EffectiveDate = GetQuote_RatesQuote_Revisions.Current.EffectiveDate
outVars.value.policy_BasicDetailsOut.effectiveDateAttr = vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).effectiveDateAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9DUGyZON6U+vHGvKrYrRyw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Policy_BasicDetails.StartDate = GetQuote_RatesQuote_Revisions.Current.EffectiveDate
outVars.value.policy_BasicDetailsOut.startDateAttr = vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).effectiveDateAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OXcamYe3qkyNxgFsr2X+6A", callContext.id);
// Execute Action: CoverList
coverListVar.value = OS.SystemActions.listFilter(vars.value.cover_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).coverAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tT3ksuDgZk2GnHjdnu5XrQ", callContext.id) && !(coverListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:P4DeDiY5BUetQt79lGv70g", callContext.id);
// Policy_BasicDetails.Cover = CoverList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.coverAttr = coverListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kBYVT_SNbUynHjUjRv5X7A", callContext.id);
// Execute Action: ClassList
classListVar.value = OS.SystemActions.listFilter(vars.value.class_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).policyClassAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dZXPwrsrR0mIOAmRb2SMsw", callContext.id) && !(classListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lDGXslbZmUScLDiQQQlS_g", callContext.id);
// Policy_BasicDetails.Class = ClassList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.classAttr = classListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+KY0k6Eao0uWzvykAR2u+A", callContext.id);
// Execute Action: StateList
stateListVar.value = OS.SystemActions.listFilter(vars.value.state_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).stateTerritoryCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IeUgbZc96U6br51TEKfuDA", callContext.id) && !(stateListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wsz9C5esIk2SUAaLwX1rdA", callContext.id);
// Policy_BasicDetails.State = StateList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.stateAttr = stateListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ON16F600fUeOLnJ7dVeF7w", callContext.id);
// Execute Action: ResidencyList
residencyListVar.value = OS.SystemActions.listFilter(vars.value.residency_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).residencyStatusAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AeU7iSegrEStOAFfl4y5Xw", callContext.id) && !(residencyListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:znh24siKGEKH4jkpJNO1mg", callContext.id);
// Policy_BasicDetails.Residency = ResidencyList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.residencyAttr = residencyListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w1lsXluC6kS83dReE1T1Pw", callContext.id);
// Execute Action: GroupList
groupListVar.value = OS.SystemActions.listFilter(vars.value.group_ListInLocal.resultAttr, function (p) {
return (p.stakeholderIdAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).groupCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Xz4Bv3nuZkCKgkTDApT01Q", callContext.id) && !(groupListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AmrGkS9uDEegZxc3mRnnCw", callContext.id);
// Policy_BasicDetails.Group = GroupList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.groupAttr = groupListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZFYmmTO+sUaIJkKveouNBA", callContext.id);
// Execute Action: Location
locationVar.value = OS.SystemActions.listFilter(vars.value.location_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).locationCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:542JinSkIkmOhh8IR5OSkg", callContext.id) && !(locationVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y+RNZ+UdA0WkayuSMrmycQ", callContext.id);
// Policy_BasicDetails.Location = Location.FilteredList.Current
outVars.value.policy_BasicDetailsOut.locationAttr = OS.DataConversion.JSConversions.typeConvertRecord(locationVar.value.filteredListOut.getCurrent(callContext.iterationContext), new Stakeholder_CSModel.ReferenceDataBasicStrucRec(), function (source, target) {
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cLRcqucisEuvrOWnCiHo1g", callContext.id);
// Execute Action: SiteList
siteListVar.value = OS.SystemActions.listFilter(vars.value.site_ListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).siteCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aT5hv1wKOU6MDJDc6LWDrw", callContext.id) && !(siteListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1FHmEMH3mUmXfWEd1eNu8w", callContext.id);
// Policy_BasicDetails.Site = SiteList.FilteredList.Current
outVars.value.policy_BasicDetailsOut.siteAttr = OS.DataConversion.JSConversions.typeConvertRecord(siteListVar.value.filteredListOut.getCurrent(callContext.iterationContext), new Stakeholder_CSModel.ReferenceDataBasicStrucRec(), function (source, target) {
target.codeAttr = source.codeAttr;
target.nameAttr = source.nameAttr;
return target;
});
}

// Badge
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FRSa21slAkGlb0UqrxZFqw", callContext.id);
// Policy_BasicDetails.Badge.Name = GetQuote_RatesQuote_Revisions.Current.Badge
outVars.value.policy_BasicDetailsOut.badgeAttr.nameAttr = vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).badgeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FRSa21slAkGlb0UqrxZFqw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Policy_BasicDetails.Badge.Code = GetQuote_RatesQuote_Revisions.Current.Badge
outVars.value.policy_BasicDetailsOut.badgeAttr.codeAttr = vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).badgeAttr;
// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ncwjPkxKdUeTAttpR5a6Kg", callContext.id);
// Out_GetQuote_RatesQuote_Revisions = GetQuote_RatesQuote_Revisions
outVars.value.out_GetQuote_RatesQuote_RevisionsOut = vars.value.getQuote_RatesQuote_RevisionsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nYvZzrV2sUyre0vSnIP3hA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:INo9AK3oyEi1S53cmwdNOQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step1_BasicDetails$vars", [{
name: "EligibilityReason_List",
attrName: "eligibilityReason_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "EligibilitySubReason_List",
attrName: "eligibilitySubReason_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Cover_List",
attrName: "cover_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Class_List",
attrName: "class_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "State_List",
attrName: "state_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Residency_List",
attrName: "residency_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Group_List",
attrName: "group_ListInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.SearchIndividuals_APIResponseRec();
},
complexType: APIGateway_ISModel.SearchIndividuals_APIResponseRec
}, {
name: "Location_List",
attrName: "location_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "Site_List",
attrName: "site_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetQuote_RatesQuote_Revisions",
attrName: "getQuote_RatesQuote_RevisionsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.CalculateRatesQuotes_APIList();
},
complexType: PHICoreModel.CalculateRatesQuotes_APIList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step1_BasicDetails$outVars", [{
name: "Out_GetQuote_RatesQuote_Revisions",
attrName: "out_GetQuote_RatesQuote_RevisionsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.CalculateRatesQuotes_APIList();
},
complexType: PHICoreModel.CalculateRatesQuotes_APIList
}, {
name: "Policy_BasicDetails",
attrName: "policy_BasicDetailsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyBasicDetailsRec();
},
complexType: PHICoreModel.PolicyBasicDetailsRec
}]);
PHICoreController.default.clientActionProxies.step1_BasicDetails$Action = function (eligibilityReason_ListIn, eligibilitySubReason_ListIn, cover_ListIn, class_ListIn, state_ListIn, residency_ListIn, group_ListIn, location_ListIn, site_ListIn, getQuote_RatesQuote_RevisionsIn) {
eligibilityReason_ListIn = (eligibilityReason_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : eligibilityReason_ListIn;
eligibilitySubReason_ListIn = (eligibilitySubReason_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : eligibilitySubReason_ListIn;
cover_ListIn = (cover_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : cover_ListIn;
class_ListIn = (class_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : class_ListIn;
state_ListIn = (state_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : state_ListIn;
residency_ListIn = (residency_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : residency_ListIn;
group_ListIn = (group_ListIn === undefined) ? new APIGateway_ISModel.SearchIndividuals_APIResponseRec() : group_ListIn;
location_ListIn = (location_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : location_ListIn;
site_ListIn = (site_ListIn === undefined) ? new PHICoreModel.ReferenceDataList() : site_ListIn;
getQuote_RatesQuote_RevisionsIn = (getQuote_RatesQuote_RevisionsIn === undefined) ? new PHICoreModel.CalculateRatesQuotes_APIList() : getQuote_RatesQuote_RevisionsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.step1_BasicDetails$Action.bind(controller, eligibilityReason_ListIn, eligibilitySubReason_ListIn, cover_ListIn, class_ListIn, state_ListIn, residency_ListIn, group_ListIn, location_ListIn, site_ListIn, getQuote_RatesQuote_RevisionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_GetQuote_RatesQuote_Revisions: actionResults.out_GetQuote_RatesQuote_RevisionsOut,
Policy_BasicDetails: actionResults.policy_BasicDetailsOut
};
});
};
});

define("PHICore.controller$Step2_PrimaryMember", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "Config_CS.model", "PHICore.clientVariables", "PHICore.model$PhoneNumberItemList", "PHICore.model$ReferenceDataList", "APIGateway_IS.model$PhoneNumberItemRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "PHICore.model$PolicyPhoneList", "Config_CS.model$ReferenceDataRec", "PHICore.referencesHealth$Config_CS", "PHICore.model$PolicyAddressList", "APIGateway_IS.model$AddressItemRec", "PHICore.model$AddressItemList", "PHICore.model$PolicyEmailList", "APIGateway_IS.model$EmailItemRec", "APIGateway_IS.model$ContactDetailV2_ResponseRec", "APIGateway_IS.model$GetIndividual_HAMBS_Response_APIRec", "PHICore.model$CalculateRatesQuotes_APIList", "PHICore.model$PolicyMemberRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, Config_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.step2_PrimaryMember$Action = function (contactDetailsIn, getData_CountryListIn, getData_MedicareCardTypeListIn, getData_StateListIn, getData_SexListIn, getData_PolicyRoleListIn, getData_TitleListIn, getData_PronounsListIn, getData_RankListIn, getData_AddressTypeListIn, getData_PhoneTypeListIn, getQuote_StakeholderIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step2_PrimaryMember$vars"))());
vars.value.contactDetailsInLocal = contactDetailsIn.clone();
vars.value.getData_CountryListInLocal = getData_CountryListIn.clone();
vars.value.getData_MedicareCardTypeListInLocal = getData_MedicareCardTypeListIn.clone();
vars.value.getData_StateListInLocal = getData_StateListIn.clone();
vars.value.getData_SexListInLocal = getData_SexListIn.clone();
vars.value.getData_PolicyRoleListInLocal = getData_PolicyRoleListIn.clone();
vars.value.getData_TitleListInLocal = getData_TitleListIn.clone();
vars.value.getData_PronounsListInLocal = getData_PronounsListIn.clone();
vars.value.getData_RankListInLocal = getData_RankListIn.clone();
vars.value.getData_AddressTypeListInLocal = getData_AddressTypeListIn.clone();
vars.value.getData_PhoneTypeListInLocal = getData_PhoneTypeListIn.clone();
vars.value.getQuote_StakeholderInLocal = getQuote_StakeholderIn.clone();
var phoneTypeVar = new OS.DataTypes.VariableHolder();
var addressTypeVar = new OS.DataTypes.VariableHolder();
var titleListVar = new OS.DataTypes.VariableHolder();
var rankListVar = new OS.DataTypes.VariableHolder();
var medicareCardTypeListVar = new OS.DataTypes.VariableHolder();
var countryListVar = new OS.DataTypes.VariableHolder();
var roleListVar = new OS.DataTypes.VariableHolder();
var pronounsVar = new OS.DataTypes.VariableHolder();
var stateVar = new OS.DataTypes.VariableHolder();
var sexListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step2_PrimaryMember$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.phoneTypeVar = phoneTypeVar;
varBag.addressTypeVar = addressTypeVar;
varBag.titleListVar = titleListVar;
varBag.rankListVar = rankListVar;
varBag.medicareCardTypeListVar = medicareCardTypeListVar;
varBag.countryListVar = countryListVar;
varBag.roleListVar = roleListVar;
varBag.pronounsVar = pronounsVar;
varBag.stateVar = stateVar;
varBag.sexListVar = sexListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:+HQzcd7Sc02iO_m0cbJQdQ:/ClientActionFlows.+HQzcd7Sc02iO_m0cbJQdQ:n+xWd3HvJHViFMmtgLJuTg", "PHICore", "Step2_PrimaryMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+LXLeu+vQ0ekhVumwmWb4Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h36OuIZUqEenkRlIap_kaw", callContext.id);
// Execute Action: RoleList
roleListVar.value = OS.SystemActions.listFilter(vars.value.getData_PolicyRoleListInLocal, function (p) {
return (p.codeAttr === "PrimaryMember");
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f35J+++B9EWAc8i70kvO0w", callContext.id) && !(roleListVar.value.filteredListOut.isEmpty))) {
// PolicyRole
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SrhifmTCl0OyuLaILf9XIA", callContext.id);
// PrimaryMember.PersonalDetails.PolicyRole = RoleList.FilteredList.Current
outVars.value.primaryMemberOut.personalDetailsAttr.policyRoleAttr = roleListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// PersonalDetails
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id);
// PrimaryMember.PersonalDetails.FirstName = GetQuote_Stakeholder.FirstName
outVars.value.primaryMemberOut.personalDetailsAttr.firstNameAttr = vars.value.getQuote_StakeholderInLocal.firstNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PrimaryMember.PersonalDetails.MiddleName = GetQuote_Stakeholder.MiddleName
outVars.value.primaryMemberOut.personalDetailsAttr.middleNameAttr = vars.value.getQuote_StakeholderInLocal.middleNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PrimaryMember.PersonalDetails.LastName = GetQuote_Stakeholder.LastName
outVars.value.primaryMemberOut.personalDetailsAttr.lastNameAttr = vars.value.getQuote_StakeholderInLocal.lastNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PrimaryMember.PersonalDetails.DateOfBirth = GetQuote_Stakeholder.DateOfBirth
outVars.value.primaryMemberOut.personalDetailsAttr.dateOfBirthAttr = vars.value.getQuote_StakeholderInLocal.dateOfBirthAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PrimaryMember.PersonalDetails.PreferredName = GetQuote_Stakeholder.PreferredName
outVars.value.primaryMemberOut.personalDetailsAttr.preferredNameAttr = vars.value.getQuote_StakeholderInLocal.preferredNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YTcri26Ci0am2iyCXMOh2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PrimaryMember.PersonalDetails.OtherPronouns = GetQuote_Stakeholder.Pronouns
outVars.value.primaryMemberOut.personalDetailsAttr.otherPronounsAttr = vars.value.getQuote_StakeholderInLocal.pronounsAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GbmrSe16r0W+NU1ZXonLTg", callContext.id);
// Execute Action: TitleList
titleListVar.value = OS.SystemActions.listFilter(vars.value.getData_TitleListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_StakeholderInLocal.titleCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aBatEDJnE0eok4CZiXQIlw", callContext.id) && !(titleListVar.value.filteredListOut.isEmpty))) {
// Title
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_H1fONLuiUWlqYh7rccvWw", callContext.id);
// PrimaryMember.PersonalDetails.Title = TitleList.FilteredList.Current
outVars.value.primaryMemberOut.personalDetailsAttr.titleAttr = titleListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OUDRWKVtsES74GGaajg1CA", callContext.id);
// Execute Action: RankList
rankListVar.value = OS.SystemActions.listFilter(vars.value.getData_RankListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_StakeholderInLocal.rankCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yZKsqrnRP0S+54rVAvAYkg", callContext.id) && !(rankListVar.value.filteredListOut.isEmpty))) {
// Rank
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p70fr8X1dkCwrmXoXsGNMg", callContext.id);
// PrimaryMember.PersonalDetails.Rank = RankList.FilteredList.Current
outVars.value.primaryMemberOut.personalDetailsAttr.rankAttr = rankListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8Eo4+v99ikCax5UqTyz56A", callContext.id);
// Execute Action: SexList
sexListVar.value = OS.SystemActions.listFilter(vars.value.getData_SexListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_StakeholderInLocal.sexAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XCqktbarPEK9LGW9msaEuA", callContext.id) && !(sexListVar.value.filteredListOut.isEmpty))) {
// Sex
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0ziXHguIO06+YasL+dfSGA", callContext.id);
// PrimaryMember.PersonalDetails.Sex = SexList.FilteredList.Current
outVars.value.primaryMemberOut.personalDetailsAttr.sexAttr = sexListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3HN74ySAhUiV9eBDQPQLpw", callContext.id);
// Execute Action: Pronouns
pronounsVar.value = OS.SystemActions.listFilter(vars.value.getData_PronounsListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_StakeholderInLocal.pronounsCodeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4RyuYPTFG0qCAH9QXsEZtw", callContext.id) && !(pronounsVar.value.filteredListOut.isEmpty))) {
// Pronouns
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rs1iZudfS0qRfyXsTOhpHQ", callContext.id);
// PrimaryMember.PersonalDetails.Pronouns = Pronouns.FilteredList.Current
outVars.value.primaryMemberOut.personalDetailsAttr.pronounsAttr = pronounsVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

// LHC / ABD Details
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id);
// PrimaryMember.PersonalDetails.LhcEntryAge = RatesQuote_Revisions.Current.Members.Current.LhcEntryAge
outVars.value.primaryMemberOut.personalDetailsAttr.lhcEntryAgeAttr = outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).membersAttr.getCurrent(callContext.iterationContext).lhcEntryAgeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PrimaryMember.PersonalDetails.LhcPercentage = RatesQuote_Revisions.Current.Members.Current.LhcLoadingPercentage
outVars.value.primaryMemberOut.personalDetailsAttr.lhcPercentageAttr = OS.BuiltinFunctions.longIntegerToDecimal(outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).membersAttr.getCurrent(callContext.iterationContext).lhcLoadingPercentageAttr);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PrimaryMember.PersonalDetails.AbsenceDays = RatesQuote_Revisions.Current.Members.Current.LhcAbsenceDays
outVars.value.primaryMemberOut.personalDetailsAttr.absenceDaysAttr = outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).membersAttr.getCurrent(callContext.iterationContext).lhcAbsenceDaysAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PrimaryMember.PersonalDetails.AbdEntryAge = RatesQuote_Revisions.Current.Members.Current.AbdEntryAge
outVars.value.primaryMemberOut.personalDetailsAttr.abdEntryAgeAttr = outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).membersAttr.getCurrent(callContext.iterationContext).abdEntryAgeAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PrimaryMember.PersonalDetails.LhcPercentageOverride = RatesQuote_Revisions.Current.Members.Current.LhcOverride
outVars.value.primaryMemberOut.personalDetailsAttr.lhcPercentageOverrideAttr = outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).membersAttr.getCurrent(callContext.iterationContext).lhcOverrideAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bNR9s_wHCEyVu_gN4gbVgw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PrimaryMember.PersonalDetails.AbdEffectiveDate = RatesQuote_Revisions.Current.EffectiveDate
outVars.value.primaryMemberOut.personalDetailsAttr.abdEffectiveDateAttr = outVars.value.ratesQuote_RevisionsOut.getCurrent(callContext.iterationContext).effectiveDateAttr;
// Foreach ContactDetails.Phones
callContext.iterationContext.registerIterationStart(vars.value.contactDetailsInLocal.phonesAttr);
try {var phonesIterator = callContext.iterationContext.getIterator(vars.value.contactDetailsInLocal.phonesAttr);
var phonesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kUsUESAcdEa3Ocfzs7j+ow", callContext.id) && (phonesIndex < vars.value.contactDetailsInLocal.phonesAttr.length))) {
phonesIterator.currentRowNumber = phonesIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hGKyElMWm0GXKdamqHmzSQ", callContext.id);
// Execute Action: PhoneType
phoneTypeVar.value = OS.SystemActions.listFilter(vars.value.getData_PhoneTypeListInLocal, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()).typeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h09HE35DDkai0kFSvoq0Yg", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.primaryMemberOut.personalDetailsAttr.phoneListAttr, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.contactDetailsInLocal.phonesAttr.getItem(phonesIndex.valueOf()), new PHICoreModel.PolicyPhoneRec(), function (source, target) {
target.phoneTypeAttr.idAttr = phoneTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
target.phoneTypeAttr.codeAttr = phoneTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
target.phoneTypeAttr.nameAttr = phoneTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
target.countryCodeAttr.idAttr = OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier());
target.numberAttr.valueAttr = source.phoneNumberAttr;
target.isActiveAttr = source.isActiveAttr;
target.isPreferredAttr.valueAttr = true;
target.isOverseasAttr = source.isOverseasAttr;
return target;
}), callContext);
phonesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.contactDetailsInLocal.phonesAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Twr758TWQkyawUwuPRrnfg", callContext.id);
// Execute Action: AppendEmail
OS.SystemActions.listAppend(outVars.value.primaryMemberOut.personalDetailsAttr.emailListAttr, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.contactDetailsInLocal.emailAttr, new PHICoreModel.PolicyEmailRec(), function (source, target) {
target.emailAttr.valueAttr = source.emailAddressAttr;
target.isActiveAttr = source.isActiveAttr;
return target;
}), callContext);
// Foreach ContactDetails.Addresses
callContext.iterationContext.registerIterationStart(vars.value.contactDetailsInLocal.addressesAttr);
try {var addressesIterator = callContext.iterationContext.getIterator(vars.value.contactDetailsInLocal.addressesAttr);
var addressesIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wlL5aLd4cEywv3ZQFz1uYQ", callContext.id) && (addressesIndex < vars.value.contactDetailsInLocal.addressesAttr.length))) {
addressesIterator.currentRowNumber = addressesIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mNLxNGenKU2E85R7zQ7UfA", callContext.id);
// Execute Action: AddressType
addressTypeVar.value = OS.SystemActions.listFilter(vars.value.getData_AddressTypeListInLocal, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).typeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hmDi6MhuwkKe3U4ofUChWw", callContext.id);
// Execute Action: State
stateVar.value = OS.SystemActions.listFilter(vars.value.getData_StateListInLocal, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).stateTerritoryCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+qH1rM4GsUaK7Jc7mc_LgA", callContext.id);
// Execute Action: CountryList
countryListVar.value = OS.SystemActions.listFilter(vars.value.getData_CountryListInLocal, function (p) {
return (p.codeAttr === vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()).countryCodeAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L_PYZ5hi90mkt+yCq1c0eg", callContext.id);
// Execute Action: ListAppend2
OS.SystemActions.listAppend(outVars.value.primaryMemberOut.personalDetailsAttr.addressListAttr, OS.DataConversion.JSConversions.typeConvertRecord(vars.value.contactDetailsInLocal.addressesAttr.getItem(addressesIndex.valueOf()), new PHICoreModel.PolicyAddressRec(), function (source, target) {
target.addressTypeAttr.idAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
target.addressTypeAttr.codeAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
target.addressTypeAttr.nameAttr = addressTypeVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
target.isOverseasAttr = source.isOverseasAttr;
target.line1Attr = source.line1Attr;
target.line2Attr.valueAttr = ((source.line1Attr + " ") + source.line2Attr);
target.suburbAttr.valueAttr = source.suburbAttr;
target.provinceAttr.valueAttr = source.stateProvinceAttr;
target.stateAttr.idAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
target.stateAttr.codeAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
target.stateAttr.nameAttr = stateVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
target.postcodeAttr.valueAttr = source.postcodeAttr;
target.countryAttr.idAttr = countryListVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr;
target.countryAttr.codeAttr = countryListVar.value.filteredListOut.getCurrent(callContext.iterationContext).codeAttr;
target.countryAttr.nameAttr = countryListVar.value.filteredListOut.getCurrent(callContext.iterationContext).nameAttr;
target.effectiveDateAttr.valueAttr = source.effectiveDateAttr;
target.isActiveAttr = source.isActiveAttr;
return target;
}), callContext);
addressesIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.contactDetailsInLocal.addressesAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MeiEqjXDjUavkNPBfGDqPA", callContext.id);
// Execute Action: MedicareCardTypeList
medicareCardTypeListVar.value = OS.SystemActions.listFilter(vars.value.getData_MedicareCardTypeListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_StakeholderInLocal.medicareCardAttr.typeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YyAzVPleFEi5KBObInXlXw", callContext.id) && !(medicareCardTypeListVar.value.filteredListOut.isEmpty))) {
// MedicareCardType
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_fAHqqeCHEGRUk805gsaaA", callContext.id);
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardType = MedicareCardTypeList.FilteredList.Current
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardTypeAttr = medicareCardTypeListVar.value.filteredListOut.getCurrent(callContext.iterationContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id);
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardNumber = GetQuote_Stakeholder.MedicareCard.MedicareCardNumber
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardNumberAttr = vars.value.getQuote_StakeholderInLocal.medicareCardAttr.medicareCardNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardFirstName = GetQuote_Stakeholder.MedicareCard.FirstName
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardFirstNameAttr = vars.value.getQuote_StakeholderInLocal.medicareCardAttr.firstNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardMiddleName = GetQuote_Stakeholder.MedicareCard.SecondName
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardMiddleNameAttr = vars.value.getQuote_StakeholderInLocal.medicareCardAttr.secondNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardLastName = GetQuote_Stakeholder.MedicareCard.LastName
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardLastNameAttr = vars.value.getQuote_StakeholderInLocal.medicareCardAttr.lastNameAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardIrn = LongIntegerToInteger
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardIrnAttr = OS.BuiltinFunctions.longIntegerToInteger(vars.value.getQuote_StakeholderInLocal.medicareCardAttr.medicareCardIrnAttr);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t+OQ_Qjd8k+K7EfjyF7nGg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PrimaryMember.PolicyCardsAssociationsDetails.MedicareCardExpiryDate = GetQuote_Stakeholder.MedicareCard.ExpiryDate
outVars.value.primaryMemberOut.policyCardsAssociationsDetailsAttr.medicareCardExpiryDateAttr = vars.value.getQuote_StakeholderInLocal.medicareCardAttr.expiryDateAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fKm+_3VSF06Ibf74t6ih+Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:+HQzcd7Sc02iO_m0cbJQdQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step2_PrimaryMember$vars", [{
name: "ContactDetails",
attrName: "contactDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.ContactDetailV2_ResponseRec();
},
complexType: APIGateway_ISModel.ContactDetailV2_ResponseRec
}, {
name: "GetData_CountryList",
attrName: "getData_CountryListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_MedicareCardTypeList",
attrName: "getData_MedicareCardTypeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_StateList",
attrName: "getData_StateListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_SexList",
attrName: "getData_SexListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_PolicyRoleList",
attrName: "getData_PolicyRoleListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_TitleList",
attrName: "getData_TitleListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_PronounsList",
attrName: "getData_PronounsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_RankList",
attrName: "getData_RankListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_AddressTypeList",
attrName: "getData_AddressTypeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_PhoneTypeList",
attrName: "getData_PhoneTypeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetQuote_Stakeholder",
attrName: "getQuote_StakeholderInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.GetIndividual_HAMBS_Response_APIRec();
},
complexType: APIGateway_ISModel.GetIndividual_HAMBS_Response_APIRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step2_PrimaryMember$outVars", [{
name: "RatesQuote_Revisions",
attrName: "ratesQuote_RevisionsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.CalculateRatesQuotes_APIList();
},
complexType: PHICoreModel.CalculateRatesQuotes_APIList
}, {
name: "PrimaryMember",
attrName: "primaryMemberOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyMemberRec();
},
complexType: PHICoreModel.PolicyMemberRec
}]);
PHICoreController.default.clientActionProxies.step2_PrimaryMember$Action = function (contactDetailsIn, getData_CountryListIn, getData_MedicareCardTypeListIn, getData_StateListIn, getData_SexListIn, getData_PolicyRoleListIn, getData_TitleListIn, getData_PronounsListIn, getData_RankListIn, getData_AddressTypeListIn, getData_PhoneTypeListIn, getQuote_StakeholderIn) {
contactDetailsIn = (contactDetailsIn === undefined) ? new APIGateway_ISModel.ContactDetailV2_ResponseRec() : contactDetailsIn;
getData_CountryListIn = (getData_CountryListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_CountryListIn;
getData_MedicareCardTypeListIn = (getData_MedicareCardTypeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_MedicareCardTypeListIn;
getData_StateListIn = (getData_StateListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_StateListIn;
getData_SexListIn = (getData_SexListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_SexListIn;
getData_PolicyRoleListIn = (getData_PolicyRoleListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_PolicyRoleListIn;
getData_TitleListIn = (getData_TitleListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_TitleListIn;
getData_PronounsListIn = (getData_PronounsListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_PronounsListIn;
getData_RankListIn = (getData_RankListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_RankListIn;
getData_AddressTypeListIn = (getData_AddressTypeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_AddressTypeListIn;
getData_PhoneTypeListIn = (getData_PhoneTypeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_PhoneTypeListIn;
getQuote_StakeholderIn = (getQuote_StakeholderIn === undefined) ? new APIGateway_ISModel.GetIndividual_HAMBS_Response_APIRec() : getQuote_StakeholderIn;
return controller.executeActionInsideJSNode(PHICoreController.default.step2_PrimaryMember$Action.bind(controller, contactDetailsIn, getData_CountryListIn, getData_MedicareCardTypeListIn, getData_StateListIn, getData_SexListIn, getData_PolicyRoleListIn, getData_TitleListIn, getData_PronounsListIn, getData_RankListIn, getData_AddressTypeListIn, getData_PhoneTypeListIn, getQuote_StakeholderIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
RatesQuote_Revisions: actionResults.ratesQuote_RevisionsOut,
PrimaryMember: actionResults.primaryMemberOut
};
});
};
});

define("PHICore.controller$Step4_Rebate", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$ReferenceDataList", "PHICore.model$CalculateRatesQuotes_APIList", "PHICore.model$RebateDetailsRec", "PHICore.model$RebateDetailsList", "PHICore.model$RebateRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.step4_Rebate$Action = function (getData_RebateActionListIn, getData_RebateAgeListIn, getQuote_RatesQuote_RevisionsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step4_Rebate$vars"))());
vars.value.getData_RebateActionListInLocal = getData_RebateActionListIn.clone();
vars.value.getData_RebateAgeListInLocal = getData_RebateAgeListIn.clone();
vars.value.getQuote_RatesQuote_RevisionsInLocal = getQuote_RatesQuote_RevisionsIn.clone();
var rebateAgeListVar = new OS.DataTypes.VariableHolder();
var rebateActionListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Step4_Rebate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.rebateAgeListVar = rebateAgeListVar;
varBag.rebateActionListVar = rebateActionListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:5sGYtCO5YUm4gEA6+tSZ1g:/ClientActionFlows.5sGYtCO5YUm4gEA6+tSZ1g:QsaUPC5V+1687k4lC2e__g", "PHICore", "Step4_Rebate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5oXBH3mkPUSf9Xsuab3iIw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8f_YrY8lBEiWZHmIWR4UJA", callContext.id);
// Execute Action: RebateActionList
rebateActionListVar.value = OS.SystemActions.listFilter(vars.value.getData_RebateActionListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).rebateTierAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EqjvD3Q3DUSRmrZwKBBr4g", callContext.id) && !(rebateActionListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YDiNtCN5iESUIH9geon64g", callContext.id);
// Rebate.RebateDetails.Current.RebateAction = RebateActionList.FilteredList.Current.Id
outVars.value.rebateOut.rebateDetailsAttr.getCurrent(callContext.iterationContext).rebateActionAttr = OS.BuiltinFunctions.longIntegerToText(rebateActionListVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ApKcjDZed02kWPS8qemGCA", callContext.id);
// Execute Action: RebateAgeList
rebateAgeListVar.value = OS.SystemActions.listFilter(vars.value.getData_RebateAgeListInLocal, function (p) {
return (p.codeAttr === vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).rebateAgeAttr);
}, callContext);

// Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Lc+UBz7NCES63sMadyHqvw", callContext.id) && !(rebateAgeListVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S5kakG8VL0y_udXAv4ZoXA", callContext.id);
// Rebate.RebateDetails.Current.RebateAge = RebateAgeList.FilteredList.Current.Id
outVars.value.rebateOut.rebateDetailsAttr.getCurrent(callContext.iterationContext).rebateAgeAttr = OS.BuiltinFunctions.longIntegerToText(rebateAgeListVar.value.filteredListOut.getCurrent(callContext.iterationContext).idAttr);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:toDR8hyJbkaVdCNXD0sjGw", callContext.id);
// Execute Action: AppendRebate
OS.SystemActions.listAppend(outVars.value.rebateOut.rebateDetailsAttr, function () {
var rec = new PHICoreModel.RebateDetailsRec();
rec.rebateActionAttr = outVars.value.rebateOut.rebateDetailsAttr.getCurrent(callContext.iterationContext).rebateActionAttr;
rec.rebateAgeAttr = outVars.value.rebateOut.rebateDetailsAttr.getCurrent(callContext.iterationContext).rebateAgeAttr;
rec.rebateLevelAttr = vars.value.getQuote_RatesQuote_RevisionsInLocal.getCurrent(callContext.iterationContext).rebateLevelAttr;
return rec;
}(), callContext);
// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EbZNo2JSLEeGsP47f_V24Q", callContext.id);
// Out_GetQuote_RatesQuote_Revisions = GetQuote_RatesQuote_Revisions
outVars.value.out_GetQuote_RatesQuote_RevisionsOut = vars.value.getQuote_RatesQuote_RevisionsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KmSywJ9xqk6DW9vHWkVf_Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5sGYtCO5YUm4gEA6+tSZ1g", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step4_Rebate$vars", [{
name: "GetData_RebateActionList",
attrName: "getData_RebateActionListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetData_RebateAgeList",
attrName: "getData_RebateAgeListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.ReferenceDataList();
},
complexType: PHICoreModel.ReferenceDataList
}, {
name: "GetQuote_RatesQuote_Revisions",
attrName: "getQuote_RatesQuote_RevisionsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.CalculateRatesQuotes_APIList();
},
complexType: PHICoreModel.CalculateRatesQuotes_APIList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Step4_Rebate$outVars", [{
name: "Out_GetQuote_RatesQuote_Revisions",
attrName: "out_GetQuote_RatesQuote_RevisionsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.CalculateRatesQuotes_APIList();
},
complexType: PHICoreModel.CalculateRatesQuotes_APIList
}, {
name: "Rebate",
attrName: "rebateOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.RebateRec();
},
complexType: PHICoreModel.RebateRec
}]);
PHICoreController.default.clientActionProxies.step4_Rebate$Action = function (getData_RebateActionListIn, getData_RebateAgeListIn, getQuote_RatesQuote_RevisionsIn) {
getData_RebateActionListIn = (getData_RebateActionListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_RebateActionListIn;
getData_RebateAgeListIn = (getData_RebateAgeListIn === undefined) ? new PHICoreModel.ReferenceDataList() : getData_RebateAgeListIn;
getQuote_RatesQuote_RevisionsIn = (getQuote_RatesQuote_RevisionsIn === undefined) ? new PHICoreModel.CalculateRatesQuotes_APIList() : getQuote_RatesQuote_RevisionsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.step4_Rebate$Action.bind(controller, getData_RebateActionListIn, getData_RebateAgeListIn, getQuote_RatesQuote_RevisionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_GetQuote_RatesQuote_Revisions: actionResults.out_GetQuote_RatesQuote_RevisionsOut,
Rebate: actionResults.rebateOut
};
});
};
});

define("PHICore.controller$SuspendPolicy_CreateCase", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CS.model", "PHICore.clientVariables", "PHICore.model$TextRecordList", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CS", "PHICore.controller$ServerAction.CreatePolicyReactivationSuspendCase"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.suspendPolicy_CreateCase$Action = function (policyIdIn, stakeholderIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.SuspendPolicy_CreateCase$vars"))());
vars.value.policyIdInLocal = policyIdIn;
vars.value.stakeholderIdInLocal = stakeholderIdIn;
var createPolicyReactivationSuspendCaseVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.SuspendPolicy_CreateCase$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.createPolicyReactivationSuspendCaseVar = createPolicyReactivationSuspendCaseVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:qArxVss9gE2I6JZrfdnwpA:/ClientActionFlows.qArxVss9gE2I6JZrfdnwpA:GVDq1f2MAb9z27KvWQCHvA", "PHICore", "SuspendPolicy_CreateCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BJqiUfihpk6P2tsNtNB77w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GzLIQu2hdEm6thFzdjdmkw", callContext.id);
// Execute Action: CreatePolicyReactivationSuspendCase
return controller.createPolicyReactivationSuspendCase$ServerAction(vars.value.policyIdInLocal, PHICoreModel.staticEntities.caseStatusPurpose.pendingSuspendPolicy, "SPE", new PHICoreModel.TextRecordList(), vars.value.stakeholderIdInLocal, false, callContext).then(function (value) {
createPolicyReactivationSuspendCaseVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:x9E44vYFKk+MTG39BNUHaQ", callContext.id);
// CaseId = CreatePolicyReactivationSuspendCase.CasesId
outVars.value.caseIdOut = createPolicyReactivationSuspendCaseVar.value.casesIdOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pqZk40HDxUGIWXxT1w4CBw", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:qArxVss9gE2I6JZrfdnwpA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:qArxVss9gE2I6JZrfdnwpA", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.SuspendPolicy_CreateCase$vars", [{
name: "PolicyId",
attrName: "policyIdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "StakeholderId",
attrName: "stakeholderIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.SuspendPolicy_CreateCase$outVars", [{
name: "CaseId",
attrName: "caseIdOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
PHICoreController.default.clientActionProxies.suspendPolicy_CreateCase$Action = function (policyIdIn, stakeholderIdIn) {
policyIdIn = (policyIdIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : policyIdIn;
stakeholderIdIn = (stakeholderIdIn === undefined) ? "" : stakeholderIdIn;
return controller.executeActionInsideJSNode(PHICoreController.default.suspendPolicy_CreateCase$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(policyIdIn, OS.Types.LongInteger), OS.DataConversion.JSNodeParamConverter.from(stakeholderIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
CaseId: OS.DataConversion.JSNodeParamConverter.to(actionResults.caseIdOut, OS.Types.Text)
};
});
};
});

define("PHICore.controller$TEMP_BuildWaitingPeriodData", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$PolicyWaitingPeriodRec", "PHICore.model$PolicyWaitingPeriodList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.tEMP_BuildWaitingPeriodData$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.TEMP_BuildWaitingPeriodData$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:BPZUg_Irn0eQUkNKUR70eA:/ClientActionFlows.BPZUg_Irn0eQUkNKUR70eA:kI236cOuGVmvzBiPSfTEYg", "PHICore", "TEMP_BuildWaitingPeriodData", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:E61lbEyNf0q64PLqVh9aKQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0cuAbt8aV0aVzOsJu8lK5A", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(outVars.value.waitingPeriodDataOut, function () {
var rec = new PHICoreModel.PolicyWaitingPeriodRec();
rec.itemServiceAttr = "No";
rec.waitingPeriodDurationAttr = OS.BuiltinFunctions.integerToLongInteger(60);
rec.isWaivedAttr = false;
rec.statusAttr = "Active";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0f6lPhxFLUuvn6MWv9UarA", callContext.id);
// Execute Action: ListAppend2
OS.SystemActions.listAppend(outVars.value.waitingPeriodDataOut, function () {
var rec = new PHICoreModel.PolicyWaitingPeriodRec();
rec.itemServiceAttr = "API";
rec.waitingPeriodDurationAttr = OS.BuiltinFunctions.integerToLongInteger(60);
rec.isWaivedAttr = false;
rec.statusAttr = "Active";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F0cPVLW0HE6gg0m14J7Vpw", callContext.id);
// Execute Action: ListAppend3
OS.SystemActions.listAppend(outVars.value.waitingPeriodDataOut, function () {
var rec = new PHICoreModel.PolicyWaitingPeriodRec();
rec.itemServiceAttr = "For";
rec.waitingPeriodDurationAttr = OS.BuiltinFunctions.integerToLongInteger(60);
rec.isWaivedAttr = false;
rec.statusAttr = "Active";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+TGZ1sde1kaEEvtHRzk3QA", callContext.id);
// Execute Action: ListAppend4
OS.SystemActions.listAppend(outVars.value.waitingPeriodDataOut, function () {
var rec = new PHICoreModel.PolicyWaitingPeriodRec();
rec.itemServiceAttr = "Data";
rec.waitingPeriodDurationAttr = OS.BuiltinFunctions.integerToLongInteger(60);
rec.isWaivedAttr = false;
rec.statusAttr = "Active";
return rec;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Voc3wGi2hEytigmYfd4F6Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:BPZUg_Irn0eQUkNKUR70eA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.TEMP_BuildWaitingPeriodData$outVars", [{
name: "WaitingPeriodData",
attrName: "waitingPeriodDataOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.PolicyWaitingPeriodList();
},
complexType: PHICoreModel.PolicyWaitingPeriodList
}]);
PHICoreController.default.clientActionProxies.tEMP_BuildWaitingPeriodData$Action = function () {
return controller.executeActionInsideJSNode(PHICoreController.default.tEMP_BuildWaitingPeriodData$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
WaitingPeriodData: actionResults.waitingPeriodDataOut
};
});
};
});

define("PHICore.controller$UpdateEntityProperties_CS", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "Common_CS.model", "PHICore.clientVariables", "APIGateway_IS.model$EntityResultItemRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore.controller$ServerAction.UpdateEntityProperties_CS"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, Common_CSModel, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.updateEntityProperties_CS$Action = function (uDP_LocalIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.UpdateEntityProperties_CS$vars"))());
vars.value.uDP_LocalInLocal = uDP_LocalIn.clone();
var updateEntityProperties_CSVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.UpdateEntityProperties_CS$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.updateEntityProperties_CSVar = updateEntityProperties_CSVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:4QcHAoVQfkSDRui+HBM+Mg:/ClientActionFlows.4QcHAoVQfkSDRui+HBM+Mg:MU5HdnlaWN4mwVprrRU03Q", "PHICore", "UpdateEntityProperties_CS", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Zsdl6WbNiEmLOJz4_Ckmsg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FYRhXSkmW0GjikdZhq7ysw", callContext.id);
// Execute Action: UpdateEntityProperties_CS
return controller.updateEntityProperties_CS$ServerAction(function () {
var rec = new APIGateway_ISModel.EntityResultItemRec();
rec.entityIdAttr = vars.value.uDP_LocalInLocal.entityIdAttr;
rec.entityTypeAttr = vars.value.uDP_LocalInLocal.entityTypeAttr;
rec.entityPropertyIdAttr = vars.value.uDP_LocalInLocal.entityPropertyIdAttr;
rec.propertyValueAttr = vars.value.uDP_LocalInLocal.propertyValueAttr;
rec.effectiveDateAttr = vars.value.uDP_LocalInLocal.effectiveDateAttr;
rec.propertyCodeAttr = vars.value.uDP_LocalInLocal.propertyCodeAttr;
return rec;
}(), callContext).then(function (value) {
updateEntityProperties_CSVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ny__4oRQp0GzsOO5wG0xMw", callContext.id);
// EntityActionResult = UpdateEntityProperties_CS.EntityActionResult
outVars.value.entityActionResultOut = updateEntityProperties_CSVar.value.entityActionResultOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ChVbP+yePEqkluJGIzAQ9w", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4QcHAoVQfkSDRui+HBM+Mg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4QcHAoVQfkSDRui+HBM+Mg", callContext.id);
throw ex;

});
};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.UpdateEntityProperties_CS$vars", [{
name: "UDP_Local",
attrName: "uDP_LocalInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.EntityResultItemRec();
},
complexType: APIGateway_ISModel.EntityResultItemRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.UpdateEntityProperties_CS$outVars", [{
name: "EntityActionResult",
attrName: "entityActionResultOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}]);
PHICoreController.default.clientActionProxies.updateEntityProperties_CS$Action = function (uDP_LocalIn) {
uDP_LocalIn = (uDP_LocalIn === undefined) ? new APIGateway_ISModel.EntityResultItemRec() : uDP_LocalIn;
return controller.executeActionInsideJSNode(PHICoreController.default.updateEntityProperties_CS$Action.bind(controller, uDP_LocalIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
EntityActionResult: actionResults.entityActionResultOut
};
});
};
});

define("PHICore.controller$Validate_Address", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$StakeholderAddressRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_Address$Action = function (stakeholderAddressIn, isOverseasIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_Address$vars"))());
vars.value.stakeholderAddressInLocal = stakeholderAddressIn.clone();
vars.value.isOverseasInLocal = isOverseasIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_Address$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:gnYIS393+UuMZhYMGP11bg:/ClientActionFlows.gnYIS393+UuMZhYMGP11bg:RMWjcWz6Pl4pjAp+yuNytw", "PHICore", "Validate_Address", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g4Q38X8WkEa5ha4FftUJKQ", callContext.id);
// CheckAddressType
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6JbyeSMm+Em5fmU0wY3Mcw", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.typeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aVXs2jZLYUu2wINY3QYHiw", callContext.id);
// StakeholderAddress.type_Error = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.type_ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

// CheckAddress
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HTJhhKnvbEm_KKM6zRK5xA", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.line1Attr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3zYsyxgG1kC7NvRMkSh2cg", callContext.id);
// StakeholderAddress.line1Error = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.line1ErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

// Check Postcode
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5PG0wTw9MEGhDoZM5Hb_1Q", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.zipPostalCodeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xVUkAatgd06L3lIXGWP0Sw", callContext.id);
// StakeholderAddress.zippostalCodeError = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.zippostalCodeErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

// Validate Country
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ouIaccU2Dk6+Fj0F2Mz18A", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.countryCodeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Tj_6PzigA0il7VUiSFxIgg", callContext.id);
// StakeholderAddress.countryError = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.countryErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ObYPYNTQak2fbL36H9Hs_A", callContext.id) && vars.value.isOverseasInLocal)) {
// CheckCity
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_rel_4crEUCH3z_N3naK+w", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.cityAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LP8NRl5eTUS9kg5TCCRotA", callContext.id);
// StakeholderAddress.cityError = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.cityErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

} else {
// CheckSuburb
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NNOSjKMlz0iKKGw4s8Ovlw", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.suburbAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:go_rpG9DvkabG8OLcPDStA", callContext.id);
// StakeholderAddress.suburbError = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.suburbErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

// CheckState
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nqEbHfA1XUCAXOurlllKBA", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.stakeholderAddressInLocal.stateTerritoryCodeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XzKtVL6jmEu9b2MCp89Qhg", callContext.id);
// StakeholderAddress.stateTerritoryError = GetRequiredFieldMsg()
vars.value.stakeholderAddressInLocal.stateTerritoryErrorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}

}

// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AwcKkLWacEuOuLx+nyzszA", callContext.id);
// Out_StakeholderAddress = StakeholderAddress
outVars.value.out_StakeholderAddressOut = vars.value.stakeholderAddressInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JNAcsOEK6U2JfbczGRWwbA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:gnYIS393+UuMZhYMGP11bg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_Address$vars", [{
name: "StakeholderAddress",
attrName: "stakeholderAddressInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressRec();
},
complexType: PHICoreModel.StakeholderAddressRec
}, {
name: "IsOverseas",
attrName: "isOverseasInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_Address$outVars", [{
name: "Out_StakeholderAddress",
attrName: "out_StakeholderAddressOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressRec();
},
complexType: PHICoreModel.StakeholderAddressRec
}]);
PHICoreController.default.clientActionProxies.validate_Address$Action = function (stakeholderAddressIn, isOverseasIn) {
stakeholderAddressIn = (stakeholderAddressIn === undefined) ? new PHICoreModel.StakeholderAddressRec() : stakeholderAddressIn;
isOverseasIn = (isOverseasIn === undefined) ? false : isOverseasIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_Address$Action.bind(controller, stakeholderAddressIn, OS.DataConversion.JSNodeParamConverter.from(isOverseasIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_StakeholderAddress: actionResults.out_StakeholderAddressOut
};
});
};
});

define("PHICore.controller$Validate_HealthScale", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$KeyValueStringPairList", "PHICore.model$PolicyHealthScaleRec", "PHICore.model$HealthScaleListsRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_HealthScale$Action = function (policyHealthScaleIn, healthScaleListsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_HealthScale$vars"))());
vars.value.policyHealthScaleInLocal = policyHealthScaleIn.clone();
vars.value.healthScaleListsInLocal = healthScaleListsIn.clone();
var productTypeVar = new OS.DataTypes.VariableHolder();
var otherRateScaleVar = new OS.DataTypes.VariableHolder();
var otherProductNameVar = new OS.DataTypes.VariableHolder();
var productNameVar = new OS.DataTypes.VariableHolder();
var rateScaleVar = new OS.DataTypes.VariableHolder();
var productTierVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_HealthScale$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.productTypeVar = productTypeVar;
varBag.otherRateScaleVar = otherRateScaleVar;
varBag.otherProductNameVar = otherProductNameVar;
varBag.productNameVar = productNameVar;
varBag.rateScaleVar = rateScaleVar;
varBag.productTierVar = productTierVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:c_JR05dkKkOrJpL8lHSm9w:/ClientActionFlows.c_JR05dkKkOrJpL8lHSm9w:L76VPNyOJynzg+dThECQIQ", "PHICore", "Validate_HealthScale", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GzySNhRDz0O6deEw0cddjw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Et1TDirsdU6JWEQoe1S7og", callContext.id);
// Execute Action: ProductType
productTypeVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.productTypesListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.productTypeAttr.keyAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+E3txBzXFkiyokPcW2sDnA", callContext.id);
// Execute Action: ProductTier
productTierVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.productTiersListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.productTierAttr.keyAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nO4wQ8TNskaX5GubUjZOfw", callContext.id);
// Execute Action: ProductName
productNameVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.productNamesListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.productNameAttr.keyAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rOokMWpluEavCoPJ9SUn8Q", callContext.id);
// Execute Action: OtherProductName
otherProductNameVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.productNamesListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.otherProductNameAttr.keyAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7YFfkQKSlEyo5yEUkPyyqQ", callContext.id);
// Execute Action: RateScale
rateScaleVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.rateScalesListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.rateScaleAttr.keyAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OzO2G3k1M0Su36z1Shh2gg", callContext.id);
// Execute Action: OtherRateScale
otherRateScaleVar.value = OS.SystemActions.listIndexOf(vars.value.healthScaleListsInLocal.rateScalesListAttr, function (p) {
return (p.keyAttr === vars.value.policyHealthScaleInLocal.otherRateScaleAttr.keyAttr);
}, callContext);

// Out_PolicyHealthScale
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id);
// Out_PolicyHealthScale.ProductType.Error = If
outVars.value.out_PolicyHealthScaleOut.productTypeAttr.errorAttr = (((productTypeVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Out_PolicyHealthScale.ProductTier.Error = If
outVars.value.out_PolicyHealthScaleOut.productTierAttr.errorAttr = (((productTierVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Out_PolicyHealthScale.ProductName.Error = If
outVars.value.out_PolicyHealthScaleOut.productNameAttr.errorAttr = (((productNameVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Out_PolicyHealthScale.RateScale.Error = If
outVars.value.out_PolicyHealthScaleOut.rateScaleAttr.errorAttr = (((rateScaleVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Out_PolicyHealthScale.OtherRateScale.Error = If
outVars.value.out_PolicyHealthScaleOut.otherRateScaleAttr.errorAttr = (((otherRateScaleVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FWpU_S7d+0yHnG5uudUpoQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Out_PolicyHealthScale.OtherProductName.Error = If
outVars.value.out_PolicyHealthScaleOut.otherProductNameAttr.errorAttr = (((otherProductNameVar.value.positionOut === -1)) ? (OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id)) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7Ks3NkOl5k+2KYg7cUReVw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:c_JR05dkKkOrJpL8lHSm9w", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_HealthScale$vars", [{
name: "PolicyHealthScale",
attrName: "policyHealthScaleInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyHealthScaleRec();
},
complexType: PHICoreModel.PolicyHealthScaleRec
}, {
name: "HealthScaleLists",
attrName: "healthScaleListsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.HealthScaleListsRec();
},
complexType: PHICoreModel.HealthScaleListsRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_HealthScale$outVars", [{
name: "Out_PolicyHealthScale",
attrName: "out_PolicyHealthScaleOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyHealthScaleRec();
},
complexType: PHICoreModel.PolicyHealthScaleRec
}]);
PHICoreController.default.clientActionProxies.validate_HealthScale$Action = function (policyHealthScaleIn, healthScaleListsIn) {
policyHealthScaleIn = (policyHealthScaleIn === undefined) ? new PHICoreModel.PolicyHealthScaleRec() : policyHealthScaleIn;
healthScaleListsIn = (healthScaleListsIn === undefined) ? new PHICoreModel.HealthScaleListsRec() : healthScaleListsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_HealthScale$Action.bind(controller, policyHealthScaleIn, healthScaleListsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_PolicyHealthScale: actionResults.out_PolicyHealthScaleOut
};
});
};
});

define("PHICore.controller$Validate_LHCABD_List", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$MemberLHCABDStructureRec", "PHICore.controller$ValidateLHCABDDetails", "PHICore.model$MemberLHCABDStructureList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_LHCABD_List$Action = function (memberLHCABDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_LHCABD_List$vars"))());
vars.value.memberLHCABDInLocal = memberLHCABDIn.clone();
var validateLHCABDDetailsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_LHCABD_List$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateLHCABDDetailsVar = validateLHCABDDetailsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:NBHwEHdOrU2EW+cv9Wf1yQ:/ClientActionFlows.NBHwEHdOrU2EW+cv9Wf1yQ:EgaBziVOeWXTanK7+Lks6Q", "PHICore", "Validate_LHCABD_List", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BgAjl+pakUafscRYYAJDVg", callContext.id);
// Foreach MemberLHCABD
callContext.iterationContext.registerIterationStart(vars.value.memberLHCABDInLocal);
try {var memberLHCABDIterator = callContext.iterationContext.getIterator(vars.value.memberLHCABDInLocal);
var memberLHCABDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:clvIdvF2wkGAJP9paI1j3A", callContext.id) && (memberLHCABDIndex < vars.value.memberLHCABDInLocal.length))) {
memberLHCABDIterator.currentRowNumber = memberLHCABDIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:W7U+15oly0K0nj9cZfl4Fg", callContext.id);
// Execute Action: ValidateLHCABDDetails
validateLHCABDDetailsVar.value = PHICoreController.default.validateLHCABDDetails$Action(vars.value.memberLHCABDInLocal.getItem(memberLHCABDIndex.valueOf()), callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2X2yjY5AoE6LRQ1pv0aBcg", callContext.id);
// IsValid = If
outVars.value.isValidOut = (((outVars.value.isValidOut === false)) ? (false) : (validateLHCABDDetailsVar.value.isValidOut));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2X2yjY5AoE6LRQ1pv0aBcg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberLHCABD.Current = ValidateLHCABDDetails.MemberLHCABD_Updated
vars.value.memberLHCABDInLocal.setItem(memberLHCABDIndex.valueOf(),validateLHCABDDetailsVar.value.memberLHCABD_UpdatedOut);
memberLHCABDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.memberLHCABDInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZxHKonVOlUyTbU+2b6Rnhg", callContext.id);
// MemberLHCABD_Updated = MemberLHCABD
outVars.value.memberLHCABD_UpdatedOut = vars.value.memberLHCABDInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zm4aj+BYgEqcaBvXTv11eg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:NBHwEHdOrU2EW+cv9Wf1yQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_LHCABD_List$vars", [{
name: "MemberLHCABD",
attrName: "memberLHCABDInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureList();
},
complexType: PHICoreModel.MemberLHCABDStructureList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_LHCABD_List$outVars", [{
name: "MemberLHCABD_Updated",
attrName: "memberLHCABD_UpdatedOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureList();
},
complexType: PHICoreModel.MemberLHCABDStructureList
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validate_LHCABD_List$Action = function (memberLHCABDIn) {
memberLHCABDIn = (memberLHCABDIn === undefined) ? new PHICoreModel.MemberLHCABDStructureList() : memberLHCABDIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_LHCABD_List$Action.bind(controller, memberLHCABDIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberLHCABD_Updated: actionResults.memberLHCABD_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$Validate_Prospect", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$MemberDetailsStructureRec", "PHICore.controller$ValidateMemberPersonalDetails", "PHICore.model$MemberLHCABDStructureRec", "PHICore.controller$ValidateLHCABDDetails", "PHICore.model$Stakeholder_AdditionalDetailsRec", "PHICore.controller$Check_Additional_Details", "PHICore.model$StakeholderAddressList", "PHICore.model$StakeholderEmailList", "PHICore.model$StakeholderPhoneList", "PHICore.model$ContactDetail_CountRec", "PHICore.model$ContactDetails_SettingsRec", "PHICore.model$ContactDetails_ValidationRec", "PHICore.controller$Check_Contact_Details", "PHICore.model$TextTextStakeholder_AdditionalDetailsRecord"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_Prospect$Action = function (memberDetailsStructureIn, memberLHCABDIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, additionalDetailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_Prospect$vars"))());
vars.value.memberDetailsStructureInLocal = memberDetailsStructureIn.clone();
vars.value.memberLHCABDInLocal = memberLHCABDIn.clone();
vars.value.addressList_HandlerInLocal = addressList_HandlerIn.clone();
vars.value.emailList_HandlerInLocal = emailList_HandlerIn.clone();
vars.value.phoneList_HandlerInLocal = phoneList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
vars.value.contactDetailSettingInLocal = contactDetailSettingIn.clone();
vars.value.additionalDetailsInLocal = additionalDetailsIn.clone();
var validateMemberPersonalDetailsVar = new OS.DataTypes.VariableHolder();
var validateLHCABDDetailsVar = new OS.DataTypes.VariableHolder();
var check_Additional_DetailsVar = new OS.DataTypes.VariableHolder();
var check_Contact_DetailsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_Prospect$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateMemberPersonalDetailsVar = validateMemberPersonalDetailsVar;
varBag.validateLHCABDDetailsVar = validateLHCABDDetailsVar;
varBag.check_Additional_DetailsVar = check_Additional_DetailsVar;
varBag.check_Contact_DetailsVar = check_Contact_DetailsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:1rnb7QBbOUehhH9Inq5c2w:/ClientActionFlows.1rnb7QBbOUehhH9Inq5c2w:0zPTP7UUWVgaqffSNbiE4Q", "PHICore", "Validate_Prospect", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S7CtTjZD_kql_ssdTHgVog", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pGVHSZahWEaDJVC2rgjFIw", callContext.id);
// Execute Action: ValidateMemberPersonalDetails
validateMemberPersonalDetailsVar.value = PHICoreController.default.validateMemberPersonalDetails$Action(vars.value.memberDetailsStructureInLocal, true, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ic62T50kwEi_HZc99gzJJg", callContext.id);
// Execute Action: ValidateLHCABDDetails
validateLHCABDDetailsVar.value = PHICoreController.default.validateLHCABDDetails$Action(vars.value.memberLHCABDInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AGVW3+0bhkahUxT6avPzEA", callContext.id);
// Execute Action: Check_Contact_Details
check_Contact_DetailsVar.value = PHICoreController.default.check_Contact_Details$Action(vars.value.addressList_HandlerInLocal, vars.value.emailList_HandlerInLocal, vars.value.phoneList_HandlerInLocal, vars.value.countRecord_HandlerInLocal, vars.value.contactDetailSettingInLocal, PHICoreModel.staticEntities.stakeholderType.prospect, false, false, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:db2YX_wP1USHN8UmNJUPVg", callContext.id);
// Execute Action: Check_Additional_Details
check_Additional_DetailsVar.value = PHICoreController.default.check_Additional_Details$Action(vars.value.additionalDetailsInLocal.stakeholder_AdditionalDetailsAttr, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id);
// hasError = If
outVars.value.hasErrorOut = ((outVars.value.hasErrorOut) ? (outVars.value.hasErrorOut) : ((((!(validateMemberPersonalDetailsVar.value.isValidOut) || !(validateLHCABDDetailsVar.value.isValidOut)) || check_Contact_DetailsVar.value.hasErrorOut) || check_Additional_DetailsVar.value.hasErrorOut)));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberDetailsStructure_Out = ValidateMemberPersonalDetails.MemberDetailsStructure_Updated
outVars.value.memberDetailsStructure_OutOut = validateMemberPersonalDetailsVar.value.memberDetailsStructure_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// MemberLHCABD_Out = ValidateLHCABDDetails.MemberLHCABD_Updated
outVars.value.memberLHCABD_OutOut = validateLHCABDDetailsVar.value.memberLHCABD_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AddressList_Handler_Out = Check_Contact_Details.AddressList_Handler_Out
outVars.value.addressList_Handler_OutOut = check_Contact_DetailsVar.value.addressList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// EmailList_Handler_Out = Check_Contact_Details.EmailList_Handler_Out
outVars.value.emailList_Handler_OutOut = check_Contact_DetailsVar.value.emailList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PhoneList_Handler_Out = Check_Contact_Details.PhoneList_Handler_Out
outVars.value.phoneList_Handler_OutOut = check_Contact_DetailsVar.value.phoneList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// CountRecord_Handler_Out = Check_Contact_Details.CountRecord_Handler_Out
outVars.value.countRecord_Handler_OutOut = check_Contact_DetailsVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// ErrorFeedbackMessage = Check_Contact_Details.ErrorFeedbackMessage
outVars.value.errorFeedbackMessageOut = check_Contact_DetailsVar.value.errorFeedbackMessageOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// AdditionalDetails_Out = AdditionalDetails
outVars.value.additionalDetails_OutOut = vars.value.additionalDetailsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// AdditionalDetails_Out.LocationError = Check_Additional_Details.LocationError
outVars.value.additionalDetails_OutOut.locationErrorAttr = check_Additional_DetailsVar.value.locationErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// AdditionalDetails_Out.SiteError = Check_Additional_Details.SiteError
outVars.value.additionalDetails_OutOut.siteErrorAttr = check_Additional_DetailsVar.value.siteErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RqAU4bSn8UKNDVhhaFBN7w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// ContactDetails_Validation = Check_Contact_Details.ContactDetails_Validation
outVars.value.contactDetails_ValidationOut = check_Contact_DetailsVar.value.contactDetails_ValidationOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HH30dH4V3UGzljPGeOTkHQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:1rnb7QBbOUehhH9Inq5c2w", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_Prospect$vars", [{
name: "MemberDetailsStructure",
attrName: "memberDetailsStructureInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD",
attrName: "memberLHCABDInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}, {
name: "AddressList_Handler",
attrName: "addressList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler",
attrName: "emailList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler",
attrName: "phoneList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "ContactDetailSetting",
attrName: "contactDetailSettingInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_SettingsRec();
},
complexType: PHICoreModel.ContactDetails_SettingsRec
}, {
name: "AdditionalDetails",
attrName: "additionalDetailsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.TextTextStakeholder_AdditionalDetailsRecord();
},
complexType: PHICoreModel.TextTextStakeholder_AdditionalDetailsRecord
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_Prospect$outVars", [{
name: "MemberDetailsStructure_Out",
attrName: "memberDetailsStructure_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD_Out",
attrName: "memberLHCABD_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}, {
name: "AddressList_Handler_Out",
attrName: "addressList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler_Out",
attrName: "emailList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler_Out",
attrName: "phoneList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "AdditionalDetails_Out",
attrName: "additionalDetails_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.TextTextStakeholder_AdditionalDetailsRecord();
},
complexType: PHICoreModel.TextTextStakeholder_AdditionalDetailsRecord
}, {
name: "ContactDetails_Validation",
attrName: "contactDetails_ValidationOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_ValidationRec();
},
complexType: PHICoreModel.ContactDetails_ValidationRec
}]);
PHICoreController.default.clientActionProxies.validate_Prospect$Action = function (memberDetailsStructureIn, memberLHCABDIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, additionalDetailsIn) {
memberDetailsStructureIn = (memberDetailsStructureIn === undefined) ? new PHICoreModel.MemberDetailsStructureRec() : memberDetailsStructureIn;
memberLHCABDIn = (memberLHCABDIn === undefined) ? new PHICoreModel.MemberLHCABDStructureRec() : memberLHCABDIn;
addressList_HandlerIn = (addressList_HandlerIn === undefined) ? new PHICoreModel.StakeholderAddressList() : addressList_HandlerIn;
emailList_HandlerIn = (emailList_HandlerIn === undefined) ? new PHICoreModel.StakeholderEmailList() : emailList_HandlerIn;
phoneList_HandlerIn = (phoneList_HandlerIn === undefined) ? new PHICoreModel.StakeholderPhoneList() : phoneList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
contactDetailSettingIn = (contactDetailSettingIn === undefined) ? new PHICoreModel.ContactDetails_SettingsRec() : contactDetailSettingIn;
additionalDetailsIn = (additionalDetailsIn === undefined) ? new PHICoreModel.TextTextStakeholder_AdditionalDetailsRecord() : additionalDetailsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_Prospect$Action.bind(controller, memberDetailsStructureIn, memberLHCABDIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, additionalDetailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberDetailsStructure_Out: actionResults.memberDetailsStructure_OutOut,
MemberLHCABD_Out: actionResults.memberLHCABD_OutOut,
AddressList_Handler_Out: actionResults.addressList_Handler_OutOut,
EmailList_Handler_Out: actionResults.emailList_Handler_OutOut,
PhoneList_Handler_Out: actionResults.phoneList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
AdditionalDetails_Out: actionResults.additionalDetails_OutOut,
ContactDetails_Validation: actionResults.contactDetails_ValidationOut
};
});
};
});

define("PHICore.controller$Validate_QuotePolicyDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$PolicyDetails_TempRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_QuotePolicyDetails$Action = function (policyDetails_TempIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_QuotePolicyDetails$vars"))());
vars.value.policyDetails_TempInLocal = policyDetails_TempIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_QuotePolicyDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:orEKWrrJK0iupCqMgAOqsA:/ClientActionFlows.orEKWrrJK0iupCqMgAOqsA:3sD5cwvL62dLE2kXUBWPAg", "PHICore", "Validate_QuotePolicyDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eajQGGkSTEiEBOdZTM6gyA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id);
// PolicyDetails_Temp.Cover.Error = ""
vars.value.policyDetails_TempInLocal.coverAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PolicyDetails_Temp.PolicyStartDate.Error = ""
vars.value.policyDetails_TempInLocal.policyStartDateAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PolicyDetails_Temp.PolicyClass.Error = ""
vars.value.policyDetails_TempInLocal.policyClassAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// PolicyDetails_Temp.State.Error = ""
vars.value.policyDetails_TempInLocal.stateAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// PolicyDetails_Temp.ResidencyStatus.Error = ""
vars.value.policyDetails_TempInLocal.residencyStatusAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// PolicyDetails_Temp.RebateAge.Error = ""
vars.value.policyDetails_TempInLocal.rebateAgeAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// PolicyDetails_Temp.RebateTier.Error = ""
vars.value.policyDetails_TempInLocal.rebateTierAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0gCRF6a8aESzuxe1YP9pNA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// PolicyDetails_Temp.RebateLevel.Error = ""
vars.value.policyDetails_TempInLocal.rebateLevelAttr.errorAttr = "";
// no cover
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Gdq36rjHBEWtZAFr+_jjsA", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.coverAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:y5MoUPJu0ki+bxaFm+ns4Q", callContext.id);
// PolicyDetails_Temp.Cover.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.coverAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:y5MoUPJu0ki+bxaFm+ns4Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no date
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XzamQFNDUU2qvUgJvoNI2w", callContext.id) && vars.value.policyDetails_TempInLocal.policyStartDateAttr.valueAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZjrElaTXd0iR14K3VzZzFw", callContext.id);
// PolicyDetails_Temp.PolicyStartDate.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.policyStartDateAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZjrElaTXd0iR14K3VzZzFw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no PolicyClass
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DT2CGyzJAka2keEo9KIx8Q", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.policyClassAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ouBhSnmX3EiHT2+VEkQzmA", callContext.id);
// PolicyDetails_Temp.PolicyClass.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.policyClassAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ouBhSnmX3EiHT2+VEkQzmA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no State
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rB2_RJIgoUaegQa8b4u_Fw", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.stateAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S9JC8Nu+skG4viJVGqO1iw", callContext.id);
// PolicyDetails_Temp.State.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.stateAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S9JC8Nu+skG4viJVGqO1iw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no ResidencyStatus
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hSFRdPhMtkWvpF9K6MHakg", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.residencyStatusAttr.codeAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XQHSApIOjkOMZ9CjKBbc2Q", callContext.id);
// PolicyDetails_Temp.ResidencyStatus.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.residencyStatusAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XQHSApIOjkOMZ9CjKBbc2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no RebateAge
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+p+0esywzUSRsjAg4u+tQw", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateAgeAttr.codeAttr) === "") && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateLevelAttr.codeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UyXNfMfT6kGYAt+e2ubbSg", callContext.id);
// PolicyDetails_Temp.RebateAge.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.rebateAgeAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UyXNfMfT6kGYAt+e2ubbSg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no RebateTier
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JC+3qSx5Hk2EHLBsqLriIQ", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateTierAttr.codeAttr) === "") && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateLevelAttr.codeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7h3e3Aj0Zki98QsScKTbHg", callContext.id);
// PolicyDetails_Temp.RebateTier.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.rebateTierAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7h3e3Aj0Zki98QsScKTbHg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

// no RebateLevel
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3h2zmYZkDUOYchfumKaHpw", callContext.id) && (((OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateLevelAttr.codeAttr) === "") && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateAgeAttr.codeAttr) === "")) && (OS.BuiltinFunctions.trim(vars.value.policyDetails_TempInLocal.rebateTierAttr.codeAttr) === "")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v_Hd8S_OqUyLBAmHvnEU4g", callContext.id);
// PolicyDetails_Temp.RebateLevel.Error = GetRequiredFieldMsg()
vars.value.policyDetails_TempInLocal.rebateLevelAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v_Hd8S_OqUyLBAmHvnEU4g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// hasError = True
outVars.value.hasErrorOut = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5VTZdA0ayEetncX7vOdZvA", callContext.id);
// PolicyDetails_Out = PolicyDetails_Temp
outVars.value.policyDetails_OutOut = vars.value.policyDetails_TempInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qt+1Iij8RkK7SJgKe8R9Fg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:orEKWrrJK0iupCqMgAOqsA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_QuotePolicyDetails$vars", [{
name: "PolicyDetails_Temp",
attrName: "policyDetails_TempInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyDetails_TempRec();
},
complexType: PHICoreModel.PolicyDetails_TempRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_QuotePolicyDetails$outVars", [{
name: "PolicyDetails_Out",
attrName: "policyDetails_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyDetails_TempRec();
},
complexType: PHICoreModel.PolicyDetails_TempRec
}, {
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.validate_QuotePolicyDetails$Action = function (policyDetails_TempIn) {
policyDetails_TempIn = (policyDetails_TempIn === undefined) ? new PHICoreModel.PolicyDetails_TempRec() : policyDetails_TempIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_QuotePolicyDetails$Action.bind(controller, policyDetails_TempIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
PolicyDetails_Out: actionResults.policyDetails_OutOut,
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$Validate_RebateDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$RebateDetailsWithValidationList"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_RebateDetails$Action = function (rebateDetailsIn, hasErrorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_RebateDetails$vars"))());
vars.value.rebateDetailsInLocal = rebateDetailsIn.clone();
vars.value.hasErrorInLocal = hasErrorIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_RebateDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:nFGTyz3A3EuyrJ5lRQ0bOw:/ClientActionFlows.nFGTyz3A3EuyrJ5lRQ0bOw:YTUpbqOEBT9b2FMBQpYSbQ", "PHICore", "Validate_RebateDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UgPGxQ47pEevQ7rMadAkqg", callContext.id);
// Foreach RebateDetails
callContext.iterationContext.registerIterationStart(vars.value.rebateDetailsInLocal);
try {var rebateDetailsIterator = callContext.iterationContext.getIterator(vars.value.rebateDetailsInLocal);
var rebateDetailsIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zdKzpdbWek+bh5dy4Wdmrw", callContext.id) && (rebateDetailsIndex < vars.value.rebateDetailsInLocal.length))) {
rebateDetailsIterator.currentRowNumber = rebateDetailsIndex;
// No Rebate Applicant
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:R8E9z1agcU6OSpjzSNsW1A", callContext.id) && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateApplicantAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eL2dblc4PEOEwIDbO6xa1A", callContext.id);
// HasError = True
vars.value.hasErrorInLocal = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eL2dblc4PEOEwIDbO6xa1A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RebateDetails.Current.RebateApplicantValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateApplicantValidationAttr.errorAttr = "Required field";
}

// Null RebateActionId
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kNvCZrklVUSOvZBy0FSDYQ", callContext.id) && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateActionAttr === (OS.BuiltinFunctions.nullIdentifier()).toString()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wYmf8ixA_kykiQuL6TTcBw", callContext.id);
// RebateDetails.Current.RebateActionValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateActionValidationAttr.errorAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wYmf8ixA_kykiQuL6TTcBw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
vars.value.hasErrorInLocal = true;
}

// Null Date
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WeXpdhLhDUifotWJE9MQYg", callContext.id) && vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).effectiveDateAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AnAFbQJmL0mysa9m3YfBqA", callContext.id);
// RebateDetails.Current.EffectiveDateValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).effectiveDateValidationAttr.errorAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AnAFbQJmL0mysa9m3YfBqA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
vars.value.hasErrorInLocal = true;
}

// No Selected Rebate Age
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:guy5cmBqY0a2S6DgLYZytw", callContext.id) && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateFieldsBooleanAttr.isShowRebateAgeAttr && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateAgeAttr === (OS.BuiltinFunctions.nullIdentifier()).toString())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:26FnzWklrEmOLrSi4NvdkA", callContext.id);
// RebateDetails.Current.RebateAgeValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateAgeValidationAttr.errorAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:26FnzWklrEmOLrSi4NvdkA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
vars.value.hasErrorInLocal = true;
}

// No Previous Fund Name
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+mmF6Fd6DkaaMryptNC_cg", callContext.id) && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateFieldsBooleanAttr.isShowPreviousFieldAttr && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).previousFundNameAttr === OS.BuiltinFunctions.nullTextIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+f8lRY8XUEOrUNNG99j8Zw", callContext.id);
// RebateDetails.Current.PreviousFundNameValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).previousFundNameValidationAttr.errorAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+f8lRY8XUEOrUNNG99j8Zw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
vars.value.hasErrorInLocal = true;
}

// No Previous Policy Number
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XcbsdochY0mo2xwZ8BlNQQ", callContext.id) && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).rebateFieldsBooleanAttr.isShowPreviousFieldAttr && (vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).previousPolicyNumberAttr === OS.BuiltinFunctions.nullTextIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Vmcq3pAEvUaiVX0QCj4Atg", callContext.id);
// RebateDetails.Current.PreviousPolicyNumValidation.Error = "Required field"
vars.value.rebateDetailsInLocal.getItem(rebateDetailsIndex.valueOf()).previousPolicyNumValidationAttr.errorAttr = "Required field";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Vmcq3pAEvUaiVX0QCj4Atg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HasError = True
vars.value.hasErrorInLocal = true;
}

rebateDetailsIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.rebateDetailsInLocal);
}

// Output Variables
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j0Pi3BvFRkqZUFjI_lEXHA", callContext.id);
// Out_RebateDetails = RebateDetails
outVars.value.out_RebateDetailsOut = vars.value.rebateDetailsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j0Pi3BvFRkqZUFjI_lEXHA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Out_HasError = HasError
outVars.value.out_HasErrorOut = vars.value.hasErrorInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2cIdtJ+WZUGnNz5PnABlnQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:nFGTyz3A3EuyrJ5lRQ0bOw", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_RebateDetails$vars", [{
name: "RebateDetails",
attrName: "rebateDetailsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RebateDetailsWithValidationList();
},
complexType: PHICoreModel.RebateDetailsWithValidationList
}, {
name: "HasError",
attrName: "hasErrorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_RebateDetails$outVars", [{
name: "Out_RebateDetails",
attrName: "out_RebateDetailsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.RebateDetailsWithValidationList();
},
complexType: PHICoreModel.RebateDetailsWithValidationList
}, {
name: "Out_HasError",
attrName: "out_HasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
PHICoreController.default.clientActionProxies.validate_RebateDetails$Action = function (rebateDetailsIn, hasErrorIn) {
rebateDetailsIn = (rebateDetailsIn === undefined) ? new PHICoreModel.RebateDetailsWithValidationList() : rebateDetailsIn;
hasErrorIn = (hasErrorIn === undefined) ? false : hasErrorIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_RebateDetails$Action.bind(controller, rebateDetailsIn, OS.DataConversion.JSNodeParamConverter.from(hasErrorIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out_RebateDetails: actionResults.out_RebateDetailsOut,
Out_HasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.out_HasErrorOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$Validate_SearchStakeholder", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$MemberDetailsStructureRec", "PHICore.controller$ValidateMemberPersonalDetails", "PHICore.model$MemberLHCABDStructureList", "PHICore.controller$Validate_LHCABD_List", "PHICore.model$PolicyDetails_TempRec", "PHICore.controller$Validate_QuotePolicyDetails", "PHICore.model$Eligibility_StructRec", "PHICore.controller$Check_Eligibility", "PHICore.model$MemberPreExisitingConditionList", "PHICore.controller$ValidatePreExistingCondition", "PHICore.model$Stakeholder_AdditionalDetailsRec", "PHICore.controller$Check_Additional_Details", "PHICore.model$StakeholderAddressList", "PHICore.model$StakeholderEmailList", "PHICore.model$StakeholderPhoneList", "PHICore.model$ContactDetail_CountRec", "PHICore.model$ContactDetails_SettingsRec", "PHICore.model$ContactDetails_ValidationRec", "PHICore.controller$Check_Contact_Details"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validate_SearchStakeholder$Action = function (memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, eligibility_StructIn, policyDetails_TempIn, hasConfiguredEligibilityIn, additionalDetailsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_SearchStakeholder$vars"))());
vars.value.memberDetailsStructureInLocal = memberDetailsStructureIn.clone();
vars.value.memberLHCABDInLocal = memberLHCABDIn.clone();
vars.value.memberPreExisitingConditionInLocal = memberPreExisitingConditionIn.clone();
vars.value.addressList_HandlerInLocal = addressList_HandlerIn.clone();
vars.value.emailList_HandlerInLocal = emailList_HandlerIn.clone();
vars.value.phoneList_HandlerInLocal = phoneList_HandlerIn.clone();
vars.value.countRecord_HandlerInLocal = countRecord_HandlerIn.clone();
vars.value.contactDetailSettingInLocal = contactDetailSettingIn.clone();
vars.value.eligibility_StructInLocal = eligibility_StructIn.clone();
vars.value.policyDetails_TempInLocal = policyDetails_TempIn.clone();
vars.value.hasConfiguredEligibilityInLocal = hasConfiguredEligibilityIn;
vars.value.additionalDetailsInLocal = additionalDetailsIn.clone();
var validateMemberPersonalDetailsVar = new OS.DataTypes.VariableHolder();
var validate_LHCABD_ListVar = new OS.DataTypes.VariableHolder();
var validate_QuotePolicyDetailsVar = new OS.DataTypes.VariableHolder();
var check_EligibilityVar = new OS.DataTypes.VariableHolder();
var validatePreExistingConditionVar = new OS.DataTypes.VariableHolder();
var check_Additional_DetailsVar = new OS.DataTypes.VariableHolder();
var check_Contact_DetailsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Validate_SearchStakeholder$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateMemberPersonalDetailsVar = validateMemberPersonalDetailsVar;
varBag.validate_LHCABD_ListVar = validate_LHCABD_ListVar;
varBag.validate_QuotePolicyDetailsVar = validate_QuotePolicyDetailsVar;
varBag.check_EligibilityVar = check_EligibilityVar;
varBag.validatePreExistingConditionVar = validatePreExistingConditionVar;
varBag.check_Additional_DetailsVar = check_Additional_DetailsVar;
varBag.check_Contact_DetailsVar = check_Contact_DetailsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:NNciE5zsDky4I3E8sGSJiA:/ClientActionFlows.NNciE5zsDky4I3E8sGSJiA:XQI1M8FhYUs8Yidjf1h+eg", "PHICore", "Validate_SearchStakeholder", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Rs0Zo4rKWkO2tEqk_8TvUw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oGAJFhKyv0mGas9XilFZzA", callContext.id);
// Execute Action: ValidateMemberPersonalDetails
validateMemberPersonalDetailsVar.value = PHICoreController.default.validateMemberPersonalDetails$Action(vars.value.memberDetailsStructureInLocal, true, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M2tUaqJ2qE+FPl5AXcN4kw", callContext.id);
// Execute Action: ValidatePreExistingCondition
validatePreExistingConditionVar.value = PHICoreController.default.validatePreExistingCondition$Action(vars.value.memberPreExisitingConditionInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MW2BHDL1sk2fWrrRhbk93w", callContext.id);
// Execute Action: Validate_LHCABD_List
validate_LHCABD_ListVar.value = PHICoreController.default.validate_LHCABD_List$Action(vars.value.memberLHCABDInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cip_STwAYkOe6Kfd_PLgig", callContext.id);
// Execute Action: Validate_QuotePolicyDetails
validate_QuotePolicyDetailsVar.value = PHICoreController.default.validate_QuotePolicyDetails$Action(vars.value.policyDetails_TempInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Aynv_2j1eEq1AFrbZ4CWiQ", callContext.id);
// Execute Action: Check_Contact_Details
check_Contact_DetailsVar.value = PHICoreController.default.check_Contact_Details$Action(vars.value.addressList_HandlerInLocal, vars.value.emailList_HandlerInLocal, vars.value.phoneList_HandlerInLocal, vars.value.countRecord_HandlerInLocal, vars.value.contactDetailSettingInLocal, 0, false, false, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:akw37jalVkSrHmCl+DziZg", callContext.id);
// Execute Action: Check_Additional_Details
check_Additional_DetailsVar.value = PHICoreController.default.check_Additional_Details$Action(vars.value.additionalDetailsInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sl_Bx9pvm0CSjhiHSbb1MA", callContext.id) && vars.value.hasConfiguredEligibilityInLocal)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mGPvUhJ_+EayKPdwhrhxZg", callContext.id);
// Execute Action: Check_Eligibility
check_EligibilityVar.value = PHICoreController.default.check_Eligibility$Action(vars.value.eligibility_StructInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F33ioGeryEuNpNahyjwUxg", callContext.id);
// hasError = Check_Eligibility.hasError
outVars.value.hasErrorOut = check_EligibilityVar.value.hasErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F33ioGeryEuNpNahyjwUxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Eligibility_Handler_Out = Check_Eligibility.Eligibility_Handler_Out
outVars.value.eligibility_Handler_OutOut = check_EligibilityVar.value.eligibility_Handler_OutOut;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id);
// hasError = If
outVars.value.hasErrorOut = ((outVars.value.hasErrorOut) ? (outVars.value.hasErrorOut) : ((((((!(validateMemberPersonalDetailsVar.value.isValidOut) || !(validatePreExistingConditionVar.value.isValidOut)) || !(validate_LHCABD_ListVar.value.isValidOut)) || validate_QuotePolicyDetailsVar.value.hasErrorOut) || check_Contact_DetailsVar.value.hasErrorOut) || check_Additional_DetailsVar.value.hasErrorOut)));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberDetailsStructure_Updated = ValidateMemberPersonalDetails.MemberDetailsStructure_Updated
outVars.value.memberDetailsStructure_UpdatedOut = validateMemberPersonalDetailsVar.value.memberDetailsStructure_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// MemberLHCABD_Updated = Validate_LHCABD_List.MemberLHCABD_Updated
outVars.value.memberLHCABD_UpdatedOut = validate_LHCABD_ListVar.value.memberLHCABD_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// MemberPreExisitingCondition_Updated = ValidatePreExistingCondition.MemberPreExisitingCondition_Updated
outVars.value.memberPreExisitingCondition_UpdatedOut = validatePreExistingConditionVar.value.memberPreExisitingCondition_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// AddressList_Handler_Out = Check_Contact_Details.AddressList_Handler_Out
outVars.value.addressList_Handler_OutOut = check_Contact_DetailsVar.value.addressList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// EmailList_Handler_Out = Check_Contact_Details.EmailList_Handler_Out
outVars.value.emailList_Handler_OutOut = check_Contact_DetailsVar.value.emailList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// PhoneList_Handler_Out = Check_Contact_Details.PhoneList_Handler_Out
outVars.value.phoneList_Handler_OutOut = check_Contact_DetailsVar.value.phoneList_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// CountRecord_Handler_Out = Check_Contact_Details.CountRecord_Handler_Out
outVars.value.countRecord_Handler_OutOut = check_Contact_DetailsVar.value.countRecord_Handler_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// PolicyDetails_Out = Validate_QuotePolicyDetails.PolicyDetails_Out
outVars.value.policyDetails_OutOut = validate_QuotePolicyDetailsVar.value.policyDetails_OutOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// ErrorFeedbackMessage = Check_Contact_Details.ErrorFeedbackMessage
outVars.value.errorFeedbackMessageOut = check_Contact_DetailsVar.value.errorFeedbackMessageOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// AdditionalDetails_Out = AdditionalDetails
outVars.value.additionalDetails_OutOut = vars.value.additionalDetailsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// AdditionalDetails_Out.Location.Error = Check_Additional_Details.LocationError
outVars.value.additionalDetails_OutOut.locationAttr.errorAttr = check_Additional_DetailsVar.value.locationErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// AdditionalDetails_Out.Site.Error = Check_Additional_Details.SiteError
outVars.value.additionalDetails_OutOut.siteAttr.errorAttr = check_Additional_DetailsVar.value.siteErrorOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H3b4HI_zvkat7ibzsyc+7g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// ContactDetails_Validation = Check_Contact_Details.ContactDetails_Validation
outVars.value.contactDetails_ValidationOut = check_Contact_DetailsVar.value.contactDetails_ValidationOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2CDD0u5IhUWhIvsdGOsydQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:NNciE5zsDky4I3E8sGSJiA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_SearchStakeholder$vars", [{
name: "MemberDetailsStructure",
attrName: "memberDetailsStructureInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD",
attrName: "memberLHCABDInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureList();
},
complexType: PHICoreModel.MemberLHCABDStructureList
}, {
name: "MemberPreExisitingCondition",
attrName: "memberPreExisitingConditionInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}, {
name: "AddressList_Handler",
attrName: "addressList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler",
attrName: "emailList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler",
attrName: "phoneList_HandlerInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler",
attrName: "countRecord_HandlerInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "ContactDetailSetting",
attrName: "contactDetailSettingInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_SettingsRec();
},
complexType: PHICoreModel.ContactDetails_SettingsRec
}, {
name: "Eligibility_Struct",
attrName: "eligibility_StructInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Eligibility_StructRec();
},
complexType: PHICoreModel.Eligibility_StructRec
}, {
name: "PolicyDetails_Temp",
attrName: "policyDetails_TempInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyDetails_TempRec();
},
complexType: PHICoreModel.PolicyDetails_TempRec
}, {
name: "hasConfiguredEligibility",
attrName: "hasConfiguredEligibilityInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "AdditionalDetails",
attrName: "additionalDetailsInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_AdditionalDetailsRec();
},
complexType: PHICoreModel.Stakeholder_AdditionalDetailsRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.Validate_SearchStakeholder$outVars", [{
name: "MemberDetailsStructure_Updated",
attrName: "memberDetailsStructure_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD_Updated",
attrName: "memberLHCABD_UpdatedOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureList();
},
complexType: PHICoreModel.MemberLHCABDStructureList
}, {
name: "MemberPreExisitingCondition_Updated",
attrName: "memberPreExisitingCondition_UpdatedOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}, {
name: "AddressList_Handler_Out",
attrName: "addressList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderAddressList();
},
complexType: PHICoreModel.StakeholderAddressList
}, {
name: "EmailList_Handler_Out",
attrName: "emailList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderEmailList();
},
complexType: PHICoreModel.StakeholderEmailList
}, {
name: "PhoneList_Handler_Out",
attrName: "phoneList_Handler_OutOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.StakeholderPhoneList();
},
complexType: PHICoreModel.StakeholderPhoneList
}, {
name: "CountRecord_Handler_Out",
attrName: "countRecord_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetail_CountRec();
},
complexType: PHICoreModel.ContactDetail_CountRec
}, {
name: "Eligibility_Handler_Out",
attrName: "eligibility_Handler_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Eligibility_StructRec();
},
complexType: PHICoreModel.Eligibility_StructRec
}, {
name: "PolicyDetails_Out",
attrName: "policyDetails_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.PolicyDetails_TempRec();
},
complexType: PHICoreModel.PolicyDetails_TempRec
}, {
name: "AdditionalDetails_Out",
attrName: "additionalDetails_OutOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Stakeholder_AdditionalDetailsRec();
},
complexType: PHICoreModel.Stakeholder_AdditionalDetailsRec
}, {
name: "hasError",
attrName: "hasErrorOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorFeedbackMessage",
attrName: "errorFeedbackMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ContactDetails_Validation",
attrName: "contactDetails_ValidationOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.ContactDetails_ValidationRec();
},
complexType: PHICoreModel.ContactDetails_ValidationRec
}]);
PHICoreController.default.clientActionProxies.validate_SearchStakeholder$Action = function (memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, eligibility_StructIn, policyDetails_TempIn, hasConfiguredEligibilityIn, additionalDetailsIn) {
memberDetailsStructureIn = (memberDetailsStructureIn === undefined) ? new PHICoreModel.MemberDetailsStructureRec() : memberDetailsStructureIn;
memberLHCABDIn = (memberLHCABDIn === undefined) ? new PHICoreModel.MemberLHCABDStructureList() : memberLHCABDIn;
memberPreExisitingConditionIn = (memberPreExisitingConditionIn === undefined) ? new PHICoreModel.MemberPreExisitingConditionList() : memberPreExisitingConditionIn;
addressList_HandlerIn = (addressList_HandlerIn === undefined) ? new PHICoreModel.StakeholderAddressList() : addressList_HandlerIn;
emailList_HandlerIn = (emailList_HandlerIn === undefined) ? new PHICoreModel.StakeholderEmailList() : emailList_HandlerIn;
phoneList_HandlerIn = (phoneList_HandlerIn === undefined) ? new PHICoreModel.StakeholderPhoneList() : phoneList_HandlerIn;
countRecord_HandlerIn = (countRecord_HandlerIn === undefined) ? new PHICoreModel.ContactDetail_CountRec() : countRecord_HandlerIn;
contactDetailSettingIn = (contactDetailSettingIn === undefined) ? new PHICoreModel.ContactDetails_SettingsRec() : contactDetailSettingIn;
eligibility_StructIn = (eligibility_StructIn === undefined) ? new PHICoreModel.Eligibility_StructRec() : eligibility_StructIn;
policyDetails_TempIn = (policyDetails_TempIn === undefined) ? new PHICoreModel.PolicyDetails_TempRec() : policyDetails_TempIn;
hasConfiguredEligibilityIn = (hasConfiguredEligibilityIn === undefined) ? false : hasConfiguredEligibilityIn;
additionalDetailsIn = (additionalDetailsIn === undefined) ? new PHICoreModel.Stakeholder_AdditionalDetailsRec() : additionalDetailsIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validate_SearchStakeholder$Action.bind(controller, memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, addressList_HandlerIn, emailList_HandlerIn, phoneList_HandlerIn, countRecord_HandlerIn, contactDetailSettingIn, eligibility_StructIn, policyDetails_TempIn, OS.DataConversion.JSNodeParamConverter.from(hasConfiguredEligibilityIn, OS.Types.Boolean), additionalDetailsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberDetailsStructure_Updated: actionResults.memberDetailsStructure_UpdatedOut,
MemberLHCABD_Updated: actionResults.memberLHCABD_UpdatedOut,
MemberPreExisitingCondition_Updated: actionResults.memberPreExisitingCondition_UpdatedOut,
AddressList_Handler_Out: actionResults.addressList_Handler_OutOut,
EmailList_Handler_Out: actionResults.emailList_Handler_OutOut,
PhoneList_Handler_Out: actionResults.phoneList_Handler_OutOut,
CountRecord_Handler_Out: actionResults.countRecord_Handler_OutOut,
Eligibility_Handler_Out: actionResults.eligibility_Handler_OutOut,
PolicyDetails_Out: actionResults.policyDetails_OutOut,
AdditionalDetails_Out: actionResults.additionalDetails_OutOut,
hasError: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasErrorOut, OS.Types.Boolean),
ErrorFeedbackMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorFeedbackMessageOut, OS.Types.Text),
ContactDetails_Validation: actionResults.contactDetails_ValidationOut
};
});
};
});

define("PHICore.controller$ValidateDocumentUpload", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$DocumentUploadRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validateDocumentUpload$Action = function (binaryIn, fileNameIn, commentsIn, isAttachmentImageIn, fileSizeWithUnitIn, fileSizeInMBIn, fileExtensionIn, supportedFileExtensionsIn, fileSizeLimitIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateDocumentUpload$vars"))());
vars.value.binaryInLocal = binaryIn;
vars.value.fileNameInLocal = fileNameIn;
vars.value.commentsInLocal = commentsIn;
vars.value.isAttachmentImageInLocal = isAttachmentImageIn;
vars.value.fileSizeWithUnitInLocal = fileSizeWithUnitIn;
vars.value.fileSizeInMBInLocal = fileSizeInMBIn;
vars.value.fileExtensionInLocal = fileExtensionIn;
vars.value.supportedFileExtensionsInLocal = supportedFileExtensionsIn.clone();
vars.value.fileSizeLimitInLocal = fileSizeLimitIn;
var listAnyFileExtensionVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateDocumentUpload$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listAnyFileExtensionVar = listAnyFileExtensionVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:PAnewNDLXkyzbNKI28QNrg:/ClientActionFlows.PAnewNDLXkyzbNKI28QNrg:2980tOVrZ20Mi6qnJIefew", "PHICore", "ValidateDocumentUpload", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lj4l20TzK0KIUULocwrGiQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id);
// Document.Binary = Binary
outVars.value.documentOut.binaryAttr = vars.value.binaryInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Document.FileName = FileName
outVars.value.documentOut.fileNameAttr = vars.value.fileNameInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Document.Comments = Comments
outVars.value.documentOut.commentsAttr = vars.value.commentsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Document.IsAttachmentImage = IsAttachmentImage
outVars.value.documentOut.isAttachmentImageAttr = vars.value.isAttachmentImageInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Document.FileSizeWithUnit = FileSizeWithUnit
outVars.value.documentOut.fileSizeWithUnitAttr = vars.value.fileSizeWithUnitInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Document.FileSizeInMB = FileSizeInMB
outVars.value.documentOut.fileSizeInMBAttr = vars.value.fileSizeInMBInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:soj6rUN3UkOtR11WbOkt5w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Document.FileExtension = FileExtension
outVars.value.documentOut.fileExtensionAttr = vars.value.fileExtensionInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+XUmdIDoZEa3oLXnfv6Rig", callContext.id);
// Execute Action: ListAnyFileExtension
listAnyFileExtensionVar.value = OS.SystemActions.listAny(vars.value.supportedFileExtensionsInLocal, function (p) {
return (p === outVars.value.documentOut.fileExtensionAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G9jXiO1ra0CFqh7Lvrrukg", callContext.id) && listAnyFileExtensionVar.value.resultOut)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0sgUzAFFf0W2zgN9w_oAgA", callContext.id) && (outVars.value.documentOut.fileSizeInMBAttr <= vars.value.fileSizeLimitInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:I34Uhd6AUEqc0cS0U0xAzg", callContext.id);
// Document.Error = ""
outVars.value.documentOut.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EWhlvXm5AkKIk+10sycl6w", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iqVNYUAU_EC1phRd9rmHBQ", callContext.id);
// Document.Error = "Upload a file that is less than 30MB"
outVars.value.documentOut.errorAttr = "Upload a file that is less than 30MB";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EWhlvXm5AkKIk+10sycl6w", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DoLNZw_+GEWV0vC8tBodvw", callContext.id);
// Document.Error = "Upload a file with the following file types .jpg, .jpeg, .png, .pdf, .html, .zip, .doc, .docx, .txt"
outVars.value.documentOut.errorAttr = "Upload a file with the following file types .jpg, .jpeg, .png, .pdf, .html, .zip, .doc, .docx, .txt";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EWhlvXm5AkKIk+10sycl6w", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:PAnewNDLXkyzbNKI28QNrg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateDocumentUpload$vars", [{
name: "Binary",
attrName: "binaryInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "FileName",
attrName: "fileNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Comments",
attrName: "commentsInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsAttachmentImage",
attrName: "isAttachmentImageInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "FileSizeWithUnit",
attrName: "fileSizeWithUnitInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "FileSizeInMB",
attrName: "fileSizeInMBInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "FileExtension",
attrName: "fileExtensionInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SupportedFileExtensions",
attrName: "supportedFileExtensionsInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}, {
name: "FileSizeLimit",
attrName: "fileSizeLimitInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateDocumentUpload$outVars", [{
name: "Document",
attrName: "documentOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.DocumentUploadRec();
},
complexType: PHICoreModel.DocumentUploadRec
}]);
PHICoreController.default.clientActionProxies.validateDocumentUpload$Action = function (binaryIn, fileNameIn, commentsIn, isAttachmentImageIn, fileSizeWithUnitIn, fileSizeInMBIn, fileExtensionIn, supportedFileExtensionsIn, fileSizeLimitIn) {
binaryIn = (binaryIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : binaryIn;
fileNameIn = (fileNameIn === undefined) ? "" : fileNameIn;
commentsIn = (commentsIn === undefined) ? "" : commentsIn;
isAttachmentImageIn = (isAttachmentImageIn === undefined) ? false : isAttachmentImageIn;
fileSizeWithUnitIn = (fileSizeWithUnitIn === undefined) ? "" : fileSizeWithUnitIn;
fileSizeInMBIn = (fileSizeInMBIn === undefined) ? 0 : fileSizeInMBIn;
fileExtensionIn = (fileExtensionIn === undefined) ? "" : fileExtensionIn;
supportedFileExtensionsIn = (supportedFileExtensionsIn === undefined) ? new OS.DataTypes.TextList() : supportedFileExtensionsIn;
fileSizeLimitIn = (fileSizeLimitIn === undefined) ? 0 : fileSizeLimitIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validateDocumentUpload$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(binaryIn, OS.Types.BinaryData), OS.DataConversion.JSNodeParamConverter.from(fileNameIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(commentsIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isAttachmentImageIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(fileSizeWithUnitIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(fileSizeInMBIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(fileExtensionIn, OS.Types.Text), supportedFileExtensionsIn, OS.DataConversion.JSNodeParamConverter.from(fileSizeLimitIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Document: actionResults.documentOut
};
});
};
});

define("PHICore.controller$ValidateLHCABDDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$MemberLHCABDStructureRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validateLHCABDDetails$Action = function (memberLHCABDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateLHCABDDetails$vars"))());
vars.value.memberLHCABDInLocal = memberLHCABDIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateLHCABDDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:WxFpZ5jKM0WbUolccGwuKA:/ClientActionFlows.WxFpZ5jKM0WbUolccGwuKA:GatCYJBwbwSygF6OmQ1C9Q", "PHICore", "ValidateLHCABDDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ot+S6H_9+EyB5XkdhCPaJw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S3nkQxxbUUO9KWlWBUW46A", callContext.id);
// MemberLHCABD.ABDEntryAge.Error = ""
vars.value.memberLHCABDInLocal.aBDEntryAgeAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S3nkQxxbUUO9KWlWBUW46A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberLHCABD.LHCOverridePercent.Error = ""
vars.value.memberLHCABDInLocal.lHCOverridePercentAttr.errorAttr = "";
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1R_p5mn5EESfZIHJCpR0JA", callContext.id) && (!(((vars.value.memberLHCABDInLocal.aBDEntryAgeAttr.valueAttr >= 18) && (vars.value.memberLHCABDInLocal.aBDEntryAgeAttr.valueAttr <= 29))) && ((vars.value.memberLHCABDInLocal.aBDEntryAgeAttr.valueAttr) !== (0))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JFYy0TgJA0aJwlddyCLEKw", callContext.id);
// MemberLHCABD.ABDEntryAge.Error = "Enter a range between 18-29"
vars.value.memberLHCABDInLocal.aBDEntryAgeAttr.errorAttr = "Enter a range between 18-29";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JFYy0TgJA0aJwlddyCLEKw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RH7Mk1TNJ0+igPQihrMAew", callContext.id);
// MemberLHCABD_Updated = MemberLHCABD
outVars.value.memberLHCABD_UpdatedOut = vars.value.memberLHCABDInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jZrvzfSmVkOX3wm2Z1romQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:WxFpZ5jKM0WbUolccGwuKA", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateLHCABDDetails$vars", [{
name: "MemberLHCABD",
attrName: "memberLHCABDInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateLHCABDDetails$outVars", [{
name: "MemberLHCABD_Updated",
attrName: "memberLHCABD_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validateLHCABDDetails$Action = function (memberLHCABDIn) {
memberLHCABDIn = (memberLHCABDIn === undefined) ? new PHICoreModel.MemberLHCABDStructureRec() : memberLHCABDIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validateLHCABDDetails$Action.bind(controller, memberLHCABDIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberLHCABD_Updated: actionResults.memberLHCABD_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$ValidateMember_Client", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.clientVariables", "PHICore.model$MemberDetailsStructureRec", "PHICore.controller$ValidateMemberPersonalDetails", "PHICore.model$MemberPreExisitingConditionList", "PHICore.controller$ValidatePreExistingCondition", "PHICore.model$MemberLHCABDStructureRec", "PHICore.controller$ValidateLHCABDDetails", "PHICore.model$MemberStudentDetailRec", "PHICore.controller$ValidateStudentDetails", "PHICore.model$BooleanBooleanBooleanBooleanBooleanBooleanRecord"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validateMember_Client$Action = function (memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, memberStudentDetailIn, accordionsIn, isValidateLHCABDIn, isValidateStudentDetailsIn, isValidatePreExistingConditionIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateMember_Client$vars"))());
vars.value.memberDetailsStructureInLocal = memberDetailsStructureIn.clone();
vars.value.memberLHCABDInLocal = memberLHCABDIn.clone();
vars.value.memberPreExisitingConditionInLocal = memberPreExisitingConditionIn.clone();
vars.value.memberStudentDetailInLocal = memberStudentDetailIn.clone();
vars.value.accordionsInLocal = accordionsIn.clone();
vars.value.isValidateLHCABDInLocal = isValidateLHCABDIn;
vars.value.isValidateStudentDetailsInLocal = isValidateStudentDetailsIn;
vars.value.isValidatePreExistingConditionInLocal = isValidatePreExistingConditionIn;
var validateMemberPersonalDetailsVar = new OS.DataTypes.VariableHolder();
var validatePreExistingConditionVar = new OS.DataTypes.VariableHolder();
var validateLHCABDDetailsVar = new OS.DataTypes.VariableHolder();
var validateStudentDetailsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateMember_Client$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateMemberPersonalDetailsVar = validateMemberPersonalDetailsVar;
varBag.validatePreExistingConditionVar = validatePreExistingConditionVar;
varBag.validateLHCABDDetailsVar = validateLHCABDDetailsVar;
varBag.validateStudentDetailsVar = validateStudentDetailsVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XfvPVQZnFUu3S3VVetVExg:/ClientActionFlows.XfvPVQZnFUu3S3VVetVExg:D82eZcgRYN7lUuzXJ+LpTA", "PHICore", "ValidateMember_Client", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:A6f+8G+yq0yzPcl9NKJbvA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xdFqFgr0DkKwnJ_fjuj6dA", callContext.id);
// Execute Action: ValidateMemberPersonalDetails
validateMemberPersonalDetailsVar.value = PHICoreController.default.validateMemberPersonalDetails$Action(vars.value.memberDetailsStructureInLocal, true, callContext);

// Not Valid Member Details
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cPE1ebKtJ0Cx2TIjYRnwiQ", callContext.id) && !(validateMemberPersonalDetailsVar.value.isValidOut))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Z4l1v_KBrUqmESC7rmfuKw", callContext.id);
// IsValid = ValidateMemberPersonalDetails.IsValid
outVars.value.isValidOut = validateMemberPersonalDetailsVar.value.isValidOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Z4l1v_KBrUqmESC7rmfuKw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Accordions.PersonalDetailsExpanded = True
vars.value.accordionsInLocal.personalDetailsExpandedAttr = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w5TnSdroLUSz3azqNx52ZA", callContext.id);
// Execute Action: ValidateLHCABDDetails
validateLHCABDDetailsVar.value = PHICoreController.default.validateLHCABDDetails$Action(vars.value.memberLHCABDInLocal, callContext);

// Not valid LHC
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jOLrzdwbuEKyFF1WX0bDtQ", callContext.id) && (!(validateLHCABDDetailsVar.value.isValidOut) && vars.value.isValidateLHCABDInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d+QmIX5bkEqbPOFeDwoqqw", callContext.id);
// IsValid = ValidateLHCABDDetails.IsValid
outVars.value.isValidOut = validateLHCABDDetailsVar.value.isValidOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:d+QmIX5bkEqbPOFeDwoqqw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Accordions.LHC_ABDDetailsExpanded = True
vars.value.accordionsInLocal.lHC_ABDDetailsExpandedAttr = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kXxkObMDPEWSLoh9Gk1Qfw", callContext.id);
// Execute Action: ValidatePreExistingCondition
validatePreExistingConditionVar.value = PHICoreController.default.validatePreExistingCondition$Action(vars.value.memberPreExisitingConditionInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:djPwZRzCCEak3d_GOHnxkQ", callContext.id) && (!(validatePreExistingConditionVar.value.isValidOut) && vars.value.isValidatePreExistingConditionInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3N1q5o8qt0GmSGdwah76pw", callContext.id);
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3N1q5o8qt0GmSGdwah76pw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Accordions.PreExistingConditionExpanded = True
vars.value.accordionsInLocal.preExistingConditionExpandedAttr = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cLXmynZDdEuIGzDeryShCA", callContext.id);
// Execute Action: ValidateStudentDetails
validateStudentDetailsVar.value = PHICoreController.default.validateStudentDetails$Action(vars.value.memberStudentDetailInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9o1bqPOOY06biHhCCIJOkg", callContext.id) && (!(validateStudentDetailsVar.value.isValidOut) && vars.value.isValidateStudentDetailsInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v2uguIbQM0G1otDoqIhjJQ", callContext.id);
// IsValid = False
outVars.value.isValidOut = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v2uguIbQM0G1otDoqIhjJQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Accordions.StudentDetailsExpanded = True
vars.value.accordionsInLocal.studentDetailsExpandedAttr = true;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r8Icxl2kTEyfze4dSWJv2Q", callContext.id);
// MemberDetailsStructure_Updated = ValidateMemberPersonalDetails.MemberDetailsStructure_Updated
outVars.value.memberDetailsStructure_UpdatedOut = validateMemberPersonalDetailsVar.value.memberDetailsStructure_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r8Icxl2kTEyfze4dSWJv2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberLHCABD_Updated = ValidateLHCABDDetails.MemberLHCABD_Updated
outVars.value.memberLHCABD_UpdatedOut = validateLHCABDDetailsVar.value.memberLHCABD_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r8Icxl2kTEyfze4dSWJv2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// MemberPreExisitingCondition_Updated = ValidatePreExistingCondition.MemberPreExisitingCondition_Updated
outVars.value.memberPreExisitingCondition_UpdatedOut = validatePreExistingConditionVar.value.memberPreExisitingCondition_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r8Icxl2kTEyfze4dSWJv2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// MemberStudentDetail_Updated = ValidateStudentDetails.MemberStudentDetail_Updated
outVars.value.memberStudentDetail_UpdatedOut = validateStudentDetailsVar.value.memberStudentDetail_UpdatedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r8Icxl2kTEyfze4dSWJv2Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Accordions_Updated = Accordions
outVars.value.accordions_UpdatedOut = vars.value.accordionsInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dIrJa34vgE6neA3XQCO+jQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XfvPVQZnFUu3S3VVetVExg", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateMember_Client$vars", [{
name: "MemberDetailsStructure",
attrName: "memberDetailsStructureInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD",
attrName: "memberLHCABDInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}, {
name: "MemberPreExisitingCondition",
attrName: "memberPreExisitingConditionInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}, {
name: "MemberStudentDetail",
attrName: "memberStudentDetailInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberStudentDetailRec();
},
complexType: PHICoreModel.MemberStudentDetailRec
}, {
name: "Accordions",
attrName: "accordionsInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.BooleanBooleanBooleanBooleanBooleanBooleanRecord();
},
complexType: PHICoreModel.BooleanBooleanBooleanBooleanBooleanBooleanRecord
}, {
name: "IsValidateLHCABD",
attrName: "isValidateLHCABDInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "IsValidateStudentDetails",
attrName: "isValidateStudentDetailsInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "IsValidatePreExistingCondition",
attrName: "isValidatePreExistingConditionInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateMember_Client$outVars", [{
name: "MemberDetailsStructure_Updated",
attrName: "memberDetailsStructure_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "MemberLHCABD_Updated",
attrName: "memberLHCABD_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberLHCABDStructureRec();
},
complexType: PHICoreModel.MemberLHCABDStructureRec
}, {
name: "MemberPreExisitingCondition_Updated",
attrName: "memberPreExisitingCondition_UpdatedOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}, {
name: "MemberStudentDetail_Updated",
attrName: "memberStudentDetail_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberStudentDetailRec();
},
complexType: PHICoreModel.MemberStudentDetailRec
}, {
name: "Accordions_Updated",
attrName: "accordions_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.BooleanBooleanBooleanBooleanBooleanBooleanRecord();
},
complexType: PHICoreModel.BooleanBooleanBooleanBooleanBooleanBooleanRecord
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validateMember_Client$Action = function (memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, memberStudentDetailIn, accordionsIn, isValidateLHCABDIn, isValidateStudentDetailsIn, isValidatePreExistingConditionIn) {
memberDetailsStructureIn = (memberDetailsStructureIn === undefined) ? new PHICoreModel.MemberDetailsStructureRec() : memberDetailsStructureIn;
memberLHCABDIn = (memberLHCABDIn === undefined) ? new PHICoreModel.MemberLHCABDStructureRec() : memberLHCABDIn;
memberPreExisitingConditionIn = (memberPreExisitingConditionIn === undefined) ? new PHICoreModel.MemberPreExisitingConditionList() : memberPreExisitingConditionIn;
memberStudentDetailIn = (memberStudentDetailIn === undefined) ? new PHICoreModel.MemberStudentDetailRec() : memberStudentDetailIn;
accordionsIn = (accordionsIn === undefined) ? new PHICoreModel.BooleanBooleanBooleanBooleanBooleanBooleanRecord() : accordionsIn;
isValidateLHCABDIn = (isValidateLHCABDIn === undefined) ? true : isValidateLHCABDIn;
isValidateStudentDetailsIn = (isValidateStudentDetailsIn === undefined) ? true : isValidateStudentDetailsIn;
isValidatePreExistingConditionIn = (isValidatePreExistingConditionIn === undefined) ? true : isValidatePreExistingConditionIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validateMember_Client$Action.bind(controller, memberDetailsStructureIn, memberLHCABDIn, memberPreExisitingConditionIn, memberStudentDetailIn, accordionsIn, OS.DataConversion.JSNodeParamConverter.from(isValidateLHCABDIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(isValidateStudentDetailsIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(isValidatePreExistingConditionIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberDetailsStructure_Updated: actionResults.memberDetailsStructure_UpdatedOut,
MemberLHCABD_Updated: actionResults.memberLHCABD_UpdatedOut,
MemberPreExisitingCondition_Updated: actionResults.memberPreExisitingCondition_UpdatedOut,
MemberStudentDetail_Updated: actionResults.memberStudentDetail_UpdatedOut,
Accordions_Updated: actionResults.accordions_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$ValidateMemberPersonalDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$MemberDetailsStructureRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validateMemberPersonalDetails$Action = function (memberDetailsStructureIn, isValidateSexIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateMemberPersonalDetails$vars"))());
vars.value.memberDetailsStructureInLocal = memberDetailsStructureIn.clone();
vars.value.isValidateSexInLocal = isValidateSexIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateMemberPersonalDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Modb2Mrgt0OxR8qVyiJ_7g:/ClientActionFlows.Modb2Mrgt0OxR8qVyiJ_7g:mGRJvebnbvbFnOgj05_WcQ", "PHICore", "ValidateMemberPersonalDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AOoU0u20q0mJDIasnbSc8w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sQdfbqdFCkGra50c7M67cg", callContext.id);
// MemberDetailsStructure.Title.Error = ""
vars.value.memberDetailsStructureInLocal.titleAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sQdfbqdFCkGra50c7M67cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberDetailsStructure.FirstName.Error = ""
vars.value.memberDetailsStructureInLocal.firstNameAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sQdfbqdFCkGra50c7M67cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// MemberDetailsStructure.LastName.Error = ""
vars.value.memberDetailsStructureInLocal.lastNameAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sQdfbqdFCkGra50c7M67cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// MemberDetailsStructure.Sex.Error = ""
vars.value.memberDetailsStructureInLocal.sexAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sQdfbqdFCkGra50c7M67cg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// MemberDetailsStructure.DateofBirth.Error = ""
vars.value.memberDetailsStructureInLocal.dateofBirthAttr.errorAttr = "";
// Has no Title?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:klw4K4Q+ZkSo7Focqjza1Q", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.memberDetailsStructureInLocal.titleAttr.descriptionAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zxsFKK4ZKEKCoYZvAmM4sQ", callContext.id);
// MemberDetailsStructure.Title.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.titleAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zxsFKK4ZKEKCoYZvAmM4sQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// Has no First Name?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+YEb2+qOak6AiRDSg+DWvg", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.memberDetailsStructureInLocal.firstNameAttr.valueAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q3B8Oa1obkmw3+3zKgmlYA", callContext.id);
// MemberDetailsStructure.FirstName.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.firstNameAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q3B8Oa1obkmw3+3zKgmlYA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// Has no last Name?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:z2WpckxdmUKjoAv8o9XeuQ", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.memberDetailsStructureInLocal.lastNameAttr.valueAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1dPhbKK9EESgrs6QwB29zg", callContext.id);
// MemberDetailsStructure.LastName.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.lastNameAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1dPhbKK9EESgrs6QwB29zg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// Has no Sex?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3T7pEixjLEOwuhWERDWZRA", callContext.id) && ((OS.BuiltinFunctions.trim(vars.value.memberDetailsStructureInLocal.sexAttr.descriptionAttr) === "") && vars.value.isValidateSexInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YCqo2zlrYEGrtesp6qYxMA", callContext.id);
// MemberDetailsStructure.Sex.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.sexAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YCqo2zlrYEGrtesp6qYxMA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// Has no Date of Birth?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OlD0enJ7iEOgKClB1UQRvg", callContext.id) && vars.value.memberDetailsStructureInLocal.dateofBirthAttr.valueAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7DTbSXyPuU6eOOKIzhYNWA", callContext.id);
// MemberDetailsStructure.DateofBirth.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.dateofBirthAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7DTbSXyPuU6eOOKIzhYNWA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// DOB in the future
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eLHFV7H0eUWWrAs1q2rv9Q", callContext.id) && vars.value.memberDetailsStructureInLocal.dateofBirthAttr.valueAttr.gt(OS.BuiltinFunctions.currDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ujjhwOlUP0qaCd42_bWWbQ", callContext.id);
// MemberDetailsStructure.DateofBirth.Error = "Invalid Date"
vars.value.memberDetailsStructureInLocal.dateofBirthAttr.errorAttr = "Invalid Date";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ujjhwOlUP0qaCd42_bWWbQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

// Has no pronouns other ?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MXrH8WNKZUOFp3ketBkjfA", callContext.id) && ((vars.value.memberDetailsStructureInLocal.pronounsOtherAttr.valueAttr === "") && (vars.value.memberDetailsStructureInLocal.pronounsAttr.codeAttr === "Other")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KMiWy3ILIUa5KY+ogMD1hA", callContext.id);
// MemberDetailsStructure.PronounsOther.Error = GetRequiredFieldMsg()
vars.value.memberDetailsStructureInLocal.pronounsOtherAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KMiWy3ILIUa5KY+ogMD1hA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5VDpgZ5LqUK5lIQFyvrV2A", callContext.id);
// MemberDetailsStructure_Updated = MemberDetailsStructure
outVars.value.memberDetailsStructure_UpdatedOut = vars.value.memberDetailsStructureInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:o_WwvBcDXkKSLWV+rw3dqw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Modb2Mrgt0OxR8qVyiJ_7g", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateMemberPersonalDetails$vars", [{
name: "MemberDetailsStructure",
attrName: "memberDetailsStructureInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "IsValidateSex",
attrName: "isValidateSexInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateMemberPersonalDetails$outVars", [{
name: "MemberDetailsStructure_Updated",
attrName: "memberDetailsStructure_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberDetailsStructureRec();
},
complexType: PHICoreModel.MemberDetailsStructureRec
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validateMemberPersonalDetails$Action = function (memberDetailsStructureIn, isValidateSexIn) {
memberDetailsStructureIn = (memberDetailsStructureIn === undefined) ? new PHICoreModel.MemberDetailsStructureRec() : memberDetailsStructureIn;
isValidateSexIn = (isValidateSexIn === undefined) ? true : isValidateSexIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validateMemberPersonalDetails$Action.bind(controller, memberDetailsStructureIn, OS.DataConversion.JSNodeParamConverter.from(isValidateSexIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberDetailsStructure_Updated: actionResults.memberDetailsStructure_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$ValidatePreExistingCondition", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$MemberPreExisitingConditionList"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validatePreExistingCondition$Action = function (memberPreExisitingConditionIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidatePreExistingCondition$vars"))());
vars.value.memberPreExisitingConditionInLocal = memberPreExisitingConditionIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidatePreExistingCondition$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:0blPAX+fYkWyP5zTvU_aUQ:/ClientActionFlows.0blPAX+fYkWyP5zTvU_aUQ:Jy7_XkjcSaQKRR5Ps94eFg", "PHICore", "ValidatePreExistingCondition", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6xfneLi0mEWXZw8uMNBgFg", callContext.id);
// Foreach MemberPreExisitingCondition
callContext.iterationContext.registerIterationStart(vars.value.memberPreExisitingConditionInLocal);
try {var memberPreExisitingConditionIterator = callContext.iterationContext.getIterator(vars.value.memberPreExisitingConditionInLocal);
var memberPreExisitingConditionIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1se_qi_qqkC8RownbJB8xQ", callContext.id) && (memberPreExisitingConditionIndex < vars.value.memberPreExisitingConditionInLocal.length))) {
memberPreExisitingConditionIterator.currentRowNumber = memberPreExisitingConditionIndex;
// Check Pre-Existing Condition
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GPfjNqBBmka_d_SNjMMLYg", callContext.id) && (vars.value.memberPreExisitingConditionInLocal.getItem(memberPreExisitingConditionIndex.valueOf()).preExisitingConidtionAttr.descriptionAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Of4S5RG5zUi2DrDr2ehpQA", callContext.id);
// MemberPreExisitingCondition.Current.PreExisitingConidtion.Error = GetRequiredFieldMsg()
vars.value.memberPreExisitingConditionInLocal.getItem(memberPreExisitingConditionIndex.valueOf()).preExisitingConidtionAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Of4S5RG5zUi2DrDr2ehpQA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

memberPreExisitingConditionIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.memberPreExisitingConditionInLocal);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vwYPrL7zO0mZk3zlkuM4mQ", callContext.id);
// MemberPreExisitingCondition_Updated = MemberPreExisitingCondition
outVars.value.memberPreExisitingCondition_UpdatedOut = vars.value.memberPreExisitingConditionInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xaK+7Xvm0kGTX_2wMVpKOA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:0blPAX+fYkWyP5zTvU_aUQ", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidatePreExistingCondition$vars", [{
name: "MemberPreExisitingCondition",
attrName: "memberPreExisitingConditionInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidatePreExistingCondition$outVars", [{
name: "MemberPreExisitingCondition_Updated",
attrName: "memberPreExisitingCondition_UpdatedOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.MemberPreExisitingConditionList();
},
complexType: PHICoreModel.MemberPreExisitingConditionList
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validatePreExistingCondition$Action = function (memberPreExisitingConditionIn) {
memberPreExisitingConditionIn = (memberPreExisitingConditionIn === undefined) ? new PHICoreModel.MemberPreExisitingConditionList() : memberPreExisitingConditionIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validatePreExistingCondition$Action.bind(controller, memberPreExisitingConditionIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberPreExisitingCondition_Updated: actionResults.memberPreExisitingCondition_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$ValidateStudentDetails", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.clientVariables", "PHICore.controller$DateFormatvalidation_MM_YYYY", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$MemberStudentDetailRec"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreClientVariables) {
var OS = OutSystems.Internal;
PHICoreController.default.validateStudentDetails$Action = function (memberStudentDetailIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateStudentDetails$vars"))());
vars.value.memberStudentDetailInLocal = memberStudentDetailIn.clone();
var dateFormatvalidation_MM_YYYYVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.ValidateStudentDetails$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.dateFormatvalidation_MM_YYYYVar = dateFormatvalidation_MM_YYYYVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:UwurM9Z3Y0KazxLugIB_mw:/ClientActionFlows.UwurM9Z3Y0KazxLugIB_mw:HIKGdZC_B48el4vEcYDh8Q", "PHICore", "ValidateStudentDetails", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0HQz5ZREnUarvlYKD9AhkA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yJteCL2ZbUuWtuFJi+Y6Ow", callContext.id);
// MemberStudentDetail.OtherInstitution.Error = ""
vars.value.memberStudentDetailInLocal.otherInstitutionAttr.errorAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yJteCL2ZbUuWtuFJi+Y6Ow", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MemberStudentDetail.StartMonth_Year.Error = ""
vars.value.memberStudentDetailInLocal.startMonth_YearAttr.errorAttr = "";
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Cdlid0IfBUy+3OHlRm+ZMg", callContext.id) && (OS.BuiltinFunctions.toLower(vars.value.memberStudentDetailInLocal.educationInstitutionAttr.descriptionAttr) === "na other"))) {
// Check Other
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XcwU88D8ZkO3deHcs070ew", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.memberStudentDetailInLocal.otherInstitutionAttr.valueAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gsR1zcDn40ah2SnHWpB_zg", callContext.id);
// MemberStudentDetail.OtherInstitution.Error = GetRequiredFieldMsg()
vars.value.memberStudentDetailInLocal.otherInstitutionAttr.errorAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gsR1zcDn40ah2SnHWpB_zg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

}

// Check Start Month Year 
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j1XHLqT78keKB1r4Omjn_A", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.memberStudentDetailInLocal.startMonth_YearAttr.valueAttr) === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WjLSdVs0Eku3WRsXupWe3g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4zH7CN6k5UqdC84DcKLDVg", callContext.id);
// Execute Action: DateFormatvalidation_MM_YYYY
dateFormatvalidation_MM_YYYYVar.value = PHICoreController.default.dateFormatvalidation_MM_YYYY$Action(vars.value.memberStudentDetailInLocal.startMonth_YearAttr.valueAttr, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GvY4izvyy0COjTuQKXA0iA", callContext.id) && !(dateFormatvalidation_MM_YYYYVar.value.isValidOut))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bRNX91rN2ke2bKY6XAzyCA", callContext.id);
// MemberStudentDetail.StartMonth_Year.Error = "Invalid date format"
vars.value.memberStudentDetailInLocal.startMonth_YearAttr.errorAttr = "Invalid date format";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bRNX91rN2ke2bKY6XAzyCA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsValid = False
outVars.value.isValidOut = false;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ugs9f4UaX0qBJUOnjmjPRw", callContext.id);
// MemberStudentDetail_Updated = MemberStudentDetail
outVars.value.memberStudentDetail_UpdatedOut = vars.value.memberStudentDetailInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WjLSdVs0Eku3WRsXupWe3g", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:UwurM9Z3Y0KazxLugIB_mw", callContext.id);
}

};
var controller = PHICoreController.default;
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateStudentDetails$vars", [{
name: "MemberStudentDetail",
attrName: "memberStudentDetailInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberStudentDetailRec();
},
complexType: PHICoreModel.MemberStudentDetailRec
}]);
PHICoreController.default.constructor.registerVariableGroupType("PHICore.ValidateStudentDetails$outVars", [{
name: "MemberStudentDetail_Updated",
attrName: "memberStudentDetail_UpdatedOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.MemberStudentDetailRec();
},
complexType: PHICoreModel.MemberStudentDetailRec
}, {
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
PHICoreController.default.clientActionProxies.validateStudentDetails$Action = function (memberStudentDetailIn) {
memberStudentDetailIn = (memberStudentDetailIn === undefined) ? new PHICoreModel.MemberStudentDetailRec() : memberStudentDetailIn;
return controller.executeActionInsideJSNode(PHICoreController.default.validateStudentDetails$Action.bind(controller, memberStudentDetailIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
MemberStudentDetail_Updated: actionResults.memberStudentDetail_UpdatedOut,
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("PHICore.controller$ServerAction.CreateOrUpdate_PolicyWaitingPeriodsCase", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CS.model", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CS"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CSModel) {
var OS = OutSystems.Internal;
PHICoreController.default.createOrUpdate_PolicyWaitingPeriodsCase$ServerAction = function (policyIdIn, stakeholderIdIn, triggerCodeIn, isNewIn, callContext) {
var controller = this.controller;
var inputs = {
PolicyId: OS.DataConversion.ServerDataConverter.to(policyIdIn, OS.Types.LongInteger),
StakeholderId: OS.DataConversion.ServerDataConverter.to(stakeholderIdIn, OS.Types.Text),
TriggerCode: OS.DataConversion.ServerDataConverter.to(triggerCodeIn, OS.Types.Text),
IsNew: OS.DataConversion.ServerDataConverter.to(isNewIn, OS.Types.Boolean)
};
return controller.callServerAction("CreateOrUpdate_PolicyWaitingPeriodsCase", "screenservices/PHICore/ActionCreateOrUpdate_PolicyWaitingPeriodsCase", "pECWwlMbLnv7U8hFxHBLSg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$rssespacestatemachinecaseservice_ActionCreateOrUpdate_PolicyWaitingPeriodsCase"))();
executeServerActionResult.entityActionResultsOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResults, Common_CSModel.EntityActionResultRec);
executeServerActionResult.caseIdOut = OS.DataConversion.ServerDataConverter.from(outputs.CaseId, OS.Types.Text);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$rssespacestatemachinecaseservice_ActionCreateOrUpdate_PolicyWaitingPeriodsCase", [{
name: "EntityActionResults",
attrName: "entityActionResultsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}, {
name: "CaseId",
attrName: "caseIdOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("PHICore.controller$ServerAction.CreatePolicyReactivationSuspendCase", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CS.model", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CS"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CSModel) {
var OS = OutSystems.Internal;
PHICoreController.default.createPolicyReactivationSuspendCase$ServerAction = function (policyIdIn, caseStatusPurposeIDIn, triggerCodeIn, stakeholderIdsIn, primaryMemberIdIn, unassignIn, callContext) {
var controller = this.controller;
var inputs = {
PolicyId: OS.DataConversion.ServerDataConverter.to(policyIdIn, OS.Types.LongInteger),
CaseStatusPurposeID: OS.DataConversion.ServerDataConverter.to(caseStatusPurposeIDIn, OS.Types.Integer),
TriggerCode: OS.DataConversion.ServerDataConverter.to(triggerCodeIn, OS.Types.Text),
StakeholderIds: OS.DataConversion.ServerDataConverter.to(stakeholderIdsIn, OS.Types.RecordList),
PrimaryMemberId: OS.DataConversion.ServerDataConverter.to(primaryMemberIdIn, OS.Types.Text),
Unassign: OS.DataConversion.ServerDataConverter.to(unassignIn, OS.Types.Boolean)
};
return controller.callServerAction("CreatePolicyReactivationSuspendCase", "screenservices/PHICore/ActionCreatePolicyReactivationSuspendCase", "OhPznwoOAob4A2pG5JYu8Q", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$rssespacestatemachinecaseservice_ActionCreatePolicyReactivationSuspendCase"))();
executeServerActionResult.entityActionResultsOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResults, Common_CSModel.EntityActionResultRec);
executeServerActionResult.casesIdOut = OS.DataConversion.ServerDataConverter.from(outputs.CasesId, OS.Types.Text);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$rssespacestatemachinecaseservice_ActionCreatePolicyReactivationSuspendCase", [{
name: "EntityActionResults",
attrName: "entityActionResultsOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}, {
name: "CasesId",
attrName: "casesIdOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("PHICore.controller$ServerAction.GetEntityFlags", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "APIGateway_IS.model", "Common_CS.model", "APIGateway_IS.model$GetEntityFlags_APIResponseRec", "PHICore.referencesHealth", "PHICore.referencesHealth$APIGateway_IS", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS"], function (exports, OutSystems, PHICoreModel, PHICoreController, APIGateway_ISModel, Common_CSModel) {
var OS = OutSystems.Internal;
PHICoreController.default.getEntityFlags$ServerAction = function (entityId_InputIn, entityType_InputIn, callContext) {
var controller = this.controller;
var inputs = {
EntityId_Input: OS.DataConversion.ServerDataConverter.to(entityId_InputIn, OS.Types.Text),
EntityType_Input: OS.DataConversion.ServerDataConverter.to(entityType_InputIn, OS.Types.Text)
};
return controller.callServerAction("GetEntityFlags", "screenservices/PHICore/ServiceAPIGetEntityFlags", "iIf_LfljcmKLy2BCijLiqw", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$ServiceAPIGetEntityFlags"))();
executeServerActionResult.responseOut = OS.DataConversion.ServerDataConverter.from(outputs.Response, APIGateway_ISModel.GetEntityFlags_APIResponseRec);
executeServerActionResult.entityActionResultOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResult, Common_CSModel.EntityActionResultRec);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$ServiceAPIGetEntityFlags", [{
name: "Response",
attrName: "responseOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new APIGateway_ISModel.GetEntityFlags_APIResponseRec();
},
complexType: APIGateway_ISModel.GetEntityFlags_APIResponseRec
}, {
name: "EntityActionResult",
attrName: "entityActionResultOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}]);
});
define("PHICore.controller$ServerAction.GetStakeholder_Type", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller"], function (exports, OutSystems, PHICoreModel, PHICoreController) {
var OS = OutSystems.Internal;
PHICoreController.default.getStakeholder_Type$ServerAction = function (stakeholderType_NameIn, callContext) {
var controller = this.controller;
var inputs = {
StakeholderType_Name: OS.DataConversion.ServerDataConverter.to(stakeholderType_NameIn, OS.Types.Text)
};
return controller.callServerAction("GetStakeholder_Type", "screenservices/PHICore/ActionGetStakeholder_Type", "j4UpI2+RelhQda64CfIEeA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$ActionGetStakeholder_Type"))();
executeServerActionResult.stakeholderTypeIdOut = OS.DataConversion.ServerDataConverter.from(outputs.StakeholderTypeId, OS.Types.Integer);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$ActionGetStakeholder_Type", [{
name: "StakeholderTypeId",
attrName: "stakeholderTypeIdOut",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
});
define("PHICore.controller$ServerAction.IsAllowSuccess", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller"], function (exports, OutSystems, PHICoreModel, PHICoreController) {
var OS = OutSystems.Internal;
PHICoreController.default.isAllowSuccess$ServerAction = function (callContext) {
var controller = this.controller;
return controller.callServerAction("IsAllowSuccess", "screenservices/PHICore/ActionIsAllowSuccess", "SDaPZbLhoJbf7Ac3_ndoDQ", {}, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$ActionIsAllowSuccess"))();
executeServerActionResult.isAllowOut = OS.DataConversion.ServerDataConverter.from(outputs.IsAllow, OS.Types.Boolean);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$ActionIsAllowSuccess", [{
name: "IsAllow",
attrName: "isAllowOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
});
define("PHICore.controller$ServerAction.Policy_Patch", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller"], function (exports, OutSystems, PHICoreModel, PHICoreController) {
var OS = OutSystems.Internal;
PHICoreController.default.policy_Patch$ServerAction = function (policyNumberIn, patch_CurrentIn, patch_NewIn, originalMembersIn, modifiedMembersIn, callContext) {
var controller = this.controller;
var inputs = {
PolicyNumber: OS.DataConversion.ServerDataConverter.to(policyNumberIn, OS.Types.Integer),
Patch_Current: OS.DataConversion.ServerDataConverter.to(patch_CurrentIn, OS.Types.Record),
Patch_New: OS.DataConversion.ServerDataConverter.to(patch_NewIn, OS.Types.Record),
OriginalMembers: OS.DataConversion.ServerDataConverter.to(originalMembersIn, OS.Types.RecordList),
ModifiedMembers: OS.DataConversion.ServerDataConverter.to(modifiedMembersIn, OS.Types.RecordList)
};
return controller.callServerAction("Policy_Patch", "screenservices/PHICore/ActionPolicy_Patch", "K2+alUpOj5R_PZyMGPiZTQ", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
});
};
});
define("PHICore.controller$ServerAction.UpdateEntityProperties_CS", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CS.model", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CS"], function (exports, OutSystems, PHICoreModel, PHICoreController, Common_CSModel) {
var OS = OutSystems.Internal;
PHICoreController.default.updateEntityProperties_CS$ServerAction = function (requestIn, callContext) {
var controller = this.controller;
var inputs = {
Request: OS.DataConversion.ServerDataConverter.to(requestIn, OS.Types.Record)
};
return controller.callServerAction("UpdateEntityProperties_CS", "screenservices/PHICore/ServiceAPIUpdateEntityProperties_CS", "Nl4OdEfjeDNP9Fd7o+RJQg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$ServiceAPIUpdateEntityProperties_CS"))();
executeServerActionResult.entityActionResultOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResult, Common_CSModel.EntityActionResultRec);
executeServerActionResult.errorCodeOut = OS.DataConversion.ServerDataConverter.from(outputs.ErrorCode, OS.Types.Integer);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$ServiceAPIUpdateEntityProperties_CS", [{
name: "EntityActionResult",
attrName: "entityActionResultOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}, {
name: "ErrorCode",
attrName: "errorCodeOut",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
});
define("PHICore.controller$ServerAction.User_GetUnifiedLoginUrl", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller"], function (exports, OutSystems, PHICoreModel, PHICoreController) {
var OS = OutSystems.Internal;
PHICoreController.default.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/PHICore/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
PHICoreController.default.constructor.registerVariableGroupType("PHICore$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("PHICore.controller", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller$debugger"], function (exports, OutSystems, PHICoreModel, PHICore_Controller_debugger) {
var OS = OutSystems.Internal;
var PHICoreController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {
SP_3_ViewCases: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*qN9KBWljFEClFBO1VDlRRw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_3_ViewCases", "SP_3_ViewCases role required")
},
SM_1_AddModifyReopenCancelLead: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*mmhCHAVHE0+ovsYgY_p9kw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_1_AddModifyReopenCancelLead", "SM_1_AddModifyReopenCancelLead role required")
},
PM_3_CreatePolicyAndMember: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*xT5TIAW_wUuUGIkVHTHK8A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_3_CreatePolicyAndMember", "PM_3_CreatePolicyAndMember role required")
},
SP_1_StaffPortal: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*3GF3IdARp0KbkcXJV+CMvA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_1_StaffPortal", "SP_1_StaffPortal role required")
},
SP_2_SearchRecord: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*ut7JKnAc5U2NB+b50Tu3Fg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_2_SearchRecord", "SP_2_SearchRecord role required")
},
PM_23_ViewPolicyAndMember: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*dzbFMugvtEmEiwQhu+dZ0A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_23_ViewPolicyAndMember", "PM_23_ViewPolicyAndMember role required")
},
HAMBSAdmin: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pTbfUvhMMEq0Im8nv1GeQg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotHAMBSAdmin", "HAMBSAdmin role required")
},
PM_8_TerminatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*zPV7aVmd2E2gp3iHK+3Drw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_8_TerminatePolicy", "PM_8_TerminatePolicy role required")
},
SM_4_ViewStakeholderLead: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*QTtsahid6EObPodwpHEwtA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_4_ViewStakeholderLead", "SM_4_ViewStakeholderLead role required")
},
PM_5_MaintainPolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*qCo0gYwe+Uu0jgrGNoPTRw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_5_MaintainPolicy", "PM_5_MaintainPolicy role required")
},
PM_3_ViewQuote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*q06ei11yXkujJHKgirKcEw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_3_ViewQuote", "PM_3_ViewQuote role required")
},
SystemAdministrator: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*eGpqnKatjECYBG4l+F4pYA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSystemAdministrator", "SystemAdministrator role required")
},
SP_6_PlaceonholdCase: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*q9WvngKAHk6NerVD7ThHhQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_6_PlaceonholdCase", "SP_6_PlaceonholdCase role required")
},
OA_5_ManageFundSetupAndBranding: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*SgSQq7k8qkC9DtiSVCHwYQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_5_ManageFundSetupAndBranding", "OA_5_ManageFundSetupAndBranding role required")
},
SP_12_ViewRestrictedCases: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*mrMosvKTGEybYT_5CkZo0g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_12_ViewRestrictedCases", "SP_12_ViewRestrictedCases role required")
},
SP_7_CancelCase: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*NR2U1trNx0yscniClhht5A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_7_CancelCase", "SP_7_CancelCase role required")
},
PM_10_ReactivatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*Ww_N83Gz+UyyqRk0tI36Yg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_10_ReactivatePolicy", "PM_10_ReactivatePolicy role required")
},
PM_1_CreateModifyQuote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*4z0_9Eh_QE+_MEzwNwbD9Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_1_CreateModifyQuote", "PM_1_CreateModifyQuote role required")
},
SP_4_ViewDashboards: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*z_ES9dS+0ka1KmVMM7YAOA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_4_ViewDashboards", "SP_4_ViewDashboards role required")
},
PM_9_SuspendPolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*_Zl9+s3HnEiBkHP9+tS6Ag",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_9_SuspendPolicy", "PM_9_SuspendPolicy role required")
}
};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
PHICoreController.default = new Controller(null, "PHICore");
});
define("PHICore.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main", "PHICore.clientVariables"], function (exports, Debugger, OutSystems, PHICoreClientVariables) {
var OS = OutSystems.Internal;
var metaInfo = {
"HVzBy14hdUiKNfS9GgW76g": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibilityReason_ListInLocal;
}
},
"BlgONBbevUiJQtfbhE90dg": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibilitySubReason_ListInLocal;
}
},
"2L3DLA7fQ0i2jOPHS4T9XQ": {
getter: function (varBag, idService) {
return varBag.vars.value.cover_ListInLocal;
}
},
"t9yQ2LX_N06Gyeitebv7vA": {
getter: function (varBag, idService) {
return varBag.vars.value.class_ListInLocal;
}
},
"fQGXNXILrEqLfFzo0x2J0g": {
getter: function (varBag, idService) {
return varBag.vars.value.state_ListInLocal;
}
},
"pWCuf80HzEK0xhBeuitoDw": {
getter: function (varBag, idService) {
return varBag.vars.value.residency_ListInLocal;
}
},
"rA3qV+6CIE6Mfuyy6KXT0Q": {
getter: function (varBag, idService) {
return varBag.vars.value.group_ListInLocal;
}
},
"wlvgpqZrmEai8iKWmqO4Hg": {
getter: function (varBag, idService) {
return varBag.vars.value.location_ListInLocal;
}
},
"4CDUIe8oN02vHTBP_gzQ+w": {
getter: function (varBag, idService) {
return varBag.vars.value.site_ListInLocal;
}
},
"xEXC0fihVESBp2QcTJ2oPw": {
getter: function (varBag, idService) {
return varBag.vars.value.getQuote_RatesQuote_RevisionsInLocal;
}
},
"y3Lb3S95RE2T7hQ4NR3qPA": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_GetQuote_RatesQuote_RevisionsOut;
}
},
"hgElCRa4GECJUOLuMG_fnA": {
getter: function (varBag, idService) {
return varBag.outVars.value.policy_BasicDetailsOut;
}
},
"ON16F600fUeOLnJ7dVeF7w": {
getter: function (varBag, idService) {
return varBag.residencyListVar.value;
}
},
"kBYVT_SNbUynHjUjRv5X7A": {
getter: function (varBag, idService) {
return varBag.classListVar.value;
}
},
"w1lsXluC6kS83dReE1T1Pw": {
getter: function (varBag, idService) {
return varBag.groupListVar.value;
}
},
"+KY0k6Eao0uWzvykAR2u+A": {
getter: function (varBag, idService) {
return varBag.stateListVar.value;
}
},
"OXcamYe3qkyNxgFsr2X+6A": {
getter: function (varBag, idService) {
return varBag.coverListVar.value;
}
},
"ZFYmmTO+sUaIJkKveouNBA": {
getter: function (varBag, idService) {
return varBag.locationVar.value;
}
},
"cLRcqucisEuvrOWnCiHo1g": {
getter: function (varBag, idService) {
return varBag.siteListVar.value;
}
},
"x9sWvUOUdUCWm0EB6HhHYA": {
getter: function (varBag, idService) {
return varBag.eligibilitySubReasonListVar.value;
}
},
"9OsD0I1qv0qOaVb_qaAe2A": {
getter: function (varBag, idService) {
return varBag.eligibilityReasonVar.value;
}
},
"2NsQVC7JyUSSY+c5ECTAdQ": {
getter: function (varBag, idService) {
return varBag.vars.value.memberPreExisitingConditionInLocal;
}
},
"YUEkZuAzeU+aIlH4l1kaMg": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberPreExisitingCondition_UpdatedOut;
}
},
"_GLFbpZ4dkSsdi9Er66cfg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"yj3MJDhtTEekLSTxq5JE7Q": {
getter: function (varBag, idService) {
return varBag.vars.value.uDP_LocalInLocal;
}
},
"8mU3ULF5mkKpeBugOPicwQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.entityActionResultOut;
}
},
"FYRhXSkmW0GjikdZhq7ysw": {
getter: function (varBag, idService) {
return varBag.updateEntityProperties_CSVar.value;
}
},
"5NTqvVs5qUSM896M7eRCvg": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderType_NameInLocal;
},
dataType: OS.Types.Text
},
"E6exUqEBtU+JErR7jzzTYQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.stakeholderTypeIdOut;
},
dataType: OS.Types.Integer
},
"zl4MSosTyEyEIqmWG68kaw": {
getter: function (varBag, idService) {
return varBag.getStakeholder_TypeVar.value;
}
},
"3mhkSZTYu0SZ2aGAlD6cXw": {
getter: function (varBag, idService) {
return varBag.vars.value.addressList_HandlerInLocal;
}
},
"fEr_E6KLt0S8Q31CPc43vw": {
getter: function (varBag, idService) {
return varBag.vars.value.emailList_HandlerInLocal;
}
},
"NDQM+vMZoka8MrY6zD_yKw": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneList_HandlerInLocal;
}
},
"s_x4SJnfMUe59VYEsf8qHA": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"_L0P644hik6csC5dKGi+nQ": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailSettingInLocal;
}
},
"bgRsg6UvV02ISVs6+9qeog": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderTypeIdInLocal;
},
dataType: OS.Types.Integer
},
"GXegTxSK8Ua3Xq8yXs+p9g": {
getter: function (varBag, idService) {
return varBag.vars.value.isContributorInLocal;
},
dataType: OS.Types.Boolean
},
"tQSTXupVrka9BwhmfuaK5A": {
getter: function (varBag, idService) {
return varBag.vars.value.isLeadInLocal;
},
dataType: OS.Types.Boolean
},
"rUVU6cxu0kSIa3gIf9vhPg": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressList_Handler_OutOut;
}
},
"6sOJG2ZlnE6HYG2TLSRySg": {
getter: function (varBag, idService) {
return varBag.outVars.value.emailList_Handler_OutOut;
}
},
"TRROx+CO9Ei14dYWrhkHaw": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneList_Handler_OutOut;
}
},
"15wCMUce2EORAGVx8ubiyQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"tXBTnIlYrkmC43hy_TlgOg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"eOK1sb7GHECBn7H+hBDjWQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"WhN036R_Q0Cwh9bJkHjbmQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactDetails_ValidationOut;
}
},
"Z2_mR5DqXkS6SEMvxAHy1g": {
getter: function (varBag, idService) {
return varBag.fullValidation_EmailListVar.value;
}
},
"TYEdY5ohXUGX5tRVlwqSFg": {
getter: function (varBag, idService) {
return varBag.fullValidation_PhoneListVar.value;
}
},
"xRlH3S9oFUyzguK+jrcz9A": {
getter: function (varBag, idService) {
return varBag.fullValidation_AddressListVar.value;
}
},
"e8GCjVlk+EOCFOLQlkLaLA": {
getter: function (varBag, idService) {
return varBag.vars.value.originalMembersVar;
}
},
"cRKsYFqlGEGL8xtHj+ZClw": {
getter: function (varBag, idService) {
return varBag.vars.value.modifiedMembersVar;
}
},
"9XUezOVc702HZMJ0aImgiA": {
getter: function (varBag, idService) {
return varBag.vars.value.policyNumberInLocal;
},
dataType: OS.Types.LongInteger
},
"e_M0Y0sYYk+XTOrboiRJKg": {
getter: function (varBag, idService) {
return varBag.vars.value.policyInLocal;
}
},
"0c5_RNsVOkOBxNOtQ+3VHQ": {
getter: function (varBag, idService) {
return varBag.vars.value.requestInLocal;
}
},
"WWzWupu7TUSCfyQbBqxFSw": {
getter: function (varBag, idService) {
return varBag.vars.value.modifiedPrimaryMemberInLocal;
}
},
"FBVMiISyyk+p1tQ29diCQQ": {
getter: function (varBag, idService) {
return varBag.vars.value.modifiedAdditionalMembersInLocal;
}
},
"_QAw6TkVPEufSFA1dj5Q+Q": {
getter: function (varBag, idService) {
return varBag.vars.value.isAscendingVar;
},
dataType: OS.Types.Boolean
},
"wDNlB+WQ9UuXiDrnrB4exw": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderListSortInLocal;
},
dataType: OS.Types.Text
},
"+3+4CLpVCEK2uQ+4+8JhoQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyMembersInLocal;
}
},
"A4EprS8OmEm2e5KvIQkJgw": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_PolicyMembersOut;
}
},
"HWUmJEwdv0iP7v11eUOd2A": {
getter: function (varBag, idService) {
return varBag.vars.value.memberLHCABDInLocal;
}
},
"1qFQEnsZL0eMOcQlGHq61A": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberLHCABD_UpdatedOut;
}
},
"5u+QqhSk6kmESFhzcl0tsg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"W7U+15oly0K0nj9cZfl4Fg": {
getter: function (varBag, idService) {
return varBag.validateLHCABDDetailsVar.value;
}
},
"xhmpN5ZivUmcHyWvHUjacA": {
getter: function (varBag, idService) {
return varBag.vars.value.entityTypeIdInLocal;
},
dataType: OS.Types.Integer
},
"09MMNOVjpUqKa7BpQHCY0g": {
getter: function (varBag, idService) {
return varBag.outVars.value.permissionsOut;
}
},
"8AJgogDxvk6rDyDpqyyGpg": {
getter: function (varBag, idService) {
return varBag.vars.value.memberDetailsStructureInLocal;
}
},
"S8Svc3lfa0un1E47+XAiYg": {
getter: function (varBag, idService) {
return varBag.vars.value.memberLHCABDInLocal;
}
},
"HiXI+QJRkkqRJsJZa6JoZA": {
getter: function (varBag, idService) {
return varBag.vars.value.memberPreExisitingConditionInLocal;
}
},
"X6fHozfX0UKR0otRvdg81g": {
getter: function (varBag, idService) {
return varBag.vars.value.addressList_HandlerInLocal;
}
},
"wQKx5Nqf8keGDOh2uOz1Vw": {
getter: function (varBag, idService) {
return varBag.vars.value.emailList_HandlerInLocal;
}
},
"MyskUbEpdkGmBEL_Tfympw": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneList_HandlerInLocal;
}
},
"UAC2wGFQUU2o7jnKT45IGQ": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"MI+EoHp1pkiUuwsJk8VqdA": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailSettingInLocal;
}
},
"345Jdfy+zkGtBBd3KmXT4g": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibility_StructInLocal;
}
},
"u2w+p5N+JE+T5TOTXDsW6g": {
getter: function (varBag, idService) {
return varBag.vars.value.policyDetails_TempInLocal;
}
},
"krCH7mCwnE+yBhz7xM63MQ": {
getter: function (varBag, idService) {
return varBag.vars.value.hasConfiguredEligibilityInLocal;
},
dataType: OS.Types.Boolean
},
"+u2YAMhUZ069wioRX8KXaA": {
getter: function (varBag, idService) {
return varBag.vars.value.additionalDetailsInLocal;
}
},
"vjioW2Rq10m2H7c+5Y9nzQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberDetailsStructure_UpdatedOut;
}
},
"pMzinQ_ZH0ChA2AwbRW+9w": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberLHCABD_UpdatedOut;
}
},
"WM8vUiYUmki6UcSVwNMHvQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberPreExisitingCondition_UpdatedOut;
}
},
"uqwapPuswEunkiqQeZmeMQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressList_Handler_OutOut;
}
},
"5Wq5SToKI02jLWJfr76lCQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.emailList_Handler_OutOut;
}
},
"JLtsBIF7iU6yUsDGbz1X2w": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneList_Handler_OutOut;
}
},
"KwSpPU8+PUW36myoRQ8stQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"6Amo0r51IU65_wErECJBsQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.eligibility_Handler_OutOut;
}
},
"Vwe612CaVEaJJvm4hOYkUw": {
getter: function (varBag, idService) {
return varBag.outVars.value.policyDetails_OutOut;
}
},
"1g4UO67RL0+Q8CN1ttwtIw": {
getter: function (varBag, idService) {
return varBag.outVars.value.additionalDetails_OutOut;
}
},
"1jUxiWF3qEmuUSG9UitqbA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"afdeRU069kCu_LfDiZ0e8A": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"_cQ+35cBs0agBJgXqhrMYg": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactDetails_ValidationOut;
}
},
"oGAJFhKyv0mGas9XilFZzA": {
getter: function (varBag, idService) {
return varBag.validateMemberPersonalDetailsVar.value;
}
},
"MW2BHDL1sk2fWrrRhbk93w": {
getter: function (varBag, idService) {
return varBag.validate_LHCABD_ListVar.value;
}
},
"cip_STwAYkOe6Kfd_PLgig": {
getter: function (varBag, idService) {
return varBag.validate_QuotePolicyDetailsVar.value;
}
},
"mGPvUhJ_+EayKPdwhrhxZg": {
getter: function (varBag, idService) {
return varBag.check_EligibilityVar.value;
}
},
"M2tUaqJ2qE+FPl5AXcN4kw": {
getter: function (varBag, idService) {
return varBag.validatePreExistingConditionVar.value;
}
},
"akw37jalVkSrHmCl+DziZg": {
getter: function (varBag, idService) {
return varBag.check_Additional_DetailsVar.value;
}
},
"Aynv_2j1eEq1AFrbZ4CWiQ": {
getter: function (varBag, idService) {
return varBag.check_Contact_DetailsVar.value;
}
},
"cQW24re6w0qFI+dY3Al5uQ": {
getter: function (varBag, idService) {
return varBag.vars.value.isPrimaryMemberInLocal;
},
dataType: OS.Types.Boolean
},
"iUXsLUeph0iEvsSYF0fkDA": {
getter: function (varBag, idService) {
return varBag.vars.value.memberPersonalDetailsInLocal;
}
},
"MuYNQQjUhUiI96FwfsnNyQ": {
getter: function (varBag, idService) {
return varBag.vars.value.roleListInLocal;
}
},
"BaQkzKUhO0mEDEXjKxjsXA": {
getter: function (varBag, idService) {
return varBag.vars.value.relationshipListInLocal;
}
},
"7K8HoZq4PUaMU6uZwdRFHA": {
getter: function (varBag, idService) {
return varBag.vars.value.titleListInLocal;
}
},
"54V_7GD9LkinXdAvy6K0CQ": {
getter: function (varBag, idService) {
return varBag.vars.value.rankListInLocal;
}
},
"WZ+hrkULFkuMrtqFM4SsxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.sexListInLocal;
}
},
"S_KiTTxSLkWNCCGzilFLVQ": {
getter: function (varBag, idService) {
return varBag.vars.value.pronounsListInLocal;
}
},
"rxAtldmc_0y5xfq9BhW_XQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.personalDetailsOut;
}
},
"4yLmR49viE68zgkKvZdGpA": {
getter: function (varBag, idService) {
return varBag.rank_ListVar.value;
}
},
"f81ATyKpFE2WOXFiVFAsDQ": {
getter: function (varBag, idService) {
return varBag.memberRole_ListVar.value;
}
},
"cmndiEWa1EWXUWC6Kr4kTA": {
getter: function (varBag, idService) {
return varBag.role_ListVar.value;
}
},
"li23j460WEuwEnW9ynl_mw": {
getter: function (varBag, idService) {
return varBag.relationship_ListVar.value;
}
},
"cXt9odgq90GhDMPg3yEbfg": {
getter: function (varBag, idService) {
return varBag.pronounsVar.value;
}
},
"F6_R1lXrYU2HhtfqMaif2g": {
getter: function (varBag, idService) {
return varBag.title_ListVar.value;
}
},
"oWp4_qJ5702vdGGNfxufiQ": {
getter: function (varBag, idService) {
return varBag.sex_ListVar.value;
}
},
"nXDj1ldpnEGZ7pna_cp0RA": {
getter: function (varBag, idService) {
return varBag.vars.value.line1InLocal;
},
dataType: OS.Types.Text
},
"GMAWBHaZNU+y8_L47R97nQ": {
getter: function (varBag, idService) {
return varBag.vars.value.line2InLocal;
},
dataType: OS.Types.Text
},
"GXc+hS0beUWf520sny1tlg": {
getter: function (varBag, idService) {
return varBag.vars.value.suburbInLocal;
},
dataType: OS.Types.Text
},
"hF_GKEkW_UmuQLmg87Cr3w": {
getter: function (varBag, idService) {
return varBag.vars.value.stateTerritoryCodeInLocal;
},
dataType: OS.Types.Text
},
"z_LmRNu+ZkeX7KExbaITrA": {
getter: function (varBag, idService) {
return varBag.vars.value.postcodeInLocal;
},
dataType: OS.Types.Text
},
"xctNaKEg6kmjm_a6hlt4iA": {
getter: function (varBag, idService) {
return varBag.vars.value.countryInLocal;
},
dataType: OS.Types.Text
},
"PYeTGXmH1k+yG2NXnw9Plg": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressOut;
},
dataType: OS.Types.Text
},
"FYodGECwn0+5bNBqgZiVHQ": {
getter: function (varBag, idService) {
return varBag.vars.value.titleInLocal;
},
dataType: OS.Types.Text
},
"1Z8zcq7eI06Zl4QdVQiCUA": {
getter: function (varBag, idService) {
return varBag.vars.value.firstNameInLocal;
},
dataType: OS.Types.Text
},
"auif32+dI02XKvqZKV8Yag": {
getter: function (varBag, idService) {
return varBag.vars.value.middleNameInLocal;
},
dataType: OS.Types.Text
},
"6jqsT+zy10CXFBjOPm8YOg": {
getter: function (varBag, idService) {
return varBag.vars.value.lastNameInLocal;
},
dataType: OS.Types.Text
},
"MFuYT9P1J0y9aBSKKJFO6Q": {
getter: function (varBag, idService) {
return varBag.vars.value.preferredNameInLocal;
},
dataType: OS.Types.Text
},
"B9B0FNfd1EinRiPgnhmZLw": {
getter: function (varBag, idService) {
return varBag.outVars.value.nameOut;
},
dataType: OS.Types.Text
},
"8n_WMIUUxUWEO8RZvr1EwA": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneVar;
}
},
"xm0GlGYvEUKyAL24+4PNkA": {
getter: function (varBag, idService) {
return varBag.vars.value.addressVar;
}
},
"DvHIAniFV0WcEWyKwuvXVA": {
getter: function (varBag, idService) {
return varBag.vars.value.referencesInLocal;
}
},
"LU13IiUkiEy34XX_14wf5w": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailsInLocal;
}
},
"6DKHAdG4u0Ovu4jI+BxawA": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholder_InformationInLocal;
}
},
"Z+4v0r0F8UijaFdJnrzhEQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneListOut;
}
},
"evuT6wH_j0uqTuFmKBVVFA": {
getter: function (varBag, idService) {
return varBag.outVars.value.emailListOut;
}
},
"4tK3zXz1OUqKfwMoyoHHKg": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressListOut;
}
},
"Qazhcr1JW02CVMKJseKYdA": {
getter: function (varBag, idService) {
return varBag.outVars.value.personalInformationOut;
}
},
"+DA7EXdSmEWC02TcyzEL1Q": {
getter: function (varBag, idService) {
return varBag.listFilter_RankVar.value;
}
},
"qc6pG6+F6Emmt5eXtP2gxA": {
getter: function (varBag, idService) {
return varBag.listFilter_CountryCodeVar.value;
}
},
"ZH_3KPDyCEGCJTQPSCiO1A": {
getter: function (varBag, idService) {
return varBag.listFilter_SexVar.value;
}
},
"Sc8cPw4i2UeI9Ru1o21cVw": {
getter: function (varBag, idService) {
return varBag.listFilter_PhoneTypeVar.value;
}
},
"h66WRU517UOHbsX0pBHrJw": {
getter: function (varBag, idService) {
return varBag.listFilter_StateVar.value;
}
},
"AbsOZLZd6U6264Vwm5jLTA": {
getter: function (varBag, idService) {
return varBag.listFilter_PronounsVar.value;
}
},
"fKAccRYHJUya6gRGJf2BZA": {
getter: function (varBag, idService) {
return varBag.listFilter_CountryVar.value;
}
},
"2bpagTFcTU6+5lvDpRBR2A": {
getter: function (varBag, idService) {
return varBag.listFilter_AddressTypeVar.value;
}
},
"T+vfiwS_BUiHRRDgl+oM5g": {
getter: function (varBag, idService) {
return varBag.listFilter_TitleVar.value;
}
},
"wPgQK3DVB0WJ0wh_gKaBgA": {
getter: function (varBag, idService) {
return varBag.vars.value.isNewInLocal;
},
dataType: OS.Types.Boolean
},
"r3b4hgpjzEyo_SHuziF3mw": {
getter: function (varBag, idService) {
return varBag.vars.value.policyIdInLocal;
},
dataType: OS.Types.LongInteger
},
"rcZ1gvxUPEe6bAtNxEaJ8Q": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderIdInLocal;
},
dataType: OS.Types.Text
},
"vi6nITFhzkOBmI692R_HSw": {
getter: function (varBag, idService) {
return varBag.outVars.value.caseIdOut;
},
dataType: OS.Types.Text
},
"RHmupiXFKUKIyNravvC8Jg": {
getter: function (varBag, idService) {
return varBag.createOrUpdate_PolicyWaitingPeriodsCaseVar.value;
}
},
"J1eMEUaZ+EuJVrm5ULSsgA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isAllowOut;
},
dataType: OS.Types.Boolean
},
"WhE6e8XQS0yWa8X5+Kughg": {
getter: function (varBag, idService) {
return varBag.isAllowSuccessVar.value;
}
},
"tn3CymFqbkuafJSM5ll67w": {
getter: function (varBag, idService) {
return varBag.vars.value.memberStudentDetailInLocal;
}
},
"+0nbo6HWAEiRHYpl8W8Y6Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberStudentDetail_UpdatedOut;
}
},
"NSXO8dLc6E2qh84uosvcHA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"4zH7CN6k5UqdC84DcKLDVg": {
getter: function (varBag, idService) {
return varBag.dateFormatvalidation_MM_YYYYVar.value;
}
},
"DIhX7Qt+kE+JQl+2uNXfrw": {
getter: function (varBag, idService) {
return varBag.vars.value.breakdownItemVar;
}
},
"9XHG5AJX1kKuhQfuSi_rVA": {
getter: function (varBag, idService) {
return varBag.vars.value.grossVar;
}
},
"IuTF9jdun0GgQHeXwqbUHw": {
getter: function (varBag, idService) {
return varBag.vars.value.discountVar;
}
},
"hCPmN6B8kEK_9Yt2MFkNzw": {
getter: function (varBag, idService) {
return varBag.vars.value.aBDVar;
}
},
"btzMyCQCM0umbJMbncwjBg": {
getter: function (varBag, idService) {
return varBag.vars.value.lHCLoadingVar;
}
},
"KPE_IGUv0UyJpayrXWmyww": {
getter: function (varBag, idService) {
return varBag.vars.value.rebatableVar;
}
},
"9urgFzZUEE+ezYFpbgM_uw": {
getter: function (varBag, idService) {
return varBag.vars.value.rebateVar;
}
},
"D5iMr2G2G0GboOpeep4AZg": {
getter: function (varBag, idService) {
return varBag.vars.value.subsidyVar;
}
},
"MLHB5N1yAEqdkrvI5ZqtPQ": {
getter: function (varBag, idService) {
return varBag.vars.value.productNameInLocal;
},
dataType: OS.Types.Text
},
"i1gCpyLdDUyUU52IViSpmw": {
getter: function (varBag, idService) {
return varBag.vars.value.ratesQuotesInLocal;
}
},
"UJKrh6ma+kySxQTZy7biow": {
getter: function (varBag, idService) {
return varBag.outVars.value.premiumsOut;
}
},
"w2HhKYJu5U2a3DYbWAhUZQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.detailsOut;
}
},
"20NvMA5_Q0CIPR225cJSpA": {
getter: function (varBag, idService) {
return varBag.outVars.value.breakdownOut;
}
},
"Ab76DRri7kamkKxUo4CINQ": {
getter: function (varBag, idService) {
return varBag.listFilterMonthlyVar.value;
}
},
"3HCGL4q2okG1+jcL7RhkEQ": {
getter: function (varBag, idService) {
return varBag.listFilterQuarterlyVar.value;
}
},
"Y0JcO5hpLk6rMowjIC1K3A": {
getter: function (varBag, idService) {
return varBag.listFilterHalfYearlyVar.value;
}
},
"39IrR_gfr0SIFbtD2jQptA": {
getter: function (varBag, idService) {
return varBag.listFilterFortnightlyVar.value;
}
},
"kkgqaPVGr02i6ux4dfU+KQ": {
getter: function (varBag, idService) {
return varBag.listFilterWeeklyVar.value;
}
},
"o9cRkYKdMEa9Ey25I+VEsQ": {
getter: function (varBag, idService) {
return varBag.listFilterYearlyVar.value;
}
},
"IDFnGdD8PECv6LkLuIZk7w": {
getter: function (varBag, idService) {
return varBag.vars.value.primaryMemberInLocal;
}
},
"Qg9n7lR_VEmSG8AnPl7llw": {
getter: function (varBag, idService) {
return varBag.vars.value.additionalMembersInLocal;
}
},
"JkGaAEykt0OF23m1gjr93g": {
getter: function (varBag, idService) {
return varBag.outVars.value.selectedStakeholderIdsOut;
}
},
"fMA36S5UUka77ZDKfCWCxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.monthDateInInLocal;
},
dataType: OS.Types.Date
},
"XAStfQJg2Uq5smguKH3n9w": {
getter: function (varBag, idService) {
return varBag.outVars.value.textDateOutOut;
},
dataType: OS.Types.Text
},
"vHvS0GB4UkiYI1ELocJwAQ": {
getter: function (varBag, idService) {
return varBag.vars.value.breakdownInLocal;
}
},
"4k1BdK_LHkqVPb1PY+NDVA": {
getter: function (varBag, idService) {
return varBag.vars.value.premiumsInLocal;
}
},
"4Jl9gMzvekWEVpt2I1t4kA": {
getter: function (varBag, idService) {
return varBag.vars.value.frequencyInLocal;
},
dataType: OS.Types.Text
},
"l4FW2hz_j06mSvQkqywcCQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.premiumAmountOut;
},
dataType: OS.Types.Currency
},
"pAWZckLo70igRCBANzf31g": {
getter: function (varBag, idService) {
return varBag.listFilter_NextDueAmountVar.value;
}
},
"pu8+UqqVnEGVKSZVZmZ41A": {
getter: function (varBag, idService) {
return varBag.vars.value.coverListInLocal;
}
},
"Tgr9BMW0NEGSeuvFs5gEJg": {
getter: function (varBag, idService) {
return varBag.vars.value.class_ListInLocal;
}
},
"Yxnlss9rt0Ozy_zuKN6_PA": {
getter: function (varBag, idService) {
return varBag.vars.value.classListInLocal;
}
},
"6hUSC2AdXkOIC4yPNGNnzQ": {
getter: function (varBag, idService) {
return varBag.vars.value.class_IdInLocal;
},
dataType: OS.Types.LongInteger
},
"0+LroHj52E6HbRuastzdlw": {
getter: function (varBag, idService) {
return varBag.vars.value.cover_IdInLocal;
},
dataType: OS.Types.LongInteger
},
"0YXsD+WlV0GXiwd8iKzzQQ": {
getter: function (varBag, idService) {
return varBag.vars.value.classDropdown_ValidInLocal;
},
dataType: OS.Types.Boolean
},
"9kXgLRBPKUWv58YlfcboZQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_Class_ListOut;
}
},
"huJ+uQdUWkuOwAFSACm2Xg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_Class_IdOut;
},
dataType: OS.Types.LongInteger
},
"PLhMJdxzV0ysZG7rxePPHg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_ClassDropdown_ValidOut;
},
dataType: OS.Types.Boolean
},
"D4HNNVqd70eNoKQQmglSKg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_CoverListOut;
}
},
"lXOtGO6IqEaSpBrV4YW7yw": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_ClassListOut;
}
},
"ut5iwhffykaet32FwWmA2w": {
getter: function (varBag, idService) {
return varBag.outVars.value.coverCodeOut;
},
dataType: OS.Types.Text
},
"IIh4sGEe_0WV1VejbPCGkQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.coverNameOut;
},
dataType: OS.Types.Text
},
"KnDjCz8jeE6mvyAnFlg1Ow": {
getter: function (varBag, idService) {
return varBag.getClassListDropdownVar.value;
}
},
"XBnUU1l6lEu97FDaLnJZKA": {
getter: function (varBag, idService) {
return varBag.listFilter_ClassVar.value;
}
},
"+zoO+hVX0kOQniq1V0opBA": {
getter: function (varBag, idService) {
return varBag.listFilter_CoverVar.value;
}
},
"DDJSJrpLz0+D+THG_nWc6A": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderAddressInLocal;
}
},
"zYaJu_nESU+Zc8s2Rqw5Rw": {
getter: function (varBag, idService) {
return varBag.vars.value.isOverseasInLocal;
},
dataType: OS.Types.Boolean
},
"iSq+m5R24UCyM0JrrcNmJg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_StakeholderAddressOut;
}
},
"Jl7Gr8Y4Bk2FQctukpS6+w": {
getter: function (varBag, idService) {
return varBag.vars.value.currentInLocal;
},
dataType: OS.Types.Text
},
"hL7gh80ZJU+fOKYOD+Znqw": {
getter: function (varBag, idService) {
return varBag.vars.value.addDescInLocal;
},
dataType: OS.Types.Boolean
},
"6BNIjhwb1UCONbUQ6YfXaQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.newOut;
},
dataType: OS.Types.Text
},
"PXpr92kqcUa75tcFoIZqjg": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibility_StructInLocal;
}
},
"yjEYcwibSk2eT7YEpvloQw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"daIWLJXZI0CKq6juoe983A": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"OL3+nKtgQ066X95bdtza4A": {
getter: function (varBag, idService) {
return varBag.outVars.value.eligibility_Handler_OutOut;
}
},
"aTsRbadw60ao8d0Bk6m22Q": {
getter: function (varBag, idService) {
return varBag.vars.value.memberDetailsStructureInLocal;
}
},
"whMhOQtJO06Tvd_0cXURNQ": {
getter: function (varBag, idService) {
return varBag.vars.value.memberLHCABDInLocal;
}
},
"Q+d7To93EkaocParbMxpKw": {
getter: function (varBag, idService) {
return varBag.vars.value.memberPreExisitingConditionInLocal;
}
},
"4uBLZVab0EynEH0S6xzXjQ": {
getter: function (varBag, idService) {
return varBag.vars.value.memberStudentDetailInLocal;
}
},
"3IijJKx4ekaC_akdq25lOQ": {
getter: function (varBag, idService) {
return varBag.vars.value.accordionsInLocal;
}
},
"un35Y_ULsUqtqW3l6j26YQ": {
getter: function (varBag, idService) {
return varBag.vars.value.isValidateLHCABDInLocal;
},
dataType: OS.Types.Boolean
},
"FLY75Xcux0WOgZEnjaCbgA": {
getter: function (varBag, idService) {
return varBag.vars.value.isValidateStudentDetailsInLocal;
},
dataType: OS.Types.Boolean
},
"gtlevtYNZUuWVavX3TMDjg": {
getter: function (varBag, idService) {
return varBag.vars.value.isValidatePreExistingConditionInLocal;
},
dataType: OS.Types.Boolean
},
"Gw283My1NUqVQ555xTVDNw": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberDetailsStructure_UpdatedOut;
}
},
"rQniuNwZnUirju7XXvvl1A": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberLHCABD_UpdatedOut;
}
},
"oGcifqBgckyuupFcWAB5uA": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberPreExisitingCondition_UpdatedOut;
}
},
"ecH46VzACkesSCSxy5eFrw": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberStudentDetail_UpdatedOut;
}
},
"R7xoDJG+902l2ltHubbbng": {
getter: function (varBag, idService) {
return varBag.outVars.value.accordions_UpdatedOut;
}
},
"RUfCDM8bOUyZCWecmFl_2A": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"xdFqFgr0DkKwnJ_fjuj6dA": {
getter: function (varBag, idService) {
return varBag.validateMemberPersonalDetailsVar.value;
}
},
"kXxkObMDPEWSLoh9Gk1Qfw": {
getter: function (varBag, idService) {
return varBag.validatePreExistingConditionVar.value;
}
},
"w5TnSdroLUSz3azqNx52ZA": {
getter: function (varBag, idService) {
return varBag.validateLHCABDDetailsVar.value;
}
},
"cLXmynZDdEuIGzDeryShCA": {
getter: function (varBag, idService) {
return varBag.validateStudentDetailsVar.value;
}
},
"7XpF2qDdV0WD5Chu1j_6+g": {
getter: function (varBag, idService) {
return varBag.vars.value.policyIdInLocal;
},
dataType: OS.Types.LongInteger
},
"eD4RGOLvCUWM005MfYzs+w": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderIdInLocal;
},
dataType: OS.Types.Text
},
"VD4bD+pJM0OLBeNirFIGiw": {
getter: function (varBag, idService) {
return varBag.outVars.value.caseIdOut;
},
dataType: OS.Types.Text
},
"GzLIQu2hdEm6thFzdjdmkw": {
getter: function (varBag, idService) {
return varBag.createPolicyReactivationSuspendCaseVar.value;
}
},
"zqDGCkU0+E6nxUKazonFvg": {
getter: function (varBag, idService) {
return varBag.vars.value.policyDetails_TempInLocal;
}
},
"xmOSpDutukSa02qhLc1txg": {
getter: function (varBag, idService) {
return varBag.outVars.value.policyDetails_OutOut;
}
},
"6e7utfvUt0+YLhHThcwc5w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"az4MCdqV3k6yQnnR__edlQ": {
getter: function (varBag, idService) {
return varBag.vars.value.dateInLocal;
},
dataType: OS.Types.Text
},
"zwqfnFJVZEm4ZCV+TsRjnA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"ict+VR5DuEWLRluO5UgQeQ": {
getter: function (varBag, idService) {
return varBag.javaScript_CheckPatternJSResult.value;
}
},
"P9MXDfo8kUKNoU5xUGX_jA": {
getter: function (varBag, idService) {
return varBag.vars.value.fundListInLocal;
}
},
"F4D9AFD7s02igj7Y9r6VPQ": {
getter: function (varBag, idService) {
return varBag.vars.value.healthScaleListInLocal;
}
},
"788BPy_iG0OwTf_pdHUm4Q": {
getter: function (varBag, idService) {
return varBag.vars.value.policyPreviousCoverDetailsListInLocal;
}
},
"ZBffLzf55kqAfO54nD2LHQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.previousCoverDetailsListOut;
}
},
"yVZeonkJ9USUwQBWtPlaGA": {
getter: function (varBag, idService) {
return varBag.healthScaleVar.value;
}
},
"2P46qJ+ObkKTJa_Ja60uJQ": {
getter: function (varBag, idService) {
return varBag.fundVar.value;
}
},
"afRGNbii2UCy7xJJhxozoQ": {
getter: function (varBag, idService) {
return varBag.vars.value.interestLevel_HandlerInLocal;
}
},
"cxAnfxNew0ewVJ4lh9Z9LA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"yxpCCQ6UZUKPhJHf2XVQZg": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"6H9EZhEB80CEr2Na28843g": {
getter: function (varBag, idService) {
return varBag.outVars.value.interestLevel_Handler_OutOut;
}
},
"MYZgEII3AUumR+TmBsFN3g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"pVjx23iI1E64HnF3_hYYBQ": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInLocal;
},
dataType: OS.Types.Text
},
"z1oJcsr0Mku+PRcS3kvKaQ": {
getter: function (varBag, idService) {
return varBag.setAriaLabelJSResult.value;
}
},
"TEY1Xk2fHkKJ+Ucsqf2HAg": {
getter: function (varBag, idService) {
return varBag.vars.value.dOBInLocal;
},
dataType: OS.Types.Date
},
"G+EKMpOIJkOk2yOvogmfEw": {
getter: function (varBag, idService) {
return varBag.outVars.value.ageOut;
},
dataType: OS.Types.Integer
},
"B3633tPLrEukJe4EodYPrg": {
getter: function (varBag, idService) {
return varBag.vars.value.memberLHCABDInLocal;
}
},
"WdBfjEzcK0aqFlzlStMFdg": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberLHCABD_UpdatedOut;
}
},
"whod83UzEEarHXE82FM14Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"altxbtT1E0K35MG4R3H_3Q": {
getter: function (varBag, idService) {
return varBag.vars.value.emailList_HandlerInLocal;
}
},
"4sPrHoA+a0GgESwDpmjf3A": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"SQGqWZRE8kOlwErKcc8y2w": {
getter: function (varBag, idService) {
return varBag.outVars.value.emailList_Handler_OutOut;
}
},
"8Qnn4VU5jkmJZ+Ux2B00tw": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"BBHACwX+F0iPLot9ZdZXxg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasError_EmailListOut;
},
dataType: OS.Types.Boolean
},
"VXTv1x+YWkKq625s9MR12Q": {
getter: function (varBag, idService) {
return varBag.validateEmailVar.value;
}
},
"pjcvDzAHkkmZPFJ2JUjLmA": {
getter: function (varBag, idService) {
return varBag.vars.value.rebateActionListInLocal;
}
},
"t2Ctnl8SeU6O_jr2AbZ5yw": {
getter: function (varBag, idService) {
return varBag.vars.value.updated_RebateDetailsListInLocal;
}
},
"6m83dOO480ycEnDCjwxTkA": {
getter: function (varBag, idService) {
return varBag.vars.value.rowNumberInLocal;
},
dataType: OS.Types.Integer
},
"PR+myFBYbUyEfN3u2dBdFw": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_Updated_RebateDetailsListOut;
}
},
"6aTBQQvywk2rOyv_kSjqFA": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_RebateActionListOut;
}
},
"f5My0SRqvUqQ2faIavBiAQ": {
getter: function (varBag, idService) {
return varBag.rebateAction2Var.value;
}
},
"rz2a6G9XBESlbzqhPE87eg": {
getter: function (varBag, idService) {
return varBag.savingsProvisionsStartVar.value;
}
},
"M4k48FA6jkaL6btds5H1SQ": {
getter: function (varBag, idService) {
return varBag.savingsProvisionsEndVar.value;
}
},
"xMsvOZnFaEOKxWNz91DbOg": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailsInLocal;
}
},
"c9BHKaXpnEKHOUeNi8DZ0g": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_CountryListInLocal;
}
},
"bZ46LLkTDUmU0tr8Hgmrwg": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_MedicareCardTypeListInLocal;
}
},
"xSWuW0vEz0OBIHa6JLHYyQ": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_StateListInLocal;
}
},
"J5fBD96zvkKgQoUmtWXZgQ": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_SexListInLocal;
}
},
"cLYRBO4YS0ycSMPlzzFfUA": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_PolicyRoleListInLocal;
}
},
"D15rBZlBUk6aJz2iy9Hbig": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_TitleListInLocal;
}
},
"1892IkvmN0WbwSaPuKdu3g": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_PronounsListInLocal;
}
},
"asKSqthQ1U+qTLYAUCIwbA": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_RankListInLocal;
}
},
"eciDyZBj20+s5mKwlxviVA": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_AddressTypeListInLocal;
}
},
"B5FGmKrPDEu9DazBIpwrFQ": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_PhoneTypeListInLocal;
}
},
"P5Vp9hIMoUeUwzYmUIsxSg": {
getter: function (varBag, idService) {
return varBag.vars.value.getQuote_StakeholderInLocal;
}
},
"1iK1FG1GhUixvmnO_Jqw9A": {
getter: function (varBag, idService) {
return varBag.outVars.value.ratesQuote_RevisionsOut;
}
},
"Ip5XNCVLQUOqBIPV9xUssA": {
getter: function (varBag, idService) {
return varBag.outVars.value.primaryMemberOut;
}
},
"hGKyElMWm0GXKdamqHmzSQ": {
getter: function (varBag, idService) {
return varBag.phoneTypeVar.value;
}
},
"mNLxNGenKU2E85R7zQ7UfA": {
getter: function (varBag, idService) {
return varBag.addressTypeVar.value;
}
},
"GbmrSe16r0W+NU1ZXonLTg": {
getter: function (varBag, idService) {
return varBag.titleListVar.value;
}
},
"OUDRWKVtsES74GGaajg1CA": {
getter: function (varBag, idService) {
return varBag.rankListVar.value;
}
},
"MeiEqjXDjUavkNPBfGDqPA": {
getter: function (varBag, idService) {
return varBag.medicareCardTypeListVar.value;
}
},
"+qH1rM4GsUaK7Jc7mc_LgA": {
getter: function (varBag, idService) {
return varBag.countryListVar.value;
}
},
"h36OuIZUqEenkRlIap_kaw": {
getter: function (varBag, idService) {
return varBag.roleListVar.value;
}
},
"3HN74ySAhUiV9eBDQPQLpw": {
getter: function (varBag, idService) {
return varBag.pronounsVar.value;
}
},
"hmDi6MhuwkKe3U4ofUChWw": {
getter: function (varBag, idService) {
return varBag.stateVar.value;
}
},
"8Eo4+v99ikCax5UqTyz56A": {
getter: function (varBag, idService) {
return varBag.sexListVar.value;
}
},
"lYnnVDUPEUK9ofHUyJU1iA": {
getter: function (varBag, idService) {
return varBag.vars.value.isUpdateInLocal;
},
dataType: OS.Types.Boolean
},
"BfZfxwxRBUKRKNDuZqR4Ow": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderRecordInLocal;
}
},
"t+nhWDeuQkyNxluUPh95MQ": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneList_HandlerInLocal;
}
},
"EYrys05iHUi07EXx1tLYuA": {
getter: function (varBag, idService) {
return varBag.vars.value.emailList_HandlerInLocal;
}
},
"0T3teAO_wUi_V2egKaHkjQ": {
getter: function (varBag, idService) {
return varBag.vars.value.addressList_HandlerInLocal;
}
},
"wmAo1oXIiEOoTfgQQrBPUA": {
getter: function (varBag, idService) {
return varBag.vars.value.personalDetails_HandlerInLocal;
}
},
"diOdhw_J4Ea8N4YU5ksHCA": {
getter: function (varBag, idService) {
return varBag.vars.value.interestLevel_HandlerInLocal;
}
},
"S9li7kTqQ02APnDYjGu1Kw": {
getter: function (varBag, idService) {
return varBag.vars.value.communicationPreference_HandlerInLocal;
}
},
"TjrA_RD6QkCwYLVvDjkm1g": {
getter: function (varBag, idService) {
return varBag.outVars.value.stakeholderRecord_OutOut;
}
},
"WFaGGl7ohE+Iqty4UFMVRQ": {
getter: function (varBag, idService) {
return varBag.activeAddressListVar.value;
}
},
"PZZTN3f7p0CP_XNsn1NqDw": {
getter: function (varBag, idService) {
return varBag.activeEmailListVar.value;
}
},
"E0o6dSoTjkmQDhxrTU4OlA": {
getter: function (varBag, idService) {
return varBag.activePhoneListVar.value;
}
},
"A+wJARc8002RGK4JPodx3g": {
getter: function (varBag, idService) {
return varBag.vars.value.communicationPreferenceListInLocal;
}
},
"Uypv335EREu0QZLNHgCq8A": {
getter: function (varBag, idService) {
return varBag.vars.value.communicationPreferenceDetailsInLocal;
}
},
"YNJnxA6Zhk+rNyDKtjH7Kg": {
getter: function (varBag, idService) {
return varBag.outVars.value.detailsOut;
}
},
"linjaCkSNk6XtOUPK+3Kbg": {
getter: function (varBag, idService) {
return varBag.legislativeCommunicationsVar.value;
}
},
"nvwxixfQCUKw49TR+uD9FQ": {
getter: function (varBag, idService) {
return varBag.claimsInformationVar.value;
}
},
"agrYjTiitUWMXFLhSn8bRg": {
getter: function (varBag, idService) {
return varBag.fundInformationVar.value;
}
},
"qV+jsFpqL02I_2AFeriMeQ": {
getter: function (varBag, idService) {
return varBag.stakeholderPolicyUpdateVar.value;
}
},
"Q4xD_IfLN0C6sG241gl4vA": {
getter: function (varBag, idService) {
return varBag.marketingVar.value;
}
},
"AUL47HPRmEqAxT7lCiKOXQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyBasicDetailsInLocal;
}
},
"+ZciHjn_m0GVMpzE9jXWmg": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibilityReasonListInLocal;
}
},
"PcEf+MoaXUCXeqAToujZ3w": {
getter: function (varBag, idService) {
return varBag.vars.value.eligibilitySubReasonListInLocal;
}
},
"wLEQMlsnxESyG0B6poD39A": {
getter: function (varBag, idService) {
return varBag.vars.value.coverListInLocal;
}
},
"pRjz8KdneUWbz2H9iQQobw": {
getter: function (varBag, idService) {
return varBag.vars.value.classListInLocal;
}
},
"khMNyIn2_EWUC_LMPp+fUw": {
getter: function (varBag, idService) {
return varBag.vars.value.stateListInLocal;
}
},
"ZRlbKz9vtkmTS4jKiTF7Sw": {
getter: function (varBag, idService) {
return varBag.vars.value.residencyListInLocal;
}
},
"7WaK6VH73EyRCayXZWmOqw": {
getter: function (varBag, idService) {
return varBag.vars.value.groupListInLocal;
}
},
"6TtTJof+VEC6iAJNw5Uddw": {
getter: function (varBag, idService) {
return varBag.vars.value.branchListInLocal;
}
},
"BkOjVwvdgU+7QuKex5Yc1g": {
getter: function (varBag, idService) {
return varBag.vars.value.agentListInLocal;
}
},
"mANJJkchvEmRNdEatnlbcQ": {
getter: function (varBag, idService) {
return varBag.vars.value.locationListInLocal;
}
},
"R8p6CKW0WU2XxhSczWrGng": {
getter: function (varBag, idService) {
return varBag.vars.value.siteListInLocal;
}
},
"737uDcbK_0q_4sN5uYkEbQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.basicDetailsOut;
}
},
"Xz9xLEWoTUOqlEHcgKQMxA": {
getter: function (varBag, idService) {
return varBag.group_ListVar.value;
}
},
"3bzFML6wikGhTvMi+CwVAA": {
getter: function (varBag, idService) {
return varBag.getClassListVar.value;
}
},
"eHh5OJoLZEuKPbtctJaSDA": {
getter: function (varBag, idService) {
return varBag.locationVar.value;
}
},
"JdECUqEfQUGRmbGFfLdXIA": {
getter: function (varBag, idService) {
return varBag.agent_ListVar.value;
}
},
"Ha8GkdlfaEqHyjMQ5k65AA": {
getter: function (varBag, idService) {
return varBag.site_ListVar.value;
}
},
"XKrrubCOvk6bakktxdI6sg": {
getter: function (varBag, idService) {
return varBag.class_ListVar.value;
}
},
"BD+hvxaCZEWFisQqydSh3g": {
getter: function (varBag, idService) {
return varBag.eligibilityReasonVar.value;
}
},
"P6Oqz4vgPU+LZWE6VIFoqg": {
getter: function (varBag, idService) {
return varBag.eligibilitySubReasonVar.value;
}
},
"NlG840O8zkKgnpB0CAU5tQ": {
getter: function (varBag, idService) {
return varBag.getCover_ByClassParentCodeVar.value;
}
},
"QIQE6BzE4U2eWhnZEL4B_g": {
getter: function (varBag, idService) {
return varBag.residency_ListVar.value;
}
},
"7WmI6fSEEUiKYZP_8GSI5Q": {
getter: function (varBag, idService) {
return varBag.branch_ListVar.value;
}
},
"Ak6g+ICm10ywY3hJtJ_2zA": {
getter: function (varBag, idService) {
return varBag.cover_ListVar.value;
}
},
"G3Pt+ugsyEqO3tgERQoiEg": {
getter: function (varBag, idService) {
return varBag.state_ListVar.value;
}
},
"qtCalF6xGkiyz_90CIxVCg": {
getter: function (varBag, idService) {
return varBag.vars.value.textDateInInLocal;
},
dataType: OS.Types.Text
},
"d24uNPCF5E+KuKs73DO9bA": {
getter: function (varBag, idService) {
return varBag.outVars.value.dateOutOut;
},
dataType: OS.Types.Date
},
"vZrUasfCKUy8UGN+LsYADg": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholder_AdditionalDetailsInLocal;
}
},
"kdkEq3dv3UmoXuAm9hsxnQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.locationErrorOut;
},
dataType: OS.Types.Text
},
"IOPmt0RqPUmcYcitqrv+qg": {
getter: function (varBag, idService) {
return varBag.outVars.value.siteErrorOut;
},
dataType: OS.Types.Text
},
"1gqZ4igT_kWsck3JBJVNfg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"ysiODQ9ffE2OGQB12vyshQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.waitingPeriodDataOut;
}
},
"Q2VqRObEL0uv9nbhw9B2oA": {
getter: function (varBag, idService) {
return varBag.vars.value.policyFlagDetailsListInLocal;
}
},
"DLGdHWH770ulSVg8VB7y_A": {
getter: function (varBag, idService) {
return varBag.vars.value.flagListInLocal;
}
},
"voxE1mFfKEq4sN9wZAeuXA": {
getter: function (varBag, idService) {
return varBag.outVars.value.flagDetailsListOut;
}
},
"Ah8dOBOYgkqLvHgeYXjCpw": {
getter: function (varBag, idService) {
return varBag.flagTypeVar.value;
}
},
"P8OD7ShJ6kuUOoV8RH_BbA": {
getter: function (varBag, idService) {
return varBag.vars.value.membersInLocal;
}
},
"l6_MheJ3yUego5Tvd7_NWw": {
getter: function (varBag, idService) {
return varBag.outVars.value.primaryMemberOut;
}
},
"hAxSid3GCEanAc1e0fmHPg": {
getter: function (varBag, idService) {
return varBag.outVars.value.otherMembersOut;
}
},
"KEN_+jBcNEmb9im45MzeiQ": {
getter: function (varBag, idService) {
return varBag.vars.value.listVar;
}
},
"SEaWG1hRJUWiWkZwtoI4fw": {
getter: function (varBag, idService) {
return varBag.vars.value.recordVar;
}
},
"HBoBpyWUPU2iem3KCZwMSw": {
getter: function (varBag, idService) {
return varBag.vars.value.policyMemberInLocal;
}
},
"Fw9KlE6PtUevuXjwiXMZYw": {
getter: function (varBag, idService) {
return varBag.outVars.value.additionalOut;
},
dataType: OS.Types.Text
},
"FqUXjZf+h0uaevscZAUegw": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"CDvsNtJ_cUa4SCPrAgBJDw": {
getter: function (varBag, idService) {
return varBag.vars.value.fileNameInLocal;
},
dataType: OS.Types.Text
},
"a0T3jS2DYE+rJRnBuZCbhw": {
getter: function (varBag, idService) {
return varBag.outVars.value.extensionOut;
},
dataType: OS.Types.Text
},
"a5C9upEDLUyVL0ozFtAwtg": {
getter: function (varBag, idService) {
return varBag.vars.value.hasMandatoryFieldErrorVar;
},
dataType: OS.Types.Boolean
},
"4DRcn5DT2UuVx9JX9jAhDA": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneList_HandlerInLocal;
}
},
"YNX4gI5ROkWrLNFY55DhaQ": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"u+Uiw2dXwUycoRW63sIorw": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailSettingInLocal;
}
},
"P4NmnrwMQUCNLAoQKjMEqg": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderTypeIdInLocal;
},
dataType: OS.Types.Integer
},
"QJD_nulFH0KuWUQIsGrTjw": {
getter: function (varBag, idService) {
return varBag.vars.value.isContributorInLocal;
},
dataType: OS.Types.Boolean
},
"6YmqXfaVc0C6aF_iuvjriA": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneList_Handler_OutOut;
}
},
"wqN2yr8Fl0mK3GHpFxO+cg": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"2lRSpaCXq0O1qFllElVm4w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasError_PhoneListOut;
},
dataType: OS.Types.Boolean
},
"SdD3fwnEbkuLZg9c6fGGZA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.Types.Text
},
"kwUU42XVW0q4VUigpYEt2Q": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"j6f55avy4E2Br1t5XpGP7g": {
getter: function (varBag, idService) {
return varBag.listDuplicate_isPreferredVar.value;
}
},
"LJotLLLUjUKsJh8hJq_xTw": {
getter: function (varBag, idService) {
return varBag.vars.value.individualStakeholder_NewInLocal;
}
},
"HTr5aDi0x0O6uty+qWGJBA": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecordOut;
}
},
"Za+iBWSv9kSPw_ElRn54Jw": {
getter: function (varBag, idService) {
return varBag.listFilter_Addr_HomeVar.value;
}
},
"bdbgD_up_0iSkocWntzVXw": {
getter: function (varBag, idService) {
return varBag.listFilter_Phone_MobileVar.value;
}
},
"cBLSFAWKX0eHQE0vdO57_w": {
getter: function (varBag, idService) {
return varBag.listFilter_Phone_HomeVar.value;
}
},
"F9J7i8pSyUKrQyZcp1d1QQ": {
getter: function (varBag, idService) {
return varBag.listFilter_Addr_BusinessVar.value;
}
},
"rTs5ygatM0+B5mAHRUh24g": {
getter: function (varBag, idService) {
return varBag.listFilter_Phone_BusinessVar.value;
}
},
"cygAy1GaQUCG2gaEvm6sfg": {
getter: function (varBag, idService) {
return varBag.listFilter_Addr_MailingVar.value;
}
},
"6gpKqIfgEE+BJ2VrJHZG8g": {
getter: function (varBag, idService) {
return varBag.vars.value.personalDetails_HandlerInLocal;
}
},
"pGux3XfmdkSVL3EOFtVKyA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"kN5u0jtrWEa6JeJU5NkkNQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"9h_ZHjE6BkqjgLuRsiRfOw": {
getter: function (varBag, idService) {
return varBag.outVars.value.personalDetails_Handler_OutOut;
}
},
"fQaTSlz3C0GgFDC8fwWKrg": {
getter: function (varBag, idService) {
return varBag.check_Additional_DetailsVar.value;
}
},
"ZJ7QI2FyPkC6xnMxZ61HSA": {
getter: function (varBag, idService) {
return varBag.vars.value.codeInLocal;
},
dataType: OS.Types.Text
},
"1GB+wFFsHEiolsYhSdHZEw": {
getter: function (varBag, idService) {
return varBag.outVars.value.shortNameOut;
},
dataType: OS.Types.Text
},
"XU+TwYxLNUaf_tgtFw8Xmw": {
getter: function (varBag, idService) {
return varBag.vars.value.policyNoteDetailsListInLocal;
}
},
"vVjAIpIPt024PVDyaTNwWA": {
getter: function (varBag, idService) {
return varBag.vars.value.noteListInLocal;
}
},
"rjdX4C0SjUiwONiAPMfm6A": {
getter: function (varBag, idService) {
return varBag.outVars.value.noteDetailsListOut;
}
},
"L9Z2z33ZtUGm1Jg4Dpeuww": {
getter: function (varBag, idService) {
return varBag.noteTypeVar.value;
}
},
"W2XWmJeai0yaotIS7hkzfA": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_RebateActionListInLocal;
}
},
"61O5nbRboU6gxEdHvq5gyw": {
getter: function (varBag, idService) {
return varBag.vars.value.getData_RebateAgeListInLocal;
}
},
"ekayj717CEab_gnrIfz4hg": {
getter: function (varBag, idService) {
return varBag.vars.value.getQuote_RatesQuote_RevisionsInLocal;
}
},
"nzQL37hlHEem1lcARvzYUA": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_GetQuote_RatesQuote_RevisionsOut;
}
},
"56Z1qxpOoEqmQCPFnvyjXA": {
getter: function (varBag, idService) {
return varBag.outVars.value.rebateOut;
}
},
"ApKcjDZed02kWPS8qemGCA": {
getter: function (varBag, idService) {
return varBag.rebateAgeListVar.value;
}
},
"8f_YrY8lBEiWZHmIWR4UJA": {
getter: function (varBag, idService) {
return varBag.rebateActionListVar.value;
}
},
"4_TCG1svhkOrOXKAAUph3Q": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderIdInLocal;
},
dataType: OS.Types.Text
},
"hdZRm5Rug0yhJruTE7p5rQ": {
getter: function (varBag, idService) {
return varBag.vars.value.flags_ListInLocal;
}
},
"zWO_w1n6MkKnrbwNekDsPg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_Flags_ListOut;
}
},
"ckxmj5qhn0Kuw+05NoxadA": {
getter: function (varBag, idService) {
return varBag.getIndividual_EntityFlagsVar.value;
}
},
"y5YA7ERUW0y9Hxib881zJg": {
getter: function (varBag, idService) {
return varBag.vars.value.policyPhoneListInLocal;
}
},
"8stMO6CiJkeuBUb5R4A+yA": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneTypeListInLocal;
}
},
"IhjUTJf6SkyYk2_I3DB7mQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyAddressListInLocal;
}
},
"XYJt0_fH0kaeZZzI2F1Qhw": {
getter: function (varBag, idService) {
return varBag.vars.value.addressTypeListInLocal;
}
},
"QTPrKpNdfE2MuGRnvT7l1w": {
getter: function (varBag, idService) {
return varBag.vars.value.stateListInLocal;
}
},
"wlPTj5_ddUSggp0C98OLcg": {
getter: function (varBag, idService) {
return varBag.vars.value.countryListInLocal;
}
},
"0oZaCzukaEet7ujY5oI19A": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneListOut;
}
},
"o6_5pmnDFk2hz_lm2C89Jg": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressListOut;
}
},
"q_MTHIrQz0SZxDcohw1vfg": {
getter: function (varBag, idService) {
return varBag.addressTypeVar.value;
}
},
"QJYNRaAQMUaAP_kdkjhV1g": {
getter: function (varBag, idService) {
return varBag.countryVar.value;
}
},
"brAvU8bHqkCGD8lNuPZ7nQ": {
getter: function (varBag, idService) {
return varBag.stateVar.value;
}
},
"wNFo+09vj0O7xfad89YEsA": {
getter: function (varBag, idService) {
return varBag.phoneTypeVar.value;
}
},
"i7XulT04YkKY_m8T4gjJeg": {
getter: function (varBag, idService) {
return varBag.vars.value.changesRecordListInLocal;
}
},
"_sUizVo3I0CIEZfdMNhVqA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasChangesOut;
},
dataType: OS.Types.Boolean
},
"Znj7zcAleEWjVXuIIjNfOw": {
getter: function (varBag, idService) {
return varBag.listAnyVar.value;
}
},
"mQMaxFGQKEGT7quZLOg8yw": {
getter: function (varBag, idService) {
return varBag.vars.value.binaryInLocal;
},
dataType: OS.Types.BinaryData
},
"gx1pph2ZakeVSa6dZMw39Q": {
getter: function (varBag, idService) {
return varBag.vars.value.fileNameInLocal;
},
dataType: OS.Types.Text
},
"1cBgKKVEEk+0h4Jd61AmqQ": {
getter: function (varBag, idService) {
return varBag.vars.value.commentsInLocal;
},
dataType: OS.Types.Text
},
"sFqNZljj6EaenznTPKuZaw": {
getter: function (varBag, idService) {
return varBag.vars.value.isAttachmentImageInLocal;
},
dataType: OS.Types.Boolean
},
"MazUBc9GTkyzpJhZsCUeTg": {
getter: function (varBag, idService) {
return varBag.vars.value.fileSizeWithUnitInLocal;
},
dataType: OS.Types.Text
},
"BgK2UcURHka6U+ZcNy8UcQ": {
getter: function (varBag, idService) {
return varBag.vars.value.fileSizeInMBInLocal;
},
dataType: OS.Types.Integer
},
"hwekEQ1SM0WY0zNrqlFrKg": {
getter: function (varBag, idService) {
return varBag.vars.value.fileExtensionInLocal;
},
dataType: OS.Types.Text
},
"uEmR8Ehk8UqJ2XAsGsPyGQ": {
getter: function (varBag, idService) {
return varBag.vars.value.supportedFileExtensionsInLocal;
}
},
"5ltoPyWM8E+ixRyeYWyS2w": {
getter: function (varBag, idService) {
return varBag.vars.value.fileSizeLimitInLocal;
},
dataType: OS.Types.Integer
},
"SzMORJd+_kOUAS6Ud04xxw": {
getter: function (varBag, idService) {
return varBag.outVars.value.documentOut;
}
},
"+XUmdIDoZEa3oLXnfv6Rig": {
getter: function (varBag, idService) {
return varBag.listAnyFileExtensionVar.value;
}
},
"Hn9OPag860WRTrYuWoOhhg": {
getter: function (varBag, idService) {
return varBag.vars.value.rebateMedicareListInLocal;
}
},
"FzlEUSDnwEaIacSxjXPP4A": {
getter: function (varBag, idService) {
return varBag.vars.value.policyPersonalDetailsInLocal;
}
},
"hKyYWue3Jki2O6EYdhpeBQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyInLocal;
}
},
"u_4XMAIP6E6gzcIjF69rzQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_RebateMedicareListOut;
}
},
"Eu6MHEGhAUCchKgvt3MMdg": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_PolicyPersonalDetailsOut;
}
},
"1Ct3_UbAxU6tH7HCA8qw9w": {
getter: function (varBag, idService) {
return varBag.vars.value.rebateDetailsInLocal;
}
},
"gzkzXS9NvUiAiUKfD4_GPg": {
getter: function (varBag, idService) {
return varBag.vars.value.hasErrorInLocal;
},
dataType: OS.Types.Boolean
},
"h8X+zkhzVEGXVwKRZD7V8w": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_RebateDetailsOut;
}
},
"7a0mxUyeKkuY+OieSJvDyA": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_HasErrorOut;
},
dataType: OS.Types.Boolean
},
"0PwcZLwjHEOvujUK3xMjKQ": {
getter: function (varBag, idService) {
return varBag.vars.value.productOptionsInInLocal;
}
},
"4mQhlxFQuESr5P20fabZPg": {
getter: function (varBag, idService) {
return varBag.outVars.value.productOptionsOutOut;
}
},
"mxy7Z7DolEiZDFAyyuhlyA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"0v5MPgen_k2O9Us5ganrkw": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"KYep+RzPu0+2VSq2p7pm4w": {
getter: function (varBag, idService) {
return varBag.vars.value.hasMandatoryFieldErrorVar;
},
dataType: OS.Types.Boolean
},
"883lYsWNHkitBcObZvZ3LQ": {
getter: function (varBag, idService) {
return varBag.vars.value.addressList_HandlerInLocal;
}
},
"EuYYmGgcuEaIFVKdbjfl+A": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"ksmrmUytCECEO8_ORiKbJw": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailSettingInLocal;
}
},
"Pr9LZHHtlUuw+2mq6BOR0g": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderTypeIdInLocal;
},
dataType: OS.Types.Integer
},
"0EmROF0IZ0S7dBHmKdLEnw": {
getter: function (varBag, idService) {
return varBag.vars.value.isContributorInLocal;
},
dataType: OS.Types.Boolean
},
"wdv5VPnjykWmCm8ze8ShBQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressList_Handler_OutOut;
}
},
"vGceetxxN0CCkPHRfnGIgQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"u+ev4yuv3EOUrFZuUCvWPg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasError_AddressListOut;
},
dataType: OS.Types.Boolean
},
"_MOSywGvpkS13DrHeysLkA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.Types.Text
},
"PWo3F+mse0e4z3SjCqAcQA": {
getter: function (varBag, idService) {
return varBag.vars.value.currentStakeholderIdInLocal;
},
dataType: OS.Types.Text
},
"RPd1n28qa0Gxla2Xqmlieg": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedStakeholderIdsInLocal;
}
},
"rZwHSRQHNE6Q8F42WcECDA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSelectedOut;
},
dataType: OS.Types.Boolean
},
"gCLfpcDzTUOyqxmMlseWqQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyHealthScaleInLocal;
}
},
"5yU0HJ8W80i2KgAG2ChG+g": {
getter: function (varBag, idService) {
return varBag.vars.value.healthScaleListsInLocal;
}
},
"7dKRwFGIaUGOYFmBMRZraQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_PolicyHealthScaleOut;
}
},
"Et1TDirsdU6JWEQoe1S7og": {
getter: function (varBag, idService) {
return varBag.productTypeVar.value;
}
},
"OzO2G3k1M0Su36z1Shh2gg": {
getter: function (varBag, idService) {
return varBag.otherRateScaleVar.value;
}
},
"rOokMWpluEavCoPJ9SUn8Q": {
getter: function (varBag, idService) {
return varBag.otherProductNameVar.value;
}
},
"nO4wQ8TNskaX5GubUjZOfw": {
getter: function (varBag, idService) {
return varBag.productNameVar.value;
}
},
"7YFfkQKSlEyo5yEUkPyyqQ": {
getter: function (varBag, idService) {
return varBag.rateScaleVar.value;
}
},
"+E3txBzXFkiyokPcW2sDnA": {
getter: function (varBag, idService) {
return varBag.productTierVar.value;
}
},
"uIM4OWA+Tky_2BYVwIyjxA": {
getter: function (varBag, idService) {
return varBag.vars.value.memberDetailsStructureInLocal;
}
},
"vr_Dk6Nc8kO3Yk5luji6Hw": {
getter: function (varBag, idService) {
return varBag.vars.value.isValidateSexInLocal;
},
dataType: OS.Types.Boolean
},
"FuaBG7p4p0mn34AfusdGvQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberDetailsStructure_UpdatedOut;
}
},
"FZnnyOiGiU6oV4aW2CZl5w": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"3QBbijICtk6aWHqqr6Re_w": {
getter: function (varBag, idService) {
return varBag.vars.value.cardNumberInLocal;
},
dataType: OS.Types.Text
},
"FQq90RbMbUazm5uEIr3kaA": {
getter: function (varBag, idService) {
return varBag.outVars.value.maskedCardNumberOut;
},
dataType: OS.Types.Text
},
"wVkn7s9lYk6HilpmeVxk6w": {
getter: function (varBag, idService) {
return varBag.maskCardNumberJSResult.value;
}
},
"lvrtSbzAJUWCcBpe7QZTYw": {
getter: function (varBag, idService) {
return varBag.vars.value.isAscendingVar;
},
dataType: OS.Types.Boolean
},
"kNVXXnLB2UqMGMf0ACqQTg": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderListSortInLocal;
},
dataType: OS.Types.Text
},
"qtLZvHL5A0CTixMfcHADAQ": {
getter: function (varBag, idService) {
return varBag.vars.value.processedCoverListInLocal;
}
},
"95dewdq6X06AZLo7E+ASpA": {
getter: function (varBag, idService) {
return varBag.vars.value.startIndexInLocal;
},
dataType: OS.Types.Integer
},
"NqOvrVO_TkS2kXF5_qe8Cg": {
getter: function (varBag, idService) {
return varBag.vars.value.maxRecordsInLocal;
},
dataType: OS.Types.Integer
},
"1UPvp7RjSUaxLN8GN8USnw": {
getter: function (varBag, idService) {
return varBag.outVars.value.displayCoverListOut;
}
},
"q_ilAgs46U6j_NUl4Nd2Rw": {
getter: function (varBag, idService) {
return varBag.vars.value.memberDetailsStructureInLocal;
}
},
"N_Hb18J4Q0WJ8pnD3jt2Pg": {
getter: function (varBag, idService) {
return varBag.vars.value.memberLHCABDInLocal;
}
},
"x3dJ5e3mC0GKCdcJF_jTgA": {
getter: function (varBag, idService) {
return varBag.vars.value.addressList_HandlerInLocal;
}
},
"1cVlYEwx00uQxLzSULNpsA": {
getter: function (varBag, idService) {
return varBag.vars.value.emailList_HandlerInLocal;
}
},
"zJ6dNhn5AE+VtaN_fycmUg": {
getter: function (varBag, idService) {
return varBag.vars.value.phoneList_HandlerInLocal;
}
},
"zUQ1kMbNgUaYdd+9vGeSrQ": {
getter: function (varBag, idService) {
return varBag.vars.value.countRecord_HandlerInLocal;
}
},
"RcpS8pfDw0uo0DUlVOs_gw": {
getter: function (varBag, idService) {
return varBag.vars.value.contactDetailSettingInLocal;
}
},
"Y2RClYSkPUCB2q5ht9btOQ": {
getter: function (varBag, idService) {
return varBag.vars.value.additionalDetailsInLocal;
}
},
"RCL9ceuPBUC6WIFv3Np0cg": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberDetailsStructure_OutOut;
}
},
"2Xhfa3HqMk6wGBBieriWLQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.memberLHCABD_OutOut;
}
},
"A2nQcOafY0Ks1NFI8miDtA": {
getter: function (varBag, idService) {
return varBag.outVars.value.addressList_Handler_OutOut;
}
},
"YJUCPrFjYUeGxZgQEJWl9A": {
getter: function (varBag, idService) {
return varBag.outVars.value.emailList_Handler_OutOut;
}
},
"H9s8qTzOGUuJdfL45gn+Tw": {
getter: function (varBag, idService) {
return varBag.outVars.value.phoneList_Handler_OutOut;
}
},
"OFAJEVF_5kiCPC2tdLzBFw": {
getter: function (varBag, idService) {
return varBag.outVars.value.countRecord_Handler_OutOut;
}
},
"kTnNPgBvMEiKwyc0Gccfnw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasErrorOut;
},
dataType: OS.Types.Boolean
},
"3qwIKXyOME20yBtsLOWPtQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorFeedbackMessageOut;
},
dataType: OS.Types.Text
},
"Nf32hld7tkS_KNFK41bFig": {
getter: function (varBag, idService) {
return varBag.outVars.value.additionalDetails_OutOut;
}
},
"oQ1H+xh7Dk+_lJpd7cl2Sg": {
getter: function (varBag, idService) {
return varBag.outVars.value.contactDetails_ValidationOut;
}
},
"pGVHSZahWEaDJVC2rgjFIw": {
getter: function (varBag, idService) {
return varBag.validateMemberPersonalDetailsVar.value;
}
},
"Ic62T50kwEi_HZc99gzJJg": {
getter: function (varBag, idService) {
return varBag.validateLHCABDDetailsVar.value;
}
},
"db2YX_wP1USHN8UmNJUPVg": {
getter: function (varBag, idService) {
return varBag.check_Additional_DetailsVar.value;
}
},
"AGVW3+0bhkahUxT6avPzEA": {
getter: function (varBag, idService) {
return varBag.check_Contact_DetailsVar.value;
}
},
"eGi0qReMtE6_4AVRfgeL9A": {
getter: function (varBag, idService) {
return varBag.vars.value.isAscendingVar;
},
dataType: OS.Types.Boolean
},
"LXDc189IsUGN46vunajasw": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderListSortInLocal;
},
dataType: OS.Types.Text
},
"D_B932DUc0C_Oam3IZNYDQ": {
getter: function (varBag, idService) {
return varBag.vars.value.policyMembersInLocal;
}
},
"xQ6i8jZv3ke8X92uAeFjug": {
getter: function (varBag, idService) {
return varBag.outVars.value.out_PolicyMembersOut;
}
},
"conPDGCjj0mUZieCMjJ0PQ": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getNotificationListSort();
},
dataType: OS.Types.Text
},
"0wDKDVJklUeeMHERs_FStA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getCauseAuditListSort();
},
dataType: OS.Types.Text
},
"4BcWEWvHTk2h3psxeZoyng": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getLastURL();
},
dataType: OS.Types.Text
},
"LZAFH4mS_Eq0IIpTHzV0zw": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderAuditListSort();
},
dataType: OS.Types.Text
},
"h2IYNVOLV0ufuc1tdCV1oQ": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyCasesListSort();
},
dataType: OS.Types.Text
},
"bFmCOUXnaUGXRGtxEWh4RQ": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyCases_SearchFilter();
},
dataType: OS.Types.Text
},
"taYqZZebzEWayrkzWmgPaA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderNoteListSortDirection();
},
dataType: OS.Types.Text
},
"NHhMZRj+F0aEP3MnuBB7QA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyApprovalCasesListSort();
},
dataType: OS.Types.Text
},
"WXZWeUp40kWYQQpf_NU+bg": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderAssociatedPoliciesListSort();
},
dataType: OS.Types.Text
},
"3N_5hw9dhUOrYFd9zuln4w": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyTeamCasesListSort();
},
dataType: OS.Types.Text
},
"5Aiakj2fPUyx3eQv_s+mNA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getisAdvanceSearch();
},
dataType: OS.Types.Boolean
},
"9jCJltfRr0mV02yrpWmWWg": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderInteractionHistoryListSortDirection();
},
dataType: OS.Types.Text
},
"pOkhneOeYUeV6WwAW0cvbw": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyTeamCases_SearchFIlter();
},
dataType: OS.Types.Text
},
"S5bXpo5bOEuj2aQp2Dcj3g": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderCoverListSort();
},
dataType: OS.Types.Text
},
"UIuItuHSLU2VGJ1fZawejw": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getMyApproval_SearchFilter();
},
dataType: OS.Types.Text
},
"zsM7vwbD10mLOSWFvjOksg": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderNotesListSort();
},
dataType: OS.Types.Text
},
"C6u32lJUD0Ws8tiPzVKPAA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderNoteListSort();
},
dataType: OS.Types.Text
},
"NIqu4kqFEkCrqdhf9CkNAA": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderInteractionHistoryListSort();
},
dataType: OS.Types.Text
},
"rpSt9PRD4Uu2LjP6RcKwbg": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderAuditListSortDirection();
},
dataType: OS.Types.Text
},
"Oag8+XRFLkOPwT1uhp5nWw": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getStakeholderQuotesListSort();
},
dataType: OS.Types.Text
},
"f2iN+WM3OU+51296SxWNFw": {
getter: function (varBag, idService) {
return PHICoreClientVariables.getPolicyProgress_Int();
},
dataType: OS.Types.Integer
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
