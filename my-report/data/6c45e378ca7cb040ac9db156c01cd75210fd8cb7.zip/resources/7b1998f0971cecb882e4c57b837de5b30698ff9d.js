define("APIGateway_IS.model$PhoneNumberItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneNumberItemRec = (function (_super) {
__extends(PhoneNumberItemRec, _super);
function PhoneNumberItemRec(defaults) {
_super.apply(this, arguments);
}
PhoneNumberItemRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberItemRec.init();
return PhoneNumberItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PhoneNumberItemRec = PhoneNumberItemRec;

});
define("APIGateway_IS.model$CardItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CardItem2Rec = (function (_super) {
__extends(CardItem2Rec, _super);
function CardItem2Rec(defaults) {
_super.apply(this, arguments);
}
CardItem2Rec.attributesToDeclare = function () {
return [
this.attr("TypeCode", "typeCodeAttr", "typeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CardNumber", "cardNumberAttr", "cardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardItem2Rec.init();
return CardItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CardItem2Rec = CardItem2Rec;

});
define("APIGateway_IS.model$RoleItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RoleItemRec = (function (_super) {
__extends(RoleItemRec, _super);
function RoleItemRec(defaults) {
_super.apply(this, arguments);
}
RoleItemRec.attributesToDeclare = function () {
return [
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EndDate", "endDateAttr", "endDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RoleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RoleItemRec.init();
return RoleItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RoleItemRec = RoleItemRec;

});
define("APIGateway_IS.model$RoleItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RoleItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RoleItemList = (function (_super) {
__extends(RoleItemList, _super);
function RoleItemList(defaults) {
_super.apply(this, arguments);
}
RoleItemList.itemType = APIGateway_ISModel.RoleItemRec;
return RoleItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.RoleItemList = RoleItemList;

});
define("APIGateway_IS.model$LhcDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var LhcDetailRec = (function (_super) {
__extends(LhcDetailRec, _super);
function LhcDetailRec(defaults) {
_super.apply(this, arguments);
}
LhcDetailRec.attributesToDeclare = function () {
return [
this.attr("LhcExempt", "lhcExemptAttr", "lhcExempt", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcOverride", "lhcOverrideAttr", "lhcOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PaidHospitalDays", "paidHospitalDaysAttr", "paidHospitalDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LhcDetailRec.init();
return LhcDetailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.LhcDetailRec = LhcDetailRec;

});
define("APIGateway_IS.model$WaitingPeriodItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var WaitingPeriodItem2Rec = (function (_super) {
__extends(WaitingPeriodItem2Rec, _super);
function WaitingPeriodItem2Rec(defaults) {
_super.apply(this, arguments);
}
WaitingPeriodItem2Rec.attributesToDeclare = function () {
return [
this.attr("WaitPeriod", "waitPeriodAttr", "waitPeriod", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitPeriodCode", "waitPeriodCodeAttr", "waitPeriodCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonForVariation", "reasonForVariationAttr", "reasonForVariation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonForVariationCode", "reasonForVariationCodeAttr", "reasonForVariationCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
WaitingPeriodItem2Rec.init();
return WaitingPeriodItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.WaitingPeriodItem2Rec = WaitingPeriodItem2Rec;

});
define("APIGateway_IS.model$WaitingPeriodItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$WaitingPeriodItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var WaitingPeriodItem2List = (function (_super) {
__extends(WaitingPeriodItem2List, _super);
function WaitingPeriodItem2List(defaults) {
_super.apply(this, arguments);
}
WaitingPeriodItem2List.itemType = APIGateway_ISModel.WaitingPeriodItem2Rec;
return WaitingPeriodItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.WaitingPeriodItem2List = WaitingPeriodItem2List;

});
define("APIGateway_IS.model$RevisionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$LhcDetailRec", "APIGateway_IS.model$WaitingPeriodItem2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RevisionItemRec = (function (_super) {
__extends(RevisionItemRec, _super);
function RevisionItemRec(defaults) {
_super.apply(this, arguments);
}
RevisionItemRec.attributesToDeclare = function () {
return [
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LhcDetails", "lhcDetailsAttr", "lhcDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LhcDetailRec());
}, true, APIGateway_ISModel.LhcDetailRec), 
this.attr("PeaOverride", "peaOverrideAttr", "peaOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Relationship", "relationshipAttr", "relationship", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CoverForMember", "coverForMemberAttr", "coverForMember", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitingPeriods", "waitingPeriodsAttr", "waitingPeriods", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.WaitingPeriodItem2List());
}, true, APIGateway_ISModel.WaitingPeriodItem2List), 
this.attr("RelationshipCode", "relationshipCodeAttr", "relationshipCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SuspensionReason", "suspensionReasonAttr", "suspensionReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DependantOverride", "dependantOverrideAttr", "dependantOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("SuspensionEndDate", "suspensionEndDateAttr", "suspensionEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TerminationReason", "terminationReasonAttr", "terminationReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DisabilityOverride", "disabilityOverrideAttr", "disabilityOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("SuspensionReasonCode", "suspensionReasonCodeAttr", "suspensionReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationReasonCode", "terminationReasonCodeAttr", "terminationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyMemberRevisionId", "policyMemberRevisionIdAttr", "policyMemberRevisionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RevisionItemRec.init();
return RevisionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RevisionItemRec = RevisionItemRec;

});
define("APIGateway_IS.model$RevisionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RevisionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RevisionItemList = (function (_super) {
__extends(RevisionItemList, _super);
function RevisionItemList(defaults) {
_super.apply(this, arguments);
}
RevisionItemList.itemType = APIGateway_ISModel.RevisionItemRec;
return RevisionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.RevisionItemList = RevisionItemList;

});
define("APIGateway_IS.model$PolicyMemberItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RoleItemList", "APIGateway_IS.model$RevisionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMemberItem2Rec = (function (_super) {
__extends(PolicyMemberItem2Rec, _super);
function PolicyMemberItem2Rec(defaults) {
_super.apply(this, arguments);
}
PolicyMemberItem2Rec.attributesToDeclare = function () {
return [
this.attr("Roles", "rolesAttr", "roles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RoleItemList());
}, true, APIGateway_ISModel.RoleItemList), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsPrivate", "isPrivateAttr", "isPrivate", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsStudent", "isStudentAttr", "isStudent", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Revisions", "revisionsAttr", "revisions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RevisionItemList());
}, true, APIGateway_ISModel.RevisionItemList), 
this.attr("AgeWarning", "ageWarningAttr", "ageWarning", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AbdEntryAge", "abdEntryAgeAttr", "abdEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("HospitalWaitExemptionUsedDate", "hospitalWaitExemptionUsedDateAttr", "hospitalWaitExemptionUsedDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyMemberItem2Rec.init();
return PolicyMemberItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyMemberItem2Rec = PolicyMemberItem2Rec;

});
define("APIGateway_IS.model$PolicyMemberItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMemberItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMemberItem2List = (function (_super) {
__extends(PolicyMemberItem2List, _super);
function PolicyMemberItem2List(defaults) {
_super.apply(this, arguments);
}
PolicyMemberItem2List.itemType = APIGateway_ISModel.PolicyMemberItem2Rec;
return PolicyMemberItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyMemberItem2List = PolicyMemberItem2List;

});
define("APIGateway_IS.model$PolicyMembers_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMemberItem2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMembers_APIRec = (function (_super) {
__extends(PolicyMembers_APIRec, _super);
function PolicyMembers_APIRec(defaults) {
_super.apply(this, arguments);
}
PolicyMembers_APIRec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PolicyMembers", "policyMembersAttr", "policyMembers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyMemberItem2List());
}, true, APIGateway_ISModel.PolicyMemberItem2List)
].concat(_super.attributesToDeclare.call(this));
};
PolicyMembers_APIRec.init();
return PolicyMembers_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyMembers_APIRec = PolicyMembers_APIRec;

});
define("APIGateway_IS.model$PHIStakeholderSearchRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchRequestRec = (function (_super) {
__extends(PHIStakeholderSearchRequestRec, _super);
function PHIStakeholderSearchRequestRec(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchRequestRec.attributesToDeclare = function () {
return [
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("search", "searchAttr", "search", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("phone", "phoneAttr", "phone", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("email", "emailAttr", "email", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("address", "addressAttr", "address", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderSearchRequestRec.init();
return PHIStakeholderSearchRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIStakeholderSearchRequestRec = PHIStakeholderSearchRequestRec;

});
define("APIGateway_IS.model$PolicyEligibilityReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyEligibilityReasonRec = (function (_super) {
__extends(PolicyEligibilityReasonRec, _super);
function PolicyEligibilityReasonRec(defaults) {
_super.apply(this, arguments);
}
PolicyEligibilityReasonRec.attributesToDeclare = function () {
return [
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonCode", "reasonCodeAttr", "reasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SubReasonCode", "subReasonCodeAttr", "subReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Reason", "reasonAttr", "reason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubReason", "subReasonAttr", "subReason", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyEligibilityReasonRec.init();
return PolicyEligibilityReasonRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyEligibilityReasonRec = PolicyEligibilityReasonRec;

});
define("APIGateway_IS.model$AddAttachmentItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddAttachmentItemRec = (function (_super) {
__extends(AddAttachmentItemRec, _super);
function AddAttachmentItemRec(defaults) {
_super.apply(this, arguments);
}
AddAttachmentItemRec.attributesToDeclare = function () {
return [
this.attr("Base64", "base64Attr", "base64", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FileName", "fileNameAttr", "fileName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddAttachmentItemRec.init();
return AddAttachmentItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddAttachmentItemRec = AddAttachmentItemRec;

});
define("APIGateway_IS.model$PolicyRebateRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRebateRec = (function (_super) {
__extends(PolicyRebateRec, _super);
function PolicyRebateRec(defaults) {
_super.apply(this, arguments);
}
PolicyRebateRec.attributesToDeclare = function () {
return [
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateAction", "rebateActionAttr", "rebateAction", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PremiumAmount", "premiumAmountAttr", "premiumAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousFundCode", "previousFundCodeAttr", "previousFundCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReprocessReceipts", "reprocessReceiptsAttr", "reprocessReceipts", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousPolicyNumber", "previousPolicyNumberAttr", "previousPolicyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousFund", "previousFundAttr", "previousFund", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RelinkProcessDecision", "relinkProcessDecisionAttr", "relinkProcessDecision", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EndDate", "endDateAttr", "endDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRebateRec.init();
return PolicyRebateRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyRebateRec = PolicyRebateRec;

});
define("APIGateway_IS.model$PHI_EntityFlag_RecordRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_EntityFlag_RecordRec = (function (_super) {
__extends(PHI_EntityFlag_RecordRec, _super);
function PHI_EntityFlag_RecordRec(defaults) {
_super.apply(this, arguments);
}
PHI_EntityFlag_RecordRec.attributesToDeclare = function () {
return [
this.attr("flagId", "flagIdAttr", "flagId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("entityId", "entityIdAttr", "entityId", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("entityType", "entityTypeAttr", "entityType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("name", "nameAttr", "name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("expiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("status", "statusAttr", "status", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHI_EntityFlag_RecordRec.init();
return PHI_EntityFlag_RecordRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHI_EntityFlag_RecordRec = PHI_EntityFlag_RecordRec;

});
define("APIGateway_IS.model$PolicyRoleItemV2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItemV2Rec = (function (_super) {
__extends(PolicyRoleItemV2Rec, _super);
function PolicyRoleItemV2Rec(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItemV2Rec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsCoverVariation", "isCoverVariationAttr", "isCoverVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRoleItemV2Rec.init();
return PolicyRoleItemV2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyRoleItemV2Rec = PolicyRoleItemV2Rec;

});
define("APIGateway_IS.model$PolicyRoleItemV2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItemV2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItemV2List = (function (_super) {
__extends(PolicyRoleItemV2List, _super);
function PolicyRoleItemV2List(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItemV2List.itemType = APIGateway_ISModel.PolicyRoleItemV2Rec;
return PolicyRoleItemV2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyRoleItemV2List = PolicyRoleItemV2List;

});
define("APIGateway_IS.model$IndividualPolicyRoles_ResponseV2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItemV2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualPolicyRoles_ResponseV2Rec = (function (_super) {
__extends(IndividualPolicyRoles_ResponseV2Rec, _super);
function IndividualPolicyRoles_ResponseV2Rec(defaults) {
_super.apply(this, arguments);
}
IndividualPolicyRoles_ResponseV2Rec.attributesToDeclare = function () {
return [
this.attr("PolicyRoles", "policyRolesAttr", "policyRoles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRoleItemV2List());
}, true, APIGateway_ISModel.PolicyRoleItemV2List)
].concat(_super.attributesToDeclare.call(this));
};
IndividualPolicyRoles_ResponseV2Rec.fromStructure = function (str) {
return new IndividualPolicyRoles_ResponseV2Rec(new IndividualPolicyRoles_ResponseV2Rec.RecordClass({
policyRolesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IndividualPolicyRoles_ResponseV2Rec.init();
return IndividualPolicyRoles_ResponseV2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.IndividualPolicyRoles_ResponseV2Rec = IndividualPolicyRoles_ResponseV2Rec;

});
define("APIGateway_IS.model$PHIMedicareCardRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIMedicareCardRec = (function (_super) {
__extends(PHIMedicareCardRec, _super);
function PHIMedicareCardRec(defaults) {
_super.apply(this, arguments);
}
PHIMedicareCardRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("medicareCardNumber", "medicareCardNumberAttr", "medicareCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("medicareCardIrn", "medicareCardIrnAttr", "medicareCardIrn", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("expiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("firstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("secondName", "secondNameAttr", "secondName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("lastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIMedicareCardRec.init();
return PHIMedicareCardRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIMedicareCardRec = PHIMedicareCardRec;

});
define("APIGateway_IS.model$EntityPropertyRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityPropertyRec = (function (_super) {
__extends(EntityPropertyRec, _super);
function EntityPropertyRec(defaults) {
_super.apply(this, arguments);
}
EntityPropertyRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Field", "fieldAttr", "field", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Required", "requiredAttr", "required", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("MaxLength", "maxLengthAttr", "maxLength", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("MinLength", "minLengthAttr", "minLength", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Pattern", "patternAttr", "pattern", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Visible", "visibleAttr", "visible", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LookupRefEntity", "lookupRefEntityAttr", "lookupRefEntity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DefaultValue", "defaultValueAttr", "defaultValue", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityPropertyRec.init();
return EntityPropertyRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityPropertyRec = EntityPropertyRec;

});
define("APIGateway_IS.model$PolicyRoleItem3Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem3Rec = (function (_super) {
__extends(PolicyRoleItem3Rec, _super);
function PolicyRoleItem3Rec(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem3Rec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsCoverVariation", "isCoverVariationAttr", "isCoverVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRoleItem3Rec.init();
return PolicyRoleItem3Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyRoleItem3Rec = PolicyRoleItem3Rec;

});
define("APIGateway_IS.model$PolicyRoleItem3List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItem3Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem3List = (function (_super) {
__extends(PolicyRoleItem3List, _super);
function PolicyRoleItem3List(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem3List.itemType = APIGateway_ISModel.PolicyRoleItem3Rec;
return PolicyRoleItem3List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyRoleItem3List = PolicyRoleItem3List;

});
define("APIGateway_IS.model$PhoneItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneItem2Rec = (function (_super) {
__extends(PhoneItem2Rec, _super);
function PhoneItem2Rec(defaults) {
_super.apply(this, arguments);
}
PhoneItem2Rec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PhoneItem2Rec.init();
return PhoneItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PhoneItem2Rec = PhoneItem2Rec;

});
define("APIGateway_IS.model$PhoneItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PhoneItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneItem2List = (function (_super) {
__extends(PhoneItem2List, _super);
function PhoneItem2List(defaults) {
_super.apply(this, arguments);
}
PhoneItem2List.itemType = APIGateway_ISModel.PhoneItem2Rec;
return PhoneItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PhoneItem2List = PhoneItem2List;

});
define("APIGateway_IS.model$EmailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailRec = (function (_super) {
__extends(EmailRec, _super);
function EmailRec(defaults) {
_super.apply(this, arguments);
}
EmailRec.attributesToDeclare = function () {
return [
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EmailRec.init();
return EmailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EmailRec = EmailRec;

});
define("APIGateway_IS.model$AddressItem3Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItem3Rec = (function (_super) {
__extends(AddressItem3Rec, _super);
function AddressItem3Rec(defaults) {
_super.apply(this, arguments);
}
AddressItem3Rec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Address", "addressAttr", "address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DeliveryPointId", "deliveryPointIdAttr", "deliveryPointId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddressItem3Rec.init();
return AddressItem3Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddressItem3Rec = AddressItem3Rec;

});
define("APIGateway_IS.model$AddressItem3List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddressItem3Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItem3List = (function (_super) {
__extends(AddressItem3List, _super);
function AddressItem3List(defaults) {
_super.apply(this, arguments);
}
AddressItem3List.itemType = APIGateway_ISModel.AddressItem3Rec;
return AddressItem3List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddressItem3List = AddressItem3List;

});
define("APIGateway_IS.model$FlagItem3Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItem3Rec = (function (_super) {
__extends(FlagItem3Rec, _super);
function FlagItem3Rec(defaults) {
_super.apply(this, arguments);
}
FlagItem3Rec.attributesToDeclare = function () {
return [
this.attr("FlagCode", "flagCodeAttr", "flagCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagType", "flagTypeAttr", "flagType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "isRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlagItem3Rec.init();
return FlagItem3Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.FlagItem3Rec = FlagItem3Rec;

});
define("APIGateway_IS.model$FlagItem3List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$FlagItem3Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItem3List = (function (_super) {
__extends(FlagItem3List, _super);
function FlagItem3List(defaults) {
_super.apply(this, arguments);
}
FlagItem3List.itemType = APIGateway_ISModel.FlagItem3Rec;
return FlagItem3List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.FlagItem3List = FlagItem3List;

});
define("APIGateway_IS.model$ResultItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItem3List", "APIGateway_IS.model$PhoneItem2List", "APIGateway_IS.model$EmailRec", "APIGateway_IS.model$AddressItem3List", "APIGateway_IS.model$FlagItem3List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItemRec = (function (_super) {
__extends(ResultItemRec, _super);
function ResultItemRec(defaults) {
_super.apply(this, arguments);
}
ResultItemRec.attributesToDeclare = function () {
return [
this.attr("StakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsContributor", "isContributorAttr", "isContributor", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDelegatedAuthority", "isDelegatedAuthorityAttr", "isDelegatedAuthority", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Relevance", "relevanceAttr", "relevance", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderStatus", "stakeholderStatusAttr", "stakeholderStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyRoles", "policyRolesAttr", "policyRoles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRoleItem3List());
}, true, APIGateway_ISModel.PolicyRoleItem3List), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneItem2List());
}, true, APIGateway_ISModel.PhoneItem2List), 
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailRec());
}, true, APIGateway_ISModel.EmailRec), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItem3List());
}, true, APIGateway_ISModel.AddressItem3List), 
this.attr("Flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FlagItem3List());
}, true, APIGateway_ISModel.FlagItem3List), 
this.attr("ResultType", "resultTypeAttr", "resultType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ResultId", "resultIdAttr", "resultId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResultItemRec.init();
return ResultItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResultItemRec = ResultItemRec;

});
define("APIGateway_IS.model$ResultItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItemList = (function (_super) {
__extends(ResultItemList, _super);
function ResultItemList(defaults) {
_super.apply(this, arguments);
}
ResultItemList.itemType = APIGateway_ISModel.ResultItemRec;
return ResultItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ResultItemList = ResultItemList;

});
define("APIGateway_IS.model$SearchResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchResponseRec = (function (_super) {
__extends(SearchResponseRec, _super);
function SearchResponseRec(defaults) {
_super.apply(this, arguments);
}
SearchResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ResultItemList());
}, true, APIGateway_ISModel.ResultItemList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchResponseRec.init();
return SearchResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchResponseRec = SearchResponseRec;

});
define("APIGateway_IS.model$PHIValidationProblemDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIValidationProblemDetailsRec = (function (_super) {
__extends(PHIValidationProblemDetailsRec, _super);
function PHIValidationProblemDetailsRec(defaults) {
_super.apply(this, arguments);
}
PHIValidationProblemDetailsRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("status", "statusAttr", "status", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("detail", "detailAttr", "detail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("instance", "instanceAttr", "instance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("errors", "errorsAttr", "errors", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("traceId", "traceIdAttr", "traceId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("errorCode", "errorCodeAttr", "errorCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIValidationProblemDetailsRec.init();
return PHIValidationProblemDetailsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIValidationProblemDetailsRec = PHIValidationProblemDetailsRec;

});
define("APIGateway_IS.model$PHIProblemDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIProblemDetailsRec = (function (_super) {
__extends(PHIProblemDetailsRec, _super);
function PHIProblemDetailsRec(defaults) {
_super.apply(this, arguments);
}
PHIProblemDetailsRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("status", "statusAttr", "status", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("detail", "detailAttr", "detail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("instance", "instanceAttr", "instance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("traceId", "traceIdAttr", "traceId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("errorCode", "errorCodeAttr", "errorCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIProblemDetailsRec.init();
return PHIProblemDetailsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIProblemDetailsRec = PHIProblemDetailsRec;

});
define("APIGateway_IS.model$PHIProblemDetailsValidationProblemDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIProblemDetailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIProblemDetailsValidationProblemDetailsRec = (function (_super) {
__extends(PHIProblemDetailsValidationProblemDetailsRec, _super);
function PHIProblemDetailsValidationProblemDetailsRec(defaults) {
_super.apply(this, arguments);
}
PHIProblemDetailsValidationProblemDetailsRec.attributesToDeclare = function () {
return [
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIProblemDetailsValidationProblemDetailsRec.init();
return PHIProblemDetailsValidationProblemDetailsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIProblemDetailsValidationProblemDetailsRec = PHIProblemDetailsValidationProblemDetailsRec;

});
define("APIGateway_IS.model$NoteItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var NoteItemRec = (function (_super) {
__extends(NoteItemRec, _super);
function NoteItemRec(defaults) {
_super.apply(this, arguments);
}
NoteItemRec.attributesToDeclare = function () {
return [
this.attr("Note", "noteAttr", "note", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Subject", "subjectAttr", "subject", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("NoteTypeCode", "noteTypeCodeAttr", "noteTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
NoteItemRec.init();
return NoteItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.NoteItemRec = NoteItemRec;

});
define("APIGateway_IS.model$PHICancelLead_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICancelLead_RequestRec = (function (_super) {
__extends(PHICancelLead_RequestRec, _super);
function PHICancelLead_RequestRec(defaults) {
_super.apply(this, arguments);
}
PHICancelLead_RequestRec.attributesToDeclare = function () {
return [
this.attr("cancellationReasonCode", "cancellationReasonCodeAttr", "cancellationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICancelLead_RequestRec.fromStructure = function (str) {
return new PHICancelLead_RequestRec(new PHICancelLead_RequestRec.RecordClass({
cancellationReasonCodeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHICancelLead_RequestRec.init();
return PHICancelLead_RequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICancelLead_RequestRec = PHICancelLead_RequestRec;

});
define("APIGateway_IS.model$TillItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TillItemRec = (function (_super) {
__extends(TillItemRec, _super);
function TillItemRec(defaults) {
_super.apply(this, arguments);
}
TillItemRec.attributesToDeclare = function () {
return [
this.attr("TillCode", "tillCodeAttr", "tillCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuthorityLevel", "authorityLevelAttr", "authorityLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TillItemRec.init();
return TillItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.TillItemRec = TillItemRec;

});
define("APIGateway_IS.model$EntityFlagItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityFlagItemRec = (function (_super) {
__extends(EntityFlagItemRec, _super);
function EntityFlagItemRec(defaults) {
_super.apply(this, arguments);
}
EntityFlagItemRec.attributesToDeclare = function () {
return [
this.attr("FlagId", "flagIdAttr", "flagId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("FlagCode", "flagCodeAttr", "flagCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagType", "flagTypeAttr", "flagType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "isRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityFlagItemRec.init();
return EntityFlagItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityFlagItemRec = EntityFlagItemRec;

});
define("APIGateway_IS.model$EntityFlagItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityFlagItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityFlagItemList = (function (_super) {
__extends(EntityFlagItemList, _super);
function EntityFlagItemList(defaults) {
_super.apply(this, arguments);
}
EntityFlagItemList.itemType = APIGateway_ISModel.EntityFlagItemRec;
return EntityFlagItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EntityFlagItemList = EntityFlagItemList;

});
define("APIGateway_IS.model$GetEntityFlags_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityFlagItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetEntityFlags_APIResponseRec = (function (_super) {
__extends(GetEntityFlags_APIResponseRec, _super);
function GetEntityFlags_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetEntityFlags_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityFlagItemList());
}, true, APIGateway_ISModel.EntityFlagItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetEntityFlags_APIResponseRec.fromStructure = function (str) {
return new GetEntityFlags_APIResponseRec(new GetEntityFlags_APIResponseRec.RecordClass({
flagsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetEntityFlags_APIResponseRec.init();
return GetEntityFlags_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetEntityFlags_APIResponseRec = GetEntityFlags_APIResponseRec;

});
define("APIGateway_IS.model$EntityPropertyList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityPropertyRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityPropertyList = (function (_super) {
__extends(EntityPropertyList, _super);
function EntityPropertyList(defaults) {
_super.apply(this, arguments);
}
EntityPropertyList.itemType = APIGateway_ISModel.EntityPropertyRec;
return EntityPropertyList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EntityPropertyList = EntityPropertyList;

});
define("APIGateway_IS.model$EntityActiveRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityActiveRec = (function (_super) {
__extends(EntityActiveRec, _super);
function EntityActiveRec(defaults) {
_super.apply(this, arguments);
}
EntityActiveRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Field", "fieldAttr", "field", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReadOnly", "readOnlyAttr", "readOnly", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("DefaultValue", "defaultValueAttr", "defaultValue", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityActiveRec.init();
return EntityActiveRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityActiveRec = EntityActiveRec;

});
define("APIGateway_IS.model$EntityPriorityRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityPriorityRec = (function (_super) {
__extends(EntityPriorityRec, _super);
function EntityPriorityRec(defaults) {
_super.apply(this, arguments);
}
EntityPriorityRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Field", "fieldAttr", "field", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Minimum", "minimumAttr", "minimum", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Label", "labelAttr", "label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Required", "requiredAttr", "required", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityPriorityRec.init();
return EntityPriorityRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityPriorityRec = EntityPriorityRec;

});
define("APIGateway_IS.model$EntityItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityPropertyRec", "APIGateway_IS.model$EntityPropertyList", "APIGateway_IS.model$EntityActiveRec", "APIGateway_IS.model$EntityPriorityRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityItemRec = (function (_super) {
__extends(EntityItemRec, _super);
function EntityItemRec(defaults) {
_super.apply(this, arguments);
}
EntityItemRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityPropertyRec());
}, true, APIGateway_ISModel.EntityPropertyRec), 
this.attr("Label", "labelAttr", "label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Entity", "entityAttr", "entity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Visible", "visibleAttr", "visible", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("FixedList", "fixedListAttr", "fixedList", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Properties", "propertiesAttr", "properties", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityPropertyList());
}, true, APIGateway_ISModel.EntityPropertyList), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityPropertyRec());
}, true, APIGateway_ISModel.EntityPropertyRec), 
this.attr("Active", "activeAttr", "active", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityActiveRec());
}, true, APIGateway_ISModel.EntityActiveRec), 
this.attr("Priority", "priorityAttr", "priority", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityPriorityRec());
}, true, APIGateway_ISModel.EntityPriorityRec), 
this.attr("ParentEntity", "parentEntityAttr", "parentEntity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ParentEntityCode", "parentEntityCodeAttr", "parentEntityCode", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityPropertyRec());
}, true, APIGateway_ISModel.EntityPropertyRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityItemRec.init();
return EntityItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityItemRec = EntityItemRec;

});
define("APIGateway_IS.model$EntityItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityItemList = (function (_super) {
__extends(EntityItemList, _super);
function EntityItemList(defaults) {
_super.apply(this, arguments);
}
EntityItemList.itemType = APIGateway_ISModel.EntityItemRec;
return EntityItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EntityItemList = EntityItemList;

});
define("APIGateway_IS.model$GetReferenceSchemas_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetReferenceSchemas_APIResponseRec = (function (_super) {
__extends(GetReferenceSchemas_APIResponseRec, _super);
function GetReferenceSchemas_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetReferenceSchemas_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Entities", "entitiesAttr", "entities", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityItemList());
}, true, APIGateway_ISModel.EntityItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetReferenceSchemas_APIResponseRec.fromStructure = function (str) {
return new GetReferenceSchemas_APIResponseRec(new GetReferenceSchemas_APIResponseRec.RecordClass({
entitiesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetReferenceSchemas_APIResponseRec.init();
return GetReferenceSchemas_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetReferenceSchemas_APIResponseRec = GetReferenceSchemas_APIResponseRec;

});
define("APIGateway_IS.model$PHILeadAddressRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadAddressRec = (function (_super) {
__extends(PHILeadAddressRec, _super);
function PHILeadAddressRec(defaults) {
_super.apply(this, arguments);
}
PHILeadAddressRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("effectiveDate", "effectiveDateAttr", "effectiveDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("line1", "line1Attr", "line1", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("countryCode", "countryCodeAttr", "countryCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("city", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("zipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadAddressRec.init();
return PHILeadAddressRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadAddressRec = PHILeadAddressRec;

});
define("APIGateway_IS.model$TerminatePolicyMembers_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TerminatePolicyMembers_APIRequestRec = (function (_super) {
__extends(TerminatePolicyMembers_APIRequestRec, _super);
function TerminatePolicyMembers_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
TerminatePolicyMembers_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("TerminateCards", "terminateCardsAttr", "terminateCards", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ReprocessReceipts", "reprocessReceiptsAttr", "reprocessReceipts", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("TerminationReason", "terminationReasonAttr", "terminationReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddSavingsEntitlement", "addSavingsEntitlementAttr", "addSavingsEntitlement", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("TerminationReasonCode", "terminationReasonCodeAttr", "terminationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ApplyLhcLoadingDueToAbsence", "applyLhcLoadingDueToAbsenceAttr", "applyLhcLoadingDueToAbsence", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ClearanceCertificateOnTermination", "clearanceCertificateOnTerminationAttr", "clearanceCertificateOnTermination", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TerminatePolicyMembers_APIRequestRec.init();
return TerminatePolicyMembers_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.TerminatePolicyMembers_APIRequestRec = TerminatePolicyMembers_APIRequestRec;

});
define("APIGateway_IS.model$ResultItem_AuditRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_AuditRec = (function (_super) {
__extends(ResultItem_AuditRec, _super);
function ResultItem_AuditRec(defaults) {
_super.apply(this, arguments);
}
ResultItem_AuditRec.attributesToDeclare = function () {
return [
this.attr("EntityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditType", "auditTypeAttr", "auditType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChangedBy", "changedByAttr", "changedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AfterValue", "afterValueAttr", "afterValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditAction", "auditActionAttr", "auditAction", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BeforeValue", "beforeValueAttr", "beforeValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditTypeCode", "auditTypeCodeAttr", "auditTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AuditHistoryId", "auditHistoryIdAttr", "auditHistoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResultItem_AuditRec.init();
return ResultItem_AuditRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResultItem_AuditRec = ResultItem_AuditRec;

});
define("APIGateway_IS.model$Policy_PatchItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Policy_PatchItemRec = (function (_super) {
__extends(Policy_PatchItemRec, _super);
function Policy_PatchItemRec(defaults) {
_super.apply(this, arguments);
}
Policy_PatchItemRec.attributesToDeclare = function () {
return [
this.attr("Op", "opAttr", "op", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Path", "pathAttr", "path", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Policy_PatchItemRec.init();
return Policy_PatchItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Policy_PatchItemRec = Policy_PatchItemRec;

});
define("APIGateway_IS.model$Policy_PatchItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Policy_PatchItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Policy_PatchItemList = (function (_super) {
__extends(Policy_PatchItemList, _super);
function Policy_PatchItemList(defaults) {
_super.apply(this, arguments);
}
Policy_PatchItemList.itemType = APIGateway_ISModel.Policy_PatchItemRec;
return Policy_PatchItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Policy_PatchItemList = Policy_PatchItemList;

});
define("APIGateway_IS.model$Policy_PatchRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Policy_PatchItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Policy_PatchRec = (function (_super) {
__extends(Policy_PatchRec, _super);
function Policy_PatchRec(defaults) {
_super.apply(this, arguments);
}
Policy_PatchRec.attributesToDeclare = function () {
return [
this.attr("Items", "itemsAttr", "items", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Policy_PatchItemList());
}, true, APIGateway_ISModel.Policy_PatchItemList)
].concat(_super.attributesToDeclare.call(this));
};
Policy_PatchRec.fromStructure = function (str) {
return new Policy_PatchRec(new Policy_PatchRec.RecordClass({
itemsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Policy_PatchRec.init();
return Policy_PatchRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Policy_PatchRec = Policy_PatchRec;

});
define("APIGateway_IS.model$SiteItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SiteItemRec = (function (_super) {
__extends(SiteItemRec, _super);
function SiteItemRec(defaults) {
_super.apply(this, arguments);
}
SiteItemRec.attributesToDeclare = function () {
return [
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Site", "siteAttr", "site", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsDefault", "isDefaultAttr", "isDefault", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SiteItemRec.init();
return SiteItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SiteItemRec = SiteItemRec;

});
define("APIGateway_IS.model$SiteItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SiteItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SiteItemList = (function (_super) {
__extends(SiteItemList, _super);
function SiteItemList(defaults) {
_super.apply(this, arguments);
}
SiteItemList.itemType = APIGateway_ISModel.SiteItemRec;
return SiteItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.SiteItemList = SiteItemList;

});
define("APIGateway_IS.model$ResultItem_LocationRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SiteItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_LocationRec = (function (_super) {
__extends(ResultItem_LocationRec, _super);
function ResultItem_LocationRec(defaults) {
_super.apply(this, arguments);
}
ResultItem_LocationRec.attributesToDeclare = function () {
return [
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Badge", "badgeAttr", "badge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Sites", "sitesAttr", "sites", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SiteItemList());
}, true, APIGateway_ISModel.SiteItemList)
].concat(_super.attributesToDeclare.call(this));
};
ResultItem_LocationRec.init();
return ResultItem_LocationRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResultItem_LocationRec = ResultItem_LocationRec;

});
define("APIGateway_IS.model$CreateIdentityRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CreateIdentityRec = (function (_super) {
__extends(CreateIdentityRec, _super);
function CreateIdentityRec(defaults) {
_super.apply(this, arguments);
}
CreateIdentityRec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DisplayName", "displayNameAttr", "displayName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MobileNo", "mobileNoAttr", "mobileNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountEnabled", "accountEnabledAttr", "accountEnabled", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CreateIdentityRec.init();
return CreateIdentityRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CreateIdentityRec = CreateIdentityRec;

});
define("APIGateway_IS.model$PolicyRoleItemV1Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItemV1Rec = (function (_super) {
__extends(PolicyRoleItemV1Rec, _super);
function PolicyRoleItemV1Rec(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItemV1Rec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ClassCode", "classCodeAttr", "classCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsCoverVariation", "isCoverVariationAttr", "isCoverVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ProductTypeCode", "productTypeCodeAttr", "productTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RoleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRoleItemV1Rec.init();
return PolicyRoleItemV1Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyRoleItemV1Rec = PolicyRoleItemV1Rec;

});
define("APIGateway_IS.model$GetPolicyContributionDetail_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyContributionDetail_APIResponseRec = (function (_super) {
__extends(GetPolicyContributionDetail_APIResponseRec, _super);
function GetPolicyContributionDetail_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyContributionDetail_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("PaidToDate", "paidToDateAttr", "paidToDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TptDate", "tptDateAttr", "tptDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ContributionDueDate", "contributionDueDateAttr", "contributionDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContributionAmount", "contributionAmountAttr", "contributionAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Balance", "balanceAttr", "balance", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("LhcLoadingPercentage", "lhcLoadingPercentageAttr", "lhcLoadingPercentage", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateAmount", "rebateAmountAttr", "rebateAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AbdPercentage", "abdPercentageAttr", "abdPercentage", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AbdAmount", "abdAmountAttr", "abdAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("BpayCrn", "bpayCrnAttr", "bpayCrn", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyContributionDetail_APIResponseRec.init();
return GetPolicyContributionDetail_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyContributionDetail_APIResponseRec = GetPolicyContributionDetail_APIResponseRec;

});
define("APIGateway_IS.model$DeleteReference_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DeleteReference_APIRequestRec = (function (_super) {
__extends(DeleteReference_APIRequestRec, _super);
function DeleteReference_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
DeleteReference_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Entity", "entityAttr", "entity", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeleteReference_APIRequestRec.init();
return DeleteReference_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.DeleteReference_APIRequestRec = DeleteReference_APIRequestRec;

});
define("APIGateway_IS.model$StudentDeclarationItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var StudentDeclarationItemRec = (function (_super) {
__extends(StudentDeclarationItemRec, _super);
function StudentDeclarationItemRec(defaults) {
_super.apply(this, arguments);
}
StudentDeclarationItemRec.attributesToDeclare = function () {
return [
this.attr("StudentDeclarationId", "studentDeclarationIdAttr", "studentDeclarationId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritory", "stateTerritoryAttr", "stateTerritory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("InstitutionCode", "institutionCodeAttr", "institutionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Institution", "institutionAttr", "institution", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartMonthYear", "startMonthYearAttr", "startMonthYear", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ErrorState", "errorStateAttr", "ErrorState", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorEducationInstitution", "errorEducationInstitutionAttr", "ErrorEducationInstitution", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorStartMonthYear", "errorStartMonthYearAttr", "ErrorStartMonthYear", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StudentDeclarationItemRec.init();
return StudentDeclarationItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.StudentDeclarationItemRec = StudentDeclarationItemRec;

});
define("APIGateway_IS.model$StudentDeclarationItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$StudentDeclarationItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var StudentDeclarationItemList = (function (_super) {
__extends(StudentDeclarationItemList, _super);
function StudentDeclarationItemList(defaults) {
_super.apply(this, arguments);
}
StudentDeclarationItemList.itemType = APIGateway_ISModel.StudentDeclarationItemRec;
return StudentDeclarationItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.StudentDeclarationItemList = StudentDeclarationItemList;

});
define("APIGateway_IS.model$StudentDeclarationsResponseListRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$StudentDeclarationItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var StudentDeclarationsResponseListRec = (function (_super) {
__extends(StudentDeclarationsResponseListRec, _super);
function StudentDeclarationsResponseListRec(defaults) {
_super.apply(this, arguments);
}
StudentDeclarationsResponseListRec.attributesToDeclare = function () {
return [
this.attr("Declarations", "declarationsAttr", "declarations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.StudentDeclarationItemList());
}, true, APIGateway_ISModel.StudentDeclarationItemList)
].concat(_super.attributesToDeclare.call(this));
};
StudentDeclarationsResponseListRec.fromStructure = function (str) {
return new StudentDeclarationsResponseListRec(new StudentDeclarationsResponseListRec.RecordClass({
declarationsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StudentDeclarationsResponseListRec.init();
return StudentDeclarationsResponseListRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.StudentDeclarationsResponseListRec = StudentDeclarationsResponseListRec;

});
define("APIGateway_IS.model$PHIEligibilityReasonRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIEligibilityReasonRec = (function (_super) {
__extends(PHIEligibilityReasonRec, _super);
function PHIEligibilityReasonRec(defaults) {
_super.apply(this, arguments);
}
PHIEligibilityReasonRec.attributesToDeclare = function () {
return [
this.attr("reasonCode", "reasonCodeAttr", "reasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("subReasonCode", "subReasonCodeAttr", "subReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("effectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIEligibilityReasonRec.init();
return PHIEligibilityReasonRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIEligibilityReasonRec = PHIEligibilityReasonRec;

});
define("APIGateway_IS.model$PHIinterestLevelRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIinterestLevelRec = (function (_super) {
__extends(PHIinterestLevelRec, _super);
function PHIinterestLevelRec(defaults) {
_super.apply(this, arguments);
}
PHIinterestLevelRec.attributesToDeclare = function () {
return [
this.attr("entryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("interestLevelCode", "interestLevelCodeAttr", "interestLevelCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isFollowUp", "isFollowUpAttr", "isFollowUp", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("followUpDueDate", "followUpDueDateAttr", "followUpDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIinterestLevelRec.init();
return PHIinterestLevelRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIinterestLevelRec = PHIinterestLevelRec;

});
define("APIGateway_IS.model$PHILeadPhoneRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadPhoneRec = (function (_super) {
__extends(PHILeadPhoneRec, _super);
function PHILeadPhoneRec(defaults) {
_super.apply(this, arguments);
}
PHILeadPhoneRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("phoneNumber", "phoneNumberAttr", "phoneNumber", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadPhoneRec.init();
return PHILeadPhoneRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadPhoneRec = PHILeadPhoneRec;

});
define("APIGateway_IS.model$PHILeadPhoneList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadPhoneRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadPhoneList = (function (_super) {
__extends(PHILeadPhoneList, _super);
function PHILeadPhoneList(defaults) {
_super.apply(this, arguments);
}
PHILeadPhoneList.itemType = APIGateway_ISModel.PHILeadPhoneRec;
return PHILeadPhoneList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadPhoneList = PHILeadPhoneList;

});
define("APIGateway_IS.model$PHILeadEmailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadEmailRec = (function (_super) {
__extends(PHILeadEmailRec, _super);
function PHILeadEmailRec(defaults) {
_super.apply(this, arguments);
}
PHILeadEmailRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("emailAddress", "emailAddressAttr", "emailAddress", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadEmailRec.init();
return PHILeadEmailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadEmailRec = PHILeadEmailRec;

});
define("APIGateway_IS.model$PHILeadEmailList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadEmailRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadEmailList = (function (_super) {
__extends(PHILeadEmailList, _super);
function PHILeadEmailList(defaults) {
_super.apply(this, arguments);
}
PHILeadEmailList.itemType = APIGateway_ISModel.PHILeadEmailRec;
return PHILeadEmailList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadEmailList = PHILeadEmailList;

});
define("APIGateway_IS.model$PHILeadAddressList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadAddressRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadAddressList = (function (_super) {
__extends(PHILeadAddressList, _super);
function PHILeadAddressList(defaults) {
_super.apply(this, arguments);
}
PHILeadAddressList.itemType = APIGateway_ISModel.PHILeadAddressRec;
return PHILeadAddressList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadAddressList = PHILeadAddressList;

});
define("APIGateway_IS.model$PHILeadCommunicationPreferenceRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadCommunicationPreferenceRec = (function (_super) {
__extends(PHILeadCommunicationPreferenceRec, _super);
function PHILeadCommunicationPreferenceRec(defaults) {
_super.apply(this, arguments);
}
PHILeadCommunicationPreferenceRec.attributesToDeclare = function () {
return [
this.attr("categoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isSendCommunications", "isSendCommunicationsAttr", "isSendCommunications", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("isMandatory", "isMandatoryAttr", "isMandatory", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("preferredChannel", "preferredChannelAttr", "preferredChannel", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadCommunicationPreferenceRec.init();
return PHILeadCommunicationPreferenceRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadCommunicationPreferenceRec = PHILeadCommunicationPreferenceRec;

});
define("APIGateway_IS.model$PHILeadAssociationRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadAssociationRec = (function (_super) {
__extends(PHILeadAssociationRec, _super);
function PHILeadAssociationRec(defaults) {
_super.apply(this, arguments);
}
PHILeadAssociationRec.attributesToDeclare = function () {
return [
this.attr("associationTypeCode", "associationTypeCodeAttr", "associationTypeCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("associationNumber", "associationNumberAttr", "associationNumber", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("description", "descriptionAttr", "description", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadAssociationRec.init();
return PHILeadAssociationRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadAssociationRec = PHILeadAssociationRec;

});
define("APIGateway_IS.model$PHILeadAssociationList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadAssociationRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadAssociationList = (function (_super) {
__extends(PHILeadAssociationList, _super);
function PHILeadAssociationList(defaults) {
_super.apply(this, arguments);
}
PHILeadAssociationList.itemType = APIGateway_ISModel.PHILeadAssociationRec;
return PHILeadAssociationList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadAssociationList = PHILeadAssociationList;

});
define("APIGateway_IS.model$PHILeadConcessionOrOtherCardsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadConcessionOrOtherCardsRec = (function (_super) {
__extends(PHILeadConcessionOrOtherCardsRec, _super);
function PHILeadConcessionOrOtherCardsRec(defaults) {
_super.apply(this, arguments);
}
PHILeadConcessionOrOtherCardsRec.attributesToDeclare = function () {
return [
this.attr("typeCode", "typeCodeAttr", "typeCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("cardNumber", "cardNumberAttr", "cardNumber", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("expiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadConcessionOrOtherCardsRec.init();
return PHILeadConcessionOrOtherCardsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadConcessionOrOtherCardsRec = PHILeadConcessionOrOtherCardsRec;

});
define("APIGateway_IS.model$PHILeadConcessionOrOtherCardsList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadConcessionOrOtherCardsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadConcessionOrOtherCardsList = (function (_super) {
__extends(PHILeadConcessionOrOtherCardsList, _super);
function PHILeadConcessionOrOtherCardsList(defaults) {
_super.apply(this, arguments);
}
PHILeadConcessionOrOtherCardsList.itemType = APIGateway_ISModel.PHILeadConcessionOrOtherCardsRec;
return PHILeadConcessionOrOtherCardsList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadConcessionOrOtherCardsList = PHILeadConcessionOrOtherCardsList;

});
define("APIGateway_IS.model$PHILeadPreExistingConditionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadPreExistingConditionRec = (function (_super) {
__extends(PHILeadPreExistingConditionRec, _super);
function PHILeadPreExistingConditionRec(defaults) {
_super.apply(this, arguments);
}
PHILeadPreExistingConditionRec.attributesToDeclare = function () {
return [
this.attr("preExistingConditionCode", "preExistingConditionCodeAttr", "preExistingConditionCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadPreExistingConditionRec.init();
return PHILeadPreExistingConditionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadPreExistingConditionRec = PHILeadPreExistingConditionRec;

});
define("APIGateway_IS.model$PHILeadPreExistingConditionList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHILeadPreExistingConditionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadPreExistingConditionList = (function (_super) {
__extends(PHILeadPreExistingConditionList, _super);
function PHILeadPreExistingConditionList(defaults) {
_super.apply(this, arguments);
}
PHILeadPreExistingConditionList.itemType = APIGateway_ISModel.PHILeadPreExistingConditionRec;
return PHILeadPreExistingConditionList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHILeadPreExistingConditionList = PHILeadPreExistingConditionList;

});
define("APIGateway_IS.model$PHICreateLead_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIEligibilityReasonRec", "APIGateway_IS.model$PHIinterestLevelRec", "APIGateway_IS.model$PHILeadPhoneList", "APIGateway_IS.model$PHILeadEmailList", "APIGateway_IS.model$PHILeadAddressList", "APIGateway_IS.model$PHILeadCommunicationPreferenceRec", "APIGateway_IS.model$PHILeadAssociationList", "APIGateway_IS.model$PHILeadConcessionOrOtherCardsList", "APIGateway_IS.model$PHILeadPreExistingConditionList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICreateLead_RequestRec = (function (_super) {
__extends(PHICreateLead_RequestRec, _super);
function PHICreateLead_RequestRec(defaults) {
_super.apply(this, arguments);
}
PHICreateLead_RequestRec.attributesToDeclare = function () {
return [
this.attr("firstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("middleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("lastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("preferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("eligibilityReason", "eligibilityReasonAttr", "eligibilityReason", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIEligibilityReasonRec());
}, true, APIGateway_ISModel.PHIEligibilityReasonRec), 
this.attr("interestLevel", "interestLevelAttr", "interestLevel", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIinterestLevelRec());
}, true, APIGateway_ISModel.PHIinterestLevelRec), 
this.attr("phoneNumbers", "phoneNumbersAttr", "phoneNumbers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadPhoneList());
}, true, APIGateway_ISModel.PHILeadPhoneList), 
this.attr("emailAddresses", "emailAddressesAttr", "emailAddresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadEmailList());
}, true, APIGateway_ISModel.PHILeadEmailList), 
this.attr("addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadAddressList());
}, true, APIGateway_ISModel.PHILeadAddressList), 
this.attr("communicationPreference", "communicationPreferenceAttr", "communicationPreference", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadCommunicationPreferenceRec());
}, true, APIGateway_ISModel.PHILeadCommunicationPreferenceRec), 
this.attr("associations", "associationsAttr", "associations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadAssociationList());
}, true, APIGateway_ISModel.PHILeadAssociationList), 
this.attr("otherCards", "otherCardsAttr", "otherCards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadConcessionOrOtherCardsList());
}, true, APIGateway_ISModel.PHILeadConcessionOrOtherCardsList), 
this.attr("preExistingConditions", "preExistingConditionsAttr", "preExistingConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadPreExistingConditionList());
}, true, APIGateway_ISModel.PHILeadPreExistingConditionList), 
this.attr("pronounsOther", "pronounsOtherAttr", "pronounsOther", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICreateLead_RequestRec.init();
return PHICreateLead_RequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICreateLead_RequestRec = PHICreateLead_RequestRec;

});
define("APIGateway_IS.model$PolicyEligibilityReasonList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyEligibilityReasonRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyEligibilityReasonList = (function (_super) {
__extends(PolicyEligibilityReasonList, _super);
function PolicyEligibilityReasonList(defaults) {
_super.apply(this, arguments);
}
PolicyEligibilityReasonList.itemType = APIGateway_ISModel.PolicyEligibilityReasonRec;
return PolicyEligibilityReasonList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyEligibilityReasonList = PolicyEligibilityReasonList;

});
define("APIGateway_IS.model$GetPolicyEligibilityReasons_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyEligibilityReasonList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyEligibilityReasons_APIResponseRec = (function (_super) {
__extends(GetPolicyEligibilityReasons_APIResponseRec, _super);
function GetPolicyEligibilityReasons_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyEligibilityReasons_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("EligibilityReasons", "eligibilityReasonsAttr", "eligibilityReasons", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyEligibilityReasonList());
}, true, APIGateway_ISModel.PolicyEligibilityReasonList)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyEligibilityReasons_APIResponseRec.fromStructure = function (str) {
return new GetPolicyEligibilityReasons_APIResponseRec(new GetPolicyEligibilityReasons_APIResponseRec.RecordClass({
eligibilityReasonsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPolicyEligibilityReasons_APIResponseRec.init();
return GetPolicyEligibilityReasons_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyEligibilityReasons_APIResponseRec = GetPolicyEligibilityReasons_APIResponseRec;

});
define("APIGateway_IS.model$ProblemStringRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ProblemStringRec = (function (_super) {
__extends(ProblemStringRec, _super);
function ProblemStringRec(defaults) {
_super.apply(this, arguments);
}
ProblemStringRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Detail", "detailAttr", "detail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Instance", "instanceAttr", "instance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Errors", "errorsAttr", "errors", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TraceId", "traceIdAttr", "traceId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorCode", "errorCodeAttr", "errorCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProblemStringRec.init();
return ProblemStringRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ProblemStringRec = ProblemStringRec;

});
define("APIGateway_IS.model$CardItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CardItemRec = (function (_super) {
__extends(CardItemRec, _super);
function CardItemRec(defaults) {
_super.apply(this, arguments);
}
CardItemRec.attributesToDeclare = function () {
return [
this.attr("CardNumber", "cardNumberAttr", "cardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TypeCode", "typeCodeAttr", "typeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CardItemRec.init();
return CardItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CardItemRec = CardItemRec;

});
define("APIGateway_IS.model$VerifyMedicareDetails_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var VerifyMedicareDetails_APIRequestRec = (function (_super) {
__extends(VerifyMedicareDetails_APIRequestRec, _super);
function VerifyMedicareDetails_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
VerifyMedicareDetails_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SecondName", "secondNameAttr", "secondName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardIrn", "medicareCardIrnAttr", "medicareCardIrn", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("MedicareCardNumber", "medicareCardNumberAttr", "medicareCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Sex", "sexAttr", "sex", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
VerifyMedicareDetails_APIRequestRec.init();
return VerifyMedicareDetails_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.VerifyMedicareDetails_APIRequestRec = VerifyMedicareDetails_APIRequestRec;

});
define("APIGateway_IS.model$SearchStakeholderInteractions_Request_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchStakeholderInteractions_Request_APIRec = (function (_super) {
__extends(SearchStakeholderInteractions_Request_APIRec, _super);
function SearchStakeholderInteractions_Request_APIRec(defaults) {
_super.apply(this, arguments);
}
SearchStakeholderInteractions_Request_APIRec.attributesToDeclare = function () {
return [
this.attr("stakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stakeholderId", "stakeholderIdAttr", "stakeholderId", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("categoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("channel", "channelAttr", "channel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("createdBy", "createdByAttr", "createdBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dateFrom", "dateFromAttr", "dateFrom", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("dateTo", "dateToAttr", "dateTo", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("direction", "directionAttr", "direction", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("includeTotalCount", "includeTotalCountAttr", "includeTotalCount", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("subCategoryCode", "subCategoryCodeAttr", "subCategoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchStakeholderInteractions_Request_APIRec.init();
return SearchStakeholderInteractions_Request_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchStakeholderInteractions_Request_APIRec = SearchStakeholderInteractions_Request_APIRec;

});
define("APIGateway_IS.model$GetHealthFundDetails_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetHealthFundDetails_APIResponseRec = (function (_super) {
__extends(GetHealthFundDetails_APIResponseRec, _super);
function GetHealthFundDetails_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetHealthFundDetails_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("FundCode", "fundCodeAttr", "fundCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FundName", "fundNameAttr", "fundName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Abn", "abnAttr", "abn", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PrimaryContactName", "primaryContactNameAttr", "primaryContactName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Phone", "phoneAttr", "phone", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Address", "addressAttr", "address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PostCode", "postCodeAttr", "postCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetHealthFundDetails_APIResponseRec.init();
return GetHealthFundDetails_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetHealthFundDetails_APIResponseRec = GetHealthFundDetails_APIResponseRec;

});
define("APIGateway_IS.model$EmailsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailsRec = (function (_super) {
__extends(EmailsRec, _super);
function EmailsRec(defaults) {
_super.apply(this, arguments);
}
EmailsRec.attributesToDeclare = function () {
return [
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EmailsRec.init();
return EmailsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EmailsRec = EmailsRec;

});
define("APIGateway_IS.model$CommunicationPreferenceItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CommunicationPreferenceItemRec = (function (_super) {
__extends(CommunicationPreferenceItemRec, _super);
function CommunicationPreferenceItemRec(defaults) {
_super.apply(this, arguments);
}
CommunicationPreferenceItemRec.attributesToDeclare = function () {
return [
this.attr("Category", "categoryAttr", "category", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "isMandatory", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CategoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredChannel", "preferredChannelAttr", "preferredChannel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SendCommunications", "sendCommunicationsAttr", "sendCommunications", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CommunicationPreferenceItemRec.init();
return CommunicationPreferenceItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CommunicationPreferenceItemRec = CommunicationPreferenceItemRec;

});
define("APIGateway_IS.model$SuspendPolicy_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SuspendPolicy_APIRec = (function (_super) {
__extends(SuspendPolicy_APIRec, _super);
function SuspendPolicy_APIRec(defaults) {
_super.apply(this, arguments);
}
SuspendPolicy_APIRec.attributesToDeclare = function () {
return [
this.attr("SuspensionReasonCode", "suspensionReasonCodeAttr", "suspensionReasonCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SuspensionStartDate", "suspensionStartDateAttr", "suspensionStartDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SuspensionEndDate", "suspensionEndDateAttr", "suspensionEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SuspendPolicy_APIRec.init();
return SuspendPolicy_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SuspendPolicy_APIRec = SuspendPolicy_APIRec;

});
define("APIGateway_IS.model$Product_BenefitCondition_SpecialityRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_BenefitCondition_SpecialityRec = (function (_super) {
__extends(Product_BenefitCondition_SpecialityRec, _super);
function Product_BenefitCondition_SpecialityRec(defaults) {
_super.apply(this, arguments);
}
Product_BenefitCondition_SpecialityRec.attributesToDeclare = function () {
return [
this.attr("SpecialityId", "specialityIdAttr", "specialityId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("SpecialityClass", "specialityClassAttr", "specialityClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Product_BenefitCondition_SpecialityRec.init();
return Product_BenefitCondition_SpecialityRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_BenefitCondition_SpecialityRec = Product_BenefitCondition_SpecialityRec;

});
define("APIGateway_IS.model$Product_BenefitCondition_SpecialityList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_BenefitCondition_SpecialityRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_BenefitCondition_SpecialityList = (function (_super) {
__extends(Product_BenefitCondition_SpecialityList, _super);
function Product_BenefitCondition_SpecialityList(defaults) {
_super.apply(this, arguments);
}
Product_BenefitCondition_SpecialityList.itemType = APIGateway_ISModel.Product_BenefitCondition_SpecialityRec;
return Product_BenefitCondition_SpecialityList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_BenefitCondition_SpecialityList = Product_BenefitCondition_SpecialityList;

});
define("APIGateway_IS.model$Product_BenefitConditionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_BenefitCondition_SpecialityList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_BenefitConditionItemRec = (function (_super) {
__extends(Product_BenefitConditionItemRec, _super);
function Product_BenefitConditionItemRec(defaults) {
_super.apply(this, arguments);
}
Product_BenefitConditionItemRec.attributesToDeclare = function () {
return [
this.attr("BenefitConditionCode", "benefitConditionCodeAttr", "benefitConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BenefitCondition", "benefitConditionAttr", "benefitCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FundType", "fundTypeAttr", "fundType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Level", "levelAttr", "level", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RelatedBenefitConditionCode", "relatedBenefitConditionCodeAttr", "relatedBenefitConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RelatedBenefitCondition", "relatedBenefitConditionAttr", "relatedBenefitCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RelatedBenefitConditionEffDate", "relatedBenefitConditionEffDateAttr", "relatedBenefitConditionEffDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Specialities", "specialitiesAttr", "specialities", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_BenefitCondition_SpecialityList());
}, true, APIGateway_ISModel.Product_BenefitCondition_SpecialityList)
].concat(_super.attributesToDeclare.call(this));
};
Product_BenefitConditionItemRec.init();
return Product_BenefitConditionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_BenefitConditionItemRec = Product_BenefitConditionItemRec;

});
define("APIGateway_IS.model$FlagItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItem2Rec = (function (_super) {
__extends(FlagItem2Rec, _super);
function FlagItem2Rec(defaults) {
_super.apply(this, arguments);
}
FlagItem2Rec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagCode", "flagCodeAttr", "flagCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagType", "flagTypeAttr", "flagType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "isRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlagItem2Rec.init();
return FlagItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.FlagItem2Rec = FlagItem2Rec;

});
define("APIGateway_IS.model$TillItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$TillItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TillItemList = (function (_super) {
__extends(TillItemList, _super);
function TillItemList(defaults) {
_super.apply(this, arguments);
}
TillItemList.itemType = APIGateway_ISModel.TillItemRec;
return TillItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.TillItemList = TillItemList;

});
define("APIGateway_IS.model$ResultItem_BranchRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$TillItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_BranchRec = (function (_super) {
__extends(ResultItem_BranchRec, _super);
function ResultItem_BranchRec(defaults) {
_super.apply(this, arguments);
}
ResultItem_BranchRec.attributesToDeclare = function () {
return [
this.attr("BranchId", "branchIdAttr", "branchId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchCode", "branchCodeAttr", "branchCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsHeadOffice", "isHeadOfficeAttr", "isHeadOffice", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ShortName", "shortNameAttr", "shortName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Tills", "tillsAttr", "tills", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.TillItemList());
}, true, APIGateway_ISModel.TillItemList)
].concat(_super.attributesToDeclare.call(this));
};
ResultItem_BranchRec.init();
return ResultItem_BranchRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResultItem_BranchRec = ResultItem_BranchRec;

});
define("APIGateway_IS.model$ResultItem_BranchList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_BranchRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_BranchList = (function (_super) {
__extends(ResultItem_BranchList, _super);
function ResultItem_BranchList(defaults) {
_super.apply(this, arguments);
}
ResultItem_BranchList.itemType = APIGateway_ISModel.ResultItem_BranchRec;
return ResultItem_BranchList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ResultItem_BranchList = ResultItem_BranchList;

});
define("APIGateway_IS.model$Branches_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_BranchList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Branches_APIResponseRec = (function (_super) {
__extends(Branches_APIResponseRec, _super);
function Branches_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
Branches_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ResultItem_BranchList());
}, true, APIGateway_ISModel.ResultItem_BranchList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Branches_APIResponseRec.init();
return Branches_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Branches_APIResponseRec = Branches_APIResponseRec;

});
define("APIGateway_IS.model$FunctionDatumRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FunctionDatumRec = (function (_super) {
__extends(FunctionDatumRec, _super);
function FunctionDatumRec(defaults) {
_super.apply(this, arguments);
}
FunctionDatumRec.attributesToDeclare = function () {
return [
this.attr("Property1", "property1Attr", "property1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Property2", "property2Attr", "property2", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FunctionDatumRec.init();
return FunctionDatumRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.FunctionDatumRec = FunctionDatumRec;

});
define("APIGateway_IS.model$EligibleProductItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EligibleProductItemRec = (function (_super) {
__extends(EligibleProductItemRec, _super);
function EligibleProductItemRec(defaults) {
_super.apply(this, arguments);
}
EligibleProductItemRec.attributesToDeclare = function () {
return [
this.attr("RateScale", "rateScaleAttr", "rateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductCode", "productCodeAttr", "productCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTier", "productTierAttr", "productTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScale", "otherRateScaleAttr", "otherRateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HospitalSetCode", "hospitalSetCodeAttr", "hospitalSetCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AncillarySetCode", "ancillarySetCodeAttr", "ancillarySetCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EligibleProductItemRec.init();
return EligibleProductItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EligibleProductItemRec = EligibleProductItemRec;

});
define("APIGateway_IS.model$EligibleProductItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EligibleProductItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EligibleProductItemList = (function (_super) {
__extends(EligibleProductItemList, _super);
function EligibleProductItemList(defaults) {
_super.apply(this, arguments);
}
EligibleProductItemList.itemType = APIGateway_ISModel.EligibleProductItemRec;
return EligibleProductItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EligibleProductItemList = EligibleProductItemList;

});
define("APIGateway_IS.model$GetEligibleProducts_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EligibleProductItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetEligibleProducts_APIResponseRec = (function (_super) {
__extends(GetEligibleProducts_APIResponseRec, _super);
function GetEligibleProducts_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetEligibleProducts_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("EligibleProducts", "eligibleProductsAttr", "eligibleProducts", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EligibleProductItemList());
}, true, APIGateway_ISModel.EligibleProductItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetEligibleProducts_APIResponseRec.fromStructure = function (str) {
return new GetEligibleProducts_APIResponseRec(new GetEligibleProducts_APIResponseRec.RecordClass({
eligibleProductsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetEligibleProducts_APIResponseRec.init();
return GetEligibleProducts_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetEligibleProducts_APIResponseRec = GetEligibleProducts_APIResponseRec;

});
define("APIGateway_IS.model$RateItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RateItemRec = (function (_super) {
__extends(RateItemRec, _super);
function RateItemRec(defaults) {
_super.apply(this, arguments);
}
RateItemRec.attributesToDeclare = function () {
return [
this.attr("RateScale", "rateScaleAttr", "rateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClassCode", "policyClassCodeAttr", "policyClassCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RateItemRec.init();
return RateItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RateItemRec = RateItemRec;

});
define("APIGateway_IS.model$RelatedBenefitConditionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RelatedBenefitConditionItemRec = (function (_super) {
__extends(RelatedBenefitConditionItemRec, _super);
function RelatedBenefitConditionItemRec(defaults) {
_super.apply(this, arguments);
}
RelatedBenefitConditionItemRec.attributesToDeclare = function () {
return [
this.attr("BenefitConditionCode", "benefitConditionCodeAttr", "benefitConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AmountType", "amountTypeAttr", "amountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Level", "levelAttr", "level", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BenefitCondition", "benefitConditionAttr", "benefitCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CycleStartDate", "cycleStartDateAttr", "cycleStartDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CycleEndDate", "cycleEndDateAttr", "cycleEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CyclePeriod", "cyclePeriodAttr", "cyclePeriod", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CycleUnit", "cycleUnitAttr", "cycleUnit", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RolloverCount", "rolloverCountAttr", "rolloverCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Amount", "amountAttr", "amount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UsedAmount", "usedAmountAttr", "usedAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AvailableAmount", "availableAmountAttr", "availableAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CapAmount", "capAmountAttr", "capAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("IsHigherBenefitUsed", "isHigherBenefitUsedAttr", "isHigherBenefitUsed", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HigherBenefitAmount", "higherBenefitAmountAttr", "higherBenefitAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HigherBenefitUsedAmount", "higherBenefitUsedAmountAttr", "higherBenefitUsedAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HigherBenefitAvailableAmount", "higherBenefitAvailableAmountAttr", "higherBenefitAvailableAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RelatedBenefitConditionItemRec.init();
return RelatedBenefitConditionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RelatedBenefitConditionItemRec = RelatedBenefitConditionItemRec;

});
define("APIGateway_IS.model$RelatedBenefitConditionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RelatedBenefitConditionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RelatedBenefitConditionItemList = (function (_super) {
__extends(RelatedBenefitConditionItemList, _super);
function RelatedBenefitConditionItemList(defaults) {
_super.apply(this, arguments);
}
RelatedBenefitConditionItemList.itemType = APIGateway_ISModel.RelatedBenefitConditionItemRec;
return RelatedBenefitConditionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.RelatedBenefitConditionItemList = RelatedBenefitConditionItemList;

});
define("APIGateway_IS.model$BenefitConditionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RelatedBenefitConditionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var BenefitConditionItemRec = (function (_super) {
__extends(BenefitConditionItemRec, _super);
function BenefitConditionItemRec(defaults) {
_super.apply(this, arguments);
}
BenefitConditionItemRec.attributesToDeclare = function () {
return [
this.attr("BenefitConditionCode", "benefitConditionCodeAttr", "benefitConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AmountType", "amountTypeAttr", "amountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Level", "levelAttr", "level", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BenefitCondition", "benefitConditionAttr", "benefitCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CycleStartDate", "cycleStartDateAttr", "cycleStartDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CycleEndDate", "cycleEndDateAttr", "cycleEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CyclePeriod", "cyclePeriodAttr", "cyclePeriod", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CycleUnit", "cycleUnitAttr", "cycleUnit", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RolloverCount", "rolloverCountAttr", "rolloverCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Amount", "amountAttr", "amount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UsedAmount", "usedAmountAttr", "usedAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AvailableAmount", "availableAmountAttr", "availableAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CapAmount", "capAmountAttr", "capAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("IsHigherBenefitUsed", "isHigherBenefitUsedAttr", "isHigherBenefitUsed", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HigherBenefitAmount", "higherBenefitAmountAttr", "higherBenefitAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HigherBenefitUsedAmount", "higherBenefitUsedAmountAttr", "higherBenefitUsedAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HigherBenefitAvailableAmount", "higherBenefitAvailableAmountAttr", "higherBenefitAvailableAmount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RelatedBenefitConditions", "relatedBenefitConditionsAttr", "relatedBenefitConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RelatedBenefitConditionItemList());
}, true, APIGateway_ISModel.RelatedBenefitConditionItemList)
].concat(_super.attributesToDeclare.call(this));
};
BenefitConditionItemRec.init();
return BenefitConditionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.BenefitConditionItemRec = BenefitConditionItemRec;

});
define("APIGateway_IS.model$BenefitConditionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$BenefitConditionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var BenefitConditionItemList = (function (_super) {
__extends(BenefitConditionItemList, _super);
function BenefitConditionItemList(defaults) {
_super.apply(this, arguments);
}
BenefitConditionItemList.itemType = APIGateway_ISModel.BenefitConditionItemRec;
return BenefitConditionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.BenefitConditionItemList = BenefitConditionItemList;

});
define("APIGateway_IS.model$SpecialityItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$BenefitConditionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SpecialityItemRec = (function (_super) {
__extends(SpecialityItemRec, _super);
function SpecialityItemRec(defaults) {
_super.apply(this, arguments);
}
SpecialityItemRec.attributesToDeclare = function () {
return [
this.attr("SpecialityClass", "specialityClassAttr", "specialityClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BenefitConditions", "benefitConditionsAttr", "benefitConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.BenefitConditionItemList());
}, true, APIGateway_ISModel.BenefitConditionItemList)
].concat(_super.attributesToDeclare.call(this));
};
SpecialityItemRec.init();
return SpecialityItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SpecialityItemRec = SpecialityItemRec;

});
define("APIGateway_IS.model$ChoiceOptionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ChoiceOptionItemRec = (function (_super) {
__extends(ChoiceOptionItemRec, _super);
function ChoiceOptionItemRec(defaults) {
_super.apply(this, arguments);
}
ChoiceOptionItemRec.attributesToDeclare = function () {
return [
this.attr("Choice", "choiceAttr", "choice", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChoiceCode", "choiceCodeAttr", "choiceCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ChoiceOptionItemRec.init();
return ChoiceOptionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ChoiceOptionItemRec = ChoiceOptionItemRec;

});
define("APIGateway_IS.model$OptionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var OptionRec = (function (_super) {
__extends(OptionRec, _super);
function OptionRec(defaults) {
_super.apply(this, arguments);
}
OptionRec.attributesToDeclare = function () {
return [
this.attr("ProduceImmediate", "produceImmediateAttr", "produceImmediate", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("InteractiveMode", "interactiveModeAttr", "interactiveMode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GenerateOnly", "generateOnlyAttr", "generateOnly", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AddressOverride", "addressOverrideAttr", "addressOverride", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MediumOverride", "mediumOverrideAttr", "mediumOverride", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OptionRec.init();
return OptionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.OptionRec = OptionRec;

});
define("APIGateway_IS.model$CommunicationRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$OptionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CommunicationRec = (function (_super) {
__extends(CommunicationRec, _super);
function CommunicationRec(defaults) {
_super.apply(this, arguments);
}
CommunicationRec.attributesToDeclare = function () {
return [
this.attr("CommunicationId", "communicationIdAttr", "communicationId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("User", "userAttr", "user", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Options", "optionsAttr", "options", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.OptionRec());
}, true, APIGateway_ISModel.OptionRec)
].concat(_super.attributesToDeclare.call(this));
};
CommunicationRec.init();
return CommunicationRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CommunicationRec = CommunicationRec;

});
define("APIGateway_IS.model$ChoiceOptionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ChoiceOptionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ChoiceOptionItemList = (function (_super) {
__extends(ChoiceOptionItemList, _super);
function ChoiceOptionItemList(defaults) {
_super.apply(this, arguments);
}
ChoiceOptionItemList.itemType = APIGateway_ISModel.ChoiceOptionItemRec;
return ChoiceOptionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ChoiceOptionItemList = ChoiceOptionItemList;

});
define("APIGateway_IS.model$PromptItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ChoiceOptionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PromptItemRec = (function (_super) {
__extends(PromptItemRec, _super);
function PromptItemRec(defaults) {
_super.apply(this, arguments);
}
PromptItemRec.attributesToDeclare = function () {
return [
this.attr("Question", "questionAttr", "question", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChoiceType", "choiceTypeAttr", "choiceType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("QuestionCode", "questionCodeAttr", "questionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChoiceOptions", "choiceOptionsAttr", "choiceOptions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ChoiceOptionItemList());
}, true, APIGateway_ISModel.ChoiceOptionItemList)
].concat(_super.attributesToDeclare.call(this));
};
PromptItemRec.init();
return PromptItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PromptItemRec = PromptItemRec;

});
define("APIGateway_IS.model$MedicareRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MedicareRec = (function (_super) {
__extends(MedicareRec, _super);
function MedicareRec(defaults) {
_super.apply(this, arguments);
}
MedicareRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardNumber", "medicareCardNumberAttr", "medicareCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardIrn", "medicareCardIrnAttr", "medicareCardIrn", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SecondName", "secondNameAttr", "secondName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MedicareRec.init();
return MedicareRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.MedicareRec = MedicareRec;

});
define("APIGateway_IS.model$Medicare2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Medicare2Rec = (function (_super) {
__extends(Medicare2Rec, _super);
function Medicare2Rec(defaults) {
_super.apply(this, arguments);
}
Medicare2Rec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardNumber", "medicareCardNumberAttr", "medicareCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardIrn", "medicareCardIrnAttr", "medicareCardIrn", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SecondName", "secondNameAttr", "secondName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Medicare2Rec.init();
return Medicare2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Medicare2Rec = Medicare2Rec;

});
define("APIGateway_IS.model$UpdateEntityNotes2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var UpdateEntityNotes2Rec = (function (_super) {
__extends(UpdateEntityNotes2Rec, _super);
function UpdateEntityNotes2Rec(defaults) {
_super.apply(this, arguments);
}
UpdateEntityNotes2Rec.attributesToDeclare = function () {
return [
this.attr("NoteTypeCode", "noteTypeCodeAttr", "noteTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Subject", "subjectAttr", "subject", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Note", "noteAttr", "note", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsPriorityNote", "isPriorityNoteAttr", "isPriorityNote", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PriorityNoteExpiryDate", "priorityNoteExpiryDateAttr", "priorityNoteExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ConcurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("NoteType", "noteTypeAttr", "noteType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RaisedBy", "raisedByAttr", "raisedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityNoteId", "entityNoteIdAttr", "entityNoteId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
UpdateEntityNotes2Rec.init();
return UpdateEntityNotes2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.UpdateEntityNotes2Rec = UpdateEntityNotes2Rec;

});
define("APIGateway_IS.model$UpdateEntityNotes2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$UpdateEntityNotes2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var UpdateEntityNotes2List = (function (_super) {
__extends(UpdateEntityNotes2List, _super);
function UpdateEntityNotes2List(defaults) {
_super.apply(this, arguments);
}
UpdateEntityNotes2List.itemType = APIGateway_ISModel.UpdateEntityNotes2Rec;
return UpdateEntityNotes2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.UpdateEntityNotes2List = UpdateEntityNotes2List;

});
define("APIGateway_IS.model$GetEntityNotes_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$UpdateEntityNotes2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetEntityNotes_APIResponseRec = (function (_super) {
__extends(GetEntityNotes_APIResponseRec, _super);
function GetEntityNotes_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetEntityNotes_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.UpdateEntityNotes2List());
}, true, APIGateway_ISModel.UpdateEntityNotes2List), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetEntityNotes_APIResponseRec.init();
return GetEntityNotes_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetEntityNotes_APIResponseRec = GetEntityNotes_APIResponseRec;

});
define("APIGateway_IS.model$MemberItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MemberItemRec = (function (_super) {
__extends(MemberItemRec, _super);
function MemberItemRec(defaults) {
_super.apply(this, arguments);
}
MemberItemRec.attributesToDeclare = function () {
return [
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcOverride", "lhcOverrideAttr", "lhcOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AbdEntryAge", "abdEntryAgeAttr", "abdEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcLoadingPercentage", "lhcLoadingPercentageAttr", "lhcLoadingPercentage", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RelationshipClass", "relationshipClassAttr", "relationshipClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsPrimaryMember", "isPrimaryMemberAttr", "isPrimaryMember", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MemberItemRec.init();
return MemberItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.MemberItemRec = MemberItemRec;

});
define("APIGateway_IS.model$MemberItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MemberItemList = (function (_super) {
__extends(MemberItemList, _super);
function MemberItemList(defaults) {
_super.apply(this, arguments);
}
MemberItemList.itemType = APIGateway_ISModel.MemberItemRec;
return MemberItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.MemberItemList = MemberItemList;

});
define("APIGateway_IS.model$FrequencyQuoteItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FrequencyQuoteItemRec = (function (_super) {
__extends(FrequencyQuoteItemRec, _super);
function FrequencyQuoteItemRec(defaults) {
_super.apply(this, arguments);
}
FrequencyQuoteItemRec.attributesToDeclare = function () {
return [
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PremiumAmount", "premiumAmountAttr", "premiumAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("LhcLoadingPercentage", "lhcLoadingPercentageAttr", "lhcLoadingPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("LhcLoadingAmount", "lhcLoadingAmountAttr", "lhcLoadingAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AbdPercentage", "abdPercentageAttr", "abdPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AbdAmount", "abdAmountAttr", "abdAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("RebatePercentage", "rebatePercentageAttr", "rebatePercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("GrossAmount", "grossAmountAttr", "grossAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("DiscountAmount", "discountAmountAttr", "discountAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("RebateAmount", "rebateAmountAttr", "rebateAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("SubsidyAmount", "subsidyAmountAttr", "subsidyAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Balance", "balanceAttr", "balance", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("PaidToDate", "paidToDateAttr", "paidToDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DebitOnDate", "debitOnDateAttr", "debitOnDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("BillCycleDate", "billCycleDateAttr", "billCycleDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("NextAmountDue", "nextAmountDueAttr", "nextAmountDue", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("PremiumDueDate", "premiumDueDateAttr", "premiumDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RateFreezeDate", "rateFreezeDateAttr", "rateFreezeDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("NextPaymentDate", "nextPaymentDateAttr", "nextPaymentDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TheoreticalPaidToDate", "theoreticalPaidToDateAttr", "theoreticalPaidToDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RebatableAmount", "rebatableAmountAttr", "rebatableAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FrequencyQuoteItemRec.init();
return FrequencyQuoteItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.FrequencyQuoteItemRec = FrequencyQuoteItemRec;

});
define("APIGateway_IS.model$FrequencyQuoteItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$FrequencyQuoteItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FrequencyQuoteItemList = (function (_super) {
__extends(FrequencyQuoteItemList, _super);
function FrequencyQuoteItemList(defaults) {
_super.apply(this, arguments);
}
FrequencyQuoteItemList.itemType = APIGateway_ISModel.FrequencyQuoteItemRec;
return FrequencyQuoteItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.FrequencyQuoteItemList = FrequencyQuoteItemList;

});
define("APIGateway_IS.model$RatesQuoteRevisionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemList", "APIGateway_IS.model$FrequencyQuoteItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RatesQuoteRevisionRec = (function (_super) {
__extends(RatesQuoteRevisionRec, _super);
function RatesQuoteRevisionRec(defaults) {
_super.apply(this, arguments);
}
RatesQuoteRevisionRec.attributesToDeclare = function () {
return [
this.attr("QuoteRevisionId", "quoteRevisionIdAttr", "quoteRevisionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EligibilityReasonCode", "eligibilityReasonCodeAttr", "eligibilityReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilitySubReasonCode", "eligibilitySubReasonCodeAttr", "eligibilitySubReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Cover", "coverAttr", "cover", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "state", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ResidencyStatus", "residencyStatusAttr", "residencyStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IgnoreMembershipConditions", "ignoreMembershipConditionsAttr", "ignoreMembershipConditions", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HealthRateScaleCode", "healthRateScaleCodeAttr", "healthRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateAge", "rebateAgeAttr", "rebateAge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateTier", "rebateTierAttr", "rebateTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Members", "membersAttr", "members", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItemList());
}, true, APIGateway_ISModel.MemberItemList), 
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FrequencyQuotes", "frequencyQuotesAttr", "frequencyQuotes", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FrequencyQuoteItemList());
}, true, APIGateway_ISModel.FrequencyQuoteItemList), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Site", "siteAttr", "site", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Badge", "badgeAttr", "badge", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RatesQuoteRevisionRec.init();
return RatesQuoteRevisionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RatesQuoteRevisionRec = RatesQuoteRevisionRec;

});
define("APIGateway_IS.model$EmailItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailItemRec = (function (_super) {
__extends(EmailItemRec, _super);
function EmailItemRec(defaults) {
_super.apply(this, arguments);
}
EmailItemRec.attributesToDeclare = function () {
return [
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EmailItemRec.init();
return EmailItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EmailItemRec = EmailItemRec;

});
define("APIGateway_IS.model$FlagItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$FlagItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItem2List = (function (_super) {
__extends(FlagItem2List, _super);
function FlagItem2List(defaults) {
_super.apply(this, arguments);
}
FlagItem2List.itemType = APIGateway_ISModel.FlagItem2Rec;
return FlagItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.FlagItem2List = FlagItem2List;

});
define("APIGateway_IS.model$AddressItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItemRec = (function (_super) {
__extends(AddressItemRec, _super);
function AddressItemRec(defaults) {
_super.apply(this, arguments);
}
AddressItemRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsReturnedMail", "isReturnedMailAttr", "isReturnedMail", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("StateTerritory", "stateTerritoryAttr", "stateTerritory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ZipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddressItemRec.init();
return AddressItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddressItemRec = AddressItemRec;

});
define("APIGateway_IS.model$DuplicateItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailItemRec", "APIGateway_IS.model$FlagItem2List", "APIGateway_IS.model$PhoneNumberItemRec", "APIGateway_IS.model$AddressItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DuplicateItemRec = (function (_super) {
__extends(DuplicateItemRec, _super);
function DuplicateItemRec(defaults) {
_super.apply(this, arguments);
}
DuplicateItemRec.attributesToDeclare = function () {
return [
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItemRec());
}, true, APIGateway_ISModel.EmailItemRec), 
this.attr("Flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FlagItem2List());
}, true, APIGateway_ISModel.FlagItem2List), 
this.attr("Phone", "phoneAttr", "phone", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemRec());
}, true, APIGateway_ISModel.PhoneNumberItemRec), 
this.attr("Address", "addressAttr", "address", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItemRec());
}, true, APIGateway_ISModel.AddressItemRec), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderStatus", "stakeholderStatusAttr", "stakeholderStatus", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DuplicateItemRec.init();
return DuplicateItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.DuplicateItemRec = DuplicateItemRec;

});
define("APIGateway_IS.model$DuplicateItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$DuplicateItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DuplicateItemList = (function (_super) {
__extends(DuplicateItemList, _super);
function DuplicateItemList(defaults) {
_super.apply(this, arguments);
}
DuplicateItemList.itemType = APIGateway_ISModel.DuplicateItemRec;
return DuplicateItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.DuplicateItemList = DuplicateItemList;

});
define("APIGateway_IS.model$GetDuplicateIndividuals_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$DuplicateItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetDuplicateIndividuals_APIResponseRec = (function (_super) {
__extends(GetDuplicateIndividuals_APIResponseRec, _super);
function GetDuplicateIndividuals_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetDuplicateIndividuals_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Duplicates", "duplicatesAttr", "duplicates", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.DuplicateItemList());
}, true, APIGateway_ISModel.DuplicateItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetDuplicateIndividuals_APIResponseRec.fromStructure = function (str) {
return new GetDuplicateIndividuals_APIResponseRec(new GetDuplicateIndividuals_APIResponseRec.RecordClass({
duplicatesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetDuplicateIndividuals_APIResponseRec.init();
return GetDuplicateIndividuals_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetDuplicateIndividuals_APIResponseRec = GetDuplicateIndividuals_APIResponseRec;

});
define("APIGateway_IS.model$Product_ComponentRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_ComponentRec = (function (_super) {
__extends(Product_ComponentRec, _super);
function Product_ComponentRec(defaults) {
_super.apply(this, arguments);
}
Product_ComponentRec.attributesToDeclare = function () {
return [
this.attr("ComponentId", "componentIdAttr", "componentId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ComponentScale", "componentScaleAttr", "componentScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ClaimType", "claimTypeAttr", "claimType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Product_ComponentRec.init();
return Product_ComponentRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_ComponentRec = Product_ComponentRec;

});
define("APIGateway_IS.model$PHINote_Search_ResultRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHINote_Search_ResultRec = (function (_super) {
__extends(PHINote_Search_ResultRec, _super);
function PHINote_Search_ResultRec(defaults) {
_super.apply(this, arguments);
}
PHINote_Search_ResultRec.attributesToDeclare = function () {
return [
this.attr("noteId", "noteIdAttr", "noteId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("entityId", "entityIdAttr", "entityId", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("entityType", "entityTypeAttr", "entityType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("noteTypeCode", "noteTypeCodeAttr", "noteTypeCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("noteType", "noteTypeAttr", "noteType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("entryDateTime", "entryDateTimeAttr", "entryDateTime", true, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("subject", "subjectAttr", "subject", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("note", "noteAttr", "note", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("raisedBy", "raisedByAttr", "raisedBy", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isPriorityNote", "isPriorityNoteAttr", "isPriorityNote", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("priorityNoteExpiryDate", "priorityNoteExpiryDateAttr", "priorityNoteExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("concurrencyToken", "concurrencyTokenAttr", "concurrencyToken", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHINote_Search_ResultRec.init();
return PHINote_Search_ResultRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHINote_Search_ResultRec = PHINote_Search_ResultRec;

});
define("APIGateway_IS.model$PHINote_Search_ResultList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHINote_Search_ResultRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHINote_Search_ResultList = (function (_super) {
__extends(PHINote_Search_ResultList, _super);
function PHINote_Search_ResultList(defaults) {
_super.apply(this, arguments);
}
PHINote_Search_ResultList.itemType = APIGateway_ISModel.PHINote_Search_ResultRec;
return PHINote_Search_ResultList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHINote_Search_ResultList = PHINote_Search_ResultList;

});
define("APIGateway_IS.model$PHINote_Search_ResultSetRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHINote_Search_ResultList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHINote_Search_ResultSetRec = (function (_super) {
__extends(PHINote_Search_ResultSetRec, _super);
function PHINote_Search_ResultSetRec(defaults) {
_super.apply(this, arguments);
}
PHINote_Search_ResultSetRec.attributesToDeclare = function () {
return [
this.attr("result", "resultAttr", "result", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHINote_Search_ResultList());
}, true, APIGateway_ISModel.PHINote_Search_ResultList), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("totalCount", "totalCountAttr", "totalCount", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHINote_Search_ResultSetRec.init();
return PHINote_Search_ResultSetRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHINote_Search_ResultSetRec = PHINote_Search_ResultSetRec;

});
define("APIGateway_IS.model$Product_RateItem_FrequencyFundRateRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateItem_FrequencyFundRateRec = (function (_super) {
__extends(Product_RateItem_FrequencyFundRateRec, _super);
function Product_RateItem_FrequencyFundRateRec(defaults) {
_super.apply(this, arguments);
}
Product_RateItem_FrequencyFundRateRec.attributesToDeclare = function () {
return [
this.attr("ContributionFrequencyCode", "contributionFrequencyCodeAttr", "contributionFrequencyCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DiscountRate", "discountRateAttr", "discountRate", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("DiscountAmount", "discountAmountAttr", "discountAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("SubsidyRate", "subsidyRateAttr", "subsidyRate", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("SubsidyAmount", "subsidyAmountAttr", "subsidyAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("BonusUnit", "bonusUnitAttr", "bonusUnit", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BonusPeriod", "bonusPeriodAttr", "bonusPeriod", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CommissionFlatRate", "commissionFlatRateAttr", "commissionFlatRate", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CommissionPercentage", "commissionPercentageAttr", "commissionPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("FundType", "fundTypeAttr", "fundType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GrossAmount", "grossAmountAttr", "grossAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Product_RateItem_FrequencyFundRateRec.init();
return Product_RateItem_FrequencyFundRateRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_RateItem_FrequencyFundRateRec = Product_RateItem_FrequencyFundRateRec;

});
define("APIGateway_IS.model$EntityResultItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityResultItemRec = (function (_super) {
__extends(EntityResultItemRec, _super);
function EntityResultItemRec(defaults) {
_super.apply(this, arguments);
}
EntityResultItemRec.attributesToDeclare = function () {
return [
this.attr("EntityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityPropertyId", "entityPropertyIdAttr", "entityPropertyId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PropertyKey", "propertyKeyAttr", "propertyKeyCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PropertyValue", "propertyValueAttr", "propertyValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PropertyCode", "propertyCodeAttr", "propertyCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PropertyDescription", "propertyDescriptionAttr", "propertyDescription", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PropertyValueType", "propertyValueTypeAttr", "propertyValueType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("UserDefinedPropertyType", "userDefinedPropertyTypeAttr", "userDefinedPropertyType", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EntityResultItemRec.init();
return EntityResultItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EntityResultItemRec = EntityResultItemRec;

});
define("APIGateway_IS.model$PHICreateNote_ResultRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICreateNote_ResultRec = (function (_super) {
__extends(PHICreateNote_ResultRec, _super);
function PHICreateNote_ResultRec(defaults) {
_super.apply(this, arguments);
}
PHICreateNote_ResultRec.attributesToDeclare = function () {
return [
this.attr("noteId", "noteIdAttr", "noteId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("concurrencyToken", "concurrencyTokenAttr", "concurrencyToken", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICreateNote_ResultRec.init();
return PHICreateNote_ResultRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICreateNote_ResultRec = PHICreateNote_ResultRec;

});
define("APIGateway_IS.model$PHICreateNote_Result_ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIProblemDetailsRec", "APIGateway_IS.model$PHICreateNote_ResultRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICreateNote_Result_ResponseRec = (function (_super) {
__extends(PHICreateNote_Result_ResponseRec, _super);
function PHICreateNote_Result_ResponseRec(defaults) {
_super.apply(this, arguments);
}
PHICreateNote_Result_ResponseRec.attributesToDeclare = function () {
return [
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec), 
this.attr("AddNoteResult", "addNoteResultAttr", "AddNoteResult", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHICreateNote_ResultRec());
}, true, APIGateway_ISModel.PHICreateNote_ResultRec)
].concat(_super.attributesToDeclare.call(this));
};
PHICreateNote_Result_ResponseRec.init();
return PHICreateNote_Result_ResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICreateNote_Result_ResponseRec = PHICreateNote_Result_ResponseRec;

});
define("APIGateway_IS.model$PHIPatchRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPatchRec = (function (_super) {
__extends(PHIPatchRec, _super);
function PHIPatchRec(defaults) {
_super.apply(this, arguments);
}
PHIPatchRec.attributesToDeclare = function () {
return [
this.attr("op", "opAttr", "op", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("path", "pathAttr", "path", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("value", "valueAttr", "value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIPatchRec.init();
return PHIPatchRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPatchRec = PHIPatchRec;

});
define("APIGateway_IS.model$PHIPatchList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPatchRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPatchList = (function (_super) {
__extends(PHIPatchList, _super);
function PHIPatchList(defaults) {
_super.apply(this, arguments);
}
PHIPatchList.itemType = APIGateway_ISModel.PHIPatchRec;
return PHIPatchList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIPatchList = PHIPatchList;

});
define("APIGateway_IS.model$PHIPatchIndividualRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPatchList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPatchIndividualRequestRec = (function (_super) {
__extends(PHIPatchIndividualRequestRec, _super);
function PHIPatchIndividualRequestRec(defaults) {
_super.apply(this, arguments);
}
PHIPatchIndividualRequestRec.attributesToDeclare = function () {
return [
this.attr("Items", "itemsAttr", "items", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIPatchList());
}, true, APIGateway_ISModel.PHIPatchList)
].concat(_super.attributesToDeclare.call(this));
};
PHIPatchIndividualRequestRec.fromStructure = function (str) {
return new PHIPatchIndividualRequestRec(new PHIPatchIndividualRequestRec.RecordClass({
itemsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHIPatchIndividualRequestRec.init();
return PHIPatchIndividualRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPatchIndividualRequestRec = PHIPatchIndividualRequestRec;

});
define("APIGateway_IS.model$WaitingPeriodRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var WaitingPeriodRec = (function (_super) {
__extends(WaitingPeriodRec, _super);
function WaitingPeriodRec(defaults) {
_super.apply(this, arguments);
}
WaitingPeriodRec.attributesToDeclare = function () {
return [
this.attr("ApplyVariationTo", "applyVariationToAttr", "applyVariationTo", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("WaitingPeriodCode", "waitingPeriodCodeAttr", "waitingPeriodCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitingPeriodStatus", "waitingPeriodStatusAttr", "waitingPeriodStatus", false, false, OS.Types.Text, function () {
return "active";
}, true), 
this.attr("ReasonForVariationCode", "reasonForVariationCodeAttr", "reasonForVariationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitingPeriodVariation", "waitingPeriodVariationAttr", "waitingPeriodVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
WaitingPeriodRec.init();
return WaitingPeriodRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.WaitingPeriodRec = WaitingPeriodRec;

});
define("APIGateway_IS.model$PolicyImmediatePaymentRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyImmediatePaymentRec = (function (_super) {
__extends(PolicyImmediatePaymentRec, _super);
function PolicyImmediatePaymentRec(defaults) {
_super.apply(this, arguments);
}
PolicyImmediatePaymentRec.attributesToDeclare = function () {
return [
this.attr("Amount", "amountAttr", "amount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CashAmount", "cashAmountAttr", "cashAmount", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CashTendered", "cashTenderedAttr", "cashTendered", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddAnotherCard", "addAnotherCardAttr", "addAnotherCard", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PayNextPayment", "payNextPaymentAttr", "payNextPayment", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PayOtherAmount", "payOtherAmountAttr", "payOtherAmount", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("NumberOfPeriods", "numberOfPeriodsAttr", "numberOfPeriods", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("UseCardForDirectDebit", "useCardForDirectDebitAttr", "useCardForDirectDebit", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyImmediatePaymentRec.init();
return PolicyImmediatePaymentRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyImmediatePaymentRec = PolicyImmediatePaymentRec;

});
define("APIGateway_IS.model$NoteItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$NoteItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var NoteItemList = (function (_super) {
__extends(NoteItemList, _super);
function NoteItemList(defaults) {
_super.apply(this, arguments);
}
NoteItemList.itemType = APIGateway_ISModel.NoteItemRec;
return NoteItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.NoteItemList = NoteItemList;

});
define("APIGateway_IS.model$AccountItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AccountItem2Rec = (function (_super) {
__extends(AccountItem2Rec, _super);
function AccountItem2Rec(defaults) {
_super.apply(this, arguments);
}
AccountItem2Rec.attributesToDeclare = function () {
return [
this.attr("Bsb", "bsbAttr", "bsb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountName", "accountNameAttr", "accountName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountType", "accountTypeAttr", "accountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountClass", "accountClassAttr", "accountClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountNumber", "accountNumberAttr", "accountNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CardExpiryDate", "cardExpiryDateAttr", "cardExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AccountItem2Rec.init();
return AccountItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AccountItem2Rec = AccountItem2Rec;

});
define("APIGateway_IS.model$AccountItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AccountItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AccountItem2List = (function (_super) {
__extends(AccountItem2List, _super);
function AccountItem2List(defaults) {
_super.apply(this, arguments);
}
AccountItem2List.itemType = APIGateway_ISModel.AccountItem2Rec;
return AccountItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AccountItem2List = AccountItem2List;

});
define("APIGateway_IS.model$PreviousCoverItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$LhcDetailRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviousCoverItem2Rec = (function (_super) {
__extends(PreviousCoverItem2Rec, _super);
function PreviousCoverItem2Rec(defaults) {
_super.apply(this, arguments);
}
PreviousCoverItem2Rec.attributesToDeclare = function () {
return [
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LhcDetails", "lhcDetailsAttr", "lhcDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LhcDetailRec());
}, true, APIGateway_ISModel.LhcDetailRec), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousFundCode", "previousFundCodeAttr", "previousFundCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PreviousCoverItem2Rec.init();
return PreviousCoverItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreviousCoverItem2Rec = PreviousCoverItem2Rec;

});
define("APIGateway_IS.model$PreviousCoverItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreviousCoverItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviousCoverItem2List = (function (_super) {
__extends(PreviousCoverItem2List, _super);
function PreviousCoverItem2List(defaults) {
_super.apply(this, arguments);
}
PreviousCoverItem2List.itemType = APIGateway_ISModel.PreviousCoverItem2Rec;
return PreviousCoverItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PreviousCoverItem2List = PreviousCoverItem2List;

});
define("APIGateway_IS.model$WaitingPeriodItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var WaitingPeriodItemRec = (function (_super) {
__extends(WaitingPeriodItemRec, _super);
function WaitingPeriodItemRec(defaults) {
_super.apply(this, arguments);
}
WaitingPeriodItemRec.attributesToDeclare = function () {
return [
this.attr("WaitingPeriodCode", "waitingPeriodCodeAttr", "waitingPeriodCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonForVariationCode", "reasonForVariationCodeAttr", "reasonForVariationCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
WaitingPeriodItemRec.init();
return WaitingPeriodItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.WaitingPeriodItemRec = WaitingPeriodItemRec;

});
define("APIGateway_IS.model$WaitingPeriodItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$WaitingPeriodItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var WaitingPeriodItemList = (function (_super) {
__extends(WaitingPeriodItemList, _super);
function WaitingPeriodItemList(defaults) {
_super.apply(this, arguments);
}
WaitingPeriodItemList.itemType = APIGateway_ISModel.WaitingPeriodItemRec;
return WaitingPeriodItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.WaitingPeriodItemList = WaitingPeriodItemList;

});
define("APIGateway_IS.model$RebateRegistrationRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RebateRegistrationRec = (function (_super) {
__extends(RebateRegistrationRec, _super);
function RebateRegistrationRec(defaults) {
_super.apply(this, arguments);
}
RebateRegistrationRec.attributesToDeclare = function () {
return [
this.attr("RebateTier", "rebateTierAttr", "rebateTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateApplicationVerified", "rebateApplicationVerifiedAttr", "rebateApplicationVerified", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RebateParticipationConsent", "rebateParticipationConsentAttr", "rebateParticipationConsent", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RebateRegistrationRec.init();
return RebateRegistrationRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RebateRegistrationRec = RebateRegistrationRec;

});
define("APIGateway_IS.model$RebateSavingsProvisionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RebateSavingsProvisionRec = (function (_super) {
__extends(RebateSavingsProvisionRec, _super);
function RebateSavingsProvisionRec(defaults) {
_super.apply(this, arguments);
}
RebateSavingsProvisionRec.attributesToDeclare = function () {
return [
this.attr("FundCode", "fundCodeAttr", "fundCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateAge", "rebateAgeAttr", "rebateAge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RebateSavingsProvisionRec.init();
return RebateSavingsProvisionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RebateSavingsProvisionRec = RebateSavingsProvisionRec;

});
define("APIGateway_IS.model$MemberItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$NoteItemList", "APIGateway_IS.model$AccountItem2List", "APIGateway_IS.model$LhcDetailRec", "APIGateway_IS.model$PreviousCoverItem2List", "APIGateway_IS.model$WaitingPeriodItemList", "APIGateway_IS.model$RebateRegistrationRec", "APIGateway_IS.model$RebateSavingsProvisionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MemberItem2Rec = (function (_super) {
__extends(MemberItem2Rec, _super);
function MemberItem2Rec(defaults) {
_super.apply(this, arguments);
}
MemberItem2Rec.attributesToDeclare = function () {
return [
this.attr("Notes", "notesAttr", "notes", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.NoteItemList());
}, true, APIGateway_ISModel.NoteItemList), 
this.attr("Private", "privateAttr", "private", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Accounts", "accountsAttr", "accounts", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AccountItem2List());
}, true, APIGateway_ISModel.AccountItem2List), 
this.attr("LhcDetails", "lhcDetailsAttr", "lhcDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LhcDetailRec());
}, true, APIGateway_ISModel.LhcDetailRec), 
this.attr("PeaOverride", "peaOverrideAttr", "peaOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsContributor", "isContributorAttr", "isContributor", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CoverVariation", "coverVariationAttr", "coverVariation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousCovers", "previousCoversAttr", "previousCovers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreviousCoverItem2List());
}, true, APIGateway_ISModel.PreviousCoverItem2List), 
this.attr("WaitingPeriods", "waitingPeriodsAttr", "waitingPeriods", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.WaitingPeriodItemList());
}, true, APIGateway_ISModel.WaitingPeriodItemList), 
this.attr("RelationshipCode", "relationshipCodeAttr", "relationshipCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DependantOverride", "dependantOverrideAttr", "dependantOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("DisabilityOverride", "disabilityOverrideAttr", "disabilityOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RebateRegistration", "rebateRegistrationAttr", "rebateRegistration", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RebateRegistrationRec());
}, true, APIGateway_ISModel.RebateRegistrationRec), 
this.attr("RebateSavingsProvision", "rebateSavingsProvisionAttr", "rebateSavingsProvision", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RebateSavingsProvisionRec());
}, true, APIGateway_ISModel.RebateSavingsProvisionRec), 
this.attr("HospitalWaitExemptionUsedDate", "hospitalWaitExemptionUsedDateAttr", "hospitalWaitExemptionUsedDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MemberItem2Rec.init();
return MemberItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.MemberItem2Rec = MemberItem2Rec;

});
define("APIGateway_IS.model$MemberItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MemberItem2List = (function (_super) {
__extends(MemberItem2List, _super);
function MemberItem2List(defaults) {
_super.apply(this, arguments);
}
MemberItem2List.itemType = APIGateway_ISModel.MemberItem2Rec;
return MemberItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.MemberItem2List = MemberItem2List;

});
define("APIGateway_IS.model$PolicyWaitingPeriodItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyWaitingPeriodItemRec = (function (_super) {
__extends(PolicyWaitingPeriodItemRec, _super);
function PolicyWaitingPeriodItemRec(defaults) {
_super.apply(this, arguments);
}
PolicyWaitingPeriodItemRec.attributesToDeclare = function () {
return [
this.attr("WaitingPeriodCode", "waitingPeriodCodeAttr", "waitingPeriodCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonForWaiveCode", "reasonForWaiveCodeAttr", "reasonForWaiveCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyWaitingPeriodItemRec.init();
return PolicyWaitingPeriodItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyWaitingPeriodItemRec = PolicyWaitingPeriodItemRec;

});
define("APIGateway_IS.model$PolicyWaitingPeriodItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyWaitingPeriodItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyWaitingPeriodItemList = (function (_super) {
__extends(PolicyWaitingPeriodItemList, _super);
function PolicyWaitingPeriodItemList(defaults) {
_super.apply(this, arguments);
}
PolicyWaitingPeriodItemList.itemType = APIGateway_ISModel.PolicyWaitingPeriodItemRec;
return PolicyWaitingPeriodItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyWaitingPeriodItemList = PolicyWaitingPeriodItemList;

});
define("APIGateway_IS.model$AddPolicy_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$WaitingPeriodRec", "APIGateway_IS.model$PolicyEligibilityReasonRec", "APIGateway_IS.model$PolicyRebateRec", "APIGateway_IS.model$FrequencyQuoteItemRec", "APIGateway_IS.model$PolicyImmediatePaymentRec", "APIGateway_IS.model$MemberItem2List", "APIGateway_IS.model$PolicyWaitingPeriodItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddPolicy_APIRec = (function (_super) {
__extends(AddPolicy_APIRec, _super);
function AddPolicy_APIRec(defaults) {
_super.apply(this, arguments);
}
AddPolicy_APIRec.attributesToDeclare = function () {
return [
this.attr("QuoteId", "quoteIdAttr", "quoteId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDate", "entryDateAttr", "entryDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StartDateOther", "startDateOtherAttr", "startDateOther", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDateOther", "entryDateOtherAttr", "entryDateOther", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PrivacyStatement", "privacyStatementAttr", "privacyStatement", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BranchCode", "branchCodeAttr", "branchCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AgentCode", "agentCodeAttr", "agentCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTierCode", "productTierCodeAttr", "productTierCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherProductName", "otherProductNameAttr", "otherProductName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CoverContinuityDate", "coverContinuityDateAttr", "coverContinuityDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("WaitingPeriod", "waitingPeriodAttr", "waitingPeriod", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.WaitingPeriodRec());
}, true, APIGateway_ISModel.WaitingPeriodRec), 
this.attr("PolicyEligibilityReason", "policyEligibilityReasonAttr", "policyEligibilityReason", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyEligibilityReasonRec());
}, true, APIGateway_ISModel.PolicyEligibilityReasonRec), 
this.attr("PolicyRebate", "policyRebateAttr", "policyRebate", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRebateRec());
}, true, APIGateway_ISModel.PolicyRebateRec), 
this.attr("PolicyPremiumDetails", "policyPremiumDetailsAttr", "policyPremiumDetails", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FrequencyQuoteItemRec());
}, true, APIGateway_ISModel.FrequencyQuoteItemRec), 
this.attr("PolicyImmediatePayment", "policyImmediatePaymentAttr", "policyImmediatePayment", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyImmediatePaymentRec());
}, true, APIGateway_ISModel.PolicyImmediatePaymentRec), 
this.attr("Members", "membersAttr", "members", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItem2List());
}, true, APIGateway_ISModel.MemberItem2List), 
this.attr("PolicyWaitingPeriods", "policyWaitingPeriodsAttr", "policyWaitingPeriods", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyWaitingPeriodItemList());
}, true, APIGateway_ISModel.PolicyWaitingPeriodItemList)
].concat(_super.attributesToDeclare.call(this));
};
AddPolicy_APIRec.init();
return AddPolicy_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddPolicy_APIRec = AddPolicy_APIRec;

});
define("APIGateway_IS.model$GetSearchProduct_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetSearchProduct_APIRequestRec = (function (_super) {
__extends(GetSearchProduct_APIRequestRec, _super);
function GetSearchProduct_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
GetSearchProduct_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("activeAsAtDate", "activeAsAtDateAttr", "activeAsAtDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("includeTotalCount", "includeTotalCountAttr", "includeTotalCount", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("productCodes", "productCodesAttr", "productCodes", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("productTierCode", "productTierCodeAttr", "productTierCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("productType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetSearchProduct_APIRequestRec.init();
return GetSearchProduct_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetSearchProduct_APIRequestRec = GetSearchProduct_APIRequestRec;

});
define("APIGateway_IS.model$PHI_QuoteRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_QuoteRec = (function (_super) {
__extends(PHI_QuoteRec, _super);
function PHI_QuoteRec(defaults) {
_super.apply(this, arguments);
}
PHI_QuoteRec.attributesToDeclare = function () {
return [
this.attr("quoteId", "quoteIdAttr", "quoteId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("policyClassCode", "policyClassCodeAttr", "policyClassCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("policyClass", "policyClassAttr", "policyClass", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("productType", "productTypeAttr", "productType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("status", "statusAttr", "status", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHI_QuoteRec.init();
return PHI_QuoteRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHI_QuoteRec = PHI_QuoteRec;

});
define("APIGateway_IS.model$CancelLead_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ProblemStringRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CancelLead_APIResponseRec = (function (_super) {
__extends(CancelLead_APIResponseRec, _super);
function CancelLead_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
CancelLead_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ProblemStringRec());
}, true, APIGateway_ISModel.ProblemStringRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ProblemStringRec());
}, true, APIGateway_ISModel.ProblemStringRec)
].concat(_super.attributesToDeclare.call(this));
};
CancelLead_APIResponseRec.init();
return CancelLead_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CancelLead_APIResponseRec = CancelLead_APIResponseRec;

});
define("APIGateway_IS.model$PreexistingConditionItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreexistingConditionItemRec = (function (_super) {
__extends(PreexistingConditionItemRec, _super);
function PreexistingConditionItemRec(defaults) {
_super.apply(this, arguments);
}
PreexistingConditionItemRec.attributesToDeclare = function () {
return [
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Condition", "conditionAttr", "condition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ConditionCode", "conditionCodeAttr", "conditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorComment", "errorCommentAttr", "ErrorComment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorPreExistingCondition", "errorPreExistingConditionAttr", "ErrorPreExistingCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreexistingConditionCode", "preexistingConditionCodeAttr", "preexistingConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PreexistingConditionItemRec.init();
return PreexistingConditionItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreexistingConditionItemRec = PreexistingConditionItemRec;

});
define("APIGateway_IS.model$SpecialityItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SpecialityItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SpecialityItemList = (function (_super) {
__extends(SpecialityItemList, _super);
function SpecialityItemList(defaults) {
_super.apply(this, arguments);
}
SpecialityItemList.itemType = APIGateway_ISModel.SpecialityItemRec;
return SpecialityItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.SpecialityItemList = SpecialityItemList;

});
define("APIGateway_IS.model$CalculateBenefitConditionsUsageResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SpecialityItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculateBenefitConditionsUsageResponseRec = (function (_super) {
__extends(CalculateBenefitConditionsUsageResponseRec, _super);
function CalculateBenefitConditionsUsageResponseRec(defaults) {
_super.apply(this, arguments);
}
CalculateBenefitConditionsUsageResponseRec.attributesToDeclare = function () {
return [
this.attr("Specialities", "specialitiesAttr", "specialities", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SpecialityItemList());
}, true, APIGateway_ISModel.SpecialityItemList)
].concat(_super.attributesToDeclare.call(this));
};
CalculateBenefitConditionsUsageResponseRec.fromStructure = function (str) {
return new CalculateBenefitConditionsUsageResponseRec(new CalculateBenefitConditionsUsageResponseRec.RecordClass({
specialitiesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CalculateBenefitConditionsUsageResponseRec.init();
return CalculateBenefitConditionsUsageResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CalculateBenefitConditionsUsageResponseRec = CalculateBenefitConditionsUsageResponseRec;

});
define("APIGateway_IS.model$PHIPolicyRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPolicyRec = (function (_super) {
__extends(PHIPolicyRec, _super);
function PHIPolicyRec(defaults) {
_super.apply(this, arguments);
}
PHIPolicyRec.attributesToDeclare = function () {
return [
this.attr("policyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("classCode", "classCodeAttr", "classCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isCoverVariation", "isCoverVariationAttr", "isCoverVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("productTypeCode", "productTypeCodeAttr", "productTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("productType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("roleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "StartDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ProductName", "productNameAttr", "ProductName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIPolicyRec.init();
return PHIPolicyRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPolicyRec = PHIPolicyRec;

});
define("APIGateway_IS.model$PHIPolicyList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPolicyRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPolicyList = (function (_super) {
__extends(PHIPolicyList, _super);
function PHIPolicyList(defaults) {
_super.apply(this, arguments);
}
PHIPolicyList.itemType = APIGateway_ISModel.PHIPolicyRec;
return PHIPolicyList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIPolicyList = PHIPolicyList;

});
define("APIGateway_IS.model$PHIPhoneRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPhoneRec = (function (_super) {
__extends(PHIPhoneRec, _super);
function PHIPhoneRec(defaults) {
_super.apply(this, arguments);
}
PHIPhoneRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("isPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("phoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIPhoneRec.init();
return PHIPhoneRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPhoneRec = PHIPhoneRec;

});
define("APIGateway_IS.model$PHIPhoneList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPhoneRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPhoneList = (function (_super) {
__extends(PHIPhoneList, _super);
function PHIPhoneList(defaults) {
_super.apply(this, arguments);
}
PHIPhoneList.itemType = APIGateway_ISModel.PHIPhoneRec;
return PHIPhoneList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIPhoneList = PHIPhoneList;

});
define("APIGateway_IS.model$PHIEmailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIEmailRec = (function (_super) {
__extends(PHIEmailRec, _super);
function PHIEmailRec(defaults) {
_super.apply(this, arguments);
}
PHIEmailRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("emailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIEmailRec.init();
return PHIEmailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIEmailRec = PHIEmailRec;

});
define("APIGateway_IS.model$PHIEmailList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIEmailRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIEmailList = (function (_super) {
__extends(PHIEmailList, _super);
function PHIEmailList(defaults) {
_super.apply(this, arguments);
}
PHIEmailList.itemType = APIGateway_ISModel.PHIEmailRec;
return PHIEmailList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIEmailList = PHIEmailList;

});
define("APIGateway_IS.model$PHIAddressRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIAddressRec = (function (_super) {
__extends(PHIAddressRec, _super);
function PHIAddressRec(defaults) {
_super.apply(this, arguments);
}
PHIAddressRec.attributesToDeclare = function () {
return [
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("effectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stateTerritory", "stateTerritoryAttr", "stateTerritory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("countryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("country", "countryAttr", "country", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("city", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("zipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isReturnedMail", "isReturnedMailAttr", "isReturnedMail", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIAddressRec.init();
return PHIAddressRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIAddressRec = PHIAddressRec;

});
define("APIGateway_IS.model$PHIAddressList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIAddressRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIAddressList = (function (_super) {
__extends(PHIAddressList, _super);
function PHIAddressList(defaults) {
_super.apply(this, arguments);
}
PHIAddressList.itemType = APIGateway_ISModel.PHIAddressRec;
return PHIAddressList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIAddressList = PHIAddressList;

});
define("APIGateway_IS.model$PHIFlagRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIFlagRec = (function (_super) {
__extends(PHIFlagRec, _super);
function PHIFlagRec(defaults) {
_super.apply(this, arguments);
}
PHIFlagRec.attributesToDeclare = function () {
return [
this.attr("name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIFlagRec.init();
return PHIFlagRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIFlagRec = PHIFlagRec;

});
define("APIGateway_IS.model$PHIFlagList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIFlagRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIFlagList = (function (_super) {
__extends(PHIFlagList, _super);
function PHIFlagList(defaults) {
_super.apply(this, arguments);
}
PHIFlagList.itemType = APIGateway_ISModel.PHIFlagRec;
return PHIFlagList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIFlagList = PHIFlagList;

});
define("APIGateway_IS.model$PHIStakeholderSearchRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPolicyList", "APIGateway_IS.model$PHIPhoneList", "APIGateway_IS.model$PHIEmailList", "APIGateway_IS.model$PHIAddressList", "APIGateway_IS.model$PHIFlagList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchRec = (function (_super) {
__extends(PHIStakeholderSearchRec, _super);
function PHIStakeholderSearchRec(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchRec.attributesToDeclare = function () {
return [
this.attr("stakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Id", "idAttr", "Id", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("relevance", "relevanceAttr", "relevance", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("dateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("policies", "policiesAttr", "policies", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIPolicyList());
}, true, APIGateway_ISModel.PHIPolicyList), 
this.attr("phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIPhoneList());
}, true, APIGateway_ISModel.PHIPhoneList), 
this.attr("emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIEmailList());
}, true, APIGateway_ISModel.PHIEmailList), 
this.attr("addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIAddressList());
}, true, APIGateway_ISModel.PHIAddressList), 
this.attr("flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIFlagList());
}, true, APIGateway_ISModel.PHIFlagList)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderSearchRec.init();
return PHIStakeholderSearchRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIStakeholderSearchRec = PHIStakeholderSearchRec;

});
define("APIGateway_IS.model$CalculateRatesQuotes_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemList", "APIGateway_IS.model$FrequencyQuoteItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculateRatesQuotes_APIRec = (function (_super) {
__extends(CalculateRatesQuotes_APIRec, _super);
function CalculateRatesQuotes_APIRec(defaults) {
_super.apply(this, arguments);
}
CalculateRatesQuotes_APIRec.attributesToDeclare = function () {
return [
this.attr("RatesQuoteRevisionId", "ratesQuoteRevisionIdAttr", "ratesQuoteRevisionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EligibilityReasonCode", "eligibilityReasonCodeAttr", "eligibilityReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilitySubReasonCode", "eligibilitySubReasonCodeAttr", "eligibilitySubReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Cover", "coverAttr", "cover", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ResidencyStatus", "residencyStatusAttr", "residencyStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IgnoreMembershipConditions", "ignoreMembershipConditionsAttr", "ignoreMembershipConditions", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HealthRateScaleCode", "healthRateScaleCodeAttr", "healthRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateAge", "rebateAgeAttr", "rebateAge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateTier", "rebateTierAttr", "rebateTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Members", "membersAttr", "members", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItemList());
}, true, APIGateway_ISModel.MemberItemList), 
this.attr("FrequencyQuotes", "frequencyQuotesAttr", "frequencyQuotes", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FrequencyQuoteItemList());
}, true, APIGateway_ISModel.FrequencyQuoteItemList), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Site", "siteAttr", "site", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Badge", "badgeAttr", "badge", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CalculateRatesQuotes_APIRec.init();
return CalculateRatesQuotes_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CalculateRatesQuotes_APIRec = CalculateRatesQuotes_APIRec;

});
define("APIGateway_IS.model$CalculateRatesQuotes_APIList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CalculateRatesQuotes_APIRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculateRatesQuotes_APIList = (function (_super) {
__extends(CalculateRatesQuotes_APIList, _super);
function CalculateRatesQuotes_APIList(defaults) {
_super.apply(this, arguments);
}
CalculateRatesQuotes_APIList.itemType = APIGateway_ISModel.CalculateRatesQuotes_APIRec;
return CalculateRatesQuotes_APIList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.CalculateRatesQuotes_APIList = CalculateRatesQuotes_APIList;

});
define("APIGateway_IS.model$AddRatesQuote_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CalculateRatesQuotes_APIList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddRatesQuote_APIRec = (function (_super) {
__extends(AddRatesQuote_APIRec, _super);
function AddRatesQuote_APIRec(defaults) {
_super.apply(this, arguments);
}
AddRatesQuote_APIRec.attributesToDeclare = function () {
return [
this.attr("RatesQuoteId", "ratesQuoteIdAttr", "ratesQuoteId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("QuoteStatus", "quoteStatusAttr", "quoteStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Revisions", "revisionsAttr", "revisions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CalculateRatesQuotes_APIList());
}, true, APIGateway_ISModel.CalculateRatesQuotes_APIList)
].concat(_super.attributesToDeclare.call(this));
};
AddRatesQuote_APIRec.init();
return AddRatesQuote_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddRatesQuote_APIRec = AddRatesQuote_APIRec;

});
define("APIGateway_IS.model$PolicyRebateList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRebateRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRebateList = (function (_super) {
__extends(PolicyRebateList, _super);
function PolicyRebateList(defaults) {
_super.apply(this, arguments);
}
PolicyRebateList.itemType = APIGateway_ISModel.PolicyRebateRec;
return PolicyRebateList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyRebateList = PolicyRebateList;

});
define("APIGateway_IS.model$GetPolicyRebateDetails_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRebateList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyRebateDetails_APIResponseRec = (function (_super) {
__extends(GetPolicyRebateDetails_APIResponseRec, _super);
function GetPolicyRebateDetails_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyRebateDetails_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Rebates", "rebatesAttr", "rebates", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRebateList());
}, true, APIGateway_ISModel.PolicyRebateList)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyRebateDetails_APIResponseRec.fromStructure = function (str) {
return new GetPolicyRebateDetails_APIResponseRec(new GetPolicyRebateDetails_APIResponseRec.RecordClass({
rebatesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPolicyRebateDetails_APIResponseRec.init();
return GetPolicyRebateDetails_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyRebateDetails_APIResponseRec = GetPolicyRebateDetails_APIResponseRec;

});
define("APIGateway_IS.model$AddressesRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressesRec = (function (_super) {
__extends(AddressesRec, _super);
function AddressesRec(defaults) {
_super.apply(this, arguments);
}
AddressesRec.attributesToDeclare = function () {
return [
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("IsReturnedMail", "isReturnedMailAttr", "isReturnedMail", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ZipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddressesRec.init();
return AddressesRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddressesRec = AddressesRec;

});
define("APIGateway_IS.model$CalculatePolicyClass_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculatePolicyClass_APIRec = (function (_super) {
__extends(CalculatePolicyClass_APIRec, _super);
function CalculatePolicyClass_APIRec(defaults) {
_super.apply(this, arguments);
}
CalculatePolicyClass_APIRec.attributesToDeclare = function () {
return [
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CalculatePolicyClass_APIRec.fromStructure = function (str) {
return new CalculatePolicyClass_APIRec(new CalculatePolicyClass_APIRec.RecordClass({
policyClassAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CalculatePolicyClass_APIRec.init();
return CalculatePolicyClass_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CalculatePolicyClass_APIRec = CalculatePolicyClass_APIRec;

});
define("APIGateway_IS.model$SecondaryRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SecondaryRec = (function (_super) {
__extends(SecondaryRec, _super);
function SecondaryRec(defaults) {
_super.apply(this, arguments);
}
SecondaryRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SecondaryRec.init();
return SecondaryRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SecondaryRec = SecondaryRec;

});
define("APIGateway_IS.model$InterestLevelRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var InterestLevelRec = (function (_super) {
__extends(InterestLevelRec, _super);
function InterestLevelRec(defaults) {
_super.apply(this, arguments);
}
InterestLevelRec.attributesToDeclare = function () {
return [
this.attr("IsFollowUp", "isFollowUpAttr", "isFollowUp", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("InterestLevelCode", "interestLevelCodeAttr", "interestLevelCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FollowUpDueDate", "followUpDueDateAttr", "followUpDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
InterestLevelRec.init();
return InterestLevelRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.InterestLevelRec = InterestLevelRec;

});
define("APIGateway_IS.model$PhoneItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneItemRec = (function (_super) {
__extends(PhoneItemRec, _super);
function PhoneItemRec(defaults) {
_super.apply(this, arguments);
}
PhoneItemRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PhoneItemRec.init();
return PhoneItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PhoneItemRec = PhoneItemRec;

});
define("APIGateway_IS.model$PhoneItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PhoneItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneItemList = (function (_super) {
__extends(PhoneItemList, _super);
function PhoneItemList(defaults) {
_super.apply(this, arguments);
}
PhoneItemList.itemType = APIGateway_ISModel.PhoneItemRec;
return PhoneItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PhoneItemList = PhoneItemList;

});
define("APIGateway_IS.model$EmailItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailItem2Rec = (function (_super) {
__extends(EmailItem2Rec, _super);
function EmailItem2Rec(defaults) {
_super.apply(this, arguments);
}
EmailItem2Rec.attributesToDeclare = function () {
return [
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EmailItem2Rec.init();
return EmailItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EmailItem2Rec = EmailItem2Rec;

});
define("APIGateway_IS.model$EmailItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailItem2List = (function (_super) {
__extends(EmailItem2List, _super);
function EmailItem2List(defaults) {
_super.apply(this, arguments);
}
EmailItem2List.itemType = APIGateway_ISModel.EmailItem2Rec;
return EmailItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EmailItem2List = EmailItem2List;

});
define("APIGateway_IS.model$AddressItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItem2Rec = (function (_super) {
__extends(AddressItem2Rec, _super);
function AddressItem2Rec(defaults) {
_super.apply(this, arguments);
}
AddressItem2Rec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ZipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddressItem2Rec.init();
return AddressItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddressItem2Rec = AddressItem2Rec;

});
define("APIGateway_IS.model$AddressItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddressItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItem2List = (function (_super) {
__extends(AddressItem2List, _super);
function AddressItem2List(defaults) {
_super.apply(this, arguments);
}
AddressItem2List.itemType = APIGateway_ISModel.AddressItem2Rec;
return AddressItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddressItem2List = AddressItem2List;

});
define("APIGateway_IS.model$CommunicationPreferenceItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CommunicationPreferenceItem2Rec = (function (_super) {
__extends(CommunicationPreferenceItem2Rec, _super);
function CommunicationPreferenceItem2Rec(defaults) {
_super.apply(this, arguments);
}
CommunicationPreferenceItem2Rec.attributesToDeclare = function () {
return [
this.attr("Category", "categoryAttr", "category", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsMandatory", "isMandatoryAttr", "isMandatory", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CategoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredChannel", "preferredChannelAttr", "preferredChannel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SendCommunications", "sendCommunicationsAttr", "sendCommunications", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CommunicationPreferenceItem2Rec.init();
return CommunicationPreferenceItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CommunicationPreferenceItem2Rec = CommunicationPreferenceItem2Rec;

});
define("APIGateway_IS.model$AssociationItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AssociationItem2Rec = (function (_super) {
__extends(AssociationItem2Rec, _super);
function AssociationItem2Rec(defaults) {
_super.apply(this, arguments);
}
AssociationItem2Rec.attributesToDeclare = function () {
return [
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationNumber", "associationNumberAttr", "associationNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationTypeCode", "associationTypeCodeAttr", "associationTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AssociationItem2Rec.init();
return AssociationItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AssociationItem2Rec = AssociationItem2Rec;

});
define("APIGateway_IS.model$AssociationItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AssociationItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AssociationItem2List = (function (_super) {
__extends(AssociationItem2List, _super);
function AssociationItem2List(defaults) {
_super.apply(this, arguments);
}
AssociationItem2List.itemType = APIGateway_ISModel.AssociationItem2Rec;
return AssociationItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AssociationItem2List = AssociationItem2List;

});
define("APIGateway_IS.model$CardItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CardItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CardItem2List = (function (_super) {
__extends(CardItem2List, _super);
function CardItem2List(defaults) {
_super.apply(this, arguments);
}
CardItem2List.itemType = APIGateway_ISModel.CardItem2Rec;
return CardItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.CardItem2List = CardItem2List;

});
define("APIGateway_IS.model$PreexistingConditionItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreexistingConditionItem2Rec = (function (_super) {
__extends(PreexistingConditionItem2Rec, _super);
function PreexistingConditionItem2Rec(defaults) {
_super.apply(this, arguments);
}
PreexistingConditionItem2Rec.attributesToDeclare = function () {
return [
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreexistingConditionCode", "preexistingConditionCodeAttr", "preexistingConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PreexistingConditionItem2Rec.init();
return PreexistingConditionItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreexistingConditionItem2Rec = PreexistingConditionItem2Rec;

});
define("APIGateway_IS.model$PreexistingConditionItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreexistingConditionItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreexistingConditionItem2List = (function (_super) {
__extends(PreexistingConditionItem2List, _super);
function PreexistingConditionItem2List(defaults) {
_super.apply(this, arguments);
}
PreexistingConditionItem2List.itemType = APIGateway_ISModel.PreexistingConditionItem2Rec;
return PreexistingConditionItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PreexistingConditionItem2List = PreexistingConditionItem2List;

});
define("APIGateway_IS.model$LeadRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyEligibilityReasonRec", "APIGateway_IS.model$InterestLevelRec", "APIGateway_IS.model$PhoneItemList", "APIGateway_IS.model$EmailItem2List", "APIGateway_IS.model$AddressItem2List", "APIGateway_IS.model$CommunicationPreferenceItem2Rec", "APIGateway_IS.model$AssociationItem2List", "APIGateway_IS.model$CardItem2List", "APIGateway_IS.model$PreexistingConditionItem2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var LeadRec = (function (_super) {
__extends(LeadRec, _super);
function LeadRec(defaults) {
_super.apply(this, arguments);
}
LeadRec.attributesToDeclare = function () {
return [
this.attr("TitleCode", "titleCodeAttr", "titleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RankCode", "rankCodeAttr", "rankCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsOther", "pronounsOtherAttr", "pronounsOther", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EligibilityReason", "eligibilityReasonAttr", "eligibilityReason", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyEligibilityReasonRec());
}, true, APIGateway_ISModel.PolicyEligibilityReasonRec), 
this.attr("InterestLevel", "interestLevelAttr", "interestLevel", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.InterestLevelRec());
}, true, APIGateway_ISModel.InterestLevelRec), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneItemList());
}, true, APIGateway_ISModel.PhoneItemList), 
this.attr("Emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItem2List());
}, true, APIGateway_ISModel.EmailItem2List), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItem2List());
}, true, APIGateway_ISModel.AddressItem2List), 
this.attr("CommunicationPreference", "communicationPreferenceAttr", "communicationPreference", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItem2Rec());
}, true, APIGateway_ISModel.CommunicationPreferenceItem2Rec), 
this.attr("Associations", "associationsAttr", "associations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AssociationItem2List());
}, true, APIGateway_ISModel.AssociationItem2List), 
this.attr("Cards", "cardsAttr", "cards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CardItem2List());
}, true, APIGateway_ISModel.CardItem2List), 
this.attr("PreexistingConditions", "preexistingConditionsAttr", "preexistingConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreexistingConditionItem2List());
}, true, APIGateway_ISModel.PreexistingConditionItem2List)
].concat(_super.attributesToDeclare.call(this));
};
LeadRec.init();
return LeadRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.LeadRec = LeadRec;

});
define("APIGateway_IS.model$AddRatesQuote_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemList", "APIGateway_IS.model$LeadRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddRatesQuote_APIRequestRec = (function (_super) {
__extends(AddRatesQuote_APIRequestRec, _super);
function AddRatesQuote_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
AddRatesQuote_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("QuoteId", "quoteIdAttr", "ratesQuoteId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RebateAge", "rebateAgeAttr", "rebateAge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateTier", "rebateTierAttr", "rebateTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilityReasonCode", "eligibilityReasonCodeAttr", "eligibilityReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilitySubReasonCode", "eligibilitySubReasonCodeAttr", "eligibilitySubReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Members", "membersAttr", "members", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItemList());
}, true, APIGateway_ISModel.MemberItemList), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Lead", "leadAttr", "lead", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LeadRec());
}, true, APIGateway_ISModel.LeadRec), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IgnoreMembershipConditions", "ignoreMembershipConditionsAttr", "ignoreMembershipConditions", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ResidencyStatus", "residencyStatusAttr", "ResidencyStatus", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddRatesQuote_APIRequestRec.init();
return AddRatesQuote_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddRatesQuote_APIRequestRec = AddRatesQuote_APIRequestRec;

});
define("APIGateway_IS.model$Product_RevisionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RevisionRec = (function (_super) {
__extends(Product_RevisionRec, _super);
function Product_RevisionRec(defaults) {
_super.apply(this, arguments);
}
Product_RevisionRec.attributesToDeclare = function () {
return [
this.attr("ProductRevisionsId", "productRevisionsIdAttr", "productRevisionsId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Product_RevisionRec.init();
return Product_RevisionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_RevisionRec = Product_RevisionRec;

});
define("APIGateway_IS.model$GetPrintersResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPrintersResponseRec = (function (_super) {
__extends(GetPrintersResponseRec, _super);
function GetPrintersResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPrintersResponseRec.attributesToDeclare = function () {
return [
this.attr("PrinterName", "printerNameAttr", "printerName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetPrintersResponseRec.fromStructure = function (str) {
return new GetPrintersResponseRec(new GetPrintersResponseRec.RecordClass({
printerNameAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPrintersResponseRec.init();
return GetPrintersResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPrintersResponseRec = GetPrintersResponseRec;

});
define("APIGateway_IS.model$Product_RateItem_FrequencyFundRateList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RateItem_FrequencyFundRateRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateItem_FrequencyFundRateList = (function (_super) {
__extends(Product_RateItem_FrequencyFundRateList, _super);
function Product_RateItem_FrequencyFundRateList(defaults) {
_super.apply(this, arguments);
}
Product_RateItem_FrequencyFundRateList.itemType = APIGateway_ISModel.Product_RateItem_FrequencyFundRateRec;
return Product_RateItem_FrequencyFundRateList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_RateItem_FrequencyFundRateList = Product_RateItem_FrequencyFundRateList;

});
define("APIGateway_IS.model$Product_RateItem_RevisionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RateItem_FrequencyFundRateList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateItem_RevisionRec = (function (_super) {
__extends(Product_RateItem_RevisionRec, _super);
function Product_RateItem_RevisionRec(defaults) {
_super.apply(this, arguments);
}
Product_RateItem_RevisionRec.attributesToDeclare = function () {
return [
this.attr("RateRevisionId", "rateRevisionIdAttr", "rateRevisionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EndChildAge", "endChildAgeAttr", "endChildAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EndStudentAge", "endStudentAgeAttr", "endStudentAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BillPublishDate", "billPublishDateAttr", "billPublishDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ContributionPublishDate", "contributionPublishDateAttr", "contributionPublishDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DiscountBase", "discountBaseAttr", "discountBase", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubsidyBase", "subsidyBaseAttr", "subsidyBase", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsDiscountOnFullContributionPeriod", "isDiscountOnFullContributionPeriodAttr", "isDiscountOnFullContributionPeriod", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IgnoreGroupDiscount", "ignoreGroupDiscountAttr", "ignoreGroupDiscount", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("FrequencyFundRates", "frequencyFundRatesAttr", "frequencyFundRates", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_RateItem_FrequencyFundRateList());
}, true, APIGateway_ISModel.Product_RateItem_FrequencyFundRateList)
].concat(_super.attributesToDeclare.call(this));
};
Product_RateItem_RevisionRec.init();
return Product_RateItem_RevisionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_RateItem_RevisionRec = Product_RateItem_RevisionRec;

});
define("APIGateway_IS.model$Product_RateItem_RevisionList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RateItem_RevisionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateItem_RevisionList = (function (_super) {
__extends(Product_RateItem_RevisionList, _super);
function Product_RateItem_RevisionList(defaults) {
_super.apply(this, arguments);
}
Product_RateItem_RevisionList.itemType = APIGateway_ISModel.Product_RateItem_RevisionRec;
return Product_RateItem_RevisionList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_RateItem_RevisionList = Product_RateItem_RevisionList;

});
define("APIGateway_IS.model$Product_RateRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RateItem_RevisionList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateRec = (function (_super) {
__extends(Product_RateRec, _super);
function Product_RateRec(defaults) {
_super.apply(this, arguments);
}
Product_RateRec.attributesToDeclare = function () {
return [
this.attr("ContributionRateId", "contributionRateIdAttr", "contributionRateId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductRateScaleCode", "productRateScaleCodeAttr", "productRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HospitalPolicyClass", "hospitalPolicyClassAttr", "hospitalPolicyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PaymentMethod", "paymentMethodAttr", "paymentMethod", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsUsed", "isUsedAttr", "isUsed", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AdjustmentRatio", "adjustmentRatioAttr", "adjustmentRatio", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AdjustmentScale", "adjustmentScaleAttr", "adjustmentScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsGst", "isGstAttr", "isGst", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CommissionFlatRate", "commissionFlatRateAttr", "commissionFlatRate", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CommissiomPercentage", "commissiomPercentageAttr", "commissiomPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("IsComprehensive", "isComprehensiveAttr", "isComprehensive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("SisCode1", "sisCode1Attr", "sisCode1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Revisions", "revisionsAttr", "revisions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_RateItem_RevisionList());
}, true, APIGateway_ISModel.Product_RateItem_RevisionList)
].concat(_super.attributesToDeclare.call(this));
};
Product_RateRec.init();
return Product_RateRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_RateRec = Product_RateRec;

});
define("APIGateway_IS.model$RequestReferenceDataRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RequestReferenceDataRec = (function (_super) {
__extends(RequestReferenceDataRec, _super);
function RequestReferenceDataRec(defaults) {
_super.apply(this, arguments);
}
RequestReferenceDataRec.attributesToDeclare = function () {
return [
this.attr("activeAsAtDate", "activeAsAtDateAttr", "activeAsAtDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("includeTotalCount", "includeTotalCountAttr", "includeTotalCount", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RequestReferenceDataRec.init();
return RequestReferenceDataRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.RequestReferenceDataRec = RequestReferenceDataRec;

});
define("APIGateway_IS.model$PHINote_Search_ResultSet_ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHINote_Search_ResultRec", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIProblemDetailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHINote_Search_ResultSet_ResponseRec = (function (_super) {
__extends(PHINote_Search_ResultSet_ResponseRec, _super);
function PHINote_Search_ResultSet_ResponseRec(defaults) {
_super.apply(this, arguments);
}
PHINote_Search_ResultSet_ResponseRec.attributesToDeclare = function () {
return [
this.attr("PHINote_Search_Result", "pHINote_Search_ResultAttr", "NoteDtoSearchResult", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHINote_Search_ResultRec());
}, true, APIGateway_ISModel.PHINote_Search_ResultRec), 
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
PHINote_Search_ResultSet_ResponseRec.init();
return PHINote_Search_ResultSet_ResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHINote_Search_ResultSet_ResponseRec = PHINote_Search_ResultSet_ResponseRec;

});
define("APIGateway_IS.model$FlagItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItemRec = (function (_super) {
__extends(FlagItemRec, _super);
function FlagItemRec(defaults) {
_super.apply(this, arguments);
}
FlagItemRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagCode", "flagCodeAttr", "flagCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagType", "flagTypeAttr", "flagType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsRestricted", "isRestrictedAttr", "isRestricted", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FlagItemRec.init();
return FlagItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.FlagItemRec = FlagItemRec;

});
define("APIGateway_IS.model$PreviewItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviewItemRec = (function (_super) {
__extends(PreviewItemRec, _super);
function PreviewItemRec(defaults) {
_super.apply(this, arguments);
}
PreviewItemRec.attributesToDeclare = function () {
return [
this.attr("Url", "urlAttr", "url", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PreviewItemRec.init();
return PreviewItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreviewItemRec = PreviewItemRec;

});
define("APIGateway_IS.model$PHICreateNote_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICreateNote_RequestRec = (function (_super) {
__extends(PHICreateNote_RequestRec, _super);
function PHICreateNote_RequestRec(defaults) {
_super.apply(this, arguments);
}
PHICreateNote_RequestRec.attributesToDeclare = function () {
return [
this.attr("entityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("entityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("noteTypeCode", "noteTypeCodeAttr", "noteTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("subject", "subjectAttr", "subject", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("note", "noteAttr", "note", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("raisedBy", "raisedByAttr", "raisedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isPriorityNote", "isPriorityNoteAttr", "isPriorityNote", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("priorityNoteExpiryDate", "priorityNoteExpiryDateAttr", "priorityNoteExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICreateNote_RequestRec.init();
return PHICreateNote_RequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICreateNote_RequestRec = PHICreateNote_RequestRec;

});
define("APIGateway_IS.model$LeadItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var LeadItemRec = (function (_super) {
__extends(LeadItemRec, _super);
function LeadItemRec(defaults) {
_super.apply(this, arguments);
}
LeadItemRec.attributesToDeclare = function () {
return [
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("InterestLevelCode", "interestLevelCodeAttr", "interestLevelCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("InterestLevel", "interestLevelAttr", "interestLevel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CancellationReasonCode", "cancellationReasonCodeAttr", "cancellationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CancellationReason", "cancellationReasonAttr", "cancellationReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsFollowUp", "isFollowUpAttr", "isFollowUp", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("FollowUpDueDate", "followUpDueDateAttr", "followUpDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LeadItemRec.init();
return LeadItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.LeadItemRec = LeadItemRec;

});
define("APIGateway_IS.model$GetIndividual_HAMBS_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MedicareRec", "APIGateway_IS.model$LeadItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetIndividual_HAMBS_Response_APIRec = (function (_super) {
__extends(GetIndividual_HAMBS_Response_APIRec, _super);
function GetIndividual_HAMBS_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
GetIndividual_HAMBS_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("StakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderStatus", "stakeholderStatusAttr", "stakeholderStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TitleCode", "titleCodeAttr", "titleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RankCode", "rankCodeAttr", "rankCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Rank", "rankAttr", "rank", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Sex", "sexAttr", "sex", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Age", "ageAttr", "age", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsContributor", "isContributorAttr", "isContributor", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDelegatedAuthority", "isDelegatedAuthorityAttr", "isDelegatedAuthority", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DiscountAge", "discountAgeAttr", "discountAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("MedicareCard", "medicareCardAttr", "medicareCard", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MedicareRec());
}, true, APIGateway_ISModel.MedicareRec), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Lead", "leadAttr", "lead", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LeadItemRec());
}, true, APIGateway_ISModel.LeadItemRec), 
this.attr("Pronouns", "pronounsAttr", "pronouns", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LhcOverride", "lhcOverrideAttr", "lhcOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcPercentage", "lhcPercentageAttr", "lhcPercentage", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AbdEntryAge", "abdEntryAgeAttr", "abdEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AbdEffectiveDate", "abdEffectiveDateAttr", "abdEffectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetIndividual_HAMBS_Response_APIRec.init();
return GetIndividual_HAMBS_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetIndividual_HAMBS_Response_APIRec = GetIndividual_HAMBS_Response_APIRec;

});
define("APIGateway_IS.model$DocumentItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DocumentItemRec = (function (_super) {
__extends(DocumentItemRec, _super);
function DocumentItemRec(defaults) {
_super.apply(this, arguments);
}
DocumentItemRec.attributesToDeclare = function () {
return [
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FileName", "fileNameAttr", "fileName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DocumentId", "documentIdAttr", "documentId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DocumentItemRec.init();
return DocumentItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.DocumentItemRec = DocumentItemRec;

});
define("APIGateway_IS.model$MailingRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MailingRec = (function (_super) {
__extends(MailingRec, _super);
function MailingRec(defaults) {
_super.apply(this, arguments);
}
MailingRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MailingRec.init();
return MailingRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.MailingRec = MailingRec;

});
define("APIGateway_IS.model$Stakeholder_PatchItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_PatchItemRec = (function (_super) {
__extends(Stakeholder_PatchItemRec, _super);
function Stakeholder_PatchItemRec(defaults) {
_super.apply(this, arguments);
}
Stakeholder_PatchItemRec.attributesToDeclare = function () {
return [
this.attr("Op", "opAttr", "op", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Path", "pathAttr", "path", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Stakeholder_PatchItemRec.init();
return Stakeholder_PatchItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Stakeholder_PatchItemRec = Stakeholder_PatchItemRec;

});
define("APIGateway_IS.model$PreviewItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreviewItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviewItemList = (function (_super) {
__extends(PreviewItemList, _super);
function PreviewItemList(defaults) {
_super.apply(this, arguments);
}
PreviewItemList.itemType = APIGateway_ISModel.PreviewItemRec;
return PreviewItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PreviewItemList = PreviewItemList;

});
define("APIGateway_IS.model$QueueCommunication_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreviewItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var QueueCommunication_APIResponseRec = (function (_super) {
__extends(QueueCommunication_APIResponseRec, _super);
function QueueCommunication_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
QueueCommunication_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("CommunicationId", "communicationIdAttr", "communicationId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("InteractiveURL", "interactiveURLAttr", "interactiveURL", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Previews", "previewsAttr", "previews", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreviewItemList());
}, true, APIGateway_ISModel.PreviewItemList)
].concat(_super.attributesToDeclare.call(this));
};
QueueCommunication_APIResponseRec.init();
return QueueCommunication_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.QueueCommunication_APIResponseRec = QueueCommunication_APIResponseRec;

});
define("APIGateway_IS.model$EmailItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailItemList = (function (_super) {
__extends(EmailItemList, _super);
function EmailItemList(defaults) {
_super.apply(this, arguments);
}
EmailItemList.itemType = APIGateway_ISModel.EmailItemRec;
return EmailItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EmailItemList = EmailItemList;

});
define("APIGateway_IS.model$PhoneNumberItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PhoneNumberItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PhoneNumberItemList = (function (_super) {
__extends(PhoneNumberItemList, _super);
function PhoneNumberItemList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberItemList.itemType = APIGateway_ISModel.PhoneNumberItemRec;
return PhoneNumberItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PhoneNumberItemList = PhoneNumberItemList;

});
define("APIGateway_IS.model$AddressItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddressItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressItemList = (function (_super) {
__extends(AddressItemList, _super);
function AddressItemList(defaults) {
_super.apply(this, arguments);
}
AddressItemList.itemType = APIGateway_ISModel.AddressItemRec;
return AddressItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddressItemList = AddressItemList;

});
define("APIGateway_IS.model$CommunicationPreferenceItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CommunicationPreferenceItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CommunicationPreferenceItemList = (function (_super) {
__extends(CommunicationPreferenceItemList, _super);
function CommunicationPreferenceItemList(defaults) {
_super.apply(this, arguments);
}
CommunicationPreferenceItemList.itemType = APIGateway_ISModel.CommunicationPreferenceItemRec;
return CommunicationPreferenceItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.CommunicationPreferenceItemList = CommunicationPreferenceItemList;

});
define("APIGateway_IS.model$ContactDetailV1_ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailItemList", "APIGateway_IS.model$PhoneNumberItemList", "APIGateway_IS.model$AddressItemList", "APIGateway_IS.model$CommunicationPreferenceItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ContactDetailV1_ResponseRec = (function (_super) {
__extends(ContactDetailV1_ResponseRec, _super);
function ContactDetailV1_ResponseRec(defaults) {
_super.apply(this, arguments);
}
ContactDetailV1_ResponseRec.attributesToDeclare = function () {
return [
this.attr("Emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItemList());
}, true, APIGateway_ISModel.EmailItemList), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemList());
}, true, APIGateway_ISModel.PhoneNumberItemList), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItemList());
}, true, APIGateway_ISModel.AddressItemList), 
this.attr("CommunicationPreferences", "communicationPreferencesAttr", "communicationPreferences", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItemList());
}, true, APIGateway_ISModel.CommunicationPreferenceItemList)
].concat(_super.attributesToDeclare.call(this));
};
ContactDetailV1_ResponseRec.init();
return ContactDetailV1_ResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ContactDetailV1_ResponseRec = ContactDetailV1_ResponseRec;

});
define("APIGateway_IS.model$Product_WaitingPeriodRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_WaitingPeriodRec = (function (_super) {
__extends(Product_WaitingPeriodRec, _super);
function Product_WaitingPeriodRec(defaults) {
_super.apply(this, arguments);
}
Product_WaitingPeriodRec.attributesToDeclare = function () {
return [
this.attr("WaitPeriodCode", "waitPeriodCodeAttr", "waitPeriodCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitPeriod", "waitPeriodAttr", "waitPeriod", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WaitPeriodDuration", "waitPeriodDurationAttr", "waitPeriodDuration", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("WaitUnit", "waitUnitAttr", "waitUnit", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ComponentScale", "componentScaleAttr", "componentScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DefaultWaiveReasonCode", "defaultWaiveReasonCodeAttr", "defaultWaiveReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DefaultWaiveReason", "defaultWaiveReasonAttr", "defaultWaiveReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DefaultEndDate", "defaultEndDateAttr", "defaultEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Product_WaitingPeriodRec.init();
return Product_WaitingPeriodRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Product_WaitingPeriodRec = Product_WaitingPeriodRec;

});
define("APIGateway_IS.model$PolicyRoleItem2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem2Rec = (function (_super) {
__extends(PolicyRoleItem2Rec, _super);
function PolicyRoleItem2Rec(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem2Rec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RoleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Role", "roleAttr", "role", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsCoverVariation", "isCoverVariationAttr", "isCoverVariation", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRoleItem2Rec.init();
return PolicyRoleItem2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyRoleItem2Rec = PolicyRoleItem2Rec;

});
define("APIGateway_IS.model$PolicyRoleItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem2List = (function (_super) {
__extends(PolicyRoleItem2List, _super);
function PolicyRoleItem2List(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem2List.itemType = APIGateway_ISModel.PolicyRoleItem2Rec;
return PolicyRoleItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyRoleItem2List = PolicyRoleItem2List;

});
define("APIGateway_IS.model$FlagItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$FlagItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var FlagItemList = (function (_super) {
__extends(FlagItemList, _super);
function FlagItemList(defaults) {
_super.apply(this, arguments);
}
FlagItemList.itemType = APIGateway_ISModel.FlagItemRec;
return FlagItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.FlagItemList = FlagItemList;

});
define("APIGateway_IS.model$SearchResultItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItem2List", "APIGateway_IS.model$PhoneNumberItemList", "APIGateway_IS.model$EmailItemRec", "APIGateway_IS.model$AddressItemList", "APIGateway_IS.model$FlagItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchResultItemRec = (function (_super) {
__extends(SearchResultItemRec, _super);
function SearchResultItemRec(defaults) {
_super.apply(this, arguments);
}
SearchResultItemRec.attributesToDeclare = function () {
return [
this.attr("StakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsContributor", "isContributorAttr", "isContributor", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDelegatedAuthority", "isDelegatedAuthorityAttr", "isDelegatedAuthority", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Relevance", "relevanceAttr", "relevance", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderStatus", "stakeholderStatusAttr", "stakeholderStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyRoles", "policyRolesAttr", "policyRoles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRoleItem2List());
}, true, APIGateway_ISModel.PolicyRoleItem2List), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemList());
}, true, APIGateway_ISModel.PhoneNumberItemList), 
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItemRec());
}, true, APIGateway_ISModel.EmailItemRec), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItemList());
}, true, APIGateway_ISModel.AddressItemList), 
this.attr("Flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FlagItemList());
}, true, APIGateway_ISModel.FlagItemList), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchResultItemRec.init();
return SearchResultItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchResultItemRec = SearchResultItemRec;

});
define("APIGateway_IS.model$SearchResultItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SearchResultItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchResultItemList = (function (_super) {
__extends(SearchResultItemList, _super);
function SearchResultItemList(defaults) {
_super.apply(this, arguments);
}
SearchResultItemList.itemType = APIGateway_ISModel.SearchResultItemRec;
return SearchResultItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.SearchResultItemList = SearchResultItemList;

});
define("APIGateway_IS.model$SearchIndividuals_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SearchResultItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchIndividuals_APIResponseRec = (function (_super) {
__extends(SearchIndividuals_APIResponseRec, _super);
function SearchIndividuals_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
SearchIndividuals_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SearchResultItemList());
}, true, APIGateway_ISModel.SearchResultItemList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchIndividuals_APIResponseRec.init();
return SearchIndividuals_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchIndividuals_APIResponseRec = SearchIndividuals_APIResponseRec;

});
define("APIGateway_IS.model$InterimRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var InterimRec = (function (_super) {
__extends(InterimRec, _super);
function InterimRec(defaults) {
_super.apply(this, arguments);
}
InterimRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SecondName", "secondNameAttr", "secondName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MedicareCardIrn", "medicareCardIrnAttr", "medicareCardIrn", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("MedicareCardNumber", "medicareCardNumberAttr", "medicareCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
InterimRec.init();
return InterimRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.InterimRec = InterimRec;

});
define("APIGateway_IS.model$SecondaryList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SecondaryRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SecondaryList = (function (_super) {
__extends(SecondaryList, _super);
function SecondaryList(defaults) {
_super.apply(this, arguments);
}
SecondaryList.itemType = APIGateway_ISModel.SecondaryRec;
return SecondaryList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.SecondaryList = SecondaryList;

});
define("APIGateway_IS.model$HomeRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var HomeRec = (function (_super) {
__extends(HomeRec, _super);
function HomeRec(defaults) {
_super.apply(this, arguments);
}
HomeRec.attributesToDeclare = function () {
return [
this.attr("City", "cityAttr", "city", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line1", "line1Attr", "line1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Line2", "line2Attr", "line2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Suburb", "suburbAttr", "suburb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "country", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Postcode", "postcodeAttr", "postcode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverseas", "isOverseasAttr", "isOverseas", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CountryCode", "countryCodeAttr", "countryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StateProvince", "stateProvinceAttr", "stateProvince", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ZipPostalCode", "zipPostalCodeAttr", "zipPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsPreferred", "isPreferredAttr", "isPreferred", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HomeRec.init();
return HomeRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.HomeRec = HomeRec;

});
define("APIGateway_IS.model$HomeList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$HomeRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var HomeList = (function (_super) {
__extends(HomeList, _super);
function HomeList(defaults) {
_super.apply(this, arguments);
}
HomeList.itemType = APIGateway_ISModel.HomeRec;
return HomeList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.HomeList = HomeList;

});
define("APIGateway_IS.model$CommunicationPreferenceItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CommunicationPreferenceItem2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CommunicationPreferenceItem2List = (function (_super) {
__extends(CommunicationPreferenceItem2List, _super);
function CommunicationPreferenceItem2List(defaults) {
_super.apply(this, arguments);
}
CommunicationPreferenceItem2List.itemType = APIGateway_ISModel.CommunicationPreferenceItem2Rec;
return CommunicationPreferenceItem2List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.CommunicationPreferenceItem2List = CommunicationPreferenceItem2List;

});
define("APIGateway_IS.model$ContactDetail2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SecondaryList", "APIGateway_IS.model$HomeList", "APIGateway_IS.model$CommunicationPreferenceItem2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ContactDetail2Rec = (function (_super) {
__extends(ContactDetail2Rec, _super);
function ContactDetail2Rec(defaults) {
_super.apply(this, arguments);
}
ContactDetail2Rec.attributesToDeclare = function () {
return [
this.attr("Emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SecondaryList());
}, true, APIGateway_ISModel.SecondaryList), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.HomeList());
}, true, APIGateway_ISModel.HomeList), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.HomeList());
}, true, APIGateway_ISModel.HomeList), 
this.attr("CommunicationPreferences", "communicationPreferencesAttr", "communicationPreferences", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItem2List());
}, true, APIGateway_ISModel.CommunicationPreferenceItem2List)
].concat(_super.attributesToDeclare.call(this));
};
ContactDetail2Rec.init();
return ContactDetail2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ContactDetail2Rec = ContactDetail2Rec;

});
define("APIGateway_IS.model$MemberRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$InterimRec", "APIGateway_IS.model$ContactDetail2Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var MemberRec = (function (_super) {
__extends(MemberRec, _super);
function MemberRec(defaults) {
_super.apply(this, arguments);
}
MemberRec.attributesToDeclare = function () {
return [
this.attr("Sex", "sexAttr", "sex", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Pronouns", "pronounsAttr", "pronouns", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RankCode", "rankCodeAttr", "rankCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TitleCode", "titleCodeAttr", "titleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("MedicareCard", "medicareCardAttr", "medicareCard", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.InterimRec());
}, true, APIGateway_ISModel.InterimRec), 
this.attr("PreferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContactDetails", "contactDetailsAttr", "contactDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ContactDetail2Rec());
}, true, APIGateway_ISModel.ContactDetail2Rec)
].concat(_super.attributesToDeclare.call(this));
};
MemberRec.init();
return MemberRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.MemberRec = MemberRec;

});
define("APIGateway_IS.model$GetAddPolicyMemberImpacts_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetAddPolicyMemberImpacts_APIRequestRec = (function (_super) {
__extends(GetAddPolicyMemberImpacts_APIRequestRec, _super);
function GetAddPolicyMemberImpacts_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
GetAddPolicyMemberImpacts_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("Member", "memberAttr", "member", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberRec());
}, true, APIGateway_ISModel.MemberRec), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Private", "privateAttr", "private", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Student", "studentAttr", "student", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RoleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AbdEntryAge", "abdEntryAgeAttr", "abdEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcOverride", "lhcOverrideAttr", "lhcOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PeaOverride", "peaOverrideAttr", "peaOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PowerOfAttorney", "powerOfAttorneyAttr", "powerOfAttorney", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RelationshipCode", "relationshipCodeAttr", "relationshipCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetAddPolicyMemberImpacts_APIRequestRec.init();
return GetAddPolicyMemberImpacts_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetAddPolicyMemberImpacts_APIRequestRec = GetAddPolicyMemberImpacts_APIRequestRec;

});
define("APIGateway_IS.model$PHIUpdateNote_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIUpdateNote_RequestRec = (function (_super) {
__extends(PHIUpdateNote_RequestRec, _super);
function PHIUpdateNote_RequestRec(defaults) {
_super.apply(this, arguments);
}
PHIUpdateNote_RequestRec.attributesToDeclare = function () {
return [
this.attr("id", "idAttr", "id", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("noteTypeCode", "noteTypeCodeAttr", "noteTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("subject", "subjectAttr", "subject", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("note", "noteAttr", "note", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isPriorityNote", "isPriorityNoteAttr", "isPriorityNote", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("priorityNoteExpiryDate", "priorityNoteExpiryDateAttr", "priorityNoteExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("concurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIUpdateNote_RequestRec.init();
return PHIUpdateNote_RequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIUpdateNote_RequestRec = PHIUpdateNote_RequestRec;

});
define("APIGateway_IS.model$PHIStakeholderPreExistingConditionRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderPreExistingConditionRec = (function (_super) {
__extends(PHIStakeholderPreExistingConditionRec, _super);
function PHIStakeholderPreExistingConditionRec(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderPreExistingConditionRec.attributesToDeclare = function () {
return [
this.attr("PreExistingConditionCode", "preExistingConditionCodeAttr", "PreExistingConditionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreExistingCondition", "preExistingConditionAttr", "PreExistingCondition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "Comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderPreExistingConditionRec.init();
return PHIStakeholderPreExistingConditionRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIStakeholderPreExistingConditionRec = PHIStakeholderPreExistingConditionRec;

});
define("APIGateway_IS.model$CalculateRatesQuotes_API2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$FrequencyQuoteItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculateRatesQuotes_API2Rec = (function (_super) {
__extends(CalculateRatesQuotes_API2Rec, _super);
function CalculateRatesQuotes_API2Rec(defaults) {
_super.apply(this, arguments);
}
CalculateRatesQuotes_API2Rec.attributesToDeclare = function () {
return [
this.attr("FrequencyQuotes", "frequencyQuotesAttr", "frequencyQuotes", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FrequencyQuoteItemList());
}, true, APIGateway_ISModel.FrequencyQuoteItemList)
].concat(_super.attributesToDeclare.call(this));
};
CalculateRatesQuotes_API2Rec.fromStructure = function (str) {
return new CalculateRatesQuotes_API2Rec(new CalculateRatesQuotes_API2Rec.RecordClass({
frequencyQuotesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CalculateRatesQuotes_API2Rec.init();
return CalculateRatesQuotes_API2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CalculateRatesQuotes_API2Rec = CalculateRatesQuotes_API2Rec;

});
define("APIGateway_IS.model$PHIConcessionOrOtherCardsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIConcessionOrOtherCardsRec = (function (_super) {
__extends(PHIConcessionOrOtherCardsRec, _super);
function PHIConcessionOrOtherCardsRec(defaults) {
_super.apply(this, arguments);
}
PHIConcessionOrOtherCardsRec.attributesToDeclare = function () {
return [
this.attr("typeCode", "typeCodeAttr", "typeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("cardNumber", "cardNumberAttr", "cardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("expiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIConcessionOrOtherCardsRec.init();
return PHIConcessionOrOtherCardsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIConcessionOrOtherCardsRec = PHIConcessionOrOtherCardsRec;

});
define("APIGateway_IS.model$PHIConcessionOrOtherCardsList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIConcessionOrOtherCardsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIConcessionOrOtherCardsList = (function (_super) {
__extends(PHIConcessionOrOtherCardsList, _super);
function PHIConcessionOrOtherCardsList(defaults) {
_super.apply(this, arguments);
}
PHIConcessionOrOtherCardsList.itemType = APIGateway_ISModel.PHIConcessionOrOtherCardsRec;
return PHIConcessionOrOtherCardsList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIConcessionOrOtherCardsList = PHIConcessionOrOtherCardsList;

});
define("APIGateway_IS.model$PHIMemberRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIMedicareCardRec", "APIGateway_IS.model$PHIConcessionOrOtherCardsList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIMemberRec = (function (_super) {
__extends(PHIMemberRec, _super);
function PHIMemberRec(defaults) {
_super.apply(this, arguments);
}
PHIMemberRec.attributesToDeclare = function () {
return [
this.attr("medicareCard", "medicareCardAttr", "medicareCard", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIMedicareCardRec());
}, true, APIGateway_ISModel.PHIMedicareCardRec), 
this.attr("cards", "cardsAttr", "cards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIConcessionOrOtherCardsList());
}, true, APIGateway_ISModel.PHIConcessionOrOtherCardsList)
].concat(_super.attributesToDeclare.call(this));
};
PHIMemberRec.init();
return PHIMemberRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIMemberRec = PHIMemberRec;

});
define("APIGateway_IS.model$PHILeadRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILeadRec = (function (_super) {
__extends(PHILeadRec, _super);
function PHILeadRec(defaults) {
_super.apply(this, arguments);
}
PHILeadRec.attributesToDeclare = function () {
return [
this.attr("entryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("interestLevelCode", "interestLevelCodeAttr", "interestLevelCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("interestLevel", "interestLevelAttr", "interestLevel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("cancellationReasonCode", "cancellationReasonCodeAttr", "cancellationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("cancellationReason", "cancellationReasonAttr", "cancellationReason", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isFollowUp", "isFollowUpAttr", "isFollowUp", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("followUpDueDate", "followUpDueDateAttr", "followUpDueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILeadRec.init();
return PHILeadRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILeadRec = PHILeadRec;

});
define("APIGateway_IS.model$PHICommunicationPreferenceRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICommunicationPreferenceRec = (function (_super) {
__extends(PHICommunicationPreferenceRec, _super);
function PHICommunicationPreferenceRec(defaults) {
_super.apply(this, arguments);
}
PHICommunicationPreferenceRec.attributesToDeclare = function () {
return [
this.attr("categoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("category", "categoryAttr", "category", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isSendCommunications", "isSendCommunicationsAttr", "isSendCommunications", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("preferredChannel", "preferredChannelAttr", "preferredChannel", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICommunicationPreferenceRec.init();
return PHICommunicationPreferenceRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICommunicationPreferenceRec = PHICommunicationPreferenceRec;

});
define("APIGateway_IS.model$PHICommunicationPreferenceList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHICommunicationPreferenceRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICommunicationPreferenceList = (function (_super) {
__extends(PHICommunicationPreferenceList, _super);
function PHICommunicationPreferenceList(defaults) {
_super.apply(this, arguments);
}
PHICommunicationPreferenceList.itemType = APIGateway_ISModel.PHICommunicationPreferenceRec;
return PHICommunicationPreferenceList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHICommunicationPreferenceList = PHICommunicationPreferenceList;

});
define("APIGateway_IS.model$PHIStakeholderPreExistingConditionList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIStakeholderPreExistingConditionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderPreExistingConditionList = (function (_super) {
__extends(PHIStakeholderPreExistingConditionList, _super);
function PHIStakeholderPreExistingConditionList(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderPreExistingConditionList.itemType = APIGateway_ISModel.PHIStakeholderPreExistingConditionRec;
return PHIStakeholderPreExistingConditionList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIStakeholderPreExistingConditionList = PHIStakeholderPreExistingConditionList;

});
define("APIGateway_IS.model$PHIStakeholderStudentDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderStudentDetailRec = (function (_super) {
__extends(PHIStakeholderStudentDetailRec, _super);
function PHIStakeholderStudentDetailRec(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderStudentDetailRec.attributesToDeclare = function () {
return [
this.attr("EducationInstitutionCode", "educationInstitutionCodeAttr", "EducationInstitutionCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EducationInstitution", "educationInstitutionAttr", "EducationInstitution", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State_TerritorityCode", "state_TerritorityCodeAttr", "State_TerritorityCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State_Territority", "state_TerritorityAttr", "State_Territority", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartMonth_Year", "startMonth_YearAttr", "StartMonth_Year", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddStudentDeclaration", "addStudentDeclarationAttr", "AddStudentDeclaration", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("OtherInstitution", "otherInstitutionAttr", "OtherInstitution", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderStudentDetailRec.init();
return PHIStakeholderStudentDetailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIStakeholderStudentDetailRec = PHIStakeholderStudentDetailRec;

});
define("APIGateway_IS.model$PHILHC_ABDDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHILHC_ABDDetailsRec = (function (_super) {
__extends(PHILHC_ABDDetailsRec, _super);
function PHILHC_ABDDetailsRec(defaults) {
_super.apply(this, arguments);
}
PHILHC_ABDDetailsRec.attributesToDeclare = function () {
return [
this.attr("ABDEntryAge", "aBDEntryAgeAttr", "ABDEntryAge", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ABDEffectiveDate", "aBDEffectiveDateAttr", "ABDEffectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("LHCOverridePercent", "lHCOverridePercentAttr", "LHCOverridePercent", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LHCOverrideApplicable", "lHCOverrideApplicableAttr", "LHCOverrideApplicable", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHILHC_ABDDetailsRec.init();
return PHILHC_ABDDetailsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHILHC_ABDDetailsRec = PHILHC_ABDDetailsRec;

});
define("APIGateway_IS.model$PHIIndividualRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIPhoneList", "APIGateway_IS.model$PHIEmailList", "APIGateway_IS.model$PHIAddressList", "APIGateway_IS.model$PHIFlagList", "APIGateway_IS.model$PHIMemberRec", "APIGateway_IS.model$PHILeadRec", "APIGateway_IS.model$PHICommunicationPreferenceList", "APIGateway_IS.model$PHIStakeholderPreExistingConditionList", "APIGateway_IS.model$PHIStakeholderStudentDetailRec", "APIGateway_IS.model$PHILHC_ABDDetailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIIndividualRec = (function (_super) {
__extends(PHIIndividualRec, _super);
function PHIIndividualRec(defaults) {
_super.apply(this, arguments);
}
PHIIndividualRec.attributesToDeclare = function () {
return [
this.attr("stakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("stakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("id", "idAttr", "id", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("isActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("rankCode", "rankCodeAttr", "rankCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("rank", "rankAttr", "rank", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("firstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("middleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("lastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("preferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("sex", "sexAttr", "sex", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pronouns", "pronounsAttr", "pronouns", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("age", "ageAttr", "age", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("JoinedDate", "joinedDateAttr", "JoinedDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("phoneNumbers", "phoneNumbersAttr", "phoneNumbers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIPhoneList());
}, true, APIGateway_ISModel.PHIPhoneList), 
this.attr("emailAddresses", "emailAddressesAttr", "emailAddresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIEmailList());
}, true, APIGateway_ISModel.PHIEmailList), 
this.attr("addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIAddressList());
}, true, APIGateway_ISModel.PHIAddressList), 
this.attr("flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIFlagList());
}, true, APIGateway_ISModel.PHIFlagList), 
this.attr("isContributor", "isContributorAttr", "isContributor", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("isDelegatedAuthority", "isDelegatedAuthorityAttr", "isDelegatedAuthority", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("lhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("lhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("discountAge", "discountAgeAttr", "discountAge", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("member", "memberAttr", "member", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIMemberRec());
}, true, APIGateway_ISModel.PHIMemberRec), 
this.attr("lead", "leadAttr", "lead", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILeadRec());
}, true, APIGateway_ISModel.PHILeadRec), 
this.attr("communicationPreferences", "communicationPreferencesAttr", "communicationPreferences", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHICommunicationPreferenceList());
}, true, APIGateway_ISModel.PHICommunicationPreferenceList), 
this.attr("PHIStakeholderPreExistingConditions", "pHIStakeholderPreExistingConditionsAttr", "PHIStakeholderPreExistingConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderPreExistingConditionList());
}, true, APIGateway_ISModel.PHIStakeholderPreExistingConditionList), 
this.attr("PHIStakeholderStudentDetail", "pHIStakeholderStudentDetailAttr", "PHIStakeholderStudentDetail", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderStudentDetailRec());
}, true, APIGateway_ISModel.PHIStakeholderStudentDetailRec), 
this.attr("LHC_ABDDetails", "lHC_ABDDetailsAttr", "LHC_ABDDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHILHC_ABDDetailsRec());
}, true, APIGateway_ISModel.PHILHC_ABDDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIIndividualRec.init();
return PHIIndividualRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIIndividualRec = PHIIndividualRec;

});
define("APIGateway_IS.model$PreviousCoverItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviousCoverItemRec = (function (_super) {
__extends(PreviousCoverItemRec, _super);
function PreviousCoverItemRec(defaults) {
_super.apply(this, arguments);
}
PreviousCoverItemRec.attributesToDeclare = function () {
return [
this.attr("PreviousCoverId", "previousCoverIdAttr", "previousCoverId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PreviousFundCode", "previousFundCodeAttr", "previousFundCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreviousFund", "previousFundAttr", "previousFund", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HealthRateScaleCode", "healthRateScaleCodeAttr", "healthRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HealthRateScale", "healthRateScaleAttr", "healthRateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PaidHospitalDays", "paidHospitalDaysAttr", "paidHospitalDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PreviousCoverItemRec.init();
return PreviousCoverItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreviousCoverItemRec = PreviousCoverItemRec;

});
define("APIGateway_IS.model$PreviousCoverItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreviousCoverItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreviousCoverItemList = (function (_super) {
__extends(PreviousCoverItemList, _super);
function PreviousCoverItemList(defaults) {
_super.apply(this, arguments);
}
PreviousCoverItemList.itemType = APIGateway_ISModel.PreviousCoverItemRec;
return PreviousCoverItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PreviousCoverItemList = PreviousCoverItemList;

});
define("APIGateway_IS.model$GetIndividualPreviousCovers_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreviousCoverItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetIndividualPreviousCovers_APIResponseRec = (function (_super) {
__extends(GetIndividualPreviousCovers_APIResponseRec, _super);
function GetIndividualPreviousCovers_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetIndividualPreviousCovers_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("PreviousCovers", "previousCoversAttr", "previousCovers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreviousCoverItemList());
}, true, APIGateway_ISModel.PreviousCoverItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetIndividualPreviousCovers_APIResponseRec.fromStructure = function (str) {
return new GetIndividualPreviousCovers_APIResponseRec(new GetIndividualPreviousCovers_APIResponseRec.RecordClass({
previousCoversAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetIndividualPreviousCovers_APIResponseRec.init();
return GetIndividualPreviousCovers_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetIndividualPreviousCovers_APIResponseRec = GetIndividualPreviousCovers_APIResponseRec;

});
define("APIGateway_IS.model$TerminatePolicy_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TerminatePolicy_APIRequestRec = (function (_super) {
__extends(TerminatePolicy_APIRequestRec, _super);
function TerminatePolicy_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
TerminatePolicy_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("TerminationReasonCode", "terminationReasonCodeAttr", "terminationReasonCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminationDate", "terminationDateAttr", "terminationDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TerminatePolicy_APIRequestRec.init();
return TerminatePolicy_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.TerminatePolicy_APIRequestRec = TerminatePolicy_APIRequestRec;

});
define("APIGateway_IS.model$", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.Types.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.TextList = TextList;

});
define("APIGateway_IS.model$PHIPatchIndividualResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPatchIndividualResponseRec = (function (_super) {
__extends(PHIPatchIndividualResponseRec, _super);
function PHIPatchIndividualResponseRec(defaults) {
_super.apply(this, arguments);
}
PHIPatchIndividualResponseRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Detail", "detailAttr", "detail", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Instance", "instanceAttr", "instance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Errors", "errorsAttr", "errors", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList), 
this.attr("TraceId", "traceIdAttr", "traceId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ErrorCode", "errorCodeAttr", "errorCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIPatchIndividualResponseRec.init();
return PHIPatchIndividualResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPatchIndividualResponseRec = PHIPatchIndividualResponseRec;

});
define("APIGateway_IS.model$IndividualCardRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualCardRec = (function (_super) {
__extends(IndividualCardRec, _super);
function IndividualCardRec(defaults) {
_super.apply(this, arguments);
}
IndividualCardRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TypeCode", "typeCodeAttr", "typeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CardNumber", "cardNumberAttr", "cardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
IndividualCardRec.init();
return IndividualCardRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.IndividualCardRec = IndividualCardRec;

});
define("APIGateway_IS.model$IndividualCardList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$IndividualCardRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualCardList = (function (_super) {
__extends(IndividualCardList, _super);
function IndividualCardList(defaults) {
_super.apply(this, arguments);
}
IndividualCardList.itemType = APIGateway_ISModel.IndividualCardRec;
return IndividualCardList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.IndividualCardList = IndividualCardList;

});
define("APIGateway_IS.model$IndividualCards_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$IndividualCardList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualCards_Response_APIRec = (function (_super) {
__extends(IndividualCards_Response_APIRec, _super);
function IndividualCards_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
IndividualCards_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("Cards", "cardsAttr", "cards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.IndividualCardList());
}, true, APIGateway_ISModel.IndividualCardList)
].concat(_super.attributesToDeclare.call(this));
};
IndividualCards_Response_APIRec.fromStructure = function (str) {
return new IndividualCards_Response_APIRec(new IndividualCards_Response_APIRec.RecordClass({
cardsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IndividualCards_Response_APIRec.init();
return IndividualCards_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.IndividualCards_Response_APIRec = IndividualCards_Response_APIRec;

});
define("APIGateway_IS.model$ReactivatePolicy_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ReactivatePolicy_APIRequestRec = (function (_super) {
__extends(ReactivatePolicy_APIRequestRec, _super);
function ReactivatePolicy_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
ReactivatePolicy_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("ProductClass", "productClassAttr", "productClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReactivationDate", "reactivationDateAttr", "reactivationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ReprocessReceipts", "reprocessReceiptsAttr", "reprocessReceipts", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("TerminateReasonCode", "terminateReasonCodeAttr", "terminateReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TerminateProductClass", "terminateProductClassAttr", "terminateProductClass", false, false, OS.Types.Text, function () {
return "False";
}, true), 
this.attr("TerminateCardsOnTermination", "terminateCardsOnTerminationAttr", "terminateCardsOnTermination", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("WithdrawFromRebateOnTermination", "withdrawFromRebateOnTerminationAttr", "withdrawFromRebateOnTermination", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ProduceClearanceCertificateOnTermination", "produceClearanceCertificateOnTerminationAttr", "produceClearanceCertificateOnTermination", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReactivatePolicy_APIRequestRec.init();
return ReactivatePolicy_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ReactivatePolicy_APIRequestRec = ReactivatePolicy_APIRequestRec;

});
define("APIGateway_IS.model$ResultItem_LocationList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_LocationRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_LocationList = (function (_super) {
__extends(ResultItem_LocationList, _super);
function ResultItem_LocationList(defaults) {
_super.apply(this, arguments);
}
ResultItem_LocationList.itemType = APIGateway_ISModel.ResultItem_LocationRec;
return ResultItem_LocationList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ResultItem_LocationList = ResultItem_LocationList;

});
define("APIGateway_IS.model$GetLocations_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_LocationList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetLocations_APIResponseRec = (function (_super) {
__extends(GetLocations_APIResponseRec, _super);
function GetLocations_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetLocations_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ResultItem_LocationList());
}, true, APIGateway_ISModel.ResultItem_LocationList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetLocations_APIResponseRec.init();
return GetLocations_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetLocations_APIResponseRec = GetLocations_APIResponseRec;

});
define("APIGateway_IS.model$PHICreateLeadRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHICreateLeadRec = (function (_super) {
__extends(PHICreateLeadRec, _super);
function PHICreateLeadRec(defaults) {
_super.apply(this, arguments);
}
PHICreateLeadRec.attributesToDeclare = function () {
return [
this.attr("stakeholderId", "stakeholderIdAttr", "stakeholderId", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("concurrencyToken", "concurrencyTokenAttr", "concurrencyToken", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHICreateLeadRec.init();
return PHICreateLeadRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHICreateLeadRec = PHICreateLeadRec;

});
define("APIGateway_IS.model$SearchDocumentsesultItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchDocumentsesultItemRec = (function (_super) {
__extends(SearchDocumentsesultItemRec, _super);
function SearchDocumentsesultItemRec(defaults) {
_super.apply(this, arguments);
}
SearchDocumentsesultItemRec.attributesToDeclare = function () {
return [
this.attr("DocumentId", "documentIdAttr", "documentId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("EntityId", "entityIdAttr", "entityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedDateTime", "createdDateTimeAttr", "createdDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FileName", "fileNameAttr", "fileName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FileType", "fileTypeAttr", "fileType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchDocumentsesultItemRec.init();
return SearchDocumentsesultItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchDocumentsesultItemRec = SearchDocumentsesultItemRec;

});
define("APIGateway_IS.model$SearchDocumentsesultItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SearchDocumentsesultItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchDocumentsesultItemList = (function (_super) {
__extends(SearchDocumentsesultItemList, _super);
function SearchDocumentsesultItemList(defaults) {
_super.apply(this, arguments);
}
SearchDocumentsesultItemList.itemType = APIGateway_ISModel.SearchDocumentsesultItemRec;
return SearchDocumentsesultItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.SearchDocumentsesultItemList = SearchDocumentsesultItemList;

});
define("APIGateway_IS.model$SearchDocuments_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SearchDocumentsesultItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchDocuments_APIResponseRec = (function (_super) {
__extends(SearchDocuments_APIResponseRec, _super);
function SearchDocuments_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
SearchDocuments_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SearchDocumentsesultItemList());
}, true, APIGateway_ISModel.SearchDocumentsesultItemList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchDocuments_APIResponseRec.init();
return SearchDocuments_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchDocuments_APIResponseRec = SearchDocuments_APIResponseRec;

});
define("APIGateway_IS.model$PHIAssociationRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIAssociationRec = (function (_super) {
__extends(PHIAssociationRec, _super);
function PHIAssociationRec(defaults) {
_super.apply(this, arguments);
}
PHIAssociationRec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "StakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationType", "associationTypeAttr", "associationType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationNumber", "associationNumberAttr", "associationNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationTypeCode", "associationTypeCodeAttr", "associationTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIAssociationRec.init();
return PHIAssociationRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIAssociationRec = PHIAssociationRec;

});
define("APIGateway_IS.model$PHIAssociationList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIAssociationRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIAssociationList = (function (_super) {
__extends(PHIAssociationList, _super);
function PHIAssociationList(defaults) {
_super.apply(this, arguments);
}
PHIAssociationList.itemType = APIGateway_ISModel.PHIAssociationRec;
return PHIAssociationList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIAssociationList = PHIAssociationList;

});
define("APIGateway_IS.model$PHIAssociationsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIAssociationList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIAssociationsRec = (function (_super) {
__extends(PHIAssociationsRec, _super);
function PHIAssociationsRec(defaults) {
_super.apply(this, arguments);
}
PHIAssociationsRec.attributesToDeclare = function () {
return [
this.attr("Associations", "associationsAttr", "associations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIAssociationList());
}, true, APIGateway_ISModel.PHIAssociationList)
].concat(_super.attributesToDeclare.call(this));
};
PHIAssociationsRec.fromStructure = function (str) {
return new PHIAssociationsRec(new PHIAssociationsRec.RecordClass({
associationsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHIAssociationsRec.init();
return PHIAssociationsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIAssociationsRec = PHIAssociationsRec;

});
define("APIGateway_IS.model$AddLeadResponse2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddLeadResponse2Rec = (function (_super) {
__extends(AddLeadResponse2Rec, _super);
function AddLeadResponse2Rec(defaults) {
_super.apply(this, arguments);
}
AddLeadResponse2Rec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ConcurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddLeadResponse2Rec.init();
return AddLeadResponse2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddLeadResponse2Rec = AddLeadResponse2Rec;

});
define("APIGateway_IS.model$ReactivatePolicyMembers_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ReactivatePolicyMembers_APIRequestRec = (function (_super) {
__extends(ReactivatePolicyMembers_APIRequestRec, _super);
function ReactivatePolicyMembers_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
ReactivatePolicyMembers_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("ReactivationDate", "reactivationDateAttr", "reactivationDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AddSavingsEntitlement", "addSavingsEntitlementAttr", "addSavingsEntitlement", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ApplyLhcLoadingDueToAbsence", "applyLhcLoadingDueToAbsenceAttr", "applyLhcLoadingDueToAbsence", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ReprocessReceipts", "reprocessReceiptsAttr", "reprocessReceipts", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReactivatePolicyMembers_APIRequestRec.init();
return ReactivatePolicyMembers_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ReactivatePolicyMembers_APIRequestRec = ReactivatePolicyMembers_APIRequestRec;

});
define("APIGateway_IS.model$PHIStakeholderSearchList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIStakeholderSearchRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchList = (function (_super) {
__extends(PHIStakeholderSearchList, _super);
function PHIStakeholderSearchList(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchList.itemType = APIGateway_ISModel.PHIStakeholderSearchRec;
return PHIStakeholderSearchList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHIStakeholderSearchList = PHIStakeholderSearchList;

});
define("APIGateway_IS.model$PHIStakeholderSearchResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIStakeholderSearchList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchResponseRec = (function (_super) {
__extends(PHIStakeholderSearchResponseRec, _super);
function PHIStakeholderSearchResponseRec(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchResponseRec.attributesToDeclare = function () {
return [
this.attr("result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderSearchList());
}, true, APIGateway_ISModel.PHIStakeholderSearchList), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("totalCount", "totalCountAttr", "totalCount", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderSearchResponseRec.init();
return PHIStakeholderSearchResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIStakeholderSearchResponseRec = PHIStakeholderSearchResponseRec;

});
define("APIGateway_IS.model$PHIProblemDetailsStakeholderSearchResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIStakeholderSearchResponseRec", "APIGateway_IS.model$PHIProblemDetailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIProblemDetailsStakeholderSearchResponseRec = (function (_super) {
__extends(PHIProblemDetailsStakeholderSearchResponseRec, _super);
function PHIProblemDetailsStakeholderSearchResponseRec(defaults) {
_super.apply(this, arguments);
}
PHIProblemDetailsStakeholderSearchResponseRec.attributesToDeclare = function () {
return [
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("StakeholderSearchResponse", "stakeholderSearchResponseAttr", "StakeholderSearchResponse", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderSearchResponseRec());
}, true, APIGateway_ISModel.PHIStakeholderSearchResponseRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIProblemDetailsStakeholderSearchResponseRec.init();
return PHIProblemDetailsStakeholderSearchResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIProblemDetailsStakeholderSearchResponseRec = PHIProblemDetailsStakeholderSearchResponseRec;

});
define("APIGateway_IS.model$AddDocument_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddDocument_APIResponseRec = (function (_super) {
__extends(AddDocument_APIResponseRec, _super);
function AddDocument_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
AddDocument_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("DocumentId", "documentIdAttr", "documentId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddDocument_APIResponseRec.fromStructure = function (str) {
return new AddDocument_APIResponseRec(new AddDocument_APIResponseRec.RecordClass({
documentIdAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AddDocument_APIResponseRec.init();
return AddDocument_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddDocument_APIResponseRec = AddDocument_APIResponseRec;

});
define("APIGateway_IS.model$ResultItem_AuditList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_AuditRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_AuditList = (function (_super) {
__extends(ResultItem_AuditList, _super);
function ResultItem_AuditList(defaults) {
_super.apply(this, arguments);
}
ResultItem_AuditList.itemType = APIGateway_ISModel.ResultItem_AuditRec;
return ResultItem_AuditList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ResultItem_AuditList = ResultItem_AuditList;

});
define("APIGateway_IS.model$AuditHistory_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_AuditList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AuditHistory_APIResponseRec = (function (_super) {
__extends(AuditHistory_APIResponseRec, _super);
function AuditHistory_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
AuditHistory_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ResultItem_AuditList());
}, true, APIGateway_ISModel.ResultItem_AuditList), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AuditHistory_APIResponseRec.init();
return AuditHistory_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AuditHistory_APIResponseRec = AuditHistory_APIResponseRec;

});
define("APIGateway_IS.model$EligibilityReason2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EligibilityReason2Rec = (function (_super) {
__extends(EligibilityReason2Rec, _super);
function EligibilityReason2Rec(defaults) {
_super.apply(this, arguments);
}
EligibilityReason2Rec.attributesToDeclare = function () {
return [
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ReasonCode", "reasonCodeAttr", "reasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubReasonCode", "subReasonCodeAttr", "subReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EligibilityReason2Rec.init();
return EligibilityReason2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.EligibilityReason2Rec = EligibilityReason2Rec;

});
define("APIGateway_IS.model$EntityResultItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityResultItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EntityResultItemList = (function (_super) {
__extends(EntityResultItemList, _super);
function EntityResultItemList(defaults) {
_super.apply(this, arguments);
}
EntityResultItemList.itemType = APIGateway_ISModel.EntityResultItemRec;
return EntityResultItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EntityResultItemList = EntityResultItemList;

});
define("APIGateway_IS.model$SearchEntityProperties_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EntityResultItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchEntityProperties_APIResponseRec = (function (_super) {
__extends(SearchEntityProperties_APIResponseRec, _super);
function SearchEntityProperties_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
SearchEntityProperties_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityResultItemList());
}, true, APIGateway_ISModel.EntityResultItemList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchEntityProperties_APIResponseRec.init();
return SearchEntityProperties_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchEntityProperties_APIResponseRec = SearchEntityProperties_APIResponseRec;

});
define("APIGateway_IS.model$RateItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RateItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var RateItemList = (function (_super) {
__extends(RateItemList, _super);
function RateItemList(defaults) {
_super.apply(this, arguments);
}
RateItemList.itemType = APIGateway_ISModel.RateItemRec;
return RateItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.RateItemList = RateItemList;

});
define("APIGateway_IS.model$ProductRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RateItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ProductRec = (function (_super) {
__extends(ProductRec, _super);
function ProductRec(defaults) {
_super.apply(this, arguments);
}
ProductRec.attributesToDeclare = function () {
return [
this.attr("ProductCode", "productCodeAttr", "productCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTierCode", "productTierCodeAttr", "productTierCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTier", "productTierAttr", "productTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScale", "rateScaleAttr", "rateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherProductName", "otherProductNameAttr", "otherProductName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScale", "otherRateScaleAttr", "otherRateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductClass", "productClassAttr", "productClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContributionRates", "contributionRatesAttr", "contributionRates", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RateItemList());
}, true, APIGateway_ISModel.RateItemList)
].concat(_super.attributesToDeclare.call(this));
};
ProductRec.init();
return ProductRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ProductRec = ProductRec;

});
define("APIGateway_IS.model$ProductList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ProductRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ProductList = (function (_super) {
__extends(ProductList, _super);
function ProductList(defaults) {
_super.apply(this, arguments);
}
ProductList.itemType = APIGateway_ISModel.ProductRec;
return ProductList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ProductList = ProductList;

});
define("APIGateway_IS.model$GetSearchProduct_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ProductList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetSearchProduct_APIResponseRec = (function (_super) {
__extends(GetSearchProduct_APIResponseRec, _super);
function GetSearchProduct_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetSearchProduct_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ProductList());
}, true, APIGateway_ISModel.ProductList), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetSearchProduct_APIResponseRec.init();
return GetSearchProduct_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetSearchProduct_APIResponseRec = GetSearchProduct_APIResponseRec;

});
define("APIGateway_IS.model$AssociationItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AssociationItemRec = (function (_super) {
__extends(AssociationItemRec, _super);
function AssociationItemRec(defaults) {
_super.apply(this, arguments);
}
AssociationItemRec.attributesToDeclare = function () {
return [
this.attr("AssociationNumber", "associationNumberAttr", "associationNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationTypeCode", "associationTypeCodeAttr", "associationTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssociationType", "associationTypeAttr", "associationType", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AssociationItemRec.init();
return AssociationItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AssociationItemRec = AssociationItemRec;

});
define("APIGateway_IS.model$AssociationItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AssociationItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AssociationItemList = (function (_super) {
__extends(AssociationItemList, _super);
function AssociationItemList(defaults) {
_super.apply(this, arguments);
}
AssociationItemList.itemType = APIGateway_ISModel.AssociationItemRec;
return AssociationItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AssociationItemList = AssociationItemList;

});
define("APIGateway_IS.model$GetIndividualAssociations_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AssociationItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetIndividualAssociations_Response_APIRec = (function (_super) {
__extends(GetIndividualAssociations_Response_APIRec, _super);
function GetIndividualAssociations_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
GetIndividualAssociations_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("Associations", "associationsAttr", "associations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AssociationItemList());
}, true, APIGateway_ISModel.AssociationItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetIndividualAssociations_Response_APIRec.fromStructure = function (str) {
return new GetIndividualAssociations_Response_APIRec(new GetIndividualAssociations_Response_APIRec.RecordClass({
associationsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetIndividualAssociations_Response_APIRec.init();
return GetIndividualAssociations_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetIndividualAssociations_Response_APIRec = GetIndividualAssociations_Response_APIRec;

});
define("APIGateway_IS.model$GetPolicyAssociatedRoles_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$RoleItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyAssociatedRoles_APIResponseRec = (function (_super) {
__extends(GetPolicyAssociatedRoles_APIResponseRec, _super);
function GetPolicyAssociatedRoles_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyAssociatedRoles_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Roles", "rolesAttr", "roles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.RoleItemList());
}, true, APIGateway_ISModel.RoleItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyAssociatedRoles_APIResponseRec.fromStructure = function (str) {
return new GetPolicyAssociatedRoles_APIResponseRec(new GetPolicyAssociatedRoles_APIResponseRec.RecordClass({
rolesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPolicyAssociatedRoles_APIResponseRec.init();
return GetPolicyAssociatedRoles_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyAssociatedRoles_APIResponseRec = GetPolicyAssociatedRoles_APIResponseRec;

});
define("APIGateway_IS.model$AddDocumentRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddDocumentRequestRec = (function (_super) {
__extends(AddDocumentRequestRec, _super);
function AddDocumentRequestRec(defaults) {
_super.apply(this, arguments);
}
AddDocumentRequestRec.attributesToDeclare = function () {
return [
this.attr("EntityId", "entityIdAttr", "entityId", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Comment", "commentAttr", "comment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "file", true, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("FileName", "fileNameAttr", "FileName", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddDocumentRequestRec.init();
return AddDocumentRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddDocumentRequestRec = AddDocumentRequestRec;

});
define("APIGateway_IS.model$GetProduct_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetProduct_APIRequestRec = (function (_super) {
__extends(GetProduct_APIRequestRec, _super);
function GetProduct_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
GetProduct_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("ProductCode", "productCodeAttr", "ProductCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "RateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetProduct_APIRequestRec.init();
return GetProduct_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetProduct_APIRequestRec = GetProduct_APIRequestRec;

});
define("APIGateway_IS.model$PHI_EntityFlag_RecordList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHI_EntityFlag_RecordRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_EntityFlag_RecordList = (function (_super) {
__extends(PHI_EntityFlag_RecordList, _super);
function PHI_EntityFlag_RecordList(defaults) {
_super.apply(this, arguments);
}
PHI_EntityFlag_RecordList.itemType = APIGateway_ISModel.PHI_EntityFlag_RecordRec;
return PHI_EntityFlag_RecordList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHI_EntityFlag_RecordList = PHI_EntityFlag_RecordList;

});
define("APIGateway_IS.model$PHI_EntityFlags_ResultRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHI_EntityFlag_RecordList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_EntityFlags_ResultRec = (function (_super) {
__extends(PHI_EntityFlags_ResultRec, _super);
function PHI_EntityFlags_ResultRec(defaults) {
_super.apply(this, arguments);
}
PHI_EntityFlags_ResultRec.attributesToDeclare = function () {
return [
this.attr("flags", "flagsAttr", "flags", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHI_EntityFlag_RecordList());
}, true, APIGateway_ISModel.PHI_EntityFlag_RecordList)
].concat(_super.attributesToDeclare.call(this));
};
PHI_EntityFlags_ResultRec.fromStructure = function (str) {
return new PHI_EntityFlags_ResultRec(new PHI_EntityFlags_ResultRec.RecordClass({
flagsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHI_EntityFlags_ResultRec.init();
return PHI_EntityFlags_ResultRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHI_EntityFlags_ResultRec = PHI_EntityFlags_ResultRec;

});
define("APIGateway_IS.model$ContactDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$SecondaryList", "APIGateway_IS.model$PhoneItemList", "APIGateway_IS.model$HomeList", "APIGateway_IS.model$CommunicationPreferenceItem2List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ContactDetailRec = (function (_super) {
__extends(ContactDetailRec, _super);
function ContactDetailRec(defaults) {
_super.apply(this, arguments);
}
ContactDetailRec.attributesToDeclare = function () {
return [
this.attr("Emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SecondaryList());
}, true, APIGateway_ISModel.SecondaryList), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneItemList());
}, true, APIGateway_ISModel.PhoneItemList), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.HomeList());
}, true, APIGateway_ISModel.HomeList), 
this.attr("CommunicationPreferences", "communicationPreferencesAttr", "communicationPreferences", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItem2List());
}, true, APIGateway_ISModel.CommunicationPreferenceItem2List)
].concat(_super.attributesToDeclare.call(this));
};
ContactDetailRec.init();
return ContactDetailRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ContactDetailRec = ContactDetailRec;

});
define("APIGateway_IS.model$ProspectRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$InterimRec", "APIGateway_IS.model$ContactDetailRec", "APIGateway_IS.model$MailingRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ProspectRec = (function (_super) {
__extends(ProspectRec, _super);
function ProspectRec(defaults) {
_super.apply(this, arguments);
}
ProspectRec.attributesToDeclare = function () {
return [
this.attr("TitleCode", "titleCodeAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RankCode", "rankCodeAttr", "rankCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FirstName", "firstNameAttr", "firstName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "lastName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Sex", "sexAttr", "sex", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Pronouns", "pronounsAttr", "pronouns", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PhoneNumber", "phoneNumberAttr", "phoneNumber", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EmailAddress", "emailAddressAttr", "emailAddress", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Rank", "rankAttr", "rank", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TitleCode2", "titleCode2Attr", "titleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("MedicareCard", "medicareCardAttr", "medicareCard", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.InterimRec());
}, true, APIGateway_ISModel.InterimRec), 
this.attr("ContactDetails", "contactDetailsAttr", "contactDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ContactDetailRec());
}, true, APIGateway_ISModel.ContactDetailRec), 
this.attr("Address", "addressAttr", "address", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MailingRec());
}, true, APIGateway_ISModel.MailingRec)
].concat(_super.attributesToDeclare.call(this));
};
ProspectRec.init();
return ProspectRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ProspectRec = ProspectRec;

});
define("APIGateway_IS.model$PolicyMemberItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ProspectRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMemberItemRec = (function (_super) {
__extends(PolicyMemberItemRec, _super);
function PolicyMemberItemRec(defaults) {
_super.apply(this, arguments);
}
PolicyMemberItemRec.attributesToDeclare = function () {
return [
this.attr("Badge", "badgeAttr", "badge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Member", "memberAttr", "member", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ProspectRec());
}, true, APIGateway_ISModel.ProspectRec), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EndDate", "endDateAttr", "endDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Private", "privateAttr", "private", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Student", "studentAttr", "student", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RoleCode", "roleCodeAttr", "roleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AbdEntryAge", "abdEntryAgeAttr", "abdEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcEntryAge", "lhcEntryAgeAttr", "lhcEntryAge", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LhcOverride", "lhcOverrideAttr", "lhcOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PeaOverride", "peaOverrideAttr", "peaOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Relationship", "relationshipAttr", "relationship", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CoverVariation", "coverVariationAttr", "coverVariation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LhcAbsenceDays", "lhcAbsenceDaysAttr", "lhcAbsenceDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PowerOfAttorney", "powerOfAttorneyAttr", "powerOfAttorney", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RelationshipCode", "relationshipCodeAttr", "relationshipCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DependantOverride", "dependantOverrideAttr", "dependantOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("DisabilityOverride", "disabilityOverrideAttr", "disabilityOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcLoadingPercentage", "lhcLoadingPercentageAttr", "lhcLoadingPercentage", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyMemberItemRec.init();
return PolicyMemberItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyMemberItemRec = PolicyMemberItemRec;

});
define("APIGateway_IS.model$EmailsList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var EmailsList = (function (_super) {
__extends(EmailsList, _super);
function EmailsList(defaults) {
_super.apply(this, arguments);
}
EmailsList.itemType = APIGateway_ISModel.EmailsRec;
return EmailsList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.EmailsList = EmailsList;

});
define("APIGateway_IS.model$AddressesList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddressesRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddressesList = (function (_super) {
__extends(AddressesList, _super);
function AddressesList(defaults) {
_super.apply(this, arguments);
}
AddressesList.itemType = APIGateway_ISModel.AddressesRec;
return AddressesList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddressesList = AddressesList;

});
define("APIGateway_IS.model$CardItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$CardItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CardItemList = (function (_super) {
__extends(CardItemList, _super);
function CardItemList(defaults) {
_super.apply(this, arguments);
}
CardItemList.itemType = APIGateway_ISModel.CardItemRec;
return CardItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.CardItemList = CardItemList;

});
define("APIGateway_IS.model$PreexistingConditionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreexistingConditionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreexistingConditionItemList = (function (_super) {
__extends(PreexistingConditionItemList, _super);
function PreexistingConditionItemList(defaults) {
_super.apply(this, arguments);
}
PreexistingConditionItemList.itemType = APIGateway_ISModel.PreexistingConditionItemRec;
return PreexistingConditionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PreexistingConditionItemList = PreexistingConditionItemList;

});
define("APIGateway_IS.model$AddLead_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$LeadItemRec", "APIGateway_IS.model$EligibilityReason2Rec", "APIGateway_IS.model$PhoneNumberItemList", "APIGateway_IS.model$EmailsList", "APIGateway_IS.model$AddressesList", "APIGateway_IS.model$CommunicationPreferenceItemRec", "APIGateway_IS.model$AssociationItemList", "APIGateway_IS.model$CardItemList", "APIGateway_IS.model$PreexistingConditionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddLead_APIRequestRec = (function (_super) {
__extends(AddLead_APIRequestRec, _super);
function AddLead_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
AddLead_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("FirstName", "firstNameAttr", "firstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("InterestLevel", "interestLevelAttr", "interestLevel", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.LeadItemRec());
}, true, APIGateway_ISModel.LeadItemRec), 
this.attr("LastName", "lastNameAttr", "lastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MiddleName", "middleNameAttr", "middleName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PreferredName", "preferredNameAttr", "preferredName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsCode", "pronounsCodeAttr", "pronounsCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PronounsOther", "pronounsOtherAttr", "pronounsOther", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "dateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EligibilityReason", "eligibilityReasonAttr", "eligibilityReason", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EligibilityReason2Rec());
}, true, APIGateway_ISModel.EligibilityReason2Rec), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemList());
}, true, APIGateway_ISModel.PhoneNumberItemList), 
this.attr("Emails", "emailsAttr", "emails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailsList());
}, true, APIGateway_ISModel.EmailsList), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressesList());
}, true, APIGateway_ISModel.AddressesList), 
this.attr("CommunicationPreference", "communicationPreferenceAttr", "communicationPreference", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItemRec());
}, true, APIGateway_ISModel.CommunicationPreferenceItemRec), 
this.attr("Associations", "associationsAttr", "associations", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AssociationItemList());
}, true, APIGateway_ISModel.AssociationItemList), 
this.attr("Cards", "cardsAttr", "cards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CardItemList());
}, true, APIGateway_ISModel.CardItemList), 
this.attr("PreexistingConditions", "preexistingConditionsAttr", "preexistingConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreexistingConditionItemList());
}, true, APIGateway_ISModel.PreexistingConditionItemList)
].concat(_super.attributesToDeclare.call(this));
};
AddLead_APIRequestRec.init();
return AddLead_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddLead_APIRequestRec = AddLead_APIRequestRec;

});
define("APIGateway_IS.model$VerifyMedicareDetails_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var VerifyMedicareDetails_APIResponseRec = (function (_super) {
__extends(VerifyMedicareDetails_APIResponseRec, _super);
function VerifyMedicareDetails_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
VerifyMedicareDetails_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Validated", "validatedAttr", "validated", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StatusCode", "statusCodeAttr", "statusCode", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PvmTime", "pvmTimeAttr", "pvmTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
VerifyMedicareDetails_APIResponseRec.init();
return VerifyMedicareDetails_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.VerifyMedicareDetails_APIResponseRec = VerifyMedicareDetails_APIResponseRec;

});
define("APIGateway_IS.model$AddPolicy_API2Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddPolicy_API2Rec = (function (_super) {
__extends(AddPolicy_API2Rec, _super);
function AddPolicy_API2Rec(defaults) {
_super.apply(this, arguments);
}
AddPolicy_API2Rec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ConcurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddPolicy_API2Rec.init();
return AddPolicy_API2Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddPolicy_API2Rec = AddPolicy_API2Rec;

});
define("APIGateway_IS.model$CalculatePolicyClass_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CalculatePolicyClass_APIRequestRec = (function (_super) {
__extends(CalculatePolicyClass_APIRequestRec, _super);
function CalculatePolicyClass_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
CalculatePolicyClass_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("Members", "membersAttr", "members", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItemList());
}, true, APIGateway_ISModel.MemberItemList), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductClass", "productClassAttr", "productClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsStudentOverride", "isStudentOverrideAttr", "isStudentOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HasOverageDependants", "hasOverageDependantsAttr", "hasOverageDependants", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HasStudentDependants", "hasStudentDependantsAttr", "hasStudentDependants", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsDisabilityOverride", "isDisabilityOverrideAttr", "isDisabilityOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HasAdultsWithDisability", "hasAdultsWithDisabilityAttr", "hasAdultsWithDisability", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsChildDependentOverride", "isChildDependentOverrideAttr", "isChildDependentOverride", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CalculatePolicyClass_APIRequestRec.init();
return CalculatePolicyClass_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CalculatePolicyClass_APIRequestRec = CalculatePolicyClass_APIRequestRec;

});
define("APIGateway_IS.model$DataContextRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DataContextRec = (function (_super) {
__extends(DataContextRec, _super);
function DataContextRec(defaults) {
_super.apply(this, arguments);
}
DataContextRec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Stakeholder", "stakeholderAttr", "stakeholder", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AgencyId", "agencyIdAttr", "agencyId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GroupId", "groupIdAttr", "groupId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Provider", "providerAttr", "provider", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DataContextRec.init();
return DataContextRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.DataContextRec = DataContextRec;

});
define("APIGateway_IS.model$TemplatePropertiesRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TemplatePropertiesRec = (function (_super) {
__extends(TemplatePropertiesRec, _super);
function TemplatePropertiesRec(defaults) {
_super.apply(this, arguments);
}
TemplatePropertiesRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TemplatePropertiesRec.init();
return TemplatePropertiesRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.TemplatePropertiesRec = TemplatePropertiesRec;

});
define("APIGateway_IS.model$TemplatePropertiesList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$TemplatePropertiesRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var TemplatePropertiesList = (function (_super) {
__extends(TemplatePropertiesList, _super);
function TemplatePropertiesList(defaults) {
_super.apply(this, arguments);
}
TemplatePropertiesList.itemType = APIGateway_ISModel.TemplatePropertiesRec;
return TemplatePropertiesList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.TemplatePropertiesList = TemplatePropertiesList;

});
define("APIGateway_IS.model$GetCommunicationTypeResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$TemplatePropertiesList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetCommunicationTypeResponseRec = (function (_super) {
__extends(GetCommunicationTypeResponseRec, _super);
function GetCommunicationTypeResponseRec(defaults) {
_super.apply(this, arguments);
}
GetCommunicationTypeResponseRec.attributesToDeclare = function () {
return [
this.attr("TypeId", "typeIdAttr", "typeId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TypeCode", "typeCodeAttr", "typeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "isActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EntityType", "entityTypeAttr", "entityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsInteractiveEnabled", "isInteractiveEnabledAttr", "isInteractiveEnabled", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPreviewEnabled", "isPreviewEnabledAttr", "isPreviewEnabled", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IncludePDS", "includePDSAttr", "includePDS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IncludePHIS", "includePHISAttr", "includePHIS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPrintEnabled", "isPrintEnabledAttr", "isPrintEnabled", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPrintDefault", "isPrintDefaultAttr", "isPrintDefault", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Channel", "channelAttr", "channel", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList), 
this.attr("Properties", "propertiesAttr", "properties", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.TemplatePropertiesList());
}, true, APIGateway_ISModel.TemplatePropertiesList)
].concat(_super.attributesToDeclare.call(this));
};
GetCommunicationTypeResponseRec.init();
return GetCommunicationTypeResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetCommunicationTypeResponseRec = GetCommunicationTypeResponseRec;

});
define("APIGateway_IS.model$GetPolicy_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicy_APIResponseRec = (function (_super) {
__extends(GetPolicy_APIResponseRec, _super);
function GetPolicy_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicy_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDate", "entryDateAttr", "entryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StartDateOther", "startDateOtherAttr", "startDateOther", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDateOther", "entryDateOtherAttr", "entryDateOther", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyStatus", "policyStatusAttr", "policyStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Group", "groupAttr", "group", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BranchCode", "branchCodeAttr", "branchCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Branch", "branchAttr", "branch", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AgentCode", "agentCodeAttr", "agentCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Agent", "agentAttr", "agent", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Site", "siteAttr", "site", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTierCode", "productTierCodeAttr", "productTierCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductTier", "productTierAttr", "productTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScale", "rateScaleAttr", "rateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherProductName", "otherProductNameAttr", "otherProductName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherRateScale", "otherRateScaleAttr", "otherRateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CoverContinuityDate", "coverContinuityDateAttr", "coverContinuityDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicy_APIResponseRec.init();
return GetPolicy_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicy_APIResponseRec = GetPolicy_APIResponseRec;

});
define("APIGateway_IS.model$PHIPolicyListResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIProblemDetailsRec", "APIGateway_IS.model$PHIPolicyList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIPolicyListResponseRec = (function (_super) {
__extends(PHIPolicyListResponseRec, _super);
function PHIPolicyListResponseRec(defaults) {
_super.apply(this, arguments);
}
PHIPolicyListResponseRec.attributesToDeclare = function () {
return [
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec), 
this.attr("PolicyDtoList", "policyDtoListAttr", "PolicyDtoList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIPolicyList());
}, true, APIGateway_ISModel.PHIPolicyList)
].concat(_super.attributesToDeclare.call(this));
};
PHIPolicyListResponseRec.init();
return PHIPolicyListResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIPolicyListResponseRec = PHIPolicyListResponseRec;

});
define("APIGateway_IS.model$APIConfigRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var APIConfigRec = (function (_super) {
__extends(APIConfigRec, _super);
function APIConfigRec(defaults) {
_super.apply(this, arguments);
}
APIConfigRec.attributesToDeclare = function () {
return [
this.attr("ClientId", "clientIdAttr", "ClientId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ClientSecret", "clientSecretAttr", "ClientSecret", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubscriptionKey", "subscriptionKeyAttr", "SubscriptionKey", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MicrosoftTenantIdentifier", "microsoftTenantIdentifierAttr", "MicrosoftTenantIdentifier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ApplicationID", "applicationIDAttr", "ApplicationID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BaseURL", "baseURLAttr", "BaseURL", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
APIConfigRec.init();
return APIConfigRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.APIConfigRec = APIConfigRec;

});
define("APIGateway_IS.model$PHINote_Search_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHINote_Search_RequestRec = (function (_super) {
__extends(PHINote_Search_RequestRec, _super);
function PHINote_Search_RequestRec(defaults) {
_super.apply(this, arguments);
}
PHINote_Search_RequestRec.attributesToDeclare = function () {
return [
this.attr("EntityType", "entityTypeAttr", "EntityType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityId", "entityIdAttr", "EntityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntryDateFrom", "entryDateFromAttr", "EntryDateFrom", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDateTo", "entryDateToAttr", "EntryDateTo", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RaisedBy", "raisedByAttr", "RaisedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("NoteTypeCode", "noteTypeCodeAttr", "NoteTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsPriorityNote", "isPriorityNoteAttr", "IsPriorityNote", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "OrderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "OrderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "PageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("PageSize", "pageSizeAttr", "PageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PHINote_Search_RequestRec.init();
return PHINote_Search_RequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHINote_Search_RequestRec = PHINote_Search_RequestRec;

});
define("APIGateway_IS.model$GetRatesQuoteRevisionsRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$MemberItemList", "APIGateway_IS.model$FrequencyQuoteItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetRatesQuoteRevisionsRec = (function (_super) {
__extends(GetRatesQuoteRevisionsRec, _super);
function GetRatesQuoteRevisionsRec(defaults) {
_super.apply(this, arguments);
}
GetRatesQuoteRevisionsRec.attributesToDeclare = function () {
return [
this.attr("Cover", "coverAttr", "cover", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Members", "membersAttr", "members", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.MemberItemList());
}, true, APIGateway_ISModel.MemberItemList), 
this.attr("GroupCode", "groupCodeAttr", "groupCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateAge", "rebateAgeAttr", "rebateAge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateTier", "rebateTierAttr", "rebateTier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebateLevel", "rebateLevelAttr", "rebateLevel", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AbdPercentage", "abdPercentageAttr", "abdPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("EffectiveDate", "effectiveDateAttr", "effectiveDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntryDateTime", "entryDateTimeAttr", "entryDateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("RateScaleCode", "rateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FrequencyQuotes", "frequencyQuotesAttr", "frequencyQuotes", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FrequencyQuoteItemList());
}, true, APIGateway_ISModel.FrequencyQuoteItemList), 
this.attr("ResidencyStatus", "residencyStatusAttr", "residencyStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RebatePercentage", "rebatePercentageAttr", "rebatePercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("OtherRateScaleCode", "otherRateScaleCodeAttr", "otherRateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateTerritoryCode", "stateTerritoryCodeAttr", "stateTerritoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HasOverageDependants", "hasOverageDependantsAttr", "hasOverageDependants", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HasStudentDependants", "hasStudentDependantsAttr", "hasStudentDependants", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("LhcLoadingPercentage", "lhcLoadingPercentageAttr", "lhcLoadingPercentage", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("RatesQuoteRevisionId", "ratesQuoteRevisionIdAttr", "ratesQuoteRevisionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ContributionFrequency", "contributionFrequencyAttr", "contributionFrequency", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilityReasonCode", "eligibilityReasonCodeAttr", "eligibilityReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EligibilitySubReasonCode", "eligibilitySubReasonCodeAttr", "eligibilitySubReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IgnoreMembershipConditions", "ignoreMembershipConditionsAttr", "ignoreMembershipConditions", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("HasAdultDependantsDisability", "hasAdultDependantsDisabilityAttr", "hasAdultDependantsDisability", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetRatesQuoteRevisionsRec.init();
return GetRatesQuoteRevisionsRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetRatesQuoteRevisionsRec = GetRatesQuoteRevisionsRec;

});
define("APIGateway_IS.model$GetRatesQuoteRevisionsList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$GetRatesQuoteRevisionsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetRatesQuoteRevisionsList = (function (_super) {
__extends(GetRatesQuoteRevisionsList, _super);
function GetRatesQuoteRevisionsList(defaults) {
_super.apply(this, arguments);
}
GetRatesQuoteRevisionsList.itemType = APIGateway_ISModel.GetRatesQuoteRevisionsRec;
return GetRatesQuoteRevisionsList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.GetRatesQuoteRevisionsList = GetRatesQuoteRevisionsList;

});
define("APIGateway_IS.model$GetRatesQuoteResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$GetRatesQuoteRevisionsList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetRatesQuoteResponseRec = (function (_super) {
__extends(GetRatesQuoteResponseRec, _super);
function GetRatesQuoteResponseRec(defaults) {
_super.apply(this, arguments);
}
GetRatesQuoteResponseRec.attributesToDeclare = function () {
return [
this.attr("Site", "siteAttr", "site", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Badge", "badgeAttr", "badge", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SiteCode", "siteCodeAttr", "siteCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BadgeCode", "badgeCodeAttr", "badgeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Revisions", "revisionsAttr", "revisions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.GetRatesQuoteRevisionsList());
}, true, APIGateway_ISModel.GetRatesQuoteRevisionsList), 
this.attr("QuoteStatus", "quoteStatusAttr", "quoteStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LocationCode", "locationCodeAttr", "locationCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RatesQuoteId", "ratesQuoteIdAttr", "ratesQuoteId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetRatesQuoteResponseRec.init();
return GetRatesQuoteResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetRatesQuoteResponseRec = GetRatesQuoteResponseRec;

});
define("APIGateway_IS.model$PHIUpdateNote_RecordRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIUpdateNote_RequestRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIUpdateNote_RecordRec = (function (_super) {
__extends(PHIUpdateNote_RecordRec, _super);
function PHIUpdateNote_RecordRec(defaults) {
_super.apply(this, arguments);
}
PHIUpdateNote_RecordRec.attributesToDeclare = function () {
return [
this.attr("UpdateNoteDto", "updateNoteDtoAttr", "UpdateNoteDto", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIUpdateNote_RequestRec());
}, true, APIGateway_ISModel.PHIUpdateNote_RequestRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIUpdateNote_RecordRec.fromStructure = function (str) {
return new PHIUpdateNote_RecordRec(new PHIUpdateNote_RecordRec.RecordClass({
updateNoteDtoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHIUpdateNote_RecordRec.init();
return PHIUpdateNote_RecordRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIUpdateNote_RecordRec = PHIUpdateNote_RecordRec;

});
define("APIGateway_IS.model$", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var LongIntegerList = (function (_super) {
__extends(LongIntegerList, _super);
function LongIntegerList(defaults) {
_super.apply(this, arguments);
}
LongIntegerList.itemType = OS.Types.LongInteger;
return LongIntegerList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.LongIntegerList = LongIntegerList;

});
define("APIGateway_IS.model$ReleaseCommunications_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ReleaseCommunications_APIResponseRec = (function (_super) {
__extends(ReleaseCommunications_APIResponseRec, _super);
function ReleaseCommunications_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
ReleaseCommunications_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("ReleasedCommIds", "releasedCommIdsAttr", "releasedCommIds", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.LongIntegerList());
}, true, OS.DataTypes.LongIntegerList)
].concat(_super.attributesToDeclare.call(this));
};
ReleaseCommunications_APIResponseRec.fromStructure = function (str) {
return new ReleaseCommunications_APIResponseRec(new ReleaseCommunications_APIResponseRec.RecordClass({
releasedCommIdsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ReleaseCommunications_APIResponseRec.init();
return ReleaseCommunications_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ReleaseCommunications_APIResponseRec = ReleaseCommunications_APIResponseRec;

});
define("APIGateway_IS.model$PolicyMembershipCardRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMembershipCardRec = (function (_super) {
__extends(PolicyMembershipCardRec, _super);
function PolicyMembershipCardRec(defaults) {
_super.apply(this, arguments);
}
PolicyMembershipCardRec.attributesToDeclare = function () {
return [
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CardNumber", "cardNumberAttr", "cardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IssueNumber", "issueNumberAttr", "issueNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IssueDate", "issueDateAttr", "issueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("MembershipCardStatus", "membershipCardStatusAttr", "membershipCardStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StatusDate", "statusDateAttr", "statusDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PolicyMembershipCardRec.init();
return PolicyMembershipCardRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PolicyMembershipCardRec = PolicyMembershipCardRec;

});
define("APIGateway_IS.model$AddAttachmentItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddAttachmentItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddAttachmentItemList = (function (_super) {
__extends(AddAttachmentItemList, _super);
function AddAttachmentItemList(defaults) {
_super.apply(this, arguments);
}
AddAttachmentItemList.itemType = APIGateway_ISModel.AddAttachmentItemRec;
return AddAttachmentItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddAttachmentItemList = AddAttachmentItemList;

});
define("APIGateway_IS.model$QueueCommunication_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$DataContextRec", "APIGateway_IS.model$FunctionDatumRec", "APIGateway_IS.model$AddAttachmentItemList", "APIGateway_IS.model$OptionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var QueueCommunication_APIRequestRec = (function (_super) {
__extends(QueueCommunication_APIRequestRec, _super);
function QueueCommunication_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
QueueCommunication_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "type", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CommBatchID", "commBatchIDAttr", "commBatchID", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("User", "userAttr", "user", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DataContext", "dataContextAttr", "dataContext", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.DataContextRec());
}, true, APIGateway_ISModel.DataContextRec), 
this.attr("Addressee", "addresseeAttr", "addressee", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.DataContextRec());
}, true, APIGateway_ISModel.DataContextRec), 
this.attr("FunctionName", "functionNameAttr", "functionName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FunctionData", "functionDataAttr", "functionData", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TemplateProperties", "templatePropertiesAttr", "templateProperties", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FunctionDatumRec());
}, true, APIGateway_ISModel.FunctionDatumRec), 
this.attr("AddAttachment", "addAttachmentAttr", "addAttachment", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddAttachmentItemList());
}, true, APIGateway_ISModel.AddAttachmentItemList), 
this.attr("Options", "optionsAttr", "options", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.OptionRec());
}, true, APIGateway_ISModel.OptionRec), 
this.attr("Publish", "publishAttr", "publish", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ReleaseDate", "releaseDateAttr", "releaseDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ExpiryDate", "expiryDateAttr", "expiryDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IncludePDS", "includePDSAttr", "includePDS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IncludeSIS", "includeSISAttr", "includeSIS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("BadgeId", "badgeIdAttr", "badgeId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
QueueCommunication_APIRequestRec.init();
return QueueCommunication_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.QueueCommunication_APIRequestRec = QueueCommunication_APIRequestRec;

});
define("APIGateway_IS.model$ResultItem_StakeholderQuotesRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_StakeholderQuotesRec = (function (_super) {
__extends(ResultItem_StakeholderQuotesRec, _super);
function ResultItem_StakeholderQuotesRec(defaults) {
_super.apply(this, arguments);
}
ResultItem_StakeholderQuotesRec.attributesToDeclare = function () {
return [
this.attr("QuoteId", "quoteIdAttr", "quoteId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RevisionDate", "revisionDateAttr", "revisionDate", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Revision", "revisionAttr", "revision", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Group", "groupAttr", "group", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductName", "productNameAttr", "productName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductType", "productTypeAttr", "productType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RateScale", "rateScaleAttr", "rateScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClassCode", "policyClassCodeAttr", "policyClassCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PolicyClass", "policyClassAttr", "policyClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherProductName", "otherProductNameAttr", "otherProductName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OtherScale", "otherScaleAttr", "otherScale", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StartDate", "startDateAttr", "startDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResultItem_StakeholderQuotesRec.init();
return ResultItem_StakeholderQuotesRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResultItem_StakeholderQuotesRec = ResultItem_StakeholderQuotesRec;

});
define("APIGateway_IS.model$PropertyItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PropertyItemRec = (function (_super) {
__extends(PropertyItemRec, _super);
function PropertyItemRec(defaults) {
_super.apply(this, arguments);
}
PropertyItemRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "value", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PropertyItemRec.init();
return PropertyItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PropertyItemRec = PropertyItemRec;

});
define("APIGateway_IS.model$PropertyItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PropertyItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PropertyItemList = (function (_super) {
__extends(PropertyItemList, _super);
function PropertyItemList(defaults) {
_super.apply(this, arguments);
}
PropertyItemList.itemType = APIGateway_ISModel.PropertyItemRec;
return PropertyItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PropertyItemList = PropertyItemList;

});
define("APIGateway_IS.model$AddUpdateReferenceRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PropertyItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddUpdateReferenceRec = (function (_super) {
__extends(AddUpdateReferenceRec, _super);
function AddUpdateReferenceRec(defaults) {
_super.apply(this, arguments);
}
AddUpdateReferenceRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Active", "activeAttr", "active", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Entity", "entityAttr", "entity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Priority", "priorityAttr", "priority", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Properties", "propertiesAttr", "properties", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PropertyItemList());
}, true, APIGateway_ISModel.PropertyItemList), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("concurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("parentEntityCode", "parentEntityCodeAttr", "parentEntityCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddUpdateReferenceRec.init();
return AddUpdateReferenceRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddUpdateReferenceRec = AddUpdateReferenceRec;

});
define("APIGateway_IS.model$PolicyMemberItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMemberItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMemberItemList = (function (_super) {
__extends(PolicyMemberItemList, _super);
function PolicyMemberItemList(defaults) {
_super.apply(this, arguments);
}
PolicyMemberItemList.itemType = APIGateway_ISModel.PolicyMemberItemRec;
return PolicyMemberItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyMemberItemList = PolicyMemberItemList;

});
define("APIGateway_IS.model$GetPolicyMembers_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMemberItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyMembers_APIResponseRec = (function (_super) {
__extends(GetPolicyMembers_APIResponseRec, _super);
function GetPolicyMembers_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyMembers_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("PolicyMembers", "policyMembersAttr", "policyMembers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyMemberItemList());
}, true, APIGateway_ISModel.PolicyMemberItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyMembers_APIResponseRec.fromStructure = function (str) {
return new GetPolicyMembers_APIResponseRec(new GetPolicyMembers_APIResponseRec.RecordClass({
policyMembersAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPolicyMembers_APIResponseRec.init();
return GetPolicyMembers_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyMembers_APIResponseRec = GetPolicyMembers_APIResponseRec;

});
define("APIGateway_IS.model$PropertyRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PropertyRec = (function (_super) {
__extends(PropertyRec, _super);
function PropertyRec(defaults) {
_super.apply(this, arguments);
}
PropertyRec.attributesToDeclare = function () {
return [
this.attr("NewTestDate", "newTestDateAttr", "NewTestDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SpaceTestString", "spaceTestStringAttr", "Space Test String", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddressChanged_Y_N_", "addressChanged_Y_N_Attr", "AddressChanged (Y/N)", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CPforCL3_2", "cPforCL3_2Attr", "1 CP for CL3.2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CPforCL3_3", "cPforCL3_3Attr", "2 CP for CL3.2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CPforCL3_4", "cPforCL3_4Attr", "3 CP for CL3.2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CPforCL3_5", "cPforCL3_5Attr", "4 CP for CL3.2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TestField1", "testField1Attr", "TestField1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CP1forCL3_5", "cP1forCL3_5Attr", "CP1 for CL3.5", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CP2forCL3_5", "cP2forCL3_5Attr", "CP2 for CL3.5", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CP3forCL3_5", "cP3forCL3_5Attr", "CP3 for CL3.5", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CP4forCL3_5", "cP4forCL3_5Attr", "CP4 for CL3.5", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MCL1_1_1PropertyNumber", "mCL1_1_1PropertyNumberAttr", "MCL1.1.1 Property Number", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MCL1_1_1PropertyText", "mCL1_1_1PropertyTextAttr", "MCL1.1.1 Property Text", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MCL1_1_1PropertyAmount", "mCL1_1_1PropertyAmountAttr", "MCL1.1.1 Property Amount", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MCL1_1_1PropertyDate", "mCL1_1_1PropertyDateAttr", "MCL1.1.1 Property Date", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OneTimePay", "oneTimePayAttr", "OneTimePay", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PayEndDate", "payEndDateAttr", "PayEndDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Z_TestingSpecialCharacters", "z_TestingSpecialCharactersAttr", "Z_TestingSpecialCharacters", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvWaitingPeriod", "intrvWaitingPeriodAttr", "IntrvWaitingPeriod", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvRichTexBox", "intrvRichTexBoxAttr", "IntrvRichTexBox", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvWaitBasic1", "intrvWaitBasic1Attr", "IntrvWaitBasic1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvWaitBasic2", "intrvWaitBasic2Attr", "IntrvWaitBasic2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvWaitSilver1", "intrvWaitSilver1Attr", "IntrvWaitSilver1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntrvWaitSilver2", "intrvWaitSilver2Attr", "IntrvWaitSilver2", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PropertyRec.init();
return PropertyRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PropertyRec = PropertyRec;

});
define("APIGateway_IS.model$ReleaseCommunications_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ReleaseCommunications_APIRequestRec = (function (_super) {
__extends(ReleaseCommunications_APIRequestRec, _super);
function ReleaseCommunications_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
ReleaseCommunications_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("CommunicationIds", "communicationIdsAttr", "communicationIds", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.LongIntegerList());
}, true, OS.DataTypes.LongIntegerList), 
this.attr("User", "userAttr", "user", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReleaseCommunications_APIRequestRec.init();
return ReleaseCommunications_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ReleaseCommunications_APIRequestRec = ReleaseCommunications_APIRequestRec;

});
define("APIGateway_IS.model$DocumentItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$DocumentItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var DocumentItemList = (function (_super) {
__extends(DocumentItemList, _super);
function DocumentItemList(defaults) {
_super.apply(this, arguments);
}
DocumentItemList.itemType = APIGateway_ISModel.DocumentItemRec;
return DocumentItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.DocumentItemList = DocumentItemList;

});
define("APIGateway_IS.model$Stakeholder_AddInteraction_Result_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$DocumentItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_AddInteraction_Result_APIRec = (function (_super) {
__extends(Stakeholder_AddInteraction_Result_APIRec, _super);
function Stakeholder_AddInteraction_Result_APIRec(defaults) {
_super.apply(this, arguments);
}
Stakeholder_AddInteraction_Result_APIRec.attributesToDeclare = function () {
return [
this.attr("Date", "dateAttr", "date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CaseId", "caseIdAttr", "caseId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Channel", "channelAttr", "channel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Details", "detailsAttr", "details", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Subject", "subjectAttr", "subject", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Category", "categoryAttr", "category", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedBy", "createdByAttr", "createdBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Direction", "directionAttr", "direction", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubCategory", "subCategoryAttr", "subCategory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CategoryCode", "categoryCodeAttr", "categoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("InteractionId", "interactionIdAttr", "interactionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContactDetails", "contactDetailsAttr", "contactDetails", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RestrictedView", "restrictedViewAttr", "restrictedView", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("SubCategoryCode", "subCategoryCodeAttr", "subCategoryCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Documents", "documentsAttr", "documents", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.DocumentItemList());
}, true, APIGateway_ISModel.DocumentItemList)
].concat(_super.attributesToDeclare.call(this));
};
Stakeholder_AddInteraction_Result_APIRec.init();
return Stakeholder_AddInteraction_Result_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Stakeholder_AddInteraction_Result_APIRec = Stakeholder_AddInteraction_Result_APIRec;

});
define("APIGateway_IS.model$Stakeholder_AddInteraction_Result_APIList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Stakeholder_AddInteraction_Result_APIRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_AddInteraction_Result_APIList = (function (_super) {
__extends(Stakeholder_AddInteraction_Result_APIList, _super);
function Stakeholder_AddInteraction_Result_APIList(defaults) {
_super.apply(this, arguments);
}
Stakeholder_AddInteraction_Result_APIList.itemType = APIGateway_ISModel.Stakeholder_AddInteraction_Result_APIRec;
return Stakeholder_AddInteraction_Result_APIList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Stakeholder_AddInteraction_Result_APIList = Stakeholder_AddInteraction_Result_APIList;

});
define("APIGateway_IS.model$SearchStakeholderInteractions_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Stakeholder_AddInteraction_Result_APIList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SearchStakeholderInteractions_Response_APIRec = (function (_super) {
__extends(SearchStakeholderInteractions_Response_APIRec, _super);
function SearchStakeholderInteractions_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
SearchStakeholderInteractions_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Stakeholder_AddInteraction_Result_APIList());
}, true, APIGateway_ISModel.Stakeholder_AddInteraction_Result_APIList), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchStakeholderInteractions_Response_APIRec.init();
return SearchStakeholderInteractions_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SearchStakeholderInteractions_Response_APIRec = SearchStakeholderInteractions_Response_APIRec;

});
define("APIGateway_IS.model$AddUpdateReferenceList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddUpdateReferenceRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddUpdateReferenceList = (function (_super) {
__extends(AddUpdateReferenceList, _super);
function AddUpdateReferenceList(defaults) {
_super.apply(this, arguments);
}
AddUpdateReferenceList.itemType = APIGateway_ISModel.AddUpdateReferenceRec;
return AddUpdateReferenceList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddUpdateReferenceList = AddUpdateReferenceList;

});
define("APIGateway_IS.model$GetReferences_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddUpdateReferenceList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetReferences_APIResponseRec = (function (_super) {
__extends(GetReferences_APIResponseRec, _super);
function GetReferences_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetReferences_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("Entities", "entitiesAttr", "entities", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddUpdateReferenceList());
}, true, APIGateway_ISModel.AddUpdateReferenceList)
].concat(_super.attributesToDeclare.call(this));
};
GetReferences_APIResponseRec.fromStructure = function (str) {
return new GetReferences_APIResponseRec(new GetReferences_APIResponseRec.RecordClass({
entitiesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetReferences_APIResponseRec.init();
return GetReferences_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetReferences_APIResponseRec = GetReferences_APIResponseRec;

});
define("APIGateway_IS.model$SuspendPolicyMembers_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var SuspendPolicyMembers_APIRec = (function (_super) {
__extends(SuspendPolicyMembers_APIRec, _super);
function SuspendPolicyMembers_APIRec(defaults) {
_super.apply(this, arguments);
}
SuspendPolicyMembers_APIRec.attributesToDeclare = function () {
return [
this.attr("SuspensionReasonCode", "suspensionReasonCodeAttr", "suspensionReasonCode", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SuspensionStartDate", "suspensionStartDateAttr", "suspensionStartDate", true, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("SuspensionEndDate", "suspensionEndDateAttr", "suspensionEndDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("FollowUpDate", "followUpDateAttr", "followUpDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ReprocessReceipts", "reprocessReceiptsAttr", "reprocessReceipts", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AddSavingsEntitlement", "addSavingsEntitlementAttr", "addSavingsEntitlement", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ApplyLhcLoadingDueToAbsence", "applyLhcLoadingDueToAbsenceAttr", "applyLhcLoadingDueToAbsence", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SuspendPolicyMembers_APIRec.init();
return SuspendPolicyMembers_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.SuspendPolicyMembers_APIRec = SuspendPolicyMembers_APIRec;

});
define("APIGateway_IS.model$PolicyMembershipCardList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMembershipCardRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyMembershipCardList = (function (_super) {
__extends(PolicyMembershipCardList, _super);
function PolicyMembershipCardList(defaults) {
_super.apply(this, arguments);
}
PolicyMembershipCardList.itemType = APIGateway_ISModel.PolicyMembershipCardRec;
return PolicyMembershipCardList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyMembershipCardList = PolicyMembershipCardList;

});
define("APIGateway_IS.model$GetPolicyMembershipCards_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyMembershipCardList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetPolicyMembershipCards_APIResponseRec = (function (_super) {
__extends(GetPolicyMembershipCards_APIResponseRec, _super);
function GetPolicyMembershipCards_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetPolicyMembershipCards_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("PolicyMembershipCards", "policyMembershipCardsAttr", "policyMembershipCards", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyMembershipCardList());
}, true, APIGateway_ISModel.PolicyMembershipCardList)
].concat(_super.attributesToDeclare.call(this));
};
GetPolicyMembershipCards_APIResponseRec.fromStructure = function (str) {
return new GetPolicyMembershipCards_APIResponseRec(new GetPolicyMembershipCards_APIResponseRec.RecordClass({
policyMembershipCardsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetPolicyMembershipCards_APIResponseRec.init();
return GetPolicyMembershipCards_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetPolicyMembershipCards_APIResponseRec = GetPolicyMembershipCards_APIResponseRec;

});
define("APIGateway_IS.model$AddPreviousCoverItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddPreviousCoverItemRec = (function (_super) {
__extends(AddPreviousCoverItemRec, _super);
function AddPreviousCoverItemRec(defaults) {
_super.apply(this, arguments);
}
AddPreviousCoverItemRec.attributesToDeclare = function () {
return [
this.attr("PreviousFundCode", "previousFundCodeAttr", "previousFundCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("JoinDate", "joinDateAttr", "joinDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("PolicyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HealthRateScaleCode", "healthRateScaleCodeAttr", "rateScaleCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PaidHospitalDays", "paidHospitalDaysAttr", "paidHospitalDays", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddPreviousCoverItemRec.init();
return AddPreviousCoverItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddPreviousCoverItemRec = AddPreviousCoverItemRec;

});
define("APIGateway_IS.model$AddPreviousCoverItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddPreviousCoverItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddPreviousCoverItemList = (function (_super) {
__extends(AddPreviousCoverItemList, _super);
function AddPreviousCoverItemList(defaults) {
_super.apply(this, arguments);
}
AddPreviousCoverItemList.itemType = APIGateway_ISModel.AddPreviousCoverItemRec;
return AddPreviousCoverItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AddPreviousCoverItemList = AddPreviousCoverItemList;

});
define("APIGateway_IS.model$IndividualPreviousCovers_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AddPreviousCoverItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualPreviousCovers_Response_APIRec = (function (_super) {
__extends(IndividualPreviousCovers_Response_APIRec, _super);
function IndividualPreviousCovers_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
IndividualPreviousCovers_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("PreviousCovers", "previousCoversAttr", "previousCovers", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddPreviousCoverItemList());
}, true, APIGateway_ISModel.AddPreviousCoverItemList), 
this.attr("StakeholderIds", "stakeholderIdsAttr", "stakeholderIds", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList)
].concat(_super.attributesToDeclare.call(this));
};
IndividualPreviousCovers_Response_APIRec.init();
return IndividualPreviousCovers_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.IndividualPreviousCovers_Response_APIRec = IndividualPreviousCovers_Response_APIRec;

});
define("APIGateway_IS.model$CancelLead_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var CancelLead_APIRequestRec = (function (_super) {
__extends(CancelLead_APIRequestRec, _super);
function CancelLead_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
CancelLead_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("CancellationReasonCode", "cancellationReasonCodeAttr", "cancellationReasonCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CancelLead_APIRequestRec.fromStructure = function (str) {
return new CancelLead_APIRequestRec(new CancelLead_APIRequestRec.RecordClass({
cancellationReasonCodeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CancelLead_APIRequestRec.init();
return CancelLead_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.CancelLead_APIRequestRec = CancelLead_APIRequestRec;

});
define("APIGateway_IS.model$PreexistingConditionsResponseListRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PreexistingConditionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PreexistingConditionsResponseListRec = (function (_super) {
__extends(PreexistingConditionsResponseListRec, _super);
function PreexistingConditionsResponseListRec(defaults) {
_super.apply(this, arguments);
}
PreexistingConditionsResponseListRec.attributesToDeclare = function () {
return [
this.attr("PreexistingConditions", "preexistingConditionsAttr", "preexistingConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PreexistingConditionItemList());
}, true, APIGateway_ISModel.PreexistingConditionItemList)
].concat(_super.attributesToDeclare.call(this));
};
PreexistingConditionsResponseListRec.fromStructure = function (str) {
return new PreexistingConditionsResponseListRec(new PreexistingConditionsResponseListRec.RecordClass({
preexistingConditionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PreexistingConditionsResponseListRec.init();
return PreexistingConditionsResponseListRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PreexistingConditionsResponseListRec = PreexistingConditionsResponseListRec;

});
define("APIGateway_IS.model$PHIIndividualResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHIIndividualRec", "APIGateway_IS.model$PHIValidationProblemDetailsRec", "APIGateway_IS.model$PHIProblemDetailsRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHIIndividualResponseRec = (function (_super) {
__extends(PHIIndividualResponseRec, _super);
function PHIIndividualResponseRec(defaults) {
_super.apply(this, arguments);
}
PHIIndividualResponseRec.attributesToDeclare = function () {
return [
this.attr("IndividualDto", "individualDtoAttr", "IndividualDto", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIIndividualRec());
}, true, APIGateway_ISModel.PHIIndividualRec), 
this.attr("ValidationProblemDetails", "validationProblemDetailsAttr", "ValidationProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIValidationProblemDetailsRec());
}, true, APIGateway_ISModel.PHIValidationProblemDetailsRec), 
this.attr("ProblemDetails", "problemDetailsAttr", "ProblemDetails", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIProblemDetailsRec());
}, true, APIGateway_ISModel.PHIProblemDetailsRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIIndividualResponseRec.init();
return PHIIndividualResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHIIndividualResponseRec = PHIIndividualResponseRec;

});
define("APIGateway_IS.model$Product_RevisionList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RevisionRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RevisionList = (function (_super) {
__extends(Product_RevisionList, _super);
function Product_RevisionList(defaults) {
_super.apply(this, arguments);
}
Product_RevisionList.itemType = APIGateway_ISModel.Product_RevisionRec;
return Product_RevisionList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_RevisionList = Product_RevisionList;

});
define("APIGateway_IS.model$Product_RateList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RateRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_RateList = (function (_super) {
__extends(Product_RateList, _super);
function Product_RateList(defaults) {
_super.apply(this, arguments);
}
Product_RateList.itemType = APIGateway_ISModel.Product_RateRec;
return Product_RateList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_RateList = Product_RateList;

});
define("APIGateway_IS.model$Product_ComponentList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_ComponentRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_ComponentList = (function (_super) {
__extends(Product_ComponentList, _super);
function Product_ComponentList(defaults) {
_super.apply(this, arguments);
}
Product_ComponentList.itemType = APIGateway_ISModel.Product_ComponentRec;
return Product_ComponentList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_ComponentList = Product_ComponentList;

});
define("APIGateway_IS.model$Product_WaitingPeriodList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_WaitingPeriodRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_WaitingPeriodList = (function (_super) {
__extends(Product_WaitingPeriodList, _super);
function Product_WaitingPeriodList(defaults) {
_super.apply(this, arguments);
}
Product_WaitingPeriodList.itemType = APIGateway_ISModel.Product_WaitingPeriodRec;
return Product_WaitingPeriodList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_WaitingPeriodList = Product_WaitingPeriodList;

});
define("APIGateway_IS.model$Product_BenefitConditionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_BenefitConditionItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Product_BenefitConditionItemList = (function (_super) {
__extends(Product_BenefitConditionItemList, _super);
function Product_BenefitConditionItemList(defaults) {
_super.apply(this, arguments);
}
Product_BenefitConditionItemList.itemType = APIGateway_ISModel.Product_BenefitConditionItemRec;
return Product_BenefitConditionItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Product_BenefitConditionItemList = Product_BenefitConditionItemList;

});
define("APIGateway_IS.model$GetProduct_APIResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Product_RevisionList", "APIGateway_IS.model$Product_RateList", "APIGateway_IS.model$Product_ComponentList", "APIGateway_IS.model$Product_WaitingPeriodList", "APIGateway_IS.model$Product_BenefitConditionItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetProduct_APIResponseRec = (function (_super) {
__extends(GetProduct_APIResponseRec, _super);
function GetProduct_APIResponseRec(defaults) {
_super.apply(this, arguments);
}
GetProduct_APIResponseRec.attributesToDeclare = function () {
return [
this.attr("ProductCode", "productCodeAttr", "productCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Class", "classAttr", "class", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CommencementDate", "commencementDateAttr", "commencementDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Tier", "tierAttr", "tier", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DiscountType", "discountTypeAttr", "discountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Revisions", "revisionsAttr", "revisions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_RevisionList());
}, true, APIGateway_ISModel.Product_RevisionList), 
this.attr("Rates", "ratesAttr", "rates", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_RateList());
}, true, APIGateway_ISModel.Product_RateList), 
this.attr("Components", "componentsAttr", "components", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_ComponentList());
}, true, APIGateway_ISModel.Product_ComponentList), 
this.attr("WaitingPeriods", "waitingPeriodsAttr", "waitingPeriods", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_WaitingPeriodList());
}, true, APIGateway_ISModel.Product_WaitingPeriodList), 
this.attr("BenefitConditions", "benefitConditionsAttr", "benefitConditions", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Product_BenefitConditionItemList());
}, true, APIGateway_ISModel.Product_BenefitConditionItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetProduct_APIResponseRec.init();
return GetProduct_APIResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetProduct_APIResponseRec = GetProduct_APIResponseRec;

});
define("APIGateway_IS.model$Stakeholder_PatchItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Stakeholder_PatchItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_PatchItemList = (function (_super) {
__extends(Stakeholder_PatchItemList, _super);
function Stakeholder_PatchItemList(defaults) {
_super.apply(this, arguments);
}
Stakeholder_PatchItemList.itemType = APIGateway_ISModel.Stakeholder_PatchItemRec;
return Stakeholder_PatchItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.Stakeholder_PatchItemList = Stakeholder_PatchItemList;

});
define("APIGateway_IS.model$Stakeholder_PatchRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$Stakeholder_PatchItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_PatchRequestRec = (function (_super) {
__extends(Stakeholder_PatchRequestRec, _super);
function Stakeholder_PatchRequestRec(defaults) {
_super.apply(this, arguments);
}
Stakeholder_PatchRequestRec.attributesToDeclare = function () {
return [
this.attr("Items", "itemsAttr", "items", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.Stakeholder_PatchItemList());
}, true, APIGateway_ISModel.Stakeholder_PatchItemList)
].concat(_super.attributesToDeclare.call(this));
};
Stakeholder_PatchRequestRec.fromStructure = function (str) {
return new Stakeholder_PatchRequestRec(new Stakeholder_PatchRequestRec.RecordClass({
itemsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Stakeholder_PatchRequestRec.init();
return Stakeholder_PatchRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Stakeholder_PatchRequestRec = Stakeholder_PatchRequestRec;

});
define("APIGateway_IS.model$AddPolicyMembershipCard_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AddPolicyMembershipCard_APIRequestRec = (function (_super) {
__extends(AddPolicyMembershipCard_APIRequestRec, _super);
function AddPolicyMembershipCard_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
AddPolicyMembershipCard_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("StakeholderIds", "stakeholderIdsAttr", "stakeholderIds", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList), 
this.attr("ReplacementReason", "replacementReasonAttr", "replacementReason", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AddPolicyMembershipCard_APIRequestRec.init();
return AddPolicyMembershipCard_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AddPolicyMembershipCard_APIRequestRec = AddPolicyMembershipCard_APIRequestRec;

});
define("APIGateway_IS.model$ResultItem_StakeholderQuotesList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_StakeholderQuotesRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResultItem_StakeholderQuotesList = (function (_super) {
__extends(ResultItem_StakeholderQuotesList, _super);
function ResultItem_StakeholderQuotesList(defaults) {
_super.apply(this, arguments);
}
ResultItem_StakeholderQuotesList.itemType = APIGateway_ISModel.ResultItem_StakeholderQuotesRec;
return ResultItem_StakeholderQuotesList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.ResultItem_StakeholderQuotesList = ResultItem_StakeholderQuotesList;

});
define("APIGateway_IS.model$StakeholderQuotes_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$ResultItem_StakeholderQuotesList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var StakeholderQuotes_APIRec = (function (_super) {
__extends(StakeholderQuotes_APIRec, _super);
function StakeholderQuotes_APIRec(defaults) {
_super.apply(this, arguments);
}
StakeholderQuotes_APIRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultAttr", "result", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ResultItem_StakeholderQuotesList());
}, true, APIGateway_ISModel.ResultItem_StakeholderQuotesList), 
this.attr("OrderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TotalCount", "totalCountAttr", "totalCount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StakeholderQuotes_APIRec.init();
return StakeholderQuotes_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.StakeholderQuotes_APIRec = StakeholderQuotes_APIRec;

});
define("APIGateway_IS.model$AuditHistory_APIRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AuditHistory_APIRequestRec = (function (_super) {
__extends(AuditHistory_APIRequestRec, _super);
function AuditHistory_APIRequestRec(defaults) {
_super.apply(this, arguments);
}
AuditHistory_APIRequestRec.attributesToDeclare = function () {
return [
this.attr("AuditActions", "auditActionsAttr", "AuditActions", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditTypeCodes", "auditTypeCodesAttr", "AuditTypeCodes", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChangedBy", "changedByAttr", "ChangedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateFrom", "dateFromAttr", "DateFrom", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DateTo", "dateToAttr", "DateTo", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("EntityId", "entityIdAttr", "EntityId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IncludedTotalCount", "includedTotalCountAttr", "IncludedTotalCount", false, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("OrderByDirection", "orderByDirectionAttr", "OrderByDirection", false, false, OS.Types.Text, function () {
return "Descending";
}, true), 
this.attr("OrderByField", "orderByFieldAttr", "OrderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PageNumber", "pageNumberAttr", "PageNumber", false, false, OS.Types.Integer, function () {
return 1;
}, true), 
this.attr("PageSize", "pageSizeAttr", "PageSize", false, false, OS.Types.Integer, function () {
return 25;
}, true), 
this.attr("EntityType", "entityTypeAttr", "EntityType", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AuditHistory_APIRequestRec.init();
return AuditHistory_APIRequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AuditHistory_APIRequestRec = AuditHistory_APIRequestRec;

});
define("APIGateway_IS.model$PHI_QuoteList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHI_QuoteRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_QuoteList = (function (_super) {
__extends(PHI_QuoteList, _super);
function PHI_QuoteList(defaults) {
_super.apply(this, arguments);
}
PHI_QuoteList.itemType = APIGateway_ISModel.PHI_QuoteRec;
return PHI_QuoteList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PHI_QuoteList = PHI_QuoteList;

});
define("APIGateway_IS.model$PHI_QuotesRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PHI_QuoteList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PHI_QuotesRec = (function (_super) {
__extends(PHI_QuotesRec, _super);
function PHI_QuotesRec(defaults) {
_super.apply(this, arguments);
}
PHI_QuotesRec.attributesToDeclare = function () {
return [
this.attr("quotes", "quotesAttr", "quotes", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHI_QuoteList());
}, true, APIGateway_ISModel.PHI_QuoteList)
].concat(_super.attributesToDeclare.call(this));
};
PHI_QuotesRec.fromStructure = function (str) {
return new PHI_QuotesRec(new PHI_QuotesRec.RecordClass({
quotesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHI_QuotesRec.init();
return PHI_QuotesRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.PHI_QuotesRec = PHI_QuotesRec;

});
define("APIGateway_IS.model$PolicyRoleItemV1List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItemV1Rec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PolicyRoleItemV1List = (function (_super) {
__extends(PolicyRoleItemV1List, _super);
function PolicyRoleItemV1List(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItemV1List.itemType = APIGateway_ISModel.PolicyRoleItemV1Rec;
return PolicyRoleItemV1List;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PolicyRoleItemV1List = PolicyRoleItemV1List;

});
define("APIGateway_IS.model$IndividualPolicyRoles_ResponseV1Rec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PolicyRoleItemV1List"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var IndividualPolicyRoles_ResponseV1Rec = (function (_super) {
__extends(IndividualPolicyRoles_ResponseV1Rec, _super);
function IndividualPolicyRoles_ResponseV1Rec(defaults) {
_super.apply(this, arguments);
}
IndividualPolicyRoles_ResponseV1Rec.attributesToDeclare = function () {
return [
this.attr("PolicyRoles", "policyRolesAttr", "policyRoles", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRoleItemV1List());
}, true, APIGateway_ISModel.PolicyRoleItemV1List)
].concat(_super.attributesToDeclare.call(this));
};
IndividualPolicyRoles_ResponseV1Rec.fromStructure = function (str) {
return new IndividualPolicyRoles_ResponseV1Rec(new IndividualPolicyRoles_ResponseV1Rec.RecordClass({
policyRolesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IndividualPolicyRoles_ResponseV1Rec.init();
return IndividualPolicyRoles_ResponseV1Rec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.IndividualPolicyRoles_ResponseV1Rec = IndividualPolicyRoles_ResponseV1Rec;

});
define("APIGateway_IS.model$GetIdentityResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetIdentityResponseRec = (function (_super) {
__extends(GetIdentityResponseRec, _super);
function GetIdentityResponseRec(defaults) {
_super.apply(this, arguments);
}
GetIdentityResponseRec.attributesToDeclare = function () {
return [
this.attr("AccountEnabled", "accountEnabledAttr", "accountEnabled", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetIdentityResponseRec.fromStructure = function (str) {
return new GetIdentityResponseRec(new GetIdentityResponseRec.RecordClass({
accountEnabledAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetIdentityResponseRec.init();
return GetIdentityResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetIdentityResponseRec = GetIdentityResponseRec;

});
define("APIGateway_IS.model$ContactDetailV2_ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$EmailItemRec", "APIGateway_IS.model$PhoneNumberItemList", "APIGateway_IS.model$AddressItemList", "APIGateway_IS.model$CommunicationPreferenceItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ContactDetailV2_ResponseRec = (function (_super) {
__extends(ContactDetailV2_ResponseRec, _super);
function ContactDetailV2_ResponseRec(defaults) {
_super.apply(this, arguments);
}
ContactDetailV2_ResponseRec.attributesToDeclare = function () {
return [
this.attr("Email", "emailAttr", "email", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItemRec());
}, true, APIGateway_ISModel.EmailItemRec), 
this.attr("Phones", "phonesAttr", "phones", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemList());
}, true, APIGateway_ISModel.PhoneNumberItemList), 
this.attr("Addresses", "addressesAttr", "addresses", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItemList());
}, true, APIGateway_ISModel.AddressItemList), 
this.attr("CommunicationPreferences", "communicationPreferencesAttr", "communicationPreferences", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.CommunicationPreferenceItemList());
}, true, APIGateway_ISModel.CommunicationPreferenceItemList)
].concat(_super.attributesToDeclare.call(this));
};
ContactDetailV2_ResponseRec.init();
return ContactDetailV2_ResponseRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ContactDetailV2_ResponseRec = ContactDetailV2_ResponseRec;

});
define("APIGateway_IS.model$AccountItemRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AccountItemRec = (function (_super) {
__extends(AccountItemRec, _super);
function AccountItemRec(defaults) {
_super.apply(this, arguments);
}
AccountItemRec.attributesToDeclare = function () {
return [
this.attr("Bsb", "bsbAttr", "bsb", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountId", "accountIdAttr", "accountId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AccountName", "accountNameAttr", "accountName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountType", "accountTypeAttr", "accountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Institution", "institutionAttr", "institution", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountClass", "accountClassAttr", "accountClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountNumber", "accountNumberAttr", "accountNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountStatus", "accountStatusAttr", "accountStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CardExpiryDate", "cardExpiryDateAttr", "cardExpiryDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("AccountClassCode", "accountClassCodeAttr", "accountClassCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AccountItemRec.init();
return AccountItemRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.AccountItemRec = AccountItemRec;

});
define("APIGateway_IS.model$AccountItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AccountItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var AccountItemList = (function (_super) {
__extends(AccountItemList, _super);
function AccountItemList(defaults) {
_super.apply(this, arguments);
}
AccountItemList.itemType = APIGateway_ISModel.AccountItemRec;
return AccountItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.AccountItemList = AccountItemList;

});
define("APIGateway_IS.model$GetIndividualAccounts_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$AccountItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var GetIndividualAccounts_Response_APIRec = (function (_super) {
__extends(GetIndividualAccounts_Response_APIRec, _super);
function GetIndividualAccounts_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
GetIndividualAccounts_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("Accounts", "accountsAttr", "accounts", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AccountItemList());
}, true, APIGateway_ISModel.AccountItemList)
].concat(_super.attributesToDeclare.call(this));
};
GetIndividualAccounts_Response_APIRec.fromStructure = function (str) {
return new GetIndividualAccounts_Response_APIRec(new GetIndividualAccounts_Response_APIRec.RecordClass({
accountsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetIndividualAccounts_Response_APIRec.init();
return GetIndividualAccounts_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.GetIndividualAccounts_Response_APIRec = GetIndividualAccounts_Response_APIRec;

});
define("APIGateway_IS.model$Stakeholder_AddInteraction_Response_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Stakeholder_AddInteraction_Response_APIRec = (function (_super) {
__extends(Stakeholder_AddInteraction_Response_APIRec, _super);
function Stakeholder_AddInteraction_Response_APIRec(defaults) {
_super.apply(this, arguments);
}
Stakeholder_AddInteraction_Response_APIRec.attributesToDeclare = function () {
return [
this.attr("InteractionId", "interactionIdAttr", "interactionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ConcurrencyToken", "concurrencyTokenAttr", "concurrencyToken", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Stakeholder_AddInteraction_Response_APIRec.init();
return Stakeholder_AddInteraction_Response_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Stakeholder_AddInteraction_Response_APIRec = Stakeholder_AddInteraction_Response_APIRec;

});
define("APIGateway_IS.model$PromptItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PromptItemRec"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var PromptItemList = (function (_super) {
__extends(PromptItemList, _super);
function PromptItemList(defaults) {
_super.apply(this, arguments);
}
PromptItemList.itemType = APIGateway_ISModel.PromptItemRec;
return PromptItemList;
})(OS.DataTypes.GenericRecordList);
APIGateway_ISModel.PromptItemList = PromptItemList;

});
define("APIGateway_IS.model$Impacts_APIRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "APIGateway_IS.model$PromptItemList"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var Impacts_APIRec = (function (_super) {
__extends(Impacts_APIRec, _super);
function Impacts_APIRec(defaults) {
_super.apply(this, arguments);
}
Impacts_APIRec.attributesToDeclare = function () {
return [
this.attr("Prompts", "promptsAttr", "prompts", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PromptItemList());
}, true, APIGateway_ISModel.PromptItemList)
].concat(_super.attributesToDeclare.call(this));
};
Impacts_APIRec.fromStructure = function (str) {
return new Impacts_APIRec(new Impacts_APIRec.RecordClass({
promptsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Impacts_APIRec.init();
return Impacts_APIRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.Impacts_APIRec = Impacts_APIRec;

});
define("APIGateway_IS.model$ResetMFARequestRec", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model"], function (exports, OutSystems, APIGateway_ISModel) {
var OS = OutSystems.Internal;
var ResetMFARequestRec = (function (_super) {
__extends(ResetMFARequestRec, _super);
function ResetMFARequestRec(defaults) {
_super.apply(this, arguments);
}
ResetMFARequestRec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "stakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderClass", "stakeholderClassAttr", "stakeholderClass", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResetMFARequestRec.init();
return ResetMFARequestRec;
})(OS.DataTypes.GenericRecord);
APIGateway_ISModel.ResetMFARequestRec = ResetMFARequestRec;

});
define("APIGateway_IS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var APIGateway_ISModel = exports;
});
