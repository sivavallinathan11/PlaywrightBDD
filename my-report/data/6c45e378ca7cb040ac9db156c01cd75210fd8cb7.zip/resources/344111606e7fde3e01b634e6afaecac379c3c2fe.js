define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$model", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "OutSystemsUI.model", "LazyDropdownSearch.controller", "LazyDropdownSearch.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "LazyDropdownSearch.referencesHealth", "LazyDropdownSearch.referencesHealth$OutSystemsUI", "LazyDropdownSearch.controller$ScrollToElement", "LazyDropdownSearch.controller$FocusOnElement"], function (OutSystems, LazyDropdownSearchModel, OutSystemsUIModel, LazyDropdownSearchController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsDropdownOpen", "isDropdownOpenVar", "IsDropdownOpen", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SearchTerm", "searchTermVar", "SearchTerm", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("ActiveItemIndex", "activeItemIndexVar", "ActiveItemIndex", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("IsFocused", "isFocusedVar", "IsFocused", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("FilteredItemList", "filteredItemListVar", "FilteredItemList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new LazyDropdownSearchModel.DropdownItemList());
}, false, LazyDropdownSearchModel.DropdownItemList), 
this.attr("ItemSelectedOnTouch", "itemSelectedOnTouchVar", "ItemSelectedOnTouch", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DropdownItemRec());
}, false, OutSystemsUIModel.DropdownItemRec), 
this.attr("ItemSelectedOnTouch_StartTimeMillis", "itemSelectedOnTouch_StartTimeMillisVar", "ItemSelectedOnTouch_StartTimeMillis", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, false), 
this.attr("DocumentEventListenerFunction", "documentEventListenerFunctionVar", "DocumentEventListenerFunction", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("IsTouchClick", "isTouchClickVar", "IsTouchClick", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SearchResultValues", "searchResultValuesIn", "SearchResultValues", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new LazyDropdownSearchModel.DropdownItemList());
}, false, LazyDropdownSearchModel.DropdownItemList), 
this.attr("_searchResultValuesInDataFetchStatus", "_searchResultValuesInDataFetchStatus", "_searchResultValuesInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SearchPrompt", "searchPromptIn", "SearchPrompt", true, false, OS.Types.Text, function () {
return "Search";
}, false), 
this.attr("_searchPromptInDataFetchStatus", "_searchPromptInDataFetchStatus", "_searchPromptInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SelectedItem", "selectedItemIn", "SelectedItem", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DropdownItemRec());
}, false, OutSystemsUIModel.DropdownItemRec), 
this.attr("_selectedItemInDataFetchStatus", "_selectedItemInDataFetchStatus", "_selectedItemInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsAutoFilter", "isAutoFilterIn", "IsAutoFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isAutoFilterInDataFetchStatus", "_isAutoFilterInDataFetchStatus", "_isAutoFilterInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsAutoSort", "isAutoSortIn", "IsAutoSort", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_isAutoSortInDataFetchStatus", "_isAutoSortInDataFetchStatus", "_isAutoSortInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("EmptyText", "emptyTextIn", "EmptyText", true, false, OS.Types.Text, function () {
return "Select";
}, false), 
this.attr("_emptyTextInDataFetchStatus", "_emptyTextInDataFetchStatus", "_emptyTextInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Enabled", "enabledIn", "Enabled", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_enabledInDataFetchStatus", "_enabledInDataFetchStatus", "_enabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsValid", "isValidIn", "IsValid", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_isValidInDataFetchStatus", "_isValidInDataFetchStatus", "_isValidInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ErrorMessage", "errorMessageIn", "ErrorMessage", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_errorMessageInDataFetchStatus", "_errorMessageInDataFetchStatus", "_errorMessageInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_SearchTerm: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("SearchResultValues" in inputs) {
this.variables.searchResultValuesIn = inputs.SearchResultValues;
if("_searchResultValuesInDataFetchStatus" in inputs) {
this.variables._searchResultValuesInDataFetchStatus = inputs._searchResultValuesInDataFetchStatus;
}

}

if("SearchPrompt" in inputs) {
this.variables.searchPromptIn = inputs.SearchPrompt;
if("_searchPromptInDataFetchStatus" in inputs) {
this.variables._searchPromptInDataFetchStatus = inputs._searchPromptInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

if("SelectedItem" in inputs) {
this.variables.selectedItemIn = inputs.SelectedItem;
if("_selectedItemInDataFetchStatus" in inputs) {
this.variables._selectedItemInDataFetchStatus = inputs._selectedItemInDataFetchStatus;
}

}

if("IsAutoFilter" in inputs) {
this.variables.isAutoFilterIn = inputs.IsAutoFilter;
if("_isAutoFilterInDataFetchStatus" in inputs) {
this.variables._isAutoFilterInDataFetchStatus = inputs._isAutoFilterInDataFetchStatus;
}

}

if("IsAutoSort" in inputs) {
this.variables.isAutoSortIn = inputs.IsAutoSort;
if("_isAutoSortInDataFetchStatus" in inputs) {
this.variables._isAutoSortInDataFetchStatus = inputs._isAutoSortInDataFetchStatus;
}

}

if("EmptyText" in inputs) {
this.variables.emptyTextIn = inputs.EmptyText;
if("_emptyTextInDataFetchStatus" in inputs) {
this.variables._emptyTextInDataFetchStatus = inputs._emptyTextInDataFetchStatus;
}

}

if("Enabled" in inputs) {
this.variables.enabledIn = inputs.Enabled;
if("_enabledInDataFetchStatus" in inputs) {
this.variables._enabledInDataFetchStatus = inputs._enabledInDataFetchStatus;
}

}

if("IsValid" in inputs) {
this.variables.isValidIn = inputs.IsValid;
if("_isValidInDataFetchStatus" in inputs) {
this.variables._isValidInDataFetchStatus = inputs._isValidInDataFetchStatus;
}

}

if("ErrorMessage" in inputs) {
this.variables.errorMessageIn = inputs.ErrorMessage;
if("_errorMessageInDataFetchStatus" in inputs) {
this.variables._errorMessageInDataFetchStatus = inputs._errorMessageInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "LazyDropdownSearch.LazyDropdownSearch");
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$view", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "OutSystemsUI.model", "react", "OutSystems/ReactView/Main", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$model", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller", "OutSystems/ReactWidgets/Main", "LazyDropdownSearch.LazyDropdownSearch.EventSwallowingOnClickContainer.mvc$view", "LazyDropdownSearch.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "LazyDropdownSearch.referencesHealth", "LazyDropdownSearch.referencesHealth$OutSystemsUI", "LazyDropdownSearch.controller$ScrollToElement", "LazyDropdownSearch.controller$FocusOnElement"], function (OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, OutSystemsUIModel, React, OSView, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_model, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller, OSWidgets, LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "LazyDropdownSearch.LazyDropdownSearch";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onFocus: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch/ChoicesElement onfocus");
controller.onFocus$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onBlur: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch/ChoicesElement onblur");
controller.onBlur$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onKeyPress: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch/ChoicesElement onkeypress");
controller.onKeypress$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
"data-type": "select-one",
tabIndex: "0",
role: "dropdown"
},
style: model.getCachedValue(idService.getId("ChoicesElement.Style"), function () {
return ((((("dropdown lazy-dropdown-search" + ((model.variables.isDropdownOpenVar) ? (" is-open") : (""))) + ((model.variables.isFocusedVar) ? (" is-focused") : (""))) + ((!(model.variables.enabledIn)) ? (" is-disabled") : (""))) + " ") + model.variables.extendedClassIn);
}, function () {
return model.variables.isDropdownOpenVar;
}, function () {
return model.variables.isFocusedVar;
}, function () {
return model.variables.enabledIn;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "ChoicesElement"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._enabledInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch/DropdownField onclick");
controller.onDropdownFieldClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
style: model.getCachedValue(idService.getId("DropdownField.Style"), function () {
return (("lazy-dropdown-search__inner" + ((model.variables.isValidIn) ? ("") : (" not-valid "))) + ((!(model.variables.enabledIn)) ? (" lazy-dropdown-search__list--disable") : ("")));
}, function () {
return model.variables.isValidIn;
}, function () {
return model.variables.enabledIn;
}),
visible: true,
_idProps: {
service: idService,
name: "DropdownField"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isValidInDataFetchStatus, model.variables._enabledInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "lazy-dropdown-search__list lazy-dropdown-search__list--single",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Q+Z5fZrKm0mhP49GfsGf6g.Style"), function () {
return ("lazy-dropdown-search__item needsclick lazy-dropdown-search__item--selectable" + (((model.variables.selectedItemIn.valueAttr === "")) ? (" lazy-dropdown-search__placeholder") : ("")));
}, function () {
return model.variables.selectedItemIn.valueAttr;
}),
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._selectedItemInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("GcuEe7tMf0KO4dGMSZ2wyQ.Style"), function () {
return ("drop-down-field" + ((model.variables.isDropdownOpenVar) ? (" open") : ("")));
}, function () {
return model.variables.isDropdownOpenVar;
}),
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "drop-down-field-value",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(((model.variables.selectedItemIn.valueAttr) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.selectedItemIn.textAttr,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._selectedItemInDataFetchStatus)
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.emptyTextIn,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._emptyTextInDataFetchStatus)
})];
})))))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-list-size": (model.variables.filteredItemListVar.length).toString()
},
style: model.getCachedValue(idService.getId("ChoicesListWrapper.Style"), function () {
return ("lazy-dropdown-search__list lazy-dropdown-search__list--dropdown" + ((model.variables.isDropdownOpenVar) ? (" is-active") : ("")));
}, function () {
return model.variables.isDropdownOpenVar;
}),
visible: true,
_idProps: {
service: idService,
name: "ChoicesListWrapper"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "dropdown-search-box",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "search--wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 50,
prompt: model.variables.searchPromptIn,
style: "form-control dropdown-search-field",
variable: model.createVariable(OS.Types.Text, model.variables.searchTermVar, function (value) {
model.variables.searchTermVar = value;
}),
_idProps: {
service: idService,
name: "Input_SearchTerm"
},
_widgetRecordProvider: widgetsRecordProvider,
prompt_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._searchPromptInDataFetchStatus)
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "lazy-dropdown-search__list",
visible: true,
_idProps: {
service: idService,
name: "ChoicesList"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
style: "no-results",
visible: model.variables.filteredItemListVar.isEmpty,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, "No results"), React.createElement(OSWidgets.List, {
animateItems: true,
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.filteredItemListVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "DropdownOptionsList"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(LazyDropdownSearch_LazyDropdownSearch_EventSwallowingOnClickContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onTouchEnd$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/EventSwallowingOnClickContainer OnTouchEnd");
return controller.dropdownItemTouchEnd$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onTouchStart$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/EventSwallowingOnClickContainer OnTouchStart");
controller.dropdownItemTouchStart$Action(model.variables.filteredItemListVar.getCurrent(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onTouchMove$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/EventSwallowingOnClickContainer OnTouchMove");
controller.dropdownItemTouchMove$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
onClick$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/EventSwallowingOnClickContainer OnClick");
return controller.triggerOnItemSelected$Action(model.variables.filteredItemListVar.getCurrent(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "15",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("Qo91s65D00u_cNMn4HXcrg.Style"), function () {
return (("lazy-dropdown-search__item needsclick lazy-dropdown-search__item--choice lazy-dropdown-search__item--selectable" + (((model.variables.filteredItemListVar.getCurrentRowNumber(callContext.iterationContext) === model.variables.activeItemIndexVar)) ? (" is-highlighted") : (""))) + (((model.variables.filteredItemListVar.getCurrent(callContext.iterationContext).valueAttr === "")) ? (" lazy-dropdown-search__placeholder") : ("")));
}, function () {
return model.variables.filteredItemListVar.getCurrentRowNumber(callContext.iterationContext);
}, function () {
return model.variables.activeItemIndexVar;
}, function () {
return model.variables.filteredItemListVar.getCurrent(callContext.iterationContext).valueAttr;
}),
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.filteredItemListVar.getCurrent(callContext.iterationContext).textAttr,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.activeItemIndexVar), asPrimitiveValue(model.variables.filteredItemListVar.getCurrent(callContext.iterationContext).textAttr), asPrimitiveValue(model.variables.filteredItemListVar.getCurrent(callContext.iterationContext).valueAttr), asPrimitiveValue(model.variables.filteredItemListVar.getCurrentRowNumber(callContext.iterationContext))]
})];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.activeItemIndexVar)]
})))), $if(model.variables.isValidIn, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Expression, {
style: "validation-message",
value: model.variables.errorMessageIn,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._errorMessageInDataFetchStatus)
})];
}))];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller", ["OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "OutSystemsUI.model", "LazyDropdownSearch.languageResources", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$debugger", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnInputKeyDown.ScrollToActiveItemJS", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnReady.RegisterFieldEventHandlersJS", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnDestroy.RemoveEventListenersJS", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.DropdownItemTouchEnd.GetTimeInMillisecondsJS", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.DropdownItemTouchStart.GetTimeInMillisecondsJS", "LazyDropdownSearch.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "LazyDropdownSearch.referencesHealth", "LazyDropdownSearch.referencesHealth$OutSystemsUI", "LazyDropdownSearch.controller$ScrollToElement", "LazyDropdownSearch.controller$FocusOnElement"], function (OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, OutSystemsUIModel, LazyDropdownSearchLanguageResources, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_Debugger, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnInputKeyDown_ScrollToActiveItemJS, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnReady_RegisterFieldEventHandlersJS, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnDestroy_RemoveEventListenersJS, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_DropdownItemTouchEnd_GetTimeInMillisecondsJS, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_DropdownItemTouchStart_GetTimeInMillisecondsJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
triggerOnFilterValueChanged$Action: function (filterValueIn) {
filterValueIn = (filterValueIn === undefined) ? "" : filterValueIn;
return controller.executeActionInsideJSNode(controller._triggerOnFilterValueChanged$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(filterValueIn, OS.Types.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "TriggerOnFilterValueChanged");
},
onInputKeyDown$Action: function (keyCodeIn) {
keyCodeIn = (keyCodeIn === undefined) ? 0 : keyCodeIn;
return controller.executeActionInsideJSNode(controller._onInputKeyDown$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(keyCodeIn, OS.Types.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "OnInputKeyDown");
},
selectActiveItem$Action: function () {
return controller.executeActionInsideJSNode(controller._selectActiveItem$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "SelectActiveItem");
},
hideItemList$Action: function () {
return controller.executeActionInsideJSNode(controller._hideItemList$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "HideItemList");
},
showItemList$Action: function () {
return controller.executeActionInsideJSNode(controller._showItemList$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "ShowItemList");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onFocus$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnFocus");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:kQdzBgIFy0KAQsGkn+j9yQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.kQdzBgIFy0KAQsGkn+j9yQ:wlxZKuohkzwIVKmV0oAbWw", "LazyDropdownSearch", "OnFocus", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:oFFr515RwEqrQoImtg+2_w", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:G5U6wjUXWECXgsMWs4GseA", callContext.id);
// IsFocused = True
model.variables.isFocusedVar = true;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:G5U6wjUXWECXgsMWs4GseA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ActiveItemIndex = 0
model.variables.activeItemIndexVar = 0;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:EidGLlkmaUexHUtep0S3mA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:kQdzBgIFy0KAQsGkn+j9yQ", callContext.id);
}

};
Controller.prototype._setFilteredItems$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetFilteredItems");
callContext = controller.callContext(callContext);
var listFilterVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterVar = listFilterVar;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:_M+TCl454keoMWNceuEWBQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions._M+TCl454keoMWNceuEWBQ:WVZ8FivAOrmo14KqI3h_CQ", "LazyDropdownSearch", "SetFilteredItems", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:ga0aXjGijEei6Ht3Q9aMng", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:ZZivUi3A6kCJ1gYsW75BHw", callContext.id) && (model.variables.isAutoFilterIn && ((model.variables.searchTermVar) !== (""))))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:mWHMgyWDFkmxD_1sk3IyAw", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.searchResultValuesIn, function (p) {
return (OS.BuiltinFunctions.index(p.textAttr, model.variables.searchTermVar, 0, false, true) >= 0);
}, callContext);

OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:ZJ2Biy3h2k+_D6lF7b1y2g", callContext.id);
// Execute Action: RefreshFilteredItemList2
controller._refreshFilteredItemList$Action(listFilterVar.value.filteredListOut, callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2BLDV+s+AECIr3PmgSnsDg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Esk6DtFBc0OFqoDoag9caQ", callContext.id);
// Execute Action: RefreshFilteredItemList
controller._refreshFilteredItemList$Action(model.variables.searchResultValuesIn, callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:SSrb+XAYUEKfqaOTkcQwiA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:_M+TCl454keoMWNceuEWBQ", callContext.id);
}

};
Controller.prototype._setSelectedItemTextFromSearchResultValues$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetSelectedItemTextFromSearchResultValues");
callContext = controller.callContext(callContext);
var listFilterVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilterVar = listFilterVar;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:ai5OLpuxb0uj8JKMP2ewmA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.ai5OLpuxb0uj8JKMP2ewmA:TIAQYIFFFUO+Yu0Qkrkocg", "LazyDropdownSearch", "SetSelectedItemTextFromSearchResultValues", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:XGQAs0CViUmAomr1sUFiJw", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:b4fKUSXm+kCYVadoYOqdPA", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.searchResultValuesIn, function (p) {
return (p.valueAttr === model.variables.selectedItemIn.valueAttr);
}, callContext);

// Found?
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:JCB6lVF_kkqix6zsYULgsA", callContext.id) && !(listFilterVar.value.filteredListOut.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:j8bMjYI6QUSZ3hLZbbxbvA", callContext.id);
// SelectedItem.Text = ListFilter.FilteredList.Current.Text
model.variables.selectedItemIn.textAttr = listFilterVar.value.filteredListOut.getCurrent(callContext.iterationContext).textAttr;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:rwEMpqtIBkmsD2mXfVDgAQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:J1Fz9T+9QUWIl8iyiKfEaQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:ai5OLpuxb0uj8JKMP2ewmA", callContext.id);
}

};
Controller.prototype._onInputKeyDown$Action = function (keyCodeIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInputKeyDown");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.OnInputKeyDown$vars"))());
vars.value.keyCodeInLocal = keyCodeIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:tFwROASCSk+PEk8oMSiVxQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.tFwROASCSk+PEk8oMSiVxQ:RcIQEZ_uwAxL086_9ZTxbw", "LazyDropdownSearch", "OnInputKeyDown", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:hEpfHQshVEmwXmeGLJsnWQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// KeyCode
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:DY1W_HD+l0qgFsmFBIM2Jw", callContext.id) && (vars.value.keyCodeInLocal === 40))) {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:wjEHc7Qw906qbDDPkl7lDg", callContext.id) && (model.variables.activeItemIndexVar < (model.variables.filteredItemListVar.length - 1)))) {
// Increment ActiveItemIndex
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Ugarhrvi_kabxt6M2eaTGQ", callContext.id);
// ActiveItemIndex = ActiveItemIndex + 1
model.variables.activeItemIndexVar = (model.variables.activeItemIndexVar + 1);
}

} else {
return OS.Flow.executeSequence(function () {
if((vars.value.keyCodeInLocal === 38)) {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:1yhi5leLQ06eYU4CBOFyHA", callContext.id) && (model.variables.activeItemIndexVar > 0))) {
// Decrement ActiveItemIndex
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:y3K+aYhUfU+XrgJXScEozg", callContext.id);
// ActiveItemIndex = ActiveItemIndex - 1
model.variables.activeItemIndexVar = (model.variables.activeItemIndexVar - 1);
}

} else {
return OS.Flow.executeSequence(function () {
if((vars.value.keyCodeInLocal === 13)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:FbuVnMHrT0+QpWqheUvSBw", callContext.id);
// Execute Action: SelectActiveItem
return controller._selectActiveItem$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:mVK1drEus06AvQMnVodLuw", callContext.id);
return OS.Flow.returnAsync();

});
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:9Qlt6AP1k0OwfKl2OCcOXQ", callContext.id);
return OS.Flow.returnAsync();

}

});
}

});
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:8v4i4zffrU2+pgJlzq_tGg", callContext.id);
controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnInputKeyDown_ScrollToActiveItemJS, "ScrollToActiveItem", "OnInputKeyDown", {
ActiveItemIndex: OS.DataConversion.JSNodeParamConverter.to(model.variables.activeItemIndexVar, OS.Types.Integer),
ChoicesListId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("ChoicesList"), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:mVK1drEus06AvQMnVodLuw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:tFwROASCSk+PEk8oMSiVxQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:tFwROASCSk+PEk8oMSiVxQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.OnInputKeyDown$vars", [{
name: "KeyCode",
attrName: "keyCodeInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:vCB1OH2+UkO7uKTaBMYNdQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.vCB1OH2+UkO7uKTaBMYNdQ:9i2yC_g50FXOPa24YXK+GA", "LazyDropdownSearch", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:piz6b83MRE+Qgn3wkQw1Dw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:f7c_VekAy0WVufYJEZPLTQ", callContext.id) && model.variables.isAutoFilterIn)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:UKJoFvjD2Eq9E_agC2J0yQ", callContext.id);
// Execute Action: SetSelectedItemTextFromSearchResultValues
controller._setSelectedItemTextFromSearchResultValues$Action(callContext);
}

OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:FB5GldSkjk6Pstc98KZK5g", callContext.id);
// Execute Action: SetFilteredItems
controller._setFilteredItems$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:pqr+1YajL0Govfo7UJq0CQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:vCB1OH2+UkO7uKTaBMYNdQ", callContext.id);
}

};
Controller.prototype._selectActiveItem$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SelectActiveItem");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:lP7BP6ZaLEKObNq02RZ_XQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.lP7BP6ZaLEKObNq02RZ_XQ:1PSLY0DGluBVaVxw6Dti9w", "LazyDropdownSearch", "SelectActiveItem", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:K7MBcxz1GUCXUWwT1LcAug", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2PFjc2lIuEWw8hAHmlaZtg", callContext.id) && !(model.variables.filteredItemListVar.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:A1GrHGwle0SHFdRq9xOvXw", callContext.id);
// Execute Action: TriggerOnItemSelected
return controller._triggerOnItemSelected$Action(model.variables.filteredItemListVar.getItem(model.variables.activeItemIndexVar), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Yo3+0ziBH0OnWDRzI7xydw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Uu+SUVknYkS8Ye3d5aROkA", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:lP7BP6ZaLEKObNq02RZ_XQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:lP7BP6ZaLEKObNq02RZ_XQ", callContext.id);
throw ex;

});
};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:FsqGaKnYvUeEH+1WQHY_aw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.FsqGaKnYvUeEH+1WQHY_aw:RSlvTCSeH9R892q+6FZYng", "LazyDropdownSearch", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:qA_HCysGn0KlfyDQrbjgxQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:zhaEd7yMpkWQF0wOoM7l1w", callContext.id) && model.variables.isAutoFilterIn)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:O7Q3vWHQlkyutWUrZ4PVQw", callContext.id);
// Execute Action: SetSelectedItemTextFromSearchResultValues
controller._setSelectedItemTextFromSearchResultValues$Action(callContext);
}

if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:PhKY+8Eea0m66_iPxMgWeg", callContext.id) && (model.variables.selectedItemIn.valueAttr === ""))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:ubNYVeHDZ0mBh7vJcBMJJw", callContext.id);
// SelectedItem.Text = EmptyText
model.variables.selectedItemIn.textAttr = model.variables.emptyTextIn;
}

OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:8ptZuesqaUmnB8UkIMuDVw", callContext.id);
// Execute Action: SetFilteredItems
controller._setFilteredItems$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:7eMhi1hqQkamld3CtySCuQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:FsqGaKnYvUeEH+1WQHY_aw", callContext.id);
}

};
Controller.prototype._onKeypress$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnKeypress");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:zFIPgJgFv0mzLl1P9g9ZzA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.zFIPgJgFv0mzLl1P9g9ZzA:AKEIl04BwtyYJL97JZr28A", "LazyDropdownSearch", "OnKeypress", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:LaGkWE9F3ku_eJRuGknjQA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:iIKzZEygvEewjrit2f25vw", callContext.id) && model.variables.enabledIn)) {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:CCQ2woh4g0GvjhHPwmShAg", callContext.id) && !(model.variables.isDropdownOpenVar))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:0KFvXObVb0CU_q3aXU8lDQ", callContext.id);
// Execute Action: ShowItemList
controller._showItemList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:YS4dUxtG0kCkclVDR1jUtw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:XtXVxMUR5k2DhLkYkKhp2g", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:UXFLLE6YSk6Ci2oeGjzliQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:zFIPgJgFv0mzLl1P9g9ZzA", callContext.id);
}

};
Controller.prototype._onDropdownFieldClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDropdownFieldClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:KzQEgbMu+UW9Kdq8X6haOg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.KzQEgbMu+UW9Kdq8X6haOg:rmh4DZRCDkqYpaDfdoB7Fw", "LazyDropdownSearch", "OnDropdownFieldClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:UVa8xW1H1US7_ldjeSsFGQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:IMfqej1aV0OCbdlQiQdxSA", callContext.id) && model.variables.isDropdownOpenVar)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:gT+CNRCBQ02OdQfHQee+9w", callContext.id);
// Execute Action: HideItemList
controller._hideItemList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:+mzxYU1510GHRxAya_J7zA", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:5nBVrSUAMUSArCYHz4WTaA", callContext.id) && model.variables.enabledIn)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:eUFEGBcbMkymULz2Yips2g", callContext.id);
// Execute Action: ShowItemList
controller._showItemList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:+mzxYU1510GHRxAya_J7zA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:A8CauI+_mkqT2+daB9R+SQ", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:KzQEgbMu+UW9Kdq8X6haOg", callContext.id);
}

};
Controller.prototype._refreshFilteredItemList$Action = function (newItemListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RefreshFilteredItemList");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.RefreshFilteredItemList$vars"))());
vars.value.newItemListInLocal = newItemListIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:2ralhWUHCUO28xP5w_SR1w:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.2ralhWUHCUO28xP5w_SR1w:5_PJDfE612TLGdPSnlVotQ", "LazyDropdownSearch", "RefreshFilteredItemList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:fZ3s4TSnxkyAWjWEVJWltA", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2Xs2ASMARU260sToLIRflA", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.filteredItemListVar, callContext);
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:EQK7CTF510eijtma1iyl7Q", callContext.id) && (model.variables.searchTermVar === ""))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:w796k9zwAUSd1pveRSwyzg", callContext.id);
// EmptyDropdownItem.Value = ""
vars.value.emptyDropdownItemVar.valueAttr = "";
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:w796k9zwAUSd1pveRSwyzg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// EmptyDropdownItem.Text = EmptyText
vars.value.emptyDropdownItemVar.textAttr = model.variables.emptyTextIn;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:RgtxHzA6qkOzozg6CUnMvA", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.filteredItemListVar, vars.value.emptyDropdownItemVar, callContext);
}

if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:y+9x5djGkku1ykmGOM4rIw", callContext.id) && model.variables.isAutoSortIn)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:wGjzyVXna0auOpRzdoM9uQ", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(vars.value.newItemListInLocal, function (p) {
return p.textAttr;
}, true, callContext);
}

OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:XavUXROIikCKezZg_PnASg", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.filteredItemListVar, vars.value.newItemListInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:WrDz_tmofkCRu5dmLcBj8g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:2ralhWUHCUO28xP5w_SR1w", callContext.id);
}

};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.RefreshFilteredItemList$vars", [{
name: "NewItemList",
attrName: "newItemListInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new LazyDropdownSearchModel.DropdownItemList();
},
complexType: LazyDropdownSearchModel.DropdownItemList
}, {
name: "EmptyDropdownItem",
attrName: "emptyDropdownItemVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.prototype._showItemList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ShowItemList");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:LuZ5lsSi2EyOCfgzeFGcQw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.LuZ5lsSi2EyOCfgzeFGcQw:cSFyO69Vo_d6Rt8r4smCqw", "LazyDropdownSearch", "ShowItemList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:1QgW_4kkYkqA3O86vCGqGg", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:y0PHNxfJjkm8VqYGEOGD7g", callContext.id);
// IsDropdownOpen = True
model.variables.isDropdownOpenVar = true;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Pic2AY2Xuk+fdd6ndRV5eQ", callContext.id);
// Execute Action: ScrollToElement
LazyDropdownSearchController.default.scrollToElement$Action(idService.getId("ChoicesListWrapper"), false, callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:oa+yNd0t60usQyxsOfkOgw", callContext.id);
// Execute Action: FocusOnElement
LazyDropdownSearchController.default.focusOnElement$Action(idService.getId("Input_SearchTerm"), callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:R1UvT4JQn0K48iFM5+4y5g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:LuZ5lsSi2EyOCfgzeFGcQw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var registerFieldEventHandlersJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.registerFieldEventHandlersJSResult = registerFieldEventHandlersJSResult;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:hZyHwSRSX0KEaX1ULg4qAA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.hZyHwSRSX0KEaX1ULg4qAA:d+zeSr2yvVjjrThsufzXBA", "LazyDropdownSearch", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:MWtiYCm8okOQiAgGKe7Tbg", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:QzG9RJHC6kaoaocuik6DMw", callContext.id);
registerFieldEventHandlersJSResult.value = controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnReady_RegisterFieldEventHandlersJS, "RegisterFieldEventHandlers", "OnReady", {
DropdownFieldId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("DropdownField"), OS.Types.Text),
ChoicesListWrapperId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("ChoicesListWrapper"), OS.Types.Text),
IsListEmpty: OS.DataConversion.JSNodeParamConverter.to(model.variables.searchResultValuesIn.isEmpty, OS.Types.Boolean),
SearchTermInputFieldId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input_SearchTerm"), OS.Types.Text),
DocumentEventListenerFunction: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.OnReady$registerFieldEventHandlersJSResult"))();
jsNodeResult.documentEventListenerFunctionOut = OS.DataConversion.JSNodeParamConverter.from($parameters.DocumentEventListenerFunction, OS.Types.Object);
return jsNodeResult;
}, {
TriggerOnFilterValueChanged: controller.clientActionProxies.triggerOnFilterValueChanged$Action,
OnInputKeyDown: controller.clientActionProxies.onInputKeyDown$Action,
SelectActiveItem: controller.clientActionProxies.selectActiveItem$Action,
HideItemList: controller.clientActionProxies.hideItemList$Action,
ShowItemList: controller.clientActionProxies.showItemList$Action
}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:HwcWnzZblk6ZNBlRA3pl0Q", callContext.id);
// DocumentEventListenerFunction = RegisterFieldEventHandlers.DocumentEventListenerFunction
model.variables.documentEventListenerFunctionVar = registerFieldEventHandlersJSResult.value.documentEventListenerFunctionOut;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:TyTdv6VDHEuAnFrjfFy46A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:hZyHwSRSX0KEaX1ULg4qAA", callContext.id);
}

};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.OnReady$registerFieldEventHandlersJSResult", [{
name: "DocumentEventListenerFunction",
attrName: "documentEventListenerFunctionOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._dropdownItemTouchMove$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownItemTouchMove");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchMove$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:DgWixCiWN0CWmq7xOKT2Dg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.DgWixCiWN0CWmq7xOKT2Dg:c_4EnXER4TIQFWsH_mTuJA", "LazyDropdownSearch", "DropdownItemTouchMove", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:DBtJ2ii1Hkau_tgzB3zgbA", callContext.id);
// Reset ItemSelectedOnTouch
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2ooSxDMMKkO67usCJXXhYw", callContext.id);
// ItemSelectedOnTouch = EmptyDropdownItem
model.variables.itemSelectedOnTouchVar = vars.value.emptyDropdownItemVar;
// ItemSelectedOnTouch_StartTimeMillis
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:w_BpCghjfkG9tsMUdjw2vg", callContext.id);
// ItemSelectedOnTouch_StartTimeMillis = 0
model.variables.itemSelectedOnTouch_StartTimeMillisVar = OS.BuiltinFunctions.integerToLongInteger(0);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:JkJPMOILXUmSa_p552HT_A", callContext.id);
// IsTouchClick = False
model.variables.isTouchClickVar = false;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:vJakGIX2j024w2YA_xmhZA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:DgWixCiWN0CWmq7xOKT2Dg", callContext.id);
}

};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchMove$vars", [{
name: "EmptyDropdownItem",
attrName: "emptyDropdownItemVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.prototype._triggerOnItemSelected$Action = function (itemIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnItemSelected");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.TriggerOnItemSelected$vars"))());
vars.value.itemInLocal = itemIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:BAQUxRU67UGhn_mkDuoR8w:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.BAQUxRU67UGhn_mkDuoR8w:DPC2GOXu5cd7KannUHnkyA", "LazyDropdownSearch", "TriggerOnItemSelected", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:SS54YmayFEGCDpHElq1yew", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// SelectedItem
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Ht2MoyXi9ECubnTfwmYloQ", callContext.id);
// SelectedItem = Item
model.variables.selectedItemIn = vars.value.itemInLocal;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:bBQz7W8+Uk+zzJ2O+2h9LA", callContext.id);
// ActiveItemIndex = 0
model.variables.activeItemIndexVar = 0;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:7GLDm8LaQE2zdM2AkJw+tw", callContext.id);
// SearchTerm = ""
model.variables.searchTermVar = "";
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2cjGqkD0kkqfJwzitg1FvA", callContext.id);
// Trigger Event: OnItemSelected
return controller.onItemSelected$Action(vars.value.itemInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:TdJ66pgvf0mGDuhI+MB4wg", callContext.id);
// Execute Action: HideItemList
controller._hideItemList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Er63Wi01OkGQhC7MaIUcxg", callContext.id);
// Execute Action: TriggerOnFilterValueChanged
return controller._triggerOnFilterValueChanged$Action(model.variables.searchTermVar, callContext);
}).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:XnHjbxTcpUOQ7TSGLl+e9Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:BAQUxRU67UGhn_mkDuoR8w", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:BAQUxRU67UGhn_mkDuoR8w", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.TriggerOnItemSelected$vars", [{
name: "Item",
attrName: "itemInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.prototype._onBlur$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnBlur");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:QZdix6+6CE+CaNt7L0gHmw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.QZdix6+6CE+CaNt7L0gHmw:wXBg3CTj8yNB1gaal8DBew", "LazyDropdownSearch", "OnBlur", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:5Wrvd9VFJkKNJ1EvIpOSow", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:qh6m9UIK90WDCs3KJSMWOA", callContext.id);
// IsFocused = False
model.variables.isFocusedVar = false;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:qh6m9UIK90WDCs3KJSMWOA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ActiveItemIndex = 0
model.variables.activeItemIndexVar = 0;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:O13zMWvbC0a9V1FLxFE86A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:QZdix6+6CE+CaNt7L0gHmw", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:0IPryDmXDkSfG__7isZo3A:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.0IPryDmXDkSfG__7isZo3A:krR5F9teRRzo7O0XjHb6zA", "LazyDropdownSearch", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:8HHy_mYKKkOGbGwqzxOAcw", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Rpb_DNceC06Rii5d0sPvCA", callContext.id);
controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_OnDestroy_RemoveEventListenersJS, "RemoveEventListeners", "OnDestroy", {
DocumentEventListenerFunction: OS.DataConversion.JSNodeParamConverter.to(model.variables.documentEventListenerFunctionVar, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:rNDKIV4R2UmmQxgtEeFayA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:0IPryDmXDkSfG__7isZo3A", callContext.id);
}

};
Controller.prototype._dropdownItemTouchEnd$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownItemTouchEnd");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchEnd$vars"))());
var getTimeInMillisecondsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getTimeInMillisecondsJSResult = getTimeInMillisecondsJSResult;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:2Wrzz6lhDkmY+ZqijzHFRA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.2Wrzz6lhDkmY+ZqijzHFRA:v_eFdh_WwV0Wkx6wl_siUQ", "LazyDropdownSearch", "DropdownItemTouchEnd", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Xl2p5YSg3ESL6RfULOwaFw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Touch cancelled?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:wnAEN451zEaX2MAIVL2nPA", callContext.id) && !(model.variables.isTouchClickVar))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:5bXhJVnW80Wj_UPx0S_Vmg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2FcPWOAfFUaJ0TQx_bBIeg", callContext.id);
getTimeInMillisecondsJSResult.value = controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_DropdownItemTouchEnd_GetTimeInMillisecondsJS, "GetTimeInMilliseconds", "DropdownItemTouchEnd", {
CurrentTimeInMillis: OS.DataConversion.JSNodeParamConverter.to(OS.DataTypes.LongInteger.defaultValue, OS.Types.LongInteger)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchEnd$getTimeInMillisecondsJSResult"))();
jsNodeResult.currentTimeInMillisOut = OS.DataConversion.JSNodeParamConverter.from($parameters.CurrentTimeInMillis, OS.Types.LongInteger);
return jsNodeResult;
}, {}, {});
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:sFKiTNKq_UKTeW15uhfIbQ", callContext.id) && getTimeInMillisecondsJSResult.value.currentTimeInMillisOut.sub(model.variables.itemSelectedOnTouch_StartTimeMillisVar).lt(OS.BuiltinFunctions.integerToLongInteger(200)))) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:NjI0EZovDEuGStYXfrCY0A", callContext.id);
// Execute Action: TriggerOnItemSelected
return controller._triggerOnItemSelected$Action(model.variables.itemSelectedOnTouchVar, callContext).then(function () {
// Reset ItemSelectedOnTouch
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:AzE2XUtF20evNAiXzdSQsg", callContext.id);
// ItemSelectedOnTouch = EmptyDropdownItem
model.variables.itemSelectedOnTouchVar = vars.value.emptyDropdownItemVar;
// ItemSelectedOnTouch_StartTimeMillis
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:53hcfg8d9UGMZ0NtWC5D8g", callContext.id);
// ItemSelectedOnTouch_StartTimeMillis = 0
model.variables.itemSelectedOnTouch_StartTimeMillisVar = OS.BuiltinFunctions.integerToLongInteger(0);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:V7R+3G2AnkqvCR6n7qn6Qw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:+c7N9ZQHoE+x1WXOW+QQAA", callContext.id);
}

});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:2Wrzz6lhDkmY+ZqijzHFRA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:2Wrzz6lhDkmY+ZqijzHFRA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchEnd$vars", [{
name: "EmptyDropdownItem",
attrName: "emptyDropdownItemVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchEnd$getTimeInMillisecondsJSResult", [{
name: "CurrentTimeInMillis",
attrName: "currentTimeInMillisOut",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._hideItemList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("HideItemList");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:AgQl2YhluUu9me8D5yJubA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.AgQl2YhluUu9me8D5yJubA:dzMcAbOr3j_UTTpwjQVAcA", "LazyDropdownSearch", "HideItemList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:uEkEj+rHdEqmxwow9U+IFg", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:JKyNiB2JGkCZ6q1pi0DyQw", callContext.id);
// IsDropdownOpen = False
model.variables.isDropdownOpenVar = false;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:W+FmVcT0I0C2Nq0izNnu_g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:AgQl2YhluUu9me8D5yJubA", callContext.id);
}

};
Controller.prototype._dropdownItemTouchStart$Action = function (itemIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownItemTouchStart");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchStart$vars"))());
vars.value.itemInLocal = itemIn.clone();
var getTimeInMillisecondsJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getTimeInMillisecondsJSResult = getTimeInMillisecondsJSResult;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:cZ5Y4av15EyS4JS6GWGRdg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.cZ5Y4av15EyS4JS6GWGRdg:0kMNtfvYDJZe8Wuw_DcORA", "LazyDropdownSearch", "DropdownItemTouchStart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:d2Hou6+A1keiFMaNehsbfQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:2xbybCOa3kOX6svAk0cNOA", callContext.id);
getTimeInMillisecondsJSResult.value = controller.safeExecuteJSNode(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_controller_DropdownItemTouchStart_GetTimeInMillisecondsJS, "GetTimeInMilliseconds", "DropdownItemTouchStart", {
CurrentTimeInMillis: OS.DataConversion.JSNodeParamConverter.to(OS.DataTypes.LongInteger.defaultValue, OS.Types.LongInteger)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchStart$getTimeInMillisecondsJSResult"))();
jsNodeResult.currentTimeInMillisOut = OS.DataConversion.JSNodeParamConverter.from($parameters.CurrentTimeInMillis, OS.Types.LongInteger);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:KSXoXbVhOUGLFERXCbw2hQ", callContext.id);
// ItemSelectedOnTouch = Item
model.variables.itemSelectedOnTouchVar = vars.value.itemInLocal;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:KSXoXbVhOUGLFERXCbw2hQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ItemSelectedOnTouch_StartTimeMillis = GetTimeInMilliseconds.CurrentTimeInMillis
model.variables.itemSelectedOnTouch_StartTimeMillisVar = getTimeInMillisecondsJSResult.value.currentTimeInMillisOut;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:KSXoXbVhOUGLFERXCbw2hQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// IsTouchClick = True
model.variables.isTouchClickVar = true;
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:f8VRZhijg0CfvC9ak+YT1Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:cZ5Y4av15EyS4JS6GWGRdg", callContext.id);
}

};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchStart$vars", [{
name: "Item",
attrName: "itemInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.DropdownItemTouchStart$getTimeInMillisecondsJSResult", [{
name: "CurrentTimeInMillis",
attrName: "currentTimeInMillisOut",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._triggerOnFilterValueChanged$Action = function (filterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TriggerOnFilterValueChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.TriggerOnFilterValueChanged$vars"))());
vars.value.filterValueInLocal = filterValueIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:oobg5Sn+4kS4yK3pTmu4ag:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA/ClientActions.oobg5Sn+4kS4yK3pTmu4ag:XboQ1ua1fMas0yPi_Xbm4g", "LazyDropdownSearch", "TriggerOnFilterValueChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:eFBbjd+Ot0mpDk5uYGOZcA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:Py24nBjKgUWjK32X9UU1xQ", callContext.id) && model.variables.isAutoFilterIn)) {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:1cfoqghCA06CvhjKh_5VYQ", callContext.id);
// Execute Action: SetFilteredItems
controller._setFilteredItems$Action(callContext);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:PU4dRnjXrkqupY4UA2KFbw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:zOt_sMks3kuoS+uAIuZnZw", callContext.id);
// Trigger Event: OnFilterValueChanged
return controller.onFilterValueChanged$Action(vars.value.filterValueInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:PU4dRnjXrkqupY4UA2KFbw", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:oobg5Sn+4kS4yK3pTmu4ag", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:oobg5Sn+4kS4yK3pTmu4ag", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.TriggerOnFilterValueChanged$vars", [{
name: "FilterValue",
attrName: "filterValueInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);

Controller.prototype.onFocus$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onFocus$Action, callContext);

};
Controller.prototype.setFilteredItems$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setFilteredItems$Action, callContext);

};
Controller.prototype.setSelectedItemTextFromSearchResultValues$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setSelectedItemTextFromSearchResultValues$Action, callContext);

};
Controller.prototype.onInputKeyDown$Action = function (keyCodeIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInputKeyDown$Action, callContext, keyCodeIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.selectActiveItem$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._selectActiveItem$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onKeypress$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onKeypress$Action, callContext);

};
Controller.prototype.onDropdownFieldClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDropdownFieldClick$Action, callContext);

};
Controller.prototype.refreshFilteredItemList$Action = function (newItemListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._refreshFilteredItemList$Action, callContext, newItemListIn);

};
Controller.prototype.showItemList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._showItemList$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.dropdownItemTouchMove$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownItemTouchMove$Action, callContext);

};
Controller.prototype.triggerOnItemSelected$Action = function (itemIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnItemSelected$Action, callContext, itemIn);

};
Controller.prototype.onBlur$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onBlur$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.dropdownItemTouchEnd$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownItemTouchEnd$Action, callContext);

};
Controller.prototype.hideItemList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._hideItemList$Action, callContext);

};
Controller.prototype.dropdownItemTouchStart$Action = function (itemIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownItemTouchStart$Action, callContext, itemIn);

};
Controller.prototype.triggerOnFilterValueChanged$Action = function (filterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._triggerOnFilterValueChanged$Action, callContext, filterValueIn);

};
Controller.prototype.onFilterValueChanged$Action = function () {
return Promise.resolve();
};
Controller.prototype.onItemSelected$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:gAB2YSYp1WGF5W4ME5QXJg", "LazyDropdownSearch", "LazyDropdownSearch", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:kFpp1MRj2U6+j2MrZP2fGA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.kFpp1MRj2U6+j2MrZP2fGA:2tYJ4M6oN5Uxw9XMJZMwEA", "LazyDropdownSearch", "LazyDropdownSearch", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:kFpp1MRj2U6+j2MrZP2fGA", callContext.id);
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LazyDropdownSearch/LazyDropdownSearch On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LazyDropdownSearch/LazyDropdownSearch On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LazyDropdownSearch/LazyDropdownSearch On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "LazyDropdownSearch/LazyDropdownSearch On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return LazyDropdownSearchController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, LazyDropdownSearchLanguageResources);
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnInputKeyDown.ScrollToActiveItemJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
document.querySelectorAll("#" + $parameters.ChoicesListId + 
    " .choices__item")[$parameters.ActiveItemIndex].scrollIntoViewIfNeeded()

};
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnReady.RegisterFieldEventHandlersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function delay(callback, ms) {
  var timer = 0;
  return function() {
    var context = this, args = arguments;
    clearTimeout(timer);
    timer = setTimeout(function () {
      callback.apply(context, args);
    }, ms || 0);
  };
}

var triggerOnFilterValueChanged = delay(function () {
        var newValue = document.getElementById($parameters.SearchTermInputFieldId).value;
        $actions.TriggerOnFilterValueChanged(newValue);
    }, 400);
    
var searchTermInputField = document.getElementById($parameters.SearchTermInputFieldId); 

searchTermInputField.onkeydown = function (evt) {
    if (evt.keyCode === 38 /* arrow up */ || evt.keyCode === 40 /* arrow down */ || evt.keyCode === 13 /* enter */) {
        $actions.OnInputKeyDown(evt.keyCode);
        evt.preventDefault();
    } else if (evt.keyCode === 8 /* backspace */ || evt.keyCode === 46 /* delete */ || evt.keyCode === 229 /* special keycode for some android keyboards */) {
        triggerOnFilterValueChanged();
    } else if (evt.keyCode === 9) {
        $actions.SelectActiveItem();
        $actions.HideItemList();
    }
}; 

searchTermInputField.onkeypress = function (evt) {
    if ((evt.charCode || evt.keyCode === 8 /* backspace */ || evt.keyCode === 46 /* delete */) && evt.keyCode !== 13) {
        triggerOnFilterValueChanged();
    }
}; 

searchTermInputField.onblur = function () {
};

searchTermInputField.onfocus = function () {
    if (!$parameters.IsListEmpty) {
        $actions.ShowItemList();
    }
};

searchTermInputField.onpaste = function () {
    triggerOnFilterValueChanged();
};

$parameters.DocumentEventListenerFunction = function(event) {
  var dropdownField = document.getElementById($parameters.DropdownFieldId); 
  var choicesListWrapperElement = document.getElementById($parameters.ChoicesListWrapperId); 

  var isClickInsideDropdownField = dropdownField.contains(event.target);
  var isClickInsideChoicesListWrapper = choicesListWrapperElement.contains(event.target);
  if (!isClickInsideDropdownField && !isClickInsideChoicesListWrapper) {
      $actions.HideItemList();
  }
};

document.addEventListener('click', $parameters.DocumentEventListenerFunction);
};
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.OnDestroy.RemoveEventListenersJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
document.removeEventListener('click', $parameters.DocumentEventListenerFunction);
};
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.DropdownItemTouchEnd.GetTimeInMillisecondsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CurrentTimeInMillis = new Date().getTime();
};
});
define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$controller.DropdownItemTouchStart.GetTimeInMillisecondsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CurrentTimeInMillis = new Date().getTime();
};
});

define("LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"mWHMgyWDFkmxD_1sk3IyAw": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"b4fKUSXm+kCYVadoYOqdPA": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"GjRPXoMFckCM_+McsrY_Fg": {
getter: function (varBag, idService) {
return varBag.vars.value.keyCodeInLocal;
},
dataType: OS.Types.Integer
},
"8v4i4zffrU2+pgJlzq_tGg": {
getter: function (varBag, idService) {
return varBag.scrollToActiveItemJSResult.value;
}
},
"R8BQ18fYzkGHUbQvjy4RGg": {
getter: function (varBag, idService) {
return varBag.vars.value.emptyDropdownItemVar;
}
},
"KaDY032qCkiKKVBo+TY6ug": {
getter: function (varBag, idService) {
return varBag.vars.value.newItemListInLocal;
}
},
"QzG9RJHC6kaoaocuik6DMw": {
getter: function (varBag, idService) {
return varBag.registerFieldEventHandlersJSResult.value;
}
},
"bgPPJ7tEcUewUL3H8_Hvfw": {
getter: function (varBag, idService) {
return varBag.vars.value.emptyDropdownItemVar;
}
},
"kch8KyQa8k+9WAT1FPFrog": {
getter: function (varBag, idService) {
return varBag.vars.value.itemInLocal;
}
},
"Rpb_DNceC06Rii5d0sPvCA": {
getter: function (varBag, idService) {
return varBag.removeEventListenersJSResult.value;
}
},
"vfuHap1uDE6QIDWnYNQJTA": {
getter: function (varBag, idService) {
return varBag.vars.value.emptyDropdownItemVar;
}
},
"2FcPWOAfFUaJ0TQx_bBIeg": {
getter: function (varBag, idService) {
return varBag.getTimeInMillisecondsJSResult.value;
}
},
"Zzbn1RDfqUGAK0y8Tdg9OA": {
getter: function (varBag, idService) {
return varBag.vars.value.itemInLocal;
}
},
"2xbybCOa3kOX6svAk0cNOA": {
getter: function (varBag, idService) {
return varBag.getTimeInMillisecondsJSResult.value;
}
},
"+JWxAb5Nh0O9zSwjjbrBoA": {
getter: function (varBag, idService) {
return varBag.vars.value.filterValueInLocal;
},
dataType: OS.Types.Text
},
"S_21kX6jSUCkdWnBKsERBw": {
getter: function (varBag, idService) {
return varBag.model.variables.isDropdownOpenVar;
},
dataType: OS.Types.Boolean
},
"ewSg+lWINkq8sq4DfKneew": {
getter: function (varBag, idService) {
return varBag.model.variables.searchTermVar;
},
dataType: OS.Types.Text
},
"g5SK00qZAku2SU+67fAVDw": {
getter: function (varBag, idService) {
return varBag.model.variables.activeItemIndexVar;
},
dataType: OS.Types.Integer
},
"xMXvgGh6c06G_I3zu15ZhQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isFocusedVar;
},
dataType: OS.Types.Boolean
},
"fwrSuQYh1E+zPFp4UYcQ9g": {
getter: function (varBag, idService) {
return varBag.model.variables.filteredItemListVar;
}
},
"uAt0gTk6Sk2wZBA7hI86lw": {
getter: function (varBag, idService) {
return varBag.model.variables.itemSelectedOnTouchVar;
}
},
"sgu8ZKz_k0W1AUU85SYRtA": {
getter: function (varBag, idService) {
return varBag.model.variables.itemSelectedOnTouch_StartTimeMillisVar;
},
dataType: OS.Types.LongInteger
},
"CP_363fldESHZcDX3+C2Qw": {
getter: function (varBag, idService) {
return varBag.model.variables.documentEventListenerFunctionVar;
},
dataType: OS.Types.Object
},
"ab4kVWBKUU2TxCMMcYvNjw": {
getter: function (varBag, idService) {
return varBag.model.variables.isTouchClickVar;
},
dataType: OS.Types.Boolean
},
"7m47SZ7tWkiPYrCHL6CLGQ": {
getter: function (varBag, idService) {
return varBag.model.variables.searchResultValuesIn;
}
},
"o6FBqChIAEGXRL_GfsDkRA": {
getter: function (varBag, idService) {
return varBag.model.variables.searchPromptIn;
},
dataType: OS.Types.Text
},
"GR7tl+Nd3k65QqG2LwcMIg": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"KM1yG1K4bU6B3XdRI5sO0A": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedItemIn;
}
},
"zwAUEJGUW0mSi6Raj7UK4w": {
getter: function (varBag, idService) {
return varBag.model.variables.isAutoFilterIn;
},
dataType: OS.Types.Boolean
},
"28gwYgmnsEWH4qLFePaZBg": {
getter: function (varBag, idService) {
return varBag.model.variables.isAutoSortIn;
},
dataType: OS.Types.Boolean
},
"fUslnMU9fk2sk5XKOCCRJA": {
getter: function (varBag, idService) {
return varBag.model.variables.emptyTextIn;
},
dataType: OS.Types.Text
},
"HmQTCmXFyEqRvXRkVsXRNg": {
getter: function (varBag, idService) {
return varBag.model.variables.enabledIn;
},
dataType: OS.Types.Boolean
},
"87viuhYCq0+SLKukVlik3Q": {
getter: function (varBag, idService) {
return varBag.model.variables.isValidIn;
},
dataType: OS.Types.Boolean
},
"rn5edY4nh06X64_Dv4vfrA": {
getter: function (varBag, idService) {
return varBag.model.variables.errorMessageIn;
},
dataType: OS.Types.Text
},
"hFDEOtE2vEGJANXzOzwbkA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ChoicesElement"));
})(varBag.model, idService);
}
},
"VeEqFP8xEECqD5J2wpsaGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DropdownField"));
})(varBag.model, idService);
}
},
"zi2+FoguyUKWykszmmqtrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ChoicesListWrapper"));
})(varBag.model, idService);
}
},
"k9T3zi2eCk2xrunutSkNIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_SearchTerm"));
})(varBag.model, idService);
}
},
"swdZ016aG0qLHEMdEPcuSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ChoicesList"));
})(varBag.model, idService);
}
},
"9rOEWZBFJ0eaXb4kljD1SQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DropdownOptionsList"));
})(varBag.model, idService);
}
},
"KqDeERygfUqWdBnrsQbFmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
