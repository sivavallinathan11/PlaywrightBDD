define("Common_CW.PHICore_CW.Branding.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "PHICore_TH.controller", "Common_CW.controller", "OutSystemsUI.Utilities.InlineSVG.mvc$model", "PHICore_TH.controller$SetClientPrimaryColor", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_TH", "Common_CW.controller$GetImage", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund"], function (OutSystems, Common_CWModel, PHICore_THController, Common_CWController, OutSystemsUI_Utilities_InlineSVG_mvcModel) {
var OS = OutSystems.Internal;

var GetTenantConfigsDataActRec = (function (_super) {
__extends(GetTenantConfigsDataActRec, _super);
function GetTenantConfigsDataActRec(defaults) {
_super.apply(this, arguments);
}
GetTenantConfigsDataActRec.attributesToDeclare = function () {
return [
this.attr("LogoOutput", "logoOutputOut", "LogoOutput", true, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("LogoFileName", "logoFileNameOut", "LogoFileName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PrimaryColor", "primaryColorOut", "PrimaryColor", true, false, OS.Types.Text, function () {
return "#0078a1";
}, true), 
this.attr("FundName", "fundNameOut", "FundName", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetTenantConfigsDataActRec.init();
return GetTenantConfigsDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SVGLogo", "sVGLogoVar", "SVGLogo", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsSVGLogo", "isSVGLogoVar", "IsSVGLogo", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Logo", "logoVar", "Logo", true, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, false), 
this.attr("HasChange", "hasChangeIn", "HasChange", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetTenantConfigs", "getTenantConfigsDataAct", "getTenantConfigsDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTenantConfigsDataActRec());
}, true, GetTenantConfigsDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = OutSystemsUI_Utilities_InlineSVG_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("HasChange" in inputs) {
this.variables.hasChangeIn = inputs.HasChange;
if("_hasChangeInDataFetchStatus" in inputs) {
this.variables._hasChangeInDataFetchStatus = inputs._hasChangeInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.Branding");
});
define("Common_CW.PHICore_CW.Branding.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "PHICore_TH.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.Branding.mvc$model", "Common_CW.PHICore_CW.Branding.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.InlineSVG.mvc$view", "PHICore_TH.controller$SetClientPrimaryColor", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_TH", "Common_CW.controller$GetImage", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund"], function (OutSystems, Common_CWModel, Common_CWController, PHICore_THController, React, OSView, Common_CW_PHICore_CW_Branding_mvc_model, Common_CW_PHICore_CW_Branding_mvc_controller, Common_CWClientVariables, OSWidgets, OutSystemsUI_Utilities_InlineSVG_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.Branding";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/Common_CW.ImportStyle.js"];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Utilities_InlineSVG_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Branding_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Branding_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
tabIndex: (-1).toString()
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Branding/Link_Branding OnClick");
return controller.logoHomepage$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "display-block",
visible: true,
_idProps: {
service: idService,
name: "Link_Branding"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.isSVGLogoVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "SVG-AppLogo",
visible: true,
_idProps: {
service: idService,
name: "SVGAppLogo"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_InlineSVG_mvc_view, {
inputs: {
SVGCode: model.variables.sVGLogoVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Image, {
defaultImage: OS.Navigation.VersionedURL.getVersionedUrl("img/PHICore_TH.imgplaceholder.png"),
extendedProperties: {
alt: "Company Logo",
"aria-label": (model.variables.getTenantConfigsDataAct.fundNameOut + " Logo"),
style: "height: 32px;"
},
imageContent: model.variables.logoVar,
style: "app-logo",
type: /*Binary*/ 2,
_idProps: {
service: idService,
name: "AppLogo"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.Branding.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "PHICore_TH.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.Branding.mvc$debugger", "Common_CW.PHICore_CW.Branding.mvc$controller.GetTenantConfigsOnAfterFetch.BinaryToBase64JS", "Common_CW.PHICore_CW.Branding.mvc$controller.SetPrimaryColor.SetPrimaryColorJS", "PHICore_TH.controller$SetClientPrimaryColor", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_TH", "Common_CW.controller$GetImage", "Common_CW.controller$Check_HAMBSAdmin", "Common_CW.controller$Check_ConfigureFund"], function (OutSystems, Common_CWModel, Common_CWController, PHICore_THController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_Branding_mvc_Debugger, Common_CW_PHICore_CW_Branding_mvc_controller_GetTenantConfigsOnAfterFetch_BinaryToBase64JS, Common_CW_PHICore_CW_Branding_mvc_controller_SetPrimaryColor_SetPrimaryColorJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getTenantConfigs$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getTenantConfigs$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getTenantConfigs$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:+ds0Olb5U0Gu1TC4O2cSkw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg/DataActions.+ds0Olb5U0Gu1TC4O2cSkw:EJyX4HQ4URn7SeYnLGbBCA", "Common_CW", "GetTenantConfigs", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Branding/GetTenantConfigs");
return controller.callDataAction("DataActionGetTenantConfigs", "screenservices/Common_CW/PHICore_CW/Branding/DataActionGetTenantConfigs", "0yIYh+h++zrhU9hFP7l+jg", function (b) {
model.variables.getTenantConfigsDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTenantConfigsDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTenantConfigsDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, undefined, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Branding/GetTenantConfigs On After Fetch");
controller._getTenantConfigsOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:+ds0Olb5U0Gu1TC4O2cSkw", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTenantConfigs$DataActRefresh"];
// Client Actions
Controller.prototype._getTenantConfigsOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetTenantConfigsOnAfterFetch");
callContext = controller.callContext(callContext);
var getImageVar = new OS.DataTypes.VariableHolder();
var binaryToBase64JSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getImageVar = getImageVar;
varBag.binaryToBase64JSResult = binaryToBase64JSResult;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:MfQvC2NAKE6MHX6VUx2XlA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg/ClientActions.MfQvC2NAKE6MHX6VUx2XlA:png7w3CJSnYDAKTrvK1EaQ", "Common_CW", "GetTenantConfigsOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:moQMmiELG0q5S+oKJrswNw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jSOBY7n7gkGiswtCEFwvng", callContext.id);
binaryToBase64JSResult.value = controller.safeExecuteJSNode(Common_CW_PHICore_CW_Branding_mvc_controller_GetTenantConfigsOnAfterFetch_BinaryToBase64JS, "BinaryToBase64", "GetTenantConfigsOnAfterFetch", {
binary: OS.DataConversion.JSNodeParamConverter.to(model.variables.getTenantConfigsDataAct.logoOutputOut, OS.Types.BinaryData),
base64String: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.Branding.GetTenantConfigsOnAfterFetch$binaryToBase64JSResult"))();
jsNodeResult.base64StringOut = OS.DataConversion.JSNodeParamConverter.from($parameters.base64String, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sJQpNPU2AU25IHCebInwFw", callContext.id);
// TenantLogo = BinaryToBase64.base64String
Common_CWClientVariables.setTenantLogo(binaryToBase64JSResult.value.base64StringOut);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sJQpNPU2AU25IHCebInwFw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// LogoFileName = GetTenantConfigs.LogoFileName
Common_CWClientVariables.setLogoFileName(model.variables.getTenantConfigsDataAct.logoFileNameOut);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sJQpNPU2AU25IHCebInwFw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PrimaryColor = GetTenantConfigs.PrimaryColor
Common_CWClientVariables.setPrimaryColor(model.variables.getTenantConfigsDataAct.primaryColorOut);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cctl7FoPWUOSp3u9Znpg5w", callContext.id);
// Execute Action: GetImage
getImageVar.value = Common_CWController.default.getImage$Action(Common_CWClientVariables.getTenantLogo(), Common_CWClientVariables.getLogoFileName(), callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:mTUObk8u_kakO4Krd4izYQ", callContext.id) && getImageVar.value.isSVGLogoOut)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:i8iA0JKLpE2soZfkx1RUmg", callContext.id);
// SVGLogo = GetImage.SVGLogo
model.variables.sVGLogoVar = getImageVar.value.sVGLogoOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:i8iA0JKLpE2soZfkx1RUmg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSVGLogo = GetImage.IsSVGLogo
model.variables.isSVGLogoVar = getImageVar.value.isSVGLogoOut;
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9TI8AjpS5ECndrRkdFI+wA", callContext.id);
// Logo = GetImage.Image
model.variables.logoVar = getImageVar.value.imageOut;
}

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+WwhTuZzBkSZKW7WavpcHg", callContext.id);
// Execute Action: SetPrimaryColor
controller._setPrimaryColor$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:boi0wzo5JEOth4Y9ZZFYuw", callContext.id);
// Execute Action: SetClientPrimaryColor
PHICore_THController.default.setClientPrimaryColor$Action(Common_CWClientVariables.getPrimaryColor(), callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5asbc+XcyUKiVDhPM2+W9Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:MfQvC2NAKE6MHX6VUx2XlA", callContext.id);
}

};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.Branding.GetTenantConfigsOnAfterFetch$binaryToBase64JSResult", [{
name: "base64String",
attrName: "base64StringOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._logoHomepage$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LogoHomepage");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:n2IhVILWg0uUJ577vJSP6w:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg/ClientActions.n2IhVILWg0uUJ577vJSP6w:Ow5DaBaC88TL5Rdbv3wiJA", "Common_CW", "LogoHomepage", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Yxw9ZQ_EjEqHCGqXNlMOBA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9XuoabANFkCzg8ocZxoJ1Q", callContext.id) && model.variables.hasChangeIn)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TpSuPoRF20OfAZfreqjBSQ", callContext.id);
// Trigger Event: Event_DashboardClicked
return controller.event_DashboardClicked$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nvzwhjRkakq9PxrU1xHTnw", callContext.id);
});
} else {
// is HAMBS Admin
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:w7sAUXand0GnLNOxNPaKCw", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_HAMBSAdmin$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:c16x5sqL2EWNwGRE8hC9dg", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/Configurations/", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NZsuzsRxbk6qUf5vqVEwFg", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ConfigureFund$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:r+404geQN0GGPikwmimBrQ", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore/", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:iDK3UEXJOEaBlNvDbaBKPA", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore/", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

}

}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:n2IhVILWg0uUJ577vJSP6w", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:n2IhVILWg0uUJ577vJSP6w", callContext.id);
throw ex;

});
};
Controller.prototype._setPrimaryColor$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SetPrimaryColor");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:aQHEXUPVP06Gt+PbOeyo3g:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg/ClientActions.aQHEXUPVP06Gt+PbOeyo3g:1uEhW1weS4BwZ541VUWcZQ", "Common_CW", "SetPrimaryColor", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:h4EAT2UU50ad0P2RaD_jIg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OozKf4vMKkqGSCk1gVV7YQ", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_Branding_mvc_controller_SetPrimaryColor_SetPrimaryColorJS, "SetPrimaryColor", "SetPrimaryColor", {
PrimaryColor: OS.DataConversion.JSNodeParamConverter.to(Common_CWClientVariables.getPrimaryColor(), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Kj4he1_4WUKpa5WJ0AZIIg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:aQHEXUPVP06Gt+PbOeyo3g", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var getImageVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getImageVar = getImageVar;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:XAPMaLMI80qQd1wJIdKlQQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg/ClientActions.XAPMaLMI80qQd1wJIdKlQQ:ZqHxWN6on5grUzb85+iUsg", "Common_CW", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:03pLLGkNYkCJCpgtqPMM8Q", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TbQ+tKCDAUq6kiFIuNPYyw", callContext.id) && ((Common_CWClientVariables.getTenantLogo()) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kNHY+l2pw0+2wu8GFeAfUA", callContext.id);
// Execute Action: GetImage
getImageVar.value = Common_CWController.default.getImage$Action(Common_CWClientVariables.getTenantLogo(), Common_CWClientVariables.getLogoFileName(), callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Cq6ohMIq30yrkgE_BpEsYg", callContext.id) && getImageVar.value.isSVGLogoOut)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Tvwoy_RUB0K5fvfdIQ4faA", callContext.id);
// SVGLogo = GetImage.SVGLogo
model.variables.sVGLogoVar = getImageVar.value.sVGLogoOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Tvwoy_RUB0K5fvfdIQ4faA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSVGLogo = GetImage.IsSVGLogo
model.variables.isSVGLogoVar = getImageVar.value.isSVGLogoOut;
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bq7GiKTGTUeQWeViL++d6Q", callContext.id);
// Logo = GetImage.Image
model.variables.logoVar = getImageVar.value.imageOut;
}

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:36mgmx8YDUCG0S4kQlJmIg", callContext.id);
// Execute Action: SetPrimaryColor
controller._setPrimaryColor$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5X_rFgAGRky1RmpxTfiRAg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5X_rFgAGRky1RmpxTfiRAg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:XAPMaLMI80qQd1wJIdKlQQ", callContext.id);
}

};

Controller.prototype.getTenantConfigsOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getTenantConfigsOnAfterFetch$Action, callContext);

};
Controller.prototype.logoHomepage$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._logoHomepage$Action, callContext);

};
Controller.prototype.setPrimaryColor$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._setPrimaryColor$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.event_DashboardClicked$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:zlMyC3epOUCAjx7ssPnbLg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.zlMyC3epOUCAjx7ssPnbLg:lwhy1j9t_CmGO80CXAqKaA", "Common_CW", "Branding", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:zlMyC3epOUCAjx7ssPnbLg", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/Branding On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});
define("Common_CW.PHICore_CW.Branding.mvc$controller.GetTenantConfigsOnAfterFetch.BinaryToBase64JS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var toBase64 = $parameters.binary;
$parameters.base64String = window.atob(toBase64);
};
});
define("Common_CW.PHICore_CW.Branding.mvc$controller.SetPrimaryColor.SetPrimaryColorJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.PrimaryColor!=='') {
    appendCSS(':root {--color-primary: '+$parameters.PrimaryColor+' !important;}')
}
};
});

define("Common_CW.PHICore_CW.Branding.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"cctl7FoPWUOSp3u9Znpg5w": {
getter: function (varBag, idService) {
return varBag.getImageVar.value;
}
},
"jSOBY7n7gkGiswtCEFwvng": {
getter: function (varBag, idService) {
return varBag.binaryToBase64JSResult.value;
}
},
"OozKf4vMKkqGSCk1gVV7YQ": {
getter: function (varBag, idService) {
return varBag.setPrimaryColorJSResult.value;
}
},
"kNHY+l2pw0+2wu8GFeAfUA": {
getter: function (varBag, idService) {
return varBag.getImageVar.value;
}
},
"cEHyuksCREat5YwOdfjw7w": {
getter: function (varBag, idService) {
return varBag.model.variables.sVGLogoVar;
},
dataType: OS.Types.Text
},
"VyFfNd+ZwEazozIUR6bmTg": {
getter: function (varBag, idService) {
return varBag.model.variables.isSVGLogoVar;
},
dataType: OS.Types.Boolean
},
"rHLgF74Er0aBC17wbM2CDg": {
getter: function (varBag, idService) {
return varBag.model.variables.logoVar;
},
dataType: OS.Types.BinaryData
},
"B_ytRiOxzUKWUhqdHP1Uyw": {
getter: function (varBag, idService) {
return varBag.model.variables.hasChangeIn;
},
dataType: OS.Types.Boolean
},
"+ds0Olb5U0Gu1TC4O2cSkw": {
getter: function (varBag, idService) {
return varBag.model.variables.getTenantConfigsDataAct;
}
},
"CpHHLWA5u0yhml3sX7E7MA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link_Branding"));
})(varBag.model, idService);
}
},
"tBvXbDbs0kKBS_Fj+iBCqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SVGAppLogo"));
})(varBag.model, idService);
}
},
"nSSVd8LGc0StEQoqf43KaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AppLogo"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
