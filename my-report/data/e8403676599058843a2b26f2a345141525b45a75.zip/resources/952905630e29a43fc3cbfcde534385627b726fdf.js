define("Common_CW.PHICore_CW.Filter.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model"], function (OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowAsEnabled", "showAsEnabledIn", "ShowAsEnabled", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_showAsEnabledInDataFetchStatus", "_showAsEnabledInDataFetchStatus", "_showAsEnabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("ShowAsEnabled" in inputs) {
this.variables.showAsEnabledIn = inputs.ShowAsEnabled;
if("_showAsEnabledInDataFetchStatus" in inputs) {
this.variables._showAsEnabledInDataFetchStatus = inputs._showAsEnabledInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.Filter");
});
define("Common_CW.PHICore_CW.Filter.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.Filter.mvc$model", "Common_CW.PHICore_CW.Filter.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_Filter_mvc_model, Common_CW_PHICore_CW_Filter_mvc_controller, Common_CWClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.Filter";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Filter_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_Filter_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: model.getCachedValue(idService.getId("5ZOSS1NjFEym3U9N+W7lFA.Style"), function () {
return ("padding-s hover-underline " + ((model.variables.showAsEnabledIn) ? ("text-primary") : ("text-neutral-6")));
}, function () {
return model.variables.showAsEnabledIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showAsEnabledInDataFetchStatus)
}, React.createElement(OSWidgets.Icon, {
icon: "sliders",
iconSize: /*FontSize*/ 0,
style: "icon margin-right-s",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
style: "bold",
text: ["Filter"],
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.Filter.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.Filter.mvc$debugger"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_Filter_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:qKjzNHmBtE+D4a6C3nNjIA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.qKjzNHmBtE+D4a6C3nNjIA:Vs5IfW64y2aRw5Jg8NJRiw", "Common_CW", "Filter", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:qKjzNHmBtE+D4a6C3nNjIA", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.Filter.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"T5sE0M3iQUmx9R7sOaszrA": {
getter: function (varBag, idService) {
return varBag.model.variables.showAsEnabledIn;
},
dataType: OS.Types.Boolean
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
