define("PHICore.Common_Widgets.SLAStatusCard.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "Common_CW.PHICore_CW.Filter.mvc$model", "OutSystemsCharts.Version1.DonutChart_v1.mvc$model", "PHICore.Common_Widgets.GraphFilter.mvc$model", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$SLAIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, Common_CW_PHICore_CW_Filter_mvcModel, OutSystemsCharts_Version1_DonutChart_v1_mvcModel, PHICore_Common_Widgets_GraphFilter_mvcModel) {
var OS = OutSystems.Internal;
var GetTeamUsersByUserIdAggrRec = (function (_super) {
__extends(GetTeamUsersByUserIdAggrRec, _super);
function GetTeamUsersByUserIdAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamUsersByUserIdAggrRec.RecordListType = PHICoreModel.TeamTeamUserRecordList;
GetTeamUsersByUserIdAggrRec.init();
return GetTeamUsersByUserIdAggrRec;
})(OS.Model.AggregateRecord);
var GetCasesByCreatedOnAggrRec = (function (_super) {
__extends(GetCasesByCreatedOnAggrRec, _super);
function GetCasesByCreatedOnAggrRec(defaults) {
_super.apply(this, arguments);
}
GetCasesByCreatedOnAggrRec.RecordListType = PHICoreModel.SLAIdentifierTextTextLongIntegerRecordList;
GetCasesByCreatedOnAggrRec.init();
return GetCasesByCreatedOnAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("SLADataPointList", "sLADataPointListVar", "SLADataPointList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.Legacy_DataPointList());
}, false, PHICoreModel.Legacy_DataPointList), 
this.attr("ShowFilter", "showFilterVar", "ShowFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GraphFilter", "graphFilterVar", "GraphFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.GraphFilterStrucRec());
}, false, PHICoreModel.GraphFilterStrucRec), 
this.attr("SelectedTeams", "selectedTeamsVar", "SelectedTeams", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("GraphFilter_Original", "graphFilter_OriginalVar", "GraphFilter_Original", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.GraphFilterStrucRec());
}, false, PHICoreModel.GraphFilterStrucRec), 
this.attr("RefreshFilter", "refreshFilterVar", "RefreshFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GetTeamUsersByUserId", "getTeamUsersByUserIdAggr", "getTeamUsersByUserIdAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamUsersByUserIdAggrRec());
}, true, GetTeamUsersByUserIdAggrRec), 
this.attr("GetCasesByCreatedOn", "getCasesByCreatedOnAggr", "getCasesByCreatedOnAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCasesByCreatedOnAggrRec());
}, true, GetCasesByCreatedOnAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((Common_CW_PHICore_CW_Filter_mvcModel.hasValidationWidgets || OutSystemsCharts_Version1_DonutChart_v1_mvcModel.hasValidationWidgets) || PHICore_Common_Widgets_GraphFilter_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.SLAStatusCard");
});
define("PHICore.Common_Widgets.SLAStatusCard.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.SLAStatusCard.mvc$model", "PHICore.Common_Widgets.SLAStatusCard.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.Filter.mvc$view", "OutSystemsCharts.Version1.DonutChart_v1.mvc$view", "PHICore.Common_Widgets.GraphFilter.mvc$view", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$SLAIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, React, OSView, PHICore_Common_Widgets_SLAStatusCard_mvc_model, PHICore_Common_Widgets_SLAStatusCard_mvc_controller, PHICoreClientVariables, OSWidgets, Common_CW_PHICore_CW_Filter_mvc_view, OutSystemsCharts_Version1_DonutChart_v1_mvc_view, PHICore_Common_Widgets_GraphFilter_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.SLAStatusCard";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [Common_CW_PHICore_CW_Filter_mvc_view, OutSystemsCharts_Version1_DonutChart_v1_mvc_view, PHICore_Common_Widgets_GraphFilter_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_SLAStatusCard_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_SLAStatusCard_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("a7yaxsWuqE+rEIX56d20GQ.Style"), function () {
return ("dashboard-card" + ((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) ? ("") : (" disabled")));
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6"
},
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
extendedProperties: {
style: "font-size: 22px;"
},
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, "SLAs")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: model.getCachedValue(idService.getId("SvezcSa2MkSkTDFd5ynpmQ.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SLAStatusCard/Link OnClick");
controller.onToggle_GraphFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_Filter_mvc_view, {
inputs: {
ShowAsEnabled: model.getCachedValue(idService.getId("boaiNQhwMEOsecfU2mHvcQ.ShowAsEnabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})))), React.createElement(OutSystemsCharts_Version1_DonutChart_v1_mvc_view, {
inputs: {
AdvancedFormat: model.getCachedValue(idService.getId("0+_1MkK5tESoDMwzB7hQcA.AdvancedFormat"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsChartsController.default.advancedFormat_Init_v1$Action(new PHICoreModel.Legacy_AdvancedDataPointFormatList(), new PHICoreModel.Legacy_AdvancedDataSeriesFormatList(), "", "", (("    plotOptions: {\r\n        pie:{\r\n            size: \'90%\',\r\n            innerSize: \'80%\',\r\n            borderWidth: 3\r\n        }\r\n    },\r\n    legend: {\r\n        enabled: " + ((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) ? ("true") : ("false"))) + "\r\n    }"), callContext).advancedFormatOut;
}, OS.Types.Record, callContext.id);
}),
SourceDataPointList: model.variables.sLADataPointListVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "7",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(PHICore_Common_Widgets_GraphFilter_mvc_view, {
inputs: {
ShowPopup: model.variables.showFilterVar,
CallToRefresh: (model.variables.refreshFilterVar ? "True" : "False"),
GraphFilterStruc: model.variables.graphFilterVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_Filter$Action: function (graphFilterOutIn, closePopUpIn, isProceedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/GraphFilter Event_Filter");
return controller.onEvent_GraphFilter$Action(graphFilterOutIn, closePopUpIn, isProceedIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.SLAStatusCard.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsCharts.model", "OutSystemsCharts.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.SLAStatusCard.mvc$debugger", "Common_CW.controller$Check_ViewDashboard", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "PHICore.model$Legacy_AdvancedDataPointFormatList", "PHICore.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "PHICore.referencesHealth$OutSystemsCharts", "OutSystemsCharts.controller$AdvancedFormat_Init_v1", "PHICore.model$Legacy_DataPointList", "PHICore.model$GraphFilterStrucRec", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_DataPointRec", "PHICore.model$MSD_ItemList", "Common_CW.controller$MSD_JoinIDs", "PHICore.model$TeamTeamUserRecordList", "PHICore.model$SLAIdentifierTextTextLongIntegerRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsChartsModel, OutSystemsChartsController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_SLAStatusCard_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getTeamUsersByUserId$AggrRefresh: 0,
getCasesByCreatedOn$AggrRefresh: -1
};
this.dataFetchDependentsGraph = {
getTeamUsersByUserId$AggrRefresh: [],
getCasesByCreatedOn$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getTeamUsersByUserId$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ta8JCWVI1UGYnldBE0V5MA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ScreenDataSets.ta8JCWVI1UGYnldBE0V5MA:KVmy6TNm837chBrjKaB3pQ", "PHICore", "GetTeamUsersByUserId", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SLAStatusCard/GetTeamUsersByUserId");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeamUsersByUserId", "screenservices/PHICore/Common_Widgets/SLAStatusCard/ScreenDataSetGetTeamUsersByUserId", "nCCCxA67ZM9NqjsWZUx4gA", maxRecords, startIndex, function (b) {
model.variables.getTeamUsersByUserIdAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamUsersByUserIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamUsersByUserIdAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SLAStatusCard/GetTeamUsersByUserId On After Fetch");
return controller._onAfterFetch_GetTeamUsersByUserId$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ta8JCWVI1UGYnldBE0V5MA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getCasesByCreatedOn$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:7Ot4rs7tdUOC1h_mgqNSPw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ScreenDataSets.7Ot4rs7tdUOC1h_mgqNSPw:JE1iSBVgM3VBBlDserVNUw", "PHICore", "GetCasesByCreatedOn", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SLAStatusCard/GetCasesByCreatedOn");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetCasesByCreatedOn", "screenservices/PHICore/Common_Widgets/SLAStatusCard/ScreenDataSetGetCasesByCreatedOn", "Ymw1MDIzTsA5Pa8hGvs8RA", maxRecords, startIndex, function (b) {
model.variables.getCasesByCreatedOnAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCasesByCreatedOnAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCasesByCreatedOnAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SLAStatusCard/GetCasesByCreatedOn On After Fetch");
controller._onAfterFetch_GetCases$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:7Ot4rs7tdUOC1h_mgqNSPw", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTeamUsersByUserId$AggrRefresh", "getCasesByCreatedOn$AggrRefresh"];
// Client Actions
Controller.prototype._onAfterFetch_GetTeamUsersByUserId$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch_GetTeamUsersByUserId");
callContext = controller.callContext(callContext);
var mSD_JoinIDsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.mSD_JoinIDsVar = mSD_JoinIDsVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:rkf4DLapmEiVv0kQ6KPkoQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ClientActions.rkf4DLapmEiVv0kQ6KPkoQ:NVn9slWF28UyIgKWJtQuIg", "PHICore", "OnAfterFetch_GetTeamUsersByUserId", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jedyZVzqY0S_o75R7AN3vw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dZfuH19xHUyt0EkUDRlPKw", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.graphFilterVar.selectedTeamAttr, OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getTeamUsersByUserIdAggr.listOut, new PHICoreModel.MSD_ItemList(), function (source, target) {
target.isSelectedAttr = true;
target.itemIdAttr = OS.BuiltinFunctions.longIntegerToText(source.teamAttr.idAttr);
target.descriptionAttr = source.teamAttr.nameAttr;
return target;
}), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TL89HHy26UuFaNNvbl87KQ", callContext.id);
// Execute Action: MSD_JoinIDs
mSD_JoinIDsVar.value = Common_CWController.default.mSD_JoinIDs$Action(model.variables.graphFilterVar.selectedTeamAttr, "|", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:huH32Yc3DUi1k1XGi1vppg", callContext.id);
// SelectedTeams = MSD_JoinIDs.JoinedStrings
model.variables.selectedTeamsVar = mSD_JoinIDsVar.value.joinedStringsOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:huH32Yc3DUi1k1XGi1vppg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// GraphFilter_Original = GraphFilter
model.variables.graphFilter_OriginalVar = model.variables.graphFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HPIYRgDgI0i7P5vEoPOKKg", callContext.id);
// Refresh Query: GetCasesByCreatedOn
var result = controller.getCasesByCreatedOn$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DH9hfZvPok+TOTd7hwKv5A", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:rkf4DLapmEiVv0kQ6KPkoQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:rkf4DLapmEiVv0kQ6KPkoQ", callContext.id);
throw ex;

});
};
Controller.prototype._onEvent_GraphFilter$Action = function (graphFilterOutIn, closePopUpIn, isProceedIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnEvent_GraphFilter");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SLAStatusCard.OnEvent_GraphFilter$vars"))());
vars.value.graphFilterOutInLocal = graphFilterOutIn.clone();
vars.value.closePopUpInLocal = closePopUpIn;
vars.value.isProceedInLocal = isProceedIn;
var mSD_JoinIDsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.mSD_JoinIDsVar = mSD_JoinIDsVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:0Uo3J8A3qkiza+0aa3mmmw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ClientActions.0Uo3J8A3qkiza+0aa3mmmw:f+h_ZdwUe2fLwGy6r12SLA", "PHICore", "OnEvent_GraphFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2+P0ICM1HEi9jsJK5NUbew", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_t1W44dD70CCaSRZeCOiQA", callContext.id) && vars.value.isProceedInLocal)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iXkdbS4ytkilIKbmFhqfYA", callContext.id) && !(vars.value.closePopUpInLocal))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kZccTzjdUU+s7u9FerQBvw", callContext.id);
// GraphFilter = GraphFilter_Original
model.variables.graphFilterVar = model.variables.graphFilter_OriginalVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kZccTzjdUU+s7u9FerQBvw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefreshFilter = notRefreshFilter
model.variables.refreshFilterVar = !(model.variables.refreshFilterVar);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XUfPd7croEa391cbF1DKkw", callContext.id);
// GraphFilter = GraphFilterOut
model.variables.graphFilterVar = vars.value.graphFilterOutInLocal;
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8IvawSPu_kS1liekReMczg", callContext.id);
// Execute Action: MSD_JoinIDs
mSD_JoinIDsVar.value = Common_CWController.default.mSD_JoinIDs$Action(model.variables.graphFilterVar.selectedTeamAttr, "|", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Yt8hGN5ML0m2Z0yfpwcb1g", callContext.id);
// SelectedTeams = MSD_JoinIDs.JoinedStrings
model.variables.selectedTeamsVar = mSD_JoinIDsVar.value.joinedStringsOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FUlyKHLcaEqNi+R26YPMGg", callContext.id);
// Refresh Query: GetCasesByCreatedOn
var result = controller.getCasesByCreatedOn$AggrRefresh(50, 0, callContext);
model.flush();
return result;
}

}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GNhh32JOlkKuYR1vP+siZA", callContext.id) && vars.value.closePopUpInLocal)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CERj__KPSU6sA_NkXMuu9g", callContext.id);
// Execute Action: OnToggle_GraphFilter
controller._onToggle_GraphFilter$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GpcFjMPWV0Ox1SBkfV9HYA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GpcFjMPWV0Ox1SBkfV9HYA", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:0Uo3J8A3qkiza+0aa3mmmw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:0Uo3J8A3qkiza+0aa3mmmw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SLAStatusCard.OnEvent_GraphFilter$vars", [{
name: "GraphFilterOut",
attrName: "graphFilterOutInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.GraphFilterStrucRec();
},
complexType: PHICoreModel.GraphFilterStrucRec
}, {
name: "ClosePopUp",
attrName: "closePopUpInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsProceed",
attrName: "isProceedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onAfterFetch_GetCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnAfterFetch_GetCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SLAStatusCard.OnAfterFetch_GetCases$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:4e_DUURHR0ehp2mksvXDLg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ClientActions.4e_DUURHR0ehp2mksvXDLg:K0QJ5exc8dzAFaj4AALP0A", "PHICore", "OnAfterFetch_GetCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0LLSxUM550iSb3yQLRInFQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wrRoLnp0kkOCk5+zCfal2Q", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
// Foreach GetCasesByCreatedOn.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesByCreatedOnAggr.listOut);
try {var getCasesByCreatedOnIterator = callContext.iterationContext.getIterator(model.variables.getCasesByCreatedOnAggr.listOut);
var getCasesByCreatedOnIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_hST3wJgJkKx9qZ_2KEy1w", callContext.id) && (getCasesByCreatedOnIndex < model.variables.getCasesByCreatedOnAggr.listOut.length))) {
getCasesByCreatedOnIterator.currentRowNumber = getCasesByCreatedOnIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Mbz5AoT_t0+Ha5WR4bqT2Q", callContext.id);
// TempTotal = TempTotal + GetCasesByCreatedOn.List.Current.Count
vars.value.tempTotalVar = vars.value.tempTotalVar.add(model.variables.getCasesByCreatedOnAggr.listOut.getItem(getCasesByCreatedOnIndex.valueOf()).countAttr);
getCasesByCreatedOnIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesByCreatedOnAggr.listOut);
}

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6P_qJi8NPEejPTOioekLow", callContext.id);
// TempTotal = 0
vars.value.tempTotalVar = OS.BuiltinFunctions.integerToLongInteger(0);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qpqw9cc750uj6KinLtyyBQ", callContext.id);
// SLADataPointList = GetCasesByCreatedOn.List
model.variables.sLADataPointListVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getCasesByCreatedOnAggr.listOut, new PHICoreModel.Legacy_DataPointList(), function (source, target) {
target.labelAttr = source.labelAttr;
target.valueAttr = OS.BuiltinFunctions.longIntegerToDecimal(((!(vars.value.tempTotalVar.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) ? (source.countAttr) : (OS.BuiltinFunctions.integerToLongInteger(0))));
target.seriesNameAttr = source.labelAttr;
target.tooltipAttr = ((source.labelAttr + " - ") + OS.BuiltinFunctions.longIntegerToText(((!(vars.value.tempTotalVar.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) ? (source.countAttr) : (OS.BuiltinFunctions.integerToLongInteger(0)))));
target.colorAttr = source.colorAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Xc_wTLkXHk6lomtej8EOXg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4e_DUURHR0ehp2mksvXDLg", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SLAStatusCard.OnAfterFetch_GetCases$vars", [{
name: "TempTotal",
attrName: "tempTotalVar",
mandatory: false,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._onToggle_GraphFilter$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnToggle_GraphFilter");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:TfrovG1GaEiq540g5AVEiw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ClientActions.TfrovG1GaEiq540g5AVEiw:eDHP8AR6kVnHrtY_QrXkwA", "PHICore", "OnToggle_GraphFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uXGD3v6UwEWKpYhOh5dzYw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wYZwSL4tuUyN_+j6W8maMA", callContext.id);
// ShowFilter = notShowFilter
model.variables.showFilterVar = !(model.variables.showFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cdONNoQWCU+bjj4iGNmJPA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:TfrovG1GaEiq540g5AVEiw", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:i1R47qSB8EqPDj8aaWwZ8A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg/ClientActions.i1R47qSB8EqPDj8aaWwZ8A:9AeaEtHxy73md5LeKsXH7g", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sX7vwi_z9Em+fXAMHL+Hmg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C2g6tVtgwkme+2B8i3cBPQ", callContext.id);
// GraphFilter.TimePeriod = 7
model.variables.graphFilterVar.timePeriodAttr = "7";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:s1wLuYEggkuP6wIL40LxcA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:i1R47qSB8EqPDj8aaWwZ8A", callContext.id);
}

};

Controller.prototype.onAfterFetch_GetTeamUsersByUserId$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch_GetTeamUsersByUserId$Action, callContext);

};
Controller.prototype.onEvent_GraphFilter$Action = function (graphFilterOutIn, closePopUpIn, isProceedIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onEvent_GraphFilter$Action, callContext, graphFilterOutIn, closePopUpIn, isProceedIn);

};
Controller.prototype.onAfterFetch_GetCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onAfterFetch_GetCases$Action, callContext);

};
Controller.prototype.onToggle_GraphFilter$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onToggle_GraphFilter$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:PtBxBjiWpk2hItZPps3gmg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.PtBxBjiWpk2hItZPps3gmg:HIkV_o27k6Exjnkfejt8MA", "PHICore", "SLAStatusCard", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:PtBxBjiWpk2hItZPps3gmg", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SLAStatusCard On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.SLAStatusCard.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"TL89HHy26UuFaNNvbl87KQ": {
getter: function (varBag, idService) {
return varBag.mSD_JoinIDsVar.value;
}
},
"va621NBLOUOhbZHLzIEsmA": {
getter: function (varBag, idService) {
return varBag.vars.value.graphFilterOutInLocal;
}
},
"BOF5UPD_9UyUhkhkMC8Hyw": {
getter: function (varBag, idService) {
return varBag.vars.value.closePopUpInLocal;
},
dataType: OS.Types.Boolean
},
"ERwZJ4SLe0WGmias+6vbGA": {
getter: function (varBag, idService) {
return varBag.vars.value.isProceedInLocal;
},
dataType: OS.Types.Boolean
},
"8IvawSPu_kS1liekReMczg": {
getter: function (varBag, idService) {
return varBag.mSD_JoinIDsVar.value;
}
},
"cFfwVsApmEq3jKTzEz+ccw": {
getter: function (varBag, idService) {
return varBag.vars.value.tempTotalVar;
},
dataType: OS.Types.LongInteger
},
"u7fpkiFKOkWo3JlXjb_Ftw": {
getter: function (varBag, idService) {
return varBag.model.variables.sLADataPointListVar;
}
},
"j2Pv4Izw5kGYZKFS2H5XYw": {
getter: function (varBag, idService) {
return varBag.model.variables.showFilterVar;
},
dataType: OS.Types.Boolean
},
"B+VdU0sQdUuA1L5XQQJJYQ": {
getter: function (varBag, idService) {
return varBag.model.variables.graphFilterVar;
}
},
"keqE1UvM7kSgFlcgn8xghA": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedTeamsVar;
},
dataType: OS.Types.Text
},
"g4D9HhY96E+3VlQ_fd6VEg": {
getter: function (varBag, idService) {
return varBag.model.variables.graphFilter_OriginalVar;
}
},
"dpkK2fGEj02EMZQqERATUg": {
getter: function (varBag, idService) {
return varBag.model.variables.refreshFilterVar;
},
dataType: OS.Types.Boolean
},
"ta8JCWVI1UGYnldBE0V5MA": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamUsersByUserIdAggr;
}
},
"7Ot4rs7tdUOC1h_mgqNSPw": {
getter: function (varBag, idService) {
return varBag.model.variables.getCasesByCreatedOnAggr;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
