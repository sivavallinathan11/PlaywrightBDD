define("Common_CW.PHICore_CW.GlobalSearchBox.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "APIGateway_IS.model", "Common_CW.controller$Check_SP_SearchRecord", "Common_CW.controller$Check_SP_ViewCases", "APIGateway_IS.model$PHIStakeholderSearchRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (OutSystems, Common_CWModel, Common_CWController, APIGateway_ISModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowConfirmationPopup", "showConfirmationPopupVar", "ShowConfirmationPopup", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsFind", "isFindVar", "IsFind", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("RequestFilter", "requestFilterVar", "RequestFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderSearchRequestRec());
}, false, APIGateway_ISModel.PHIStakeholderSearchRequestRec), 
this.attr("isClearSearch", "isClearSearchIn", "isClearSearch", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_isClearSearchInDataFetchStatus", "_isClearSearchInDataFetchStatus", "_isClearSearchInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("HasChange", "hasChangeIn", "HasChange", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", "_hasChangeInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form1: OS.Model.ValidationWidgetRecord,
Input_SearchKeyword: OS.Model.ValidationWidgetRecord,
Input_SearchKeyword2: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("isClearSearch" in inputs) {
this.variables.isClearSearchIn = inputs.isClearSearch;
if("_isClearSearchInDataFetchStatus" in inputs) {
this.variables._isClearSearchInDataFetchStatus = inputs._isClearSearchInDataFetchStatus;
}

}

if("HasChange" in inputs) {
this.variables.hasChangeIn = inputs.HasChange;
if("_hasChangeInDataFetchStatus" in inputs) {
this.variables._hasChangeInDataFetchStatus = inputs._hasChangeInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.GlobalSearchBox");
});
define("Common_CW.PHICore_CW.GlobalSearchBox.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "APIGateway_IS.model", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.GlobalSearchBox.mvc$model", "Common_CW.PHICore_CW.GlobalSearchBox.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Interaction.InputWithIcon.mvc$view", "OutSystemsUI.Content.Tooltip.mvc$view", "Common_CW.PHICore_CW.ConfirmationPopup.mvc$view", "Common_CW.controller$Check_SP_SearchRecord", "Common_CW.controller$Check_SP_ViewCases", "APIGateway_IS.model$PHIStakeholderSearchRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (OutSystems, Common_CWModel, Common_CWController, APIGateway_ISModel, React, OSView, Common_CW_PHICore_CW_GlobalSearchBox_mvc_model, Common_CW_PHICore_CW_GlobalSearchBox_mvc_controller, Common_CWClientVariables, OSWidgets, OutSystemsUI_Interaction_InputWithIcon_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, Common_CW_PHICore_CW_ConfirmationPopup_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.GlobalSearchBox";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Interaction_InputWithIcon_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, Common_CW_PHICore_CW_ConfirmationPopup_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_GlobalSearchBox_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_GlobalSearchBox_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "\"form card\"",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width9"
},
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_InputWithIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "3",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: model.getCachedValue(idService.getId("Input_SearchKeyword.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
extendedProperties: {
"aria-label": "Search",
autoComplete: "off"
},
gridProperties: {
classes: "ThemeGrid_Width9"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 100,
style: "form-control input-small gsearch-input",
variable: model.createVariable(OS.Types.Text, Common_CWClientVariables.getGlobalBasicSearch(), function (value) {
Common_CWClientVariables.setGlobalBasicSearch(value);
}),
_idProps: {
service: idService,
name: "Input_SearchKeyword"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "Clear Search"
},
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Link OnClick");
controller.clear$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "gsearch-clear",
visible: model.getCachedValue(idService.getId("DVlzPZpp_kCps73JEC52Jw.Visible"), function () {
return ((OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch())) !== (""));
}, function () {
return Common_CWClientVariables.getGlobalBasicSearch();
}),
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon text-neutral-6",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(Common_CWClientVariables.getGlobalBasicSearch())]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
extendedProperties: {
style: "text-align: right;"
},
style: "font-semi-bold",
visible: model.getCachedValue(idService.getId("RpKlxSNiXUuK1NQjDqQKmQ.Visible"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Link OnClick");
return controller.onClick_AdvancedSearch$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "under-header-link",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Advanced Search"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "angle-down",
iconSize: /*FontSize*/ 0,
style: "icon under-header-link",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("mz8RNKdIHk6WweclaVxVqA.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
gridProperties: {
classes: "ThemeGrid_Width3 ThemeGrid_MarginGutter"
},
isDefault: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Button OnClick");
return controller.onClick_Find$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-small",
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Find"))];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
ExtendedClass: "display-unset",
Position: Common_CWModel.staticEntities.position.bottomRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "12",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width9"
},
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Interaction_InputWithIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "15",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: false,
extendedProperties: {
"aria-label": "Search",
autoComplete: "off"
},
gridProperties: {
classes: "ThemeGrid_Width9"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 100,
style: "form-control input-small gsearch-input",
variable: model.createVariable(OS.Types.Text, Common_CWClientVariables.getGlobalBasicSearch(), function (value) {
Common_CWClientVariables.setGlobalBasicSearch(value);
}),
_idProps: {
service: idService,
name: "Input_SearchKeyword2"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Link, {
enabled: false,
extendedProperties: {
"aria-label": "Clear Search"
},
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Link OnClick");
controller.clear$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "gsearch-clear",
visible: model.getCachedValue(idService.getId("g7_sqwJIB0G6Qb+HKncyfw.Visible"), function () {
return ((OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch())) !== (""));
}, function () {
return Common_CWClientVariables.getGlobalBasicSearch();
}),
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon text-neutral-6",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(Common_CWClientVariables.getGlobalBasicSearch())]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
style: "font-semi-bold",
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Link OnClick");
return controller.onClick_AdvancedSearch$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "under-header-link",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Advanced Search"), React.createElement(OSWidgets.Icon, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
icon: "angle-down",
iconSize: /*FontSize*/ 0,
style: "icon under-header-link",
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Button, {
enabled: false,
gridProperties: {
classes: "ThemeGrid_Width3 ThemeGrid_MarginGutter"
},
isDefault: true,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/GlobalSearchBox/Button OnClick");
return controller.onClick_Find$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-small",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Find"))];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(Common_CWClientVariables.getGlobalBasicSearch())]
})];
}))];
}, function () {
return [];
}), React.createElement(Common_CW_PHICore_CW_ConfirmationPopup_mvc_view, {
inputs: {
Show: model.variables.showConfirmationPopupVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
confirmationResponse$Action: function (userResponseIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/ConfirmationPopup ConfirmationResponse");
controller.confirmationResponse$Action(userResponseIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "25",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.GlobalSearchBox.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "APIGateway_IS.model", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.GlobalSearchBox.mvc$debugger", "Common_CW.controller$Check_SP_SearchRecord", "Common_CW.controller$Check_SP_ViewCases", "APIGateway_IS.model$PHIStakeholderSearchRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (OutSystems, Common_CWModel, Common_CWController, APIGateway_ISModel, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_GlobalSearchBox_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClick_Find$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Find");
callContext = controller.callContext(callContext);
var check_SP_SearchRecordVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.check_SP_SearchRecordVar = check_SP_SearchRecordVar;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:dtM_Apd6iEetoF603hsrcg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.dtM_Apd6iEetoF603hsrcg:XLLc0eIj_1e4W45gmjvDSQ", "Common_CW", "OnClick_Find", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Nnanu977ME+ClWKA3_syAg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7T+suM0WA063Qf_qfHGPHA", callContext.id);
// Trigger Event: CheckChanges
return controller.checkChanges$Action(model.variables.hasChangeIn, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2IN61X_HSU+0CQW2xNUXuQ", callContext.id);
// IsFind = True
model.variables.isFindVar = true;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sg3ijr2zukKL5qHLCi8JUA", callContext.id) && model.variables.hasChangeIn)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pfk586_arEKPEUOnYo+Fdw", callContext.id);
// Execute Action: Toggle_Confirmation
controller._toggle_Confirmation$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:K+oey0A6tUqVhJIDxcOFRQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MKJEhruCIEC35065fS2Xgg", callContext.id);
// Execute Action: Check_SP_SearchRecord
check_SP_SearchRecordVar.value = Common_CWController.default.check_SP_SearchRecord$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:R6M1k6tjqUidUnLp0xL3xg", callContext.id) && check_SP_SearchRecordVar.value.hasAccessOut)) {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KuaquSnqgEa1gf8Uq51bWA", callContext.id) && (OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch()) === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:EW182EZEHkW4kFJUmcMAJw", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Please enter a search term", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Yxj5pYzOaEyensiUiLTgWw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id);
// RequestFilter.search = If
model.variables.requestFilterVar.searchAttr = (((OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch()) === "")) ? ("") : (Common_CWClientVariables.getGlobalBasicSearch()));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RequestFilter.orderByField = "Name"
model.variables.requestFilterVar.orderByFieldAttr = "Name";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// RequestFilter.orderByDirection = "Ascending"
model.variables.requestFilterVar.orderByDirectionAttr = "Ascending";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// RequestFilter.isActive = Trim = ""
model.variables.requestFilterVar.isActiveAttr = (OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch()) === "");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// RequestFilter.name = If
model.variables.requestFilterVar.nameAttr = (((((((Common_CWClientVariables.getGlobalBasicSearch()) !== ("")) && (OS.BuiltinFunctions.textToIntegerValidate(Common_CWClientVariables.getGlobalBasicSearch()) === false)) && (OS.BuiltinFunctions.textToDateValidate(Common_CWClientVariables.getGlobalBasicSearch()) === false)) && (OS.BuiltinFunctions.emailAddressValidate(Common_CWClientVariables.getGlobalBasicSearch()) === false))) ? (Common_CWClientVariables.getGlobalBasicSearch()) : (""));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// RequestFilter.email = If
model.variables.requestFilterVar.emailAttr = ((OS.BuiltinFunctions.emailAddressValidate(Common_CWClientVariables.getGlobalBasicSearch())) ? (Common_CWClientVariables.getGlobalBasicSearch()) : (""));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OvMCMMNR4E+nbffnnyjgDw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// RequestFilter.phone = If
model.variables.requestFilterVar.phoneAttr = (((((Common_CWClientVariables.getGlobalBasicSearch()) !== ("")) && ((OS.BuiltinFunctions.textToIntegerValidate(Common_CWClientVariables.getGlobalBasicSearch()) === true) || ((OS.BuiltinFunctions.index(Common_CWClientVariables.getGlobalBasicSearch(), "+", 0, false, false)) !== (-1))))) ? (Common_CWClientVariables.getGlobalBasicSearch()) : (""));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KEM6TUzcSEi74GjkgC0K7w", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(("/PHICore/Search?For=" + Common_CWClientVariables.getGlobalBasicSearch()), {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vF1jINUxFkO5R8yBrrySGw", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:dtM_Apd6iEetoF603hsrcg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:dtM_Apd6iEetoF603hsrcg", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:QvReLxnIhUGr5ppZIQ_mMA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.QvReLxnIhUGr5ppZIQ_mMA:VOqEKcM0QkA4uCKmU3se_Q", "Common_CW", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:F3qvfIXA8UKeX+Y46tEqlw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:snkNbPZ960iZCj89+kF49A", callContext.id);
// GlobalBasicSearch = If
Common_CWClientVariables.setGlobalBasicSearch(((model.variables.isClearSearchIn) ? ("") : (Common_CWClientVariables.getGlobalBasicSearch())));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:4vUV_RvEHEKR7T8jUR5FKQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:QvReLxnIhUGr5ppZIQ_mMA", callContext.id);
}

};
Controller.prototype._clear$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Clear");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:pI54O__5i0GPTeQiB530NQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.pI54O__5i0GPTeQiB530NQ:u53pzLjMRehzmu52r9M5Gw", "Common_CW", "Clear", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rRY6wxAbJU27XjdxsX0GFg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dPMy0NWnLEipt8IhH87V_Q", callContext.id);
// GlobalBasicSearch = ""
Common_CWClientVariables.setGlobalBasicSearch("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:taI2k1Xl6E6owErcTBCMWA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:pI54O__5i0GPTeQiB530NQ", callContext.id);
}

};
Controller.prototype._onClick_AdvancedSearch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_AdvancedSearch");
callContext = controller.callContext(callContext);
var check_SP_SearchRecordVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.check_SP_SearchRecordVar = check_SP_SearchRecordVar;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:eJthldj33kOAr7PN85YVFA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.eJthldj33kOAr7PN85YVFA:GuRZIwDaolz4+Z_cot9btw", "Common_CW", "OnClick_AdvancedSearch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:d3X+EMOSOk62E6fq_A2bPw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:4MlUdX70L0O7ONljAl4rDw", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_SearchRecord$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tM9SsYQUI0KPAJemDWwjFg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:WKjJyTPyYUe782ckduqKkQ", callContext.id);
// Trigger Event: CheckChanges
return controller.checkChanges$Action(model.variables.hasChangeIn, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:khPUf6cts0Se34MZvlPjVw", callContext.id);
// IsFind = False
model.variables.isFindVar = false;
}).then(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kvvGuHaeu0Ovxr1Vsv3YXQ", callContext.id) && model.variables.hasChangeIn)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vrjZKb8KD0qGDh3_m_vibQ", callContext.id);
// Execute Action: Toggle_Confirmation
controller._toggle_Confirmation$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:DFajH+WtpE6mr0Mqco7Xnw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+1RcvdCWck23FdvwuN3K3A", callContext.id);
// Execute Action: Check_SP_SearchRecord
check_SP_SearchRecordVar.value = Common_CWController.default.check_SP_SearchRecord$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wHgtPIwg0kmqE6Ym2HOaxQ", callContext.id) && check_SP_SearchRecordVar.value.hasAccessOut)) {
// clear basic search
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NGTE7+aagEmm09Wom0pIrQ", callContext.id);
// GlobalBasicSearch = ""
Common_CWClientVariables.setGlobalBasicSearch("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+72xGVxZ1EW2zh5c2G8Z0A", callContext.id);
// Destination: /Common_CW/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore/Search?For", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rahd82hvT0a8jo7o3_hc1w", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

}

});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:eJthldj33kOAr7PN85YVFA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:eJthldj33kOAr7PN85YVFA", callContext.id);
throw ex;

});
};
Controller.prototype._toggle_Confirmation$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_Confirmation");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:VGOPqM7RiUme7dqiViwVIQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.VGOPqM7RiUme7dqiViwVIQ:Q72NO4YST2ciPVaw+1G0WQ", "Common_CW", "Toggle_Confirmation", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:28u_d6keKEyrUXNfrCHRfA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:SDGpUvPPy022EuWDw248VA", callContext.id);
// ShowConfirmationPopup = notShowConfirmationPopup
model.variables.showConfirmationPopupVar = !(model.variables.showConfirmationPopupVar);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0_w3dLu74ky5uml4b05hnA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:VGOPqM7RiUme7dqiViwVIQ", callContext.id);
}

};
Controller.prototype._confirmationResponse$Action = function (userResponseIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ConfirmationResponse");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.PHICore_CW.GlobalSearchBox.ConfirmationResponse$vars"))());
vars.value.userResponseInLocal = userResponseIn;
var check_SP_SearchRecord2Var = new OS.DataTypes.VariableHolder();
var check_SP_SearchRecordVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.check_SP_SearchRecord2Var = check_SP_SearchRecord2Var;
varBag.check_SP_SearchRecordVar = check_SP_SearchRecordVar;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:+KgK81wI9kOwodNN38xKaw:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ/ClientActions.+KgK81wI9kOwodNN38xKaw:rvWq8CFGQLMuplomOqxSWg", "Common_CW", "ConfirmationResponse", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Qf7i2BZtc0uYxFEeX+HOpg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1H+TMWFZNESorej7+sz4ng", callContext.id) && vars.value.userResponseInLocal)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:R6KAk69ih0aGZ4TF8mWWsg", callContext.id);
// Execute Action: Toggle_Confirmation3
controller._toggle_Confirmation$Action(callContext);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pUFyPlDxBEef+wHVtVLk2Q", callContext.id) && model.variables.isFindVar)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xuJFJRfhw0ySmC94vf8F1Q", callContext.id);
// Execute Action: Check_SP_SearchRecord
check_SP_SearchRecordVar.value = Common_CWController.default.check_SP_SearchRecord$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1_mqbtZYoUaEeGDA3y5bww", callContext.id) && check_SP_SearchRecordVar.value.hasAccessOut)) {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Tt1ykiEnqkeRGwEhc8iQ6g", callContext.id) && (OS.BuiltinFunctions.trim(Common_CWClientVariables.getGlobalBasicSearch()) === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GhsaVreQoEefCO_CzOXWOg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Please enter a search term", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ni1J8BRCDEOgo_kHp24vvA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qW3++r3W1U23nLSOZc7R4A", callContext.id);
// Destination: /Common_CW/
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(("/PHICore/Search?For=" + Common_CWClientVariables.getGlobalBasicSearch()), {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sMVZzBFf90qL3J1HuBnocw", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0B_OA31MAEWabd8GASlocQ", callContext.id);
// Execute Action: Check_SP_SearchRecord2
check_SP_SearchRecord2Var.value = Common_CWController.default.check_SP_SearchRecord$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GHHGEs+OB0eEjExAwzxC0g", callContext.id) && check_SP_SearchRecord2Var.value.hasAccessOut)) {
// clear basic search
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_wv8Hf4OMkSilgeGya4gqw", callContext.id);
// GlobalBasicSearch = ""
Common_CWClientVariables.setGlobalBasicSearch("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fO4nTeL01EqOp_ItQEya5g", callContext.id);
// Destination: /Common_CW/
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("/PHICore/Search", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:woyA_b_YLE+ER_keFu3n4w", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

}

} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:JtT1sS6vckKDMtMt7bTZpg", callContext.id);
// Execute Action: Toggle_Confirmation
controller._toggle_Confirmation$Action(callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HYWM64IIf0ads8kXN9vTRQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:+KgK81wI9kOwodNN38xKaw", callContext.id);
}

};
Controller.registerVariableGroupType("Common_CW.PHICore_CW.GlobalSearchBox.ConfirmationResponse$vars", [{
name: "UserResponse",
attrName: "userResponseInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);

Controller.prototype.onClick_Find$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Find$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.clear$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clear$Action, callContext);

};
Controller.prototype.onClick_AdvancedSearch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_AdvancedSearch$Action, callContext);

};
Controller.prototype.toggle_Confirmation$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_Confirmation$Action, callContext);

};
Controller.prototype.confirmationResponse$Action = function (userResponseIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._confirmationResponse$Action, callContext, userResponseIn);

};
Controller.prototype.checkChanges$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:9Rmm1sm7rkiASU3zP5qhgQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.9Rmm1sm7rkiASU3zP5qhgQ:Q2_CqQucleFpg7oRl9q3GQ", "Common_CW", "GlobalSearchBox", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:9Rmm1sm7rkiASU3zP5qhgQ", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/GlobalSearchBox On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.GlobalSearchBox.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"MKJEhruCIEC35065fS2Xgg": {
getter: function (varBag, idService) {
return varBag.check_SP_SearchRecordVar.value;
}
},
"+1RcvdCWck23FdvwuN3K3A": {
getter: function (varBag, idService) {
return varBag.check_SP_SearchRecordVar.value;
}
},
"NMiPWomgAEKRlMbj1_qNrw": {
getter: function (varBag, idService) {
return varBag.vars.value.userResponseInLocal;
},
dataType: OS.Types.Boolean
},
"0B_OA31MAEWabd8GASlocQ": {
getter: function (varBag, idService) {
return varBag.check_SP_SearchRecord2Var.value;
}
},
"xuJFJRfhw0ySmC94vf8F1Q": {
getter: function (varBag, idService) {
return varBag.check_SP_SearchRecordVar.value;
}
},
"jyGWJAuGF0upMWd4IJG9Mw": {
getter: function (varBag, idService) {
return varBag.model.variables.showConfirmationPopupVar;
},
dataType: OS.Types.Boolean
},
"5daOYdm1LkSQYjRB4biePg": {
getter: function (varBag, idService) {
return varBag.model.variables.isFindVar;
},
dataType: OS.Types.Boolean
},
"tNOC7r+otkikBtDmyWVu_w": {
getter: function (varBag, idService) {
return varBag.model.variables.requestFilterVar;
}
},
"aUyZOvwC0EmKQBl42SzENw": {
getter: function (varBag, idService) {
return varBag.model.variables.isClearSearchIn;
},
dataType: OS.Types.Boolean
},
"mlVdidMBUUakLq1YOXlj9Q": {
getter: function (varBag, idService) {
return varBag.model.variables.hasChangeIn;
},
dataType: OS.Types.Boolean
},
"7nT8EzlJQUauN214Vvv7VQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CheckSearchRecord"));
})(varBag.model, idService);
}
},
"ne7_+WWuNUW8ArsSkONVCA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form1"));
})(varBag.model, idService);
}
},
"M3X5Sh05L0CTQYuXT3kc4A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Check_SP_SearchRecord3"));
})(varBag.model, idService);
}
},
"VUdpTgZozECn3l6atvhK6A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"bzL3j3mepECUMel7aqKbcg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"fpR4Lv2J00Sk9o7QT5vhaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_SearchKeyword"));
})(varBag.model, idService);
}
},
"9voO7puGYky_tINcXSUedA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"oW8h1Wf6ukulHFluIDOY_A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"9EdUJtXC7Uu99PpMp_Va6A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"SQomUojrYUCTuRREKQOw1w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_SearchKeyword2"));
})(varBag.model, idService);
}
},
"6s+sM07J50e4arTbD9XEow": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
