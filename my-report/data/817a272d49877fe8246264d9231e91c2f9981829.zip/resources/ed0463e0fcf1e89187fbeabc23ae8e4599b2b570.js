﻿define("PHICore.Common_Widgets.SearchResults.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "PHICore.controller", "Common_CW.model", "Common_CW.PHICore_CW.PolicyStatus_Pill.mvc$model", "Common_CW.PHICore_CW.Flag_Pill.mvc$model", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$model", "Common_CW.PHICore_CW.Pagination.mvc$model", "Common_CW.PHICore_CW.RestrictedPopup.mvc$model", "Common_CW.controller$Check_PM_34_ViewQuoteAndProspect", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_23_ViewPolicyAndMember", "Common_CW.controller$Check_SM_ViewStakeholderExclMember", "PHICore.model$StakeholderSearchRec", "PHICore.model$FlagItemList", "Common_CW.controller$OnValidate_Flags", "PHICore.controller$GetIndividualFlags", "Common_CW.model$SearchRec"], function (OutSystems, PHICoreModel, Common_CWController, PHICoreController, Common_CWModel, Common_CW_PHICore_CW_PolicyStatus_Pill_mvcModel, Common_CW_PHICore_CW_Flag_Pill_mvcModel, Common_CW_PHICore_CW_NoItemsFound_Block_mvcModel, Common_CW_PHICore_CW_Pagination_mvcModel, Common_CW_PHICore_CW_RestrictedPopup_mvcModel) {
var OS = OutSystems.Internal;

var SearchDataActRec = (function (_super) {
__extends(SearchDataActRec, _super);
function SearchDataActRec(defaults) {
_super.apply(this, arguments);
}
SearchDataActRec.attributesToDeclare = function () {
return [
this.attr("Result", "resultOut", "Result", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.SearchRec());
}, true, Common_CWModel.SearchRec)
].concat(_super.attributesToDeclare.call(this));
};
SearchDataActRec.fromStructure = function (str) {
return new SearchDataActRec(new SearchDataActRec.RecordClass({
resultOut: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SearchDataActRec.init();
return SearchDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("StartIndex", "startIndexVar", "StartIndex", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("MaxRecords", "maxRecordsVar", "MaxRecords", true, false, OS.Types.Integer, function () {
return 25;
}, false), 
this.attr("TableSortByField", "tableSortByFieldVar", "TableSortByField", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("TableSortByDirection", "tableSortByDirectionVar", "TableSortByDirection", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsDisplayRestrictedPopup", "isDisplayRestrictedPopupVar", "IsDisplayRestrictedPopup", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Request", "requestIn", "Request", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.StakeholderSearchRec());
}, false, PHICoreModel.StakeholderSearchRec), 
this.attr("_requestInDataFetchStatus", "_requestInDataFetchStatus", "_requestInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsBasicSearch", "isBasicSearchIn", "IsBasicSearch", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isBasicSearchInDataFetchStatus", "_isBasicSearchInDataFetchStatus", "_isBasicSearchInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("BasicSearchQuery", "basicSearchQueryIn", "BasicSearchQuery", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_basicSearchQueryInDataFetchStatus", "_basicSearchQueryInDataFetchStatus", "_basicSearchQueryInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Search", "searchDataAct", "searchDataAct", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new SearchDataActRec());
}, true, SearchDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((Common_CW_PHICore_CW_PolicyStatus_Pill_mvcModel.hasValidationWidgets || Common_CW_PHICore_CW_Flag_Pill_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_NoItemsFound_Block_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_Pagination_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_RestrictedPopup_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Request" in inputs) {
this.variables.requestIn = inputs.Request;
if("_requestInDataFetchStatus" in inputs) {
this.variables._requestInDataFetchStatus = inputs._requestInDataFetchStatus;
}

}

if("IsBasicSearch" in inputs) {
this.variables.isBasicSearchIn = inputs.IsBasicSearch;
if("_isBasicSearchInDataFetchStatus" in inputs) {
this.variables._isBasicSearchInDataFetchStatus = inputs._isBasicSearchInDataFetchStatus;
}

}

if("BasicSearchQuery" in inputs) {
this.variables.basicSearchQueryIn = inputs.BasicSearchQuery;
if("_basicSearchQueryInDataFetchStatus" in inputs) {
this.variables._basicSearchQueryInDataFetchStatus = inputs._basicSearchQueryInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.SearchResults");
});
define("PHICore.Common_Widgets.SearchResults.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "Common_CW.model", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.SearchResults.mvc$model", "PHICore.Common_Widgets.SearchResults.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.PolicyStatus_Pill.mvc$view", "Common_CW.PHICore_CW.Flag_Pill.mvc$view", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$view", "Common_CW.PHICore_CW.Pagination.mvc$view", "Common_CW.PHICore_CW.RestrictedPopup.mvc$view", "Common_CW.controller$Check_PM_34_ViewQuoteAndProspect", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_23_ViewPolicyAndMember", "Common_CW.controller$Check_SM_ViewStakeholderExclMember", "PHICore.model$StakeholderSearchRec", "PHICore.model$FlagItemList", "Common_CW.controller$OnValidate_Flags", "PHICore.controller$GetIndividualFlags", "Common_CW.model$SearchRec"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, Common_CWModel, React, OSView, PHICore_Common_Widgets_SearchResults_mvc_model, PHICore_Common_Widgets_SearchResults_mvc_controller, PHICoreClientVariables, OSWidgets, Common_CW_PHICore_CW_PolicyStatus_Pill_mvc_view, Common_CW_PHICore_CW_Flag_Pill_mvc_view, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, Common_CW_PHICore_CW_Pagination_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.SearchResults";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/PHICore.Common_Widgets.SearchResults.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [Common_CW_PHICore_CW_PolicyStatus_Pill_mvc_view, Common_CW_PHICore_CW_Flag_Pill_mvc_view, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, Common_CW_PHICore_CW_Pagination_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_SearchResults_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_SearchResults_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.TableRecords, {
onSort: function (clickedColumnIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults/Table OnSort");
return controller.onSort$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
showHeader: true,
source: model.variables.searchDataAct.resultOut.searchStructureListAttr,
style: "table display-table",
styleHeader: "table-header",
styleRow: "table-row",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr),
placeholders: {
headerRow: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "StakeholderId",
style: "width-1p",
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Text, {
style: "break-word",
text: ["ID"],
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
extendedProperties: {
style: "min-width: 190px;"
},
sortAttribute: "Name",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Text, {
style: "break-word wrap",
text: ["Name"],
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
style: "width-1p",
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Type"), React.createElement(OSWidgets.HeaderCell, {
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Contact Details"), React.createElement(OSWidgets.HeaderCell, {
extendedProperties: {
style: "min-width: 190px;"
},
style: "custom-widthSFA",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Text, {
style: "break-word wrap",
text: ["Address"],
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "DateOfBirth",
style: "width-1p",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "DOB"), React.createElement(OSWidgets.HeaderCell, {
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Policy No."), React.createElement(OSWidgets.HeaderCell, {
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Product"), React.createElement(OSWidgets.HeaderCell, {
style: "width-1p",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Policy Status"), React.createElement(OSWidgets.HeaderCell, {
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Flags")];
}),
row: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderIdAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderIdAttr,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(!(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})];
}, function () {
return [$if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_34_ViewQuoteAndProspect$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) && (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === "prospect")), false, this, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": ("Stakeholder\'s Name " + model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr)
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults/StakeholderLink2 OnClick");
return controller.onClick_StakeholderName$Action(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderIdAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flags_ListAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "StakeholderLink2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
}))];
}, function () {
return [$if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) && (((((OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === "member") || (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === OS.BuiltinFunctions.toLower("nonInsured"))) || (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === OS.BuiltinFunctions.toLower("group"))) || (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === OS.BuiltinFunctions.toLower("agent"))) || (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === OS.BuiltinFunctions.toLower("provider")))), false, this, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": ("Stakeholder\'s Name " + model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr)
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults/StakeholderLink OnClick");
return controller.onClick_StakeholderName$Action(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderIdAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flags_ListAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "StakeholderLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
}))];
}, function () {
return [$if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_ViewStakeholderExclMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) && (OS.BuiltinFunctions.toLower(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr) === "lead")), false, this, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": ("Stakeholder\'s Name " + model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr)
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults/StakeholderLink3 OnClick");
return controller.onClick_StakeholderName$Action(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderIdAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flags_ListAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "StakeholderLink3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
}))];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).nameAttr,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})];
})];
})];
})];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, false, this, function () {
return [$if(((OS.BuiltinFunctions.substr(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr, 20, 1)) !== ("")), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
title: model.getCachedValue(idService.getId("a0odQQf46EWUKglk5MsKeQ.title"), function () {
return ((((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) : ("-")) + "\r\n") + ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) : ("-")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr;
})
},
value: model.getCachedValue(idService.getId("a0odQQf46EWUKglk5MsKeQ.Value"), function () {
return ((((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) : ("-")) + "\r\n") + ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) !== (""))) ? ((OS.BuiltinFunctions.substr(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr, 0, 20) + "...")) : ("-")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr;
}),
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
extendedProperties: {
title: model.getCachedValue(idService.getId("Ew5hjJqOyE2Xxb0lGXNUFw.title"), function () {
return ((((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) : ("-")) + "\r\n") + ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) : ("-")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr;
})
},
value: model.getCachedValue(idService.getId("Ew5hjJqOyE2Xxb0lGXNUFw.Value"), function () {
return ((((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr) : ("-")) + "\r\n") + ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr) : ("-")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).phoneAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).emailAttr;
}),
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})];
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).addressAttr)]
}, React.createElement(OSWidgets.Expression, {
style: "break-word wrap",
value: model.getCachedValue(idService.getId("dCjvkjJc_EKyMEDreb6i_A.Value"), function () {
return ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).addressAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).addressAttr) : ("-"));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).addressAttr;
}),
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).dateOfBirthAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("lKgSN9rWJke9Nxjp7PuSVA.Value"), function () {
return ((!(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).dateOfBirthAttr.equals(OS.BuiltinFunctions.nullDate()))) ? (OS.BuiltinFunctions.formatDateTime(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).dateOfBirthAttr, "dd/MM/yyyy")) : ("-"));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).dateOfBirthAttr;
}),
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, false, this, function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [$if((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr === ""), false, this, function () {
return ["- "];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("6YNkKiWUaki0uHxzlsLcyg.aria-label"), function () {
return ("Policy Number " + (((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr === "")) ? ("Empty") : ((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr + ((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr) ? (((" (+" + (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr).toString()) + ")")) : (""))))));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr;
})
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults/Link OnClick");
return controller.onClick_PolicyNumber$Action(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("9tUkZp7tIUGMKN0rYB_Xpg.Value"), function () {
return (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr + ((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr) ? (((" (+" + (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr).toString()) + ")")) : ("")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr;
}),
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
}))];
})];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: false,
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("#", {}),
visible: true,
_idProps: {
service: idService,
name: "Link_Policy_Disabled"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("PCE9AX2yZ061XaNWmbIj0Q.Value"), function () {
return (((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr) : ("-")) + ((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr) ? (((" (+" + (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr).toString()) + ")")) : ("")));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyNumberAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).hasMultiplePoliciesAttr;
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr;
}),
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
}))];
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).productAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("cwqf6ecl+UOyFu8uCK5Iug.Value"), function () {
return ((((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).productAttr) !== (""))) ? (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).productAttr) : ("-"));
}, function () {
return model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).productAttr;
}),
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "42"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, false, this, function () {
return [React.createElement(Common_CW_PHICore_CW_PolicyStatus_Pill_mvc_view, {
inputs: {
Policy: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyStatusAttr,
_policyInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr),
Count: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).policyCountAttr,
_countInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "43",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flagCountAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flagsAttr), asPrimitiveValue(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)]
}, $if(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr, false, this, function () {
return [React.createElement(Common_CW_PHICore_CW_Flag_Pill_mvc_view, {
inputs: {
Flag: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flagsAttr,
_flagInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr),
Count: model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).flagCountAttr,
_countInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "45",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}))];
}, callContext, idService, "1_0")
},
_dependencies: [asPrimitiveValue(model.variables.searchDataAct.dataFetchStatusAttr)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "IsTableLoadingOrEmpty"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.searchDataAct.isDataFetchedAttr && model.variables.searchDataAct.resultOut.searchStructureListAttr.isEmpty), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "49",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No results were found. "];
}),
subtitle_Placeholder: new PlaceholderContent(function () {
return ["Please revise your search criteria and try again"];
}),
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
})))];
}, function () {
return [$if(!(model.variables.searchDataAct.isDataFetchedAttr), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating",
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
}))), React.createElement(Common_CW_PHICore_CW_Pagination_mvc_view, {
inputs: {
TotalCount: OS.BuiltinFunctions.integerToLongInteger(model.variables.searchDataAct.resultOut.totalCountAttr),
_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.searchDataAct.dataFetchStatusAttr),
MaxRecords: model.variables.maxRecordsVar,
StartIndex: model.variables.startIndexVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onNavigate$Action: function (newStartIndexIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination OnNavigate");
return controller.onNavigate_Pagination$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "51",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
previous: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-left",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
next: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-right",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_RestrictedPopup_mvc_view, {
inputs: {
Message: "Your current permissions do not allow access this record. If you think this is an error, please contact your administrator.",
Show: model.variables.isDisplayRestrictedPopupVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
eventClose$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/RestrictedPopup EventClose");
controller.onClose_RestrictedPopUp$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "54",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.SearchResults.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "Common_CW.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.SearchResults.mvc$debugger", "Common_CW.controller$Check_PM_34_ViewQuoteAndProspect", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_23_ViewPolicyAndMember", "Common_CW.controller$Check_SM_ViewStakeholderExclMember", "PHICore.model$StakeholderSearchRec", "PHICore.model$FlagItemList", "Common_CW.controller$OnValidate_Flags", "PHICore.controller$GetIndividualFlags", "Common_CW.model$SearchRec"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, Common_CWModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_SearchResults_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
search$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
search$DataActRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.search$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:PTZHeG0S5ESaRJdFYDHVEQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/DataActions.PTZHeG0S5ESaRJdFYDHVEQ:qtM0oa0QYLoKXD+m47fhug", "PHICore", "Search", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchResults/Search");
return controller.callDataAction("DataActionSearch", "screenservices/PHICore/Common_Widgets/SearchResults/DataActionSearch", "_q0JGUXgTDnhw+KLXpe6lA", function (b) {
model.variables.searchDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.searchDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.searchDataAct.constructor));
}, 60, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:PTZHeG0S5ESaRJdFYDHVEQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["search$DataActRefresh"];
// Client Actions
Controller.prototype._onClick_StakeholderName$Action = function (stakeholderIdIn, isAuthorizedIn, flags_ListIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_StakeholderName");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchResults.OnClick_StakeholderName$vars"))());
vars.value.stakeholderIdInLocal = stakeholderIdIn;
vars.value.isAuthorizedInLocal = isAuthorizedIn;
vars.value.flags_ListInLocal = flags_ListIn.clone();
var onValidate_FlagsVar = new OS.DataTypes.VariableHolder();
var getIndividualFlagsVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.onValidate_FlagsVar = onValidate_FlagsVar;
varBag.getIndividualFlagsVar = getIndividualFlagsVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:KTIQEm4yAUup1zyoGJKNPQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.KTIQEm4yAUup1zyoGJKNPQ:b0dqwUt2IjaJ8sCCInj5gw", "PHICore", "OnClick_StakeholderName", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BkrLfzDqH0qXB4wIc_BNwA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
var block2 = false;
return OS.Flow.doWhileAsync(function () {
return false;
}, function () {
block2 = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VtFRqGJ3jU2BAMrJ8LQ8vw", callContext.id);
// Execute Action: GetIndividualFlags
model.flush();
return PHICoreController.default.getIndividualFlags$Action(vars.value.stakeholderIdInLocal, vars.value.flags_ListInLocal, callContext).then(function (value) {
getIndividualFlagsVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4tZCabUD+Ues++Y8+63JBg", callContext.id) && !(!(model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).isAuthorisedAttr)))) {
return OS.Flow.doWhileAsync(function () {
return false;
}, function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2ebbSnZ9HUOJKR0OWcAQDQ", callContext.id) && vars.value.isAuthorizedInLocal)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TevAKnDnREeg0qmJn3n4Jw", callContext.id);
// Execute Action: OnValidate_Flags
model.flush();
return Common_CWController.default.onValidate_Flags$Action(vars.value.flags_ListInLocal, callContext).then(function (value) {
onValidate_FlagsVar.value = value;
}).then(function () {
// Has Flags
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:df4+visUYEmA4p66oQbyiQ", callContext.id) && !(onValidate_FlagsVar.value.isValidOut))) {
// jump to block2
block2 = true;
return OS.Flow.breakAsync();
}

});
}

}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ozOp4DV+g0SOKdKQWVrnDA", callContext.id) && (model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr === "Lead"))) {
// Check_SM_ViewLead
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f5_pX8DILkuxq_8ObRdSDw", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_ViewStakeholderExclMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ALpBjYp1Bkeqssigf9mv0A", callContext.id);
// Destination: /PHICore/Lead
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Lead", {
isSearch: OS.DataConversion.ServerDataConverter.to(true, OS.Types.Boolean),
StakeholderId: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.trim(vars.value.stakeholderIdInLocal), OS.Types.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

} else {
if((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr === "Prospect")) {
// ViewQuoteAndProspect
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ALXl_UDJP0GlSshCra6K3g", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_34_ViewQuoteAndProspect$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VQbLJCbr+0GSV7uUNST9FQ", callContext.id);
// Destination: /PHICore/Prospect
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Prospect", {
StakeholderId: OS.DataConversion.ServerDataConverter.to(vars.value.stakeholderIdInLocal, OS.Types.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

} else {
if((model.variables.searchDataAct.resultOut.searchStructureListAttr.getCurrent(callContext.iterationContext).stakeholderTypeAttr === "NonInsured")) {
// ViewPolicyAndMember
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5mQpKcgYREWM9OFvuB4jog", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:viRXaKQFa0KwhuwoYjzNlA", callContext.id);
// Destination: /PHICore/NonInsured
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "NonInsured", {
StakeholderId: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.trim(vars.value.stakeholderIdInLocal), OS.Types.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
return OS.Flow.breakAsync();
}

} else {
// ViewPolicyAndMember
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5eRoR_3jYkm6qysIUHnrsg", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KYse41u9JkGxquoSmDvgyQ", callContext.id);
// Destination: /PHICore/Member
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Member", {
StakeholderId: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.trim(vars.value.stakeholderIdInLocal), OS.Types.Text)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iIBsqyGhh0+QeAEzAqeZwQ", callContext.id);
// Trigger Event: Event_RestrictedScreen3
return controller.event_RestrictedScreen$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gZ0YE8nMr0mrSDxaf44q6g", callContext.id);
return OS.Flow.returnAsync();

});
}

});
});
}).then(function () {
if(block2) {
return OS.Flow.breakAsync();
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:x80dihnsW06Q32uDP6Ztzg", callContext.id);
// Trigger Event: Event_RestrictedScreen2
return controller.event_RestrictedScreen$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wFITTBOY9EaMcmU4Pt9V7g", callContext.id);
return OS.Flow.returnAsync();

});
});
}

});
});
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M7Pj347LUUCu0xPg9sJd9A", callContext.id);
// Trigger Event: Event_RestrictedScreen
return controller.event_RestrictedScreen$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WJ9OCzqGDEGlwmtEOtDRdQ", callContext.id);
});
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KTIQEm4yAUup1zyoGJKNPQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KTIQEm4yAUup1zyoGJKNPQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchResults.OnClick_StakeholderName$vars", [{
name: "StakeholderId",
attrName: "stakeholderIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsAuthorized",
attrName: "isAuthorizedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Flags_List",
attrName: "flags_ListInLocal",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.FlagItemList();
},
complexType: PHICoreModel.FlagItemList
}]);
Controller.prototype._onSort$Action = function (clickedColumnIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnSort");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchResults.OnSort$vars"))());
vars.value.clickedColumnInLocal = clickedColumnIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:cHQ_KD5KOUORgI1UOHXqmQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.cHQ_KD5KOUORgI1UOHXqmQ:p7AsQ3UKySqJ9PrVHFqNsg", "PHICore", "OnSort", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ww1tTKsF9EeySDB3wxIXDw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// same column and ascending
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5rNLuGvgy0K832l66T37Rg", callContext.id) && ((model.variables.tableSortByFieldVar === vars.value.clickedColumnInLocal) && (model.variables.tableSortByDirectionVar === "Ascending")))) {
// TableSort += DESC
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:diPnPoo3UkeNY4g6jCCq8Q", callContext.id);
// TableSortByField = ClickedColumn
model.variables.tableSortByFieldVar = vars.value.clickedColumnInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:diPnPoo3UkeNY4g6jCCq8Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TableSortByDirection = "Descending"
model.variables.tableSortByDirectionVar = "Descending";
} else {
// same column and descending
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kZu52LsdmkGw9OPoiEzZwA", callContext.id) && ((model.variables.tableSortByFieldVar === vars.value.clickedColumnInLocal) && (model.variables.tableSortByDirectionVar === "Descending")))) {
// TableSort += ASC
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lyl+MAf8JESzmFuoNUElgA", callContext.id);
// TableSortByField = ClickedColumn
model.variables.tableSortByFieldVar = vars.value.clickedColumnInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lyl+MAf8JESzmFuoNUElgA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TableSortByDirection = "Ascending"
model.variables.tableSortByDirectionVar = "Ascending";
} else {
// different column
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AgFEsedbqE6UYhSFH3rjSg", callContext.id);
// TableSortByField = ClickedColumn
model.variables.tableSortByFieldVar = vars.value.clickedColumnInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AgFEsedbqE6UYhSFH3rjSg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TableSortByDirection = "Ascending"
model.variables.tableSortByDirectionVar = "Ascending";
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L7UAIKaS+kq2mtdIINJn8g", callContext.id);
// Request.orderByField = TableSortByField
model.variables.requestIn.orderByFieldAttr = model.variables.tableSortByFieldVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L7UAIKaS+kq2mtdIINJn8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Request.orderByDirection = TableSortByDirection
model.variables.requestIn.orderByDirectionAttr = model.variables.tableSortByDirectionVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L7UAIKaS+kq2mtdIINJn8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// StartIndex = 0
model.variables.startIndexVar = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L7UAIKaS+kq2mtdIINJn8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Request.pageNumber = StartIndex
model.variables.requestIn.pageNumberAttr = model.variables.startIndexVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SpVOYY9JL0mS05dEmPjkmg", callContext.id);
// Refresh Query: Search
var result = controller.search$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0J9sjEbiI0Wi4uLcwrAdUA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:cHQ_KD5KOUORgI1UOHXqmQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:cHQ_KD5KOUORgI1UOHXqmQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchResults.OnSort$vars", [{
name: "ClickedColumn",
attrName: "clickedColumnInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onClose_RestrictedPopUp$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClose_RestrictedPopUp");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:52NiLE+jIEOhq9Uv1lN_7Q:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.52NiLE+jIEOhq9Uv1lN_7Q:RsMmfPsj_B4nilEhCYeHQw", "PHICore", "OnClose_RestrictedPopUp", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mY_xI+_At06aW_ljHf0Vsw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q8+8M7HXwU2D4+kU4vY1LQ", callContext.id);
// IsDisplayRestrictedPopup = False
model.variables.isDisplayRestrictedPopupVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QLVPWIo33UK3O6FZVFEkkA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:52NiLE+jIEOhq9Uv1lN_7Q", callContext.id);
}

};
Controller.prototype._onClick_PolicyNumber$Action = function (policyNumberIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_PolicyNumber");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchResults.OnClick_PolicyNumber$vars"))());
vars.value.policyNumberInLocal = policyNumberIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:70TOXQrps0SSpdroePmD1A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.70TOXQrps0SSpdroePmD1A:X6Qwhqf_7EnJwM6eAKfZLw", "PHICore", "OnClick_PolicyNumber", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RXLRhPLxxUK3VMajTPwLrw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// ViewPolicyAndMember
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OHVGNq10EES2LCJPIQPlQw", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jPo_TCcB3kuYC2ojoIuFjA", callContext.id);
// Destination: /PHICore/Policy
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Policy", {
PolicyNumber: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.textToInteger(vars.value.policyNumberInLocal), OS.Types.Integer)
}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sw49BE0CMEqjgHFSTaOfnQ", callContext.id);
// Trigger Event: Event_RestrictedScreen
return controller.event_RestrictedScreen$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GdBPzEaNRUSHoa7hvhZnOA", callContext.id);
});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:70TOXQrps0SSpdroePmD1A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:70TOXQrps0SSpdroePmD1A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchResults.OnClick_PolicyNumber$vars", [{
name: "PolicyNumber",
attrName: "policyNumberInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onNavigate_Pagination$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnNavigate_Pagination");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.SearchResults.OnNavigate_Pagination$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:fy7+d1Mr4k6rzYxFaHATbg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.fy7+d1Mr4k6rzYxFaHATbg:ZZl6Wo_ZH05nYPWwklWB1g", "PHICore", "OnNavigate_Pagination", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EzQTTSpNw0C0b7QBBEleGQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t6glivNLY0Os6K7SVN3Vrg", callContext.id);
// StartIndex = NewStartIndex
model.variables.startIndexVar = vars.value.newStartIndexInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t6glivNLY0Os6K7SVN3Vrg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Request.pageNumber = Trunc + 1
model.variables.requestIn.pageNumberAttr = OS.BuiltinFunctions.decimalToInteger(OS.BuiltinFunctions.trunc(OS.BuiltinFunctions.trunc(OS.BuiltinFunctions.integerToDecimal(model.variables.startIndexVar).div(OS.BuiltinFunctions.integerToDecimal(model.variables.maxRecordsVar))).plus(OS.BuiltinFunctions.integerToDecimal(1))));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F0zKX+bxR0CxwjoI5CX_jA", callContext.id);
// Refresh Query: Search
var result = controller.search$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EI0p3HD6D0GN8etTz4W6NQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fy7+d1Mr4k6rzYxFaHATbg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fy7+d1Mr4k6rzYxFaHATbg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.SearchResults.OnNavigate_Pagination$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:nm3Gm3Ubu0G+GSRlJMwJew:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ/ClientActions.nm3Gm3Ubu0G+GSRlJMwJew:X3VtmUxHpksoNbiIM0pIuA", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0Ib62CcABkSA53pTfK1Eew", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UurLquHpT0e5mYS_HygzDQ", callContext.id);
// StartIndex = If
model.variables.startIndexVar = (((model.variables.requestIn.pageNumberAttr === 1)) ? (0) : (model.variables.startIndexVar));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:a7hFRYST9EaAJ8EqLzLTaw", callContext.id);
// Refresh Query: Search
var result = controller.search$DataActRefresh(callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tCygdBPjf0K08TCsQWrKJA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:nm3Gm3Ubu0G+GSRlJMwJew", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:nm3Gm3Ubu0G+GSRlJMwJew", callContext.id);
throw ex;

});
};

Controller.prototype.onClick_StakeholderName$Action = function (stakeholderIdIn, isAuthorizedIn, flags_ListIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_StakeholderName$Action, callContext, stakeholderIdIn, isAuthorizedIn, flags_ListIn);

};
Controller.prototype.onSort$Action = function (clickedColumnIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onSort$Action, callContext, clickedColumnIn);

};
Controller.prototype.onClose_RestrictedPopUp$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClose_RestrictedPopUp$Action, callContext);

};
Controller.prototype.onClick_PolicyNumber$Action = function (policyNumberIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_PolicyNumber$Action, callContext, policyNumberIn);

};
Controller.prototype.onNavigate_Pagination$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onNavigate_Pagination$Action, callContext, newStartIndexIn);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.event_RestrictedScreen$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:_BBGHzNptkWTArzHWtwWPQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree._BBGHzNptkWTArzHWtwWPQ:Ed02dLpRdYuFN_j+_FyJvg", "PHICore", "SearchResults", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_BBGHzNptkWTArzHWtwWPQ", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/SearchResults On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.SearchResults.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"+UKG2fmS5k2knap6B_oPwg": {
getter: function (varBag, idService) {
return varBag.vars.value.stakeholderIdInLocal;
},
dataType: OS.Types.Text
},
"xeitCtEOaEGA+pvgZxlCQA": {
getter: function (varBag, idService) {
return varBag.vars.value.isAuthorizedInLocal;
},
dataType: OS.Types.Boolean
},
"r9_SfbxwqUm9AeFhb3g4vg": {
getter: function (varBag, idService) {
return varBag.vars.value.flags_ListInLocal;
}
},
"TevAKnDnREeg0qmJn3n4Jw": {
getter: function (varBag, idService) {
return varBag.onValidate_FlagsVar.value;
}
},
"VtFRqGJ3jU2BAMrJ8LQ8vw": {
getter: function (varBag, idService) {
return varBag.getIndividualFlagsVar.value;
}
},
"DPJ4cxQ87UeD22cSA0Pfhw": {
getter: function (varBag, idService) {
return varBag.vars.value.clickedColumnInLocal;
},
dataType: OS.Types.Text
},
"n8iCiTdpmka6b2WCjbkE9w": {
getter: function (varBag, idService) {
return varBag.vars.value.policyNumberInLocal;
},
dataType: OS.Types.Text
},
"GCVWgSCglE+GaPp0yuAg2w": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"DnhmoyJnxUGP1Y4MYizpyQ": {
getter: function (varBag, idService) {
return varBag.model.variables.startIndexVar;
},
dataType: OS.Types.Integer
},
"COVot3yue0C2q6SRVpzzHA": {
getter: function (varBag, idService) {
return varBag.model.variables.maxRecordsVar;
},
dataType: OS.Types.Integer
},
"VIaFb0rWLUKT0EWrezHitg": {
getter: function (varBag, idService) {
return varBag.model.variables.tableSortByFieldVar;
},
dataType: OS.Types.Text
},
"lCIJaH7toUGo0zTxjmmTog": {
getter: function (varBag, idService) {
return varBag.model.variables.tableSortByDirectionVar;
},
dataType: OS.Types.Text
},
"n_L8YXQqhkKV38MZAfv7Aw": {
getter: function (varBag, idService) {
return varBag.model.variables.isDisplayRestrictedPopupVar;
},
dataType: OS.Types.Boolean
},
"HrR9CzN5H0yOgpfZirSagw": {
getter: function (varBag, idService) {
return varBag.model.variables.requestIn;
}
},
"m62wepn1f0CoUVHsWI_23Q": {
getter: function (varBag, idService) {
return varBag.model.variables.isBasicSearchIn;
},
dataType: OS.Types.Boolean
},
"YBsw05OnGUGS8CUn2QYtDA": {
getter: function (varBag, idService) {
return varBag.model.variables.basicSearchQueryIn;
},
dataType: OS.Types.Text
},
"PTZHeG0S5ESaRJdFYDHVEQ": {
getter: function (varBag, idService) {
return varBag.model.variables.searchDataAct;
}
},
"lvjpu4nWFUW75EviMnm8OQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoFlagAccess"));
})(varBag.model, idService);
}
},
"zDCAV84PxkGO9XylM769zw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewProspectPermission"));
})(varBag.model, idService);
}
},
"8bAC2TKoSEyCRqQoJuVMqg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("StakeholderLink2"));
})(varBag.model, idService);
}
},
"WbZhtW3P5UunuTU_RjH+Bg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewPolicyMember"));
})(varBag.model, idService);
}
},
"xBWljIe5OkeqLaRxWpRyCA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("StakeholderLink"));
})(varBag.model, idService);
}
},
"dtDrjabYFU6WxnO2SpNhQQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewLead"));
})(varBag.model, idService);
}
},
"SXrZ7xEvkE2QInjLwbIpig": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("StakeholderLink3"));
})(varBag.model, idService);
}
},
"vuv6zGFL+EGRqeXeLOJSaQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Greater_than_20_chars"));
})(varBag.model, idService);
}
},
"911a+mvsgk6wC0vnf215Ag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("isAuthorised2"));
})(varBag.model, idService);
}
},
"0No+X6UaVUyE1taH2S6hvg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewPolicyMember2"));
})(varBag.model, idService);
}
},
"7Bt2dPeW50+IEVak8g9+nw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsEmpty2"));
})(varBag.model, idService);
}
},
"LAJP7jZtQ0mbaDuKHNLMBg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link_Policy_Disabled"));
})(varBag.model, idService);
}
},
"5oDCHmooWkmYTcuirqxyCw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("isAuthorised3"));
})(varBag.model, idService);
}
},
"zmlyUcMx2UmYXmxr2iFmBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsTableLoadingOrEmpty"));
})(varBag.model, idService);
}
},
"TQnHEbxZUkqWHTi7gBCWQA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsEmpty"));
})(varBag.model, idService);
}
},
"VOtFrehOZU+FBH4FWEcTBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"slpaEjDEwEq_JpEIE_1+hQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"KD0H9BcciUq5WOydIKgs1w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"b1sNbZNVc0KArhkCkPwzbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsLoading"));
})(varBag.model, idService);
}
},
"hZg_J5vMzkqaQwmbMCZagw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"ns2z9ARuG0iroDPCGsDD8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
