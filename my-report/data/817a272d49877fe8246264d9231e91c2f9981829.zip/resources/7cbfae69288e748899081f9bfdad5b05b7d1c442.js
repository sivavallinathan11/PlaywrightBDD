﻿define("SandBoxLogin.Exceptions.Login.mvc$model", ["OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FeedbackMessageClose", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI", "SandBoxLogin.model$TenantEspaceRecordList"], function (OutSystems, SandBoxLoginModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
var GetTenantsAggrRec = (function (_super) {
__extends(GetTenantsAggrRec, _super);
function GetTenantsAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTenantsAggrRec.RecordListType = SandBoxLoginModel.TenantEspaceRecordList;
GetTenantsAggrRec.init();
return GetTenantsAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Username", "usernameVar", "Username", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("Password", "passwordVar", "Password", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsExecuting", "isExecutingVar", "IsExecuting", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Remember", "rememberVar", "Remember", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SelectTenant", "selectTenantVar", "SelectTenant", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("GetTenants", "getTenantsAggr", "getTenantsAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTenantsAggrRec());
}, true, GetTenantsAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
LoginForm: OS.Model.ValidationWidgetRecord,
Select_Tenant: OS.Model.ValidationWidgetRecord,
Input_UsernameVal: OS.Model.ValidationWidgetRecord,
Input_PasswordVal: OS.Model.ValidationWidgetRecord,
Checkbox1: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Exceptions.Login");
});
define("SandBoxLogin.Exceptions.Login.mvc$view", ["OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.controller", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "SandBoxLogin.Exceptions.Login.mvc$model", "SandBoxLogin.Exceptions.Login.mvc$controller", "SandBoxLogin.clientVariables", "PHICore_TH.Layouts.LayoutBlank.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Adaptive.Columns2.mvc$view", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "OutSystemsUI.Utilities.ButtonLoading.mvc$view", "OutSystemsUI.controller$FeedbackMessageClose", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI", "SandBoxLogin.model$TenantEspaceRecordList"], function (OutSystems, SandBoxLoginModel, SandBoxLoginController, OutSystemsUIController, React, OSView, SandBoxLogin_Exceptions_Login_mvc_model, SandBoxLogin_Exceptions_Login_mvc_controller, SandBoxLoginClientVariables, PHICore_TH_Layouts_LayoutBlank_mvc_view, OSWidgets, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Exceptions.Login";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/PHICore_TH.HambsComp_th.css", "css/PHICore_TH.HAMBS_THEME.css", "css/SandBoxLogin.SandBoxLogin.css", "css/SandBoxLogin.SandBoxLogin.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [PHICore_TH_Layouts_LayoutBlank_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return SandBoxLogin_Exceptions_Login_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return SandBoxLogin_Exceptions_Login_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Login";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(PHICore_TH_Layouts_LayoutBlank_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "login-screen",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
style: "login-form",
_idProps: {
service: idService,
name: "LoginForm"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: center;"
},
style: "login-logo",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: center;"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Image, {
extendedProperties: {
alt: "",
style: "height: 80px;"
},
image: OS.Navigation.VersionedURL.getVersionedUrl("img/SandBoxLogin.hambsnotagline.png"),
type: /*Static*/ 0,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "login-inputs margin-top-m",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Select_Tenant",
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Select Tenant"), React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
dropdownMode: /*Text*/ 0,
enabled: true,
labels: function (elem) {
return elem.tenantAttr.nameAttr;
},
list: model.variables.getTenantsAggr.listOut,
mandatory: false,
style: "dropdown",
values: function (elem) {
return elem.tenantAttr.idAttr;
},
variable: model.createVariable(OS.Types.Integer, model.variables.selectTenantVar, function (value) {
model.variables.selectTenantVar = value;
}),
_idProps: {
service: idService,
name: "Select_Tenant"
},
_widgetRecordProvider: widgetsRecordProvider,
list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTenantsAggr.dataFetchStatusAttr),
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_UsernameVal",
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Username"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: true,
maxLength: 250,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.usernameVar, function (value) {
model.variables.usernameVar = value;
}),
_idProps: {
service: idService,
name: "Input_UsernameVal"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Input_PasswordVal",
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Password"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Password*/ 1,
mandatory: true,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.passwordVar, function (value) {
model.variables.passwordVar = value;
}),
_idProps: {
service: idService,
name: "Input_PasswordVal"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-m",
visible: false,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
_idProps: {
service: idService,
uuid: "17",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
_idProps: {
service: idService,
uuid: "18",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
enabled: true,
extendedProperties: {
"aria-label": "Remember me the password"
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.rememberVar, function (value) {
model.variables.rememberVar = value;
}),
_idProps: {
service: idService,
name: "Checkbox1"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
style: "font-size-s margin-left-s",
targetWidget: "Checkbox1",
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Remember me")];
})
},
_dependencies: [asPrimitiveValue(model.variables.rememberVar)]
})];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "Forgot password? Click here to recover it"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Exceptions/Login/Link OnClick");
controller.forgotPassword$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Forgot password?"))];
})
},
_dependencies: [asPrimitiveValue(model.variables.rememberVar)]
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "login-button margin-top-m",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_ButtonLoading_mvc_view, {
inputs: {
ExtendedClass: "full-width",
IsLoading: model.variables.isExecutingVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("LoginForm")
},
_idProps: {
service: idService,
uuid: "24",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: true,
onClick: function () {
_this.validateWidget(idService.getId("LoginForm"));
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Exceptions/Login/Button OnClick");
return controller.login$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "osui-btn-loading__spinner-animation",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}), "Login")];
})
},
_dependencies: []
}))))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isExecutingVar), asPrimitiveValue(model.variables.rememberVar), asPrimitiveValue(model.variables.passwordVar), asPrimitiveValue(model.variables.usernameVar), asPrimitiveValue(model.variables.getTenantsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTenantsAggr.listOut), asPrimitiveValue(model.variables.selectTenantVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("SandBoxLogin.Exceptions.Login.mvc$controller", ["OutSystems/ClientRuntime/Main", "SandBoxLogin.model", "SandBoxLogin.controller", "OutSystemsUI.controller", "SandBoxLogin.languageResources", "SandBoxLogin.clientVariables", "SandBoxLogin.Exceptions.Login.mvc$debugger", "SandBoxLogin.Exceptions.controller", "OutSystemsUI.controller$FeedbackMessageClose", "SandBoxLogin.referencesHealth", "SandBoxLogin.referencesHealth$OutSystemsUI", "SandBoxLogin.model$TenantEspaceRecordList"], function (OutSystems, SandBoxLoginModel, SandBoxLoginController, OutSystemsUIController, SandBoxLoginLanguageResources, SandBoxLoginClientVariables, SandBoxLogin_Exceptions_Login_mvc_Debugger, SandBoxLogin_ExceptionsController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getTenants$AggrRefresh: 0
};
this.dataFetchDependentsGraph = {
getTenants$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions
Controller.prototype.doLogin$ServerAction = function (usernameIn, passwordIn, rememberLoginIn, tenantIdIn, callContext) {
var controller = this.controller;
var inputs = {
Username: OS.DataConversion.ServerDataConverter.to(usernameIn, OS.Types.Text),
Password: OS.DataConversion.ServerDataConverter.to(passwordIn, OS.Types.Text),
RememberLogin: OS.DataConversion.ServerDataConverter.to(rememberLoginIn, OS.Types.Boolean),
TenantId: OS.DataConversion.ServerDataConverter.to(tenantIdIn, OS.Types.Integer)
};
return controller.callServerAction("DoLogin", "screenservices/SandBoxLogin/Exceptions/Login/ActionDoLogin", "6u4Qff_wAiWbw2+nr1rIhA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("SandBoxLogin.Exceptions.Login$ActionDoLogin"))();
executeServerActionResult.redirectURLOut = OS.DataConversion.ServerDataConverter.from(outputs.RedirectURL, OS.Types.Text);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("SandBoxLogin.Exceptions.Login$ActionDoLogin", [{
name: "RedirectURL",
attrName: "redirectURLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);

// Aggregates and Data Actions
Controller.prototype.getTenants$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:kNg07iXtY0a605WyzayayQ:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.O7EJxtyRHU+blDfVTbmT5Q/ScreenDataSets.kNg07iXtY0a605WyzayayQ:AylDDcaR+qeLNymZc+gzrQ", "SandBoxLogin", "GetTenants", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Exceptions/Login/GetTenants");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTenants", "screenservices/SandBoxLogin/Exceptions/Login/ScreenDataSetGetTenants", "0RVhhk6LUd_EHJRgIJBf4Q", maxRecords, startIndex, function (b) {
model.variables.getTenantsAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTenantsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTenantsAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, undefined, false);

}, function () {
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:kNg07iXtY0a605WyzayayQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTenants$AggrRefresh"];
// Client Actions
Controller.prototype._forgotPassword$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ForgotPassword");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:9DNGBiceOkO87LYGuAlU6A:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.O7EJxtyRHU+blDfVTbmT5Q/ClientActions.9DNGBiceOkO87LYGuAlU6A:SqdRAwHI0w1c0epPqbTNfQ", "SandBoxLogin", "ForgotPassword", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:ZY5bLTLJL0Ot2BdOFBfWsA", callContext.id);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:q5vp2UBeVkawCYoVh6AsmQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:9DNGBiceOkO87LYGuAlU6A", callContext.id);
}

};
Controller.prototype._login$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Login");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var doLoginVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.doLoginVar = doLoginVar;
OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:lfSfInDip0qOrPxfONESBg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.O7EJxtyRHU+blDfVTbmT5Q/ClientActions.lfSfInDip0qOrPxfONESBg:IxgTWn0urB5_55lJtoKbCQ", "SandBoxLogin", "Login", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:_KYk7MMpNkGmEbJ02ZhzWQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:D0yUa0ye0UWcrqSNNEqP0g", callContext.id);
// IsExecuting = True
model.variables.isExecutingVar = true;
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:kWDbFi2l_kOCO2Bel3lcag", callContext.id);
// Execute Action: DoLogin
model.flush();
return controller.doLogin$ServerAction(model.variables.usernameVar, model.variables.passwordVar, model.variables.rememberVar, model.variables.selectTenantVar, callContext).then(function (value) {
doLoginVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:rOrzsxHb_0+LmQQNKBh0dw", callContext.id);
// Execute Action: FeedbackMessageClose
OutSystemsUIController.default.feedbackMessageClose$Action(callContext);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:eQkxOzZcQEuxFrk_3sY5jw", callContext.id);
// Destination: /SandBoxLogin/
return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL(doLoginVar.value.redirectURLOut, {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Fade), callContext, true));
});
}).catch(function (ex) {
OS.Logger.trace("Login.Login", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:R3D5XLy4lUi54mMFu85pkg", callContext.id);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:I2tMqb6noE255CBhLc+ghw", callContext.id);
// IsExecuting = False
model.variables.isExecutingVar = false;
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:yXiG_3fnQEqgcF+xosmyAg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(allExceptionsVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:wbnoQlCsmEOexX+11JIhwQ", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:lfSfInDip0qOrPxfONESBg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:lfSfInDip0qOrPxfONESBg", callContext.id);
throw ex;

});
};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:RFFEu5ktdE69D6J3mZdkfA:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.O7EJxtyRHU+blDfVTbmT5Q/ClientActions.RFFEu5ktdE69D6J3mZdkfA:kMF+d7yPV4b8yQxb8zT99w", "SandBoxLogin", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:CeHrsNtIQESxUFVXXai7Zg", callContext.id);
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:l41R9B4Rj0KYUyHgWs1NcQ", callContext.id);
// IsExecuting = False
model.variables.isExecutingVar = false;
OutSystemsDebugger.handleBreakpoint("co5gvpLb+0OcEkR2f6h33Q:Xpw_LIJ5lEO68RrtLIzxfA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:RFFEu5ktdE69D6J3mZdkfA", callContext.id);
}

};

Controller.prototype.forgotPassword$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._forgotPassword$Action, callContext);

};
Controller.prototype.login$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._login$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:B4kRGvrnOEmQonA8ir4Pyg:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg:i8FAYHPys1Ez7yHsVEanKw", "SandBoxLogin", "Exceptions", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("co5gvpLb+0OcEkR2f6h33Q:O7EJxtyRHU+blDfVTbmT5Q:/NRWebFlows.B4kRGvrnOEmQonA8ir4Pyg/NodesShownInESpaceTree.O7EJxtyRHU+blDfVTbmT5Q:w60ehGoVXII1xCV7NuM4yg", "SandBoxLogin", "Login", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:O7EJxtyRHU+blDfVTbmT5Q", callContext.id);
OutSystemsDebugger.pop("co5gvpLb+0OcEkR2f6h33Q:B4kRGvrnOEmQonA8ir4Pyg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Exceptions/Login On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return SandBoxLogin_ExceptionsController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return SandBoxLoginController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, SandBoxLoginLanguageResources);
});

define("SandBoxLogin.Exceptions.Login.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"R3D5XLy4lUi54mMFu85pkg": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"kWDbFi2l_kOCO2Bel3lcag": {
getter: function (varBag, idService) {
return varBag.doLoginVar.value;
}
},
"zchyF4JLdEqT+6FUtCbL0g": {
getter: function (varBag, idService) {
return varBag.model.variables.usernameVar;
},
dataType: OS.Types.Text
},
"AheBypiX0kuzoJs2V1cAgQ": {
getter: function (varBag, idService) {
return varBag.model.variables.passwordVar;
},
dataType: OS.Types.Text
},
"_Y0eVZaEBkqVBmSQH89q0A": {
getter: function (varBag, idService) {
return varBag.model.variables.isExecutingVar;
},
dataType: OS.Types.Boolean
},
"q3gCE9+KykWFR_WtLf5cJw": {
getter: function (varBag, idService) {
return varBag.model.variables.rememberVar;
},
dataType: OS.Types.Boolean
},
"10am8eaeSEuLSMRc+z06wA": {
getter: function (varBag, idService) {
return varBag.model.variables.selectTenantVar;
},
dataType: OS.Types.Integer
},
"kNg07iXtY0a605WyzayayQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getTenantsAggr;
}
},
"zFcRlK_VdUS0Kj+LWzXJOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"SszQF0ordk6Ql+4Vnqe3NQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("LoginForm"));
})(varBag.model, idService);
}
},
"Uj5q+eOFK0OqjzSrUmoyrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Select_Tenant"));
})(varBag.model, idService);
}
},
"eVbS1rLZGk2mg4mMOuEEGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_UsernameVal"));
})(varBag.model, idService);
}
},
"r1bbo9nl3UKhIyzGpeLTKQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_PasswordVal"));
})(varBag.model, idService);
}
},
"A6KCsQHrP0aIXLGXInlW6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"Bz0EGw4XFEWwFAc10vrZnA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"IzFNF2aQU0K4q+p02a+lrg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Checkbox1"));
})(varBag.model, idService);
}
},
"relusiFwb0OYybspcepWGQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"wsxt2zn3JEGYCUkHufJeMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
