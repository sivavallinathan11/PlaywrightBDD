﻿define("PHICore.MainFlow.controller", ["exports", "OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "PHICore.Exceptions.controller", "PHICore.clientVariables", "PHICore.MainFlow.controller$debugger"], function (exports, OutSystems, PHICoreModel, PHICoreController, PHICore_ExceptionsController, PHICoreClientVariables, PHICore_MainFlow_Controller_debugger) {
var OS = OutSystems.Internal;
var PHICore_MainFlowController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var varBag = {};
var controller = this.controller;
OS.Logger.trace("MainFlow", OS.Exceptions.getMessage(ex), ex.name);
return PHICore_ExceptionsController.default.handleError(ex, callContext);


};
return Controller;
})(OS.Controller.BaseController);
PHICore_MainFlowController.default = new Controller();
});

define("PHICore.MainFlow.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
});
