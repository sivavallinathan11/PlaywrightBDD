﻿define("PHICore.Stakeholder.Search.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "Common_CS.model", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$StakeholderSearchRec", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$KeyValuePairList", "OutSystemsUI.model$ErrorMessageRec", "PHICore.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$DatePickerClear", "Common_CW.controller$Check_SP_SearchRecord", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "Common_CW.controller$SetCurrentAsValidURL"], function (OutSystems, PHICoreModel, Common_CWController, OutSystemsUIModel, OutSystemsUIController, Common_CSModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("AdvancedSearch", "advancedSearchVar", "AdvancedSearch", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord());
}, false, PHICoreModel.TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord), 
this.attr("RequestFilter", "requestFilterVar", "RequestFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.StakeholderSearchRec());
}, false, PHICoreModel.StakeholderSearchRec), 
this.attr("ClearAdvancedSearch", "clearAdvancedSearchVar", "ClearAdvancedSearch", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextTextTextDatePhoneNumberLongIntegerIntegerIntegerIntegerRecord());
}, false, PHICoreModel.TextTextTextTextTextDatePhoneNumberLongIntegerIntegerIntegerIntegerRecord), 
this.attr("Status", "statusVar", "Status", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.KeyValuePairList());
}, false, PHICoreModel.KeyValuePairList), 
this.attr("isInitialLoad", "isInitialLoadVar", "isInitialLoad", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("ShowPopup_NewStakeholder", "showPopup_NewStakeholderVar", "ShowPopup_NewStakeholder", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Type", "typeVar", "Type", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.KeyValuePairList());
}, false, PHICoreModel.KeyValuePairList), 
this.attr("For", "forIn", "For", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_forInDataFetchStatus", "_forInDataFetchStatus", "_forInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Form1: OS.Model.ValidationWidgetRecord,
Input_Name: OS.Model.ValidationWidgetRecord,
Input_DateOfBirth: OS.Model.ValidationWidgetRecord,
Input_Address: OS.Model.ValidationWidgetRecord,
Dropdown_Status2: OS.Model.ValidationWidgetRecord,
Input_Phone: OS.Model.ValidationWidgetRecord,
Input_Email: OS.Model.ValidationWidgetRecord,
Input_PolicyNumber: OS.Model.ValidationWidgetRecord,
Input_MemberNumber: OS.Model.ValidationWidgetRecord,
Input_CommunicationId: OS.Model.ValidationWidgetRecord,
Input_QuoteNumber: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("For" in inputs) {
this.variables.forIn = OS.DataConversion.ServerDataConverter.from(inputs.For, OS.Types.Text);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Stakeholder.Search");
});
define("PHICore.Stakeholder.Search.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "Common_CS.model", "react", "OutSystems/ReactView/Main", "PHICore.Stakeholder.Search.mvc$model", "PHICore.Stakeholder.Search.mvc$controller", "PHICore.clientVariables", "PHICore.Common_Widgets.BaseLayout.mvc$view", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.GlobalSearchBox.mvc$view", "OutSystemsUI.Adaptive.Columns2.mvc$view", "OutSystemsUI.Interaction.InputWithIcon.mvc$view", "OutSystemsUI.Adaptive.Columns4.mvc$view", "OutSystemsUI.Content.Tooltip.mvc$view", "PHICore.Common_Widgets.SearchResults.mvc$view", "PHICore.Stakeholder.NewStakeholder_Popup.mvc$view", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$StakeholderSearchRec", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$KeyValuePairList", "OutSystemsUI.model$ErrorMessageRec", "PHICore.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$DatePickerClear", "Common_CW.controller$Check_SP_SearchRecord", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "Common_CW.controller$SetCurrentAsValidURL"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, OutSystemsUIController, Common_CSModel, React, OSView, PHICore_Stakeholder_Search_mvc_model, PHICore_Stakeholder_Search_mvc_controller, PHICoreClientVariables, PHICore_Common_Widgets_BaseLayout_mvc_view, OSWidgets, Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Interaction_InputWithIcon_mvc_view, OutSystemsUI_Adaptive_Columns4_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, PHICore_Common_Widgets_SearchResults_mvc_view, PHICore_Stakeholder_NewStakeholder_Popup_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Stakeholder.Search";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/PHICore_TH.HambsComp_th.css", "css/PHICore_TH.HAMBS_THEME.css", "css/PHICore.HAMBSReactive.css", "css/PHICore.HAMBSReactive.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [PHICore_Common_Widgets_BaseLayout_mvc_view, Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Interaction_InputWithIcon_mvc_view, OutSystemsUI_Adaptive_Columns4_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, PHICore_Common_Widgets_SearchResults_mvc_view, PHICore_Stakeholder_NewStakeholder_Popup_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Stakeholder_Search_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Stakeholder_Search_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                var model = this.model;
                var controller = this.controller;
                var idService = this.idService;
                var validationService = controller.validationService;
                var callContext = controller.callContext();
                var asPrimitiveValue = View.asPrimitiveValue;
                var getTranslation = View.getTranslation;
                var _this = this;

                return "Search";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(PHICore_Common_Widgets_BaseLayout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
underHeaderTitle: new PlaceholderContent(function () {
return [$if(true, false, this, function () {
return [];
}, function () {
return [];
})];
}),
underHeaderAction: new PlaceholderContent(function () {
return [React.createElement(Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, {
inputs: {
isClearSearch: false
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
breadcrumbs: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: true,
style: "case-card margin-bottom-xl",
visible: PHICoreClientVariables.getisAdvanceSearch(),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "font-size-h4 font-semi-bold",
text: ["Advanced Search"],
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form margin-top-m",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "6",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "7",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Name",
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Stakeholder Name"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.advancedSearchVar.nameAttr, function (value) {
model.variables.advancedSearchVar.nameAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Name"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_DateOfBirth",
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Date of Birth"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
extendedProperties: {
max: "9999-12-31"
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Date*/ 4,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Date, model.variables.advancedSearchVar.dateOfBirthAttr, function (value) {
model.variables.advancedSearchVar.dateOfBirthAttr = value;
}),
_idProps: {
service: idService,
name: "Input_DateOfBirth"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.advancedSearchVar.dateOfBirthAttr), asPrimitiveValue(model.variables.advancedSearchVar.nameAttr)]
})];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Address",
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Address"), React.createElement(OutSystemsUI_Interaction_InputWithIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "16",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
input: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 0,
prompt: "Search",
style: "icon form-control",
variable: model.createVariable(OS.Types.Text, model.variables.advancedSearchVar.addressAttr, function (value) {
model.variables.advancedSearchVar.addressAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Address"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.advancedSearchVar.addressAttr)]
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.advancedSearchVar.addressAttr), asPrimitiveValue(model.variables.advancedSearchVar.dateOfBirthAttr), asPrimitiveValue(model.variables.advancedSearchVar.nameAttr)]
}), React.createElement(OutSystemsUI_Adaptive_Columns4_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "19",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "margin-top: 0px;"
},
visible: true,
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Dropdown_Status2",
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Stakeholder Type"), React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
dropdownMode: /*Text*/ 0,
emptyValue: " ",
enabled: true,
labels: function (elem) {
return elem.valueAttr;
},
list: model.variables.typeVar,
mandatory: false,
style: "dropdown",
values: function (elem) {
return elem.keyAttr;
},
variable: model.createVariable(OS.Types.LongInteger, model.variables.advancedSearchVar.stakeholderTypeAttr, function (value) {
model.variables.advancedSearchVar.stakeholderTypeAttr = value;
}),
_idProps: {
service: idService,
name: "Dropdown_Status2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
}))];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Phone",
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Phone Number"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Phone*/ 6,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.PhoneNumber, model.variables.advancedSearchVar.phoneAttr, function (value) {
model.variables.advancedSearchVar.phoneAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Phone"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column3: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Email",
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Email"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.advancedSearchVar.emailAttr, function (value) {
model.variables.advancedSearchVar.emailAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Email"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column4: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.typeVar), asPrimitiveValue(model.variables.advancedSearchVar.emailAttr), asPrimitiveValue(model.variables.advancedSearchVar.phoneAttr), asPrimitiveValue(model.variables.advancedSearchVar.stakeholderTypeAttr)]
}), React.createElement(OutSystemsUI_Adaptive_Columns4_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "29",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: PlaceholderContent.Empty,
column2: PlaceholderContent.Empty,
column3: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: false,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_PolicyNumber",
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Policy Number"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Number*/ 2,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Integer, model.variables.advancedSearchVar.policyNumberAttr, function (value) {
model.variables.advancedSearchVar.policyNumberAttr = value;
}),
_idProps: {
service: idService,
name: "Input_PolicyNumber"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column4: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: false,
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_MemberNumber",
_idProps: {
service: idService,
uuid: "34"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Member Number"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Number*/ 2,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Integer, model.variables.advancedSearchVar.memberNumberAttr, function (value) {
model.variables.advancedSearchVar.memberNumberAttr = value;
}),
_idProps: {
service: idService,
name: "Input_MemberNumber"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.advancedSearchVar.memberNumberAttr), asPrimitiveValue(model.variables.advancedSearchVar.policyNumberAttr)]
}), React.createElement(OutSystemsUI_Adaptive_Columns4_mvc_view, {
inputs: {
ExtendedClass: "align-bottom"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "36",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m text-align text-align-left",
visible: true,
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: true,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Button OnClick");
controller.search$Action(false, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Search"), React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Button OnClick");
controller.search$Action(true, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Clear"))];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "margin-top: 0px;"
},
visible: false,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_CommunicationId",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Communication ID"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.advancedSearchVar.communicationIdAttr, function (value) {
model.variables.advancedSearchVar.communicationIdAttr = value;
}),
_idProps: {
service: idService,
name: "Input_CommunicationId"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column3: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: false,
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_QuoteNumber",
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Quote Number"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Number*/ 2,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Integer, model.variables.advancedSearchVar.quoteNumberAttr, function (value) {
model.variables.advancedSearchVar.quoteNumberAttr = value;
}),
_idProps: {
service: idService,
name: "Input_QuoteNumber"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}),
column4: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.advancedSearchVar.quoteNumberAttr), asPrimitiveValue(model.variables.advancedSearchVar.communicationIdAttr)]
}))), $if(model.variables.isInitialLoadVar, true, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "display-flex justify-content-space-between",
visible: true,
_idProps: {
service: idService,
uuid: "46"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "font-size-h4 font-semi-bold",
text: ["Search Results"],
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right button-container",
visible: true,
_idProps: {
service: idService,
uuid: "49"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("Btn_CreateNewStakeholder.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_CreateNewStakeholder OnClick");
controller.onClick_NewStakeholderButton$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_CreateNewStakeholder"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Stakeholder")];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "51",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: false,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_CreateNewStakeholder2 OnClick");
controller.onClick_NewStakeholderButton$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_CreateNewStakeholder2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Stakeholder")];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "53"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
}), $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_1_CreateModifyQuote$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("Btn_CreateRateQuote.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_1_CreateModifyQuote$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_CreateRateQuote OnClick");
controller.onClick_NewRateQuote$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn margin-left-base width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_CreateRateQuote"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Rates Quote")];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "55",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: false,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_CreateRateQuote2 OnClick");
controller.onClick_NewRateQuote$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn margin-left-base width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_CreateRateQuote2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Rates Quote")];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
}), $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("Btn_NewPolicy.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_NewPolicy OnClick");
controller.onClick_NewPolicy$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn margin-left-base width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_NewPolicy"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Policy")];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "59",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: false,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/Search/Btn_NewPolicy2 OnClick");
controller.onClick_NewPolicy$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn margin-left-base width-auto",
visible: true,
_idProps: {
service: idService,
name: "Btn_NewPolicy2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "New Policy")];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-base",
visible: true,
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(PHICore_Common_Widgets_SearchResults_mvc_view, {
inputs: {
IsBasicSearch: !(PHICoreClientVariables.getisAdvanceSearch()),
Request: model.variables.requestFilterVar,
BasicSearchQuery: model.getCachedValue(idService.getId("bTgD+69hwk+6KRoWoBTjuw.BasicSearchQuery"), function () {
return OS.BuiltinFunctions.trim(model.variables.forIn);
}, function () {
return model.variables.forIn;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
event_RestrictedScreen$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchResults Event_RestrictedScreen");
controller.event_RestrictedScreen$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "63",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
})];
}),
title: PlaceholderContent.Empty,
actions: PlaceholderContent.Empty,
mainContent: new PlaceholderContent(function () {
return [React.createElement(PHICore_Stakeholder_NewStakeholder_Popup_mvc_view, {
inputs: {
ShowNewStakeholderPopup: model.variables.showPopup_NewStakeholderVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
toggle_NewStakeholder$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup Toggle_NewStakeholder");
controller.toggle_NewStakeholder$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "64",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
footer: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.showPopup_NewStakeholderVar), asPrimitiveValue(model.variables.forIn), asPrimitiveValue(model.variables.requestFilterVar), asPrimitiveValue(model.variables.isInitialLoadVar), asPrimitiveValue(model.variables.typeVar), asPrimitiveValue(model.variables.advancedSearchVar.quoteNumberAttr), asPrimitiveValue(model.variables.advancedSearchVar.communicationIdAttr), asPrimitiveValue(model.variables.advancedSearchVar.memberNumberAttr), asPrimitiveValue(model.variables.advancedSearchVar.policyNumberAttr), asPrimitiveValue(model.variables.advancedSearchVar.emailAttr), asPrimitiveValue(model.variables.advancedSearchVar.phoneAttr), asPrimitiveValue(model.variables.advancedSearchVar.stakeholderTypeAttr), asPrimitiveValue(model.variables.advancedSearchVar.addressAttr), asPrimitiveValue(model.variables.advancedSearchVar.dateOfBirthAttr), asPrimitiveValue(model.variables.advancedSearchVar.nameAttr), asPrimitiveValue(PHICoreClientVariables.getisAdvanceSearch())]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("PHICore.Stakeholder.Search.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "Common_CS.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Stakeholder.Search.mvc$debugger", "PHICore.Stakeholder.controller", "PHICore.Stakeholder.Search.mvc$controller.ClearValue_JS.JavaScript_ClearValueJS", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$StakeholderSearchRec", "PHICore.model$TextTextTextTextTextDatePhoneNumberLongIntegerIntegerIntegerIntegerRecord", "PHICore.model$KeyValuePairList", "OutSystemsUI.model$ErrorMessageRec", "PHICore.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$DatePickerClear", "Common_CW.controller$Check_SP_SearchRecord", "Common_CS.model$KeyValuePairRec", "PHICore.referencesHealth$Common_CS", "Common_CW.controller$SetCurrentAsValidURL"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, OutSystemsUIController, Common_CSModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Stakeholder_Search_mvc_Debugger, PHICore_StakeholderController, PHICore_Stakeholder_Search_mvc_controller_ClearValue_JS_JavaScript_ClearValueJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClick_NewRateQuote$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_NewRateQuote");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:JKCHCtMzi02Vd+aETfdZ1A:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.JKCHCtMzi02Vd+aETfdZ1A:csxOnTGktrMCja69na730Q", "PHICore", "OnClick_NewRateQuote", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JXrwWJRunEChwjW86512Xg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7e9Lt2O5QEiRz3yeDQCcBQ", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_1_CreateModifyQuote$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:voeQp6HAF0ma75DS4lQYjQ", callContext.id);
// Destination: /PHICore/Quote_Detail
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Quote_Detail", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:H_LDgR0ZLUaHKGeFAUQ5xg", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:JKCHCtMzi02Vd+aETfdZ1A", callContext.id);
}

};
Controller.prototype._search$Action = function (isClearIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Search");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Stakeholder.Search.Search$vars"))());
vars.value.isClearInLocal = isClearIn;
var datePickerClearVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.datePickerClearVar = datePickerClearVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:4cAeKalWA0iTQYPuM0AIxQ:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.4cAeKalWA0iTQYPuM0AIxQ:FOCk5wlnQsqucSklhOZzYQ", "PHICore", "Search", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TuXh7H2BSkiT7mRlsnrwjA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UDva7Y6EBkuMH2Pb+93_lg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mieSWTCiQEi6ZAgjw2RzDQ", callContext.id) && vars.value.isClearInLocal)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7msPqzlhVk2QBXio57H3tA", callContext.id) && model.variables.advancedSearchVar.dateOfBirthAttr.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:k+cxVcQy00S6qIynr+DiSQ", callContext.id);
// Execute Action: ClearValue_JS
controller._clearValue_JS$Action(idService.getId("Input_DateOfBirth"), callContext);
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pcwp7+_JQkuMROfgi4Smcw", callContext.id);
// AdvancedSearch = ClearAdvancedSearch
model.variables.advancedSearchVar = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.clearAdvancedSearchVar, new PHICoreModel.TextTextTextTextTextDatePhoneNumberLongIntegerLongIntegerIntegerIntegerIntegerRecord(), function (source, target) {
target.addressAttr = source.addressAttr;
target.communicationIdAttr = source.communicationIdAttr;
target.dateOfBirthAttr = source.dateOfBirthAttr;
target.emailAttr = source.emailAttr;
target.memberNumberAttr = source.memberNumberAttr;
target.nameAttr = source.nameAttr;
target.phoneAttr = source.phoneAttr;
target.policyNumberAttr = source.policyNumberAttr;
target.quoteNumberAttr = source.quoteNumberAttr;
target.searchAttr = source.searchAttr;
target.stakeholderStatusAttr = source.stakeholderStatusAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pcwp7+_JQkuMROfgi4Smcw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AdvancedSearch.StakeholderStatus = 1
model.variables.advancedSearchVar.stakeholderStatusAttr = OS.BuiltinFunctions.integerToLongInteger(1);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zJyiE2mNm0CNWHWtUqi6mw", callContext.id);
// Execute Action: DatePickerClear
datePickerClearVar.value = OutSystemsUIController.default.datePickerClear$Action(idService.getId("Input_DateOfBirth"), callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KdGZOOoWOk6agcqsVoK8PA", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:klh+uJuoOkGQFf3ONM3kkA", callContext.id) && ((((((OS.BuiltinFunctions.trim(model.variables.advancedSearchVar.addressAttr) === "") && model.variables.advancedSearchVar.dateOfBirthAttr.equals(OS.BuiltinFunctions.nullDate())) && (OS.BuiltinFunctions.trim(model.variables.advancedSearchVar.emailAttr) === "")) && (OS.BuiltinFunctions.trim(model.variables.advancedSearchVar.nameAttr) === "")) && (OS.BuiltinFunctions.trim(model.variables.advancedSearchVar.phoneAttr) === "")) && model.variables.advancedSearchVar.stakeholderStatusAttr.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier()))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WJa27duqk0S5shaQTSs9nA", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Please enter a search term", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uJ6EHvSgvEykqrx+Xh19MQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dixvu9z7BE+UUC0UpKKuZw", callContext.id);
// isInitialLoad = False
model.variables.isInitialLoadVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M_AByEpKF0Cul40mXUqeUA", callContext.id);
// RequestFilter = AdvancedSearch
model.variables.requestFilterVar = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.advancedSearchVar, new PHICoreModel.StakeholderSearchRec(), function (source, target) {
target.orderByFieldAttr = "Name";
target.orderByDirectionAttr = "Ascending";
target.pageNumberAttr = 1;
target.typeAttr = ((source.stakeholderTypeAttr.equals(OS.BuiltinFunctions.integerToLongInteger(1))) ? ("Lead") : (((source.stakeholderTypeAttr.equals(OS.BuiltinFunctions.integerToLongInteger(2))) ? ("Member") : (((source.stakeholderTypeAttr.equals(OS.BuiltinFunctions.integerToLongInteger(3))) ? ("Prospect") : (((source.stakeholderTypeAttr.equals(OS.BuiltinFunctions.integerToLongInteger(4))) ? ("NonInsured") : (""))))))));
target.searchAttr = source.nameAttr;
target.nameAttr = source.nameAttr;
target.dateOfBirthAttr = source.dateOfBirthAttr;
target.isActiveAttr = ((source.stakeholderStatusAttr.equals(OS.BuiltinFunctions.integerToLongInteger(1))) ? ("True") : (((source.stakeholderStatusAttr.equals(OS.BuiltinFunctions.integerToLongInteger(2))) ? ("False") : (""))));
target.phoneAttr = source.phoneAttr;
target.emailAttr = source.emailAttr;
target.addressAttr = source.addressAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:593x9EHBJ0Shp0Eia9U5wA", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4cAeKalWA0iTQYPuM0AIxQ", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Stakeholder.Search.Search$vars", [{
name: "isClear",
attrName: "isClearInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var check_SP_SearchRecordVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.check_SP_SearchRecordVar = check_SP_SearchRecordVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:D2PmLpP8ykiMp_7wR3e+aA:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.D2PmLpP8ykiMp_7wR3e+aA:Q4kHORkXAYSaDwILrgTHlQ", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:c6ABbu7mtk+jNufUv8V3nQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JPkvtSLsGU+NsVkDAgrqog", callContext.id);
// Execute Action: Check_SP_SearchRecord
check_SP_SearchRecordVar.value = Common_CWController.default.check_SP_SearchRecord$Action(callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jV2NeHcokEmF8GtqBdKOzw", callContext.id) && check_SP_SearchRecordVar.value.hasAccessOut)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:R5md0O574EiQYs_Yr1+LhQ", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.statusVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:05F0xDPzPkeEgwf8u0HJ7w", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.statusVar, function () {
var list = new PHICoreModel.KeyValuePairList();
list.pushAll([function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(1);
rec.valueAttr = "Active";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(2);
rec.valueAttr = "Inactive";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(3);
rec.valueAttr = "Both";
return rec;
}()]);
return list;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iqaedQhei0GlzLu9Yezx1A", callContext.id);
// Execute Action: ListAppendAll2
OS.SystemActions.listAppendAll(model.variables.typeVar, function () {
var list = new PHICoreModel.KeyValuePairList();
list.pushAll([function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(1);
rec.valueAttr = "Lead";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(2);
rec.valueAttr = "Member";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(3);
rec.valueAttr = "Prospect";
return rec;
}(), function () {
var rec = new Common_CSModel.KeyValuePairRec();
rec.keyAttr = OS.BuiltinFunctions.integerToLongInteger(4);
rec.valueAttr = "NonInsured";
return rec;
}()]);
return list;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id);
// isAdvanceSearch = Trim = ""
PHICoreClientVariables.setisAdvanceSearch((OS.BuiltinFunctions.trim(model.variables.forIn) === ""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// isInitialLoad = Trim = ""
model.variables.isInitialLoadVar = (OS.BuiltinFunctions.trim(model.variables.forIn) === "");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// RequestFilter.search = If
model.variables.requestFilterVar.searchAttr = (((OS.BuiltinFunctions.trim(model.variables.forIn) === "")) ? ("") : (model.variables.forIn));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// RequestFilter.orderByField = "Name"
model.variables.requestFilterVar.orderByFieldAttr = "Name";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// RequestFilter.orderByDirection = "Ascending"
model.variables.requestFilterVar.orderByDirectionAttr = "Ascending";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// RequestFilter.isActive = Trim = ""
model.variables.requestFilterVar.isActiveAttr = ((OS.BuiltinFunctions.trim(model.variables.forIn) === "") ? "True" : "False");
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// AdvancedSearch.StakeholderStatus = 1
model.variables.advancedSearchVar.stakeholderStatusAttr = OS.BuiltinFunctions.integerToLongInteger(1);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// RequestFilter.name = If
model.variables.requestFilterVar.nameAttr = (((((((model.variables.forIn) !== ("")) && (OS.BuiltinFunctions.textToIntegerValidate(model.variables.forIn) === false)) && (OS.BuiltinFunctions.textToDateValidate(model.variables.forIn) === false)) && (OS.BuiltinFunctions.emailAddressValidate(model.variables.forIn) === false))) ? (model.variables.forIn) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// RequestFilter.email = If
model.variables.requestFilterVar.emailAttr = ((OS.BuiltinFunctions.emailAddressValidate(model.variables.forIn)) ? (model.variables.forIn) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kocfLlfX00uheT3nNwk1rw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// RequestFilter.phone = If
model.variables.requestFilterVar.phoneAttr = (((((model.variables.forIn) !== ("")) && ((OS.BuiltinFunctions.textToIntegerValidate(model.variables.forIn) === true) || ((OS.BuiltinFunctions.index(model.variables.forIn, "+", 0, false, false)) !== (-1))))) ? (model.variables.forIn) : (""));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:R62uh_R9YES5qD813vfSDA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IsRtufHRIkONjuO1z9PR5Q", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:D2PmLpP8ykiMp_7wR3e+aA", callContext.id);
}

};
Controller.prototype._event_RestrictedScreen$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Event_RestrictedScreen");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:rP4lL4JC3kev+hFmWaSXrw:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.rP4lL4JC3kev+hFmWaSXrw:hZ+5fNZBZ2jkOPyty45PeA", "PHICore", "Event_RestrictedScreen", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vhuPbORttUqRaJUhUhdGLQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dx_ED1B+X0+S6HAjT++c5g", callContext.id);
// Destination: /PHICore_TH/InvalidPermissions
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore_TH", "InvalidPermissions", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:rP4lL4JC3kev+hFmWaSXrw", callContext.id);
}

};
Controller.prototype._clearValue_JS$Action = function (elementIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClearValue_JS");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Stakeholder.Search.ClearValue_JS$vars"))());
vars.value.elementIdInLocal = elementIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:oC0FMQwiDkKO97feGzeiEg:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.oC0FMQwiDkKO97feGzeiEg:I5wRjBkOjhbHIv74DNBFgw", "PHICore", "ClearValue_JS", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U5RldhuKzEmGhIBHNPPIqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YEncb+bpHU+e0JmqN5hgNQ", callContext.id);
controller.safeExecuteJSNode(PHICore_Stakeholder_Search_mvc_controller_ClearValue_JS_JavaScript_ClearValueJS, "JavaScript_ClearValue", "ClearValue_JS", {
ElementId: OS.DataConversion.JSNodeParamConverter.to(vars.value.elementIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pNC6UVVIUkmTCstVNY7NBw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:oC0FMQwiDkKO97feGzeiEg", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Stakeholder.Search.ClearValue_JS$vars", [{
name: "ElementId",
attrName: "elementIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._toggle_NewStakeholder$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_NewStakeholder");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ShncYXVAl0Sq0baL9wZYog:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.ShncYXVAl0Sq0baL9wZYog:nfgwhX_NmmUKF8paeOh13g", "PHICore", "Toggle_NewStakeholder", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LHmGLlfdmEK6UXAIRou0CA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JTV7u2+kOUu7eiI2wYkCpg", callContext.id);
// ShowPopup_NewStakeholder = notShowPopup_NewStakeholder
model.variables.showPopup_NewStakeholderVar = !(model.variables.showPopup_NewStakeholderVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:q6tDzb_FeUaUAm24T7v5JQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ShncYXVAl0Sq0baL9wZYog", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:hCQre5yUL0y_r1uKpB6vGg:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.hCQre5yUL0y_r1uKpB6vGg:lGbrzoKMwg2FHNdXXXGeOg", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pwDEQG07ckqqGYQ1iRzIZQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:55iC+X6W+UeqWRKGql6oMA", callContext.id);
// Execute Action: SetCurrentAsValidURL
Common_CWController.default.setCurrentAsValidURL$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h3EL3l1JTkKrRCxFnwWYdQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:hCQre5yUL0y_r1uKpB6vGg", callContext.id);
}

};
Controller.prototype._onClick_NewStakeholderButton$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_NewStakeholderButton");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:RGt5pein_UWv+BeBN+rHIw:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.RGt5pein_UWv+BeBN+rHIw:CiCxIcUP39ARWyKEWWjhmw", "PHICore", "OnClick_NewStakeholderButton", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QwUhlJrgQkCxPvomYpunRg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4yUI1htC2USQPeU3859Wbw", callContext.id);
// Execute Action: Toggle_NewStakeholder
controller._toggle_NewStakeholder$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qAEIZ_aGLU2sw1oMUhJXhQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:RGt5pein_UWv+BeBN+rHIw", callContext.id);
}

};
Controller.prototype._onClick_NewPolicy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_NewPolicy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:2RxJ1bhkP0CGl6rUxGB_QQ:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA/ClientActions.2RxJ1bhkP0CGl6rUxGB_QQ:KWzrn2djgyt5_qeBHW02Ww", "PHICore", "OnClick_NewPolicy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kZAjdXxauEawLowVVzb2hg", callContext.id);
// Has Permission
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l52Qr6I8KUyV56ve8caqGg", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ImWq69MwukCUUPV9VqAfcQ", callContext.id);
// Destination: /PHICore/PolicyDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "PolicyDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4i0mImU9LEO7taSnGWqXgA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:2RxJ1bhkP0CGl6rUxGB_QQ", callContext.id);
}

};

Controller.prototype.onClick_NewRateQuote$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_NewRateQuote$Action, callContext);

};
Controller.prototype.search$Action = function (isClearIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._search$Action, callContext, isClearIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.event_RestrictedScreen$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._event_RestrictedScreen$Action, callContext);

};
Controller.prototype.clearValue_JS$Action = function (elementIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clearValue_JS$Action, callContext, elementIdIn);

};
Controller.prototype.toggle_NewStakeholder$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_NewStakeholder$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onClick_NewStakeholderButton$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_NewStakeholderButton$Action, callContext);

};
Controller.prototype.onClick_NewPolicy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_NewPolicy$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:81TaMXbH30eFBDGHZnRU9A:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A:yTK3TFV6a6LgpT6Ltgqz_Q", "PHICore", "Stakeholder", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:sG8k+R00e0CXoFKB_ZkixA:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.sG8k+R00e0CXoFKB_ZkixA:6I+CeqY1RqiTWcU+zBevHg", "PHICore", "Search", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:sG8k+R00e0CXoFKB_ZkixA", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:81TaMXbH30eFBDGHZnRU9A", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/Search On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/Search On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return PHICore_StakeholderController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
OS.RolesInfo.checkRoles([PHICoreController.default.roles.SP_2_SearchRecord, PHICoreController.default.roles.SP_1_StaffPortal]);
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});
define("PHICore.Stakeholder.Search.mvc$controller.ClearValue_JS.JavaScript_ClearValueJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
document.querySelector("#" + $parameters.ElementId).value = "";
};
});

define("PHICore.Stakeholder.Search.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"stA9wDQEyk+PI5ElVoQz0w": {
getter: function (varBag, idService) {
return varBag.vars.value.isClearInLocal;
},
dataType: OS.Types.Boolean
},
"zJyiE2mNm0CNWHWtUqi6mw": {
getter: function (varBag, idService) {
return varBag.datePickerClearVar.value;
}
},
"JPkvtSLsGU+NsVkDAgrqog": {
getter: function (varBag, idService) {
return varBag.check_SP_SearchRecordVar.value;
}
},
"F3e6fwQTU0WqMBI4RAKcUg": {
getter: function (varBag, idService) {
return varBag.vars.value.elementIdInLocal;
},
dataType: OS.Types.Text
},
"YEncb+bpHU+e0JmqN5hgNQ": {
getter: function (varBag, idService) {
return varBag.javaScript_ClearValueJSResult.value;
}
},
"n1mWc4rD0UOKQvwhjAgsWQ": {
getter: function (varBag, idService) {
return varBag.model.variables.advancedSearchVar;
}
},
"+JzzkOx_AE2bLMPBRbgFPA": {
getter: function (varBag, idService) {
return varBag.model.variables.requestFilterVar;
}
},
"DHIEeOJz0UW5edYJ84Zskg": {
getter: function (varBag, idService) {
return varBag.model.variables.clearAdvancedSearchVar;
}
},
"w4pzKt1nAkiI_zCiVVHI8g": {
getter: function (varBag, idService) {
return varBag.model.variables.statusVar;
}
},
"mv+olqpKOkeTatoxIqHV6A": {
getter: function (varBag, idService) {
return varBag.model.variables.isInitialLoadVar;
},
dataType: OS.Types.Boolean
},
"U4bdSg2Lm0mDSA3dmqnKrA": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopup_NewStakeholderVar;
},
dataType: OS.Types.Boolean
},
"s0RpRIJx2k2joox3zIwjSg": {
getter: function (varBag, idService) {
return varBag.model.variables.typeVar;
}
},
"o5ppOpFM1U2ONFClSIHiAg": {
getter: function (varBag, idService) {
return varBag.model.variables.forIn;
},
dataType: OS.Types.Text
},
"oFAqGZ+GE0ymW9FRO0+A9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderTitle"));
})(varBag.model, idService);
}
},
"mik4KZcsVEiVfIBvVQ0xew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderAction"));
})(varBag.model, idService);
}
},
"gqmEfaz+Uk6cfCo3eR9UYA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Breadcrumbs"));
})(varBag.model, idService);
}
},
"QegTCR8AQ0m4c6JsRr8L8A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Form1"));
})(varBag.model, idService);
}
},
"rnPUME+FM0WAwJnx8MxQTQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"XTR8EQ+irEWaltAHd_K7bw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"Y5IUkDRQkkeaHokgjfP4Sw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Name"));
})(varBag.model, idService);
}
},
"ANEY4TDk4U24jKCK3pZOxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"4ibAxJZl8EuNWqXBtYkX8Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_DateOfBirth"));
})(varBag.model, idService);
}
},
"PIiGCkIyIkGieDnpaXnnDA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"dTlNQyOomkGIsjP7svQLPA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"GC8_zvp7PEae0MEE3YNR3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"sHql9rMIiUaDkKIpBLvrQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Address"));
})(varBag.model, idService);
}
},
"9ADWXNoYxkayQDYFTzD2xw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"AGCuNdbOukaT3+67RhWfjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_Status2"));
})(varBag.model, idService);
}
},
"OHL7QR+0pkaJR3KTPCMpbA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"7CcLntBkC0WcdN7GiEnETQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Phone"));
})(varBag.model, idService);
}
},
"KoARlyb6xEqV_627RrGSLg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column3"));
})(varBag.model, idService);
}
},
"wUd2jA7IM0uzX2ek1wXpPg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_Email"));
})(varBag.model, idService);
}
},
"paKFxbiWdk6tN9UrJwjfFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column4"));
})(varBag.model, idService);
}
},
"VwAgns9m8UeGg_veMbGWUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"WL1jD6WkaUONWCAnzshobg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"zi4ASi2L8E63gJ7H3BnKRQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column3"));
})(varBag.model, idService);
}
},
"ouCG8moSYE2Ph0sSNCCKVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_PolicyNumber"));
})(varBag.model, idService);
}
},
"jgzXvzpqRUuFAn3k9jLDQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column4"));
})(varBag.model, idService);
}
},
"+AThmauYZ0CeHOSCR4qf1g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_MemberNumber"));
})(varBag.model, idService);
}
},
"DETu0VAYt0KelMtrj00jkg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"mWvLkehcTUmqUUzod+D1YQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"ruqYXvG0pU238escBDJa6w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_CommunicationId"));
})(varBag.model, idService);
}
},
"bEV8QZ1lA0ieVh0tNUBUeA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column3"));
})(varBag.model, idService);
}
},
"yV27qqohg0W4rEdTgJGn9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_QuoteNumber"));
})(varBag.model, idService);
}
},
"jWQLsKcUjUSwUv1cD0S5aQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column4"));
})(varBag.model, idService);
}
},
"BKTuiHbbrUyEV691CjZz0g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("isInitialLoad2"));
})(varBag.model, idService);
}
},
"Pw3Q48s14kOoa2i7idQ5Jg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Check_SM_1_AddModifyReopenCancelLead"));
})(varBag.model, idService);
}
},
"navUV5+tYkS8moVgB4W7fA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_CreateNewStakeholder"));
})(varBag.model, idService);
}
},
"ZZWWDl3rJkCJkctTJQhS5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"449RS0bYY0eJFPzTSn7CjQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_CreateNewStakeholder2"));
})(varBag.model, idService);
}
},
"S56SZNqweUml2JQzTc1JiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"bzkM7sIz5kqjWM93hSvZiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Check_PM_1_CreateModifyQuote"));
})(varBag.model, idService);
}
},
"rA8gdTZV1EuxDWtAD0AQDQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_CreateRateQuote"));
})(varBag.model, idService);
}
},
"N8wXl8VisEy0JZC2TOlSQw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"WDX7HETCAkinnHErkoN+qA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_CreateRateQuote2"));
})(varBag.model, idService);
}
},
"I_d_+wtK80myMRN59n_vww": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"MNdQpzOLNU6p1HEwgRKMTw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Check_PM_3_CreatePolicyAndMember"));
})(varBag.model, idService);
}
},
"s6+o1pXqgkWMIJNNOyG7LQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_NewPolicy"));
})(varBag.model, idService);
}
},
"gULRkmwKd0WYU0VlSI6YNQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"gs6UQI2jDk+CQ7g4JNDO3Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_NewPolicy2"));
})(varBag.model, idService);
}
},
"5ftfeszsRUiOqgcWPiyV+A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"JHYFTQAbiU2Y3wCfy8VGqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"rbzUnkHSp0qEi1KRg_ghag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"YPhSlneAg0O_mr1LGzTSVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContent"));
})(varBag.model, idService);
}
},
"ExbX3wooW0ikUtZjytVWBg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
