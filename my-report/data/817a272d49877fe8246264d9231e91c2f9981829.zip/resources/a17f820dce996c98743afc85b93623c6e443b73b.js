﻿define("PHICore.clientVariables", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
var ClientVariables = (function (_super) {
var clientVarsService;
function ClientVariables() {
clientVarsService = OS.Injector.resolve(OS.ServiceNames.ClientVariablesService);
}
ClientVariables.prototype.getNotificationListSort = function () {
return clientVarsService.getVariable("NotificationListSort", "PHICore", OS.Types.Text, "CreatedOn DESC");
};
ClientVariables.prototype.setNotificationListSort = function (value) {
return clientVarsService.setVariable("NotificationListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getCauseAuditListSort = function () {
return clientVarsService.getVariable("CauseAuditListSort", "PHICore", OS.Types.Text, "{AuditLog}.[PerformedAt] DESC");
};
ClientVariables.prototype.setCauseAuditListSort = function (value) {
return clientVarsService.setVariable("CauseAuditListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getLastURL = function () {
return clientVarsService.getVariable("LastURL", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setLastURL = function (value) {
return clientVarsService.setVariable("LastURL", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderAuditListSort = function () {
return clientVarsService.getVariable("StakeholderAuditListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderAuditListSort = function (value) {
return clientVarsService.setVariable("StakeholderAuditListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyCasesListSort = function () {
return clientVarsService.getVariable("MyCasesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setMyCasesListSort = function (value) {
return clientVarsService.setVariable("MyCasesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyCases_SearchFilter = function () {
return clientVarsService.getVariable("MyCases_SearchFilter", "PHICore", OS.Types.Text, "{\"SearchFilter\":{\"Status\":[{\"Name\":\"New\",\"Value\":\"2\"},{\"Name\":\"In Progress\",\"Value\":\"3\"},{\"Name\":\"On Hold\",\"Value\":\"4\"},{\"Name\":\"Cancelled\",\"Value\":\"6\"}]},\"JoinedFilter\":{\"Status\":\"2#3#4#6\"}}");
};
ClientVariables.prototype.setMyCases_SearchFilter = function (value) {
return clientVarsService.setVariable("MyCases_SearchFilter", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderNoteListSortDirection = function () {
return clientVarsService.getVariable("StakeholderNoteListSortDirection", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderNoteListSortDirection = function (value) {
return clientVarsService.setVariable("StakeholderNoteListSortDirection", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyApprovalCasesListSort = function () {
return clientVarsService.getVariable("MyApprovalCasesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setMyApprovalCasesListSort = function (value) {
return clientVarsService.setVariable("MyApprovalCasesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderAssociatedPoliciesListSort = function () {
return clientVarsService.getVariable("StakeholderAssociatedPoliciesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderAssociatedPoliciesListSort = function (value) {
return clientVarsService.setVariable("StakeholderAssociatedPoliciesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyTeamCasesListSort = function () {
return clientVarsService.getVariable("MyTeamCasesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setMyTeamCasesListSort = function (value) {
return clientVarsService.setVariable("MyTeamCasesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getisAdvanceSearch = function () {
return clientVarsService.getVariable("isAdvanceSearch", "PHICore", OS.Types.Boolean, false);
};
ClientVariables.prototype.setisAdvanceSearch = function (value) {
return clientVarsService.setVariable("isAdvanceSearch", "PHICore", OS.Types.Boolean, value);
};
ClientVariables.prototype.getStakeholderInteractionHistoryListSortDirection = function () {
return clientVarsService.getVariable("StakeholderInteractionHistoryListSortDirection", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderInteractionHistoryListSortDirection = function (value) {
return clientVarsService.setVariable("StakeholderInteractionHistoryListSortDirection", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyTeamCases_SearchFIlter = function () {
return clientVarsService.getVariable("MyTeamCases_SearchFIlter", "PHICore", OS.Types.Text, "{\"SearchFilter\":{\"Status\":[{\"Name\":\"New\",\"Value\":\"2\"},{\"Name\":\"In Progress\",\"Value\":\"3\"},{\"Name\":\"On Hold\",\"Value\":\"4\"},{\"Name\":\"Cancelled\",\"Value\":\"6\"}]},\"JoinedFilter\":{\"Status\":\"2#3#4#6\"}}");
};
ClientVariables.prototype.setMyTeamCases_SearchFIlter = function (value) {
return clientVarsService.setVariable("MyTeamCases_SearchFIlter", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderCoverListSort = function () {
return clientVarsService.getVariable("StakeholderCoverListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderCoverListSort = function (value) {
return clientVarsService.setVariable("StakeholderCoverListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getMyApproval_SearchFilter = function () {
return clientVarsService.getVariable("MyApproval_SearchFilter", "PHICore", OS.Types.Text, "{\"SearchFilter\":{\"Status\":[{\"Name\":\"New\",\"Value\":\"2\"},{\"Name\":\"In Progress\",\"Value\":\"3\"},{\"Name\":\"On Hold\",\"Value\":\"4\"},{\"Name\":\"Cancelled\",\"Value\":\"6\"}]},\"JoinedFilter\":{\"Status\":\"2#3#4#6\"}}");
};
ClientVariables.prototype.setMyApproval_SearchFilter = function (value) {
return clientVarsService.setVariable("MyApproval_SearchFilter", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderNotesListSort = function () {
return clientVarsService.getVariable("StakeholderNotesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderNotesListSort = function (value) {
return clientVarsService.setVariable("StakeholderNotesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderNoteListSort = function () {
return clientVarsService.getVariable("StakeholderNoteListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderNoteListSort = function (value) {
return clientVarsService.setVariable("StakeholderNoteListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderInteractionHistoryListSort = function () {
return clientVarsService.getVariable("StakeholderInteractionHistoryListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderInteractionHistoryListSort = function (value) {
return clientVarsService.setVariable("StakeholderInteractionHistoryListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderAuditListSortDirection = function () {
return clientVarsService.getVariable("StakeholderAuditListSortDirection", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderAuditListSortDirection = function (value) {
return clientVarsService.setVariable("StakeholderAuditListSortDirection", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getStakeholderQuotesListSort = function () {
return clientVarsService.getVariable("StakeholderQuotesListSort", "PHICore", OS.Types.Text);
};
ClientVariables.prototype.setStakeholderQuotesListSort = function (value) {
return clientVarsService.setVariable("StakeholderQuotesListSort", "PHICore", OS.Types.Text, value);
};
ClientVariables.prototype.getPolicyProgress_Int = function () {
return clientVarsService.getVariable("PolicyProgress_Int", "PHICore", OS.Types.Integer);
};
ClientVariables.prototype.setPolicyProgress_Int = function (value) {
return clientVarsService.setVariable("PolicyProgress_Int", "PHICore", OS.Types.Integer, value);
};
ClientVariables.prototype.serialize = function () {
return {
NotificationListSort: OS.DataConversion.ServerDataConverter.to(this.getNotificationListSort(), OS.Types.Text),
CauseAuditListSort: OS.DataConversion.ServerDataConverter.to(this.getCauseAuditListSort(), OS.Types.Text),
LastURL: OS.DataConversion.ServerDataConverter.to(this.getLastURL(), OS.Types.Text),
StakeholderAuditListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderAuditListSort(), OS.Types.Text),
MyCasesListSort: OS.DataConversion.ServerDataConverter.to(this.getMyCasesListSort(), OS.Types.Text),
MyCases_SearchFilter: OS.DataConversion.ServerDataConverter.to(this.getMyCases_SearchFilter(), OS.Types.Text),
StakeholderNoteListSortDirection: OS.DataConversion.ServerDataConverter.to(this.getStakeholderNoteListSortDirection(), OS.Types.Text),
MyApprovalCasesListSort: OS.DataConversion.ServerDataConverter.to(this.getMyApprovalCasesListSort(), OS.Types.Text),
StakeholderAssociatedPoliciesListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderAssociatedPoliciesListSort(), OS.Types.Text),
MyTeamCasesListSort: OS.DataConversion.ServerDataConverter.to(this.getMyTeamCasesListSort(), OS.Types.Text),
isAdvanceSearch: OS.DataConversion.ServerDataConverter.to(this.getisAdvanceSearch(), OS.Types.Boolean),
StakeholderInteractionHistoryListSortDirection: OS.DataConversion.ServerDataConverter.to(this.getStakeholderInteractionHistoryListSortDirection(), OS.Types.Text),
MyTeamCases_SearchFIlter: OS.DataConversion.ServerDataConverter.to(this.getMyTeamCases_SearchFIlter(), OS.Types.Text),
StakeholderCoverListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderCoverListSort(), OS.Types.Text),
MyApproval_SearchFilter: OS.DataConversion.ServerDataConverter.to(this.getMyApproval_SearchFilter(), OS.Types.Text),
StakeholderNotesListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderNotesListSort(), OS.Types.Text),
StakeholderNoteListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderNoteListSort(), OS.Types.Text),
StakeholderInteractionHistoryListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderInteractionHistoryListSort(), OS.Types.Text),
StakeholderAuditListSortDirection: OS.DataConversion.ServerDataConverter.to(this.getStakeholderAuditListSortDirection(), OS.Types.Text),
StakeholderQuotesListSort: OS.DataConversion.ServerDataConverter.to(this.getStakeholderQuotesListSort(), OS.Types.Text),
PolicyProgress_Int: OS.DataConversion.ServerDataConverter.to(this.getPolicyProgress_Int(), OS.Types.Integer)
};
};
return ClientVariables;
})();
return new ClientVariables();
});
