﻿define("Common_CW.PHICore_CW.NextFocus.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model"], function (OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CurrentElement", "currentElementIn", "CurrentElement", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_currentElementInDataFetchStatus", "_currentElementInDataFetchStatus", "_currentElementInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("NextElement", "nextElementIn", "NextElement", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_nextElementInDataFetchStatus", "_nextElementInDataFetchStatus", "_nextElementInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CurrentWidgetId", "currentWidgetIdIn", "CurrentWidgetId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_currentWidgetIdInDataFetchStatus", "_currentWidgetIdInDataFetchStatus", "_currentWidgetIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("CurrentElement" in inputs) {
this.variables.currentElementIn = inputs.CurrentElement;
if("_currentElementInDataFetchStatus" in inputs) {
this.variables._currentElementInDataFetchStatus = inputs._currentElementInDataFetchStatus;
}

}

if("NextElement" in inputs) {
this.variables.nextElementIn = inputs.NextElement;
if("_nextElementInDataFetchStatus" in inputs) {
this.variables._nextElementInDataFetchStatus = inputs._nextElementInDataFetchStatus;
}

}

if("CurrentWidgetId" in inputs) {
this.variables.currentWidgetIdIn = inputs.CurrentWidgetId;
if("_currentWidgetIdInDataFetchStatus" in inputs) {
this.variables._currentWidgetIdInDataFetchStatus = inputs._currentWidgetIdInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.NextFocus");
});
define("Common_CW.PHICore_CW.NextFocus.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.NextFocus.mvc$model", "Common_CW.PHICore_CW.NextFocus.mvc$controller", "Common_CW.clientVariables"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_NextFocus_mvc_model, Common_CW_PHICore_CW_NextFocus_mvc_controller, Common_CWClientVariables) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.NextFocus";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NextFocus_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NextFocus_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.NextFocus.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.NextFocus.mvc$debugger", "Common_CW.PHICore_CW.NextFocus.mvc$controller.OnReady.JavaScript_AddKeyDownJS", "Common_CW.PHICore_CW.NextFocus.mvc$controller.OnDestroy.JavaScript_RemoveKeydownJS"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_NextFocus_mvc_Debugger, Common_CW_PHICore_CW_NextFocus_mvc_controller_OnReady_JavaScript_AddKeyDownJS, Common_CW_PHICore_CW_NextFocus_mvc_controller_OnDestroy_JavaScript_RemoveKeydownJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Aj6fXkOZjEKO27YEjnVazA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.8KO26YzCakCe9MgWW_72BQ/ClientActions.Aj6fXkOZjEKO27YEjnVazA:LALymmcexUWfcIjZdNJWug", "Common_CW", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:BVkPWXYyDUeFbZzvSAqTSA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bAwJ+4Gu3EC_+AcGjRSc2g", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_NextFocus_mvc_controller_OnReady_JavaScript_AddKeyDownJS, "JavaScript_AddKeyDown", "OnReady", {
VariableName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.replace(model.variables.currentWidgetIdIn, "-", ""), OS.Types.Text),
CurrentElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.currentElementIn, OS.Types.Text),
NextElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.nextElementIn, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Bjp2BfjPe0ic1cjD3Nukgw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Aj6fXkOZjEKO27YEjnVazA", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:6WGX47iKE0m0+jwRpJnfhA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.8KO26YzCakCe9MgWW_72BQ/ClientActions.6WGX47iKE0m0+jwRpJnfhA:h6LNW5vs7aeLNjshuV_MaA", "Common_CW", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jx8b2e2+9Ea8+T82Gy7igw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rFQDUdpavkSg8ABvLo4c2A", callContext.id);
controller.safeExecuteJSNode(Common_CW_PHICore_CW_NextFocus_mvc_controller_OnDestroy_JavaScript_RemoveKeydownJS, "JavaScript_RemoveKeydown", "OnDestroy", {
VariableName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.replace(model.variables.currentWidgetIdIn, "-", ""), OS.Types.Text),
CurrentElement: OS.DataConversion.JSNodeParamConverter.to(model.variables.currentElementIn, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FR1Lzq46i0+wMbo7xyZS5g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:6WGX47iKE0m0+jwRpJnfhA", callContext.id);
}

};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8KO26YzCakCe9MgWW_72BQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.8KO26YzCakCe9MgWW_72BQ:FtNiAzyr87FOWlEp1xQzpQ", "Common_CW", "NextFocus", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8KO26YzCakCe9MgWW_72BQ", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/NextFocus On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/NextFocus On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});
define("Common_CW.PHICore_CW.NextFocus.mvc$controller.OnReady.JavaScript_AddKeyDownJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window[$parameters.VariableName] = function(event) {
    var e = event || window.event; // for trans-browser compatibility
    var charCode = e.which || e.keyCode;

    if (!e.shiftKey && charCode === 9) { // Check for Tab key without Shift
        try {
            var nextElement = document.querySelector($parameters.NextElement);
            if (nextElement) {
                nextElement.focus();
                e.preventDefault();
            }
        } catch (error) {
            console.error('Error handling Tab key:', error);
        }
    }

    return false;
};

let element = document.querySelector($parameters.CurrentElement);
if (element !== null) {
    element.addEventListener("keydown", window[$parameters.VariableName], false);
}

};
});
define("Common_CW.PHICore_CW.NextFocus.mvc$controller.OnDestroy.JavaScript_RemoveKeydownJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
let element = document.querySelector($parameters.CurrentElement);
if (element !== null) {
    try {
        // Make sure $parameters.VariableName holds a valid function reference
        const eventHandler = window[$parameters.VariableName];
        if (typeof eventHandler === 'function') {
            element.removeEventListener("keydown", eventHandler, false);
        } else {
            console.error(`Function ${$parameters.VariableName} is not defined.`);
        }
    } catch (error) {
        console.error('Error removing event listener:', error);
    }
}

};
});

define("Common_CW.PHICore_CW.NextFocus.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"bAwJ+4Gu3EC_+AcGjRSc2g": {
getter: function (varBag, idService) {
return varBag.javaScript_AddKeyDownJSResult.value;
}
},
"rFQDUdpavkSg8ABvLo4c2A": {
getter: function (varBag, idService) {
return varBag.javaScript_RemoveKeydownJSResult.value;
}
},
"WwJENRMjIE64TUrgcX14dw": {
getter: function (varBag, idService) {
return varBag.model.variables.currentElementIn;
},
dataType: OS.Types.Text
},
"4w8uXWf+wU+NE+aCNNNDEg": {
getter: function (varBag, idService) {
return varBag.model.variables.nextElementIn;
},
dataType: OS.Types.Text
},
"bYMa9EaoW0qyKTPoNHD8mg": {
getter: function (varBag, idService) {
return varBag.model.variables.currentWidgetIdIn;
},
dataType: OS.Types.Text
},
"e9nV0veWV0imBdEmbyz5lg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("False2"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
