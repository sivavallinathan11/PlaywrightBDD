﻿define("PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "OutSystemsUI.Utilities.AlignCenter.mvc$model", "OutSystemsUI.Interaction.InputWithIcon.mvc$model", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$model", "OutSystemsUI.Adaptive.Columns2.mvc$model", "OutSystemsUI.Utilities.ButtonLoading.mvc$model", "Common_CW.PHICore_CW.PreviousFocus.mvc$model", "Common_CW.PHICore_CW.NextFocus.mvc$model", "Common_CW.controller$Check_SP_AssignCaseTeam", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_AssignCasePerson", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.model$UserIdentifierTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$Set_Focus", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$TeamIdentifierRecordList", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$UserIdentifierTextRecordList", "PHICore.model$TeamRecordList"], function (OutSystems, PHICoreModel, Common_CWController, OutSystemsUIModel, Common_CSModel, OutSystemsUI_Utilities_AlignCenter_mvcModel, OutSystemsUI_Interaction_InputWithIcon_mvcModel, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvcModel, OutSystemsUI_Adaptive_Columns2_mvcModel, OutSystemsUI_Utilities_ButtonLoading_mvcModel, Common_CW_PHICore_CW_PreviousFocus_mvcModel, Common_CW_PHICore_CW_NextFocus_mvcModel) {
var OS = OutSystems.Internal;
var GetAssigneeAggrRec = (function (_super) {
__extends(GetAssigneeAggrRec, _super);
function GetAssigneeAggrRec(defaults) {
_super.apply(this, arguments);
}
GetAssigneeAggrRec.RecordListType = PHICoreModel.UserIdentifierTextRecordList;
GetAssigneeAggrRec.init();
return GetAssigneeAggrRec;
})(OS.Model.AggregateRecord);
var GetTeamAggrRec = (function (_super) {
__extends(GetTeamAggrRec, _super);
function GetTeamAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamAggrRec.RecordListType = PHICoreModel.TeamRecordList;
GetTeamAggrRec.init();
return GetTeamAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("AssigneeUserId", "assigneeUserIdVar", "AssigneeUserId", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.UserIdentifierTextRecord());
}, false, PHICoreModel.UserIdentifierTextRecord), 
this.attr("TeamId", "teamIdVar", "TeamId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, false), 
this.attr("TeamSearchKeyword", "teamSearchKeywordVar", "TeamSearchKeyword", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("AssigneeSearchKeyword", "assigneeSearchKeywordVar", "AssigneeSearchKeyword", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsSaving", "isSavingVar", "IsSaving", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("TeamIsValid", "teamIsValidVar", "TeamIsValid", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("TeamsCombined", "teamsCombinedVar", "TeamsCombined", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsPopupOpen", "isPopupOpenIn", "IsPopupOpen", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isPopupOpenInDataFetchStatus", "_isPopupOpenInDataFetchStatus", "_isPopupOpenInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SelectedCasesList", "selectedCasesListIn", "SelectedCasesList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseIdentifier1RecordList());
}, false, PHICoreModel.CaseIdentifier1RecordList), 
this.attr("_selectedCasesListInDataFetchStatus", "_selectedCasesListInDataFetchStatus", "_selectedCasesListInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetAssignee", "getAssigneeAggr", "getAssigneeAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetAssigneeAggrRec());
}, true, GetAssigneeAggrRec), 
this.attr("GetTeam", "getTeamAggr", "getTeamAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamAggrRec());
}, true, GetTeamAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((((((OutSystemsUI_Utilities_AlignCenter_mvcModel.hasValidationWidgets || OutSystemsUI_Interaction_InputWithIcon_mvcModel.hasValidationWidgets) || LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvcModel.hasValidationWidgets) || OutSystemsUI_Adaptive_Columns2_mvcModel.hasValidationWidgets) || OutSystemsUI_Utilities_ButtonLoading_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_PreviousFocus_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_NextFocus_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("IsPopupOpen" in inputs) {
this.variables.isPopupOpenIn = inputs.IsPopupOpen;
if("_isPopupOpenInDataFetchStatus" in inputs) {
this.variables._isPopupOpenInDataFetchStatus = inputs._isPopupOpenInDataFetchStatus;
}

}

if("SelectedCasesList" in inputs) {
this.variables.selectedCasesListIn = inputs.SelectedCasesList;
if("_selectedCasesListInDataFetchStatus" in inputs) {
this.variables._selectedCasesListInDataFetchStatus = inputs._selectedCasesListInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.AssignCaseTeam_Popup");
});
define("PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$model", "PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "OutSystemsUI.Interaction.InputWithIcon.mvc$view", "LazyDropdownSearch.LazyDropdownSearch.LazyDropdownSearch.mvc$view", "OutSystemsUI.Adaptive.Columns2.mvc$view", "OutSystemsUI.Utilities.ButtonLoading.mvc$view", "Common_CW.PHICore_CW.PreviousFocus.mvc$view", "Common_CW.PHICore_CW.NextFocus.mvc$view", "Common_CW.controller$Check_SP_AssignCaseTeam", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_AssignCasePerson", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.model$UserIdentifierTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$Set_Focus", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$TeamIdentifierRecordList", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$UserIdentifierTextRecordList", "PHICore.model$TeamRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, Common_CSModel, React, OSView, PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_model, PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_controller, PHICoreClientVariables, OSWidgets, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Interaction_InputWithIcon_mvc_view, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.AssignCaseTeam_Popup";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Interaction_InputWithIcon_mvc_view, LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(model.variables.isPopupOpenIn, false, this, function () {
return [React.createElement(OSWidgets.Popup, {
showPopup: model.variables.isPopupOpenIn,
style: "popup-dialog show-overflow",
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
showPopup_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isPopupOpenInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
name: "Title"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width10"
},
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "heading4",
text: ["Assign Case"],
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
gridProperties: {
classes: "ThemeGrid_Width2 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": "close assign case",
role: "button"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/AssignCaseTeam_Popup/Link_CloseAssignCase OnClick");
return controller.onClickClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "Link_CloseAssignCase"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "padding-xs text-neutral-7",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}))))];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseTeam$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCasePerson$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
name: "Team"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Team", React.createElement(OSWidgets.Text, {
style: "text-red",
text: [" *"],
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OutSystemsUI_Interaction_InputWithIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
input: new PlaceholderContent(function () {
return [React.createElement(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_view, {
inputs: {
SearchResultValues: model.getCachedValue(idService.getId("TeamDropdown.SearchResultValues"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getTeamAggr.listOut, new PHICoreModel.DropdownItemList(), function (source, target) {
target.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.teamAttr.idAttr);
target.textAttr = source.teamAttr.nameAttr;
return target;
});
}, function () {
return model.variables.getTeamAggr.listOut;
}),
_searchResultValuesInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamAggr.dataFetchStatusAttr),
IsValid: model.variables.teamIsValidVar,
ErrorMessage: model.getCachedValue(idService.getId("TeamDropdown.ErrorMessage"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onItemSelected$Action: function (newValueIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch OnItemSelected");
return controller.lazyDropdownSearchOnTeamSelected$Action(newValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onFilterValueChanged$Action: function (filterValueIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch OnFilterValueChanged");
return controller.lazyDropdownSearchOnTeamFilterValueChanged$Action(filterValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "TeamDropdown",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.teamIsValidVar), asPrimitiveValue(model.variables.getTeamAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamAggr.listOut)]
}))];
}, function () {
return [];
}), $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCasePerson$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
name: "Assignee"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Assignee"), React.createElement(OutSystemsUI_Interaction_InputWithIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "18",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "search",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
input: new PlaceholderContent(function () {
return [React.createElement(LazyDropdownSearch_LazyDropdownSearch_LazyDropdownSearch_mvc_view, {
inputs: {
ErrorMessage: model.getCachedValue(idService.getId("AssigneeDropdown.ErrorMessage"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
}),
SearchResultValues: model.getCachedValue(idService.getId("AssigneeDropdown.SearchResultValues"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.getAssigneeAggr.listOut, new PHICoreModel.DropdownItemList(), function (source, target) {
target.valueAttr = (source.idAttr).toString();
target.textAttr = source.nameAttr;
return target;
});
}, function () {
return model.variables.getAssigneeAggr.listOut;
}),
_searchResultValuesInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getAssigneeAggr.dataFetchStatusAttr),
SelectedItem: model.getCachedValue(idService.getId("AssigneeDropdown.SelectedItem"), function () {
return OS.DataConversion.JSConversions.typeConvertRecord(model.variables.assigneeUserIdVar, new OutSystemsUIModel.DropdownItemRec(), function (source, target) {
target.valueAttr = (((source.userIdentifierAttr === OS.BuiltinFunctions.nullIdentifier())) ? ("") : ((source.userIdentifierAttr).toString()));
target.textAttr = source.nameAttr;
return target;
});
}, function () {
return model.variables.assigneeUserIdVar;
}),
IsValid: true,
Enabled: model.getCachedValue(idService.getId("AssigneeDropdown.Enabled"), function () {
return !(model.variables.teamIdVar.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())));
}, function () {
return model.variables.teamIdVar;
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onFilterValueChanged$Action: function (filterValueIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch OnFilterValueChanged");
return controller.lazyDropdownSearchOnUserFilterValueChanged$Action(filterValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
onItemSelected$Action: function (newValueIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "LazyDropdownSearch/LazyDropdownSearch OnItemSelected");
controller.lazyDropdownSearchOnUserSelected$Action(newValueIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "AssigneeDropdown",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.teamIdVar), asPrimitiveValue(model.variables.assigneeUserIdVar), asPrimitiveValue(model.variables.getAssigneeAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getAssigneeAggr.listOut)]
}))];
}, function () {
return [];
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-top-base",
visible: true,
_idProps: {
service: idService,
name: "Buttons"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "22",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/AssignCaseTeam_Popup/Button OnClick");
return controller.onClickClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Cancel")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
visible: true,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_ButtonLoading_mvc_view, {
inputs: {
ShowLabelOnLoading: true,
IsLoading: model.variables.isSavingVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "25",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
button: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/AssignCaseTeam_Popup/BtnAssign OnClick");
return controller.onClickSave$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "BtnAssign"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "osui-btn-loading__spinner-animation",
visible: true,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}), "Assign")];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.isSavingVar)]
})), React.createElement(Common_CW_PHICore_CW_PreviousFocus_mvc_view, {
inputs: {
CurrentElement: ("#" + idService.getId("Link_CloseAssignCase")),
CurrentWidgetId: idService.getId("PreviousFocus"),
PreviousElement: ("#" + idService.getId("BtnAssign"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "PreviousFocus",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_NextFocus_mvc_view, {
inputs: {
CurrentElement: ("#" + idService.getId("BtnAssign")),
NextElement: ("#" + idService.getId("Link_CloseAssignCase")),
CurrentWidgetId: idService.getId("NextFocus")
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "NextFocus",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$debugger", "Common_CW.controller$Check_SP_AssignCaseTeam", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_AssignCasePerson", "Common_CW.controller$GetRequiredFieldMsg", "PHICore.model$UserIdentifierTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$DropdownItemList", "OutSystemsUI.model$DropdownItemRec", "PHICore.referencesHealth$OutSystemsUI", "Common_CW.controller$Set_Focus", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "PHICore.model$TeamIdentifierRecordList", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore.model$UserIdentifierTextRecordList", "PHICore.model$TeamRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, Common_CSModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getAssignee$AggrRefresh: 0,
getTeam$AggrRefresh: 0
};
this.dataFetchDependentsGraph = {
getAssignee$AggrRefresh: [],
getTeam$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions
Controller.prototype.reassignCases$ServerAction = function (assigneeIn, teamIdIn, caseIDsIn, callContext) {
var controller = this.controller;
var inputs = {
Assignee: OS.DataConversion.ServerDataConverter.to(assigneeIn, OS.Types.Integer),
TeamId: OS.DataConversion.ServerDataConverter.to(teamIdIn, OS.Types.LongInteger),
CaseIDs: OS.DataConversion.ServerDataConverter.to(caseIDsIn, OS.Types.RecordList)
};
return controller.callServerAction("ReassignCases", "screenservices/PHICore/Common_Widgets/AssignCaseTeam_Popup/ServiceAPIReassignCases", "cj7e6TVw7pI6aEm2pHQPvg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup$ServiceAPIReassignCases"))();
executeServerActionResult.entityActionResultOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResult, Common_CSModel.EntityActionResultRec);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup$ServiceAPIReassignCases", [{
name: "EntityActionResult",
attrName: "entityActionResultOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}]);

// Aggregates and Data Actions
Controller.prototype.getAssignee$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:sIsSBfKXZ06Z0bcWRl3eJA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ScreenDataSets.sIsSBfKXZ06Z0bcWRl3eJA:6JlRTmJkp0u+2T01r2u57Q", "PHICore", "GetAssignee", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/AssignCaseTeam_Popup/GetAssignee");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetAssignee", "screenservices/PHICore/Common_Widgets/AssignCaseTeam_Popup/ScreenDataSetGetAssignee", "QkOdqWFwBbjba6a_8OPjOw", maxRecords, startIndex, function (b) {
model.variables.getAssigneeAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getAssigneeAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getAssigneeAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:sIsSBfKXZ06Z0bcWRl3eJA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getTeam$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:usw7zidR1EyHtibYwKCZJQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ScreenDataSets.usw7zidR1EyHtibYwKCZJQ:z5dvHSClnFTay5_ABY_Crw", "PHICore", "GetTeam", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/AssignCaseTeam_Popup/GetTeam");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeam", "screenservices/PHICore/Common_Widgets/AssignCaseTeam_Popup/ScreenDataSetGetTeam", "Qu4M8CXUAsNszn5hmOCERw", maxRecords, startIndex, function (b) {
model.variables.getTeamAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:usw7zidR1EyHtibYwKCZJQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getAssignee$AggrRefresh", "getTeam$AggrRefresh"];
// Client Actions
Controller.prototype._lazyDropdownSearchOnUserSelected$Action = function (newValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LazyDropdownSearchOnUserSelected");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnUserSelected$vars"))());
vars.value.newValueInLocal = newValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:T6gnBFxlnkGGLp9v330E3A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.T6gnBFxlnkGGLp9v330E3A:36de5lX_ri13aeJ+0tk03g", "PHICore", "LazyDropdownSearchOnUserSelected", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8WI1yUHCBEagVuIXzZIo9Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:T3VBywy9uUyXIongeRCKmw", callContext.id);
// AssigneeUserId.UserIdentifier = LongIntegerToIdentifier
model.variables.assigneeUserIdVar.userIdentifierAttr = OS.BuiltinFunctions.longIntegerToInteger(OS.BuiltinFunctions.longIntegerToIdentifier(OS.BuiltinFunctions.textToLongInteger(vars.value.newValueInLocal.valueAttr)));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:T3VBywy9uUyXIongeRCKmw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AssigneeUserId.Name = NewValue.Text
model.variables.assigneeUserIdVar.nameAttr = vars.value.newValueInLocal.textAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kgHcFwRO4E6c+1HA4Bo8OQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:T6gnBFxlnkGGLp9v330E3A", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnUserSelected$vars", [{
name: "NewValue",
attrName: "newValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.prototype._lazyDropdownSearchOnTeamSelected$Action = function (newValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LazyDropdownSearchOnTeamSelected");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnTeamSelected$vars"))());
vars.value.newValueInLocal = newValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:zruLF1AdA0yrCbSsOJLAVg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.zruLF1AdA0yrCbSsOJLAVg:n18JYS1_IRle9rp3rtJXMQ", "PHICore", "LazyDropdownSearchOnTeamSelected", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QFA45uF4ZE6hTQrL80r7cQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p70B81zmrEG3zE0ks7D2bQ", callContext.id) && !(model.variables.teamIdVar.equals(OS.BuiltinFunctions.longIntegerToIdentifier(OS.BuiltinFunctions.textToLongInteger(vars.value.newValueInLocal.valueAttr)))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+lKVAwH0l02s39FpAmp4wA", callContext.id);
// AssigneeUserId.UserIdentifier = NullIdentifier
model.variables.assigneeUserIdVar.userIdentifierAttr = OS.BuiltinFunctions.nullIdentifier();
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+lKVAwH0l02s39FpAmp4wA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AssigneeUserId.Name = ""
model.variables.assigneeUserIdVar.nameAttr = "";
}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kVWBqxiroUy89mK6nG3q1w", callContext.id);
// TeamId = LongIntegerToIdentifier
model.variables.teamIdVar = OS.BuiltinFunctions.longIntegerToIdentifier(OS.BuiltinFunctions.textToLongInteger(vars.value.newValueInLocal.valueAttr));
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y8YpTmO00kKFYj2U5hjCcA", callContext.id);
// Refresh Query: GetAssignee
var result = controller.getAssignee$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hhNnryGVp0exWjKMIsUphQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:zruLF1AdA0yrCbSsOJLAVg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:zruLF1AdA0yrCbSsOJLAVg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnTeamSelected$vars", [{
name: "NewValue",
attrName: "newValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DropdownItemRec();
},
complexType: OutSystemsUIModel.DropdownItemRec
}]);
Controller.prototype._lazyDropdownSearchOnUserFilterValueChanged$Action = function (filterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LazyDropdownSearchOnUserFilterValueChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnUserFilterValueChanged$vars"))());
vars.value.filterValueInLocal = filterValueIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Hfc4c7towUG_3lL9uw8NsA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.Hfc4c7towUG_3lL9uw8NsA:ZQkKWw1+5zcox9k4BC4t8A", "PHICore", "LazyDropdownSearchOnUserFilterValueChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ABTKyggcekKW+YeW53dYEQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JRxE8HC6p0yuc1oLt7Gk+A", callContext.id);
// AssigneeSearchKeyword = FilterValue
model.variables.assigneeSearchKeywordVar = vars.value.filterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jsq+TIJHsUyS7knFq2f8IA", callContext.id);
// Refresh Query: GetAssignee
var result = controller.getAssignee$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UkiimpC460aNT_6v5w1MDQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Hfc4c7towUG_3lL9uw8NsA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Hfc4c7towUG_3lL9uw8NsA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnUserFilterValueChanged$vars", [{
name: "FilterValue",
attrName: "filterValueInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._lazyDropdownSearchOnTeamFilterValueChanged$Action = function (filterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("LazyDropdownSearchOnTeamFilterValueChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnTeamFilterValueChanged$vars"))());
vars.value.filterValueInLocal = filterValueIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Aaa+oR1wvUaUWn7NQa6aVQ:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.Aaa+oR1wvUaUWn7NQa6aVQ:c805HLH5CFrJ6ab1WQZThw", "PHICore", "LazyDropdownSearchOnTeamFilterValueChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jtUnszKyaEKve3YUXakJqw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iQcxOlz120GOfBc3rtUPbw", callContext.id);
// TeamSearchKeyword = FilterValue
model.variables.teamSearchKeywordVar = vars.value.filterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:j0Ui96HNakytMFOnK2OXbw", callContext.id);
// Refresh Query: GetTeam
var result = controller.getTeam$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_DumEZSYsE2uJjSPp2dOUA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Aaa+oR1wvUaUWn7NQa6aVQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Aaa+oR1wvUaUWn7NQa6aVQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.LazyDropdownSearchOnTeamFilterValueChanged$vars", [{
name: "FilterValue",
attrName: "filterValueInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.OnParametersChanged$vars"))());
var listDistinctVar = new OS.DataTypes.VariableHolder();
var string_JoinVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listDistinctVar = listDistinctVar;
varBag.string_JoinVar = string_JoinVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:S+eEu_NWN0e2gK7i9JyJ4A:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.S+eEu_NWN0e2gK7i9JyJ4A:9rYdeyza3V9X2Dw8WrYRjQ", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bjMZX3jv_UKVjWSQ0Mucew", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GMmC3YoZG0yDrrHgE2lmoA", callContext.id);
// Execute Action: ListDistinct
listDistinctVar.value = OS.SystemActions.listDistinct(vars.value.teamId_ListVar, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eFC2A3q1hEqkxB0kXH2MlA", callContext.id);
// TeamId_List = ListDistinct.DistinctList
vars.value.teamId_ListVar = listDistinctVar.value.distinctListOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9BdN7+YCO0eRSpwVC62h5g", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(vars.value.teamId_ListVar, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.teamIdentifierListAttr);
return target;
}), ",", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+48np4mcSUm8xsrAVPZaFw", callContext.id);
// TeamsCombined = String_Join.Text
model.variables.teamsCombinedVar = string_JoinVar.value.textOut;
// Reset Assignee
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q_b9NKMoqk6XD8yI9UlkPQ", callContext.id);
// AssigneeUserId.Name = ""
model.variables.assigneeUserIdVar.nameAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q_b9NKMoqk6XD8yI9UlkPQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AssigneeUserId.UserIdentifier = NullIdentifier
model.variables.assigneeUserIdVar.userIdentifierAttr = OS.BuiltinFunctions.nullIdentifier();
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bVsPLjqWOESkPVJx3zhyhg", callContext.id);
// Refresh Query: GetAssignee
var result = controller.getAssignee$AggrRefresh(50, 0, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w7SZmkJxh0uvkr_cfRXZNQ", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.isPopupOpenIn, idService.getId("Link_CloseAssignCase"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1dOSQqKKOEim2ZrcywhMHQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:S+eEu_NWN0e2gK7i9JyJ4A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:S+eEu_NWN0e2gK7i9JyJ4A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.Common_Widgets.AssignCaseTeam_Popup.OnParametersChanged$vars", [{
name: "TeamId_List",
attrName: "teamId_ListVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.TeamIdentifierRecordList();
},
complexType: PHICoreModel.TeamIdentifierRecordList
}]);
Controller.prototype._onClickClose$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickClose");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:5MNj44tnS0q+x83E27cnAg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.5MNj44tnS0q+x83E27cnAg:rQGlpst+SGSoseV_N1uViQ", "PHICore", "OnClickClose", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:N5tSG8RlUEaEiZmVETQVjg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JHJQD0snPE2KMyHmyF8Blw", callContext.id);
// IsPopupOpen = False
model.variables.isPopupOpenIn = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JHJQD0snPE2KMyHmyF8Blw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TeamIsValid = True
model.variables.teamIsValidVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JHJQD0snPE2KMyHmyF8Blw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// TeamId = NullIdentifier
model.variables.teamIdVar = OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier());
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hlQiN4J3JUOcSZfq++IdpA", callContext.id);
// Trigger Event: EventAssignCase
return controller.eventAssignCase$Action(false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MSM246l_xE2vqYLGsQka0Q", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5MNj44tnS0q+x83E27cnAg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5MNj44tnS0q+x83E27cnAg", callContext.id);
throw ex;

});
};
Controller.prototype._onClickSave$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickSave");
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var reassignCasesVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.allExceptionsVar = allExceptionsVar;
varBag.reassignCasesVar = reassignCasesVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:5I858nxQL0qB0LuysMo7Rw:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q/ClientActions.5I858nxQL0qB0LuysMo7Rw:7Vjz5fXrG3Xj5CWWeuQvUg", "PHICore", "OnClickSave", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:E3Nqtl7R7U2VA4xBn7k4FA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nrBjWC9jjUi+gRaLx0FhBA", callContext.id) && model.variables.isSavingVar)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7IF6pJ_i9kyHPEtSOyOdUw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7fSkCkjJy0+yoN7BCG1zAw", callContext.id);
// IsSaving = True
model.variables.isSavingVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7fSkCkjJy0+yoN7BCG1zAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TeamIsValid = True
model.variables.teamIsValidVar = true;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:glrvc2lit0SQaMLRFsweXw", callContext.id) && model.variables.teamIdVar.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier())))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zmTwRE9JvUCMdBKLaAh2qw", callContext.id);
// TeamIsValid = False
model.variables.teamIsValidVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zmTwRE9JvUCMdBKLaAh2qw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSaving = False
model.variables.isSavingVar = false;
}

return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9g4ol25kqEuIbRdcVw3wUw", callContext.id) && !(model.variables.teamIsValidVar))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sRCso18_tUua1Xd2Hw4Ltw", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QzMCDkcIx0SO59oTfwIwOg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Errors have occurred, please review highlighted fields", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:owY6Ju5f6U+D6GT6PaCdfw", callContext.id);
} else {
// Has Assign Case - Person and Assign Case - Team
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:x4miD4iay0mNPFEoZrPWVA", callContext.id) && (!(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCasePerson$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseTeam$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6t7H3_i+NkCCJAwNVTYXmw", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lIK1My6pak2HW9P82+mExw", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("You dont have access to perform this operation.", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CziSqroGLkiqh5O1xACusg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RXaRgyYM8UiUoHrZBz4U6A", callContext.id);
// Execute Action: ReassignCases
model.flush();
return controller.reassignCases$ServerAction(((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCasePerson$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)) ? (model.variables.assigneeUserIdVar.userIdentifierAttr) : (OS.BuiltinFunctions.nullIdentifier())), model.variables.teamIdVar, model.variables.selectedCasesListIn, callContext).then(function (value) {
reassignCasesVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:h0dDSNPSN0K3bhL5Qk182g", callContext.id) && !(reassignCasesVar.value.entityActionResultOut.isSuccessAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zB3t_XUGgke6IiUMlKenwQ", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(reassignCasesVar.value.entityActionResultOut.combinedEntityMessageTextAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nqzfQmZ3NUKUUjqZkSe+nA", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ag57894yrEySlw2y3HOtsQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JVPVAvmrDEq43QM_9XCOUg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Case successfully assigned", /*Success*/ 1);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PWl0wBBaK0OH3OO1u3ry8w", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SbbxBczFVEitVsZpDkJzrQ", callContext.id);
// Trigger Event: EventAssignCase
return controller.eventAssignCase$Action(true, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:2Gc97452+U6Fy_PnpUd7Fw", callContext.id);
});
}

});
});
}

});
}

});
}

});
}).catch(function (ex) {
OS.Logger.trace("AssignCaseTeam_Popup.OnClickSave", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:E8utLNkURkKoYzBfO6WbIA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gv7VeRQWUUOOdyPAq8c9mQ", callContext.id);
// IsSaving = False
model.variables.isSavingVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vR_BxDyfb02oxgAzN4PKUA", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5I858nxQL0qB0LuysMo7Rw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5I858nxQL0qB0LuysMo7Rw", callContext.id);
throw ex;

});
};

Controller.prototype.lazyDropdownSearchOnUserSelected$Action = function (newValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._lazyDropdownSearchOnUserSelected$Action, callContext, newValueIn);

};
Controller.prototype.lazyDropdownSearchOnTeamSelected$Action = function (newValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._lazyDropdownSearchOnTeamSelected$Action, callContext, newValueIn);

};
Controller.prototype.lazyDropdownSearchOnUserFilterValueChanged$Action = function (filterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._lazyDropdownSearchOnUserFilterValueChanged$Action, callContext, filterValueIn);

};
Controller.prototype.lazyDropdownSearchOnTeamFilterValueChanged$Action = function (filterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._lazyDropdownSearchOnTeamFilterValueChanged$Action, callContext, filterValueIn);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onClickClose$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickClose$Action, callContext);

};
Controller.prototype.onClickSave$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickSave$Action, callContext);

};
Controller.prototype.eventAssignCase$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:vTXEVzQlBkGABGq1DsOD0Q:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.vTXEVzQlBkGABGq1DsOD0Q:FaQH0ib0IiJZCdSUw1VFmg", "PHICore", "AssignCaseTeam_Popup", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:vTXEVzQlBkGABGq1DsOD0Q", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Common_Widgets/AssignCaseTeam_Popup On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"MarF7sY4PEm3UlLk_Y8ejw": {
getter: function (varBag, idService) {
return varBag.vars.value.newValueInLocal;
}
},
"cYaoHYJBZU+fpgLkv1Zd7Q": {
getter: function (varBag, idService) {
return varBag.vars.value.newValueInLocal;
}
},
"3rm12N1x9Ua5nppaRYre0w": {
getter: function (varBag, idService) {
return varBag.vars.value.filterValueInLocal;
},
dataType: OS.Types.Text
},
"fIBxsNiKT06cYZQCI0c92Q": {
getter: function (varBag, idService) {
return varBag.vars.value.filterValueInLocal;
},
dataType: OS.Types.Text
},
"D+MJbN+ZgECgaXjQDC4JSg": {
getter: function (varBag, idService) {
return varBag.vars.value.teamId_ListVar;
}
},
"GMmC3YoZG0yDrrHgE2lmoA": {
getter: function (varBag, idService) {
return varBag.listDistinctVar.value;
}
},
"9BdN7+YCO0eRSpwVC62h5g": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"E8utLNkURkKoYzBfO6WbIA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"RXaRgyYM8UiUoHrZBz4U6A": {
getter: function (varBag, idService) {
return varBag.reassignCasesVar.value;
}
},
"u4BGIOI86ki6d7pRy2jh4A": {
getter: function (varBag, idService) {
return varBag.model.variables.assigneeUserIdVar;
}
},
"N62M7Nr1_0OSFzQYE70T3A": {
getter: function (varBag, idService) {
return varBag.model.variables.teamIdVar;
},
dataType: OS.Types.LongInteger
},
"mshzjrDNjECOX1cl+LXDbg": {
getter: function (varBag, idService) {
return varBag.model.variables.teamSearchKeywordVar;
},
dataType: OS.Types.Text
},
"Q7dSqKp+iEWTkWrW44J4mQ": {
getter: function (varBag, idService) {
return varBag.model.variables.assigneeSearchKeywordVar;
},
dataType: OS.Types.Text
},
"fJwK0Kx1aEq_YGVXnVkzSQ": {
getter: function (varBag, idService) {
return varBag.model.variables.isSavingVar;
},
dataType: OS.Types.Boolean
},
"RfAsrXUd4EmWLDOgqBQIxw": {
getter: function (varBag, idService) {
return varBag.model.variables.teamIsValidVar;
},
dataType: OS.Types.Boolean
},
"NV8+plktPU+IQNmMumvrng": {
getter: function (varBag, idService) {
return varBag.model.variables.teamsCombinedVar;
},
dataType: OS.Types.Text
},
"oU66nBsI+Ea7A2_AReqTqw": {
getter: function (varBag, idService) {
return varBag.model.variables.isPopupOpenIn;
},
dataType: OS.Types.Boolean
},
"vivBdiikr0C5Y6qHvLb9nw": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedCasesListIn;
}
},
"sIsSBfKXZ06Z0bcWRl3eJA": {
getter: function (varBag, idService) {
return varBag.model.variables.getAssigneeAggr;
}
},
"usw7zidR1EyHtibYwKCZJQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamAggr;
}
},
"v6aXUaBuekyXG_JoUSXlvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"nMg35fIoe0+_EsCxRhNblg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"VVL5zRYrE0uLSUrwyMMAsA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link_CloseAssignCase"));
})(varBag.model, idService);
}
},
"hSIfnn_x2EWyeohR6frp4Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Vx2ivBQWPUOTe4RaWMAz8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Team"));
})(varBag.model, idService);
}
},
"96DZoJJrq0u1DATtB84g5w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"seQEqOoG5kqfqqPqdrbHHQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"IA6uuPMn+Ue3dWbmM1VbPw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamDropdown"));
})(varBag.model, idService);
}
},
"gXCtx+dTX0qE+QUQZkvq5A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Assignee"));
})(varBag.model, idService);
}
},
"7N2a80zAo0KyBsKf3YVSMA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Icon"));
})(varBag.model, idService);
}
},
"+3DfZHHmaU61R3flHel85A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
},
"M5YDcYYfj0OCPVHywNYwoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("AssigneeDropdown"));
})(varBag.model, idService);
}
},
"R5wbpekpwU+QL9zxMW+g2g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Buttons"));
})(varBag.model, idService);
}
},
"cirC8eKFv0CJ3VHNuScgOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"eUjklV6Gb0SDAWlWDAeXEA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"eEQnCkg+Q06aLnQ8DnUyuA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button"));
})(varBag.model, idService);
}
},
"OcAwM9JMQ0eP0pUdN5Eypg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("BtnAssign"));
})(varBag.model, idService);
}
},
"ZE5OzAULlE6GbJKLRXAuVQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreviousFocus"));
})(varBag.model, idService);
}
},
"UeaDoLTOekSGhUJkBvfgqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NextFocus"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
