﻿define("InputMaskReactive.InputMask.InputPatternMask.mvc$model", ["OutSystems/ClientRuntime/Main", "InputMaskReactive.model"], function (OutSystems, InputMaskReactiveModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IMaskObject", "iMaskObjectVar", "IMaskObject", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("InputOnFocusEventListener", "inputOnFocusEventListenerVar", "InputOnFocusEventListener", true, false, OS.Types.Object, function () {
return null;
}, false), 
this.attr("InputId", "inputIdIn", "InputId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_inputIdInDataFetchStatus", "_inputIdInDataFetchStatus", "_inputIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Pattern", "patternIn", "Pattern", true, false, OS.Types.Text, function () {
return "000000000";
}, false), 
this.attr("_patternInDataFetchStatus", "_patternInDataFetchStatus", "_patternInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsRegExp", "isRegExpIn", "IsRegExp", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isRegExpInDataFetchStatus", "_isRegExpInDataFetchStatus", "_isRegExpInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsLazy", "isLazyIn", "IsLazy", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_isLazyInDataFetchStatus", "_isLazyInDataFetchStatus", "_isLazyInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("InputId" in inputs) {
this.variables.inputIdIn = inputs.InputId;
if("_inputIdInDataFetchStatus" in inputs) {
this.variables._inputIdInDataFetchStatus = inputs._inputIdInDataFetchStatus;
}

}

if("Pattern" in inputs) {
this.variables.patternIn = inputs.Pattern;
if("_patternInDataFetchStatus" in inputs) {
this.variables._patternInDataFetchStatus = inputs._patternInDataFetchStatus;
}

}

if("IsRegExp" in inputs) {
this.variables.isRegExpIn = inputs.IsRegExp;
if("_isRegExpInDataFetchStatus" in inputs) {
this.variables._isRegExpInDataFetchStatus = inputs._isRegExpInDataFetchStatus;
}

}

if("IsLazy" in inputs) {
this.variables.isLazyIn = inputs.IsLazy;
if("_isLazyInDataFetchStatus" in inputs) {
this.variables._isLazyInDataFetchStatus = inputs._isLazyInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "InputMask.InputPatternMask");
});
define("InputMaskReactive.InputMask.InputPatternMask.mvc$view", ["OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.controller", "react", "OutSystems/ReactView/Main", "InputMaskReactive.InputMask.InputPatternMask.mvc$model", "InputMaskReactive.InputMask.InputPatternMask.mvc$controller"], function (OutSystems, InputMaskReactiveModel, InputMaskReactiveController, React, OSView, InputMaskReactive_InputMask_InputPatternMask_mvc_model, InputMaskReactive_InputMask_InputPatternMask_mvc_controller) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "InputMask.InputPatternMask";
        View.getCssDependencies = function() {
            return [];
        };
        View.getJsDependencies = function() {
            return ["scripts/InputMaskReactive.InputMaskScript.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return InputMaskReactive_InputMask_InputPatternMask_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return InputMaskReactive_InputMask_InputPatternMask_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("InputMaskReactive.InputMask.InputPatternMask.mvc$controller", ["OutSystems/ClientRuntime/Main", "InputMaskReactive.model", "InputMaskReactive.controller", "InputMaskReactive.languageResources", "InputMaskReactive.InputMask.InputPatternMask.mvc$debugger", "InputMaskReactive.InputMask.InputPatternMask.mvc$controller.InitIMask.RegisterInputMaskJS", "InputMaskReactive.InputMask.InputPatternMask.mvc$controller.InitIMask.DestroyExistingIMaskIfNecessaryJS"], function (OutSystems, InputMaskReactiveModel, InputMaskReactiveController, InputMaskReactiveLanguageResources, InputMaskReactive_InputMask_InputPatternMask_mvc_Debugger, InputMaskReactive_InputMask_InputPatternMask_mvc_controller_InitIMask_RegisterInputMaskJS, InputMaskReactive_InputMask_InputPatternMask_mvc_controller_InitIMask_DestroyExistingIMaskIfNecessaryJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:pTSnCAJxKUafkYLuGHHMfw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.vJjeHiKBREiH6rinScBvLA/ClientActions.pTSnCAJxKUafkYLuGHHMfw:x9SyBtMXMXz5wS58_1vOAQ", "InputMaskReactive", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:mvCwgxV35UmgNRgYc8qWdw", callContext.id);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:usk9UhyGJEuyGf2hW5vJRQ", callContext.id);
// Execute Action: InitIMask
controller._initIMask$Action(callContext);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:uByUSmHYaEqNQMkIdXeVTA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:pTSnCAJxKUafkYLuGHHMfw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:juUTTrBipU2XC0V0ONmnbw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.vJjeHiKBREiH6rinScBvLA/ClientActions.juUTTrBipU2XC0V0ONmnbw:HVqguNxjbuSamlSYz47ZvQ", "InputMaskReactive", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:gZ6RiL5Yr0G2JFm8vr3POw", callContext.id);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:CyHlfSLzZkW0PClChKH0RA", callContext.id);
// Execute Action: InitIMask
controller._initIMask$Action(callContext);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:eW9B0DWHRUSXSwVgagVo7g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:juUTTrBipU2XC0V0ONmnbw", callContext.id);
}

};
Controller.prototype._initIMask$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InitIMask");
callContext = controller.callContext(callContext);
var registerInputMaskJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.registerInputMaskJSResult = registerInputMaskJSResult;
try {OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:XgBI1JHKH0yewoO3Hizyyg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.vJjeHiKBREiH6rinScBvLA/ClientActions.XgBI1JHKH0yewoO3Hizyyg:G+H4pqgbaiwj1nFFzkbEmQ", "InputMaskReactive", "InitIMask", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:RB3RqxocKkaN0mirW9EytA", callContext.id);
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:DIM+_j61YU6hvHkdjKd59g", callContext.id);
controller.safeExecuteJSNode(InputMaskReactive_InputMask_InputPatternMask_mvc_controller_InitIMask_DestroyExistingIMaskIfNecessaryJS, "DestroyExistingIMaskIfNecessary", "InitIMask", {
IMaskObject: OS.DataConversion.JSNodeParamConverter.to(model.variables.iMaskObjectVar, OS.Types.Object),
InputId: OS.DataConversion.JSNodeParamConverter.to(model.variables.inputIdIn, OS.Types.Text),
InputOnFocusEventListener: OS.DataConversion.JSNodeParamConverter.to(model.variables.inputOnFocusEventListenerVar, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:algdt14ULUasDd5vugJJiQ", callContext.id);
// IMaskObject = NullObject
model.variables.iMaskObjectVar = OS.BuiltinFunctions.nullObject();
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:algdt14ULUasDd5vugJJiQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// InputOnFocusEventListener = NullObject
model.variables.inputOnFocusEventListenerVar = OS.BuiltinFunctions.nullObject();
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:2tBMeZ0ru0OJjSn3Z2B+jg", callContext.id);
registerInputMaskJSResult.value = controller.safeExecuteJSNode(InputMaskReactive_InputMask_InputPatternMask_mvc_controller_InitIMask_RegisterInputMaskJS, "RegisterInputMask", "InitIMask", {
IsLazy: OS.DataConversion.JSNodeParamConverter.to(model.variables.isLazyIn, OS.Types.Boolean),
IsRegExp: OS.DataConversion.JSNodeParamConverter.to(model.variables.isRegExpIn, OS.Types.Boolean),
InputId: OS.DataConversion.JSNodeParamConverter.to(model.variables.inputIdIn, OS.Types.Text),
Mask: OS.DataConversion.JSNodeParamConverter.to(model.variables.patternIn, OS.Types.Text),
IMaskObject: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object),
InputOnFocusEventListener: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("InputMaskReactive.InputMask.InputPatternMask.InitIMask$registerInputMaskJSResult"))();
jsNodeResult.iMaskObjectOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IMaskObject, OS.Types.Object);
jsNodeResult.inputOnFocusEventListenerOut = OS.DataConversion.JSNodeParamConverter.from($parameters.InputOnFocusEventListener, OS.Types.Object);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:FBV4PyLFfka7HtqFbqIArQ", callContext.id);
// IMaskObject = RegisterInputMask.IMaskObject
model.variables.iMaskObjectVar = registerInputMaskJSResult.value.iMaskObjectOut;
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:FBV4PyLFfka7HtqFbqIArQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// InputOnFocusEventListener = RegisterInputMask.InputOnFocusEventListener
model.variables.inputOnFocusEventListenerVar = registerInputMaskJSResult.value.inputOnFocusEventListenerOut;
OutSystemsDebugger.handleBreakpoint("4hxT94Jw+kWVDQ0ByGZD2A:csvMpbPmFUO9fL2aAeowUw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:XgBI1JHKH0yewoO3Hizyyg", callContext.id);
}

};
Controller.registerVariableGroupType("InputMaskReactive.InputMask.InputPatternMask.InitIMask$registerInputMaskJSResult", [{
name: "IMaskObject",
attrName: "iMaskObjectOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}, {
name: "InputOnFocusEventListener",
attrName: "inputOnFocusEventListenerOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.initIMask$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._initIMask$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:JdGK4GUa7vDkLp+Zd0ytFg", "InputMaskReactive", "InputMask", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("4hxT94Jw+kWVDQ0ByGZD2A:vJjeHiKBREiH6rinScBvLA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.vJjeHiKBREiH6rinScBvLA:rbRiI5eHLVlJHcNSoMLf8Q", "InputMaskReactive", "InputPatternMask", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:vJjeHiKBREiH6rinScBvLA", callContext.id);
OutSystemsDebugger.pop("4hxT94Jw+kWVDQ0ByGZD2A:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "InputMask/InputPatternMask On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "InputMask/InputPatternMask On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return InputMaskReactiveController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, InputMaskReactiveLanguageResources);
});
define("InputMaskReactive.InputMask.InputPatternMask.mvc$controller.InitIMask.RegisterInputMaskJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.InputId);

var maskOptions = {
  mask: $parameters.IsRegExp ? new RegExp($parameters.Mask) : $parameters.Mask,
  lazy: $parameters.IsLazy
};

var mask = new IMask(element, maskOptions);

$parameters.InputOnFocusEventListener = function() { mask.updateValue() };

element.addEventListener("focus", $parameters.InputOnFocusEventListener);

$parameters.IMaskObject = mask;

};
});
define("InputMaskReactive.InputMask.InputPatternMask.mvc$controller.InitIMask.DestroyExistingIMaskIfNecessaryJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if ($parameters.IMaskObject !== undefined && $parameters.IMaskObject !== null) {
    $parameters.IMaskObject.destroy();
}
var element = document.getElementById($parameters.InputId);
element.removeEventListener("focus", $parameters.InputOnFocusEventListener);
};
});

define("InputMaskReactive.InputMask.InputPatternMask.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"2tBMeZ0ru0OJjSn3Z2B+jg": {
getter: function (varBag, idService) {
return varBag.registerInputMaskJSResult.value;
}
},
"DIM+_j61YU6hvHkdjKd59g": {
getter: function (varBag, idService) {
return varBag.destroyExistingIMaskIfNecessaryJSResult.value;
}
},
"kw1oX1HsoEu50DFG3mcDcw": {
getter: function (varBag, idService) {
return varBag.model.variables.iMaskObjectVar;
},
dataType: OS.Types.Object
},
"j15puaBxVUexczCaRrABSg": {
getter: function (varBag, idService) {
return varBag.model.variables.inputOnFocusEventListenerVar;
},
dataType: OS.Types.Object
},
"MvRQfATce0G3jPg+HunGKw": {
getter: function (varBag, idService) {
return varBag.model.variables.inputIdIn;
},
dataType: OS.Types.Text
},
"ywKp7ih9OkWhsTRVtCMSiQ": {
getter: function (varBag, idService) {
return varBag.model.variables.patternIn;
},
dataType: OS.Types.Text
},
"H_N9msiNbkCRhmDyHdrgvA": {
getter: function (varBag, idService) {
return varBag.model.variables.isRegExpIn;
},
dataType: OS.Types.Boolean
},
"QQmwpgpOjU+DF_0ldOpC2A": {
getter: function (varBag, idService) {
return varBag.model.variables.isLazyIn;
},
dataType: OS.Types.Boolean
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
