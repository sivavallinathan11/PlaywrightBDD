﻿define("Common_CW.PHICore_CW.ConfirmationPopup.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "OutSystemsUI.Adaptive.Columns2.mvc$model", "Common_CW.PHICore_CW.PreviousFocus.mvc$model", "Common_CW.PHICore_CW.NextFocus.mvc$model", "Common_CW.controller$SelectFocus", "Common_CW.controller$Set_Focus"], function (OutSystems, Common_CWModel, Common_CWController, OutSystemsUI_Adaptive_Columns2_mvcModel, Common_CW_PHICore_CW_PreviousFocus_mvcModel, Common_CW_PHICore_CW_NextFocus_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("Show", "showIn", "Show", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showInDataFetchStatus", "_showInDataFetchStatus", "_showInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = ((OutSystemsUI_Adaptive_Columns2_mvcModel.hasValidationWidgets || Common_CW_PHICore_CW_PreviousFocus_mvcModel.hasValidationWidgets) || Common_CW_PHICore_CW_NextFocus_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("Show" in inputs) {
this.variables.showIn = inputs.Show;
if("_showInDataFetchStatus" in inputs) {
this.variables._showInDataFetchStatus = inputs._showInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.ConfirmationPopup");
});
define("Common_CW.PHICore_CW.ConfirmationPopup.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.ConfirmationPopup.mvc$model", "Common_CW.PHICore_CW.ConfirmationPopup.mvc$controller", "Common_CW.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Adaptive.Columns2.mvc$view", "Common_CW.PHICore_CW.PreviousFocus.mvc$view", "Common_CW.PHICore_CW.NextFocus.mvc$view", "Common_CW.controller$SelectFocus", "Common_CW.controller$Set_Focus"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_ConfirmationPopup_mvc_model, Common_CW_PHICore_CW_ConfirmationPopup_mvc_controller, Common_CWClientVariables, OSWidgets, OutSystemsUI_Adaptive_Columns2_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.ConfirmationPopup";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Adaptive_Columns2_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_ConfirmationPopup_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_ConfirmationPopup_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showIn,
style: "popup-dialog",
_idProps: {
service: idService,
name: "Popup"
},
_widgetRecordProvider: widgetsRecordProvider,
showPopup_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width11"
},
visible: true,
_idProps: {
service: idService,
name: "PopupTitle"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.AdvancedHtml, {
tag: "h2",
_idProps: {
service: idService,
name: "h2id"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 24px; font-weight: bold;"
},
text: ["Confirmation"],
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width1 ThemeGrid_MarginGutter"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
role: "button",
"aria-label": "close confirmation"
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/ConfirmationPopup/Link_Close OnClick");
return controller.actionNo$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "Link_Close"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
extendedProperties: {
"aria-label": "Close confirmation"
},
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon text-neutral-6",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "font-size: 24px; font-weight: bold;"
},
text: [React.createElement("br"), React.createElement("br")],
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"aria-label": "Unsaved changes will be discarded. Do you wish to continue?"
},
text: ["Unsaved changes will be discarded. Do you wish to continue?", React.createElement("br"), React.createElement("br"), React.createElement("br")],
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "10",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/ConfirmationPopup/Button OnClick");
return controller.actionNo$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, "No"))];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/ConfirmationPopup/Btn_Yes OnClick");
return controller.actionYes$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "Btn_Yes"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
style: "color: #fff;"
},
text: ["Yes"],
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_PreviousFocus_mvc_view, {
inputs: {
CurrentElement: ("#" + idService.getId("Link_Close")),
CurrentWidgetId: idService.getId("PreviousFocus"),
PreviousElement: ("#" + idService.getId("Btn_Yes"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "PreviousFocus",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_NextFocus_mvc_view, {
inputs: {
CurrentWidgetId: idService.getId("NextFocus"),
NextElement: ("#" + idService.getId("Link_Close")),
CurrentElement: ("#" + idService.getId("Btn_Yes"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "NextFocus",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.ConfirmationPopup.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.ConfirmationPopup.mvc$debugger", "Common_CW.controller$SelectFocus", "Common_CW.controller$Set_Focus"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_ConfirmationPopup_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._actionYes$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ActionYes");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:h_UMMEK6dE6_H3EFFpaEmg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.sU8yaeJLPESfqoqggPMgJQ/ClientActions.h_UMMEK6dE6_H3EFFpaEmg:TWjXEh8wPWC_2Mnt27oipQ", "Common_CW", "ActionYes", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:eIxm7usvBkSy_U24Uej9xQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LN_PneXhO0e8e+mUbFpi9A", callContext.id);
// Trigger Event: ConfirmationResponse
return controller.confirmationResponse$Action(true, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tY7rAKtifUiJuqrCv7cdzw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:h_UMMEK6dE6_H3EFFpaEmg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:h_UMMEK6dE6_H3EFFpaEmg", callContext.id);
throw ex;

});
};
Controller.prototype._actionNo$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ActionNo");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:bI_3icgMREaAMzDwnf4j5Q:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.sU8yaeJLPESfqoqggPMgJQ/ClientActions.bI_3icgMREaAMzDwnf4j5Q:ZpCsKCtrwEgD4IUpcPoNgA", "Common_CW", "ActionNo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NoZmE8IOaUujFwZXpU_+kw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ITDTqj0pN02iLhslJ2a3tg", callContext.id);
// Trigger Event: ConfirmationResponse
return controller.confirmationResponse$Action(false, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:g+2kvcaKmECIG2p2kuWeOg", callContext.id);
// Execute Action: SelectFocus
Common_CWController.default.selectFocus$Action(".content-top-title.heading1", callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GN_VWyM27UyGAjAK9n+GXA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:bI_3icgMREaAMzDwnf4j5Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:bI_3icgMREaAMzDwnf4j5Q", callContext.id);
throw ex;

});
};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:p9Qv7P+7vE2EMi5NQXzdnA:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.sU8yaeJLPESfqoqggPMgJQ/ClientActions.p9Qv7P+7vE2EMi5NQXzdnA:6tqwpCJVRUpVmKJoPMqp9A", "Common_CW", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Uq3NyMkpHUyUVKZLiFI0yQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vZKfTAeC2kaZRhXP9Pb7ag", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.showIn, idService.getId("Link_Close"), callContext);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dqJubeZnUUiPiRKi0El6CQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:p9Qv7P+7vE2EMi5NQXzdnA", callContext.id);
}

};

Controller.prototype.actionYes$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._actionYes$Action, callContext);

};
Controller.prototype.actionNo$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._actionNo$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.confirmationResponse$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:sU8yaeJLPESfqoqggPMgJQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.sU8yaeJLPESfqoqggPMgJQ:Ms8B4G9TBiqV9h2_8LCmAw", "Common_CW", "ConfirmationPopup", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:sU8yaeJLPESfqoqggPMgJQ", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "PHICore_CW/ConfirmationPopup On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.ConfirmationPopup.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"2JhWlQ4VZEmi7SFysZfPdg": {
getter: function (varBag, idService) {
return varBag.model.variables.showIn;
},
dataType: OS.Types.Boolean
},
"sJVeOquTGESTg4MfeZt6qQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup"));
})(varBag.model, idService);
}
},
"_Z7cVUKQkUe+2sOdG+GQdA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PopupTitle"));
})(varBag.model, idService);
}
},
"qt4ebZ2uYkGgtH1N9+pxUA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("h2id"));
})(varBag.model, idService);
}
},
"Gt7s6EdrhEmbEByHkUDcbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link_Close"));
})(varBag.model, idService);
}
},
"To8gq_8UZ0+n2CPe+C4AOw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"P7AY5N+CO0WtFU8e4X8bvA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"tGt5qciZ30y12PIlRXq4GA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_Yes"));
})(varBag.model, idService);
}
},
"ARSYL21TnEavEjAy5k4J4A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreviousFocus"));
})(varBag.model, idService);
}
},
"d4+2P2GXV0+IvLC7++JTqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NextFocus"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
