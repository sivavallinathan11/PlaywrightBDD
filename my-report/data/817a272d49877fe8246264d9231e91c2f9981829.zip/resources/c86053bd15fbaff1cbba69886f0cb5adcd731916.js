﻿define("Common_CW.model$UserTenantEspaceBooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter", "ServiceCenter.model$TenantRec", "ServiceCenter.model$EspaceRec"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var UserTenantEspaceBooleanRecord = (function (_super) {
__extends(UserTenantEspaceBooleanRecord, _super);
function UserTenantEspaceBooleanRecord(defaults) {
_super.apply(this, arguments);
}
UserTenantEspaceBooleanRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec), 
this.attr("Tenant", "tenantAttr", "Tenant", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.TenantRec());
}, true, ServiceCenterModel.TenantRec), 
this.attr("Espace", "espaceAttr", "Espace", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, true, ServiceCenterModel.EspaceRec), 
this.attr("IsHambs", "isHambsAttr", "IsHambs", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
UserTenantEspaceBooleanRecord._isAnonymousRecord = true;
UserTenantEspaceBooleanRecord.UniqueId = "016a386f-fa52-335e-bb77-436ff37e3525";
UserTenantEspaceBooleanRecord.init();
return UserTenantEspaceBooleanRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.UserTenantEspaceBooleanRecord = UserTenantEspaceBooleanRecord;

});
define("Common_CW.model$SpaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$SpaceRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SpaceRecord = (function (_super) {
__extends(SpaceRecord, _super);
function SpaceRecord(defaults) {
_super.apply(this, arguments);
}
SpaceRecord.attributesToDeclare = function () {
return [
this.attr("Space", "spaceAttr", "Space", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SpaceRec());
}, true, OutSystemsUIModel.SpaceRec)
].concat(_super.attributesToDeclare.call(this));
};
SpaceRecord.fromStructure = function (str) {
return new SpaceRecord(new SpaceRecord.RecordClass({
spaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpaceRecord._isAnonymousRecord = true;
SpaceRecord.UniqueId = "9589ecc0-6297-88c2-aca6-b47bcbae782c";
SpaceRecord.init();
return SpaceRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SpaceRecord = SpaceRecord;

});
define("Common_CW.model$SpaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SpaceRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SpaceRecordList = (function (_super) {
__extends(SpaceRecordList, _super);
function SpaceRecordList(defaults) {
_super.apply(this, arguments);
}
SpaceRecordList.itemType = Common_CWModel.SpaceRecord;
return SpaceRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SpaceRecordList = SpaceRecordList;

});
define("Common_CW.model$FundLogoRecord", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$FundLogoRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var FundLogoRecord = (function (_super) {
__extends(FundLogoRecord, _super);
function FundLogoRecord(defaults) {
_super.apply(this, arguments);
}
FundLogoRecord.attributesToDeclare = function () {
return [
this.attr("FundLogo", "fundLogoAttr", "FundLogo", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.FundLogoRec());
}, true, Config_CSModel.FundLogoRec)
].concat(_super.attributesToDeclare.call(this));
};
FundLogoRecord.fromStructure = function (str) {
return new FundLogoRecord(new FundLogoRecord.RecordClass({
fundLogoAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FundLogoRecord._isAnonymousRecord = true;
FundLogoRecord.UniqueId = "0564fe49-6c53-7707-ff16-7a5bbba2c756";
FundLogoRecord.init();
return FundLogoRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.FundLogoRecord = FundLogoRecord;

});
define("Common_CW.model$NotificationRecord", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model", "Common_CW.model", "PHICore_Notification.model$NotificationRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_Notification"], function (exports, OutSystems, PHICore_NotificationModel, Common_CWModel) {
var OS = OutSystems.Internal;
var NotificationRecord = (function (_super) {
__extends(NotificationRecord, _super);
function NotificationRecord(defaults) {
_super.apply(this, arguments);
}
NotificationRecord.attributesToDeclare = function () {
return [
this.attr("Notification", "notificationAttr", "Notification", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_NotificationModel.NotificationRec());
}, true, PHICore_NotificationModel.NotificationRec)
].concat(_super.attributesToDeclare.call(this));
};
NotificationRecord.fromStructure = function (str) {
return new NotificationRecord(new NotificationRecord.RecordClass({
notificationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
NotificationRecord._isAnonymousRecord = true;
NotificationRecord.UniqueId = "0a5f4a64-34fe-511e-ac24-727bc09b32ee";
NotificationRecord.init();
return NotificationRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.NotificationRecord = NotificationRecord;

});
define("Common_CW.model$ShapeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ShapeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ShapeRecord = (function (_super) {
__extends(ShapeRecord, _super);
function ShapeRecord(defaults) {
_super.apply(this, arguments);
}
ShapeRecord.attributesToDeclare = function () {
return [
this.attr("Shape", "shapeAttr", "Shape", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ShapeRec());
}, true, OutSystemsUIModel.ShapeRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeRecord.fromStructure = function (str) {
return new ShapeRecord(new ShapeRecord.RecordClass({
shapeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeRecord._isAnonymousRecord = true;
ShapeRecord.UniqueId = "0a89eeb6-0fa1-f44b-6316-ca69b462007b";
ShapeRecord.init();
return ShapeRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ShapeRecord = ShapeRecord;

});
define("Common_CW.model$ReferenceDataList", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$ReferenceDataRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataList = (function (_super) {
__extends(ReferenceDataList, _super);
function ReferenceDataList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataList.itemType = Config_CSModel.ReferenceDataRec;
return ReferenceDataList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReferenceDataList = ReferenceDataList;

});
define("Common_CW.model$StepsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$StepsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var StepsRecord = (function (_super) {
__extends(StepsRecord, _super);
function StepsRecord(defaults) {
_super.apply(this, arguments);
}
StepsRecord.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "Steps", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.StepsRec());
}, true, OutSystemsUIModel.StepsRec)
].concat(_super.attributesToDeclare.call(this));
};
StepsRecord.fromStructure = function (str) {
return new StepsRecord(new StepsRecord.RecordClass({
stepsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StepsRecord._isAnonymousRecord = true;
StepsRecord.UniqueId = "0d776a4e-191f-af32-1030-d5ce57aa4167";
StepsRecord.init();
return StepsRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.StepsRecord = StepsRecord;

});
define("Common_CW.model$TextRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.Text.model", "Common_CW.model", "Extension.Text.model$TextRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Text"], function (exports, OutSystems, Extension_TextModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TextRecord = (function (_super) {
__extends(TextRecord, _super);
function TextRecord(defaults) {
_super.apply(this, arguments);
}
TextRecord.attributesToDeclare = function () {
return [
this.attr("Text", "textAttr", "Text", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_TextModel.TextRec());
}, true, Extension_TextModel.TextRec)
].concat(_super.attributesToDeclare.call(this));
};
TextRecord.fromStructure = function (str) {
return new TextRecord(new TextRecord.RecordClass({
textAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TextRecord._isAnonymousRecord = true;
TextRecord.UniqueId = "0d84b59e-ff89-87c4-71ae-b49dfa9f2c39";
TextRecord.init();
return TextRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TextRecord = TextRecord;

});
define("Common_CW.model$FlagItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$FlagItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var FlagItemRecord = (function (_super) {
__extends(FlagItemRecord, _super);
function FlagItemRecord(defaults) {
_super.apply(this, arguments);
}
FlagItemRecord.attributesToDeclare = function () {
return [
this.attr("FlagItem", "flagItemAttr", "FlagItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.FlagItemRec());
}, true, APIGateway_ISModel.FlagItemRec)
].concat(_super.attributesToDeclare.call(this));
};
FlagItemRecord.fromStructure = function (str) {
return new FlagItemRecord(new FlagItemRecord.RecordClass({
flagItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FlagItemRecord._isAnonymousRecord = true;
FlagItemRecord.UniqueId = "0e8b7397-b2fd-e6f4-946f-af9dfe614515";
FlagItemRecord.init();
return FlagItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.FlagItemRecord = FlagItemRecord;

});
define("Common_CW.model$EntityFlagItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$EntityFlagItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityFlagItemList = (function (_super) {
__extends(EntityFlagItemList, _super);
function EntityFlagItemList(defaults) {
_super.apply(this, arguments);
}
EntityFlagItemList.itemType = APIGateway_ISModel.EntityFlagItemRec;
return EntityFlagItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityFlagItemList = EntityFlagItemList;

});
define("Common_CW.model$TenantRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$TenantRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantRecord = (function (_super) {
__extends(TenantRecord, _super);
function TenantRecord(defaults) {
_super.apply(this, arguments);
}
TenantRecord.attributesToDeclare = function () {
return [
this.attr("Tenant", "tenantAttr", "Tenant", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.TenantRec());
}, true, ServiceCenterModel.TenantRec)
].concat(_super.attributesToDeclare.call(this));
};
TenantRecord.fromStructure = function (str) {
return new TenantRecord(new TenantRecord.RecordClass({
tenantAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TenantRecord._isAnonymousRecord = true;
TenantRecord.UniqueId = "40d0f5c5-ba63-0b10-5850-cead15ae2223";
TenantRecord.init();
return TenantRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TenantRecord = TenantRecord;

});
define("Common_CW.model$TenantRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TenantRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantRecordList = (function (_super) {
__extends(TenantRecordList, _super);
function TenantRecordList(defaults) {
_super.apply(this, arguments);
}
TenantRecordList.itemType = Common_CWModel.TenantRecord;
return TenantRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TenantRecordList = TenantRecordList;

});
define("Common_CW.model$TextTextRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TextTextRecord = (function (_super) {
__extends(TextTextRecord, _super);
function TextTextRecord(defaults) {
_super.apply(this, arguments);
}
TextTextRecord.attributesToDeclare = function () {
return [
this.attr("FlagCode", "flagCodeAttr", "FlagCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TextTextRecord._isAnonymousRecord = true;
TextTextRecord.UniqueId = "e2b6d330-02e8-f060-463e-5f1910d6788f";
TextTextRecord.init();
return TextTextRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TextTextRecord = TextTextRecord;

});
define("Common_CW.model$TextTextRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TextTextRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TextTextRecordList = (function (_super) {
__extends(TextTextRecordList, _super);
function TextTextRecordList(defaults) {
_super.apply(this, arguments);
}
TextTextRecordList.itemType = Common_CWModel.TextTextRecord;
return TextTextRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TextTextRecordList = TextTextRecordList;

});
define("Common_CW.model$FlagItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$FlagItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var FlagItemList = (function (_super) {
__extends(FlagItemList, _super);
function FlagItemList(defaults) {
_super.apply(this, arguments);
}
FlagItemList.itemType = APIGateway_ISModel.FlagItemRec;
return FlagItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.FlagItemList = FlagItemList;

});
define("Common_CW.model$SearchStructureRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$FlagItemList"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchStructureRec = (function (_super) {
__extends(SearchStructureRec, _super);
function SearchStructureRec(defaults) {
_super.apply(this, arguments);
}
SearchStructureRec.attributesToDeclare = function () {
return [
this.attr("StakeholderId", "stakeholderIdAttr", "StakeholderId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("policyNumber", "policyNumberAttr", "policyNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("hasMultiplePolicies", "hasMultiplePoliciesAttr", "hasMultiplePolicies", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("PolicyCount", "policyCountAttr", "PolicyCount", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderStatus", "stakeholderStatusAttr", "StakeholderStatus", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Address", "addressAttr", "Address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateOfBirth", "dateOfBirthAttr", "DateOfBirth", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("isAuthorised", "isAuthorisedAttr", "isAuthorised", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Flags", "flagsAttr", "Flags", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("hasMultipleFlags", "hasMultipleFlagsAttr", "hasMultipleFlags", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("FlagCount", "flagCountAttr", "FlagCount", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("policyStatus", "policyStatusAttr", "policyStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StakeholderType", "stakeholderTypeAttr", "stakeholderType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Flags_List", "flags_ListAttr", "Flags_List", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.FlagItemList());
}, true, Common_CWModel.FlagItemList), 
this.attr("Phone", "phoneAttr", "Phone", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("product", "productAttr", "product", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchStructureRec.init();
return SearchStructureRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchStructureRec = SearchStructureRec;

});
define("Common_CW.model$SearchStructureRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchStructureRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchStructureRecord = (function (_super) {
__extends(SearchStructureRecord, _super);
function SearchStructureRecord(defaults) {
_super.apply(this, arguments);
}
SearchStructureRecord.attributesToDeclare = function () {
return [
this.attr("SearchStructure", "searchStructureAttr", "SearchStructure", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.SearchStructureRec());
}, true, Common_CWModel.SearchStructureRec)
].concat(_super.attributesToDeclare.call(this));
};
SearchStructureRecord.fromStructure = function (str) {
return new SearchStructureRecord(new SearchStructureRecord.RecordClass({
searchStructureAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SearchStructureRecord._isAnonymousRecord = true;
SearchStructureRecord.UniqueId = "71c81542-742a-91fd-9862-21eff0b698c6";
SearchStructureRecord.init();
return SearchStructureRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchStructureRecord = SearchStructureRecord;

});
define("Common_CW.model$SearchStructureRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchStructureRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchStructureRecordList = (function (_super) {
__extends(SearchStructureRecordList, _super);
function SearchStructureRecordList(defaults) {
_super.apply(this, arguments);
}
SearchStructureRecordList.itemType = Common_CWModel.SearchStructureRecord;
return SearchStructureRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchStructureRecordList = SearchStructureRecordList;

});
define("Common_CW.model$ReadReceiptNotificationRecord", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model", "Common_CW.model", "PHICore_Notification.model$ReadReceiptRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_Notification", "PHICore_Notification.model$NotificationRec"], function (exports, OutSystems, PHICore_NotificationModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReadReceiptNotificationRecord = (function (_super) {
__extends(ReadReceiptNotificationRecord, _super);
function ReadReceiptNotificationRecord(defaults) {
_super.apply(this, arguments);
}
ReadReceiptNotificationRecord.attributesToDeclare = function () {
return [
this.attr("ReadReceipt", "readReceiptAttr", "ReadReceipt", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_NotificationModel.ReadReceiptRec());
}, true, PHICore_NotificationModel.ReadReceiptRec), 
this.attr("Notification", "notificationAttr", "Notification", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_NotificationModel.NotificationRec());
}, true, PHICore_NotificationModel.NotificationRec)
].concat(_super.attributesToDeclare.call(this));
};
ReadReceiptNotificationRecord._isAnonymousRecord = true;
ReadReceiptNotificationRecord.UniqueId = "115faaf3-c0f4-0d15-03f6-541ac3a55d4a";
ReadReceiptNotificationRecord.init();
return ReadReceiptNotificationRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ReadReceiptNotificationRecord = ReadReceiptNotificationRecord;

});
define("Common_CW.model$PHIStakeholderSearchRequestRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PHIStakeholderSearchRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchRequestRecord = (function (_super) {
__extends(PHIStakeholderSearchRequestRecord, _super);
function PHIStakeholderSearchRequestRecord(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchRequestRecord.attributesToDeclare = function () {
return [
this.attr("PHIStakeholderSearchRequest", "pHIStakeholderSearchRequestAttr", "PHIStakeholderSearchRequest", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIStakeholderSearchRequestRec());
}, true, APIGateway_ISModel.PHIStakeholderSearchRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIStakeholderSearchRequestRecord.fromStructure = function (str) {
return new PHIStakeholderSearchRequestRecord(new PHIStakeholderSearchRequestRecord.RecordClass({
pHIStakeholderSearchRequestAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHIStakeholderSearchRequestRecord._isAnonymousRecord = true;
PHIStakeholderSearchRequestRecord.UniqueId = "f7762380-d60b-4a5d-79d4-0faa5361ed58";
PHIStakeholderSearchRequestRecord.init();
return PHIStakeholderSearchRequestRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PHIStakeholderSearchRequestRecord = PHIStakeholderSearchRequestRecord;

});
define("Common_CW.model$PHIStakeholderSearchRequestRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PHIStakeholderSearchRequestRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchRequestRecordList = (function (_super) {
__extends(PHIStakeholderSearchRequestRecordList, _super);
function PHIStakeholderSearchRequestRecordList(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchRequestRecordList.itemType = Common_CWModel.PHIStakeholderSearchRequestRecord;
return PHIStakeholderSearchRequestRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PHIStakeholderSearchRequestRecordList = PHIStakeholderSearchRequestRecordList;

});
define("Common_CW.model$AccessRequestList", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestList = (function (_super) {
__extends(AccessRequestList, _super);
function AccessRequestList(defaults) {
_super.apply(this, arguments);
}
AccessRequestList.itemType = AccessControl_CSModel.AccessRequestRec;
return AccessRequestList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestList = AccessRequestList;

});
define("Common_CW.model$PHIFlagRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PHIFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIFlagRecord = (function (_super) {
__extends(PHIFlagRecord, _super);
function PHIFlagRecord(defaults) {
_super.apply(this, arguments);
}
PHIFlagRecord.attributesToDeclare = function () {
return [
this.attr("PHIFlag", "pHIFlagAttr", "PHIFlag", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PHIFlagRec());
}, true, APIGateway_ISModel.PHIFlagRec)
].concat(_super.attributesToDeclare.call(this));
};
PHIFlagRecord.fromStructure = function (str) {
return new PHIFlagRecord(new PHIFlagRecord.RecordClass({
pHIFlagAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PHIFlagRecord._isAnonymousRecord = true;
PHIFlagRecord.UniqueId = "1523bf9e-869d-7db4-4f7f-2476428ba6b7";
PHIFlagRecord.init();
return PHIFlagRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PHIFlagRecord = PHIFlagRecord;

});
define("Common_CW.model$SpaceList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$SpaceRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SpaceList = (function (_super) {
__extends(SpaceList, _super);
function SpaceList(defaults) {
_super.apply(this, arguments);
}
SpaceList.itemType = OutSystemsUIModel.SpaceRec;
return SpaceList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SpaceList = SpaceList;

});
define("Common_CW.model$AccessRequestPermissionRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestPermissionRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestPermissionRecord = (function (_super) {
__extends(AccessRequestPermissionRecord, _super);
function AccessRequestPermissionRecord(defaults) {
_super.apply(this, arguments);
}
AccessRequestPermissionRecord.attributesToDeclare = function () {
return [
this.attr("AccessRequestPermission", "accessRequestPermissionAttr", "AccessRequestPermission", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.AccessRequestPermissionRec());
}, true, AccessControl_CSModel.AccessRequestPermissionRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessRequestPermissionRecord.fromStructure = function (str) {
return new AccessRequestPermissionRecord(new AccessRequestPermissionRecord.RecordClass({
accessRequestPermissionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AccessRequestPermissionRecord._isAnonymousRecord = true;
AccessRequestPermissionRecord.UniqueId = "ae253910-d48e-495b-b2b3-b7de0803fb8d";
AccessRequestPermissionRecord.init();
return AccessRequestPermissionRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AccessRequestPermissionRecord = AccessRequestPermissionRecord;

});
define("Common_CW.model$AccessRequestPermissionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AccessRequestPermissionRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestPermissionRecordList = (function (_super) {
__extends(AccessRequestPermissionRecordList, _super);
function AccessRequestPermissionRecordList(defaults) {
_super.apply(this, arguments);
}
AccessRequestPermissionRecordList.itemType = Common_CWModel.AccessRequestPermissionRecord;
return AccessRequestPermissionRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestPermissionRecordList = AccessRequestPermissionRecordList;

});
define("Common_CW.model$TriggerList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$TriggerRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TriggerList = (function (_super) {
__extends(TriggerList, _super);
function TriggerList(defaults) {
_super.apply(this, arguments);
}
TriggerList.itemType = OutSystemsUIModel.TriggerRec;
return TriggerList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TriggerList = TriggerList;

});
define("Common_CW.model$AccessRequestStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestStatusRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestStatusRecord = (function (_super) {
__extends(AccessRequestStatusRecord, _super);
function AccessRequestStatusRecord(defaults) {
_super.apply(this, arguments);
}
AccessRequestStatusRecord.attributesToDeclare = function () {
return [
this.attr("AccessRequestStatus", "accessRequestStatusAttr", "AccessRequestStatus", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.AccessRequestStatusRec());
}, true, AccessControl_CSModel.AccessRequestStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessRequestStatusRecord.fromStructure = function (str) {
return new AccessRequestStatusRecord(new AccessRequestStatusRecord.RecordClass({
accessRequestStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AccessRequestStatusRecord._isAnonymousRecord = true;
AccessRequestStatusRecord.UniqueId = "87321edf-71b6-c436-0e20-3ea9664bb399";
AccessRequestStatusRecord.init();
return AccessRequestStatusRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AccessRequestStatusRecord = AccessRequestStatusRecord;

});
define("Common_CW.model$AccessRequestStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AccessRequestStatusRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestStatusRecordList = (function (_super) {
__extends(AccessRequestStatusRecordList, _super);
function AccessRequestStatusRecordList(defaults) {
_super.apply(this, arguments);
}
AccessRequestStatusRecordList.itemType = Common_CWModel.AccessRequestStatusRecord;
return AccessRequestStatusRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestStatusRecordList = AccessRequestStatusRecordList;

});
define("Common_CW.model$PHIStakeholderSearchRequestList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PHIStakeholderSearchRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIStakeholderSearchRequestList = (function (_super) {
__extends(PHIStakeholderSearchRequestList, _super);
function PHIStakeholderSearchRequestList(defaults) {
_super.apply(this, arguments);
}
PHIStakeholderSearchRequestList.itemType = APIGateway_ISModel.PHIStakeholderSearchRequestRec;
return PHIStakeholderSearchRequestList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PHIStakeholderSearchRequestList = PHIStakeholderSearchRequestList;

});
define("Common_CW.model$TextList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.Text.model", "Common_CW.model", "Extension.Text.model$TextRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Text"], function (exports, OutSystems, Extension_TextModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = Extension_TextModel.TextRec;
return TextList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TextList = TextList;

});
define("Common_CW.model$AccessRequestPermissionList", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestPermissionRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestPermissionList = (function (_super) {
__extends(AccessRequestPermissionList, _super);
function AccessRequestPermissionList(defaults) {
_super.apply(this, arguments);
}
AccessRequestPermissionList.itemType = AccessControl_CSModel.AccessRequestPermissionRec;
return AccessRequestPermissionList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestPermissionList = AccessRequestPermissionList;

});
define("Common_CW.model$PolicyRoleItem2List", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PolicyRoleItem2Rec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem2List = (function (_super) {
__extends(PolicyRoleItem2List, _super);
function PolicyRoleItem2List(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem2List.itemType = APIGateway_ISModel.PolicyRoleItem2Rec;
return PolicyRoleItem2List;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PolicyRoleItem2List = PolicyRoleItem2List;

});
define("Common_CW.model$PhoneNumberItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PhoneNumberItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PhoneNumberItemList = (function (_super) {
__extends(PhoneNumberItemList, _super);
function PhoneNumberItemList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberItemList.itemType = APIGateway_ISModel.PhoneNumberItemRec;
return PhoneNumberItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PhoneNumberItemList = PhoneNumberItemList;

});
define("Common_CW.model$AddressItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$AddressItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AddressItemList = (function (_super) {
__extends(AddressItemList, _super);
function AddressItemList(defaults) {
_super.apply(this, arguments);
}
AddressItemList.itemType = APIGateway_ISModel.AddressItemRec;
return AddressItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AddressItemList = AddressItemList;

});
define("Common_CW.model$SearchResultItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$SearchResultItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchResultItemList = (function (_super) {
__extends(SearchResultItemList, _super);
function SearchResultItemList(defaults) {
_super.apply(this, arguments);
}
SearchResultItemList.itemType = APIGateway_ISModel.SearchResultItemRec;
return SearchResultItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchResultItemList = SearchResultItemList;

});
define("Common_CW.model$SearchIndividuals_APIResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$SearchIndividuals_APIResponseRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchIndividuals_APIResponseRecord = (function (_super) {
__extends(SearchIndividuals_APIResponseRecord, _super);
function SearchIndividuals_APIResponseRecord(defaults) {
_super.apply(this, arguments);
}
SearchIndividuals_APIResponseRecord.attributesToDeclare = function () {
return [
this.attr("SearchIndividuals_APIResponse", "searchIndividuals_APIResponseAttr", "SearchIndividuals_APIResponse", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SearchIndividuals_APIResponseRec());
}, true, APIGateway_ISModel.SearchIndividuals_APIResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
SearchIndividuals_APIResponseRecord.fromStructure = function (str) {
return new SearchIndividuals_APIResponseRecord(new SearchIndividuals_APIResponseRecord.RecordClass({
searchIndividuals_APIResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SearchIndividuals_APIResponseRecord._isAnonymousRecord = true;
SearchIndividuals_APIResponseRecord.UniqueId = "c213b221-c514-43f6-fd3f-8263409dcc1d";
SearchIndividuals_APIResponseRecord.init();
return SearchIndividuals_APIResponseRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchIndividuals_APIResponseRecord = SearchIndividuals_APIResponseRecord;

});
define("Common_CW.model$SearchIndividuals_APIResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchIndividuals_APIResponseRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchIndividuals_APIResponseRecordList = (function (_super) {
__extends(SearchIndividuals_APIResponseRecordList, _super);
function SearchIndividuals_APIResponseRecordList(defaults) {
_super.apply(this, arguments);
}
SearchIndividuals_APIResponseRecordList.itemType = Common_CWModel.SearchIndividuals_APIResponseRecord;
return SearchIndividuals_APIResponseRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchIndividuals_APIResponseRecordList = SearchIndividuals_APIResponseRecordList;

});
define("Common_CW.model$ReferenceDataPropertyRecord", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$ReferenceDataPropertyRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataPropertyRecord = (function (_super) {
__extends(ReferenceDataPropertyRecord, _super);
function ReferenceDataPropertyRecord(defaults) {
_super.apply(this, arguments);
}
ReferenceDataPropertyRecord.attributesToDeclare = function () {
return [
this.attr("ReferenceDataProperty", "referenceDataPropertyAttr", "ReferenceDataProperty", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataPropertyRec());
}, true, Config_CSModel.ReferenceDataPropertyRec)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataPropertyRecord.fromStructure = function (str) {
return new ReferenceDataPropertyRecord(new ReferenceDataPropertyRecord.RecordClass({
referenceDataPropertyAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ReferenceDataPropertyRecord._isAnonymousRecord = true;
ReferenceDataPropertyRecord.UniqueId = "24aef366-6fc1-2ddc-4f66-c8f875d35899";
ReferenceDataPropertyRecord.init();
return ReferenceDataPropertyRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ReferenceDataPropertyRecord = ReferenceDataPropertyRecord;

});
define("Common_CW.model$BreakColumnsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$BreakColumnsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecord = (function (_super) {
__extends(BreakColumnsRecord, _super);
function BreakColumnsRecord(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecord.attributesToDeclare = function () {
return [
this.attr("BreakColumns", "breakColumnsAttr", "BreakColumns", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.BreakColumnsRec());
}, true, OutSystemsUIModel.BreakColumnsRec)
].concat(_super.attributesToDeclare.call(this));
};
BreakColumnsRecord.fromStructure = function (str) {
return new BreakColumnsRecord(new BreakColumnsRecord.RecordClass({
breakColumnsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BreakColumnsRecord._isAnonymousRecord = true;
BreakColumnsRecord.UniqueId = "261685da-2c79-9bcc-3b48-73485e008694";
BreakColumnsRecord.init();
return BreakColumnsRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.BreakColumnsRecord = BreakColumnsRecord;

});
define("Common_CW.model$AccessRequestRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestRecord = (function (_super) {
__extends(AccessRequestRecord, _super);
function AccessRequestRecord(defaults) {
_super.apply(this, arguments);
}
AccessRequestRecord.attributesToDeclare = function () {
return [
this.attr("AccessRequest", "accessRequestAttr", "AccessRequest", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.AccessRequestRec());
}, true, AccessControl_CSModel.AccessRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessRequestRecord.fromStructure = function (str) {
return new AccessRequestRecord(new AccessRequestRecord.RecordClass({
accessRequestAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AccessRequestRecord._isAnonymousRecord = true;
AccessRequestRecord.UniqueId = "d9fa8577-f3b1-7904-f9fd-eb051a43443e";
AccessRequestRecord.init();
return AccessRequestRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AccessRequestRecord = AccessRequestRecord;

});
define("Common_CW.model$AccessRequestRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AccessRequestRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestRecordList = (function (_super) {
__extends(AccessRequestRecordList, _super);
function AccessRequestRecordList(defaults) {
_super.apply(this, arguments);
}
AccessRequestRecordList.itemType = Common_CWModel.AccessRequestRecord;
return AccessRequestRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestRecordList = AccessRequestRecordList;

});
define("Common_CW.model$SizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$SizeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SizeRecord = (function (_super) {
__extends(SizeRecord, _super);
function SizeRecord(defaults) {
_super.apply(this, arguments);
}
SizeRecord.attributesToDeclare = function () {
return [
this.attr("Size", "sizeAttr", "Size", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SizeRec());
}, true, OutSystemsUIModel.SizeRec)
].concat(_super.attributesToDeclare.call(this));
};
SizeRecord.fromStructure = function (str) {
return new SizeRecord(new SizeRecord.RecordClass({
sizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SizeRecord._isAnonymousRecord = true;
SizeRecord.UniqueId = "ca426fec-0751-e5b6-dcf0-15e9fdc2120e";
SizeRecord.init();
return SizeRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SizeRecord = SizeRecord;

});
define("Common_CW.model$SizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SizeRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SizeRecordList = (function (_super) {
__extends(SizeRecordList, _super);
function SizeRecordList(defaults) {
_super.apply(this, arguments);
}
SizeRecordList.itemType = Common_CWModel.SizeRecord;
return SizeRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SizeRecordList = SizeRecordList;

});
define("Common_CW.model$ErrorMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ErrorMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecord = (function (_super) {
__extends(ErrorMessageRecord, _super);
function ErrorMessageRecord(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecord.attributesToDeclare = function () {
return [
this.attr("ErrorMessage", "errorMessageAttr", "ErrorMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ErrorMessageRec());
}, true, OutSystemsUIModel.ErrorMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorMessageRecord.fromStructure = function (str) {
return new ErrorMessageRecord(new ErrorMessageRecord.RecordClass({
errorMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorMessageRecord._isAnonymousRecord = true;
ErrorMessageRecord.UniqueId = "27b5a164-e828-de9b-9068-6831c7908b4a";
ErrorMessageRecord.init();
return ErrorMessageRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ErrorMessageRecord = ErrorMessageRecord;

});
define("Common_CW.model$ReadReceiptNotificationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ReadReceiptNotificationRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ReadReceiptNotificationRecordList = (function (_super) {
__extends(ReadReceiptNotificationRecordList, _super);
function ReadReceiptNotificationRecordList(defaults) {
_super.apply(this, arguments);
}
ReadReceiptNotificationRecordList.itemType = Common_CWModel.ReadReceiptNotificationRecord;
return ReadReceiptNotificationRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReadReceiptNotificationRecordList = ReadReceiptNotificationRecordList;

});
define("Common_CW.model$PHIFlagRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PHIFlagRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIFlagRecordList = (function (_super) {
__extends(PHIFlagRecordList, _super);
function PHIFlagRecordList(defaults) {
_super.apply(this, arguments);
}
PHIFlagRecordList.itemType = Common_CWModel.PHIFlagRecord;
return PHIFlagRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PHIFlagRecordList = PHIFlagRecordList;

});
define("Common_CW.model$TenantConfigRecord", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$TenantConfigRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantConfigRecord = (function (_super) {
__extends(TenantConfigRecord, _super);
function TenantConfigRecord(defaults) {
_super.apply(this, arguments);
}
TenantConfigRecord.attributesToDeclare = function () {
return [
this.attr("TenantConfig", "tenantConfigAttr", "TenantConfig", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.TenantConfigRec());
}, true, Config_CSModel.TenantConfigRec)
].concat(_super.attributesToDeclare.call(this));
};
TenantConfigRecord.fromStructure = function (str) {
return new TenantConfigRecord(new TenantConfigRecord.RecordClass({
tenantConfigAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TenantConfigRecord._isAnonymousRecord = true;
TenantConfigRecord.UniqueId = "33fa04e9-9388-fe05-aa2b-aee77c2d0948";
TenantConfigRecord.init();
return TenantConfigRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TenantConfigRecord = TenantConfigRecord;

});
define("Common_CW.model$ProgressBarOptionalConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ProgressBarOptionalConfigsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionalConfigsRecord = (function (_super) {
__extends(ProgressBarOptionalConfigsRecord, _super);
function ProgressBarOptionalConfigsRecord(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionalConfigsRecord.attributesToDeclare = function () {
return [
this.attr("ProgressBarOptionalConfigs", "progressBarOptionalConfigsAttr", "ProgressBarOptionalConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ProgressBarOptionalConfigsRec());
}, true, OutSystemsUIModel.ProgressBarOptionalConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
ProgressBarOptionalConfigsRecord.fromStructure = function (str) {
return new ProgressBarOptionalConfigsRecord(new ProgressBarOptionalConfigsRecord.RecordClass({
progressBarOptionalConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ProgressBarOptionalConfigsRecord._isAnonymousRecord = true;
ProgressBarOptionalConfigsRecord.UniqueId = "3554b1e2-806a-5b82-7c45-7cdecc492d4a";
ProgressBarOptionalConfigsRecord.init();
return ProgressBarOptionalConfigsRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ProgressBarOptionalConfigsRecord = ProgressBarOptionalConfigsRecord;

});
define("Common_CW.model$MSD_ItemList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "Common_CW.model", "MSD.model$MSD_ItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$MSD"], function (exports, OutSystems, MSDModel, Common_CWModel) {
var OS = OutSystems.Internal;
var MSD_ItemList = (function (_super) {
__extends(MSD_ItemList, _super);
function MSD_ItemList(defaults) {
_super.apply(this, arguments);
}
MSD_ItemList.itemType = MSDModel.MSD_ItemRec;
return MSD_ItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.MSD_ItemList = MSD_ItemList;

});
define("Common_CW.model$AuditFilterRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$MSD_ItemList"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AuditFilterRec = (function (_super) {
__extends(AuditFilterRec, _super);
function AuditFilterRec(defaults) {
_super.apply(this, arguments);
}
AuditFilterRec.attributesToDeclare = function () {
return [
this.attr("EntryDate", "entryDateAttr", "EntryDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateFrom", "dateFromAttr", "DateFrom", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("DateTo", "dateToAttr", "DateTo", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ChangedBy", "changedByAttr", "ChangedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditType", "auditTypeAttr", "AuditType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditAction", "auditActionAttr", "AuditAction", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditTypeCode", "auditTypeCodeAttr", "AuditTypeCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditActionList", "auditActionListAttr", "AuditActionList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.MSD_ItemList());
}, true, Common_CWModel.MSD_ItemList), 
this.attr("IsLast24Hours", "isLast24HoursAttr", "IsLast24Hours", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("EntityNumber", "entityNumberAttr", "EntityNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EntityType", "entityTypeAttr", "EntityType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AuditTypeList", "auditTypeListAttr", "AuditTypeList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.MSD_ItemList());
}, true, Common_CWModel.MSD_ItemList), 
this.attr("UserList", "userListAttr", "UserList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.MSD_ItemList());
}, true, Common_CWModel.MSD_ItemList)
].concat(_super.attributesToDeclare.call(this));
};
AuditFilterRec.init();
return AuditFilterRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AuditFilterRec = AuditFilterRec;

});
define("Common_CW.model$AuditFilterRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AuditFilterRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AuditFilterRecord = (function (_super) {
__extends(AuditFilterRecord, _super);
function AuditFilterRecord(defaults) {
_super.apply(this, arguments);
}
AuditFilterRecord.attributesToDeclare = function () {
return [
this.attr("AuditFilter", "auditFilterAttr", "AuditFilter", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.AuditFilterRec());
}, true, Common_CWModel.AuditFilterRec)
].concat(_super.attributesToDeclare.call(this));
};
AuditFilterRecord.fromStructure = function (str) {
return new AuditFilterRecord(new AuditFilterRecord.RecordClass({
auditFilterAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AuditFilterRecord._isAnonymousRecord = true;
AuditFilterRecord.UniqueId = "35f00b9f-9865-c783-71e4-4809019cc355";
AuditFilterRecord.init();
return AuditFilterRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AuditFilterRecord = AuditFilterRecord;

});
define("Common_CW.model$ChoiceOptionItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$ChoiceOptionItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ChoiceOptionItemList = (function (_super) {
__extends(ChoiceOptionItemList, _super);
function ChoiceOptionItemList(defaults) {
_super.apply(this, arguments);
}
ChoiceOptionItemList.itemType = APIGateway_ISModel.ChoiceOptionItemRec;
return ChoiceOptionItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ChoiceOptionItemList = ChoiceOptionItemList;

});
define("Common_CW.model$MenuItemsRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var MenuItemsRec = (function (_super) {
__extends(MenuItemsRec, _super);
function MenuItemsRec(defaults) {
_super.apply(this, arguments);
}
MenuItemsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Index", "indexAttr", "Index", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemsRec.init();
return MenuItemsRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.MenuItemsRec = MenuItemsRec;

});
define("Common_CW.model$MenuItemsRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$MenuItemsRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var MenuItemsRecord = (function (_super) {
__extends(MenuItemsRecord, _super);
function MenuItemsRecord(defaults) {
_super.apply(this, arguments);
}
MenuItemsRecord.attributesToDeclare = function () {
return [
this.attr("MenuItems", "menuItemsAttr", "MenuItems", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.MenuItemsRec());
}, true, Common_CWModel.MenuItemsRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuItemsRecord.fromStructure = function (str) {
return new MenuItemsRecord(new MenuItemsRecord.RecordClass({
menuItemsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuItemsRecord._isAnonymousRecord = true;
MenuItemsRecord.UniqueId = "37a3a3e9-5158-77fa-6fa6-5a4b9abbbb86";
MenuItemsRecord.init();
return MenuItemsRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.MenuItemsRecord = MenuItemsRecord;

});
define("Common_CW.model$ChoiceOptionItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$ChoiceOptionItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ChoiceOptionItemRecord = (function (_super) {
__extends(ChoiceOptionItemRecord, _super);
function ChoiceOptionItemRecord(defaults) {
_super.apply(this, arguments);
}
ChoiceOptionItemRecord.attributesToDeclare = function () {
return [
this.attr("ChoiceOptionItem", "choiceOptionItemAttr", "ChoiceOptionItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.ChoiceOptionItemRec());
}, true, APIGateway_ISModel.ChoiceOptionItemRec)
].concat(_super.attributesToDeclare.call(this));
};
ChoiceOptionItemRecord.fromStructure = function (str) {
return new ChoiceOptionItemRecord(new ChoiceOptionItemRecord.RecordClass({
choiceOptionItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ChoiceOptionItemRecord._isAnonymousRecord = true;
ChoiceOptionItemRecord.UniqueId = "3881541b-bddd-216e-f29d-c075d624ea73";
ChoiceOptionItemRecord.init();
return ChoiceOptionItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ChoiceOptionItemRecord = ChoiceOptionItemRecord;

});
define("Common_CW.model$EntityActionMessageList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CW.model", "Common_CS.model$EntityActionMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionMessageList = (function (_super) {
__extends(EntityActionMessageList, _super);
function EntityActionMessageList(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageList.itemType = Common_CSModel.EntityActionMessageRec;
return EntityActionMessageList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityActionMessageList = EntityActionMessageList;

});
define("Common_CW.model$ReferenceDataPropertyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ReferenceDataPropertyRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataPropertyRecordList = (function (_super) {
__extends(ReferenceDataPropertyRecordList, _super);
function ReferenceDataPropertyRecordList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataPropertyRecordList.itemType = Common_CWModel.ReferenceDataPropertyRecord;
return ReferenceDataPropertyRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReferenceDataPropertyRecordList = ReferenceDataPropertyRecordList;

});
define("Common_CW.model$PhoneNumberItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PhoneNumberItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PhoneNumberItemRecord = (function (_super) {
__extends(PhoneNumberItemRecord, _super);
function PhoneNumberItemRecord(defaults) {
_super.apply(this, arguments);
}
PhoneNumberItemRecord.attributesToDeclare = function () {
return [
this.attr("PhoneNumberItem", "phoneNumberItemAttr", "PhoneNumberItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PhoneNumberItemRec());
}, true, APIGateway_ISModel.PhoneNumberItemRec)
].concat(_super.attributesToDeclare.call(this));
};
PhoneNumberItemRecord.fromStructure = function (str) {
return new PhoneNumberItemRecord(new PhoneNumberItemRecord.RecordClass({
phoneNumberItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PhoneNumberItemRecord._isAnonymousRecord = true;
PhoneNumberItemRecord.UniqueId = "3b614924-8875-b85f-e8d7-68d7a7581989";
PhoneNumberItemRecord.init();
return PhoneNumberItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PhoneNumberItemRecord = PhoneNumberItemRecord;

});
define("Common_CW.model$ProgressBarOptionalConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ProgressBarOptionalConfigsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionalConfigsList = (function (_super) {
__extends(ProgressBarOptionalConfigsList, _super);
function ProgressBarOptionalConfigsList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionalConfigsList.itemType = OutSystemsUIModel.ProgressBarOptionalConfigsRec;
return ProgressBarOptionalConfigsList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ProgressBarOptionalConfigsList = ProgressBarOptionalConfigsList;

});
define("Common_CW.model$UserTenantEspaceBooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$UserTenantEspaceBooleanRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var UserTenantEspaceBooleanRecordList = (function (_super) {
__extends(UserTenantEspaceBooleanRecordList, _super);
function UserTenantEspaceBooleanRecordList(defaults) {
_super.apply(this, arguments);
}
UserTenantEspaceBooleanRecordList.itemType = Common_CWModel.UserTenantEspaceBooleanRecord;
return UserTenantEspaceBooleanRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.UserTenantEspaceBooleanRecordList = UserTenantEspaceBooleanRecordList;

});
define("Common_CW.model$GetEntityFlags_APIResponseRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$GetEntityFlags_APIResponseRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GetEntityFlags_APIResponseRecord = (function (_super) {
__extends(GetEntityFlags_APIResponseRecord, _super);
function GetEntityFlags_APIResponseRecord(defaults) {
_super.apply(this, arguments);
}
GetEntityFlags_APIResponseRecord.attributesToDeclare = function () {
return [
this.attr("GetEntityFlags_APIResponse", "getEntityFlags_APIResponseAttr", "GetEntityFlags_APIResponse", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.GetEntityFlags_APIResponseRec());
}, true, APIGateway_ISModel.GetEntityFlags_APIResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
GetEntityFlags_APIResponseRecord.fromStructure = function (str) {
return new GetEntityFlags_APIResponseRecord(new GetEntityFlags_APIResponseRecord.RecordClass({
getEntityFlags_APIResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GetEntityFlags_APIResponseRecord._isAnonymousRecord = true;
GetEntityFlags_APIResponseRecord.UniqueId = "40df092e-95c2-a53a-8067-1df925e857a1";
GetEntityFlags_APIResponseRecord.init();
return GetEntityFlags_APIResponseRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.GetEntityFlags_APIResponseRecord = GetEntityFlags_APIResponseRecord;

});
define("Common_CW.model$EmailItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$EmailItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EmailItemRecord = (function (_super) {
__extends(EmailItemRecord, _super);
function EmailItemRecord(defaults) {
_super.apply(this, arguments);
}
EmailItemRecord.attributesToDeclare = function () {
return [
this.attr("EmailItem", "emailItemAttr", "EmailItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EmailItemRec());
}, true, APIGateway_ISModel.EmailItemRec)
].concat(_super.attributesToDeclare.call(this));
};
EmailItemRecord.fromStructure = function (str) {
return new EmailItemRecord(new EmailItemRecord.RecordClass({
emailItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EmailItemRecord._isAnonymousRecord = true;
EmailItemRecord.UniqueId = "416e9bb4-0786-5989-2040-4a1e888a7c05";
EmailItemRecord.init();
return EmailItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.EmailItemRecord = EmailItemRecord;

});
define("Common_CW.model$PromptItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PromptItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PromptItemRecord = (function (_super) {
__extends(PromptItemRecord, _super);
function PromptItemRecord(defaults) {
_super.apply(this, arguments);
}
PromptItemRecord.attributesToDeclare = function () {
return [
this.attr("PromptItem", "promptItemAttr", "PromptItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PromptItemRec());
}, true, APIGateway_ISModel.PromptItemRec)
].concat(_super.attributesToDeclare.call(this));
};
PromptItemRecord.fromStructure = function (str) {
return new PromptItemRecord(new PromptItemRecord.RecordClass({
promptItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PromptItemRecord._isAnonymousRecord = true;
PromptItemRecord.UniqueId = "81f49b36-c3f6-57bf-ad9f-07a418cef953";
PromptItemRecord.init();
return PromptItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PromptItemRecord = PromptItemRecord;

});
define("Common_CW.model$PromptItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PromptItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PromptItemRecordList = (function (_super) {
__extends(PromptItemRecordList, _super);
function PromptItemRecordList(defaults) {
_super.apply(this, arguments);
}
PromptItemRecordList.itemType = Common_CWModel.PromptItemRecord;
return PromptItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PromptItemRecordList = PromptItemRecordList;

});
define("Common_CW.model$ErrorMessageList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ErrorMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ErrorMessageList = (function (_super) {
__extends(ErrorMessageList, _super);
function ErrorMessageList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageList.itemType = OutSystemsUIModel.ErrorMessageRec;
return ErrorMessageList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ErrorMessageList = ErrorMessageList;

});
define("Common_CW.model$MSD_ItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "Common_CW.model", "MSD.model$MSD_ItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$MSD"], function (exports, OutSystems, MSDModel, Common_CWModel) {
var OS = OutSystems.Internal;
var MSD_ItemRecord = (function (_super) {
__extends(MSD_ItemRecord, _super);
function MSD_ItemRecord(defaults) {
_super.apply(this, arguments);
}
MSD_ItemRecord.attributesToDeclare = function () {
return [
this.attr("MSD_Item", "mSD_ItemAttr", "MSD_Item", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemRec());
}, true, MSDModel.MSD_ItemRec)
].concat(_super.attributesToDeclare.call(this));
};
MSD_ItemRecord.fromStructure = function (str) {
return new MSD_ItemRecord(new MSD_ItemRecord.RecordClass({
mSD_ItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MSD_ItemRecord._isAnonymousRecord = true;
MSD_ItemRecord.UniqueId = "77876896-9ddf-f445-2c03-3e03578bf347";
MSD_ItemRecord.init();
return MSD_ItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.MSD_ItemRecord = MSD_ItemRecord;

});
define("Common_CW.model$MSD_ItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$MSD_ItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var MSD_ItemRecordList = (function (_super) {
__extends(MSD_ItemRecordList, _super);
function MSD_ItemRecordList(defaults) {
_super.apply(this, arguments);
}
MSD_ItemRecordList.itemType = Common_CWModel.MSD_ItemRecord;
return MSD_ItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.MSD_ItemRecordList = MSD_ItemRecordList;

});
define("Common_CW.model$GroupFlagRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$GroupFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagRecord = (function (_super) {
__extends(GroupFlagRecord, _super);
function GroupFlagRecord(defaults) {
_super.apply(this, arguments);
}
GroupFlagRecord.attributesToDeclare = function () {
return [
this.attr("GroupFlag", "groupFlagAttr", "GroupFlag", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.GroupFlagRec());
}, true, AccessControl_CSModel.GroupFlagRec)
].concat(_super.attributesToDeclare.call(this));
};
GroupFlagRecord.fromStructure = function (str) {
return new GroupFlagRecord(new GroupFlagRecord.RecordClass({
groupFlagAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GroupFlagRecord._isAnonymousRecord = true;
GroupFlagRecord.UniqueId = "49848e84-1d58-763f-e4db-bad242173ee3";
GroupFlagRecord.init();
return GroupFlagRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.GroupFlagRecord = GroupFlagRecord;

});
define("Common_CW.model$EntityActionMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CW.model", "Common_CS.model$EntityActionMessageRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionMessageRecord = (function (_super) {
__extends(EntityActionMessageRecord, _super);
function EntityActionMessageRecord(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageRecord.attributesToDeclare = function () {
return [
this.attr("EntityActionMessage", "entityActionMessageAttr", "EntityActionMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CSModel.EntityActionMessageRec());
}, true, Common_CSModel.EntityActionMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionMessageRecord.fromStructure = function (str) {
return new EntityActionMessageRecord(new EntityActionMessageRecord.RecordClass({
entityActionMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EntityActionMessageRecord._isAnonymousRecord = true;
EntityActionMessageRecord.UniqueId = "7c3ebb2f-1f8a-e07a-62f7-36f460c8e4b8";
EntityActionMessageRecord.init();
return EntityActionMessageRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.EntityActionMessageRecord = EntityActionMessageRecord;

});
define("Common_CW.model$EntityActionMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$EntityActionMessageRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionMessageRecordList = (function (_super) {
__extends(EntityActionMessageRecordList, _super);
function EntityActionMessageRecordList(defaults) {
_super.apply(this, arguments);
}
EntityActionMessageRecordList.itemType = Common_CWModel.EntityActionMessageRecord;
return EntityActionMessageRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityActionMessageRecordList = EntityActionMessageRecordList;

});
define("Common_CW.model$EntityFlagItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$EntityFlagItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityFlagItemRecord = (function (_super) {
__extends(EntityFlagItemRecord, _super);
function EntityFlagItemRecord(defaults) {
_super.apply(this, arguments);
}
EntityFlagItemRecord.attributesToDeclare = function () {
return [
this.attr("EntityFlagItem", "entityFlagItemAttr", "EntityFlagItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.EntityFlagItemRec());
}, true, APIGateway_ISModel.EntityFlagItemRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityFlagItemRecord.fromStructure = function (str) {
return new EntityFlagItemRecord(new EntityFlagItemRecord.RecordClass({
entityFlagItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EntityFlagItemRecord._isAnonymousRecord = true;
EntityFlagItemRecord.UniqueId = "4be6611a-bd4b-e335-859a-9f3cd31c5726";
EntityFlagItemRecord.init();
return EntityFlagItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.EntityFlagItemRecord = EntityFlagItemRecord;

});
define("Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "ServiceCenter.model", "Config_CS.model", "Common_CW.model", "AccessControl_CS.model$GroupFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS", "ServiceCenter.model$Group_UserRec", "Common_CW.referencesHealth$ServiceCenter", "Config_CS.model$ReferenceDataRec", "Common_CW.referencesHealth$Config_CS", "Config_CS.model$ReferenceDataPropertyRec"], function (exports, OutSystems, AccessControl_CSModel, ServiceCenterModel, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord = (function (_super) {
__extends(GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord, _super);
function GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord(defaults) {
_super.apply(this, arguments);
}
GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord.attributesToDeclare = function () {
return [
this.attr("GroupFlag", "groupFlagAttr", "GroupFlag", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.GroupFlagRec());
}, true, AccessControl_CSModel.GroupFlagRec), 
this.attr("Group_User", "group_UserAttr", "Group_User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.Group_UserRec());
}, true, ServiceCenterModel.Group_UserRec), 
this.attr("ReferenceData", "referenceDataAttr", "ReferenceData", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataRec());
}, true, Config_CSModel.ReferenceDataRec), 
this.attr("ReferenceDataProperty", "referenceDataPropertyAttr", "ReferenceDataProperty", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataPropertyRec());
}, true, Config_CSModel.ReferenceDataPropertyRec), 
this.attr("IsSelected", "isSelectedAttr", "IsSelected", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("OriginalIsSelected", "originalIsSelectedAttr", "OriginalIsSelected", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord._isAnonymousRecord = true;
GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord.UniqueId = "4ef94ca7-2b23-ee16-45e2-d8dc7ee2b623";
GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord.init();
return GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord = GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord;

});
define("Common_CW.model$BreakColumnsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$BreakColumnsRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecordList = (function (_super) {
__extends(BreakColumnsRecordList, _super);
function BreakColumnsRecordList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecordList.itemType = Common_CWModel.BreakColumnsRecord;
return BreakColumnsRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.BreakColumnsRecordList = BreakColumnsRecordList;

});
define("Common_CW.model$Group_UserRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$Group_UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var Group_UserRecord = (function (_super) {
__extends(Group_UserRecord, _super);
function Group_UserRecord(defaults) {
_super.apply(this, arguments);
}
Group_UserRecord.attributesToDeclare = function () {
return [
this.attr("Group_User", "group_UserAttr", "Group_User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.Group_UserRec());
}, true, ServiceCenterModel.Group_UserRec)
].concat(_super.attributesToDeclare.call(this));
};
Group_UserRecord.fromStructure = function (str) {
return new Group_UserRecord(new Group_UserRecord.RecordClass({
group_UserAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Group_UserRecord._isAnonymousRecord = true;
Group_UserRecord.UniqueId = "ae1a5910-a458-c6d0-fdd0-2febdd67fd69";
Group_UserRecord.init();
return Group_UserRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.Group_UserRecord = Group_UserRecord;

});
define("Common_CW.model$Group_UserRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$Group_UserRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var Group_UserRecordList = (function (_super) {
__extends(Group_UserRecordList, _super);
function Group_UserRecordList(defaults) {
_super.apply(this, arguments);
}
Group_UserRecordList.itemType = Common_CWModel.Group_UserRecord;
return Group_UserRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.Group_UserRecordList = Group_UserRecordList;

});
define("Common_CW.model$TeamRecord", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model", "Common_CW.model", "StateMachineCaseService.model$TeamRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$StateMachineCaseService"], function (exports, OutSystems, StateMachineCaseServiceModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TeamRecord = (function (_super) {
__extends(TeamRecord, _super);
function TeamRecord(defaults) {
_super.apply(this, arguments);
}
TeamRecord.attributesToDeclare = function () {
return [
this.attr("Team", "teamAttr", "Team", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new StateMachineCaseServiceModel.TeamRec());
}, true, StateMachineCaseServiceModel.TeamRec)
].concat(_super.attributesToDeclare.call(this));
};
TeamRecord.fromStructure = function (str) {
return new TeamRecord(new TeamRecord.RecordClass({
teamAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TeamRecord._isAnonymousRecord = true;
TeamRecord.UniqueId = "b1681689-a3df-f19e-08e1-9dbef659808b";
TeamRecord.init();
return TeamRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TeamRecord = TeamRecord;

});
define("Common_CW.model$TeamRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TeamRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TeamRecordList = (function (_super) {
__extends(TeamRecordList, _super);
function TeamRecordList(defaults) {
_super.apply(this, arguments);
}
TeamRecordList.itemType = Common_CWModel.TeamRecord;
return TeamRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TeamRecordList = TeamRecordList;

});
define("Common_CW.model$TenantConfigList", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$TenantConfigRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantConfigList = (function (_super) {
__extends(TenantConfigList, _super);
function TenantConfigList(defaults) {
_super.apply(this, arguments);
}
TenantConfigList.itemType = Config_CSModel.TenantConfigRec;
return TenantConfigList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TenantConfigList = TenantConfigList;

});
define("Common_CW.model$ShapeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ShapeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ShapeList = (function (_super) {
__extends(ShapeList, _super);
function ShapeList(defaults) {
_super.apply(this, arguments);
}
ShapeList.itemType = OutSystemsUIModel.ShapeRec;
return ShapeList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ShapeList = ShapeList;

});
define("Common_CW.model$SearchResultItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$SearchResultItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchResultItemRecord = (function (_super) {
__extends(SearchResultItemRecord, _super);
function SearchResultItemRecord(defaults) {
_super.apply(this, arguments);
}
SearchResultItemRecord.attributesToDeclare = function () {
return [
this.attr("SearchResultItem", "searchResultItemAttr", "SearchResultItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.SearchResultItemRec());
}, true, APIGateway_ISModel.SearchResultItemRec)
].concat(_super.attributesToDeclare.call(this));
};
SearchResultItemRecord.fromStructure = function (str) {
return new SearchResultItemRecord(new SearchResultItemRecord.RecordClass({
searchResultItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SearchResultItemRecord._isAnonymousRecord = true;
SearchResultItemRecord.UniqueId = "57ece52f-667c-48a1-ab2a-50906f1c7714";
SearchResultItemRecord.init();
return SearchResultItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchResultItemRecord = SearchResultItemRecord;

});
define("Common_CW.model$AccessRequestPermissionAccessRequestRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestPermissionRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS", "AccessControl_CS.model$AccessRequestRec"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestPermissionAccessRequestRecord = (function (_super) {
__extends(AccessRequestPermissionAccessRequestRecord, _super);
function AccessRequestPermissionAccessRequestRecord(defaults) {
_super.apply(this, arguments);
}
AccessRequestPermissionAccessRequestRecord.attributesToDeclare = function () {
return [
this.attr("AccessRequestPermission", "accessRequestPermissionAttr", "AccessRequestPermission", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.AccessRequestPermissionRec());
}, true, AccessControl_CSModel.AccessRequestPermissionRec), 
this.attr("AccessRequest", "accessRequestAttr", "AccessRequest", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.AccessRequestRec());
}, true, AccessControl_CSModel.AccessRequestRec)
].concat(_super.attributesToDeclare.call(this));
};
AccessRequestPermissionAccessRequestRecord._isAnonymousRecord = true;
AccessRequestPermissionAccessRequestRecord.UniqueId = "84f91a35-fcc2-61a9-7617-0dc66a7690c1";
AccessRequestPermissionAccessRequestRecord.init();
return AccessRequestPermissionAccessRequestRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AccessRequestPermissionAccessRequestRecord = AccessRequestPermissionAccessRequestRecord;

});
define("Common_CW.model$AccessRequestPermissionAccessRequestRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AccessRequestPermissionAccessRequestRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestPermissionAccessRequestRecordList = (function (_super) {
__extends(AccessRequestPermissionAccessRequestRecordList, _super);
function AccessRequestPermissionAccessRequestRecordList(defaults) {
_super.apply(this, arguments);
}
AccessRequestPermissionAccessRequestRecordList.itemType = Common_CWModel.AccessRequestPermissionAccessRequestRecord;
return AccessRequestPermissionAccessRequestRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestPermissionAccessRequestRecordList = AccessRequestPermissionAccessRequestRecordList;

});
define("Common_CW.model$MenuItemsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$MenuItemsRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var MenuItemsRecordList = (function (_super) {
__extends(MenuItemsRecordList, _super);
function MenuItemsRecordList(defaults) {
_super.apply(this, arguments);
}
MenuItemsRecordList.itemType = Common_CWModel.MenuItemsRecord;
return MenuItemsRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.MenuItemsRecordList = MenuItemsRecordList;

});
define("Common_CW.model$AuditFilterList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AuditFilterRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AuditFilterList = (function (_super) {
__extends(AuditFilterList, _super);
function AuditFilterList(defaults) {
_super.apply(this, arguments);
}
AuditFilterList.itemType = Common_CWModel.AuditFilterRec;
return AuditFilterList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AuditFilterList = AuditFilterList;

});
define("Common_CW.model$PositionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$PositionRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PositionRecord = (function (_super) {
__extends(PositionRecord, _super);
function PositionRecord(defaults) {
_super.apply(this, arguments);
}
PositionRecord.attributesToDeclare = function () {
return [
this.attr("Position", "positionAttr", "Position", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.PositionRec());
}, true, OutSystemsUIModel.PositionRec)
].concat(_super.attributesToDeclare.call(this));
};
PositionRecord.fromStructure = function (str) {
return new PositionRecord(new PositionRecord.RecordClass({
positionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PositionRecord._isAnonymousRecord = true;
PositionRecord.UniqueId = "5f28219a-5e30-fb90-023f-cbc295513e7c";
PositionRecord.init();
return PositionRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PositionRecord = PositionRecord;

});
define("Common_CW.model$PositionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PositionRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PositionRecordList = (function (_super) {
__extends(PositionRecordList, _super);
function PositionRecordList(defaults) {
_super.apply(this, arguments);
}
PositionRecordList.itemType = Common_CWModel.PositionRecord;
return PositionRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PositionRecordList = PositionRecordList;

});
define("Common_CW.model$SearchStructureList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchStructureRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchStructureList = (function (_super) {
__extends(SearchStructureList, _super);
function SearchStructureList(defaults) {
_super.apply(this, arguments);
}
SearchStructureList.itemType = Common_CWModel.SearchStructureRec;
return SearchStructureList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchStructureList = SearchStructureList;

});
define("Common_CW.model$SearchRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchStructureList"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchRec = (function (_super) {
__extends(SearchRec, _super);
function SearchRec(defaults) {
_super.apply(this, arguments);
}
SearchRec.attributesToDeclare = function () {
return [
this.attr("SearchStructureList", "searchStructureListAttr", "SearchStructureList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.SearchStructureList());
}, true, Common_CWModel.SearchStructureList), 
this.attr("orderByField", "orderByFieldAttr", "orderByField", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("orderByDirection", "orderByDirectionAttr", "orderByDirection", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("pageNumber", "pageNumberAttr", "pageNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("pageSize", "pageSizeAttr", "pageSize", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("totalCount", "totalCountAttr", "totalCount", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SearchRec.init();
return SearchRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchRec = SearchRec;

});
define("Common_CW.model$SearchRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchRecord = (function (_super) {
__extends(SearchRecord, _super);
function SearchRecord(defaults) {
_super.apply(this, arguments);
}
SearchRecord.attributesToDeclare = function () {
return [
this.attr("Search", "searchAttr", "Search", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.SearchRec());
}, true, Common_CWModel.SearchRec)
].concat(_super.attributesToDeclare.call(this));
};
SearchRecord.fromStructure = function (str) {
return new SearchRecord(new SearchRecord.RecordClass({
searchAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SearchRecord._isAnonymousRecord = true;
SearchRecord.UniqueId = "752f5cbc-6893-4b95-48bd-be7e62ee1d25";
SearchRecord.init();
return SearchRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SearchRecord = SearchRecord;

});
define("Common_CW.model$SearchRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchRecordList = (function (_super) {
__extends(SearchRecordList, _super);
function SearchRecordList(defaults) {
_super.apply(this, arguments);
}
SearchRecordList.itemType = Common_CWModel.SearchRecord;
return SearchRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchRecordList = SearchRecordList;

});
define("Common_CW.model$TextTextPromptItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PromptItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TextTextPromptItemRecord = (function (_super) {
__extends(TextTextPromptItemRecord, _super);
function TextTextPromptItemRecord(defaults) {
_super.apply(this, arguments);
}
TextTextPromptItemRecord.attributesToDeclare = function () {
return [
this.attr("Choice", "choiceAttr", "Choice", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Error", "errorAttr", "Error", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PromptItem", "promptItemAttr", "PromptItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PromptItemRec());
}, true, APIGateway_ISModel.PromptItemRec)
].concat(_super.attributesToDeclare.call(this));
};
TextTextPromptItemRecord._isAnonymousRecord = true;
TextTextPromptItemRecord.UniqueId = "618059cf-a57d-5f67-a064-3284abecb3e3";
TextTextPromptItemRecord.init();
return TextTextPromptItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TextTextPromptItemRecord = TextTextPromptItemRecord;

});
define("Common_CW.model$UserFundLogoTenantConfigRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Config_CS.model", "Common_CW.model", "ServiceCenter.model$UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter", "Config_CS.model$FundLogoRec", "Common_CW.referencesHealth$Config_CS", "Config_CS.model$TenantConfigRec"], function (exports, OutSystems, ServiceCenterModel, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var UserFundLogoTenantConfigRecord = (function (_super) {
__extends(UserFundLogoTenantConfigRecord, _super);
function UserFundLogoTenantConfigRecord(defaults) {
_super.apply(this, arguments);
}
UserFundLogoTenantConfigRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec), 
this.attr("FundLogo", "fundLogoAttr", "FundLogo", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.FundLogoRec());
}, true, Config_CSModel.FundLogoRec), 
this.attr("TenantConfig", "tenantConfigAttr", "TenantConfig", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.TenantConfigRec());
}, true, Config_CSModel.TenantConfigRec)
].concat(_super.attributesToDeclare.call(this));
};
UserFundLogoTenantConfigRecord._isAnonymousRecord = true;
UserFundLogoTenantConfigRecord.UniqueId = "633c9a26-e5f5-7497-e68b-d0a50c5b7e8c";
UserFundLogoTenantConfigRecord.init();
return UserFundLogoTenantConfigRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.UserFundLogoTenantConfigRecord = UserFundLogoTenantConfigRecord;

});
define("Common_CW.model$TriggerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$TriggerRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TriggerRecord = (function (_super) {
__extends(TriggerRecord, _super);
function TriggerRecord(defaults) {
_super.apply(this, arguments);
}
TriggerRecord.attributesToDeclare = function () {
return [
this.attr("Trigger", "triggerAttr", "Trigger", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.TriggerRec());
}, true, OutSystemsUIModel.TriggerRec)
].concat(_super.attributesToDeclare.call(this));
};
TriggerRecord.fromStructure = function (str) {
return new TriggerRecord(new TriggerRecord.RecordClass({
triggerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TriggerRecord._isAnonymousRecord = true;
TriggerRecord.UniqueId = "ab84a98a-3ac9-de80-e927-8e5b21681a23";
TriggerRecord.init();
return TriggerRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.TriggerRecord = TriggerRecord;

});
define("Common_CW.model$TriggerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TriggerRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TriggerRecordList = (function (_super) {
__extends(TriggerRecordList, _super);
function TriggerRecordList(defaults) {
_super.apply(this, arguments);
}
TriggerRecordList.itemType = Common_CWModel.TriggerRecord;
return TriggerRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TriggerRecordList = TriggerRecordList;

});
define("Common_CW.model$EspaceList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$EspaceRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EspaceList = (function (_super) {
__extends(EspaceList, _super);
function EspaceList(defaults) {
_super.apply(this, arguments);
}
EspaceList.itemType = ServiceCenterModel.EspaceRec;
return EspaceList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EspaceList = EspaceList;

});
define("Common_CW.model$ListNavigationRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ListNavigationRec = (function (_super) {
__extends(ListNavigationRec, _super);
function ListNavigationRec(defaults) {
_super.apply(this, arguments);
}
ListNavigationRec.attributesToDeclare = function () {
return [
this.attr("Page", "pageAttr", "Page", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("StartIndex", "startIndexAttr", "StartIndex", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ListNavigationRec.init();
return ListNavigationRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ListNavigationRec = ListNavigationRec;

});
define("Common_CW.model$TextRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TextRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TextRecordList = (function (_super) {
__extends(TextRecordList, _super);
function TextRecordList(defaults) {
_super.apply(this, arguments);
}
TextRecordList.itemType = Common_CWModel.TextRecord;
return TextRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TextRecordList = TextRecordList;

});
define("Common_CW.model$BreakColumnsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$BreakColumnsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var BreakColumnsList = (function (_super) {
__extends(BreakColumnsList, _super);
function BreakColumnsList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsList.itemType = OutSystemsUIModel.BreakColumnsRec;
return BreakColumnsList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.BreakColumnsList = BreakColumnsList;

});
define("Common_CW.model$ShapeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ShapeRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ShapeRecordList = (function (_super) {
__extends(ShapeRecordList, _super);
function ShapeRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeRecordList.itemType = Common_CWModel.ShapeRecord;
return ShapeRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ShapeRecordList = ShapeRecordList;

});
define("Common_CW.model$SLAList", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model", "Common_CW.model", "StateMachineCaseService.model$SLARec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$StateMachineCaseService"], function (exports, OutSystems, StateMachineCaseServiceModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SLAList = (function (_super) {
__extends(SLAList, _super);
function SLAList(defaults) {
_super.apply(this, arguments);
}
SLAList.itemType = StateMachineCaseServiceModel.SLARec;
return SLAList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SLAList = SLAList;

});
define("Common_CW.model$TeamList", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model", "Common_CW.model", "StateMachineCaseService.model$TeamRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$StateMachineCaseService"], function (exports, OutSystems, StateMachineCaseServiceModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TeamList = (function (_super) {
__extends(TeamList, _super);
function TeamList(defaults) {
_super.apply(this, arguments);
}
TeamList.itemType = StateMachineCaseServiceModel.TeamRec;
return TeamList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TeamList = TeamList;

});
define("Common_CW.model$EntityActionResultRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CW.model", "Common_CS.model$EntityActionResultRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionResultRecord = (function (_super) {
__extends(EntityActionResultRecord, _super);
function EntityActionResultRecord(defaults) {
_super.apply(this, arguments);
}
EntityActionResultRecord.attributesToDeclare = function () {
return [
this.attr("EntityActionResult", "entityActionResultAttr", "EntityActionResult", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CSModel.EntityActionResultRec());
}, true, Common_CSModel.EntityActionResultRec)
].concat(_super.attributesToDeclare.call(this));
};
EntityActionResultRecord.fromStructure = function (str) {
return new EntityActionResultRecord(new EntityActionResultRecord.RecordClass({
entityActionResultAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EntityActionResultRecord._isAnonymousRecord = true;
EntityActionResultRecord.UniqueId = "71775667-ce43-fc5f-99a9-c6e1ecc450a4";
EntityActionResultRecord.init();
return EntityActionResultRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.EntityActionResultRecord = EntityActionResultRecord;

});
define("Common_CW.model$EspaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$EspaceRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EspaceRecord = (function (_super) {
__extends(EspaceRecord, _super);
function EspaceRecord(defaults) {
_super.apply(this, arguments);
}
EspaceRecord.attributesToDeclare = function () {
return [
this.attr("Espace", "espaceAttr", "Espace", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.EspaceRec());
}, true, ServiceCenterModel.EspaceRec)
].concat(_super.attributesToDeclare.call(this));
};
EspaceRecord.fromStructure = function (str) {
return new EspaceRecord(new EspaceRecord.RecordClass({
espaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EspaceRecord._isAnonymousRecord = true;
EspaceRecord.UniqueId = "a702e171-772a-9b89-c17e-2544ab6d1d29";
EspaceRecord.init();
return EspaceRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.EspaceRecord = EspaceRecord;

});
define("Common_CW.model$EspaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$EspaceRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var EspaceRecordList = (function (_super) {
__extends(EspaceRecordList, _super);
function EspaceRecordList(defaults) {
_super.apply(this, arguments);
}
EspaceRecordList.itemType = Common_CWModel.EspaceRecord;
return EspaceRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EspaceRecordList = EspaceRecordList;

});
define("Common_CW.model$DropDownInputListRec", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var DropDownInputListRec = (function (_super) {
__extends(DropDownInputListRec, _super);
function DropDownInputListRec(defaults) {
_super.apply(this, arguments);
}
DropDownInputListRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DropDownInputListRec.init();
return DropDownInputListRec;
})(OS.DataTypes.GenericRecord);
Common_CWModel.DropDownInputListRec = DropDownInputListRec;

});
define("Common_CW.model$DropDownInputListRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$DropDownInputListRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var DropDownInputListRecord = (function (_super) {
__extends(DropDownInputListRecord, _super);
function DropDownInputListRecord(defaults) {
_super.apply(this, arguments);
}
DropDownInputListRecord.attributesToDeclare = function () {
return [
this.attr("DropDownInputList", "dropDownInputListAttr", "DropDownInputList", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.DropDownInputListRec());
}, true, Common_CWModel.DropDownInputListRec)
].concat(_super.attributesToDeclare.call(this));
};
DropDownInputListRecord.fromStructure = function (str) {
return new DropDownInputListRecord(new DropDownInputListRecord.RecordClass({
dropDownInputListAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DropDownInputListRecord._isAnonymousRecord = true;
DropDownInputListRecord.UniqueId = "78ff1626-637e-8a7e-c0e5-d3bd8dc28ea1";
DropDownInputListRecord.init();
return DropDownInputListRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.DropDownInputListRecord = DropDownInputListRecord;

});
define("Common_CW.model$AddressItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$AddressItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AddressItemRecord = (function (_super) {
__extends(AddressItemRecord, _super);
function AddressItemRecord(defaults) {
_super.apply(this, arguments);
}
AddressItemRecord.attributesToDeclare = function () {
return [
this.attr("AddressItem", "addressItemAttr", "AddressItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.AddressItemRec());
}, true, APIGateway_ISModel.AddressItemRec)
].concat(_super.attributesToDeclare.call(this));
};
AddressItemRecord.fromStructure = function (str) {
return new AddressItemRecord(new AddressItemRecord.RecordClass({
addressItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AddressItemRecord._isAnonymousRecord = true;
AddressItemRecord.UniqueId = "8d4f257a-5e14-c606-732c-e81461e326ec";
AddressItemRecord.init();
return AddressItemRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.AddressItemRecord = AddressItemRecord;

});
define("Common_CW.model$AddressItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AddressItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AddressItemRecordList = (function (_super) {
__extends(AddressItemRecordList, _super);
function AddressItemRecordList(defaults) {
_super.apply(this, arguments);
}
AddressItemRecordList.itemType = Common_CWModel.AddressItemRecord;
return AddressItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AddressItemRecordList = AddressItemRecordList;

});
define("Common_CW.model$EmailItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$EmailItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var EmailItemRecordList = (function (_super) {
__extends(EmailItemRecordList, _super);
function EmailItemRecordList(defaults) {
_super.apply(this, arguments);
}
EmailItemRecordList.itemType = Common_CWModel.EmailItemRecord;
return EmailItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EmailItemRecordList = EmailItemRecordList;

});
define("Common_CW.model$EntityFlagItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$EntityFlagItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityFlagItemRecordList = (function (_super) {
__extends(EntityFlagItemRecordList, _super);
function EntityFlagItemRecordList(defaults) {
_super.apply(this, arguments);
}
EntityFlagItemRecordList.itemType = Common_CWModel.EntityFlagItemRecord;
return EntityFlagItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityFlagItemRecordList = EntityFlagItemRecordList;

});
define("Common_CW.model$ReferenceDataRecord", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$ReferenceDataRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataRecord = (function (_super) {
__extends(ReferenceDataRecord, _super);
function ReferenceDataRecord(defaults) {
_super.apply(this, arguments);
}
ReferenceDataRecord.attributesToDeclare = function () {
return [
this.attr("ReferenceData", "referenceDataAttr", "ReferenceData", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataRec());
}, true, Config_CSModel.ReferenceDataRec)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataRecord.fromStructure = function (str) {
return new ReferenceDataRecord(new ReferenceDataRecord.RecordClass({
referenceDataAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ReferenceDataRecord._isAnonymousRecord = true;
ReferenceDataRecord.UniqueId = "9a0d5b8d-f443-151c-dece-0df858aa8202";
ReferenceDataRecord.init();
return ReferenceDataRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ReferenceDataRecord = ReferenceDataRecord;

});
define("Common_CW.model$ReferenceDataRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ReferenceDataRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataRecordList = (function (_super) {
__extends(ReferenceDataRecordList, _super);
function ReferenceDataRecordList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataRecordList.itemType = Common_CWModel.ReferenceDataRecord;
return ReferenceDataRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReferenceDataRecordList = ReferenceDataRecordList;

});
define("Common_CW.model$UserRecord", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var UserRecord = (function (_super) {
__extends(UserRecord, _super);
function UserRecord(defaults) {
_super.apply(this, arguments);
}
UserRecord.attributesToDeclare = function () {
return [
this.attr("User", "userAttr", "User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.UserRec());
}, true, ServiceCenterModel.UserRec)
].concat(_super.attributesToDeclare.call(this));
};
UserRecord.fromStructure = function (str) {
return new UserRecord(new UserRecord.RecordClass({
userAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
UserRecord._isAnonymousRecord = true;
UserRecord.UniqueId = "ced01335-8a82-a813-f1d9-a5108f17ce79";
UserRecord.init();
return UserRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.UserRecord = UserRecord;

});
define("Common_CW.model$UserRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$UserRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var UserRecordList = (function (_super) {
__extends(UserRecordList, _super);
function UserRecordList(defaults) {
_super.apply(this, arguments);
}
UserRecordList.itemType = Common_CWModel.UserRecord;
return UserRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.UserRecordList = UserRecordList;

});
define("Common_CW.model$SLARecord", ["exports", "OutSystems/ClientRuntime/Main", "StateMachineCaseService.model", "Common_CW.model", "StateMachineCaseService.model$SLARec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$StateMachineCaseService"], function (exports, OutSystems, StateMachineCaseServiceModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SLARecord = (function (_super) {
__extends(SLARecord, _super);
function SLARecord(defaults) {
_super.apply(this, arguments);
}
SLARecord.attributesToDeclare = function () {
return [
this.attr("SLA", "sLAAttr", "SLA", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new StateMachineCaseServiceModel.SLARec());
}, true, StateMachineCaseServiceModel.SLARec)
].concat(_super.attributesToDeclare.call(this));
};
SLARecord.fromStructure = function (str) {
return new SLARecord(new SLARecord.RecordClass({
sLAAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SLARecord._isAnonymousRecord = true;
SLARecord.UniqueId = "85c6d3b8-08c3-9706-bac7-9a44097d8029";
SLARecord.init();
return SLARecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.SLARecord = SLARecord;

});
define("Common_CW.model$ColorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ColorRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ColorRecord = (function (_super) {
__extends(ColorRecord, _super);
function ColorRecord(defaults) {
_super.apply(this, arguments);
}
ColorRecord.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColorRec());
}, true, OutSystemsUIModel.ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
ColorRecord.fromStructure = function (str) {
return new ColorRecord(new ColorRecord.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRecord._isAnonymousRecord = true;
ColorRecord.UniqueId = "87351e3b-0fa2-ca59-cf6c-6749c6405006";
ColorRecord.init();
return ColorRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ColorRecord = ColorRecord;

});
define("Common_CW.model$SizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$SizeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SizeList = (function (_super) {
__extends(SizeList, _super);
function SizeList(defaults) {
_super.apply(this, arguments);
}
SizeList.itemType = OutSystemsUIModel.SizeRec;
return SizeList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SizeList = SizeList;

});
define("Common_CW.model$DropDownInputListList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$DropDownInputListRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var DropDownInputListList = (function (_super) {
__extends(DropDownInputListList, _super);
function DropDownInputListList(defaults) {
_super.apply(this, arguments);
}
DropDownInputListList.itemType = Common_CWModel.DropDownInputListRec;
return DropDownInputListList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.DropDownInputListList = DropDownInputListList;

});
define("Common_CW.model$GetEntityFlags_APIResponseList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$GetEntityFlags_APIResponseRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GetEntityFlags_APIResponseList = (function (_super) {
__extends(GetEntityFlags_APIResponseList, _super);
function GetEntityFlags_APIResponseList(defaults) {
_super.apply(this, arguments);
}
GetEntityFlags_APIResponseList.itemType = APIGateway_ISModel.GetEntityFlags_APIResponseRec;
return GetEntityFlags_APIResponseList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GetEntityFlags_APIResponseList = GetEntityFlags_APIResponseList;

});
define("Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "ServiceCenter.model", "Config_CS.model", "Common_CW.model", "AccessControl_CS.model$GroupFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS", "ServiceCenter.model$Group_UserRec", "Common_CW.referencesHealth$ServiceCenter", "Config_CS.model$ReferenceDataRec", "Common_CW.referencesHealth$Config_CS", "Config_CS.model$ReferenceDataPropertyRec"], function (exports, OutSystems, AccessControl_CSModel, ServiceCenterModel, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord = (function (_super) {
__extends(GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord, _super);
function GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord(defaults) {
_super.apply(this, arguments);
}
GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord.attributesToDeclare = function () {
return [
this.attr("GroupFlag", "groupFlagAttr", "GroupFlag", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new AccessControl_CSModel.GroupFlagRec());
}, true, AccessControl_CSModel.GroupFlagRec), 
this.attr("Group_User", "group_UserAttr", "Group_User", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ServiceCenterModel.Group_UserRec());
}, true, ServiceCenterModel.Group_UserRec), 
this.attr("ReferenceData", "referenceDataAttr", "ReferenceData", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataRec());
}, true, Config_CSModel.ReferenceDataRec), 
this.attr("IsRestricted", "isRestrictedAttr", "IsRestricted", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataPropertyRec());
}, true, Config_CSModel.ReferenceDataPropertyRec)
].concat(_super.attributesToDeclare.call(this));
};
GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord._isAnonymousRecord = true;
GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord.UniqueId = "f94d9d43-8f55-ce34-716e-5c3c9c90ba91";
GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord.init();
return GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord = GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord;

});
define("Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList = (function (_super) {
__extends(GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList, _super);
function GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList(defaults) {
_super.apply(this, arguments);
}
GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList.itemType = Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecord;
return GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList = GroupFlagGroup_UserReferenceDataReferenceDataPropertyRecordList;

});
define("Common_CW.model$UserFundLogoTenantConfigRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$UserFundLogoTenantConfigRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var UserFundLogoTenantConfigRecordList = (function (_super) {
__extends(UserFundLogoTenantConfigRecordList, _super);
function UserFundLogoTenantConfigRecordList(defaults) {
_super.apply(this, arguments);
}
UserFundLogoTenantConfigRecordList.itemType = Common_CWModel.UserFundLogoTenantConfigRecord;
return UserFundLogoTenantConfigRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.UserFundLogoTenantConfigRecordList = UserFundLogoTenantConfigRecordList;

});
define("Common_CW.model$PolicyRoleItem2Record", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PolicyRoleItem2Rec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem2Record = (function (_super) {
__extends(PolicyRoleItem2Record, _super);
function PolicyRoleItem2Record(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem2Record.attributesToDeclare = function () {
return [
this.attr("PolicyRoleItem2", "policyRoleItem2Attr", "PolicyRoleItem2", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new APIGateway_ISModel.PolicyRoleItem2Rec());
}, true, APIGateway_ISModel.PolicyRoleItem2Rec)
].concat(_super.attributesToDeclare.call(this));
};
PolicyRoleItem2Record.fromStructure = function (str) {
return new PolicyRoleItem2Record(new PolicyRoleItem2Record.RecordClass({
policyRoleItem2Attr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PolicyRoleItem2Record._isAnonymousRecord = true;
PolicyRoleItem2Record.UniqueId = "9739e31f-5450-475e-12fe-2c9969ac9a65";
PolicyRoleItem2Record.init();
return PolicyRoleItem2Record;
})(OS.DataTypes.GenericRecord);
Common_CWModel.PolicyRoleItem2Record = PolicyRoleItem2Record;

});
define("Common_CW.model$DropDownInputListRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$DropDownInputListRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var DropDownInputListRecordList = (function (_super) {
__extends(DropDownInputListRecordList, _super);
function DropDownInputListRecordList(defaults) {
_super.apply(this, arguments);
}
DropDownInputListRecordList.itemType = Common_CWModel.DropDownInputListRecord;
return DropDownInputListRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.DropDownInputListRecordList = DropDownInputListRecordList;

});
define("Common_CW.model$ProgressBarOptionalConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ProgressBarOptionalConfigsRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ProgressBarOptionalConfigsRecordList = (function (_super) {
__extends(ProgressBarOptionalConfigsRecordList, _super);
function ProgressBarOptionalConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
ProgressBarOptionalConfigsRecordList.itemType = Common_CWModel.ProgressBarOptionalConfigsRecord;
return ProgressBarOptionalConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ProgressBarOptionalConfigsRecordList = ProgressBarOptionalConfigsRecordList;

});
define("Common_CW.model$SearchResultItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchResultItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchResultItemRecordList = (function (_super) {
__extends(SearchResultItemRecordList, _super);
function SearchResultItemRecordList(defaults) {
_super.apply(this, arguments);
}
SearchResultItemRecordList.itemType = Common_CWModel.SearchResultItemRecord;
return SearchResultItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchResultItemRecordList = SearchResultItemRecordList;

});
define("Common_CW.model$ColorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ColorRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ColorRecordList = (function (_super) {
__extends(ColorRecordList, _super);
function ColorRecordList(defaults) {
_super.apply(this, arguments);
}
ColorRecordList.itemType = Common_CWModel.ColorRecord;
return ColorRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ColorRecordList = ColorRecordList;

});
define("Common_CW.model$GroupFlagList", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$GroupFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagList = (function (_super) {
__extends(GroupFlagList, _super);
function GroupFlagList(defaults) {
_super.apply(this, arguments);
}
GroupFlagList.itemType = AccessControl_CSModel.GroupFlagRec;
return GroupFlagList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GroupFlagList = GroupFlagList;

});
define("Common_CW.model$FundLogoList", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$FundLogoRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var FundLogoList = (function (_super) {
__extends(FundLogoList, _super);
function FundLogoList(defaults) {
_super.apply(this, arguments);
}
FundLogoList.itemType = Config_CSModel.FundLogoRec;
return FundLogoList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.FundLogoList = FundLogoList;

});
define("Common_CW.model$ChoiceOptionItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ChoiceOptionItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ChoiceOptionItemRecordList = (function (_super) {
__extends(ChoiceOptionItemRecordList, _super);
function ChoiceOptionItemRecordList(defaults) {
_super.apply(this, arguments);
}
ChoiceOptionItemRecordList.itemType = Common_CWModel.ChoiceOptionItemRecord;
return ChoiceOptionItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ChoiceOptionItemRecordList = ChoiceOptionItemRecordList;

});
define("Common_CW.model$GutterSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$GutterSizeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GutterSizeRecord = (function (_super) {
__extends(GutterSizeRecord, _super);
function GutterSizeRecord(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecord.attributesToDeclare = function () {
return [
this.attr("GutterSize", "gutterSizeAttr", "GutterSize", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.GutterSizeRec());
}, true, OutSystemsUIModel.GutterSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
GutterSizeRecord.fromStructure = function (str) {
return new GutterSizeRecord(new GutterSizeRecord.RecordClass({
gutterSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GutterSizeRecord._isAnonymousRecord = true;
GutterSizeRecord.UniqueId = "a5018402-fa6c-90c5-e826-e54b2748cedc";
GutterSizeRecord.init();
return GutterSizeRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.GutterSizeRecord = GutterSizeRecord;

});
define("Common_CW.model$MenuItemsList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$MenuItemsRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var MenuItemsList = (function (_super) {
__extends(MenuItemsList, _super);
function MenuItemsList(defaults) {
_super.apply(this, arguments);
}
MenuItemsList.itemType = Common_CWModel.MenuItemsRec;
return MenuItemsList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.MenuItemsList = MenuItemsList;

});
define("Common_CW.model$SearchIndividuals_APIResponseList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$SearchIndividuals_APIResponseRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchIndividuals_APIResponseList = (function (_super) {
__extends(SearchIndividuals_APIResponseList, _super);
function SearchIndividuals_APIResponseList(defaults) {
_super.apply(this, arguments);
}
SearchIndividuals_APIResponseList.itemType = APIGateway_ISModel.SearchIndividuals_APIResponseRec;
return SearchIndividuals_APIResponseList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchIndividuals_APIResponseList = SearchIndividuals_APIResponseList;

});
define("Common_CW.model$PhoneNumberItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PhoneNumberItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PhoneNumberItemRecordList = (function (_super) {
__extends(PhoneNumberItemRecordList, _super);
function PhoneNumberItemRecordList(defaults) {
_super.apply(this, arguments);
}
PhoneNumberItemRecordList.itemType = Common_CWModel.PhoneNumberItemRecord;
return PhoneNumberItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PhoneNumberItemRecordList = PhoneNumberItemRecordList;

});
define("Common_CW.model$ReferenceDataReferenceDataPropertyRecord", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$ReferenceDataRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS", "Config_CS.model$ReferenceDataPropertyRec"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataReferenceDataPropertyRecord = (function (_super) {
__extends(ReferenceDataReferenceDataPropertyRecord, _super);
function ReferenceDataReferenceDataPropertyRecord(defaults) {
_super.apply(this, arguments);
}
ReferenceDataReferenceDataPropertyRecord.attributesToDeclare = function () {
return [
this.attr("ReferenceData", "referenceDataAttr", "ReferenceData", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataRec());
}, true, Config_CSModel.ReferenceDataRec), 
this.attr("ReferenceDataProperty", "referenceDataPropertyAttr", "ReferenceDataProperty", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Config_CSModel.ReferenceDataPropertyRec());
}, true, Config_CSModel.ReferenceDataPropertyRec)
].concat(_super.attributesToDeclare.call(this));
};
ReferenceDataReferenceDataPropertyRecord._isAnonymousRecord = true;
ReferenceDataReferenceDataPropertyRecord.UniqueId = "b08e399d-b021-24f4-d62d-a5a358106b0f";
ReferenceDataReferenceDataPropertyRecord.init();
return ReferenceDataReferenceDataPropertyRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ReferenceDataReferenceDataPropertyRecord = ReferenceDataReferenceDataPropertyRecord;

});
define("Common_CW.model$NotificationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$NotificationRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var NotificationRecordList = (function (_super) {
__extends(NotificationRecordList, _super);
function NotificationRecordList(defaults) {
_super.apply(this, arguments);
}
NotificationRecordList.itemType = Common_CWModel.NotificationRecord;
return NotificationRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.NotificationRecordList = NotificationRecordList;

});
define("Common_CW.model$ReadReceiptRecord", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model", "Common_CW.model", "PHICore_Notification.model$ReadReceiptRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_Notification"], function (exports, OutSystems, PHICore_NotificationModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReadReceiptRecord = (function (_super) {
__extends(ReadReceiptRecord, _super);
function ReadReceiptRecord(defaults) {
_super.apply(this, arguments);
}
ReadReceiptRecord.attributesToDeclare = function () {
return [
this.attr("ReadReceipt", "readReceiptAttr", "ReadReceipt", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICore_NotificationModel.ReadReceiptRec());
}, true, PHICore_NotificationModel.ReadReceiptRec)
].concat(_super.attributesToDeclare.call(this));
};
ReadReceiptRecord.fromStructure = function (str) {
return new ReadReceiptRecord(new ReadReceiptRecord.RecordClass({
readReceiptAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ReadReceiptRecord._isAnonymousRecord = true;
ReadReceiptRecord.UniqueId = "dd2c3f0d-90d0-ff51-03da-6f09f86d6b53";
ReadReceiptRecord.init();
return ReadReceiptRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ReadReceiptRecord = ReadReceiptRecord;

});
define("Common_CW.model$ReadReceiptRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ReadReceiptRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ReadReceiptRecordList = (function (_super) {
__extends(ReadReceiptRecordList, _super);
function ReadReceiptRecordList(defaults) {
_super.apply(this, arguments);
}
ReadReceiptRecordList.itemType = Common_CWModel.ReadReceiptRecord;
return ReadReceiptRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReadReceiptRecordList = ReadReceiptRecordList;

});
define("Common_CW.model$SearchList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SearchRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SearchList = (function (_super) {
__extends(SearchList, _super);
function SearchList(defaults) {
_super.apply(this, arguments);
}
SearchList.itemType = Common_CWModel.SearchRec;
return SearchList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SearchList = SearchList;

});
define("Common_CW.model$ListNavigationList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ListNavigationRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ListNavigationList = (function (_super) {
__extends(ListNavigationList, _super);
function ListNavigationList(defaults) {
_super.apply(this, arguments);
}
ListNavigationList.itemType = Common_CWModel.ListNavigationRec;
return ListNavigationList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ListNavigationList = ListNavigationList;

});
define("Common_CW.model$FundLogoRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$FundLogoRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var FundLogoRecordList = (function (_super) {
__extends(FundLogoRecordList, _super);
function FundLogoRecordList(defaults) {
_super.apply(this, arguments);
}
FundLogoRecordList.itemType = Common_CWModel.FundLogoRecord;
return FundLogoRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.FundLogoRecordList = FundLogoRecordList;

});
define("Common_CW.model$TenantConfigRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TenantConfigRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantConfigRecordList = (function (_super) {
__extends(TenantConfigRecordList, _super);
function TenantConfigRecordList(defaults) {
_super.apply(this, arguments);
}
TenantConfigRecordList.itemType = Common_CWModel.TenantConfigRecord;
return TenantConfigRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TenantConfigRecordList = TenantConfigRecordList;

});
define("Common_CW.model$GroupFlagRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$GroupFlagRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagRecordList = (function (_super) {
__extends(GroupFlagRecordList, _super);
function GroupFlagRecordList(defaults) {
_super.apply(this, arguments);
}
GroupFlagRecordList.itemType = Common_CWModel.GroupFlagRecord;
return GroupFlagRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GroupFlagRecordList = GroupFlagRecordList;

});
define("Common_CW.model$PHIFlagList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PHIFlagRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PHIFlagList = (function (_super) {
__extends(PHIFlagList, _super);
function PHIFlagList(defaults) {
_super.apply(this, arguments);
}
PHIFlagList.itemType = APIGateway_ISModel.PHIFlagRec;
return PHIFlagList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PHIFlagList = PHIFlagList;

});
define("Common_CW.model$AuditFilterRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$AuditFilterRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var AuditFilterRecordList = (function (_super) {
__extends(AuditFilterRecordList, _super);
function AuditFilterRecordList(defaults) {
_super.apply(this, arguments);
}
AuditFilterRecordList.itemType = Common_CWModel.AuditFilterRecord;
return AuditFilterRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AuditFilterRecordList = AuditFilterRecordList;

});
define("Common_CW.model$PromptItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$PromptItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PromptItemList = (function (_super) {
__extends(PromptItemList, _super);
function PromptItemList(defaults) {
_super.apply(this, arguments);
}
PromptItemList.itemType = APIGateway_ISModel.PromptItemRec;
return PromptItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PromptItemList = PromptItemList;

});
define("Common_CW.model$ErrorMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ErrorMessageRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecordList = (function (_super) {
__extends(ErrorMessageRecordList, _super);
function ErrorMessageRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecordList.itemType = Common_CWModel.ErrorMessageRecord;
return ErrorMessageRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ErrorMessageRecordList = ErrorMessageRecordList;

});
define("Common_CW.model$FlagItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$FlagItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var FlagItemRecordList = (function (_super) {
__extends(FlagItemRecordList, _super);
function FlagItemRecordList(defaults) {
_super.apply(this, arguments);
}
FlagItemRecordList.itemType = Common_CWModel.FlagItemRecord;
return FlagItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.FlagItemRecordList = FlagItemRecordList;

});
define("Common_CW.model$ListNavigationRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ListNavigationRec"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ListNavigationRecord = (function (_super) {
__extends(ListNavigationRecord, _super);
function ListNavigationRecord(defaults) {
_super.apply(this, arguments);
}
ListNavigationRecord.attributesToDeclare = function () {
return [
this.attr("ListNavigation", "listNavigationAttr", "ListNavigation", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Common_CWModel.ListNavigationRec());
}, true, Common_CWModel.ListNavigationRec)
].concat(_super.attributesToDeclare.call(this));
};
ListNavigationRecord.fromStructure = function (str) {
return new ListNavigationRecord(new ListNavigationRecord.RecordClass({
listNavigationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ListNavigationRecord._isAnonymousRecord = true;
ListNavigationRecord.UniqueId = "c0eecaf4-7a32-e115-25c9-ecf287c27949";
ListNavigationRecord.init();
return ListNavigationRecord;
})(OS.DataTypes.GenericRecord);
Common_CWModel.ListNavigationRecord = ListNavigationRecord;

});
define("Common_CW.model$EntityActionResultList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CS.model", "Common_CW.model", "Common_CS.model$EntityActionResultRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Common_CS"], function (exports, OutSystems, Common_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionResultList = (function (_super) {
__extends(EntityActionResultList, _super);
function EntityActionResultList(defaults) {
_super.apply(this, arguments);
}
EntityActionResultList.itemType = Common_CSModel.EntityActionResultRec;
return EntityActionResultList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityActionResultList = EntityActionResultList;

});
define("Common_CW.model$ListNavigationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ListNavigationRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ListNavigationRecordList = (function (_super) {
__extends(ListNavigationRecordList, _super);
function ListNavigationRecordList(defaults) {
_super.apply(this, arguments);
}
ListNavigationRecordList.itemType = Common_CWModel.ListNavigationRecord;
return ListNavigationRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ListNavigationRecordList = ListNavigationRecordList;

});
define("Common_CW.model$StepsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$StepsRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var StepsList = (function (_super) {
__extends(StepsList, _super);
function StepsList(defaults) {
_super.apply(this, arguments);
}
StepsList.itemType = OutSystemsUIModel.StepsRec;
return StepsList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.StepsList = StepsList;

});
define("Common_CW.model$EntityActionResultRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$EntityActionResultRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var EntityActionResultRecordList = (function (_super) {
__extends(EntityActionResultRecordList, _super);
function EntityActionResultRecordList(defaults) {
_super.apply(this, arguments);
}
EntityActionResultRecordList.itemType = Common_CWModel.EntityActionResultRecord;
return EntityActionResultRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EntityActionResultRecordList = EntityActionResultRecordList;

});
define("Common_CW.model$ReferenceDataPropertyList", ["exports", "OutSystems/ClientRuntime/Main", "Config_CS.model", "Common_CW.model", "Config_CS.model$ReferenceDataPropertyRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$Config_CS"], function (exports, OutSystems, Config_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataPropertyList = (function (_super) {
__extends(ReferenceDataPropertyList, _super);
function ReferenceDataPropertyList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataPropertyList.itemType = Config_CSModel.ReferenceDataPropertyRec;
return ReferenceDataPropertyList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReferenceDataPropertyList = ReferenceDataPropertyList;

});
define("Common_CW.model$ColorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$ColorRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ColorList = (function (_super) {
__extends(ColorList, _super);
function ColorList(defaults) {
_super.apply(this, arguments);
}
ColorList.itemType = OutSystemsUIModel.ColorRec;
return ColorList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ColorList = ColorList;

});
define("Common_CW.model$GutterSizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$GutterSizeRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var GutterSizeList = (function (_super) {
__extends(GutterSizeList, _super);
function GutterSizeList(defaults) {
_super.apply(this, arguments);
}
GutterSizeList.itemType = OutSystemsUIModel.GutterSizeRec;
return GutterSizeList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GutterSizeList = GutterSizeList;

});
define("Common_CW.model$EmailItemList", ["exports", "OutSystems/ClientRuntime/Main", "APIGateway_IS.model", "Common_CW.model", "APIGateway_IS.model$EmailItemRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$APIGateway_IS"], function (exports, OutSystems, APIGateway_ISModel, Common_CWModel) {
var OS = OutSystems.Internal;
var EmailItemList = (function (_super) {
__extends(EmailItemList, _super);
function EmailItemList(defaults) {
_super.apply(this, arguments);
}
EmailItemList.itemType = APIGateway_ISModel.EmailItemRec;
return EmailItemList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.EmailItemList = EmailItemList;

});
define("Common_CW.model$TenantList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$TenantRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var TenantList = (function (_super) {
__extends(TenantList, _super);
function TenantList(defaults) {
_super.apply(this, arguments);
}
TenantList.itemType = ServiceCenterModel.TenantRec;
return TenantList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TenantList = TenantList;

});
define("Common_CW.model$PositionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "Common_CW.model", "OutSystemsUI.model$PositionRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, Common_CWModel) {
var OS = OutSystems.Internal;
var PositionList = (function (_super) {
__extends(PositionList, _super);
function PositionList(defaults) {
_super.apply(this, arguments);
}
PositionList.itemType = OutSystemsUIModel.PositionRec;
return PositionList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PositionList = PositionList;

});
define("Common_CW.model$Group_UserList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$Group_UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var Group_UserList = (function (_super) {
__extends(Group_UserList, _super);
function Group_UserList(defaults) {
_super.apply(this, arguments);
}
Group_UserList.itemType = ServiceCenterModel.Group_UserRec;
return Group_UserList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.Group_UserList = Group_UserList;

});
define("Common_CW.model$ReadReceiptList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model", "Common_CW.model", "PHICore_Notification.model$ReadReceiptRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_Notification"], function (exports, OutSystems, PHICore_NotificationModel, Common_CWModel) {
var OS = OutSystems.Internal;
var ReadReceiptList = (function (_super) {
__extends(ReadReceiptList, _super);
function ReadReceiptList(defaults) {
_super.apply(this, arguments);
}
ReadReceiptList.itemType = PHICore_NotificationModel.ReadReceiptRec;
return ReadReceiptList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReadReceiptList = ReadReceiptList;

});
define("Common_CW.model$AccessRequestStatusList", ["exports", "OutSystems/ClientRuntime/Main", "AccessControl_CS.model", "Common_CW.model", "AccessControl_CS.model$AccessRequestStatusRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$AccessControl_CS"], function (exports, OutSystems, AccessControl_CSModel, Common_CWModel) {
var OS = OutSystems.Internal;
var AccessRequestStatusList = (function (_super) {
__extends(AccessRequestStatusList, _super);
function AccessRequestStatusList(defaults) {
_super.apply(this, arguments);
}
AccessRequestStatusList.itemType = AccessControl_CSModel.AccessRequestStatusRec;
return AccessRequestStatusList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.AccessRequestStatusList = AccessRequestStatusList;

});
define("Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList = (function (_super) {
__extends(GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList, _super);
function GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList(defaults) {
_super.apply(this, arguments);
}
GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList.itemType = Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecord;
return GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList = GroupFlagGroup_UserReferenceDataReferenceDataPropertyBooleanBooleanRecordList;

});
define("Common_CW.model$ReferenceDataReferenceDataPropertyRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$ReferenceDataReferenceDataPropertyRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var ReferenceDataReferenceDataPropertyRecordList = (function (_super) {
__extends(ReferenceDataReferenceDataPropertyRecordList, _super);
function ReferenceDataReferenceDataPropertyRecordList(defaults) {
_super.apply(this, arguments);
}
ReferenceDataReferenceDataPropertyRecordList.itemType = Common_CWModel.ReferenceDataReferenceDataPropertyRecord;
return ReferenceDataReferenceDataPropertyRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.ReferenceDataReferenceDataPropertyRecordList = ReferenceDataReferenceDataPropertyRecordList;

});
define("Common_CW.model$SLARecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$SLARecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var SLARecordList = (function (_super) {
__extends(SLARecordList, _super);
function SLARecordList(defaults) {
_super.apply(this, arguments);
}
SLARecordList.itemType = Common_CWModel.SLARecord;
return SLARecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.SLARecordList = SLARecordList;

});
define("Common_CW.model$StepsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$StepsRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var StepsRecordList = (function (_super) {
__extends(StepsRecordList, _super);
function StepsRecordList(defaults) {
_super.apply(this, arguments);
}
StepsRecordList.itemType = Common_CWModel.StepsRecord;
return StepsRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.StepsRecordList = StepsRecordList;

});
define("Common_CW.model$PolicyRoleItem2RecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$PolicyRoleItem2Record"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var PolicyRoleItem2RecordList = (function (_super) {
__extends(PolicyRoleItem2RecordList, _super);
function PolicyRoleItem2RecordList(defaults) {
_super.apply(this, arguments);
}
PolicyRoleItem2RecordList.itemType = Common_CWModel.PolicyRoleItem2Record;
return PolicyRoleItem2RecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.PolicyRoleItem2RecordList = PolicyRoleItem2RecordList;

});
define("Common_CW.model$GutterSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$GutterSizeRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var GutterSizeRecordList = (function (_super) {
__extends(GutterSizeRecordList, _super);
function GutterSizeRecordList(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecordList.itemType = Common_CWModel.GutterSizeRecord;
return GutterSizeRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GutterSizeRecordList = GutterSizeRecordList;

});
define("Common_CW.model$UserList", ["exports", "OutSystems/ClientRuntime/Main", "ServiceCenter.model", "Common_CW.model", "ServiceCenter.model$UserRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$ServiceCenter"], function (exports, OutSystems, ServiceCenterModel, Common_CWModel) {
var OS = OutSystems.Internal;
var UserList = (function (_super) {
__extends(UserList, _super);
function UserList(defaults) {
_super.apply(this, arguments);
}
UserList.itemType = ServiceCenterModel.UserRec;
return UserList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.UserList = UserList;

});
define("Common_CW.model$NotificationList", ["exports", "OutSystems/ClientRuntime/Main", "PHICore_Notification.model", "Common_CW.model", "PHICore_Notification.model$NotificationRec", "Common_CW.referencesHealth", "Common_CW.referencesHealth$PHICore_Notification"], function (exports, OutSystems, PHICore_NotificationModel, Common_CWModel) {
var OS = OutSystems.Internal;
var NotificationList = (function (_super) {
__extends(NotificationList, _super);
function NotificationList(defaults) {
_super.apply(this, arguments);
}
NotificationList.itemType = PHICore_NotificationModel.NotificationRec;
return NotificationList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.NotificationList = NotificationList;

});
define("Common_CW.model$GetEntityFlags_APIResponseRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$GetEntityFlags_APIResponseRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var GetEntityFlags_APIResponseRecordList = (function (_super) {
__extends(GetEntityFlags_APIResponseRecordList, _super);
function GetEntityFlags_APIResponseRecordList(defaults) {
_super.apply(this, arguments);
}
GetEntityFlags_APIResponseRecordList.itemType = Common_CWModel.GetEntityFlags_APIResponseRecord;
return GetEntityFlags_APIResponseRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.GetEntityFlags_APIResponseRecordList = GetEntityFlags_APIResponseRecordList;

});
define("Common_CW.model$TextTextPromptItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.model$TextTextPromptItemRecord"], function (exports, OutSystems, Common_CWModel) {
var OS = OutSystems.Internal;
var TextTextPromptItemRecordList = (function (_super) {
__extends(TextTextPromptItemRecordList, _super);
function TextTextPromptItemRecordList(defaults) {
_super.apply(this, arguments);
}
TextTextPromptItemRecordList.itemType = Common_CWModel.TextTextPromptItemRecord;
return TextTextPromptItemRecordList;
})(OS.DataTypes.GenericRecordList);
Common_CWModel.TextTextPromptItemRecordList = TextTextPromptItemRecordList;

});
define("Common_CW.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Common_CWModel = exports;
Object.defineProperty(Common_CWModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["edf2e844-43c5-4031-b79d-bb4915c126c1"];
}
});

Common_CWModel.staticEntities = {};
Common_CWModel.staticEntities.menuItems = {};
var getMenuItemsRecord = function (record) {
return Common_CWModel.module.staticEntities["0372d2ce-e6f0-4d4b-adda-e760e2f026f7"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.menuItems, "audit", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("0144003e-3691-402b-9924-f85e6592a35c"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "batchProcess", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("1a1c9495-7f48-4216-93c0-aeda9c2a5094"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "fundsHAMBS", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("2e7b3581-9ea6-4a7a-b8dc-2bc838481ec6"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "fundAdministration", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("484d3ae0-f35a-4383-9344-773976b7de06"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "dashboard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("9b2480ad-4e58-4940-a33c-bc1eae5fcb4f"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "referenceData", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("c85adb70-628d-48b3-ba42-6eb9e60f74a9"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.menuItems, "cases", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getMenuItemsRecord("e78850f2-16ab-418c-8f8b-a20de6bba28b"));
}
});

Common_CWModel.staticEntities.accessRequestStatus = {};
var getAccessRequestStatusRecord = function (record) {
return OS.ApplicationInfo.getModules()["191b1d06-22aa-43f8-a6be-9d8f4600535d"].staticEntities["58694639-377c-43bd-a7f3-339a7a6edea2"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.accessRequestStatus, "expired", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getAccessRequestStatusRecord("1ec905eb-48f2-4348-9f02-07bac7a7e72b"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.accessRequestStatus, "pending", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getAccessRequestStatusRecord("36b010bd-5b07-4f96-abc2-dd1d04bc1bff"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.accessRequestStatus, "rejected", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getAccessRequestStatusRecord("3c7c2cb4-d339-44c7-9dff-f71025d1d1b3"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.accessRequestStatus, "approved", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getAccessRequestStatusRecord("52a36828-1b0e-4473-93ae-5db2673bbe6e"));
}
});

Common_CWModel.staticEntities.sLA = {};
var getSLARecord = function (record) {
return OS.ApplicationInfo.getModules()["4293487a-0124-4d81-ba3f-43747b129ad9"].staticEntities["a783cee4-9642-47ca-933f-1c3406201c24"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.sLA, "onTrack", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSLARecord("1a6bc65a-8f5d-4464-a863-c4321bdabf00"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.sLA, "offTrack", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSLARecord("6176987b-8b5a-442b-824d-63f0c497fc4a"));
}
});

Object.defineProperty(Common_CWModel.staticEntities.sLA, "needsAttention", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getSLARecord("ad5913f4-f673-4ce2-910f-487c7d223187"));
}
});

Common_CWModel.staticEntities.size = {};
var getSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["1ac110b4-8964-470b-a6b2-81ae4a6b5bde"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.size, "medium", {
get: function () {
return getSizeRecord("0f4cba2c-32d2-4bef-b0e8-0ecd7eadbffa");
}
});

Object.defineProperty(Common_CWModel.staticEntities.size, "small", {
get: function () {
return getSizeRecord("9133cb8a-ca17-4e39-a9fd-4a07cf123c82");
}
});

Common_CWModel.staticEntities.gutterSize = {};
var getGutterSizeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["2e81a1e8-4fa4-4bd0-a945-65352999b0be"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "xXLarge", {
get: function () {
return getGutterSizeRecord("087ea4c4-96ff-4fc5-87c9-70e35c61fe6e");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "medium", {
get: function () {
return getGutterSizeRecord("12874371-fb77-4707-afda-cdddbba81173");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "none", {
get: function () {
return getGutterSizeRecord("1a6cb2a2-b448-4f08-ba92-5bd24d30a422");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "extraLarge", {
get: function () {
return getGutterSizeRecord("8d669ecd-b220-4b80-b57b-4700987734dd");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "small", {
get: function () {
return getGutterSizeRecord("96f816b9-2511-49f9-8e9c-c6ab4ff8683e");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "large", {
get: function () {
return getGutterSizeRecord("a9dce78b-0487-49ef-b5c0-d3054293816b");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "base", {
get: function () {
return getGutterSizeRecord("b7549354-102c-45e6-8c2e-b171c6f589c5");
}
});

Object.defineProperty(Common_CWModel.staticEntities.gutterSize, "extraSmall", {
get: function () {
return getGutterSizeRecord("b8734df5-7557-4609-a566-cf5c35a6dade");
}
});

Common_CWModel.staticEntities.breakColumns = {};
var getBreakColumnsRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["68f74593-a5c4-4e65-858b-f44211eaf122"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.breakColumns, "none", {
get: function () {
return getBreakColumnsRecord("0712904e-03be-4b5f-9b9e-ecc640f84913");
}
});

Object.defineProperty(Common_CWModel.staticEntities.breakColumns, "first", {
get: function () {
return getBreakColumnsRecord("3d55ca44-9c70-4bd4-bf96-7d0a7ec1c3b6");
}
});

Object.defineProperty(Common_CWModel.staticEntities.breakColumns, "all", {
get: function () {
return getBreakColumnsRecord("63e0af38-8b6c-4970-b96a-acd8c6d863e4");
}
});

Object.defineProperty(Common_CWModel.staticEntities.breakColumns, "middle", {
get: function () {
return getBreakColumnsRecord("694d423c-ce17-45a1-9993-cb57c30ec674");
}
});

Object.defineProperty(Common_CWModel.staticEntities.breakColumns, "last", {
get: function () {
return getBreakColumnsRecord("6c98320a-c178-4925-b42b-7165ed805ea0");
}
});

Common_CWModel.staticEntities.shape = {};
var getShapeRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["6fe168a9-c16d-4cdb-9b6f-a9e6c6b79326"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.shape, "sharp", {
get: function () {
return getShapeRecord("94deb1f5-6153-4438-92ad-cedea3c1f6f0");
}
});

Object.defineProperty(Common_CWModel.staticEntities.shape, "softRounded", {
get: function () {
return getShapeRecord("d1093539-d77d-439d-8d53-03d2e0053a52");
}
});

Object.defineProperty(Common_CWModel.staticEntities.shape, "rounded", {
get: function () {
return getShapeRecord("f20c2269-270a-43b2-ba29-bd8fbff2519f");
}
});

Common_CWModel.staticEntities.position = {};
var getPositionRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["83c073e8-bac2-4122-9772-aa6e122a5d36"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.position, "top", {
get: function () {
return getPositionRecord("3bbcac35-309e-49a8-bf1b-a3c66e1ef3cd");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "left", {
get: function () {
return getPositionRecord("4d70c81a-67bd-4a1f-a21a-c6aa13d0f364");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "bottomRight", {
get: function () {
return getPositionRecord("73459c44-0160-4454-8ad0-c9bd44778a61");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "bottomLeft", {
get: function () {
return getPositionRecord("7352570c-243a-4f05-b6d1-608495931118");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "right", {
get: function () {
return getPositionRecord("bf43697b-2483-4855-a6c2-0a786bab472f");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "topLeft", {
get: function () {
return getPositionRecord("c1d22c62-5a36-4d69-b188-02d62b8fe7c4");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "topRight", {
get: function () {
return getPositionRecord("d14d8aae-f1c9-4538-a4a9-91a2690e6d92");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "center", {
get: function () {
return getPositionRecord("dcc9ffa2-34a7-4097-86d0-dde224907425");
}
});

Object.defineProperty(Common_CWModel.staticEntities.position, "bottom", {
get: function () {
return getPositionRecord("fb8d90f9-5432-4678-932b-f468c00d3361");
}
});

Common_CWModel.staticEntities.trigger = {};
var getTriggerRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["8f0912ba-c626-4795-90a6-5311e2b970cb"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.trigger, "onClick", {
get: function () {
return getTriggerRecord("19fabbad-c01d-41a3-bdbb-f4f1d87b8042");
}
});

Object.defineProperty(Common_CWModel.staticEntities.trigger, "onHover", {
get: function () {
return getTriggerRecord("b60aa471-1556-46df-bc15-585543a2a05d");
}
});

Common_CWModel.staticEntities.space = {};
var getSpaceRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["8fb3d471-82a4-439c-9cc1-0555dfa91451"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.space, "large", {
get: function () {
return getSpaceRecord("51b55067-e608-49ed-9f00-1faf9e4a694a");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "medium", {
get: function () {
return getSpaceRecord("7340e97f-de64-4337-ad0d-1defcab8adb2");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "xXLarge", {
get: function () {
return getSpaceRecord("823213f8-9df9-4de0-8aba-2b5566e6f87d");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "extraSmall", {
get: function () {
return getSpaceRecord("83adf9ba-fbcf-4ce0-b4a4-bc6330956b89");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "small", {
get: function () {
return getSpaceRecord("919210a5-6b3b-40c9-9a28-b4e2c28a46f8");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "base", {
get: function () {
return getSpaceRecord("f0572ad3-54ac-4755-8c8e-a9004171fcb1");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "extraLarge", {
get: function () {
return getSpaceRecord("f8dafab9-63b9-40b2-9755-f2f8fa3d6e84");
}
});

Object.defineProperty(Common_CWModel.staticEntities.space, "none", {
get: function () {
return getSpaceRecord("fb937b97-bd94-4ba4-80ff-446cb3bdf6ae");
}
});

Common_CWModel.staticEntities.color = {};
var getColorRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["cb6d1da7-26d4-45d9-bc22-9a4c482e6ce2"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.color, "neutral9", {
get: function () {
return getColorRecord("04a6c700-0ae5-44d5-81ce-34ec81d72c1c");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "grape", {
get: function () {
return getColorRecord("0d81324f-81ae-44eb-b81e-cd27ebce7460");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral7", {
get: function () {
return getColorRecord("1434454b-4d44-4ec7-a9ee-8353529b1621");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral10", {
get: function () {
return getColorRecord("1566893e-a30d-405f-878b-e64efdab7f7b");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "teal", {
get: function () {
return getColorRecord("19254415-08b2-4887-a6cf-36433bb1ade0");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "primary", {
get: function () {
return getColorRecord("1df261bf-454e-49a0-951e-87f6077cbbc1");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral4", {
get: function () {
return getColorRecord("20d4e7d1-c296-4853-b584-d2b004ddf9f5");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral8", {
get: function () {
return getColorRecord("31cd8495-438d-4825-8a93-c083bf6f016a");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "indigo", {
get: function () {
return getColorRecord("47b9565a-4f82-4a9d-a543-4aaa707853ac");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "orange", {
get: function () {
return getColorRecord("4d20d5b8-5570-4e18-9345-55772434a9ad");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "lime", {
get: function () {
return getColorRecord("50b20d51-09a6-43df-aa5d-6ae3c99f31e8");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "cyan", {
get: function () {
return getColorRecord("59edafdd-089e-409e-a2d2-78298e55e0f2");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "secondary", {
get: function () {
return getColorRecord("61f545b9-e074-40ee-a884-8102a56d9ee7");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral6", {
get: function () {
return getColorRecord("69c65fbc-5ddc-4e41-afcf-03acff40e7a8");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "yellow", {
get: function () {
return getColorRecord("80145099-0e84-4301-902b-2bd6a933e319");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral2", {
get: function () {
return getColorRecord("8577e423-4296-434f-9ca1-9a18b91e0c29");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral1", {
get: function () {
return getColorRecord("9946980c-176a-4345-90ff-312523579ef0");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral3", {
get: function () {
return getColorRecord("b7447296-c2b5-4d01-883b-b49d25b1c8a6");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "transparent", {
get: function () {
return getColorRecord("b87c59d9-4a95-4567-876d-b978ca413429");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "violet", {
get: function () {
return getColorRecord("bb39306e-ce82-47a7-9c0f-a78f92ff53c6");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "blue", {
get: function () {
return getColorRecord("c1bb8b1b-2f09-4fe9-bec9-eeb243b903d5");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral5", {
get: function () {
return getColorRecord("c1d63249-fde7-4438-b4c9-d445bcfc9257");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "red", {
get: function () {
return getColorRecord("d6c564f5-847a-4155-ba84-91b826bd676f");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "pink", {
get: function () {
return getColorRecord("e9991560-a98c-431e-a583-b707840dc2f3");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "green", {
get: function () {
return getColorRecord("ede4099b-595f-47f0-98ed-583414f4f6bd");
}
});

Object.defineProperty(Common_CWModel.staticEntities.color, "neutral0", {
get: function () {
return getColorRecord("fb934ce5-6b33-4c96-8d40-b06352706a8d");
}
});

Common_CWModel.staticEntities.steps = {};
var getStepsRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["e4dd8e9f-a620-4df5-b619-9b8a771be5a3"][record];
};
Object.defineProperty(Common_CWModel.staticEntities.steps, "next", {
get: function () {
return getStepsRecord("03e9ec31-9b26-4304-b532-29aa077d99ea");
}
});

Object.defineProperty(Common_CWModel.staticEntities.steps, "past", {
get: function () {
return getStepsRecord("5452e8a1-02ca-4ff2-8d74-bff1512fc4a3");
}
});

Object.defineProperty(Common_CWModel.staticEntities.steps, "active", {
get: function () {
return getStepsRecord("dbde9903-8367-49e7-8302-f6758c190844");
}
});

});
