﻿define("PHICore.MainFlow.Dashboard.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "PHICore_Notification.model", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "Common_CW.controller$Check_SP_AssignCaseIndividual", "Common_CW.controller$Check_SP_AssignCaseBulk", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$Check_ViewDashboard", "PHICore.model$SearchFilterRec", "PHICore.model$TextTextTextTextTextTextTextTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$CaseInfoIdentifierRecordList", "PHICore.model$CaseIdentifierRecordList", "PHICore.model$IntegerIntegerIntegerRecord", "PHICore.model$TextTextTextRecord", "OutSystemsUI.model$TabsOptionalConfigsRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TextText2RecordList", "PHICore.model$CaseIdentifierRecord", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore_Notification.model$NotificationRec", "PHICore.referencesHealth$PHICore_Notification", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecordList", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamUserStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$CaseInfoIdentifierRecord", "Common_CW.controller$SetCurrentAsValidURL", "PHICore.model$JoinedFilterRec", "PHICore.model$Dashboard_CasesFilterRec", "PHICore.model$DashboardDropdownSearchTagList", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecord", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecord", "PHICore.model$PriorityCaseSLASubCategoryTeamStatusSLACategoryCaseUserRecordList", "PHICore.model$TeamTeamUserUserRecordList", "PHICore.model$PriorityCaseSLASubCategoryStatusSLACategoryCaseRecordList", "PHICore.model$ReadReceiptNotificationRecordList"], function (OutSystems, PHICoreModel, Common_CWController, OutSystemsUIModel, Common_CSModel, PHICore_NotificationModel) {
var OS = OutSystems.Internal;
var GetTeamsCasesByOwnerUserID_NoFilterAggrRec = (function (_super) {
__extends(GetTeamsCasesByOwnerUserID_NoFilterAggrRec, _super);
function GetTeamsCasesByOwnerUserID_NoFilterAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamsCasesByOwnerUserID_NoFilterAggrRec.RecordListType = PHICoreModel.PriorityCaseSLASubCategoryTeamStatusSLACategoryCaseUserRecordList;
GetTeamsCasesByOwnerUserID_NoFilterAggrRec.init();
return GetTeamsCasesByOwnerUserID_NoFilterAggrRec;
})(OS.Model.AggregateRecord);
var GetTeamsCasesByOwnerUserIDAggrRec = (function (_super) {
__extends(GetTeamsCasesByOwnerUserIDAggrRec, _super);
function GetTeamsCasesByOwnerUserIDAggrRec(defaults) {
_super.apply(this, arguments);
}
GetTeamsCasesByOwnerUserIDAggrRec.RecordListType = PHICoreModel.PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecordList;
GetTeamsCasesByOwnerUserIDAggrRec.init();
return GetTeamsCasesByOwnerUserIDAggrRec;
})(OS.Model.AggregateRecord);
var GetCasesByOwnerUserIDAggrRec = (function (_super) {
__extends(GetCasesByOwnerUserIDAggrRec, _super);
function GetCasesByOwnerUserIDAggrRec(defaults) {
_super.apply(this, arguments);
}
GetCasesByOwnerUserIDAggrRec.RecordListType = PHICoreModel.PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecordList;
GetCasesByOwnerUserIDAggrRec.init();
return GetCasesByOwnerUserIDAggrRec;
})(OS.Model.AggregateRecord);
var GetUserByIdAggrRec = (function (_super) {
__extends(GetUserByIdAggrRec, _super);
function GetUserByIdAggrRec(defaults) {
_super.apply(this, arguments);
}
GetUserByIdAggrRec.RecordListType = PHICoreModel.TeamTeamUserUserRecordList;
GetUserByIdAggrRec.init();
return GetUserByIdAggrRec;
})(OS.Model.AggregateRecord);
var GetApprovalsByOwnerUserId_NoFilterAggrRec = (function (_super) {
__extends(GetApprovalsByOwnerUserId_NoFilterAggrRec, _super);
function GetApprovalsByOwnerUserId_NoFilterAggrRec(defaults) {
_super.apply(this, arguments);
}
GetApprovalsByOwnerUserId_NoFilterAggrRec.RecordListType = PHICoreModel.PriorityCaseInfoCaseSLASubCategoryTeamUserStatusSLACategoryCaseBooleanIntegerRecordList;
GetApprovalsByOwnerUserId_NoFilterAggrRec.init();
return GetApprovalsByOwnerUserId_NoFilterAggrRec;
})(OS.Model.AggregateRecord);
var GetCasesByOwnerUserID_NoFilterAggrRec = (function (_super) {
__extends(GetCasesByOwnerUserID_NoFilterAggrRec, _super);
function GetCasesByOwnerUserID_NoFilterAggrRec(defaults) {
_super.apply(this, arguments);
}
GetCasesByOwnerUserID_NoFilterAggrRec.RecordListType = PHICoreModel.PriorityCaseSLASubCategoryStatusSLACategoryCaseRecordList;
GetCasesByOwnerUserID_NoFilterAggrRec.init();
return GetCasesByOwnerUserID_NoFilterAggrRec;
})(OS.Model.AggregateRecord);
var GetNotificationsWithReadReceiptsAggrRec = (function (_super) {
__extends(GetNotificationsWithReadReceiptsAggrRec, _super);
function GetNotificationsWithReadReceiptsAggrRec(defaults) {
_super.apply(this, arguments);
}
GetNotificationsWithReadReceiptsAggrRec.RecordListType = PHICoreModel.ReadReceiptNotificationRecordList;
GetNotificationsWithReadReceiptsAggrRec.init();
return GetNotificationsWithReadReceiptsAggrRec;
})(OS.Model.AggregateRecord);
var GetApprovalsByOwnerUserIdAggrRec = (function (_super) {
__extends(GetApprovalsByOwnerUserIdAggrRec, _super);
function GetApprovalsByOwnerUserIdAggrRec(defaults) {
_super.apply(this, arguments);
}
GetApprovalsByOwnerUserIdAggrRec.RecordListType = PHICoreModel.PriorityCaseInfoCaseSLASubCategoryTeamUserStatusSLACategoryCaseBooleanIntegerRecordList;
GetApprovalsByOwnerUserIdAggrRec.init();
return GetApprovalsByOwnerUserIdAggrRec;
})(OS.Model.AggregateRecord);

var GetTeamsDataActRec = (function (_super) {
__extends(GetTeamsDataActRec, _super);
function GetTeamsDataActRec(defaults) {
_super.apply(this, arguments);
}
GetTeamsDataActRec.attributesToDeclare = function () {
return [
this.attr("JoinedTeams", "joinedTeamsOut", "JoinedTeams", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsViewApprovals", "isViewApprovalsOut", "IsViewApprovals", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GetTeamsDataActRec.init();
return GetTeamsDataActRec;
})(OS.Model.DataSourceRecord);

var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MaxRecords", "maxRecordsVar", "MaxRecords", true, false, OS.Types.Integer, function () {
return 10;
}, false), 
this.attr("ShowMyCasesFilter", "showMyCasesFilterVar", "ShowMyCasesFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ShowMyTeamCasesFilter", "showMyTeamCasesFilterVar", "ShowMyTeamCasesFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ShowApprovalsFilter", "showApprovalsFilterVar", "ShowApprovalsFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("MyApprovalsSelectAll", "myApprovalsSelectAllVar", "MyApprovalsSelectAll", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SearchFilter_MyCases", "searchFilter_MyCasesVar", "SearchFilter_MyCases", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("SearchFilter_Approvals", "searchFilter_ApprovalsVar", "SearchFilter_Approvals", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("SearchFilter_MyTeamCases", "searchFilter_MyTeamCasesVar", "SearchFilter_MyTeamCases", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("JoinedStrings_MyCases", "joinedStrings_MyCasesVar", "JoinedStrings_MyCases", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextTextTextTextTextTextRecord());
}, false, PHICoreModel.TextTextTextTextTextTextTextTextRecord), 
this.attr("JoinedStrings_MyTeamCases", "joinedStrings_MyTeamCasesVar", "JoinedStrings_MyTeamCases", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextTextTextTextTextTextRecord());
}, false, PHICoreModel.TextTextTextTextTextTextTextTextRecord), 
this.attr("JoinedStrings_Approvals", "joinedStrings_ApprovalsVar", "JoinedStrings_Approvals", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextTextTextTextTextTextRecord());
}, false, PHICoreModel.TextTextTextTextTextTextTextTextRecord), 
this.attr("ShowPopup_Restricted", "showPopup_RestrictedVar", "ShowPopup_Restricted", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ShowPopup_NewStakeholder", "showPopup_NewStakeholderVar", "ShowPopup_NewStakeholder", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("CaseActiveTab", "caseActiveTabVar", "CaseActiveTab", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("ShowAssignTeam", "showAssignTeamVar", "ShowAssignTeam", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SelectedMyCaseList", "selectedMyCaseListVar", "SelectedMyCaseList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseIdentifier1RecordList());
}, false, PHICoreModel.CaseIdentifier1RecordList), 
this.attr("SelectedMyCaseText", "selectedMyCaseTextVar", "SelectedMyCaseText", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("SelectedTeamCaseList", "selectedTeamCaseListVar", "SelectedTeamCaseList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseInfoIdentifierRecordList());
}, false, PHICoreModel.CaseInfoIdentifierRecordList), 
this.attr("SelectedTeamCaseText", "selectedTeamCaseTextVar", "SelectedTeamCaseText", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("SelectedMyApprovalList", "selectedMyApprovalListVar", "SelectedMyApprovalList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseInfoIdentifierRecordList());
}, false, PHICoreModel.CaseInfoIdentifierRecordList), 
this.attr("SelectedMyApprovalText", "selectedMyApprovalTextVar", "SelectedMyApprovalText", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("TeamCaseAllSelected", "teamCaseAllSelectedVar", "TeamCaseAllSelected", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SharedSelectedCases", "sharedSelectedCasesVar", "SharedSelectedCases", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.CaseIdentifierRecordList());
}, false, PHICoreModel.CaseIdentifierRecordList), 
this.attr("ApprovalTableVariables", "approvalTableVariablesVar", "ApprovalTableVariables", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.IntegerIntegerIntegerRecord());
}, false, PHICoreModel.IntegerIntegerIntegerRecord), 
this.attr("MyCasesTableVariables", "myCasesTableVariablesVar", "MyCasesTableVariables", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.IntegerIntegerIntegerRecord());
}, false, PHICoreModel.IntegerIntegerIntegerRecord), 
this.attr("TeamCasesTableVariables", "teamCasesTableVariablesVar", "TeamCasesTableVariables", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.IntegerIntegerIntegerRecord());
}, false, PHICoreModel.IntegerIntegerIntegerRecord), 
this.attr("hasViewCaseRole", "hasViewCaseRoleVar", "hasViewCaseRole", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ShowNotificationDetail", "showNotificationDetailVar", "ShowNotificationDetail", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("RefreshNotificationBell", "refreshNotificationBellVar", "RefreshNotificationBell", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("MyCasesSearch_Original", "myCasesSearch_OriginalVar", "MyCasesSearch_Original", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.TextTextTextRecord());
}, false, PHICoreModel.TextTextTextRecord), 
this.attr("CaseNumberSearch", "caseNumberSearchVar", "CaseNumberSearch", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("NotificationDescription", "notificationDescriptionVar", "NotificationDescription", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("EmptyFilter", "emptyFilterVar", "EmptyFilter", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.SearchFilterRec());
}, false, PHICoreModel.SearchFilterRec), 
this.attr("IsLoadingFilter", "isLoadingFilterVar", "IsLoadingFilter", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsLoadingExportMyTeamCases", "isLoadingExportMyTeamCasesVar", "IsLoadingExportMyTeamCases", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ActiveCaseTab", "activeCaseTabIn", "ActiveCaseTab", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_activeCaseTabInDataFetchStatus", "_activeCaseTabInDataFetchStatus", "_activeCaseTabInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetTeamsCasesByOwnerUserID_NoFilter", "getTeamsCasesByOwnerUserID_NoFilterAggr", "getTeamsCasesByOwnerUserID_NoFilterAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamsCasesByOwnerUserID_NoFilterAggrRec());
}, true, GetTeamsCasesByOwnerUserID_NoFilterAggrRec), 
this.attr("GetTeamsCasesByOwnerUserID", "getTeamsCasesByOwnerUserIDAggr", "getTeamsCasesByOwnerUserIDAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamsCasesByOwnerUserIDAggrRec());
}, true, GetTeamsCasesByOwnerUserIDAggrRec), 
this.attr("GetCasesByOwnerUserID", "getCasesByOwnerUserIDAggr", "getCasesByOwnerUserIDAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCasesByOwnerUserIDAggrRec());
}, true, GetCasesByOwnerUserIDAggrRec), 
this.attr("GetUserById", "getUserByIdAggr", "getUserByIdAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetUserByIdAggrRec());
}, true, GetUserByIdAggrRec), 
this.attr("GetApprovalsByOwnerUserId_NoFilter", "getApprovalsByOwnerUserId_NoFilterAggr", "getApprovalsByOwnerUserId_NoFilterAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetApprovalsByOwnerUserId_NoFilterAggrRec());
}, true, GetApprovalsByOwnerUserId_NoFilterAggrRec), 
this.attr("GetCasesByOwnerUserID_NoFilter", "getCasesByOwnerUserID_NoFilterAggr", "getCasesByOwnerUserID_NoFilterAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetCasesByOwnerUserID_NoFilterAggrRec());
}, true, GetCasesByOwnerUserID_NoFilterAggrRec), 
this.attr("GetNotificationsWithReadReceipts", "getNotificationsWithReadReceiptsAggr", "getNotificationsWithReadReceiptsAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetNotificationsWithReadReceiptsAggrRec());
}, true, GetNotificationsWithReadReceiptsAggrRec), 
this.attr("GetApprovalsByOwnerUserId", "getApprovalsByOwnerUserIdAggr", "getApprovalsByOwnerUserIdAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetApprovalsByOwnerUserIdAggrRec());
}, true, GetApprovalsByOwnerUserIdAggrRec), 
this.attr("GetTeams", "getTeamsDataAct", "getTeamsDataAct", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetTeamsDataActRec());
}, true, GetTeamsDataActRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_MyCaseNumber: OS.Model.ValidationWidgetRecord,
Input_MyCaseNumber2: OS.Model.ValidationWidgetRecord,
MyCaseSelectAll: OS.Model.ValidationWidgetRecord,
MyCaseSelectAll2: OS.Model.ValidationWidgetRecord,
MyCaseSelect: OS.Model.ValidationWidgetRecord,
MyCaseSelect2: OS.Model.ValidationWidgetRecord,
TeamCaseSelectAll: OS.Model.ValidationWidgetRecord,
TeamCaseSelectAll2: OS.Model.ValidationWidgetRecord,
TeamCaseSelect: OS.Model.ValidationWidgetRecord,
TeamCaseSelect2: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("ActiveCaseTab" in inputs) {
this.variables.activeCaseTabIn = OS.DataConversion.ServerDataConverter.from(inputs.ActiveCaseTab, OS.Types.Integer);
}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "MainFlow.Dashboard");
});
define("PHICore.MainFlow.Dashboard.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "PHICore_Notification.model", "react", "OutSystems/ReactView/Main", "PHICore.MainFlow.Dashboard.mvc$model", "PHICore.MainFlow.Dashboard.mvc$controller", "PHICore.clientVariables", "PHICore.Common_Widgets.BaseLayout.mvc$view", "OutSystems/ReactWidgets/Main", "Common_CW.PHICore_CW.GlobalSearchBox.mvc$view", "OutSystemsUI.Adaptive.ColumnsMediumRight.mvc$view", "OutSystemsUI.Adaptive.Columns3.mvc$view", "Common_CW.PHICore_CW.DashboardCard.mvc$view", "OutSystemsUI.Content.Tooltip.mvc$view", "OutSystemsUI.Navigation.Tabs.mvc$view", "OutSystemsUI.Navigation.TabsHeaderItem.mvc$view", "OutSystemsUI.Numbers.Badge.mvc$view", "Common_CW.PHICore_CW.TabExport.mvc$view", "OutSystemsUI.Utilities.Separator.mvc$view", "PHICore_TH.Common.TabAssign.mvc$view", "PHICore_TH.Common.TabHeaderFilter.mvc$view", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "InputMaskReactive.InputMask.InputPatternMask.mvc$view", "OutSystemsUI.Navigation.TabsContentItem.mvc$view", "PHICore.Common_Widgets.CaseNumber.mvc$view", "PHICore.Common_Widgets.SLAPill.mvc$view", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$view", "Common_CW.PHICore_CW.Pagination.mvc$view", "OutSystemsUI.Adaptive.Columns2.mvc$view", "PHICore.Common_Widgets.CaseStatusGraphCard.mvc$view", "PHICore.Common_Widgets.SLAStatusCard.mvc$view", "OutSystemsUI.Content.Card.mvc$view", "PHICore.Common_Widgets.SearchFilterPopup.mvc$view", "Common_CW.PHICore_CW.RestrictedPopup.mvc$view", "PHICore.Stakeholder.NewStakeholder_Popup.mvc$view", "PHICore.Common_Widgets.AssignCaseTeam_Popup.mvc$view", "Common_CW.PHICore_CW.NotificationDetail.mvc$view", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "Common_CW.controller$Check_SP_AssignCaseIndividual", "Common_CW.controller$Check_SP_AssignCaseBulk", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$Check_ViewDashboard", "PHICore.model$SearchFilterRec", "PHICore.model$TextTextTextTextTextTextTextTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$CaseInfoIdentifierRecordList", "PHICore.model$CaseIdentifierRecordList", "PHICore.model$IntegerIntegerIntegerRecord", "PHICore.model$TextTextTextRecord", "OutSystemsUI.model$TabsOptionalConfigsRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TextText2RecordList", "PHICore.model$CaseIdentifierRecord", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore_Notification.model$NotificationRec", "PHICore.referencesHealth$PHICore_Notification", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecordList", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamUserStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$CaseInfoIdentifierRecord", "Common_CW.controller$SetCurrentAsValidURL", "PHICore.model$JoinedFilterRec", "PHICore.model$Dashboard_CasesFilterRec", "PHICore.model$DashboardDropdownSearchTagList", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecord", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecord", "PHICore.model$PriorityCaseSLASubCategoryTeamStatusSLACategoryCaseUserRecordList", "PHICore.model$TeamTeamUserUserRecordList", "PHICore.model$PriorityCaseSLASubCategoryStatusSLACategoryCaseRecordList", "PHICore.model$ReadReceiptNotificationRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, Common_CSModel, PHICore_NotificationModel, React, OSView, PHICore_MainFlow_Dashboard_mvc_model, PHICore_MainFlow_Dashboard_mvc_controller, PHICoreClientVariables, PHICore_Common_Widgets_BaseLayout_mvc_view, OSWidgets, Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, OutSystemsUI_Adaptive_Columns3_mvc_view, Common_CW_PHICore_CW_DashboardCard_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, OutSystemsUI_Navigation_Tabs_mvc_view, OutSystemsUI_Navigation_TabsHeaderItem_mvc_view, OutSystemsUI_Numbers_Badge_mvc_view, Common_CW_PHICore_CW_TabExport_mvc_view, OutSystemsUI_Utilities_Separator_mvc_view, PHICore_TH_Common_TabAssign_mvc_view, PHICore_TH_Common_TabHeaderFilter_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, InputMaskReactive_InputMask_InputPatternMask_mvc_view, OutSystemsUI_Navigation_TabsContentItem_mvc_view, PHICore_Common_Widgets_CaseNumber_mvc_view, PHICore_Common_Widgets_SLAPill_mvc_view, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, Common_CW_PHICore_CW_Pagination_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, PHICore_Common_Widgets_CaseStatusGraphCard_mvc_view, PHICore_Common_Widgets_SLAStatusCard_mvc_view, OutSystemsUI_Content_Card_mvc_view, PHICore_Common_Widgets_SearchFilterPopup_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view, PHICore_Stakeholder_NewStakeholder_Popup_mvc_view, PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_view, Common_CW_PHICore_CW_NotificationDetail_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "MainFlow.Dashboard";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/PHICore_TH.HambsComp_th.css", "css/PHICore_TH.HAMBS_THEME.css", "css/PHICore.HAMBSReactive.css", "css/PHICore.HAMBSReactive.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [PHICore_Common_Widgets_BaseLayout_mvc_view, Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, OutSystemsUI_Adaptive_Columns3_mvc_view, Common_CW_PHICore_CW_DashboardCard_mvc_view, OutSystemsUI_Content_Tooltip_mvc_view, OutSystemsUI_Navigation_Tabs_mvc_view, OutSystemsUI_Navigation_TabsHeaderItem_mvc_view, OutSystemsUI_Numbers_Badge_mvc_view, Common_CW_PHICore_CW_TabExport_mvc_view, OutSystemsUI_Utilities_Separator_mvc_view, PHICore_TH_Common_TabAssign_mvc_view, PHICore_TH_Common_TabHeaderFilter_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, InputMaskReactive_InputMask_InputPatternMask_mvc_view, OutSystemsUI_Navigation_TabsContentItem_mvc_view, PHICore_Common_Widgets_CaseNumber_mvc_view, PHICore_Common_Widgets_SLAPill_mvc_view, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, Common_CW_PHICore_CW_Pagination_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, PHICore_Common_Widgets_CaseStatusGraphCard_mvc_view, PHICore_Common_Widgets_SLAStatusCard_mvc_view, OutSystemsUI_Content_Card_mvc_view, PHICore_Common_Widgets_SearchFilterPopup_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view, PHICore_Stakeholder_NewStakeholder_Popup_mvc_view, PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_view, Common_CW_PHICore_CW_NotificationDetail_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_MainFlow_Dashboard_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_MainFlow_Dashboard_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "Dashboard";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(PHICore_Common_Widgets_BaseLayout_mvc_view, {
inputs: {
MenuId: PHICoreModel.staticEntities.menuItems.dashboard,
OnRefreshMenu: model.variables.refreshNotificationBellVar,
ExtendedClass: "hidden-headers"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
underHeaderTitle: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.AdvancedHtml, {
tag: "h1",
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "OSFillParent"
},
style: "heading1 text-neutral-0",
value: model.getCachedValue(idService.getId("bJx7KBn9AkeG8HLwtMJOVw.Value"), function () {
return ((model.variables.getUserByIdAggr.isDataFetchedAttr) ? (("Hello, " + model.variables.getUserByIdAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr)) : ("Hello"));
}, function () {
return model.variables.getUserByIdAggr.isDataFetchedAttr;
}, function () {
return model.variables.getUserByIdAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr;
}),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getUserByIdAggr.dataFetchStatusAttr)
}))];
}),
underHeaderAction: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_GlobalSearchBox_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
}),
breadcrumbs: PlaceholderContent.Empty,
title: PlaceholderContent.Empty,
actions: PlaceholderContent.Empty,
mainContent: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, {
inputs: {
TabletBehavior: PHICoreModel.staticEntities.breakColumns.all,
PhoneBehavior: PHICoreModel.staticEntities.breakColumns.all
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Adaptive_Columns3_mvc_view, {
inputs: {
PhoneBehavior: PHICoreModel.staticEntities.breakColumns.all,
TabletBehavior: PHICoreModel.staticEntities.breakColumns.all
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "6",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_1_CreateModifyQuote$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Container onclick");
controller.toggle_NewRateQuote$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
role: "button",
"aria-label": "New Rates Quote"
},
style: "dashboard flex1 full-height",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "8",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "file",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Rates Quote"];
})
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-label": "New Rates Quote"
},
style: "dashboard flex1 full-height",
visible: true,
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
ExtendedClass: "display-unset",
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "11",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {
IsDisabled: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "12",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "file",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Rates Quote"];
})
},
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
}))];
})];
}),
column2: new PlaceholderContent(function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Container onclick");
controller.onClick_NewPolicy$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
role: "button"
},
style: "dashboard flex1 full-height",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "DashboardCard_NewPolicy",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "file-text-o",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Policy"];
})
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "dashboard flex1 full-height",
visible: true,
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight,
ExtendedClass: "display-unset"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "19",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {
IsDisabled: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "DashboardCard_NewPolicy_Disabled",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "file-text-o",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Policy"];
})
},
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
}))];
})];
}),
column3: new PlaceholderContent(function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Container onclick");
controller.toggle_NewStakeholder$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
extendedProperties: {
role: "button"
},
style: "dashboard flex1 full-height ",
visible: true,
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "DashboardCard_NewStakeholder",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "user",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Stakeholder"];
})
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "dashboard flex1 full-height",
visible: true,
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight,
ExtendedClass: "display-unset"
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "27",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(Common_CW_PHICore_CW_DashboardCard_mvc_view, {
inputs: {
IsDisabled: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "DashboardCard_NewStakeholder_Disabled",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
extendedProperties: {
style: "color: #fff;"
},
icon: "user",
iconSize: /*FontSize*/ 0,
style: "\"icon\"",
visible: true,
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
text: new PlaceholderContent(function () {
return ["New Stakeholder"];
})
},
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "30"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
}))];
})];
})
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m display-flex justify-content-space-between",
visible: true,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
column2: PlaceholderContent.Empty
},
_dependencies: []
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "position-relative",
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Navigation_Tabs_mvc_view, {
inputs: {
StartingTab: model.variables.caseActiveTabVar,
OptionalConfigs: model.getCachedValue(idService.getId("WGBIelOmSkqiZyGqqkvuwg.OptionalConfigs"), function () {
return function () {
var rec = new OutSystemsUIModel.TabsOptionalConfigsRec();
rec.contentAutoHeightAttr = true;
return rec;
}();
})
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onTabChange$Action: function (tabsIdIn, activeTabIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Tabs OnTabChange");
return controller.tabsOnTabChange$Action(activeTabIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
initialized$Action: function (tabsIdIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Tabs Initialized");
controller.tabsInitialized$Action(tabsIdIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "33",
alias: "14"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
header: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Navigation_TabsHeaderItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "34",
alias: "15"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["My Cases"];
})
},
_dependencies: []
}), React.createElement(OutSystemsUI_Navigation_TabsHeaderItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "35",
alias: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["My Team\'s Cases"];
})
},
_dependencies: []
}), React.createElement(OutSystemsUI_Navigation_TabsHeaderItem_mvc_view, {
inputs: {
ExtendedClass: model.getCachedValue(idService.getId("ApprovalTabHeader.ExtendedClass"), function () {
return ((model.variables.getTeamsDataAct.isViewApprovalsOut) ? ("") : ("hidden"));
}, function () {
return model.variables.getTeamsDataAct.isViewApprovalsOut;
}),
_extendedClassInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "ApprovalTabHeader",
alias: "17"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["Approvals", React.createElement(OutSystemsUI_Numbers_Badge_mvc_view, {
inputs: {
ExtendedClass: model.getCachedValue(idService.getId("ApprovalsCountBadge.ExtendedClass"), function () {
return ((model.variables.getApprovalsByOwnerUserIdAggr.countOut.equals(OS.BuiltinFunctions.integerToLongInteger(0))) ? ("hidden") : ("margin-left-s"));
}, function () {
return model.variables.getApprovalsByOwnerUserIdAggr.countOut;
}),
_extendedClassInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
Number: model.variables.getApprovalsByOwnerUserIdAggr.countOut,
_numberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
Color: PHICoreModel.staticEntities.color.red,
Shape: PHICoreModel.staticEntities.shape.rounded,
Size: PHICoreModel.staticEntities.size.small
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "ApprovalsCountBadge",
alias: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.countOut)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "align-to-tab",
visible: true,
_idProps: {
service: idService,
uuid: "38"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.caseActiveTabVar === 1), false, this, function () {
return [React.createElement(Common_CW_PHICore_CW_TabExport_mvc_view, {
inputs: {
IsLoading: model.variables.isLoadingExportMyTeamCasesVar,
isEnabled: (model.variables.caseActiveTabVar === 1),
IsRightAlign: false
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
exportExcel$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/TabExport ExportExcel");
return controller.onClick_ExportMyTeamCases$Action(false, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
exportCSV$Action: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/TabExport ExportCSV");
return controller.onClick_ExportMyTeamCases$Action(true, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "39",
alias: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(OutSystemsUI_Utilities_Separator_mvc_view, {
inputs: {
IsVertical: true,
Space: PHICoreModel.staticEntities.space.small
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "40",
alias: "20"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
}), $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseIndividual$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [$if(((model.variables.caseActiveTabVar === 0) || (model.variables.caseActiveTabVar === 1)), false, this, function () {
return [React.createElement(PHICore_TH_Common_TabAssign_mvc_view, {
inputs: {
isEnabled: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClickTabAssign$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/TabAssign OnClickTabAssign");
controller.onClickAssignTeam$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "41",
alias: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [];
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "42",
alias: "22"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(PHICore_TH_Common_TabAssign_mvc_view, {
inputs: {
isEnabled: false
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClickTabAssign$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/TabAssign OnClickTabAssign");
controller.onClickTabAssign_Disabled$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "43",
alias: "23"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
visible: true,
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(PHICore_TH_Common_TabHeaderFilter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onClickTabHeaderFilter$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common/TabHeaderFilter OnClickTabHeaderFilter");
controller.onClickFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "46",
alias: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width3"
},
style: "case-search-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "48",
alias: "25"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: model.getCachedValue(idService.getId("Input_MyCaseNumber.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
extendedProperties: {
"aria-label": "Case Number"
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 10,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Input_MyCaseNumber OnChange");
return controller.input_MyCaseNumberOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
prompt: "Case No.",
style: "form-contro case-search-input",
variable: model.createVariable(OS.Types.Text, model.variables.caseNumberSearchVar, function (value) {
model.variables.caseNumberSearchVar = value;
}),
_idProps: {
service: idService,
name: "Input_MyCaseNumber"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Button, {
enabled: model.getCachedValue(idService.getId("SearchCasesButton.Enabled"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id);
}),
extendedProperties: {
"aria-label": "Case Number search button"
},
gridProperties: {
classes: "ThemeGrid_Width4"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/SearchCasesButton OnClick");
return controller.searchOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary case-search-btn",
visible: true,
_idProps: {
service: idService,
name: "SearchCasesButton"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
extendedProperties: {
alt: "search icon"
},
icon: "search",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(InputMaskReactive_InputMask_InputPatternMask_mvc_view, {
inputs: {
InputId: idService.getId("Input_MyCaseNumber"),
IsLazy: true,
IsRegExp: false
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "52",
alias: "26"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.caseNumberSearchVar)]
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
ExtendedClass: "display-unset",
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "53",
alias: "27"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "54",
alias: "28"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: false,
extendedProperties: {
"aria-label": "Case Number"
},
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 10,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Input_MyCaseNumber2 OnChange");
return controller.input_MyCaseNumberOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
prompt: "Case No.",
style: "form-control case-search-input",
variable: model.createVariable(OS.Types.Text, model.variables.caseNumberSearchVar, function (value) {
model.variables.caseNumberSearchVar = value;
}),
_idProps: {
service: idService,
name: "Input_MyCaseNumber2"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Button, {
enabled: false,
extendedProperties: {
"aria-label": "Case Number search button"
},
gridProperties: {
classes: "ThemeGrid_Width4"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/SearchCasesButton2 OnClick");
return controller.searchOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "btn btn-primary case-search-btn",
visible: true,
_idProps: {
service: idService,
name: "SearchCasesButton2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
extendedProperties: {
alt: "search icon"
},
icon: "search",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "57"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.caseNumberSearchVar)]
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "58"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(model.variables.caseNumberSearchVar)]
})];
})))];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Navigation_TabsContentItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "59",
alias: "29"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((model.variables.caseActiveTabVar === 0), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "60"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.TableRecords, {
extendedProperties: {
style: "width: 100%;"
},
onSort: function (clickedColumnIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Table OnSort");
return controller.onSortMyCases$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
showHeader: true,
source: model.variables.getCasesByOwnerUserIDAggr.listOut,
style: "table",
styleHeader: "table-header",
styleRow: "table-row",
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider,
source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
placeholders: {
headerRow: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.HeaderCell, {
extendedProperties: {
style: "margin-top: 0px; text-align: center;"
},
style: "cell-checkbox",
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.myApprovalsSelectAllVar)]
}, $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseIndividual$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedProperties: {
"aria-label": "Select all cases"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/MyCaseSelectAll OnChange");
controller.onChange_MyCaseSelectAll$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.myApprovalsSelectAllVar, function (value) {
model.variables.myApprovalsSelectAllVar = value;
}),
_idProps: {
service: idService,
name: "MyCaseSelectAll"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "64",
alias: "30"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: false,
extendedProperties: {
"aria-label": "Select all cases"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/MyCaseSelectAll2 OnChange");
controller.onChange_MyCaseSelectAll$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.myApprovalsSelectAllVar, function (value) {
model.variables.myApprovalsSelectAllVar = value;
}),
_idProps: {
service: idService,
name: "MyCaseSelectAll2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(model.variables.myApprovalsSelectAllVar)]
})];
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Priority.Priority",
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error",
visible: true,
_idProps: {
service: idService,
uuid: "68"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Case.CaseNumber",
_idProps: {
service: idService,
uuid: "69"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Case No."), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Category.Description",
style: "skiptab",
_idProps: {
service: idService,
uuid: "70"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SubCategory.Name",
style: "skiptab",
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Sub-Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SLAOrder",
style: "skiptab",
_idProps: {
service: idService,
uuid: "72"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "SLA"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Status.Label",
style: "skiptab",
_idProps: {
service: idService,
uuid: "73"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Status"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "CaseSLA.DueOn",
style: "skiptab",
_idProps: {
service: idService,
uuid: "74"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Due Date"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "ApprovalStatus.Label",
_idProps: {
service: idService,
uuid: "75"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Approval")];
}),
row: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.RowCell, {
style: "cell-checkbox",
_idProps: {
service: idService,
uuid: "76"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.idAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseStatusIdAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)]
}, $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseIndividual$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: (((model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseStatusIdAttr) !== (PHICoreModel.staticEntities.status.closed)) && ((model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.idAttr) !== (PHICoreModel.staticEntities.approvalStatus.pending))),
extendedProperties: {
"aria-label": ("Select Case " + model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr)
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/MyCaseSelect OnChange");
controller.onChange_MyCaseSelect$Action(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr, function (value) {
model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr = value;
}),
_idProps: {
service: idService,
name: "MyCaseSelect"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "78",
alias: "31"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: false,
extendedProperties: {
"aria-label": ("Select Case " + model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr)
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/MyCaseSelect2 OnChange");
controller.onChange_MyCaseSelect$Action(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr, function (value) {
model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr = value;
}),
_idProps: {
service: idService,
name: "MyCaseSelect2"
},
_widgetRecordProvider: widgetsRecordProvider,
variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "80"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)]
})];
})), React.createElement(OSWidgets.RowCell, {
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "81"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr)]
}, $if((model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr === PHICoreModel.staticEntities.priority.urgent), true, this, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error",
visible: true,
_idProps: {
service: idService,
uuid: "82"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "83"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr)]
}, React.createElement(PHICore_Common_Widgets_CaseNumber_mvc_view, {
inputs: {
CaseId: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr,
_caseIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseNumber: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr,
_caseNumberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
IsRestricted: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr,
_isRestrictedInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseActiveTab: 0,
CaseStatusPurposeId: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr,
_caseStatusPurposeIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "MyCases_CaseNumber",
alias: "32"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "85"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr,
_idProps: {
service: idService,
uuid: "86"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "87"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr,
_idProps: {
service: idService,
uuid: "88"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "89"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr)]
}, $if((model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr === PHICoreModel.staticEntities.status.onHold), false, this, function () {
return [];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SLAPill_mvc_view, {
inputs: {
IsSmall: true,
SLAId: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr,
_sLAIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
SLAText: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr,
_sLATextInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "90",
alias: "33"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "91"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr,
_idProps: {
service: idService,
uuid: "92"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "93"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("HQ9AxZiyYE+w7vJH2rjlNQ.Value"), function () {
return OS.BuiltinFunctions.formatDateTime(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr, "dd/MM/yyyy");
}, function () {
return model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr;
}),
_idProps: {
service: idService,
uuid: "94"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "95"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.labelAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("AQqx6J3e3Uq0YFM6NZ2Qjw.Value"), function () {
return (((model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.labelAttr === "")) ? ("N/A") : (model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.labelAttr));
}, function () {
return model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).approvalStatusAttr.labelAttr;
}),
_idProps: {
service: idService,
uuid: "96"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr)
}))];
}, callContext, idService, "1_0")
},
_dependencies: [asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.myApprovalsSelectAllVar)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "IsTableLoadingOrEmpty"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.getCasesByOwnerUserIDAggr.isDataFetchedAttr && model.variables.getCasesByOwnerUserIDAggr.listOut.isEmpty), false, this, function () {
return [$if((model.variables.getCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr && model.variables.getCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "NoCases"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "99",
alias: "34"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No cases assigned."];
}),
subtitle_Placeholder: PlaceholderContent.Empty,
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "NoResults"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "101",
alias: "35"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No results were found."];
}),
subtitle_Placeholder: new PlaceholderContent(function () {
return ["Please revise your search criteria and try again."];
}),
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
})];
}, function () {
return [$if(!(model.variables.getCasesByOwnerUserIDAggr.isDataFetchedAttr), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating",
visible: true,
_idProps: {
service: idService,
uuid: "102"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
})), React.createElement(Common_CW_PHICore_CW_Pagination_mvc_view, {
inputs: {
TotalCount: model.variables.getCasesByOwnerUserIDAggr.countOut,
_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr),
MaxRecords: model.variables.maxRecordsVar,
StartIndex: model.variables.myCasesTableVariablesVar.startIndexAttr
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onNavigate$Action: function (newStartIndexIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination OnNavigate");
return controller.onPaginationNavigateMyCases$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "103",
alias: "36"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
previous: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-left",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "104"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
next: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-right",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "105"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.myCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.myApprovalsSelectAllVar), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.caseActiveTabVar)]
}), React.createElement(OutSystemsUI_Navigation_TabsContentItem_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "106",
alias: "37"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((model.variables.caseActiveTabVar === 1), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "107"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.TableRecords, {
extendedProperties: {
style: "width: 100%;"
},
onSort: function (clickedColumnIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Table OnSort");
return controller.onSortTeamCases$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
showHeader: true,
source: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut,
style: "table",
styleHeader: "table-header",
styleRow: "table-row",
_idProps: {
service: idService,
uuid: "108"
},
_widgetRecordProvider: widgetsRecordProvider,
source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
placeholders: {
headerRow: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.HeaderCell, {
extendedProperties: {
style: "margin-top: 0px; text-align: center;"
},
style: "cell-checkbox",
_idProps: {
service: idService,
uuid: "109"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.teamCaseAllSelectedVar)]
}, $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseIndividual$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedProperties: {
"aria-label": "Select all cases"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/TeamCaseSelectAll OnChange");
controller.onChange_TeamCaseSelectAll$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox transition-none",
variable: model.createVariable(OS.Types.Boolean, model.variables.teamCaseAllSelectedVar, function (value) {
model.variables.teamCaseAllSelectedVar = value;
}),
_idProps: {
service: idService,
name: "TeamCaseSelectAll"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "111",
alias: "38"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: false,
extendedProperties: {
"aria-label": "Select all cases"
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/TeamCaseSelectAll2 OnChange");
controller.onChange_TeamCaseSelectAll$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox transition-none",
variable: model.createVariable(OS.Types.Boolean, model.variables.teamCaseAllSelectedVar, function (value) {
model.variables.teamCaseAllSelectedVar = value;
}),
_idProps: {
service: idService,
name: "TeamCaseSelectAll2"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "113"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(model.variables.teamCaseAllSelectedVar)]
})];
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Priority.Priority",
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "114"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error",
visible: true,
_idProps: {
service: idService,
uuid: "115"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Case.CaseNumber",
_idProps: {
service: idService,
uuid: "116"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Case No."), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Category.Description",
style: "skiptab",
_idProps: {
service: idService,
uuid: "117"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SubCategory.Name",
style: "skiptab",
_idProps: {
service: idService,
uuid: "118"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Sub-Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SLAOrder",
style: "skiptab",
_idProps: {
service: idService,
uuid: "119"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "SLA"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "User.Name",
style: "skiptab",
_idProps: {
service: idService,
uuid: "120"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Assigned To"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Team.Name",
style: "skiptab",
_idProps: {
service: idService,
uuid: "121"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Team"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Status.Label",
style: "skiptab",
_idProps: {
service: idService,
uuid: "122"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Status"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "CaseSLA.DueOn",
style: "skiptab",
_idProps: {
service: idService,
uuid: "123"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Due Date")];
}),
row: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.RowCell, {
style: "cell-checkbox",
_idProps: {
service: idService,
uuid: "124"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.approvalStatusIdAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseStatusIdAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)]
}, $if((OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseIndividual$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id) || OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)), false, this, function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: (((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseStatusIdAttr) !== (PHICoreModel.staticEntities.status.closed)) && ((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.approvalStatusIdAttr) !== (PHICoreModel.staticEntities.approvalStatus.pending))),
extendedProperties: {
"aria-label": ("Select Case " + model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr)
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/TeamCaseSelect OnChange");
controller.onChange_TeamCaseSelect$Action(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr, function (value) {
model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr = value;
}),
_idProps: {
service: idService,
name: "TeamCaseSelect"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "126",
alias: "39"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: false,
extendedProperties: {
"aria-label": ("Select Case " + model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr)
},
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/TeamCaseSelect2 OnChange");
controller.onChange_TeamCaseSelect$Action(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr, function (value) {
model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr = value;
}),
_idProps: {
service: idService,
name: "TeamCaseSelect2"
},
_widgetRecordProvider: widgetsRecordProvider,
variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "128"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)]
})];
})), React.createElement(OSWidgets.RowCell, {
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "129"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr)]
}, $if((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr === PHICoreModel.staticEntities.priority.urgent), false, this, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error",
visible: true,
_idProps: {
service: idService,
uuid: "130"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
_idProps: {
service: idService,
uuid: "131"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr)]
}, React.createElement(PHICore_Common_Widgets_CaseNumber_mvc_view, {
inputs: {
IsRestricted: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr,
_isRestrictedInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseId: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr,
_caseIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseNumber: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr,
_caseNumberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseStatusPurposeId: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr,
_caseStatusPurposeIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
CaseActiveTab: 1
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "TeamCasesCaseNumber",
alias: "40"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "133"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr,
_idProps: {
service: idService,
uuid: "134"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "135"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr,
_idProps: {
service: idService,
uuid: "136"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "137"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr)]
}, $if((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr === PHICoreModel.staticEntities.status.onHold), false, this, function () {
return [];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SLAPill_mvc_view, {
inputs: {
IsSmall: true,
SLAId: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr,
_sLAIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr),
SLAText: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr,
_sLATextInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "138",
alias: "41"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "139"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.idAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("XUtoKnD_j0WcUB28IcEFmg.Value"), function () {
return ((((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.idAttr) !== (OS.BuiltinFunctions.nullIdentifier()))) ? (model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr) : ("Unassigned"));
}, function () {
return model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.idAttr;
}, function () {
return model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr;
}),
_idProps: {
service: idService,
uuid: "140"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "141"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).teamAttr.nameAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).teamAttr.nameAttr,
_idProps: {
service: idService,
uuid: "142"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "143"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr,
_idProps: {
service: idService,
uuid: "144"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "145"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("EXm7fUQLu0q2mRYExCVCrg.Value"), function () {
return OS.BuiltinFunctions.formatDateTime(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr, "dd/MM/yyyy");
}, function () {
return model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr;
}),
_idProps: {
service: idService,
uuid: "146"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
}))];
}, callContext, idService, "2_0")
},
_dependencies: [asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.teamCaseAllSelectedVar)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "IsTableLoadingOrEmpty2"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.getTeamsCasesByOwnerUserIDAggr.isDataFetchedAttr && model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.isEmpty), false, this, function () {
return [$if((model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr && model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "NoTeamCases"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "149",
alias: "42"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No cases assigned."];
}),
subtitle_Placeholder: PlaceholderContent.Empty,
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "NoTeamResults"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "151",
alias: "43"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No results were found."];
}),
subtitle_Placeholder: new PlaceholderContent(function () {
return ["Please revise your search criteria and try again."];
}),
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
})];
}, function () {
return [$if(!(model.variables.getTeamsCasesByOwnerUserIDAggr.isDataFetchedAttr), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating",
visible: true,
_idProps: {
service: idService,
uuid: "152"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
})), React.createElement(Common_CW_PHICore_CW_Pagination_mvc_view, {
inputs: {
MaxRecords: model.variables.maxRecordsVar,
StartIndex: model.variables.teamCasesTableVariablesVar.startIndexAttr,
TotalCount: model.variables.getTeamsCasesByOwnerUserIDAggr.countOut,
_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onNavigate$Action: function (newStartIndexIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination OnNavigate");
return controller.onPaginationNavigateMyTeamCases$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "153",
alias: "44"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
previous: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-left",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "154"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
next: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-right",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "155"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.teamCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.teamCaseAllSelectedVar), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.caseActiveTabVar)]
}), React.createElement(OutSystemsUI_Navigation_TabsContentItem_mvc_view, {
inputs: {
ExtendedClass: model.getCachedValue(idService.getId("ApprovalTab.ExtendedClass"), function () {
return ((model.variables.getTeamsDataAct.isViewApprovalsOut) ? ("") : ("hidden"));
}, function () {
return model.variables.getTeamsDataAct.isViewApprovalsOut;
}),
_extendedClassInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getTeamsDataAct.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "ApprovalTab",
alias: "45"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [$if((model.variables.caseActiveTabVar === 2), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "157"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.TableRecords, {
extendedProperties: {
style: "width: 100%;"
},
onSort: function (clickedColumnIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/Table OnSort");
return controller.onSortMyApprovals$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
showHeader: true,
source: model.variables.getApprovalsByOwnerUserIdAggr.listOut,
style: "table",
styleHeader: "table-header",
styleRow: "table-row",
_idProps: {
service: idService,
uuid: "158"
},
_widgetRecordProvider: widgetsRecordProvider,
source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
placeholders: {
headerRow: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Priority.Priority",
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "159"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error padding-left-base",
visible: true,
_idProps: {
service: idService,
uuid: "160"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Case.CaseNumber",
style: "skiptab",
_idProps: {
service: idService,
uuid: "161"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Case No."), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Category.Description",
style: "skiptab",
_idProps: {
service: idService,
uuid: "162"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SubCategory.Name",
style: "skiptab",
_idProps: {
service: idService,
uuid: "163"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Sub-Category"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "SLAOrder",
style: "skiptab",
_idProps: {
service: idService,
uuid: "164"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "SLA"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "Status.Label",
style: "skiptab",
_idProps: {
service: idService,
uuid: "165"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Status"), React.createElement(OSWidgets.HeaderCell, {
sortAttribute: "CaseSLA.DueOn",
style: "skiptab",
_idProps: {
service: idService,
uuid: "166"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}, "Due Date")];
}),
row: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.RowCell, {
style: "Priority-Marker skiptab",
_idProps: {
service: idService,
uuid: "167"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr)]
}, $if((model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.priorityIdAttr === PHICoreModel.staticEntities.priority.urgent), false, this, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "exclamation",
iconSize: /*FontSize*/ 0,
style: "icon text-error padding-left-base",
visible: true,
_idProps: {
service: idService,
uuid: "168"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "169"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr)]
}, React.createElement(PHICore_Common_Widgets_CaseNumber_mvc_view, {
inputs: {
CaseId: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr,
_caseIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
CaseNumber: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseNumberAttr,
_caseNumberInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
CaseActiveTab: 2,
IsRestricted: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.isRestrictedAttr,
_isRestrictedInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
CaseStatusPurposeId: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseInfoAttr.caseStatusPurposeIdAttr,
_caseStatusPurposeIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "ApprovalsCaseNumber",
alias: "46"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "171"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).categoryAttr.descriptionAttr,
_idProps: {
service: idService,
uuid: "172"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "173"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).subCategoryAttr.nameAttr,
_idProps: {
service: idService,
uuid: "174"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "175"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr)]
}, $if((model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.idAttr === PHICoreModel.staticEntities.status.onHold), false, this, function () {
return [];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SLAPill_mvc_view, {
inputs: {
SLAId: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.idAttr,
_sLAIdInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
SLAText: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).sLAAttr.labelAttr,
_sLATextInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr),
IsSmall: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "176",
alias: "47"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "177"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).statusAttr.labelAttr,
_idProps: {
service: idService,
uuid: "178"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
})), React.createElement(OSWidgets.RowCell, {
style: "skiptab",
_idProps: {
service: idService,
uuid: "179"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr)]
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("cOrrEggbWE6yT0WMyUOJjA.Value"), function () {
return OS.BuiltinFunctions.formatDateTime(model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr, "dd/MM/yyyy");
}, function () {
return model.variables.getApprovalsByOwnerUserIdAggr.listOut.getCurrent(callContext.iterationContext).caseSLAAttr.dueOnAttr;
}),
_idProps: {
service: idService,
uuid: "180"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
}))];
}, callContext, idService, "3_0")
},
_dependencies: [asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "IsApprovalsLoadingOrEmpty"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if((model.variables.getApprovalsByOwnerUserIdAggr.isDataFetchedAttr && model.variables.getApprovalsByOwnerUserIdAggr.listOut.isEmpty), false, this, function () {
return [$if((model.variables.getApprovalsByOwnerUserId_NoFilterAggr.isDataFetchedAttr && model.variables.getApprovalsByOwnerUserId_NoFilterAggr.listOut.isEmpty), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "NoApprovalsAssigned"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "183",
alias: "48"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No cases assigned."];
}),
subtitle_Placeholder: PlaceholderContent.Empty,
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "table-empty",
visible: true,
_idProps: {
service: idService,
name: "ApprovalNoResults"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(Common_CW_PHICore_CW_NoItemsFound_Block_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "185",
alias: "49"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title_PlaceHolder: new PlaceholderContent(function () {
return ["No results were found."];
}),
subtitle_Placeholder: new PlaceholderContent(function () {
return ["Please revise your search criteria and try again."];
}),
nullPagination_Placeholder: PlaceholderContent.Empty
},
_dependencies: []
}))];
})];
}, function () {
return [$if(!(model.variables.getApprovalsByOwnerUserIdAggr.isDataFetchedAttr), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating",
visible: true,
_idProps: {
service: idService,
uuid: "186"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [];
})];
})), React.createElement(Common_CW_PHICore_CW_Pagination_mvc_view, {
inputs: {
MaxRecords: model.variables.maxRecordsVar,
StartIndex: model.variables.approvalTableVariablesVar.startIndexAttr,
TotalCount: model.variables.getApprovalsByOwnerUserIdAggr.countOut,
_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
onNavigate$Action: function (newStartIndexIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/Pagination OnNavigate");
return controller.onPaginationNavigateApprovals$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "187",
alias: "50"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
previous: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-left",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "188"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
next: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "angle-right",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "189"
},
_widgetRecordProvider: widgetsRecordProvider
})];
})
},
_dependencies: []
}))];
}, function () {
return [];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.approvalTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.countOut), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut), asPrimitiveValue(model.variables.caseActiveTabVar)]
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.approvalTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.teamCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.teamCaseAllSelectedVar), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.myCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.myApprovalsSelectAllVar), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.caseNumberSearchVar), asPrimitiveValue(model.variables.isLoadingExportMyTeamCasesVar), asPrimitiveValue(model.variables.caseActiveTabVar), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.countOut), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsDataAct.isViewApprovalsOut)]
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "190"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, {
inputs: {
ExtendedClass: "margin-top-base",
PhoneBehavior: PHICoreModel.staticEntities.breakColumns.all,
TabletBehavior: PHICoreModel.staticEntities.breakColumns.all
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "191",
alias: "51"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
inputs: {
PhoneBehavior: PHICoreModel.staticEntities.breakColumns.all,
TabletBehavior: PHICoreModel.staticEntities.breakColumns.all
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "192",
alias: "52"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(PHICore_Common_Widgets_CaseStatusGraphCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "193",
alias: "53"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
ExtendedClass: "display-unset",
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "194",
alias: "54"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(PHICore_Common_Widgets_CaseStatusGraphCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "195",
alias: "55"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "196"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
})];
}),
column2: new PlaceholderContent(function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_ViewDashboard$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(PHICore_Common_Widgets_SLAStatusCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "197",
alias: "56"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}, function () {
return [React.createElement(OutSystemsUI_Content_Tooltip_mvc_view, {
inputs: {
ExtendedClass: "display-unset",
Position: PHICoreModel.staticEntities.position.topRight
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "198",
alias: "57"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(PHICore_Common_Widgets_SLAStatusCard_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "199",
alias: "58"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
tooltip: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "lock",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "200"
},
_widgetRecordProvider: widgetsRecordProvider
}), " Access denied, if in error, please contact your administrator."];
})
},
_dependencies: []
})];
})];
})
},
_dependencies: []
})];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "border-color: var(--color-neutral-5);"
},
style: "border-radius-soft border-size-s",
visible: true,
_idProps: {
service: idService,
uuid: "201"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "border-color: var(--color-neutral-5);"
},
style: "padding-x-m padding-y-base background-neutral-0 border-radius-top-soft border-bottom-s",
visible: true,
_idProps: {
service: idService,
uuid: "202"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "203",
alias: "59"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width7"
},
visible: true,
_idProps: {
service: idService,
uuid: "204"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "heading4 font-regular",
text: ["Notifications"],
_idProps: {
service: idService,
uuid: "205"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
gridProperties: {
classes: "ThemeGrid_Width6 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "206"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
style: "skiptab",
transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
url: OS.Navigation.generateScreenURL("PHICore", "Notification", {}),
visible: true,
_idProps: {
service: idService,
uuid: "207"
},
_widgetRecordProvider: widgetsRecordProvider
}, "View All Notifications"))];
})
},
_dependencies: []
})), $if(model.variables.getNotificationsWithReadReceiptsAggr.listOut.isEmpty, false, this, function () {
return [React.createElement(OutSystemsUI_Content_Card_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "208",
alias: "60"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "209"
},
_widgetRecordProvider: widgetsRecordProvider
}, "No notifications.")];
})
},
_dependencies: []
})];
}, function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.getNotificationsWithReadReceiptsAggr.listOut,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "210"
},
_widgetRecordProvider: widgetsRecordProvider,
source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr),
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.ListItem, {
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/ListItem1 OnClick");
return controller.onClickNotification$Action(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "list-item",
triggerActionOnFullSwipeLeft: true,
triggerActionOnFullSwipeRight: true,
_idProps: {
service: idService,
name: "ListItem1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
leftActions: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "212",
alias: "61"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width1"
},
style: "margin-right-base",
visible: true,
_idProps: {
service: idService,
uuid: "213"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "calendar-o",
iconSize: /*Twotimes*/ 1,
style: "icon text-primary",
visible: true,
_idProps: {
service: idService,
uuid: "214"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width10 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "215"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "216",
alias: "62"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "217"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
style: "font-size-h6",
value: model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.titleAttr,
_idProps: {
service: idService,
uuid: "218"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr)
}))];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
visible: true,
_idProps: {
service: idService,
uuid: "219"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
style: "text-neutral-8",
value: model.getCachedValue(idService.getId("GDxSTgNHqE6Zfs2lwlEYLA.Value"), function () {
return OS.BuiltinFunctions.toLower(OS.BuiltinFunctions.formatDateTime(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.createdOnAttr, "dd/MM/yyyy"));
}, function () {
return model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.createdOnAttr;
}),
_idProps: {
service: idService,
uuid: "220"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr)
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.createdOnAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.titleAttr)]
}), React.createElement(OutSystemsUI_Adaptive_ColumnsMediumRight_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "221",
alias: "63"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "222"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
style: "text-neutral-8",
value: model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.descriptionAttr,
_idProps: {
service: idService,
uuid: "223"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr)
}))];
}),
column2: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.descriptionAttr)]
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: right;"
},
gridProperties: {
classes: "ThemeGrid_Width1 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "224"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": ("go to" + model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.titleAttr)
},
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MainFlow/Dashboard/NotificationLink OnClick");
return controller.onClickNotification$Action(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
visible: true,
_idProps: {
service: idService,
name: "NotificationLink"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "angle-right",
iconSize: /*Twotimes*/ 1,
style: "icon",
visible: true,
_idProps: {
service: idService,
uuid: "226"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.descriptionAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.createdOnAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.titleAttr)]
})];
}),
rightActions: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.descriptionAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.createdOnAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut.getCurrent(callContext.iterationContext).notificationAttr.titleAttr)]
})];
}, callContext, idService, "4")
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr)]
})];
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut)]
})), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showMyCasesFilterVar,
style: "popup-dialog",
_idProps: {
service: idService,
name: "MyCasesPopup"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.isLoadingFilterVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating margin-top-none",
visible: true,
_idProps: {
service: idService,
uuid: "228"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SearchFilterPopup_mvc_view, {
inputs: {
SearchFilter_Input: model.variables.searchFilter_MyCasesVar,
FilterIndictor: model.variables.caseActiveTabVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
refreshFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup RefreshFilter");
controller.onRefresh_FilterPopup$Action(searchFilter_InputIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
clearSearchFilter$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup ClearSearchFilter");
controller.clearSearchFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
closeFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup CloseFilter");
controller.toggle_FilterMyCases$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
searchFilter$Action: function (searchFilterIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup SearchFilter");
return controller.applyMyCasesFilter$Action(searchFilterIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "229",
alias: "64"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showMyTeamCasesFilterVar,
style: "popup-dialog",
_idProps: {
service: idService,
name: "MyTeamsPopUp"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.isLoadingFilterVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating margin-top-none",
visible: true,
_idProps: {
service: idService,
uuid: "231"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SearchFilterPopup_mvc_view, {
inputs: {
SearchFilter_Input: model.variables.searchFilter_MyTeamCasesVar,
FilterIndictor: model.variables.caseActiveTabVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
refreshFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup RefreshFilter");
controller.onRefresh_FilterPopup$Action(searchFilter_InputIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
searchFilter$Action: function (searchFilterIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup SearchFilter");
return controller.applyMyTeamCasesFilter$Action(searchFilterIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
closeFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup CloseFilter");
controller.toggle_FilterMyTeamCases$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
clearSearchFilter$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup ClearSearchFilter");
controller.clearSearchFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "232",
alias: "65"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showApprovalsFilterVar,
style: "popup-dialog",
_idProps: {
service: idService,
name: "ApprovalsFilterPopUp"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.isLoadingFilterVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "list-updating margin-top-none",
visible: true,
_idProps: {
service: idService,
uuid: "234"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(PHICore_Common_Widgets_SearchFilterPopup_mvc_view, {
inputs: {
FilterIndictor: model.variables.caseActiveTabVar,
SearchFilter_Input: model.variables.searchFilter_ApprovalsVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
refreshFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup RefreshFilter");
controller.onRefresh_FilterPopup$Action(searchFilter_InputIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
closeFilter$Action: function (searchFilter_InputIn) {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup CloseFilter");
controller.toggle_FilterApprovals$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
clearSearchFilter$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup ClearSearchFilter");
controller.clearSearchFilter$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
searchFilter$Action: function (searchFilterIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/SearchFilterPopup SearchFilter");
return controller.applyApprovalsFilter$Action(searchFilterIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "235",
alias: "66"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})), React.createElement(Common_CW_PHICore_CW_RestrictedPopup_mvc_view, {
inputs: {
Message: "Your current permissions do not allow access to restricted cases. If you think this is an error, please contact your administrator.",
Show: model.variables.showPopup_RestrictedVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
eventClose$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/RestrictedPopup EventClose");
controller.toggle_RestrictedPopup$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "236",
alias: "67"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(PHICore_Stakeholder_NewStakeholder_Popup_mvc_view, {
inputs: {
ShowNewStakeholderPopup: model.variables.showPopup_NewStakeholderVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
toggle_NewStakeholder$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup Toggle_NewStakeholder");
controller.toggle_NewStakeholder$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "237",
alias: "68"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(PHICore_Common_Widgets_AssignCaseTeam_Popup_mvc_view, {
inputs: {
SelectedCasesList: model.getCachedValue(idService.getId("5t9+BAjpNE+9oAQFI6j4Xg.SelectedCasesList"), function () {
return OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.sharedSelectedCasesVar, new PHICoreModel.CaseIdentifier1RecordList(), function (source, target) {
target.caseIdentifierAttr = source.caseAttr;
return target;
});
}, function () {
return model.variables.sharedSelectedCasesVar;
}),
IsPopupOpen: model.variables.showAssignTeamVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
eventAssignCase$Action: function (isProceedIn) {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/AssignCaseTeam_Popup EventAssignCase");
return controller.assignCaseTeam_PopupEventAssignCase$Action(isProceedIn, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "238",
alias: "69"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_NotificationDetail_mvc_view, {
inputs: {
NotificationDescription: model.variables.notificationDescriptionVar,
EnablePopup: model.variables.showNotificationDetailVar
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
enableNotification$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/NotificationDetail EnableNotification");
controller.enableNotificationDetail$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "239",
alias: "70"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
footer: PlaceholderContent.Empty
},
_dependencies: [asPrimitiveValue(model.variables.showNotificationDetailVar), asPrimitiveValue(model.variables.notificationDescriptionVar), asPrimitiveValue(model.variables.showAssignTeamVar), asPrimitiveValue(model.variables.sharedSelectedCasesVar), asPrimitiveValue(model.variables.showPopup_NewStakeholderVar), asPrimitiveValue(model.variables.showPopup_RestrictedVar), asPrimitiveValue(model.variables.searchFilter_ApprovalsVar), asPrimitiveValue(model.variables.showApprovalsFilterVar), asPrimitiveValue(model.variables.searchFilter_MyTeamCasesVar), asPrimitiveValue(model.variables.showMyTeamCasesFilterVar), asPrimitiveValue(model.variables.searchFilter_MyCasesVar), asPrimitiveValue(model.variables.isLoadingFilterVar), asPrimitiveValue(model.variables.showMyCasesFilterVar), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.listOut), asPrimitiveValue(model.variables.approvalTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.teamCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.teamCaseAllSelectedVar), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.myCasesTableVariablesVar.startIndexAttr), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.listOut.isEmpty), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.myApprovalsSelectAllVar), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.countOut), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.listOut), asPrimitiveValue(model.variables.caseNumberSearchVar), asPrimitiveValue(model.variables.isLoadingExportMyTeamCasesVar), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.listOut), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.countOut), asPrimitiveValue(model.variables.getTeamsDataAct.isViewApprovalsOut), asPrimitiveValue(model.variables.caseActiveTabVar), asPrimitiveValue(model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserId_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getTeamsDataAct.dataFetchStatusAttr), asPrimitiveValue(model.variables.getUserByIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getUserByIdAggr.listOut.getCurrent(callContext.iterationContext).userAttr.nameAttr), asPrimitiveValue(model.variables.getUserByIdAggr.isDataFetchedAttr)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("PHICore.MainFlow.Dashboard.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "OutSystemsUI.model", "Common_CS.model", "PHICore_Notification.model", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.MainFlow.Dashboard.mvc$debugger", "PHICore.MainFlow.controller", "PHICore.MainFlow.Dashboard.mvc$controller.TabsInitialized.JavaScript1JS", "PHICore.MainFlow.Dashboard.mvc$controller.OnRefresh_FilterPopup.SetTimoutJSJS", "PHICore.MainFlow.Dashboard.mvc$controller.OnReady.OnPressEnterCaseSearchJS", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "Common_CW.controller$Check_SP_AssignCaseIndividual", "Common_CW.controller$Check_SP_AssignCaseBulk", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$Check_ViewDashboard", "PHICore.model$SearchFilterRec", "PHICore.model$TextTextTextTextTextTextTextTextRecord", "PHICore.model$CaseIdentifier1RecordList", "PHICore.model$CaseInfoIdentifierRecordList", "PHICore.model$CaseIdentifierRecordList", "PHICore.model$IntegerIntegerIntegerRecord", "PHICore.model$TextTextTextRecord", "OutSystemsUI.model$TabsOptionalConfigsRec", "PHICore.referencesHealth$OutSystemsUI", "PHICore.model$TextText2RecordList", "PHICore.model$CaseIdentifierRecord", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$Text1RecordList", "Common_CW.controller$String_Join", "Common_CS.model$EntityActionResultRec", "PHICore.referencesHealth$Common_CS", "PHICore_Notification.model$NotificationRec", "PHICore.referencesHealth$PHICore_Notification", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecordList", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamUserStatusSLACategoryCaseBooleanIntegerRecordList", "PHICore.model$CaseInfoIdentifierRecord", "Common_CW.controller$SetCurrentAsValidURL", "PHICore.model$JoinedFilterRec", "PHICore.model$Dashboard_CasesFilterRec", "PHICore.model$DashboardDropdownSearchTagList", "PHICore.model$PriorityCaseInfoCaseSLAApprovalStatusSubCategoryStatusSLACategoryCaseBooleanIntegerRecord", "PHICore.model$PriorityCaseInfoCaseSLASubCategoryTeamStatusSLACategoryCaseUserBooleanIntegerRecord", "PHICore.model$PriorityCaseSLASubCategoryTeamStatusSLACategoryCaseUserRecordList", "PHICore.model$TeamTeamUserUserRecordList", "PHICore.model$PriorityCaseSLASubCategoryStatusSLACategoryCaseRecordList", "PHICore.model$ReadReceiptNotificationRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, OutSystemsUIModel, Common_CSModel, PHICore_NotificationModel, PHICoreLanguageResources, PHICoreClientVariables, PHICore_MainFlow_Dashboard_mvc_Debugger, PHICore_MainFlowController, PHICore_MainFlow_Dashboard_mvc_controller_TabsInitialized_JavaScript1JS, PHICore_MainFlow_Dashboard_mvc_controller_OnRefresh_FilterPopup_SetTimoutJSJS, PHICore_MainFlow_Dashboard_mvc_controller_OnReady_OnPressEnterCaseSearchJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
toggle_FilterLoading$Action: function () {
return controller.executeActionInsideJSNode(controller._toggle_FilterLoading$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Toggle_FilterLoading");
},
searchOnClick$Action: function () {
return controller.executeActionInsideJSNode(controller._searchOnClick$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "SearchOnClick");
}
};
this.dataFetchDependenciesOriginal = {
getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh: -1,
getTeamsCasesByOwnerUserID$AggrRefresh: -1,
getCasesByOwnerUserID$AggrRefresh: 0,
getUserById$AggrRefresh: 0,
getApprovalsByOwnerUserId_NoFilter$AggrRefresh: 0,
getCasesByOwnerUserID_NoFilter$AggrRefresh: 0,
getNotificationsWithReadReceipts$AggrRefresh: 0,
getApprovalsByOwnerUserId$AggrRefresh: 0,
getTeams$DataActRefresh: 0
};
this.dataFetchDependentsGraph = {
getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh: [],
getTeamsCasesByOwnerUserID$AggrRefresh: [],
getCasesByOwnerUserID$AggrRefresh: [],
getUserById$AggrRefresh: [],
getApprovalsByOwnerUserId_NoFilter$AggrRefresh: [],
getCasesByOwnerUserID_NoFilter$AggrRefresh: [],
getNotificationsWithReadReceipts$AggrRefresh: [],
getApprovalsByOwnerUserId$AggrRefresh: [],
getTeams$DataActRefresh: ["getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh", "getTeamsCasesByOwnerUserID$AggrRefresh"]
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions
Controller.prototype.exportMyTeamCases$ServerAction = function (isCSVIn, myTeamCasesListSortIn, joinedStrings_MyTeamCasesIn, searchFilter_MyTeamCasesIn, caseNumberSearchIn, callContext) {
var controller = this.controller;
var inputs = {
IsCSV: OS.DataConversion.ServerDataConverter.to(isCSVIn, OS.Types.Boolean),
MyTeamCasesListSort: OS.DataConversion.ServerDataConverter.to(myTeamCasesListSortIn, OS.Types.Text),
JoinedStrings_MyTeamCases: OS.DataConversion.ServerDataConverter.to(joinedStrings_MyTeamCasesIn, OS.Types.Record),
SearchFilter_MyTeamCases: OS.DataConversion.ServerDataConverter.to(searchFilter_MyTeamCasesIn, OS.Types.Record),
CaseNumberSearch: OS.DataConversion.ServerDataConverter.to(caseNumberSearchIn, OS.Types.Text)
};
return controller.callServerAction("ExportMyTeamCases", "screenservices/PHICore/MainFlow/Dashboard/ActionExportMyTeamCases", "NnuK4zVkwiCdSUN_WGpakA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard$ActionExportMyTeamCases"))();
executeServerActionResult.binaryOut = OS.DataConversion.ServerDataConverter.from(outputs.Binary, OS.Types.BinaryData);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard$ActionExportMyTeamCases", [{
name: "Binary",
attrName: "binaryOut",
mandatory: false,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}]);
Controller.prototype.readNotification$ServerAction = function (notificationIdIn, callContext) {
var controller = this.controller;
var inputs = {
NotificationId: OS.DataConversion.ServerDataConverter.to(notificationIdIn, OS.Types.LongInteger)
};
return controller.callServerAction("ReadNotification", "screenservices/PHICore/MainFlow/Dashboard/ActionReadNotification", "ZomqWwMYsAqQl5q_UdC5VQ", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard$ActionReadNotification"))();
executeServerActionResult.entityActionResultOut = OS.DataConversion.ServerDataConverter.from(outputs.EntityActionResult, Common_CSModel.EntityActionResultRec);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard$ActionReadNotification", [{
name: "EntityActionResult",
attrName: "entityActionResultOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new Common_CSModel.EntityActionResultRec();
},
complexType: Common_CSModel.EntityActionResultRec
}]);
Controller.prototype.dashboardStringJoin$ServerAction = function (categoryIn, subCategoryIn, sLAsIn, priorityIn, statusIn, teamsIn, assignedToIn, raisedByIn, callContext) {
var controller = this.controller;
var inputs = {
Category: OS.DataConversion.ServerDataConverter.to(categoryIn, OS.Types.RecordList),
SubCategory: OS.DataConversion.ServerDataConverter.to(subCategoryIn, OS.Types.RecordList),
SLAs: OS.DataConversion.ServerDataConverter.to(sLAsIn, OS.Types.RecordList),
Priority: OS.DataConversion.ServerDataConverter.to(priorityIn, OS.Types.RecordList),
Status: OS.DataConversion.ServerDataConverter.to(statusIn, OS.Types.RecordList),
Teams: OS.DataConversion.ServerDataConverter.to(teamsIn, OS.Types.RecordList),
AssignedTo: OS.DataConversion.ServerDataConverter.to(assignedToIn, OS.Types.RecordList),
RaisedBy: OS.DataConversion.ServerDataConverter.to(raisedByIn, OS.Types.RecordList)
};
return controller.callServerAction("DashboardStringJoin", "screenservices/PHICore/MainFlow/Dashboard/ActionDashboardStringJoin", "klPf49tE8qh6sG1qIQ_m2A", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard$ActionDashboardStringJoin"))();
executeServerActionResult.categoryStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.CategoryStringJoined, OS.Types.Text);
executeServerActionResult.subCategoryStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.SubCategoryStringJoined, OS.Types.Text);
executeServerActionResult.sLAsStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.SLAsStringJoined, OS.Types.Text);
executeServerActionResult.priorityStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.PriorityStringJoined, OS.Types.Text);
executeServerActionResult.statusStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.StatusStringJoined, OS.Types.Text);
executeServerActionResult.raisedByStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.RaisedByStringJoined, OS.Types.Text);
executeServerActionResult.assignedToByStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.AssignedToByStringJoined, OS.Types.Text);
executeServerActionResult.teamByStringJoinedOut = OS.DataConversion.ServerDataConverter.from(outputs.TeamByStringJoined, OS.Types.Text);
return executeServerActionResult;
});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard$ActionDashboardStringJoin", [{
name: "CategoryStringJoined",
attrName: "categoryStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SubCategoryStringJoined",
attrName: "subCategoryStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "SLAsStringJoined",
attrName: "sLAsStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "PriorityStringJoined",
attrName: "priorityStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "StatusStringJoined",
attrName: "statusStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "RaisedByStringJoined",
attrName: "raisedByStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "AssignedToByStringJoined",
attrName: "assignedToByStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "TeamByStringJoined",
attrName: "teamByStringJoinedOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);

// Aggregates and Data Actions
Controller.prototype.getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:3pXHBiJdCkmdOF0iaE7DJQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.3pXHBiJdCkmdOF0iaE7DJQ:9gEZn+S8Fn06R3moyvozrA", "PHICore", "GetTeamsCasesByOwnerUserID_NoFilter", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetTeamsCasesByOwnerUserID_NoFilter");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeamsCasesByOwnerUserID_NoFilter", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetTeamsCasesByOwnerUserID_NoFilter", "G+lEAE_ayYBQJocf8SVv7w", maxRecords, startIndex, function (b) {
model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:3pXHBiJdCkmdOF0iaE7DJQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getTeamsCasesByOwnerUserID$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:jNHrSFSJLk6D+QQRuTD5Bg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.jNHrSFSJLk6D+QQRuTD5Bg:QM3t4nh+mkrdyjwrQEgTmA", "PHICore", "GetTeamsCasesByOwnerUserID", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetTeamsCasesByOwnerUserID");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetTeamsCasesByOwnerUserID", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetTeamsCasesByOwnerUserID", "JyKTBlbusVPevfit6yLuGA", maxRecords, startIndex, function (b) {
model.variables.getTeamsCasesByOwnerUserIDAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamsCasesByOwnerUserIDAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamsCasesByOwnerUserIDAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:jNHrSFSJLk6D+QQRuTD5Bg", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getCasesByOwnerUserID$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:uy6hZf6UF0OGW9znArYbWg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.uy6hZf6UF0OGW9znArYbWg:borgOlbJOGIzHoyL2AzwyA", "PHICore", "GetCasesByOwnerUserID", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetCasesByOwnerUserID");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetCasesByOwnerUserID", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetCasesByOwnerUserID", "GTxPHZbao7VL8PI6dBDNkw", maxRecords, startIndex, function (b) {
model.variables.getCasesByOwnerUserIDAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCasesByOwnerUserIDAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCasesByOwnerUserIDAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:uy6hZf6UF0OGW9znArYbWg", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getUserById$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:EX5Dc6ajJk2I1z_a9PtGCw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.EX5Dc6ajJk2I1z_a9PtGCw:XFPnsDiY7hTDro7l0MakFQ", "PHICore", "GetUserById", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetUserById");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetUserById", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetUserById", "s9liXDouNdUNYc1IR+Mj7Q", maxRecords, startIndex, function (b) {
model.variables.getUserByIdAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getUserByIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getUserByIdAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:EX5Dc6ajJk2I1z_a9PtGCw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getApprovalsByOwnerUserId_NoFilter$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:RqY4jnKar0i8SevqOUwhQA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.RqY4jnKar0i8SevqOUwhQA:c669c8TcPIuhgX0xrP_sdg", "PHICore", "GetApprovalsByOwnerUserId_NoFilter", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetApprovalsByOwnerUserId_NoFilter");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetApprovalsByOwnerUserId_NoFilter", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetApprovalsByOwnerUserId_NoFilter", "RRpsZgyrfaIBlxp2gd8RFQ", maxRecords, startIndex, function (b) {
model.variables.getApprovalsByOwnerUserId_NoFilterAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getApprovalsByOwnerUserId_NoFilterAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getApprovalsByOwnerUserId_NoFilterAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:RqY4jnKar0i8SevqOUwhQA", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getCasesByOwnerUserID_NoFilter$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:i6TTn3JPcEWAVrL5i90cpQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.i6TTn3JPcEWAVrL5i90cpQ:5944XGJpiRN4hWU9raSZ7w", "PHICore", "GetCasesByOwnerUserID_NoFilter", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetCasesByOwnerUserID_NoFilter");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetCasesByOwnerUserID_NoFilter", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetCasesByOwnerUserID_NoFilter", "Go9n6ExWylsJZt5Dyq74Ug", maxRecords, startIndex, function (b) {
model.variables.getCasesByOwnerUserID_NoFilterAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getCasesByOwnerUserID_NoFilterAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getCasesByOwnerUserID_NoFilterAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:i6TTn3JPcEWAVrL5i90cpQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getNotificationsWithReadReceipts$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:8XkeySM3yE6UYHqON+6FBw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.8XkeySM3yE6UYHqON+6FBw:l1htq_06dNRaqtktjOo38g", "PHICore", "GetNotificationsWithReadReceipts", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetNotificationsWithReadReceipts");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetNotificationsWithReadReceipts", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetNotificationsWithReadReceipts", "xbdljR6FIxugLwgFXci7Tg", maxRecords, startIndex, function (b) {
model.variables.getNotificationsWithReadReceiptsAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getNotificationsWithReadReceiptsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getNotificationsWithReadReceiptsAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8XkeySM3yE6UYHqON+6FBw", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getApprovalsByOwnerUserId$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:LuQ30jij6UKmfgbKcmFlIQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ScreenDataSets.LuQ30jij6UKmfgbKcmFlIQ:wVwdrTleSv3rN_5L1wJ9_w", "PHICore", "GetApprovalsByOwnerUserId", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetApprovalsByOwnerUserId");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetApprovalsByOwnerUserId", "screenservices/PHICore/MainFlow/Dashboard/ScreenDataSetGetApprovalsByOwnerUserId", "hTEuRjg7c_27l74r2K1UYw", maxRecords, startIndex, function (b) {
model.variables.getApprovalsByOwnerUserIdAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getApprovalsByOwnerUserIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getApprovalsByOwnerUserIdAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:LuQ30jij6UKmfgbKcmFlIQ", callContext.id);
controller.popDebuggerContext(callContext);

});
};
Controller.prototype.getTeams$DataActRefresh = function (callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:rts6Szm2gEC7jcbCdRxvOw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/DataActions.rts6Szm2gEC7jcbCdRxvOw:exDo1CcdYYC7qpA2SWBz3w", "PHICore", "GetTeams", "NRFlows.DataScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetTeams");
return controller.callDataAction("DataActionGetTeams", "screenservices/PHICore/MainFlow/Dashboard/DataActionGetTeams", "5EOYJxWfhsix+c7j+8RKcw", function (b) {
model.variables.getTeamsDataAct.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getTeamsDataAct.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getTeamsDataAct.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false).then(function () {
OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard/GetTeams On After Fetch");
return controller._getTeamsOnAfterFetch$Action(controller.callContext(callContext));

});

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:rts6Szm2gEC7jcbCdRxvOw", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh", "getTeamsCasesByOwnerUserID$AggrRefresh", "getCasesByOwnerUserID$AggrRefresh", "getUserById$AggrRefresh", "getApprovalsByOwnerUserId_NoFilter$AggrRefresh", "getCasesByOwnerUserID_NoFilter$AggrRefresh", "getNotificationsWithReadReceipts$AggrRefresh", "getApprovalsByOwnerUserId$AggrRefresh", "getTeams$DataActRefresh"];
// Client Actions
Controller.prototype._toggle_AssignCase$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_AssignCase");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:N2+aA3BBGEewOboMKhOY9g:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.N2+aA3BBGEewOboMKhOY9g:ng7z9vwnxz5SXa1Ldcbg2g", "PHICore", "Toggle_AssignCase", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vOkedFJWQkGI7Gc+i0mOhQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HEQV_Xk3skiZi+cZ4ClQ9g", callContext.id);
// ShowAssignTeam = notShowAssignTeam
model.variables.showAssignTeamVar = !(model.variables.showAssignTeamVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Stk8cAarpU202cN3hqQNPg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:N2+aA3BBGEewOboMKhOY9g", callContext.id);
}

};
Controller.prototype._onChange_MyCaseSelect$Action = function (selectedCaseIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_MyCaseSelect");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnChange_MyCaseSelect$vars"))());
vars.value.selectedCaseIdInLocal = selectedCaseIdIn;
var listIndexOfVar = new OS.DataTypes.VariableHolder();
var listFilter_SelectedVar = new OS.DataTypes.VariableHolder();
var listFilter_ClosedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listIndexOfVar = listIndexOfVar;
varBag.listFilter_SelectedVar = listFilter_SelectedVar;
varBag.listFilter_ClosedVar = listFilter_ClosedVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:qCmCB8k0dECTYC5GSDjtng:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.qCmCB8k0dECTYC5GSDjtng:C6FjFSbh0tE1NPg7bZI6IQ", "PHICore", "OnChange_MyCaseSelect", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PeREf3YHDk2cFhQ0ofWloQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ucwp8Al_B0y3JVsY7cKaFA", callContext.id) && model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l0GcV1cI9UGDp0okGmhxKA", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zelVMJ+6f0WejAQ0vyvWOg", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedMyCaseListVar, callContext);
// Foreach GetCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesByOwnerUserIDAggr.listOut);
try {var getCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getCasesByOwnerUserIDAggr.listOut);
var getCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7LFEe71_Q0ebpidqgE+3Ag", callContext.id) && (getCasesByOwnerUserIDIndex < model.variables.getCasesByOwnerUserIDAggr.listOut.length))) {
getCasesByOwnerUserIDIterator.currentRowNumber = getCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:t88Ly33A4U2nXmQEG2VzVQ", callContext.id) && !(vars.value.selectedCaseIdInLocal.equals(model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).caseAttr.idAttr)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tlVYrPPa2kWkZjOI44RMMg", callContext.id);
// GetCasesByOwnerUserID.List.Current.IsSelected = False
model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = false;
}

getCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesByOwnerUserIDAggr.listOut);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FjLvFt7QAU2M4M7VbvHk3w", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.selectedMyCaseListVar, function () {
var rec = new PHICoreModel.CaseIdentifierRecord();
rec.caseIdentifierAttr = vars.value.selectedCaseIdInLocal;
return rec;
}(), callContext);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DT6jGES66kOsL52ojD948Q", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(model.variables.selectedMyCaseListVar, function (p) {
return p.caseIdentifierAttr.equals(model.variables.getCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hZYsa4ecXEqurE_4K+syIw", callContext.id) && (listIndexOfVar.value.positionOut === -1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iC0vNTVNgUeIqxWQ1mU8cg", callContext.id);
return ;

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Dpuu2r4sx0mqSmXTDjcpJw", callContext.id);
// Execute Action: ListRemove
OS.SystemActions.listRemove(model.variables.selectedMyCaseListVar, listIndexOfVar.value.positionOut, callContext);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4UnPMbQWwUiohzZtmwvXqg", callContext.id);
// Execute Action: JoinSelectedCaseList
controller._joinSelectedCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kbPeqOtMhEWEMVaHLY4bZQ", callContext.id);
// MyCasesTableVariables.SelectCount = 0
model.variables.myCasesTableVariablesVar.selectCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kbPeqOtMhEWEMVaHLY4bZQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MyCasesTableVariables.ClosedCount = 0
model.variables.myCasesTableVariablesVar.closedCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AleDYRoP_EaE2kXX0BbX3w", callContext.id);
// Execute Action: ListFilter_Selected
listFilter_SelectedVar.value = OS.SystemActions.listFilter(model.variables.getCasesByOwnerUserIDAggr.listOut, function (p) {
return p.isSelectedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:m5YTvXhEWUCbpncIFXQIHA", callContext.id);
// Execute Action: ListFilter_Closed
listFilter_ClosedVar.value = OS.SystemActions.listFilter(model.variables.getCasesByOwnerUserIDAggr.listOut, function (p) {
return (p.caseAttr.caseStatusIdAttr === PHICoreModel.staticEntities.status.closed);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yg63e+DonkuJs11xMLTUdw", callContext.id);
// MyCasesTableVariables.SelectCount = ListFilter_Selected.FilteredList.Length
model.variables.myCasesTableVariablesVar.selectCountAttr = listFilter_SelectedVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yg63e+DonkuJs11xMLTUdw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MyCasesTableVariables.ClosedCount = ListFilter_Closed.FilteredList.Length
model.variables.myCasesTableVariablesVar.closedCountAttr = listFilter_ClosedVar.value.filteredListOut.length;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3vYqg7tq8ky_dzXn9OgcNA", callContext.id) && ((model.variables.getCasesByOwnerUserIDAggr.listOut.length - model.variables.myCasesTableVariablesVar.closedCountAttr) === model.variables.myCasesTableVariablesVar.selectCountAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:g06x+bnDuE6rdtj8Z_QblA", callContext.id);
// MyApprovalsSelectAll = True
model.variables.myApprovalsSelectAllVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y9wbkAl1ckuzm3tqFn7Lhw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:x_NFbWViy0yZxfPcms64vQ", callContext.id);
// MyApprovalsSelectAll = False
model.variables.myApprovalsSelectAllVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Y9wbkAl1ckuzm3tqFn7Lhw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:qCmCB8k0dECTYC5GSDjtng", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnChange_MyCaseSelect$vars", [{
name: "SelectedCaseId",
attrName: "selectedCaseIdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._onClick_ExportMyTeamCases$Action = function (isCSVIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_ExportMyTeamCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnClick_ExportMyTeamCases$vars"))());
vars.value.isCSVInLocal = isCSVIn;
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var exportMyTeamCasesVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.allExceptionsVar = allExceptionsVar;
varBag.exportMyTeamCasesVar = exportMyTeamCasesVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:hxsjCq6SPE+lkdGkvpD6FQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.hxsjCq6SPE+lkdGkvpD6FQ:YAZSreTOf3iRmw_2v+9EtQ", "PHICore", "OnClick_ExportMyTeamCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QHlPNoS7aU6yH7_6PiHAqQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lkWXGV+TdEiAwnsB4H19aw", callContext.id);
// IsLoadingExportMyTeamCases = True
model.variables.isLoadingExportMyTeamCasesVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uT6NhfWahEOObCo54421gw", callContext.id);
// Execute Action: ExportMyTeamCases
model.flush();
return controller.exportMyTeamCases$ServerAction(vars.value.isCSVInLocal, PHICoreClientVariables.getMyTeamCasesListSort(), model.variables.joinedStrings_MyTeamCasesVar, model.variables.searchFilter_MyTeamCasesVar, model.variables.caseNumberSearchVar, callContext).then(function (value) {
exportMyTeamCasesVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9c4m2owxYUiBVeWv6NXGaA", callContext.id);
// IsLoadingExportMyTeamCases = False
model.variables.isLoadingExportMyTeamCasesVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PAzMLfdxNE+sLl4atbKQjQ", callContext.id);
return OS.Flow.returnAsync(OS.Controller.BaseViewController.downloadBinary(exportMyTeamCasesVar.value.binaryOut, ((("My Teams Cases " + OS.BuiltinFunctions.formatDateTime(OS.BuiltinFunctions.currDate(), "dd_MM_yyyy")) + ".") + ((vars.value.isCSVInLocal) ? ("csv") : ("xlsx")))));
});
}).catch(function (ex) {
OS.Logger.trace("Dashboard.OnClick_ExportMyTeamCases", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
OutSystemsDebugger.handleException(allExceptionsVar.value.exceptionMessageAttr, callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7LkneGfkjEmw_tq74sfMxA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fOcw2LfGaEWnLKx5b3Nw3Q", callContext.id);
// IsLoadingExportMyTeamCases = False
model.variables.isLoadingExportMyTeamCasesVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AWey2lqxUU+S8vp_xk5iAg", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage(allExceptionsVar.value.exceptionMessageAttr, /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kc0tIA61qkWL7lWtXZdkEQ", callContext.id);
return OS.Flow.returnAsync();

});
}

throw ex;
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:hxsjCq6SPE+lkdGkvpD6FQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:hxsjCq6SPE+lkdGkvpD6FQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnClick_ExportMyTeamCases$vars", [{
name: "IsCSV",
attrName: "isCSVInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._toggle_FilterLoading$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_FilterLoading");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:BpMqCtVDYUSGwlpUJ72Cew:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.BpMqCtVDYUSGwlpUJ72Cew:RnIE2eAv3W_JCkWlfuiQeA", "PHICore", "Toggle_FilterLoading", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uP8wtWVPDky8mJ8xQKRiHA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JlBM3TA81kCMlsj9i64nSA", callContext.id);
// IsLoadingFilter = notIsLoadingFilter
model.variables.isLoadingFilterVar = !(model.variables.isLoadingFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f9LDOHJb2EabQEqhv40Z1A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:BpMqCtVDYUSGwlpUJ72Cew", callContext.id);
}

};
Controller.prototype._resetSelectedMyCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ResetSelectedMyCases");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:klbXDsycjEqC0ZEdQv3dsA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.klbXDsycjEqC0ZEdQv3dsA:0lY39x9y_pGXwmQ_EZmcvA", "PHICore", "ResetSelectedMyCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AQPK4FCDzk2WDjNrDdl6yA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nzlaxRp800OBw+MWdjhZdA", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedMyCaseListVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S+LpK1dIHUe_RVmo+FxMjw", callContext.id);
// Execute Action: JoinSelectedCaseList
controller._joinSelectedCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TbENS_v+RUS3ou+jLBoMpA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:klbXDsycjEqC0ZEdQv3dsA", callContext.id);
}

};
Controller.prototype._toggle_FilterApprovals$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_FilterApprovals");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:91nsEIvq50GS8vwKwwHPBg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.91nsEIvq50GS8vwKwwHPBg:AqKyu88gCYJ8o2pAbtq76Q", "PHICore", "Toggle_FilterApprovals", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BJ_LSW3G20C0gmG0QM9_yQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:57uYR5WOvUOZS8e5048Wnw", callContext.id);
// ShowApprovalsFilter = notShowApprovalsFilter
model.variables.showApprovalsFilterVar = !(model.variables.showApprovalsFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:19yKsy1wgkqEUmi1hFJEcQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:91nsEIvq50GS8vwKwwHPBg", callContext.id);
}

};
Controller.prototype._enableNotificationDetail$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("EnableNotificationDetail");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:+0jvEVDnT0+gQ3_KBsvC+g:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.+0jvEVDnT0+gQ3_KBsvC+g:z1st3Ak9kBLCPOapi_qxZw", "PHICore", "EnableNotificationDetail", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:J8SMT56dYUOc8FqDvqBJqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HHm1H42O30KhMn37eP7oPQ", callContext.id);
// ShowNotificationDetail = False
model.variables.showNotificationDetailVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HHm1H42O30KhMn37eP7oPQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefreshNotificationBell = False
model.variables.refreshNotificationBellVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8A0Y_UT9gE6U+5dPfLvXzw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:+0jvEVDnT0+gQ3_KBsvC+g", callContext.id);
}

};
Controller.prototype._joinSelectedMyApprovalsList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("JoinSelectedMyApprovalsList");
callContext = controller.callContext(callContext);
var string_JoinVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.string_JoinVar = string_JoinVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:S4gKFcrdl06jmIN3qRvscw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.S4gKFcrdl06jmIN3qRvscw:zC0Jsk6l5fUMoPhVzQVfwQ", "PHICore", "JoinSelectedMyApprovalsList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Cy+ix3imjUCmtaeXNKCaZA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xtIO8j5V7Uel0UsQqMipEA", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedMyApprovalListVar, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.caseInfoIdentifierAttr);
return target;
}), "#", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_rR9QccI4k+x79TgbH5g0g", callContext.id);
// SelectedMyApprovalText = String_Join.Text
model.variables.selectedMyApprovalTextVar = string_JoinVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NnwfH44w50mzKmZ37T9NlQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:S4gKFcrdl06jmIN3qRvscw", callContext.id);
}

};
Controller.prototype._input_MyCaseNumberOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Input_MyCaseNumberOnChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:ULVVFbXmbkWYnV7fCWCiUQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.ULVVFbXmbkWYnV7fCWCiUQ:LDoAa5aCSI_xeIoN+Pk5YQ", "PHICore", "Input_MyCaseNumberOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TTursYjNhEqiB3_ifGm28Q", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LXQNLAvir0C42L5DdpR5dg", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RSktq6nCaES6Oju0rDrmuA", callContext.id);
// MyCasesSearch_Original.MyCasesCaseNumber = CaseNumberSearch
model.variables.myCasesSearch_OriginalVar.myCasesCaseNumberAttr = model.variables.caseNumberSearchVar;
} else {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:InUaui1gsU+bM41m2FJO9w", callContext.id);
// MyCasesSearch_Original.MyTeamCasesNumber = CaseNumberSearch
model.variables.myCasesSearch_OriginalVar.myTeamCasesNumberAttr = model.variables.caseNumberSearchVar;
} else {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b7r+Sdl9fEOkgNyNM1eHaw", callContext.id);
// MyCasesSearch_Original.MyApprovalsCaseNumber = CaseNumberSearch
model.variables.myCasesSearch_OriginalVar.myApprovalsCaseNumberAttr = model.variables.caseNumberSearchVar;
}

}

}

return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_HVdaZYfVkykRITcpzVxAg", callContext.id) && (model.variables.caseNumberSearchVar === ""))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+kJY5An+Pkq9sWcxuCwRZA", callContext.id);
// Execute Action: SearchOnClick
return controller._searchOnClick$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Piir3jVhDUqE2V9VbNti_A", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Piir3jVhDUqE2V9VbNti_A", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ULVVFbXmbkWYnV7fCWCiUQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:ULVVFbXmbkWYnV7fCWCiUQ", callContext.id);
throw ex;

});
};
Controller.prototype._clearSearchFilter$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ClearSearchFilter");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Gr1cGnEKDkya1J+dYlbRVg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.Gr1cGnEKDkya1J+dYlbRVg:jtf_CeUlo8wYz2OX+9+kRg", "PHICore", "ClearSearchFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zX519131sEWvLSXEaW79NA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ozicioiffU2HdZBQDXFWYA", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9VkouCtmUaoGKVaug7tMA", callContext.id);
// CaseNumberSearch = ""
model.variables.caseNumberSearchVar = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9VkouCtmUaoGKVaug7tMA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MyCasesSearch_Original.MyCasesCaseNumber = ""
model.variables.myCasesSearch_OriginalVar.myCasesCaseNumberAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9VkouCtmUaoGKVaug7tMA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SearchFilter_MyCases = EmptyFilter
model.variables.searchFilter_MyCasesVar = model.variables.emptyFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l39wG05cpk6h8ZT9d97jmQ", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iMP4HzfwWU6sv0nl1nwBsg", callContext.id);
// MyCasesSearch_Original.MyApprovalsCaseNumber = ""
model.variables.myCasesSearch_OriginalVar.myApprovalsCaseNumberAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iMP4HzfwWU6sv0nl1nwBsg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CaseNumberSearch = ""
model.variables.caseNumberSearchVar = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iMP4HzfwWU6sv0nl1nwBsg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SearchFilter_MyTeamCases = EmptyFilter
model.variables.searchFilter_MyTeamCasesVar = model.variables.emptyFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l39wG05cpk6h8ZT9d97jmQ", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jquJxtwp1U+jV4oWyw915g", callContext.id);
// MyCasesSearch_Original.MyTeamCasesNumber = ""
model.variables.myCasesSearch_OriginalVar.myTeamCasesNumberAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jquJxtwp1U+jV4oWyw915g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SearchFilter_Approvals = EmptyFilter
model.variables.searchFilter_ApprovalsVar = model.variables.emptyFilterVar;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jquJxtwp1U+jV4oWyw915g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// CaseNumberSearch = ""
model.variables.caseNumberSearchVar = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l39wG05cpk6h8ZT9d97jmQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZoQzgcyFvEyxMuBl00mdIg", callContext.id);
}

}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Gr1cGnEKDkya1J+dYlbRVg", callContext.id);
}

};
Controller.prototype._tabsInitialized$Action = function (tabsIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TabsInitialized");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.TabsInitialized$vars"))());
vars.value.tabsIdInLocal = tabsIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:9471IOXiR0uTia9so+grww:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.9471IOXiR0uTia9so+grww:WErKN9lRHFqbr37ocOueDw", "PHICore", "TabsInitialized", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rU74Of92OEqQJY9D4MUCtQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pNjvzEbbQUOBTdMlge1ksg", callContext.id);
controller.safeExecuteJSNode(PHICore_MainFlow_Dashboard_mvc_controller_TabsInitialized_JavaScript1JS, "JavaScript1", "TabsInitialized", {
TabsWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.tabsIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hykvcdUDRU2grB89KgGLtA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9471IOXiR0uTia9so+grww", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.TabsInitialized$vars", [{
name: "TabsId",
attrName: "tabsIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._toggle_RestrictedPopup$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_RestrictedPopup");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:8XZJI3PTKUasZe3HU6C41Q:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.8XZJI3PTKUasZe3HU6C41Q:fIY98PtmVJqQM9CHQ+Xyfw", "PHICore", "Toggle_RestrictedPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NboeCsVYnkeaB_ePNJGeoQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YgJwbzXGhkamcLZA2JvrlA", callContext.id);
// ShowPopup_Restricted = notShowPopup_Restricted
model.variables.showPopup_RestrictedVar = !(model.variables.showPopup_RestrictedVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7zR_3bcM8EaPsxAm59j3Uw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8XZJI3PTKUasZe3HU6C41Q", callContext.id);
}

};
Controller.prototype._assignCaseTeam_PopupEventAssignCase$Action = function (isProceedIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("AssignCaseTeam_PopupEventAssignCase");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.AssignCaseTeam_PopupEventAssignCase$vars"))());
vars.value.isProceedInLocal = isProceedIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:vYGUJJzjOEacvHa0qlGO9w:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.vYGUJJzjOEacvHa0qlGO9w:AN0WA5szhcbAAX28qCzeqQ", "PHICore", "AssignCaseTeam_PopupEventAssignCase", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kLUq2JysOEi7qK2+WpYcTQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IcR7MfoEzUGg9EGYGxwIRw", callContext.id) && vars.value.isProceedInLocal)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:shCtoyW0b0arALP7Y7tCgQ", callContext.id) && (model.variables.activeCaseTabIn === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:RSsywQFzb0Kn48P65WRbtw", callContext.id);
// Execute Action: ResetSelectedMyCases
controller._resetSelectedMyCases$Action(callContext);
} else {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SaCWPmghHEmCMN+pj1Nzpg", callContext.id) && (model.variables.activeCaseTabIn === 1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3gsPERfOCEGT2gSRSSu2ug", callContext.id);
// Execute Action: ResetSelectedMyTeamCases
controller._resetSelectedMyTeamCases$Action(callContext);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_DSw++JgP02W60cXGrIJ3Q", callContext.id);
// Execute Action: ResetSelectedMyApprovals
controller._resetSelectedMyApprovals$Action(callContext);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PBowuYv2rUaks5HeXRcniw", callContext.id);
// Refresh Query: GetCasesByOwnerUserID
var result = controller.getCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.myCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0ix_Yl15ukefTvkFTbMU1w", callContext.id);
// Refresh Query: GetCasesByOwnerUserID_NoFilter
var result = controller.getCasesByOwnerUserID_NoFilter$AggrRefresh(1, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9unSNHdNg0K5Nn0I54GNXg", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:k54UBBMrz0iiTPV_B2EsTQ", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID_NoFilter
var result = controller.getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh(1, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6aagFw85MUKRW8c28rgymw", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId
var result = controller.getApprovalsByOwnerUserId$AggrRefresh(model.variables.maxRecordsVar, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3NkqVlggwUmCyhHF3QvgDw", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId_NoFilter
var result = controller.getApprovalsByOwnerUserId_NoFilter$AggrRefresh(1, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result;
});
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oswBy+8+GUKBJ+BD_79JEw", callContext.id);
// Execute Action: Toggle_AssignCase
controller._toggle_AssignCase$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ce3Nmjey6U+L+U0pqQOtfA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:vYGUJJzjOEacvHa0qlGO9w", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:vYGUJJzjOEacvHa0qlGO9w", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.AssignCaseTeam_PopupEventAssignCase$vars", [{
name: "IsProceed",
attrName: "isProceedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._applyMyTeamCasesFilter$Action = function (searchFilterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ApplyMyTeamCasesFilter");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.ApplyMyTeamCasesFilter$vars"))());
vars.value.searchFilterValueInLocal = searchFilterValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:xTwgMrP6ukG23wMI+Y6nuw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.xTwgMrP6ukG23wMI+Y6nuw:PEEeuqdVVQzK8sbeenTKEw", "PHICore", "ApplyMyTeamCasesFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NSLcfPedsE64rl3KL_2Jjw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nnTavLtSYkG6CFtYaCw+5A", callContext.id);
// Execute Action: Toggle_FilterMyTeamCases
controller._toggle_FilterMyTeamCases$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S8nkCstSr0qY5QsAPkM1wg", callContext.id);
// SearchFilter_MyTeamCases = SearchFilterValue
model.variables.searchFilter_MyTeamCasesVar = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:83DL0J8Xw0i5KC6daZPFLA", callContext.id);
// Execute Action: RefreshCurrentTable
return controller._refreshCurrentTable$Action(vars.value.searchFilterValueInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:q7uh1qRfOUyu2ot6uQb4aw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:xTwgMrP6ukG23wMI+Y6nuw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:xTwgMrP6ukG23wMI+Y6nuw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.ApplyMyTeamCasesFilter$vars", [{
name: "SearchFilterValue",
attrName: "searchFilterValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}]);
Controller.prototype._onClickNotification$Action = function (notificationIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickNotification");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnClickNotification$vars"))());
vars.value.notificationInLocal = notificationIn.clone();
var readNotificationVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.readNotificationVar = readNotificationVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:bySEMwYgMUyudY3rEcp0og:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.bySEMwYgMUyudY3rEcp0og:10IgOwZwStNQvep7t+bsLw", "PHICore", "OnClickNotification", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SiWh2mI2REuZekmbAHyo2w", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gWB0G45H9UOn6U6jr1r9LQ", callContext.id);
// Execute Action: ReadNotification
model.flush();
return controller.readNotification$ServerAction(vars.value.notificationInLocal.idAttr, callContext).then(function (value) {
readNotificationVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iIVcNlmqP0e1Ob06T4B+bw", callContext.id);
// ShowNotificationDetail = True
model.variables.showNotificationDetailVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iIVcNlmqP0e1Ob06T4B+bw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// RefreshNotificationBell = True
model.variables.refreshNotificationBellVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iIVcNlmqP0e1Ob06T4B+bw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// NotificationDescription = Notification.Description
model.variables.notificationDescriptionVar = vars.value.notificationInLocal.descriptionAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vxuR90Q8oECfxP5KbrfRYw", callContext.id);
// Refresh Query: GetNotificationsWithReadReceipts
var result = controller.getNotificationsWithReadReceipts$AggrRefresh(5, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ovSHwtq4xk6EcU+0JAEMMw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:bySEMwYgMUyudY3rEcp0og", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:bySEMwYgMUyudY3rEcp0og", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnClickNotification$vars", [{
name: "Notification",
attrName: "notificationInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICore_NotificationModel.NotificationRec();
},
complexType: PHICore_NotificationModel.NotificationRec
}]);
Controller.prototype._resetSelectedMyTeamCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ResetSelectedMyTeamCases");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:kaJtNIp_fUGOnVgzzcrDsQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.kaJtNIp_fUGOnVgzzcrDsQ:UYQQoxrX+cZO7IDi9pIcPw", "PHICore", "ResetSelectedMyTeamCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:I04rJVPOC02eVxE9qarvGQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_TUrxUj6N0uA5ViNeWsNDw", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedTeamCaseListVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Bw25GcDkWkq_5jRPLreB7Q", callContext.id);
// Execute Action: JoinSelectedTeamCaseList
controller._joinSelectedTeamCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_m0184kvJ0yqE2pk3rgiHQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:kaJtNIp_fUGOnVgzzcrDsQ", callContext.id);
}

};
Controller.prototype._onPaginationNavigateMyTeamCases$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnPaginationNavigateMyTeamCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateMyTeamCases$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:YhfvNpuBTEmIGGytp2xX3A:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.YhfvNpuBTEmIGGytp2xX3A:830a5h2EeNSM8wxGO66tvQ", "PHICore", "OnPaginationNavigateMyTeamCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:i7oYWhkbmESA7qCuBeeZJQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// StartIndex = NewStartIndex
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wGYJVxqYSUyX3cplkNm5rw", callContext.id);
// TeamCasesTableVariables.StartIndex = NewStartIndex
model.variables.teamCasesTableVariablesVar.startIndexAttr = vars.value.newStartIndexInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EdQyh14jH0ac7RigEAL52g", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TnUi3XbchE6jzsecEB4gYg", callContext.id);
// TeamCasesTableVariables.SelectCount = 0
model.variables.teamCasesTableVariablesVar.selectCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TnUi3XbchE6jzsecEB4gYg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TeamCasesTableVariables.ClosedCount = 0
model.variables.teamCasesTableVariablesVar.closedCountAttr = 0;
// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}).then(function () {
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:w8riq35JcUmB4CYznUDkHA", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NRuq8rqHdUqTOo912SAw2g", callContext.id) && model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GQ9kKJVVuE6I84oAED756w", callContext.id);
// TeamCasesTableVariables.SelectCount = TeamCasesTableVariables.SelectCount + 1
model.variables.teamCasesTableVariablesVar.selectCountAttr = (model.variables.teamCasesTableVariablesVar.selectCountAttr + 1);
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:66Mp0YQXKkmDEXbBT9Cn5A", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:48v112dBpUGTuq7zwkOkRg", callContext.id) && (model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).caseAttr.caseStatusIdAttr === PHICoreModel.staticEntities.status.closed))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MdmTiWeDVEmZ_W8h6_NF+g", callContext.id);
// TeamCasesTableVariables.ClosedCount = TeamCasesTableVariables.ClosedCount + 1
model.variables.teamCasesTableVariablesVar.closedCountAttr = (model.variables.teamCasesTableVariablesVar.closedCountAttr + 1);
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mSsdqwI7XUSpJ+TBRFIShQ", callContext.id) && ((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length - model.variables.teamCasesTableVariablesVar.closedCountAttr) === model.variables.teamCasesTableVariablesVar.selectCountAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hxbIequ3BECd1jjZrPg8tA", callContext.id);
// TeamCaseAllSelected = True
model.variables.teamCaseAllSelectedVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SYtEdiwYHU2DMFdVvDQo8w", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HmqRb1oCRE6pPgEGABycBQ", callContext.id);
// TeamCaseAllSelected = False
model.variables.teamCaseAllSelectedVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SYtEdiwYHU2DMFdVvDQo8w", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:YhfvNpuBTEmIGGytp2xX3A", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:YhfvNpuBTEmIGGytp2xX3A", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateMyTeamCases$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._toggle_FilterMyTeamCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_FilterMyTeamCases");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:yQvHQERrLEez4Ds5xVwZog:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.yQvHQERrLEez4Ds5xVwZog:se4Ur1XAQ+kUK_0rVxiFpQ", "PHICore", "Toggle_FilterMyTeamCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5R5aCiO6pE2WmVPX_5WJTg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KV7UXhWIDEaQzhQ045ix9g", callContext.id);
// ShowMyTeamCasesFilter = notShowMyTeamCasesFilter
model.variables.showMyTeamCasesFilterVar = !(model.variables.showMyTeamCasesFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GOMVunOKhkm40hLBTduApw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:yQvHQERrLEez4Ds5xVwZog", callContext.id);
}

};
Controller.prototype._toggle_NewRateQuote$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_NewRateQuote");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:qZwNRHIgtEeHi3yS3o0U0A:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.qZwNRHIgtEeHi3yS3o0U0A:3Jcn05OhnwiL7gXjnCVdAw", "PHICore", "Toggle_NewRateQuote", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aGf3l8mKqkOrW5TeRrzaRQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fkozemoSuEeG_cAv6ZjnbA", callContext.id);
// Destination: /PHICore/Quote_Detail
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "Quote_Detail", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:qZwNRHIgtEeHi3yS3o0U0A", callContext.id);
}

};
Controller.prototype._joinSelectedCaseList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("JoinSelectedCaseList");
callContext = controller.callContext(callContext);
var string_JoinVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.string_JoinVar = string_JoinVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:81LbRAumUUm+YS5etgLBUw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.81LbRAumUUm+YS5etgLBUw:oHmz5GSpsLhDc_BhKTve_g", "PHICore", "JoinSelectedCaseList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oR7RIZDp8kaJbxhgb0JRIA", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SwhAQLyi0UeydPhI4wrXQQ", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedMyCaseListVar, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.caseIdentifierAttr);
return target;
}), "#", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LtXiZTCyjEO9aqywXcYD9A", callContext.id);
// SelectedMyCaseText = String_Join.Text
model.variables.selectedMyCaseTextVar = string_JoinVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MLfNpT_d4kmyWYuM8CZxUw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:81LbRAumUUm+YS5etgLBUw", callContext.id);
}

};
Controller.prototype._onRefresh_FilterPopup$Action = function (searchFilterIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnRefresh_FilterPopup");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnRefresh_FilterPopup$vars"))());
vars.value.searchFilterInLocal = searchFilterIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:s2ADRyyII0eiqdgJ8O4L4w:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.s2ADRyyII0eiqdgJ8O4L4w:IK68gp65WbJwp3YtOG0wtw", "PHICore", "OnRefresh_FilterPopup", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xKy8NdPXKUS1OQgTaURjpw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WzP2pFMyZ0WGTOgi4jxJ2Q", callContext.id) && (model.variables.activeCaseTabIn === 1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BDI3QBlWH0+CiT24y3_D1w", callContext.id);
// SearchFilter_MyCases = SearchFilter
model.variables.searchFilter_MyCasesVar = vars.value.searchFilterInLocal;
} else {
if((model.variables.activeCaseTabIn === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sbsBcoZ_AUCgrPEKyJVobg", callContext.id);
// SearchFilter_MyTeamCases = SearchFilter
model.variables.searchFilter_MyTeamCasesVar = vars.value.searchFilterInLocal;
} else {
if((model.variables.activeCaseTabIn === 3)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:bIyEtHIKSkaAdifcGICjBA", callContext.id);
// SearchFilter_Approvals = SearchFilter
model.variables.searchFilter_ApprovalsVar = vars.value.searchFilterInLocal;
}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:psYeiPmGN0Kk4Ut1tSTCKQ", callContext.id);
// IsLoadingFilter = True
model.variables.isLoadingFilterVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FKg+tXeUw0imN1ujF3g_NA", callContext.id);
controller.safeExecuteJSNode(PHICore_MainFlow_Dashboard_mvc_controller_OnRefresh_FilterPopup_SetTimoutJSJS, "SetTimoutJS", "OnRefresh_FilterPopup", null, function ($parameters) {
}, {
Toggle_FilterLoading: controller.clientActionProxies.toggle_FilterLoading$Action
}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5wU6240hFE2GtKjxBptFmQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:s2ADRyyII0eiqdgJ8O4L4w", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnRefresh_FilterPopup$vars", [{
name: "SearchFilter",
attrName: "searchFilterInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}]);
Controller.prototype._onSortMyCases$Action = function (sortByIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnSortMyCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnSortMyCases$vars"))());
vars.value.sortByInLocal = sortByIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:2NBpSWUCJUOkSTWNIT7IlA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.2NBpSWUCJUOkSTWNIT7IlA:Ka9aZZ4LA3YmGtS2E+nD2A", "PHICore", "OnSortMyCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hzq681FkF0Wi9Thl0wb4zw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QV4jLwsoyEOfhBK5JrsasA", callContext.id) && ((PHICoreClientVariables.getMyCasesListSort() === vars.value.sortByInLocal) && ((vars.value.sortByInLocal) !== (""))))) {
// TableSort2 += DESC
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:CDRLdbYaVUqVRb0VbW1KNg", callContext.id);
// MyCasesListSort = SortBy + " DESC"
PHICoreClientVariables.setMyCasesListSort((vars.value.sortByInLocal + " DESC"));
} else {
// TableSort2 = SortBy
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+rUrtcwhqkq4_1yFrzZpoA", callContext.id);
// MyCasesListSort = SortBy
PHICoreClientVariables.setMyCasesListSort(vars.value.sortByInLocal);
}

// StartIndex = 0
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SLZe0iidnEar+esFsDPHHg", callContext.id);
// MyCasesTableVariables.StartIndex = 0
model.variables.myCasesTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jLKrHYwg5USyPTB5aR2ncA", callContext.id);
// Refresh Query: GetCasesByOwnerUserID
var result = controller.getCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.myCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eUlqNBSTq0G_208HeCa9EQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:2NBpSWUCJUOkSTWNIT7IlA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:2NBpSWUCJUOkSTWNIT7IlA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnSortMyCases$vars", [{
name: "SortBy",
attrName: "sortByInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._tabsOnTabChange$Action = function (activeTabIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("TabsOnTabChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.TabsOnTabChange$vars"))());
vars.value.activeTabInLocal = activeTabIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:NvH8SfdUYEybsgPQBKYSjQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.NvH8SfdUYEybsgPQBKYSjQ:5nXiWDEsvLNRAnoGSuy3hQ", "PHICore", "TabsOnTabChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VYHyopuiVUmIAprlQJbaew", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xM95B4hUZkyg6Rnzy2ybcw", callContext.id);
// CaseActiveTab = ActiveTab
model.variables.caseActiveTabVar = vars.value.activeTabInLocal;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JMoxLjOgrEGG5zKPRTJcPg", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Fnc4zVbaz0uGWnrFwkI1FQ", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyCasesCaseNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myCasesCaseNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:K7jW5DhB30imeIkusmEmqw", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QfUMRQ9R1EeyMSZYHyvS_w", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyTeamCasesNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myTeamCasesNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dV_k5eZX5ESPfxgu3Cpzag", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9MK2CVCWWUeTxNdMAVUK0w", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyApprovalsCaseNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myApprovalsCaseNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rPa7nNSM1kqd5WoVVPM4kg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jrTY3EdjXkaEY2KBz0mW0A", callContext.id);
}

}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:NvH8SfdUYEybsgPQBKYSjQ", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.TabsOnTabChange$vars", [{
name: "ActiveTab",
attrName: "activeTabInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onClickAssignTeam$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickAssignTeam");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:BgtNS2Umm0OVKeHAeA4P0Q:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.BgtNS2Umm0OVKeHAeA4P0Q:CthCE9uLeLze4glYJfLvKg", "PHICore", "OnClickAssignTeam", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kYlyev_QZEy+S_v655Kx4g", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dc9kTK1iE0qJOmlCSkIOQw", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:jiUk5y1Hg02DulY5kJ4HmQ", callContext.id);
// SharedSelectedCases = SelectedMyCaseList
model.variables.sharedSelectedCasesVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedMyCaseListVar, new PHICoreModel.CaseIdentifierRecordList(), function (source, target) {
target.caseAttr = source.caseIdentifierAttr;
return target;
});
} else {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KhBwt6UObk2seYa0RbEZiA", callContext.id) && (model.variables.caseActiveTabVar === 1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dt9JIGI2k0iGySSXhgc0Rw", callContext.id);
// SharedSelectedCases = SelectedTeamCaseList
model.variables.sharedSelectedCasesVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedTeamCaseListVar, new PHICoreModel.CaseIdentifierRecordList(), function (source, target) {
target.caseAttr = source.caseInfoIdentifierAttr;
return target;
});
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IO8_oEJ4mU+zpFI3lWZeZg", callContext.id);
// SharedSelectedCases = SelectedMyApprovalList
model.variables.sharedSelectedCasesVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedMyApprovalListVar, new PHICoreModel.CaseIdentifierRecordList(), function (source, target) {
target.caseAttr = source.caseInfoIdentifierAttr;
return target;
});
}

}

// No selected Cases?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8UDgUXQK0Eynn2_Vrl1ACw", callContext.id) && model.variables.sharedSelectedCasesVar.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:P1ar5Xpft0OPjHJaGMTGmA", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Select a case to assign it", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FEav5fYtfUW2zSXeKZgoxw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6UzJWuetDEmQjSiwtlhDZw", callContext.id);
// Execute Action: Toggle_AssignCase
controller._toggle_AssignCase$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:viMtyCWWQE+BZJTyYVpaLw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:BgtNS2Umm0OVKeHAeA4P0Q", callContext.id);
}

};
Controller.prototype._onClick_NewPolicy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_NewPolicy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:OTB3TDd8bUCqtVsuoZQVaA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.OTB3TDd8bUCqtVsuoZQVaA:et72kkY_QoMkETUvH_FVew", "PHICore", "OnClick_NewPolicy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MnirECBloUqlj5K+nW2lIg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:B8NOOdNOU0ysaDTtpkePQQ", callContext.id);
// Destination: /PHICore/PolicyDetails
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "PolicyDetails", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:OTB3TDd8bUCqtVsuoZQVaA", callContext.id);
}

};
Controller.prototype._onPaginationNavigateApprovals$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnPaginationNavigateApprovals");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateApprovals$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:szw1Ya07I0WOOgVtnW85Yw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.szw1Ya07I0WOOgVtnW85Yw:3SRlMfGHXz_PBZMnJLqFZw", "PHICore", "OnPaginationNavigateApprovals", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4W5skWh0iUGSpjIDWiYLIA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// StartIndex = NewStartIndex
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ukqIzFp0Mkikt7jCCgRlXA", callContext.id);
// ApprovalTableVariables.StartIndex = NewStartIndex
model.variables.approvalTableVariablesVar.startIndexAttr = vars.value.newStartIndexInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:a4aqOuhA5UyDm4KSjQYGkQ", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId
var result = controller.getApprovalsByOwnerUserId$AggrRefresh(model.variables.maxRecordsVar, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7MI5lXtwDEOpw2SxKkov8g", callContext.id);
// ApprovalTableVariables.SelectCount = 0
model.variables.approvalTableVariablesVar.selectCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7MI5lXtwDEOpw2SxKkov8g", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ApprovalTableVariables.ClosedCount = 0
model.variables.approvalTableVariablesVar.closedCountAttr = 0;
// Foreach GetApprovalsByOwnerUserId.List
callContext.iterationContext.registerIterationStart(model.variables.getApprovalsByOwnerUserIdAggr.listOut);
}).then(function () {
try {var getApprovalsByOwnerUserIdIterator = callContext.iterationContext.getIterator(model.variables.getApprovalsByOwnerUserIdAggr.listOut);
var getApprovalsByOwnerUserIdIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q1WHx4FvEkaNfdbAcKXSyg", callContext.id) && (getApprovalsByOwnerUserIdIndex < model.variables.getApprovalsByOwnerUserIdAggr.listOut.length))) {
getApprovalsByOwnerUserIdIterator.currentRowNumber = getApprovalsByOwnerUserIdIndex;
// IsSelected?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1NIi8vl4akqVegO69utkzQ", callContext.id) && model.variables.getApprovalsByOwnerUserIdAggr.listOut.getItem(getApprovalsByOwnerUserIdIndex.valueOf()).isSelectedAttr)) {
// Increment Select Count
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C3gX_gBWn0uJ73XVyHyiCA", callContext.id);
// ApprovalTableVariables.SelectCount = ApprovalTableVariables.SelectCount + 1
model.variables.approvalTableVariablesVar.selectCountAttr = (model.variables.approvalTableVariablesVar.selectCountAttr + 1);
}

// Is Closed?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5rmMVTWr6kWW2St6DkUeew", callContext.id) && (model.variables.getApprovalsByOwnerUserIdAggr.listOut.getItem(getApprovalsByOwnerUserIdIndex.valueOf()).caseAttr.caseStatusIdAttr === PHICoreModel.staticEntities.status.closed))) {
// Increment Closed Count
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:atD9JjWl70iY98UPttSrGA", callContext.id);
// ApprovalTableVariables.ClosedCount = ApprovalTableVariables.ClosedCount + 1
model.variables.approvalTableVariablesVar.closedCountAttr = (model.variables.approvalTableVariablesVar.closedCountAttr + 1);
}

getApprovalsByOwnerUserIdIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getApprovalsByOwnerUserIdAggr.listOut);
}

// All non closed selected?
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ULZXeQMTkEmYXbPMaxTNAw", callContext.id) && ((model.variables.getApprovalsByOwnerUserIdAggr.listOut.length - model.variables.myCasesTableVariablesVar.closedCountAttr) === model.variables.myCasesTableVariablesVar.selectCountAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JwxO+g_Wj0CirvU0uBaLQw", callContext.id);
// MyApprovalsSelectAll = True
model.variables.myApprovalsSelectAllVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TbwqBRgqgUmvT_eC1BZNZw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NJwzIqCaO0CCiaA+EqmBUA", callContext.id);
// MyApprovalsSelectAll = False
model.variables.myApprovalsSelectAllVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TbwqBRgqgUmvT_eC1BZNZw", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:szw1Ya07I0WOOgVtnW85Yw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:szw1Ya07I0WOOgVtnW85Yw", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateApprovals$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._applyApprovalsFilter$Action = function (searchFilterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ApplyApprovalsFilter");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.ApplyApprovalsFilter$vars"))());
vars.value.searchFilterValueInLocal = searchFilterValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:KLNqaW6KFk6qDNZV5KScCA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.KLNqaW6KFk6qDNZV5KScCA:EJdJW2vnIsCYKPYEe0y6KA", "PHICore", "ApplyApprovalsFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3yWKChW4z0KRZexwPJEqoQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:z0y6mxTRoE+5CEx8c3xIrQ", callContext.id);
// Execute Action: Toggle_FilterApprovals
controller._toggle_FilterApprovals$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QE80Ce+RLUGroh9khTwmlQ", callContext.id);
// SearchFilter_Approvals = SearchFilterValue
model.variables.searchFilter_ApprovalsVar = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4hVl+c7IjUmY1HrG_0rATQ", callContext.id);
// Execute Action: RefreshCurrentTable
return controller._refreshCurrentTable$Action(vars.value.searchFilterValueInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+R6sGY1wOECnlxp3S8o1Dg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KLNqaW6KFk6qDNZV5KScCA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KLNqaW6KFk6qDNZV5KScCA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.ApplyApprovalsFilter$vars", [{
name: "SearchFilterValue",
attrName: "searchFilterValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}]);
Controller.prototype._onChange_TeamCaseSelect$Action = function (selectedCaseIdIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_TeamCaseSelect");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnChange_TeamCaseSelect$vars"))());
vars.value.selectedCaseIdInLocal = selectedCaseIdIn;
var listFilter_SelectedVar = new OS.DataTypes.VariableHolder();
var listFilter_ClosedVar = new OS.DataTypes.VariableHolder();
var listIndexOfVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listFilter_SelectedVar = listFilter_SelectedVar;
varBag.listFilter_ClosedVar = listFilter_ClosedVar;
varBag.listIndexOfVar = listIndexOfVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:9VkIba6yAEK7t4cvXsJ1Wg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.9VkIba6yAEK7t4cvXsJ1Wg:hGLnAPIroPWqeA4rhjeRmw", "PHICore", "OnChange_TeamCaseSelect", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6eYrKMAQpEiDuLaS0SRULQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sFgtQY7jI0SdcXrTKs++kA", callContext.id) && model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).isSelectedAttr)) {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0XQAmDCiG0Kh10Q4mrmxgQ", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_AssignCaseBulk$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3VOxux+7HEG0r1SPsnCAKw", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedTeamCaseListVar, callContext);
// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nvqoOsoMn0CcHStcfAghTw", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OAJOQcF_P0Oph2tPzGHmgg", callContext.id) && !(vars.value.selectedCaseIdInLocal.equals(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).caseAttr.idAttr)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pdRq6_4JLUCvThv2hKL3ew", callContext.id);
// GetTeamsCasesByOwnerUserID.List.Current.IsSelected = False
model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = false;
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5CImh6segkOeRogPBo_GHQ", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.selectedTeamCaseListVar, function () {
var rec = new PHICoreModel.CaseInfoIdentifierRecord();
rec.caseInfoIdentifierAttr = vars.value.selectedCaseIdInLocal;
return rec;
}(), callContext);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vKKIYCm6sUaCY1OWjFTMAg", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(model.variables.selectedTeamCaseListVar, function (p) {
return p.caseInfoIdentifierAttr.equals(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.idAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UbdxmpjJkEKmzUd_z2LXRA", callContext.id) && (listIndexOfVar.value.positionOut === -1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:PZAO_GmvnUyi7lqGwpPTDg", callContext.id);
return ;

} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7cMSjsqlf0+rcPd9GCnQeA", callContext.id);
// Execute Action: ListRemove
OS.SystemActions.listRemove(model.variables.selectedTeamCaseListVar, listIndexOfVar.value.positionOut, callContext);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:wnOjIes+FE2hKICsnbXLvw", callContext.id);
// Execute Action: JoinSelectedTeamCaseList
controller._joinSelectedTeamCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e8HxAO4tzUGPBAKjahGxUw", callContext.id);
// TeamCasesTableVariables.SelectCount = 0
model.variables.teamCasesTableVariablesVar.selectCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:e8HxAO4tzUGPBAKjahGxUw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TeamCasesTableVariables.ClosedCount = 0
model.variables.teamCasesTableVariablesVar.closedCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MXhfLEMjzE6igqBpdd7hBg", callContext.id);
// Execute Action: ListFilter_Selected
listFilter_SelectedVar.value = OS.SystemActions.listFilter(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut, function (p) {
return p.isSelectedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3rUlPkjVR0GKF0W5ySHS2w", callContext.id);
// Execute Action: ListFilter_Closed
listFilter_ClosedVar.value = OS.SystemActions.listFilter(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut, function (p) {
return (p.caseAttr.caseStatusIdAttr === PHICoreModel.staticEntities.status.closed);
}, callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HFPmL+Nu6UyEAXhRm3Ziqg", callContext.id);
// TeamCasesTableVariables.SelectCount = ListFilter_Selected.FilteredList.Length
model.variables.teamCasesTableVariablesVar.selectCountAttr = listFilter_SelectedVar.value.filteredListOut.length;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HFPmL+Nu6UyEAXhRm3Ziqg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// TeamCasesTableVariables.ClosedCount = ListFilter_Closed.FilteredList.Length
model.variables.teamCasesTableVariablesVar.closedCountAttr = listFilter_ClosedVar.value.filteredListOut.length;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MSRf3kN0bU6TSQNMgZL_jg", callContext.id) && ((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length - model.variables.teamCasesTableVariablesVar.closedCountAttr) === model.variables.teamCasesTableVariablesVar.selectCountAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xNhE5Kw5zUSBdNrLC4lvIA", callContext.id);
// TeamCaseAllSelected = True
model.variables.teamCaseAllSelectedVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b5v8u2hlkEKhoIz8tUrA7Q", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8+q+By4yJUyrSMDwdqyUGw", callContext.id);
// TeamCaseAllSelected = False
model.variables.teamCaseAllSelectedVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:b5v8u2hlkEKhoIz8tUrA7Q", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9VkIba6yAEK7t4cvXsJ1Wg", callContext.id);
}

};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnChange_TeamCaseSelect$vars", [{
name: "SelectedCaseId",
attrName: "selectedCaseIdInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}]);
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:98TUf1Lorkqx2hCOGsTRNA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.98TUf1Lorkqx2hCOGsTRNA:3tY4yjKINFdlqldzCSiXpg", "PHICore", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:yRGQCBEQRE26A0kp2HnCsg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hMuspt_qpUedKSGuZ8D5iQ", callContext.id);
// Execute Action: SetCurrentAsValidURL
Common_CWController.default.setCurrentAsValidURL$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n+0WYyO5L0yhwB_uKdz9+w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:98TUf1Lorkqx2hCOGsTRNA", callContext.id);
}

};
Controller.prototype._getTeamsOnAfterFetch$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetTeamsOnAfterFetch");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:4OiokAj5wkCjT0USZyqxmg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.4OiokAj5wkCjT0USZyqxmg:rpgP6JHbOqHm9opUHybwXA", "PHICore", "GetTeamsOnAfterFetch", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4E_zrZtKe0+A7M6qUsyvQA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:APw6JCYhjUqcIq+Whk5N7w", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SP70rPwsrkGPw7wVOJdy_w", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID_NoFilter
var result = controller.getTeamsCasesByOwnerUserID_NoFilter$AggrRefresh(1, 0, callContext);
model.flush();
return result;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:TGHuYohOnEatA9wev+gDng", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4OiokAj5wkCjT0USZyqxmg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:4OiokAj5wkCjT0USZyqxmg", callContext.id);
throw ex;

});
};
Controller.prototype._onPaginationNavigateMyCases$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnPaginationNavigateMyCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateMyCases$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:L8G6k9_pXEmefUA9LhZEog:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.L8G6k9_pXEmefUA9LhZEog:onRP_LQFP1Hv5XQnSSPjrQ", "PHICore", "OnPaginationNavigateMyCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HUX0e6BOVk66R4KGXNjnAQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// StartIndex = NewStartIndex
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p7z0ozTzGk+sK0RcT06jJQ", callContext.id);
// MyCasesTableVariables.StartIndex = NewStartIndex
model.variables.myCasesTableVariablesVar.startIndexAttr = vars.value.newStartIndexInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:G9QyHi0H6kWp0K+Osx412w", callContext.id);
// Refresh Query: GetCasesByOwnerUserID
var result = controller.getCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.myCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qqrpUaIu1EKxq0OWHqw2tA", callContext.id);
// MyCasesTableVariables.SelectCount = 0
model.variables.myCasesTableVariablesVar.selectCountAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qqrpUaIu1EKxq0OWHqw2tA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// MyCasesTableVariables.ClosedCount = 0
model.variables.myCasesTableVariablesVar.closedCountAttr = 0;
// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}).then(function () {
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:MI+86EjFzEmWdtPiUWowAw", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0zhs+iWiFU61Zhbv0aXDRQ", callContext.id) && model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kQ0yHoOFMk2fMgpdIGReVg", callContext.id);
// MyCasesTableVariables.SelectCount = MyCasesTableVariables.SelectCount + 1
model.variables.myCasesTableVariablesVar.selectCountAttr = (model.variables.myCasesTableVariablesVar.selectCountAttr + 1);
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

// Foreach GetCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesByOwnerUserIDAggr.listOut);
try {var getCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getCasesByOwnerUserIDAggr.listOut);
var getCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:r+KCnlnjMEC2urNiXDex0Q", callContext.id) && (getCasesByOwnerUserIDIndex < model.variables.getCasesByOwnerUserIDAggr.listOut.length))) {
getCasesByOwnerUserIDIterator.currentRowNumber = getCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WT70MtkDhkGaiS5i0d7zXA", callContext.id) && (model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getCurrent(callContext.iterationContext).caseAttr.caseStatusIdAttr === PHICoreModel.staticEntities.status.closed))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:SRSTb5PID0aVehxIapFCKw", callContext.id);
// MyCasesTableVariables.ClosedCount = MyCasesTableVariables.ClosedCount + 1
model.variables.myCasesTableVariablesVar.closedCountAttr = (model.variables.myCasesTableVariablesVar.closedCountAttr + 1);
}

getCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesByOwnerUserIDAggr.listOut);
}

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JDxFRKhDhkW4jP2MnqFkuA", callContext.id) && ((model.variables.getCasesByOwnerUserIDAggr.listOut.length - model.variables.myCasesTableVariablesVar.closedCountAttr) === model.variables.myCasesTableVariablesVar.selectCountAttr))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:k7CngWnhZkS2O1pLvNY7Qg", callContext.id);
// MyApprovalsSelectAll = True
model.variables.myApprovalsSelectAllVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l6sZl0VnXEub6pPSM+ob3g", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8igbqeeAUkeBJnVRT8hUdQ", callContext.id);
// MyApprovalsSelectAll = False
model.variables.myApprovalsSelectAllVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:l6sZl0VnXEub6pPSM+ob3g", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:L8G6k9_pXEmefUA9LhZEog", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:L8G6k9_pXEmefUA9LhZEog", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnPaginationNavigateMyCases$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._joinSelectedTeamCaseList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("JoinSelectedTeamCaseList");
callContext = controller.callContext(callContext);
var string_JoinVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.string_JoinVar = string_JoinVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:kTOrlmwKOkq7O+UCbzTaSg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.kTOrlmwKOkq7O+UCbzTaSg:bWCP9EDADHf0VTBctWibWQ", "PHICore", "JoinSelectedTeamCaseList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:KBE1vYZCH0WcPmHRkYNPmQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9obwH_q_VEqVDrw0P2mrDw", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.selectedTeamCaseListVar, new PHICoreModel.Text1RecordList(), function (source, target) {
target.textAttr.valueAttr = OS.BuiltinFunctions.longIntegerToText(source.caseInfoIdentifierAttr);
return target;
}), "#", callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IEqqyWxWrkuNmoFcu7O3Ww", callContext.id);
// SelectedTeamCaseText = String_Join.Text
model.variables.selectedTeamCaseTextVar = string_JoinVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QDHO4w4fnEWSxh6IMYpyvQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:kTOrlmwKOkq7O+UCbzTaSg", callContext.id);
}

};
Controller.prototype._onClickFilter$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickFilter");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:v_k0mmO6xEicB3hOMAbvCA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.v_k0mmO6xEicB3hOMAbvCA:1mqirIEEiAi_XzSvAitbMA", "PHICore", "OnClickFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lZL9aDzy70iL+HVgPoAgmw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:aIOcp4ctwUaCp5blVNEH3A", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:f36tCBSlJUun0dLX_6kr_Q", callContext.id);
// Execute Action: Toggle_FilterMyCases
controller._toggle_FilterMyCases$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eywMOusO30ylGHoAGlP5+g", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8Ifk0bwjUU2d9MonNBQvfQ", callContext.id);
// Execute Action: Toggle_FilterMyTeamCases
controller._toggle_FilterMyTeamCases$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n9OOTlLQmU6smpKL4abf0Q", callContext.id);
} else {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OkfAjI5jOUi2qYp9apCOTQ", callContext.id);
// Execute Action: Toggle_FilterApprovals
controller._toggle_FilterApprovals$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cNKxgIhmvEO46DmP_Rz4Vg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:1_EDvsOysEu1rL2HZdSYuQ", callContext.id);
}

}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:v_k0mmO6xEicB3hOMAbvCA", callContext.id);
}

};
Controller.prototype._onClickTabAssign_Disabled$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClickTabAssign_Disabled");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:S_Cdpsf_ZkKbZTZlwa6cQA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.S_Cdpsf_ZkKbZTZlwa6cQA:T0_WgAnH8C59FSBSvLhO7w", "PHICore", "OnClickTabAssign_Disabled", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ACJR5MyLeUqzQyeOFZo66w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C4dvwmRPXk6xXqWIDri0cQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:S_Cdpsf_ZkKbZTZlwa6cQA", callContext.id);
}

};
Controller.prototype._deserialize_Filters$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Deserialize_Filters");
callContext = controller.callContext(callContext);
var jSONDeserializeMyApproval_SearchFilterVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(PHICoreModel.Dashboard_CasesFilterRec))());
var jSONDeserializeMyTeamCases_SearchFIlterVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(PHICoreModel.Dashboard_CasesFilterRec))());
var jSONDeserializeMyCases_SearchFilterVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(PHICoreModel.Dashboard_CasesFilterRec))());
varBag.callContext = callContext;
varBag.jSONDeserializeMyApproval_SearchFilterVar = jSONDeserializeMyApproval_SearchFilterVar;
varBag.jSONDeserializeMyTeamCases_SearchFIlterVar = jSONDeserializeMyTeamCases_SearchFIlterVar;
varBag.jSONDeserializeMyCases_SearchFilterVar = jSONDeserializeMyCases_SearchFilterVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:cveTrVopR0qXw9_nF5tZlg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.cveTrVopR0qXw9_nF5tZlg:WMXiqb4CC5cn7sn9al7gnQ", "PHICore", "Deserialize_Filters", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Shrv5AcuvUSeViIbyQ2QBg", callContext.id);
// MyCases_SearchFilter not Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JVwrPxjoWki5Y_Fd1_PMcQ", callContext.id) && ((PHICoreClientVariables.getMyCases_SearchFilter()) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DfncwRSb0kW3E+eEytIdCQ", callContext.id);
// JSON Deserialize: JSONDeserializeMyCases_SearchFilter
jSONDeserializeMyCases_SearchFilterVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(PHICoreClientVariables.getMyCases_SearchFilter(), PHICoreModel.Dashboard_CasesFilterRec, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xMnIaSln9U+5xFgNGbAFaQ", callContext.id);
// SearchFilter_MyCases = JSONDeserializeMyCases_SearchFilter.Data
model.variables.searchFilter_MyCasesVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyCases_SearchFilterVar.value.dataOut, new PHICoreModel.SearchFilterRec(), function (source, target) {
target = source.searchFilterAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xMnIaSln9U+5xFgNGbAFaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_MyCases = JSONDeserializeMyCases_SearchFilter.Data.JoinedFilter
model.variables.joinedStrings_MyCasesVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyCases_SearchFilterVar.value.dataOut.joinedFilterAttr, new PHICoreModel.TextTextTextTextTextTextTextTextRecord(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
}

// MyTeamCases_SearchFIlter not Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6eU2wO1EcEC6axPPA1xmHw", callContext.id) && ((PHICoreClientVariables.getMyTeamCases_SearchFIlter()) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qZlWkzNltkeB_OX57dy_pw", callContext.id);
// JSON Deserialize: JSONDeserializeMyTeamCases_SearchFIlter
jSONDeserializeMyTeamCases_SearchFIlterVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(PHICoreClientVariables.getMyTeamCases_SearchFIlter(), PHICoreModel.Dashboard_CasesFilterRec, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vn2ZZykfNEK9bMqUUjBWCg", callContext.id);
// SearchFilter_MyTeamCases = JSONDeserializeMyTeamCases_SearchFIlter.Data
model.variables.searchFilter_MyTeamCasesVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyTeamCases_SearchFIlterVar.value.dataOut, new PHICoreModel.SearchFilterRec(), function (source, target) {
target = source.searchFilterAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:vn2ZZykfNEK9bMqUUjBWCg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_MyTeamCases = JSONDeserializeMyTeamCases_SearchFIlter.Data.JoinedFilter
model.variables.joinedStrings_MyTeamCasesVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyTeamCases_SearchFIlterVar.value.dataOut.joinedFilterAttr, new PHICoreModel.TextTextTextTextTextTextTextTextRecord(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
}

// MyApproval_SearchFilter not Empty
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zvbLYyvSaEyDSO2npF0+cg", callContext.id) && ((PHICoreClientVariables.getMyApproval_SearchFilter()) !== ("")))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:J54aVqfE+k+h5bhrO5gSxw", callContext.id);
// JSON Deserialize: JSONDeserializeMyApproval_SearchFilter
jSONDeserializeMyApproval_SearchFilterVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(PHICoreClientVariables.getMyApproval_SearchFilter(), PHICoreModel.Dashboard_CasesFilterRec, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VJluF5YajUiaSCfpgiKwUg", callContext.id);
// SearchFilter_Approvals = JSONDeserializeMyApproval_SearchFilter.Data
model.variables.searchFilter_ApprovalsVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyApproval_SearchFilterVar.value.dataOut, new PHICoreModel.SearchFilterRec(), function (source, target) {
target = source.searchFilterAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:VJluF5YajUiaSCfpgiKwUg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_Approvals = JSONDeserializeMyApproval_SearchFilter.Data.JoinedFilter
model.variables.joinedStrings_ApprovalsVar = OS.DataConversion.JSConversions.typeConvertRecord(jSONDeserializeMyApproval_SearchFilterVar.value.dataOut.joinedFilterAttr, new PHICoreModel.TextTextTextTextTextTextTextTextRecord(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fD1ao4fsuk2H_q0DbymnNw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fD1ao4fsuk2H_q0DbymnNw", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:cveTrVopR0qXw9_nF5tZlg", callContext.id);
}

};
Controller.prototype._toggle_FilterMyCases$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_FilterMyCases");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:5OfPtFDB5029N_A284kU4Q:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.5OfPtFDB5029N_A284kU4Q:QE1D46xyp9IadJ2B8zOtcQ", "PHICore", "Toggle_FilterMyCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:efxzN3kGXk68RI2W6n1pKQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:33_Wir70dES+88zhMX7Bkg", callContext.id);
// ShowMyCasesFilter = notShowMyCasesFilter
model.variables.showMyCasesFilterVar = !(model.variables.showMyCasesFilterVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:sqLbweALYEupcisjwC0+9Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:5OfPtFDB5029N_A284kU4Q", callContext.id);
}

};
Controller.prototype._refreshCurrentTable$Action = function (searchFilterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RefreshCurrentTable");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.RefreshCurrentTable$vars"))());
vars.value.searchFilterValueInLocal = searchFilterValueIn.clone();
var dashboardStringJoin_FiltersVar = new OS.DataTypes.VariableHolder();
var jSONSerializeSearch_MyTeamVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONSerializeSearch_MyCasesVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONSerializeSearch_MyApprovalVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.dashboardStringJoin_FiltersVar = dashboardStringJoin_FiltersVar;
varBag.jSONSerializeSearch_MyTeamVar = jSONSerializeSearch_MyTeamVar;
varBag.jSONSerializeSearch_MyCasesVar = jSONSerializeSearch_MyCasesVar;
varBag.jSONSerializeSearch_MyApprovalVar = jSONSerializeSearch_MyApprovalVar;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:QIhMuezLxU6hcBGSrwE7ZQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.QIhMuezLxU6hcBGSrwE7ZQ:mmqTxjgVFRptLrZU1aqHIA", "PHICore", "RefreshCurrentTable", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UjwVfa8YTUKbKpfZXEZ_yQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:mnkt+TyqJUSCtzeiicSLtw", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id);
// Category = SearchFilter_MyCases.Category
vars.value.categoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.categoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SubCategory = SearchFilter_MyCases.SubCategory
vars.value.subCategoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.subCategoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SLAs = SearchFilter_MyCases.SLA
vars.value.sLAsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.sLAAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Priority = SearchFilter_MyCases.Priority
vars.value.priorityVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.priorityAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Status = SearchFilter_MyCases.Status
vars.value.statusVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.statusAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Teams = SearchFilter_MyCases.Teams
vars.value.teamsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.teamsAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// AssignedTo = SearchFilter_MyCases.AssignedTo
vars.value.assignedToVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.assignedToAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:62aNzElfwUSyR23xXu0G_w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// RaisedBy = SearchFilter_MyCases.RaisedBy
vars.value.raisedByVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyCasesVar.raisedByAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
} else {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id);
// Category = SearchFilter_MyTeamCases.Category
vars.value.categoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.categoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SubCategory = SearchFilter_MyTeamCases.SubCategory
vars.value.subCategoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.subCategoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SLAs = SearchFilter_MyTeamCases.SLA
vars.value.sLAsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.sLAAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Priority = SearchFilter_MyTeamCases.Priority
vars.value.priorityVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.priorityAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Status = SearchFilter_MyTeamCases.Status
vars.value.statusVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.statusAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Teams = SearchFilter_MyTeamCases.Teams
vars.value.teamsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.teamsAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// AssignedTo = SearchFilter_MyTeamCases.AssignedTo
vars.value.assignedToVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.assignedToAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hTMyWvx0CEiUQEZUt9kURA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// RaisedBy = SearchFilter_MyTeamCases.RaisedBy
vars.value.raisedByVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_MyTeamCasesVar.raisedByAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
} else {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id);
// Category = SearchFilter_Approvals.Category
vars.value.categoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.categoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SubCategory = SearchFilter_Approvals.SubCategory
vars.value.subCategoryVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.subCategoryAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SLAs = SearchFilter_Approvals.SLA
vars.value.sLAsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.sLAAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Priority = SearchFilter_Approvals.Priority
vars.value.priorityVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.priorityAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Status = SearchFilter_Approvals.Status
vars.value.statusVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.statusAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Teams = SearchFilter_Approvals.Teams
vars.value.teamsVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.teamsAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// AssignedTo = SearchFilter_Approvals.AssignedTo
vars.value.assignedToVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.assignedToAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0hmt2dHWIkerRhZJvoZ5Sw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// RaisedBy = SearchFilter_Approvals.RaisedBy
vars.value.raisedByVar = OS.DataConversion.JSConversions.typeConvertRecordList(model.variables.searchFilter_ApprovalsVar.raisedByAttr, new PHICoreModel.DashboardDropdownSearchTagList(), function (source, target) {
target.valueAttr = source.valueAttr;
return target;
});
}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GA3hFstEikm4YNgpjT7WEA", callContext.id);
// Execute Action: DashboardStringJoin_Filters
model.flush();
return controller.dashboardStringJoin$ServerAction(vars.value.categoryVar, vars.value.subCategoryVar, vars.value.sLAsVar, vars.value.priorityVar, vars.value.statusVar, vars.value.teamsVar, vars.value.assignedToVar, vars.value.raisedByVar, callContext).then(function (value) {
dashboardStringJoin_FiltersVar.value = value;
}).then(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GZa6qh2lIU6DkTUHM5nNTw", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id);
// JoinedStrings_MyCases.Category = DashboardStringJoin_Filters.CategoryStringJoined
model.variables.joinedStrings_MyCasesVar.categoryAttr = dashboardStringJoin_FiltersVar.value.categoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_MyCases.SubCategory = DashboardStringJoin_Filters.SubCategoryStringJoined
model.variables.joinedStrings_MyCasesVar.subCategoryAttr = dashboardStringJoin_FiltersVar.value.subCategoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// JoinedStrings_MyCases.SLAs = DashboardStringJoin_Filters.SLAsStringJoined
model.variables.joinedStrings_MyCasesVar.sLAsAttr = dashboardStringJoin_FiltersVar.value.sLAsStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// JoinedStrings_MyCases.Priority = DashboardStringJoin_Filters.PriorityStringJoined
model.variables.joinedStrings_MyCasesVar.priorityAttr = dashboardStringJoin_FiltersVar.value.priorityStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// JoinedStrings_MyCases.Status = DashboardStringJoin_Filters.StatusStringJoined
model.variables.joinedStrings_MyCasesVar.statusAttr = dashboardStringJoin_FiltersVar.value.statusStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// JoinedStrings_MyCases.RaisedBy = DashboardStringJoin_Filters.RaisedByStringJoined
model.variables.joinedStrings_MyCasesVar.raisedByAttr = dashboardStringJoin_FiltersVar.value.raisedByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// JoinedStrings_MyCases.AssignedTo = DashboardStringJoin_Filters.AssignedToByStringJoined
model.variables.joinedStrings_MyCasesVar.assignedToAttr = dashboardStringJoin_FiltersVar.value.assignedToByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// JoinedStrings_MyCases.Teams = DashboardStringJoin_Filters.TeamByStringJoined
model.variables.joinedStrings_MyCasesVar.teamsAttr = dashboardStringJoin_FiltersVar.value.teamByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// MyCasesTableVariables.StartIndex = 0
model.variables.myCasesTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Dashboard_CasesFilter.SearchFilter = SearchFilterValue
vars.value.dashboard_CasesFilterVar.searchFilterAttr = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gzLzQQjyGkKFyWslLOhb7Q", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Dashboard_CasesFilter.JoinedFilter = JoinedStrings_MyCases
vars.value.dashboard_CasesFilterVar.joinedFilterAttr = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.joinedStrings_MyCasesVar, new PHICoreModel.JoinedFilterRec(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L_K5YHgX3ke_h3xyOpmOuw", callContext.id);
// JSON Serialize: JSONSerializeSearch_MyCases
jSONSerializeSearch_MyCasesVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.dashboard_CasesFilterVar, true, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eWa7LmQiQkO_qZEWbGoxGA", callContext.id);
// MyCases_SearchFilter = JSONSerializeSearch_MyCases.JSON
PHICoreClientVariables.setMyCases_SearchFilter(jSONSerializeSearch_MyCasesVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0YTxnnYd5U+RyOEA1Ocz3A", callContext.id);
// Refresh Query: GetCasesByOwnerUserID
var result = controller.getCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.myCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:YmNe0eZiAkGXbiWtHgYXaA", callContext.id);
});
} else {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:axUN6cycckWZnVanPIN+7w", callContext.id) && (model.variables.caseActiveTabVar === 1))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id);
// JoinedStrings_MyTeamCases.Category = DashboardStringJoin_Filters.CategoryStringJoined
model.variables.joinedStrings_MyTeamCasesVar.categoryAttr = dashboardStringJoin_FiltersVar.value.categoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_MyTeamCases.SubCategory = DashboardStringJoin_Filters.SubCategoryStringJoined
model.variables.joinedStrings_MyTeamCasesVar.subCategoryAttr = dashboardStringJoin_FiltersVar.value.subCategoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// JoinedStrings_MyTeamCases.SLAs = DashboardStringJoin_Filters.SLAsStringJoined
model.variables.joinedStrings_MyTeamCasesVar.sLAsAttr = dashboardStringJoin_FiltersVar.value.sLAsStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// JoinedStrings_MyTeamCases.Priority = DashboardStringJoin_Filters.PriorityStringJoined
model.variables.joinedStrings_MyTeamCasesVar.priorityAttr = dashboardStringJoin_FiltersVar.value.priorityStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// JoinedStrings_MyTeamCases.Status = DashboardStringJoin_Filters.StatusStringJoined
model.variables.joinedStrings_MyTeamCasesVar.statusAttr = dashboardStringJoin_FiltersVar.value.statusStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// JoinedStrings_MyTeamCases.RaisedBy = DashboardStringJoin_Filters.RaisedByStringJoined
model.variables.joinedStrings_MyTeamCasesVar.raisedByAttr = dashboardStringJoin_FiltersVar.value.raisedByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// JoinedStrings_MyTeamCases.AssignedTo = DashboardStringJoin_Filters.AssignedToByStringJoined
model.variables.joinedStrings_MyTeamCasesVar.assignedToAttr = dashboardStringJoin_FiltersVar.value.assignedToByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// JoinedStrings_MyTeamCases.Teams = DashboardStringJoin_Filters.TeamByStringJoined
model.variables.joinedStrings_MyTeamCasesVar.teamsAttr = dashboardStringJoin_FiltersVar.value.teamByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// TeamCasesTableVariables.StartIndex = 0
model.variables.teamCasesTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Dashboard_CasesFilter.SearchFilter = SearchFilterValue
vars.value.dashboard_CasesFilterVar.searchFilterAttr = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fIc4TiTmR0GTBg8q7jLBRA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Dashboard_CasesFilter.JoinedFilter = JoinedStrings_MyTeamCases
vars.value.dashboard_CasesFilterVar.joinedFilterAttr = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.joinedStrings_MyTeamCasesVar, new PHICoreModel.JoinedFilterRec(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:BlmbNZ7no0G1mzJPbj_nEA", callContext.id);
// JSON Serialize: JSONSerializeSearch_MyTeam
jSONSerializeSearch_MyTeamVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.dashboard_CasesFilterVar, true, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9o6Pvknd6kOIlGe4kEF6Lw", callContext.id);
// MyTeamCases_SearchFIlter = JSONSerializeSearch_MyTeam.JSON
PHICoreClientVariables.setMyTeamCases_SearchFIlter(jSONSerializeSearch_MyTeamVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:M_RYzBErokq4Y2sjZyB1nQ", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:9c0IbnPDAkC4HGe0sX1few", callContext.id);
});
} else {
// Is Approvals?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:p_SttvpnFkqEOKMehj7iMA", callContext.id) && (model.variables.caseActiveTabVar === 2))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id);
// JoinedStrings_Approvals.Category = DashboardStringJoin_Filters.CategoryStringJoined
model.variables.joinedStrings_ApprovalsVar.categoryAttr = dashboardStringJoin_FiltersVar.value.categoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// JoinedStrings_Approvals.SubCategory = DashboardStringJoin_Filters.SubCategoryStringJoined
model.variables.joinedStrings_ApprovalsVar.subCategoryAttr = dashboardStringJoin_FiltersVar.value.subCategoryStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// JoinedStrings_Approvals.SLAs = DashboardStringJoin_Filters.SLAsStringJoined
model.variables.joinedStrings_ApprovalsVar.sLAsAttr = dashboardStringJoin_FiltersVar.value.sLAsStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// JoinedStrings_Approvals.Priority = DashboardStringJoin_Filters.PriorityStringJoined
model.variables.joinedStrings_ApprovalsVar.priorityAttr = dashboardStringJoin_FiltersVar.value.priorityStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// JoinedStrings_Approvals.Status = DashboardStringJoin_Filters.StatusStringJoined
model.variables.joinedStrings_ApprovalsVar.statusAttr = dashboardStringJoin_FiltersVar.value.statusStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// JoinedStrings_Approvals.RaisedBy = DashboardStringJoin_Filters.RaisedByStringJoined
model.variables.joinedStrings_ApprovalsVar.raisedByAttr = dashboardStringJoin_FiltersVar.value.raisedByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// JoinedStrings_Approvals.AssignedTo = DashboardStringJoin_Filters.AssignedToByStringJoined
model.variables.joinedStrings_ApprovalsVar.assignedToAttr = dashboardStringJoin_FiltersVar.value.assignedToByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// JoinedStrings_Approvals.Teams = DashboardStringJoin_Filters.TeamByStringJoined
model.variables.joinedStrings_ApprovalsVar.teamsAttr = dashboardStringJoin_FiltersVar.value.teamByStringJoinedOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// ApprovalTableVariables.StartIndex = 0
model.variables.approvalTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Dashboard_CasesFilter.SearchFilter = SearchFilterValue
vars.value.dashboard_CasesFilterVar.searchFilterAttr = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QJiFfQDVtUCSJklfR0JzAw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Dashboard_CasesFilter.JoinedFilter = JoinedStrings_Approvals
vars.value.dashboard_CasesFilterVar.joinedFilterAttr = OS.DataConversion.JSConversions.typeConvertRecord(model.variables.joinedStrings_ApprovalsVar, new PHICoreModel.JoinedFilterRec(), function (source, target) {
target.assignedToAttr = source.assignedToAttr;
target.categoryAttr = source.categoryAttr;
target.priorityAttr = source.priorityAttr;
target.raisedByAttr = source.raisedByAttr;
target.sLAsAttr = source.sLAsAttr;
target.statusAttr = source.statusAttr;
target.subCategoryAttr = source.subCategoryAttr;
target.teamsAttr = source.teamsAttr;
return target;
});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZjjUzP9i7Eq3GGGTJhOi0w", callContext.id);
// JSON Serialize: JSONSerializeSearch_MyApproval
jSONSerializeSearch_MyApprovalVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.dashboard_CasesFilterVar, true, false);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FLoZqoo5Kka10UVl9WyquA", callContext.id);
// MyApproval_SearchFilter = JSONSerializeSearch_MyApproval.JSON
PHICoreClientVariables.setMyApproval_SearchFilter(jSONSerializeSearch_MyApprovalVar.value.jSONOut);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uGGF7_4vAUyxcsHddhMu7g", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId
var result = controller.getApprovalsByOwnerUserId$AggrRefresh(model.variables.maxRecordsVar, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hjn_dkJHdEqH62k+qtQ6Hg", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dFiWpUA0TUuisESZn6d9wg", callContext.id);
}

});
}

});
}

});
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:QIhMuezLxU6hcBGSrwE7ZQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:QIhMuezLxU6hcBGSrwE7ZQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.RefreshCurrentTable$vars", [{
name: "SearchFilterValue",
attrName: "searchFilterValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}, {
name: "Category",
attrName: "categoryVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "SubCategory",
attrName: "subCategoryVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "SLAs",
attrName: "sLAsVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "Priority",
attrName: "priorityVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "Status",
attrName: "statusVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "Teams",
attrName: "teamsVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "AssignedTo",
attrName: "assignedToVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "RaisedBy",
attrName: "raisedByVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new PHICoreModel.DashboardDropdownSearchTagList();
},
complexType: PHICoreModel.DashboardDropdownSearchTagList
}, {
name: "Dashboard_CasesFilter",
attrName: "dashboard_CasesFilterVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.Dashboard_CasesFilterRec();
},
complexType: PHICoreModel.Dashboard_CasesFilterRec
}]);
Controller.prototype._onSortMyApprovals$Action = function (sortByIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnSortMyApprovals");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnSortMyApprovals$vars"))());
vars.value.sortByInLocal = sortByIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:8oW2uiXzvk+e5R7QUHZjVQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.8oW2uiXzvk+e5R7QUHZjVQ:GgzHxL7CgNlkkHAKlkRptA", "PHICore", "OnSortMyApprovals", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5MIpYazVAkyzSbQHWDPRhw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:_XaFqb4jjkaLTgo_01UhOg", callContext.id) && ((PHICoreClientVariables.getMyApprovalCasesListSort() === vars.value.sortByInLocal) && ((vars.value.sortByInLocal) !== (""))))) {
// TableSort2 += DESC
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:NJ+X5+XSXUK2g8OUc0H+AQ", callContext.id);
// MyApprovalCasesListSort = SortBy + " DESC"
PHICoreClientVariables.setMyApprovalCasesListSort((vars.value.sortByInLocal + " DESC"));
} else {
// TableSort2 = SortBy
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:dS4KrEIa1kWAkb1o6_3M+w", callContext.id);
// MyApprovalCasesListSort = SortBy
PHICoreClientVariables.setMyApprovalCasesListSort(vars.value.sortByInLocal);
}

// StartIndex = 0
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:3F6Ra6GYBESXq6ud5Q6ybw", callContext.id);
// ApprovalTableVariables.StartIndex = 0
model.variables.approvalTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+TGplEXTwEeLSPcbaeSy7Q", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId
var result = controller.getApprovalsByOwnerUserId$AggrRefresh(model.variables.maxRecordsVar, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0rkXDtoQ7k6n64FxStSstw", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8oW2uiXzvk+e5R7QUHZjVQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:8oW2uiXzvk+e5R7QUHZjVQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnSortMyApprovals$vars", [{
name: "SortBy",
attrName: "sortByInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onChange_MyCaseSelectAll$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_MyCaseSelectAll");
callContext = controller.callContext(callContext);
var listIndexOf2Var = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listIndexOf2Var = listIndexOf2Var;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:unb9v0t6yk2uE0Riwo1t3Q:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.unb9v0t6yk2uE0Riwo1t3Q:aKUvh3YTjObSOFirlLmneg", "PHICore", "OnChange_MyCaseSelectAll", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gVJNOt5ahkS4eE0QpXf0aQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:AOhxO3EYvk67lDbLX9koEQ", callContext.id) && model.variables.myApprovalsSelectAllVar)) {
// Foreach GetCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesByOwnerUserIDAggr.listOut);
try {var getCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getCasesByOwnerUserIDAggr.listOut);
var getCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U8IbhEZXRUqvcQuEfHCN6Q", callContext.id) && (getCasesByOwnerUserIDIndex < model.variables.getCasesByOwnerUserIDAggr.listOut.length))) {
getCasesByOwnerUserIDIterator.currentRowNumber = getCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:JXCErBK0Fk+7sWSU9OC0gg", callContext.id) && (((model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).caseAttr.caseStatusIdAttr) !== (PHICoreModel.staticEntities.status.closed)) && ((model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).caseInfoAttr.approvalStatusIdAttr) !== (PHICoreModel.staticEntities.approvalStatus.pending))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:U9PEEbsli0us_4sAy0gaSQ", callContext.id);
// GetCasesByOwnerUserID.List.Current.IsSelected = True
model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Q+UPKzLCi0KdRm5UtZInDA", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.selectedMyCaseListVar, OS.DataConversion.JSConversions.typeConvertRecord(model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()), new PHICoreModel.CaseIdentifierRecord(), function (source, target) {
target.caseIdentifierAttr = source.caseAttr.idAttr;
return target;
}), callContext);
}

getCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesByOwnerUserIDAggr.listOut);
}

} else {
// Foreach GetCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getCasesByOwnerUserIDAggr.listOut);
try {var getCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getCasesByOwnerUserIDAggr.listOut);
var getCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ENlKdliSFk6xTwyrXIyn6g", callContext.id) && (getCasesByOwnerUserIDIndex < model.variables.getCasesByOwnerUserIDAggr.listOut.length))) {
getCasesByOwnerUserIDIterator.currentRowNumber = getCasesByOwnerUserIDIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uNBGYCE+rE+ESHAugue51A", callContext.id);
// Execute Action: ListIndexOf2
listIndexOf2Var.value = OS.SystemActions.listIndexOf(model.variables.selectedMyCaseListVar, function (p) {
return p.caseIdentifierAttr.equals(model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).caseAttr.idAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Fw4KYunNf0a2o1YDhAOhZw", callContext.id) && !((listIndexOf2Var.value.positionOut === -1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:+gyihApkz0SoHYP9EFaDMw", callContext.id);
// Execute Action: ListRemove2
OS.SystemActions.listRemove(model.variables.selectedMyCaseListVar, listIndexOf2Var.value.positionOut, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5SJucYpaMkCcMyqC6Lbjfg", callContext.id);
// GetCasesByOwnerUserID.List.Current.IsSelected = False
model.variables.getCasesByOwnerUserIDAggr.listOut.getItem(getCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = false;
}

getCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getCasesByOwnerUserIDAggr.listOut);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZVuT78tdsUOQICu52+nMiQ", callContext.id);
// Execute Action: JoinSelectedCaseList
controller._joinSelectedCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7k3IOzGFsUmCvQLB0doz2g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:unb9v0t6yk2uE0Riwo1t3Q", callContext.id);
}

};
Controller.prototype._applyMyCasesFilter$Action = function (searchFilterValueIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ApplyMyCasesFilter");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.ApplyMyCasesFilter$vars"))());
vars.value.searchFilterValueInLocal = searchFilterValueIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:9yk4xgfVAEeCEESpxGFlJQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.9yk4xgfVAEeCEESpxGFlJQ:r_aJC0VZyv76U3YmIo2ACQ", "PHICore", "ApplyMyCasesFilter", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:XK3UYXlcVUeVRAPWkvsVrg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Ze5rk9xe3UW4XLKOwbmpXA", callContext.id);
// Execute Action: Toggle_FilterMyCases
controller._toggle_FilterMyCases$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:qNebAGkKfkelx5aJnoCHpg", callContext.id);
// SearchFilter_MyCases = SearchFilterValue
model.variables.searchFilter_MyCasesVar = vars.value.searchFilterValueInLocal;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:uBSDEEUEwUqCD54HJSdmqg", callContext.id);
// Execute Action: RefreshCurrentTable
return controller._refreshCurrentTable$Action(vars.value.searchFilterValueInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:lXI2oxgtMkyIPEa+6uTbkg", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9yk4xgfVAEeCEESpxGFlJQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9yk4xgfVAEeCEESpxGFlJQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.ApplyMyCasesFilter$vars", [{
name: "SearchFilterValue",
attrName: "searchFilterValueInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new PHICoreModel.SearchFilterRec();
},
complexType: PHICoreModel.SearchFilterRec
}]);
Controller.prototype._resetSelectedMyApprovals$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ResetSelectedMyApprovals");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:fUw1zScUFEuEQxV0cPLaKw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.fUw1zScUFEuEQxV0cPLaKw:tauInnKrNxH8nDiQ7LAUJw", "PHICore", "ResetSelectedMyApprovals", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:kQOFX5ANLkGoO1A7inJnxg", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zTQZ_J+C8E+qWCVEwMuvXg", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedMyApprovalListVar, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0oWp0EE8_kKiS2AWZLX_Jg", callContext.id);
// Execute Action: JoinSelectedMyApprovalsList
controller._joinSelectedMyApprovalsList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oRZIMUMzy0y3eYSH41R88w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fUw1zScUFEuEQxV0cPLaKw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:IrFD2v2XGkWOqzF64dBjHg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.IrFD2v2XGkWOqzF64dBjHg:C1j5hbaWVQWMsBLUsL9crQ", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Grw0AIFesU+IKpSGwHg9EQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:R9LPOLt_Ek67bO72eM0Iqg", callContext.id);
controller.safeExecuteJSNode(PHICore_MainFlow_Dashboard_mvc_controller_OnReady_OnPressEnterCaseSearchJS, "OnPressEnterCaseSearch", "OnReady", null, function ($parameters) {
}, {
SearchOnClick: controller.clientActionProxies.searchOnClick$Action
}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:v3wgGifDmUipVu6xakOyhw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:IrFD2v2XGkWOqzF64dBjHg", callContext.id);
}

};
Controller.prototype._onChange_TeamCaseSelectAll$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_TeamCaseSelectAll");
callContext = controller.callContext(callContext);
var listIndexOfVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listIndexOfVar = listIndexOfVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:jJGJ49s4Zkq3XLvJhmC8ng:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.jJGJ49s4Zkq3XLvJhmC8ng:wPW676m9x2fexs9dKvNE2g", "PHICore", "OnChange_TeamCaseSelectAll", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OsYNwUjBbUiTRVoKpxr2QQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6KY4mG8yZ0OzDmUpWNYcwQ", callContext.id) && model.variables.teamCaseAllSelectedVar)) {
// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ACgmuAaAUEixRbg_tRhwkw", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:F_0MKdsdGEe5d6Al1UFOmg", callContext.id) && (((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).caseAttr.caseStatusIdAttr) !== (PHICoreModel.staticEntities.status.closed)) && ((model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).caseInfoAttr.approvalStatusIdAttr) !== (PHICoreModel.staticEntities.approvalStatus.pending))))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ZOX7zYHerEKHSFYuIroNNw", callContext.id);
// GetTeamsCasesByOwnerUserID.List.Current.IsSelected = True
model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DRPsDUBe6kG9vsX57T+Tmw", callContext.id);
// Execute Action: ListAppend2
OS.SystemActions.listAppend(model.variables.selectedTeamCaseListVar, OS.DataConversion.JSConversions.typeConvertRecord(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()), new PHICoreModel.CaseInfoIdentifierRecord(), function (source, target) {
target.caseInfoIdentifierAttr = source.caseAttr.idAttr;
return target;
}), callContext);
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

} else {
// Foreach GetTeamsCasesByOwnerUserID.List
callContext.iterationContext.registerIterationStart(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
try {var getTeamsCasesByOwnerUserIDIterator = callContext.iterationContext.getIterator(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
var getTeamsCasesByOwnerUserIDIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:xm6UKp+HR0Gi0HukON5KIQ", callContext.id) && (getTeamsCasesByOwnerUserIDIndex < model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.length))) {
getTeamsCasesByOwnerUserIDIterator.currentRowNumber = getTeamsCasesByOwnerUserIDIndex;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:8goeSovb2Ei3nSBC0Z4gvQ", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(model.variables.selectedTeamCaseListVar, function (p) {
return p.caseInfoIdentifierAttr.equals(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).caseAttr.idAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S2zg1JBenkuOatbesVPtKQ", callContext.id) && !((listIndexOfVar.value.positionOut === -1)))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GJuWkwKKWU6WReWmphlgHA", callContext.id);
// Execute Action: ListRemove
OS.SystemActions.listRemove(model.variables.selectedTeamCaseListVar, listIndexOfVar.value.positionOut, callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7jpI0SHsN0ydYsnieTg4vQ", callContext.id);
// GetTeamsCasesByOwnerUserID.List.Current.IsSelected = False
model.variables.getTeamsCasesByOwnerUserIDAggr.listOut.getItem(getTeamsCasesByOwnerUserIDIndex.valueOf()).isSelectedAttr = false;
}

getTeamsCasesByOwnerUserIDIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.getTeamsCasesByOwnerUserIDAggr.listOut);
}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zKSnqKmPfkaARyEJq+3rNA", callContext.id);
// Execute Action: JoinSelectedTeamCaseList
controller._joinSelectedTeamCaseList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:EmekeqO4MUicP2lYYaMr7A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:jJGJ49s4Zkq3XLvJhmC8ng", callContext.id);
}

};
Controller.prototype._searchOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SearchOnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:EWKw5pKXNk6BR8fMIk2DMw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.EWKw5pKXNk6BR8fMIk2DMw:drcxzUzhXNdUssRDdVDe4A", "PHICore", "SearchOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:OhmygsGPNkSw7wZSGr1PEg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HVjf7MWN1USyQLIsALbwvQ", callContext.id) && (model.variables.caseActiveTabVar === 0))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:LU6Embn1i0WdlXqgGamrtA", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyCasesCaseNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myCasesCaseNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:y_NIlqLQ7EquYf01+tf2HQ", callContext.id);
// Refresh Query: GetCasesByOwnerUserID
var result = controller.getCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.myCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IVpVKXvOJ0aaOt2aN_AL4w", callContext.id);
});
} else {
return OS.Flow.executeSequence(function () {
if((model.variables.caseActiveTabVar === 1)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:5fEkgz7tBEeGi2UuPkq64Q", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyTeamCasesNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myTeamCasesNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GXGuthvnM0icy1apWnxEaQ", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:u8CZv470a02OpUZQbTZTlA", callContext.id);
});
} else {
return OS.Flow.executeSequence(function () {
if((model.variables.caseActiveTabVar === 2)) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:QPJTDMondUato3H7HsfZOg", callContext.id);
// CaseNumberSearch = MyCasesSearch_Original.MyApprovalsCaseNumber
model.variables.caseNumberSearchVar = model.variables.myCasesSearch_OriginalVar.myApprovalsCaseNumberAttr;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:S_521hM+W0+77s+uIXNAmw", callContext.id);
// Refresh Query: GetApprovalsByOwnerUserId
var result = controller.getApprovalsByOwnerUserId$AggrRefresh(model.variables.maxRecordsVar, model.variables.approvalTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:T7y0R9Y3rUiEq2lcWqccsQ", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UvQTvZd0JUuIs4dd1xZn0A", callContext.id);
}

});
}

});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:EWKw5pKXNk6BR8fMIk2DMw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:EWKw5pKXNk6BR8fMIk2DMw", callContext.id);
throw ex;

});
};
Controller.prototype._onSortTeamCases$Action = function (sortByIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnSortTeamCases");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("PHICore.MainFlow.Dashboard.OnSortTeamCases$vars"))());
vars.value.sortByInLocal = sortByIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:+JYZ9q_+R0iFOG6USTHgsg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.+JYZ9q_+R0iFOG6USTHgsg:S9mmDB9ktP6hwsD9M7L6rg", "PHICore", "OnSortTeamCases", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hjZQflnJ+0mWjqOq9fOHfA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FsNa+SbBekGCEk7T+6yB_g", callContext.id) && ((PHICoreClientVariables.getMyTeamCasesListSort() === vars.value.sortByInLocal) && ((vars.value.sortByInLocal) !== (""))))) {
// TableSort2 += DESC
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Pmsov1DaJkKH1R3S_p__Tw", callContext.id);
// MyTeamCasesListSort = SortBy + " DESC"
PHICoreClientVariables.setMyTeamCasesListSort((vars.value.sortByInLocal + " DESC"));
} else {
// TableSort2 = SortBy
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Qj7FwGAqGEOFhCSgO3n1_w", callContext.id);
// MyTeamCasesListSort = SortBy
PHICoreClientVariables.setMyTeamCasesListSort(vars.value.sortByInLocal);
}

// StartIndex = 0
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:n6VgDi5SeUK0czf9F41Izg", callContext.id);
// TeamCasesTableVariables.StartIndex = 0
model.variables.teamCasesTableVariablesVar.startIndexAttr = 0;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6Qu3yF+eG02AoROhjw2a4g", callContext.id);
// Refresh Query: GetTeamsCasesByOwnerUserID
var result = controller.getTeamsCasesByOwnerUserID$AggrRefresh(model.variables.maxRecordsVar, model.variables.teamCasesTableVariablesVar.startIndexAttr, callContext);
model.flush();
return result.then(function () {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L9Qjzu3du0mIega53HZkIQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:+JYZ9q_+R0iFOG6USTHgsg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:+JYZ9q_+R0iFOG6USTHgsg", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("PHICore.MainFlow.Dashboard.OnSortTeamCases$vars", [{
name: "SortBy",
attrName: "sortByInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var check_SP_ViewCasesVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.check_SP_ViewCasesVar = check_SP_ViewCasesVar;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:d8uF993if0SWUgIayvdu4A:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.d8uF993if0SWUgIayvdu4A:Jyt4dT9IMvLizEbCeMlGvA", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Hg0iYKIHO0GVjcVm9aU4ig", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7zlFfZr8mUmVieQxdH8ObQ", callContext.id);
// Execute Action: Check_SP_ViewCases
check_SP_ViewCasesVar.value = Common_CWController.default.check_SP_ViewCases$Action(callContext);

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IeflgRAZe0CZ8C06nt926w", callContext.id);
// hasViewCaseRole = Check_SP_ViewCases.HasAccess
model.variables.hasViewCaseRoleVar = check_SP_ViewCasesVar.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:IeflgRAZe0CZ8C06nt926w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// CaseActiveTab = ActiveCaseTab
model.variables.caseActiveTabVar = model.variables.activeCaseTabIn;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:UORoaaGEEU+dtAhnSiHNTQ", callContext.id);
// Execute Action: Deserialize_Filters
controller._deserialize_Filters$Action(callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:coGwubssiU6A3K+MLDAh5Q", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:d8uF993if0SWUgIayvdu4A", callContext.id);
}

};
Controller.prototype._toggle_NewStakeholder$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Toggle_NewStakeholder");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Dn7U_u23r0iLj5sKp86lbA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ/ClientActions.Dn7U_u23r0iLj5sKp86lbA:ZG2NoDIhazQWQU2RJ6lEUg", "PHICore", "Toggle_NewStakeholder", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:7hH+r+diqkKo6XrU0RMXAQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pi3dDD5qR0aWtJEIWfQIWA", callContext.id);
// ShowPopup_NewStakeholder = notShowPopup_NewStakeholder
model.variables.showPopup_NewStakeholderVar = !(model.variables.showPopup_NewStakeholderVar);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DK0VCD_2U02eoS4HLrLS1A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Dn7U_u23r0iLj5sKp86lbA", callContext.id);
}

};

Controller.prototype.toggle_AssignCase$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_AssignCase$Action, callContext);

};
Controller.prototype.onChange_MyCaseSelect$Action = function (selectedCaseIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_MyCaseSelect$Action, callContext, selectedCaseIdIn);

};
Controller.prototype.onClick_ExportMyTeamCases$Action = function (isCSVIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_ExportMyTeamCases$Action, callContext, isCSVIn);

};
Controller.prototype.toggle_FilterLoading$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_FilterLoading$Action, callContext);

};
Controller.prototype.resetSelectedMyCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._resetSelectedMyCases$Action, callContext);

};
Controller.prototype.toggle_FilterApprovals$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_FilterApprovals$Action, callContext);

};
Controller.prototype.enableNotificationDetail$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._enableNotificationDetail$Action, callContext);

};
Controller.prototype.joinSelectedMyApprovalsList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._joinSelectedMyApprovalsList$Action, callContext);

};
Controller.prototype.input_MyCaseNumberOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._input_MyCaseNumberOnChange$Action, callContext);

};
Controller.prototype.clearSearchFilter$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._clearSearchFilter$Action, callContext);

};
Controller.prototype.tabsInitialized$Action = function (tabsIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tabsInitialized$Action, callContext, tabsIdIn);

};
Controller.prototype.toggle_RestrictedPopup$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_RestrictedPopup$Action, callContext);

};
Controller.prototype.assignCaseTeam_PopupEventAssignCase$Action = function (isProceedIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._assignCaseTeam_PopupEventAssignCase$Action, callContext, isProceedIn);

};
Controller.prototype.applyMyTeamCasesFilter$Action = function (searchFilterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._applyMyTeamCasesFilter$Action, callContext, searchFilterValueIn);

};
Controller.prototype.onClickNotification$Action = function (notificationIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickNotification$Action, callContext, notificationIn);

};
Controller.prototype.resetSelectedMyTeamCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._resetSelectedMyTeamCases$Action, callContext);

};
Controller.prototype.onPaginationNavigateMyTeamCases$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onPaginationNavigateMyTeamCases$Action, callContext, newStartIndexIn);

};
Controller.prototype.toggle_FilterMyTeamCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_FilterMyTeamCases$Action, callContext);

};
Controller.prototype.toggle_NewRateQuote$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_NewRateQuote$Action, callContext);

};
Controller.prototype.joinSelectedCaseList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._joinSelectedCaseList$Action, callContext);

};
Controller.prototype.onRefresh_FilterPopup$Action = function (searchFilterIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onRefresh_FilterPopup$Action, callContext, searchFilterIn);

};
Controller.prototype.onSortMyCases$Action = function (sortByIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onSortMyCases$Action, callContext, sortByIn);

};
Controller.prototype.tabsOnTabChange$Action = function (activeTabIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._tabsOnTabChange$Action, callContext, activeTabIn);

};
Controller.prototype.onClickAssignTeam$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickAssignTeam$Action, callContext);

};
Controller.prototype.onClick_NewPolicy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_NewPolicy$Action, callContext);

};
Controller.prototype.onPaginationNavigateApprovals$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onPaginationNavigateApprovals$Action, callContext, newStartIndexIn);

};
Controller.prototype.applyApprovalsFilter$Action = function (searchFilterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._applyApprovalsFilter$Action, callContext, searchFilterValueIn);

};
Controller.prototype.onChange_TeamCaseSelect$Action = function (selectedCaseIdIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_TeamCaseSelect$Action, callContext, selectedCaseIdIn);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.getTeamsOnAfterFetch$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getTeamsOnAfterFetch$Action, callContext);

};
Controller.prototype.onPaginationNavigateMyCases$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onPaginationNavigateMyCases$Action, callContext, newStartIndexIn);

};
Controller.prototype.joinSelectedTeamCaseList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._joinSelectedTeamCaseList$Action, callContext);

};
Controller.prototype.onClickFilter$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickFilter$Action, callContext);

};
Controller.prototype.onClickTabAssign_Disabled$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClickTabAssign_Disabled$Action, callContext);

};
Controller.prototype.deserialize_Filters$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._deserialize_Filters$Action, callContext);

};
Controller.prototype.toggle_FilterMyCases$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_FilterMyCases$Action, callContext);

};
Controller.prototype.refreshCurrentTable$Action = function (searchFilterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._refreshCurrentTable$Action, callContext, searchFilterValueIn);

};
Controller.prototype.onSortMyApprovals$Action = function (sortByIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onSortMyApprovals$Action, callContext, sortByIn);

};
Controller.prototype.onChange_MyCaseSelectAll$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_MyCaseSelectAll$Action, callContext);

};
Controller.prototype.applyMyCasesFilter$Action = function (searchFilterValueIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._applyMyCasesFilter$Action, callContext, searchFilterValueIn);

};
Controller.prototype.resetSelectedMyApprovals$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._resetSelectedMyApprovals$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onChange_TeamCaseSelectAll$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_TeamCaseSelectAll$Action, callContext);

};
Controller.prototype.searchOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._searchOnClick$Action, callContext);

};
Controller.prototype.onSortTeamCases$Action = function (sortByIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onSortTeamCases$Action, callContext, sortByIn);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.toggle_NewStakeholder$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._toggle_NewStakeholder$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:O86_aszw1VPyw_odCm0n0g", "PHICore", "MainFlow", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:2OJuW3+kr0SOlDpi0epkKQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.2OJuW3+kr0SOlDpi0epkKQ:tnJkrK33_vNTOBTMMeo6Gw", "PHICore", "Dashboard", "NRNodes.WebScreen", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:2OJuW3+kr0SOlDpi0epkKQ", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MainFlow/Dashboard On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return PHICore_MainFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
OS.RolesInfo.checkRoles([PHICoreController.default.roles.SystemAdministrator, PHICoreController.default.roles.SP_1_StaffPortal, PHICoreController.default.roles.SP_4_ViewDashboards]);
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});
define("PHICore.MainFlow.Dashboard.mvc$controller.TabsInitialized.JavaScript1JS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var a = document.getElementById($parameters.TabsWidgetId);
if (a) {
    var b = a.querySelectorAll('button.osui-tabs__header-item:not(.hidden)');
    b.forEach(function(element, index) {
        element.setAttribute('tabindex', 0);
    });
}
};
});
define("PHICore.MainFlow.Dashboard.mvc$controller.OnRefresh_FilterPopup.SetTimoutJSJS", [], function () {
return function ($actions, $roles, $public) {
setTimeout(function(){$actions.Toggle_FilterLoading()},10);
};
});
define("PHICore.MainFlow.Dashboard.mvc$controller.OnReady.OnPressEnterCaseSearchJS", [], function () {
return function ($actions, $roles, $public) {
var caseNumberInput = document.getElementById('Input_MyCaseNumber');
if(caseNumberInput) {
    caseNumberInput.addEventListener('keydown', function(event) {
        if (event.keyCode === 13) {
            event.preventDefault();
            $actions.SearchOnClick();
        }
    });
}
};
});

define("PHICore.MainFlow.Dashboard.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"ZEUh4XciOka6IUUjp88t+w": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedCaseIdInLocal;
},
dataType: OS.Types.LongInteger
},
"DT6jGES66kOsL52ojD948Q": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
},
"AleDYRoP_EaE2kXX0BbX3w": {
getter: function (varBag, idService) {
return varBag.listFilter_SelectedVar.value;
}
},
"m5YTvXhEWUCbpncIFXQIHA": {
getter: function (varBag, idService) {
return varBag.listFilter_ClosedVar.value;
}
},
"fx8vt6HUmEmFQE8MFFi8PA": {
getter: function (varBag, idService) {
return varBag.vars.value.isCSVInLocal;
},
dataType: OS.Types.Boolean
},
"7LkneGfkjEmw_tq74sfMxA": {
getter: function (varBag, idService) {
return varBag.allExceptionsVar.value;
}
},
"uT6NhfWahEOObCo54421gw": {
getter: function (varBag, idService) {
return varBag.exportMyTeamCasesVar.value;
}
},
"xtIO8j5V7Uel0UsQqMipEA": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"LP+Y9blwO0GaKuDmvbdDmg": {
getter: function (varBag, idService) {
return varBag.vars.value.tabsIdInLocal;
},
dataType: OS.Types.Text
},
"pNjvzEbbQUOBTdMlge1ksg": {
getter: function (varBag, idService) {
return varBag.javaScript1JSResult.value;
}
},
"CaPjVsAkLkOpN+MEHhzSNg": {
getter: function (varBag, idService) {
return varBag.vars.value.isProceedInLocal;
},
dataType: OS.Types.Boolean
},
"DQiD+2Dc+0KwENr5MsneCw": {
getter: function (varBag, idService) {
return varBag.vars.value.searchFilterValueInLocal;
}
},
"pO1xvwsJs0a8joBuNoCG9g": {
getter: function (varBag, idService) {
return varBag.vars.value.notificationInLocal;
}
},
"gWB0G45H9UOn6U6jr1r9LQ": {
getter: function (varBag, idService) {
return varBag.readNotificationVar.value;
}
},
"ZJFbq_U3Akml+3avIeYbwA": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"SwhAQLyi0UeydPhI4wrXQQ": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"y_ha261gwEuCPoWn88Uc_Q": {
getter: function (varBag, idService) {
return varBag.vars.value.searchFilterInLocal;
}
},
"FKg+tXeUw0imN1ujF3g_NA": {
getter: function (varBag, idService) {
return varBag.setTimoutJSJSResult.value;
}
},
"bkQ8QqYlEUGtjkhUFBs7DQ": {
getter: function (varBag, idService) {
return varBag.vars.value.sortByInLocal;
},
dataType: OS.Types.Text
},
"ksn9rxiUm0OpkybEEVpQ7A": {
getter: function (varBag, idService) {
return varBag.vars.value.activeTabInLocal;
},
dataType: OS.Types.Integer
},
"wPV1rVekkk6SgBGNt3q6Ew": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"KLn_W0Gr50G+eG0VLSnFtw": {
getter: function (varBag, idService) {
return varBag.vars.value.searchFilterValueInLocal;
}
},
"7p6p3Fi7wEWhzPAKfl2L8w": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedCaseIdInLocal;
},
dataType: OS.Types.LongInteger
},
"MXhfLEMjzE6igqBpdd7hBg": {
getter: function (varBag, idService) {
return varBag.listFilter_SelectedVar.value;
}
},
"3rUlPkjVR0GKF0W5ySHS2w": {
getter: function (varBag, idService) {
return varBag.listFilter_ClosedVar.value;
}
},
"vKKIYCm6sUaCY1OWjFTMAg": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
},
"IDfUivSoJ0S9jvElPw8evA": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"9obwH_q_VEqVDrw0P2mrDw": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"J54aVqfE+k+h5bhrO5gSxw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeMyApproval_SearchFilterVar.value;
}
},
"qZlWkzNltkeB_OX57dy_pw": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeMyTeamCases_SearchFIlterVar.value;
}
},
"DfncwRSb0kW3E+eEytIdCQ": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeMyCases_SearchFilterVar.value;
}
},
"cGc54YV2aUKfqDgd83tc1A": {
getter: function (varBag, idService) {
return varBag.vars.value.categoryVar;
}
},
"G8Dv+5TC1EW+RwkLhWCzhg": {
getter: function (varBag, idService) {
return varBag.vars.value.subCategoryVar;
}
},
"pNFedMzOPU6Yld4CTyG9Jg": {
getter: function (varBag, idService) {
return varBag.vars.value.sLAsVar;
}
},
"POzGrcOwNEWYMx2fj+s7nw": {
getter: function (varBag, idService) {
return varBag.vars.value.priorityVar;
}
},
"C5O3SAT5QE2KuY0lY4oH0A": {
getter: function (varBag, idService) {
return varBag.vars.value.statusVar;
}
},
"ZVCYjp9wgU+njsF+5yYN2w": {
getter: function (varBag, idService) {
return varBag.vars.value.teamsVar;
}
},
"7pJz7aeP3UOmKQp05MIGLw": {
getter: function (varBag, idService) {
return varBag.vars.value.assignedToVar;
}
},
"ZZ9slkdAYUKBcgX5_G0_ig": {
getter: function (varBag, idService) {
return varBag.vars.value.raisedByVar;
}
},
"E6Pl5GB2lEGxfeMVGQ7MKQ": {
getter: function (varBag, idService) {
return varBag.vars.value.dashboard_CasesFilterVar;
}
},
"TjgxWpkXvUSxcNUYgcgF_Q": {
getter: function (varBag, idService) {
return varBag.vars.value.searchFilterValueInLocal;
}
},
"GA3hFstEikm4YNgpjT7WEA": {
getter: function (varBag, idService) {
return varBag.dashboardStringJoin_FiltersVar.value;
}
},
"BlmbNZ7no0G1mzJPbj_nEA": {
getter: function (varBag, idService) {
return varBag.jSONSerializeSearch_MyTeamVar.value;
}
},
"L_K5YHgX3ke_h3xyOpmOuw": {
getter: function (varBag, idService) {
return varBag.jSONSerializeSearch_MyCasesVar.value;
}
},
"ZjjUzP9i7Eq3GGGTJhOi0w": {
getter: function (varBag, idService) {
return varBag.jSONSerializeSearch_MyApprovalVar.value;
}
},
"99SiHiclSkOoBxfMjB4LPg": {
getter: function (varBag, idService) {
return varBag.vars.value.sortByInLocal;
},
dataType: OS.Types.Text
},
"uNBGYCE+rE+ESHAugue51A": {
getter: function (varBag, idService) {
return varBag.listIndexOf2Var.value;
}
},
"WpipjV7TFkmovf1ALNtNAA": {
getter: function (varBag, idService) {
return varBag.vars.value.searchFilterValueInLocal;
}
},
"R9LPOLt_Ek67bO72eM0Iqg": {
getter: function (varBag, idService) {
return varBag.onPressEnterCaseSearchJSResult.value;
}
},
"8goeSovb2Ei3nSBC0Z4gvQ": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
},
"_MfJkg+oMk27PinEBnEycw": {
getter: function (varBag, idService) {
return varBag.vars.value.sortByInLocal;
},
dataType: OS.Types.Text
},
"7zlFfZr8mUmVieQxdH8ObQ": {
getter: function (varBag, idService) {
return varBag.check_SP_ViewCasesVar.value;
}
},
"4aGNrI0Gw0KCJCKZA93AOA": {
getter: function (varBag, idService) {
return varBag.model.variables.maxRecordsVar;
},
dataType: OS.Types.Integer
},
"eAfBea0tH0eFifHnjdwrdw": {
getter: function (varBag, idService) {
return varBag.model.variables.showMyCasesFilterVar;
},
dataType: OS.Types.Boolean
},
"zDokkHnM4U+Wk60iIdHfig": {
getter: function (varBag, idService) {
return varBag.model.variables.showMyTeamCasesFilterVar;
},
dataType: OS.Types.Boolean
},
"2ls_GuxJS0yBUX_jCGAqxw": {
getter: function (varBag, idService) {
return varBag.model.variables.showApprovalsFilterVar;
},
dataType: OS.Types.Boolean
},
"rn3zvltKPEySikp2LvEYiQ": {
getter: function (varBag, idService) {
return varBag.model.variables.myApprovalsSelectAllVar;
},
dataType: OS.Types.Boolean
},
"AQaEfz+Jx0K2rFt97N7l3g": {
getter: function (varBag, idService) {
return varBag.model.variables.searchFilter_MyCasesVar;
}
},
"dLIW4t9S+EetZRGPtw8Vdw": {
getter: function (varBag, idService) {
return varBag.model.variables.searchFilter_ApprovalsVar;
}
},
"7rF_NVZwPkyUrHdDP_M2Gw": {
getter: function (varBag, idService) {
return varBag.model.variables.searchFilter_MyTeamCasesVar;
}
},
"IoPgwt_480C_v7ldA_esbQ": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedStrings_MyCasesVar;
}
},
"cg_i3ar4R0iq1CAHT4Pt+Q": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedStrings_MyTeamCasesVar;
}
},
"LzvA15O_qkK525aKLdS4EQ": {
getter: function (varBag, idService) {
return varBag.model.variables.joinedStrings_ApprovalsVar;
}
},
"p59raPLJOUeGfQzuc0RRfg": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopup_RestrictedVar;
},
dataType: OS.Types.Boolean
},
"b2aQSgE9gEa83MNgbfYZuA": {
getter: function (varBag, idService) {
return varBag.model.variables.showPopup_NewStakeholderVar;
},
dataType: OS.Types.Boolean
},
"LVNmO1gLeU+vIX8GmjflYA": {
getter: function (varBag, idService) {
return varBag.model.variables.caseActiveTabVar;
},
dataType: OS.Types.Integer
},
"EBBb6oycAkCzFvRKk9+b7w": {
getter: function (varBag, idService) {
return varBag.model.variables.showAssignTeamVar;
},
dataType: OS.Types.Boolean
},
"tkIHbnahHEC+qGFd_KuARg": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedMyCaseListVar;
}
},
"TZYXkpVQxEmI3FOorYxlTw": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedMyCaseTextVar;
},
dataType: OS.Types.Text
},
"geDqxYJciUW4XrcHZ2zlmQ": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedTeamCaseListVar;
}
},
"QdzOnSP4JEG8hGuFdLj7zg": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedTeamCaseTextVar;
},
dataType: OS.Types.Text
},
"pAKrb6wlO0yYxB0NfrUDmw": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedMyApprovalListVar;
}
},
"ViYZYEMtj0aQ0leCsEp05g": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedMyApprovalTextVar;
},
dataType: OS.Types.Text
},
"UsKLgVqcdUyWk_ti7Pnq_A": {
getter: function (varBag, idService) {
return varBag.model.variables.teamCaseAllSelectedVar;
},
dataType: OS.Types.Boolean
},
"FB+e+wvWAkmOqbGMbm4Kng": {
getter: function (varBag, idService) {
return varBag.model.variables.sharedSelectedCasesVar;
}
},
"HHGoJuj3rkGLgQ31mFIsoA": {
getter: function (varBag, idService) {
return varBag.model.variables.approvalTableVariablesVar;
}
},
"zD_wM9a4F0q+k6LLXeDYHw": {
getter: function (varBag, idService) {
return varBag.model.variables.myCasesTableVariablesVar;
}
},
"hAF71AQ+pkKrFFEXCaBDYw": {
getter: function (varBag, idService) {
return varBag.model.variables.teamCasesTableVariablesVar;
}
},
"pUZ98V0es0St2f1Q0AXltw": {
getter: function (varBag, idService) {
return varBag.model.variables.hasViewCaseRoleVar;
},
dataType: OS.Types.Boolean
},
"mka+PvLF_Ein+D8cRqp+HQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showNotificationDetailVar;
},
dataType: OS.Types.Boolean
},
"smqE9MRmm0OzzX3VyWrs_Q": {
getter: function (varBag, idService) {
return varBag.model.variables.refreshNotificationBellVar;
},
dataType: OS.Types.Boolean
},
"IDi_AWZiEkSCD8znGGdVZw": {
getter: function (varBag, idService) {
return varBag.model.variables.myCasesSearch_OriginalVar;
}
},
"L0xCRAAm4EqiXttzRhQSDw": {
getter: function (varBag, idService) {
return varBag.model.variables.caseNumberSearchVar;
},
dataType: OS.Types.Text
},
"tEEYFUWKX0GhIbB2s40iTQ": {
getter: function (varBag, idService) {
return varBag.model.variables.notificationDescriptionVar;
},
dataType: OS.Types.Text
},
"Mfhies9Ie0mfgFFchFC0sQ": {
getter: function (varBag, idService) {
return varBag.model.variables.emptyFilterVar;
}
},
"i86_TwA8MEeB0QMsBaZ3Zw": {
getter: function (varBag, idService) {
return varBag.model.variables.isLoadingFilterVar;
},
dataType: OS.Types.Boolean
},
"qjKePZEVdka1bHPlQX_F_w": {
getter: function (varBag, idService) {
return varBag.model.variables.isLoadingExportMyTeamCasesVar;
},
dataType: OS.Types.Boolean
},
"2f6wl3DeP0GktbRbzqs+UQ": {
getter: function (varBag, idService) {
return varBag.model.variables.activeCaseTabIn;
},
dataType: OS.Types.Integer
},
"rts6Szm2gEC7jcbCdRxvOw": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamsDataAct;
}
},
"3pXHBiJdCkmdOF0iaE7DJQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamsCasesByOwnerUserID_NoFilterAggr;
}
},
"jNHrSFSJLk6D+QQRuTD5Bg": {
getter: function (varBag, idService) {
return varBag.model.variables.getTeamsCasesByOwnerUserIDAggr;
}
},
"uy6hZf6UF0OGW9znArYbWg": {
getter: function (varBag, idService) {
return varBag.model.variables.getCasesByOwnerUserIDAggr;
}
},
"EX5Dc6ajJk2I1z_a9PtGCw": {
getter: function (varBag, idService) {
return varBag.model.variables.getUserByIdAggr;
}
},
"RqY4jnKar0i8SevqOUwhQA": {
getter: function (varBag, idService) {
return varBag.model.variables.getApprovalsByOwnerUserId_NoFilterAggr;
}
},
"i6TTn3JPcEWAVrL5i90cpQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getCasesByOwnerUserID_NoFilterAggr;
}
},
"8XkeySM3yE6UYHqON+6FBw": {
getter: function (varBag, idService) {
return varBag.model.variables.getNotificationsWithReadReceiptsAggr;
}
},
"LuQ30jij6UKmfgbKcmFlIQ": {
getter: function (varBag, idService) {
return varBag.model.variables.getApprovalsByOwnerUserIdAggr;
}
},
"zxq8YjtC+k6znn6KjYkUMg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderTitle"));
})(varBag.model, idService);
}
},
"K90rxinBNkiAPp41Vl22jw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("UnderHeaderAction"));
})(varBag.model, idService);
}
},
"w+0Xu9pj4U6aOBmdz2B2lg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Breadcrumbs"));
})(varBag.model, idService);
}
},
"RqoKfoveaUm95HKIbHYOBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"Km71QRUK4EWmObIyo+WnEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Actions"));
})(varBag.model, idService);
}
},
"0c+b+QM7QUeIMBt+OJrwtg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MainContent"));
})(varBag.model, idService);
}
},
"OryR8s9v_kmqO0a+zJx_Gw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"EVsfNiIfTUaboxV15C2+tw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"T2jsSqYx0USvjMC5xieRfA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasPermissions_CreateModifyQuote"));
})(varBag.model, idService);
}
},
"89gslOXb+UqT0NvxpYVZdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"3G7fjLCP2Ee32uhoJ6Tu1Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"M7vyPEU6FEOabYv6rWrdHA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BL1QFgXuLUegdk2DdBH6kw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"yEcNg072R0i5eYHNsCdAqw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"ceEKqWYABEqpMiUQrW7zYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"CZUpj4xwwEiZ6zBrvn4wYg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"aPGED6hHDEecesdbmYOhew": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasPermissions_CreatePolicyAndMember"));
})(varBag.model, idService);
}
},
"Bfj6P8bJT0aLv7s7DFQ2yg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DashboardCard_NewPolicy"));
})(varBag.model, idService);
}
},
"kkjGzpb1bESBEVLYzGd4qg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"0iJmvSbjHECyHofGQvzLJg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"clIOSToO8EOAayQeDxfSlQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"YkwHyIZhp0SAlGuA23kM+A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DashboardCard_NewPolicy_Disabled"));
})(varBag.model, idService);
}
},
"wGI4amabIUGLAunDG7YKpQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"JMQczMZKQEaWBmEOdPsZUw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"jsvzHTMeqUGR1HK2tOpgmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"CZAImS46SUOJVczf+itMQA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column3"));
})(varBag.model, idService);
}
},
"0F+bZcsfIEOxQNyIBwyKbA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasPermission_AddModifyReopenCancelLead"));
})(varBag.model, idService);
}
},
"T2Q2f7mLz0ubWino5xlgoA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DashboardCard_NewStakeholder"));
})(varBag.model, idService);
}
},
"N38XexTwjUqrFJ7x_GSAzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"PulhqHtvqECsrvn+NaokZQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"Pe2LsTxOG0qjCaNYb8LsvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"FHQo99vepUqVwpf51SeuQA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DashboardCard_NewStakeholder_Disabled"));
})(varBag.model, idService);
}
},
"FSlMVcdcVEmm68Eafq97Wg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("icon"));
})(varBag.model, idService);
}
},
"JZSeihKxsk6_NdKCfQejCA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Text"));
})(varBag.model, idService);
}
},
"L6zfVQUnUE6ORYrFk4_+5w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"1bhB5D6ud0qDbO5tFQkjBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"1loClH5t30Sq2QpT3qvOpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Header"));
})(varBag.model, idService);
}
},
"H7heE308v0+t+txuorPoug": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"9Ba64JGXU0id4o6jSBxFuQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"DUc7SP9010GXrUtdt7sgZw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalTabHeader"));
})(varBag.model, idService);
}
},
"0vbLpDLcH0+giVQIMJ1OAg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"Cb0xRyr5C0ygcGjsRBqraw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalsCountBadge"));
})(varBag.model, idService);
}
},
"V3R+l_h4DEaKXyBvfFTyrw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("CheckPermisisons"));
})(varBag.model, idService);
}
},
"STyXZo4P_022W6FgQvMcpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"au0VMRBuXkKl8kqZamhFXw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"jwyNwhFVlEmBBmPRpLX3Og": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Check_SP_ViewCases2"));
})(varBag.model, idService);
}
},
"Pnnv_e0ueUOEZJVcmovwyA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"kSsHryi1ZUOJaLPbwVmctA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_MyCaseNumber"));
})(varBag.model, idService);
}
},
"+WHtQ3NL80CBwtvuVE+urA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SearchCasesButton"));
})(varBag.model, idService);
}
},
"e1K7DfMTzEqfMK4hwkbXvQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"wvkvRtL630CdSqVDW10IJA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ZZsjE81FUUCd3l+vBr+cIQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_MyCaseNumber2"));
})(varBag.model, idService);
}
},
"YffA7+wHOE2SEAmEvrmMmw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SearchCasesButton2"));
})(varBag.model, idService);
}
},
"TLgW58I1FkiJ+hAekk4z3Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"TwKDAWB5zU6IrXofehLzYg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+64S_VeScEGWDPCKasPgIA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"0_Rm68H98U6O_J5TI_NryQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TabIs0"));
})(varBag.model, idService);
}
},
"FBoUSnpPmU2AFinU+YatwA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Permission"));
})(varBag.model, idService);
}
},
"zxhzjAUzwU2mcPxKZNXq3Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCaseSelectAll"));
})(varBag.model, idService);
}
},
"M7D4DilaZ0a1KoOQrw+t9Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"+egUHhICCk+dTpvon9fGYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCaseSelectAll2"));
})(varBag.model, idService);
}
},
"MD7fD1OKBESXSpVkSnB+zg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"kHe3gU8G7kyfQqKoNBjavQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasPermission"));
})(varBag.model, idService);
}
},
"VOMPP+4BsE+74uyYXhjJ8w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCaseSelect"));
})(varBag.model, idService);
}
},
"mRBeWHPJ3UGc_34geHZwSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"z7ULq82ti0OCSHR1_pdqpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCaseSelect2"));
})(varBag.model, idService);
}
},
"mvxstizk9UWPMZ8yjT2FJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"40Fkf2kqZUKt7m+vLvndMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCases_CaseNumber"));
})(varBag.model, idService);
}
},
"rJqteTt130Cvh2huX_EtLQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsTableLoadingOrEmpty"));
})(varBag.model, idService);
}
},
"8Z6i7vnZeE2GrnNGj2o_yA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsEmpty"));
})(varBag.model, idService);
}
},
"N1_r4FsZrU2Mn2pUbphuEQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoCasesAssigned"));
})(varBag.model, idService);
}
},
"wBhNKmC6n0GZaIpB28MTxw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoCases"));
})(varBag.model, idService);
}
},
"m0s7SFnL9kSD0Aa4BsRm2w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"vqomdgPvTEGZ5FRfRCjBgw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"dPpHSx1BkkOQW9f57xfhUg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"Am47nlsXsEuDF_Bdag6D1w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoResults"));
})(varBag.model, idService);
}
},
"Hmd9fJR2GUyHaJvWOa98CQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"PQp5UCk3aEqsj9h2pBlxqQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"QUu4Hp7en0G1ktGjVnCpSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"zSiGiIXBIkW6BBqnBGSCBg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsLoading"));
})(varBag.model, idService);
}
},
"dxBvo6ZjW0CyNlF3W2IAhg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"EVmVRm2Wb0epfL9fjia8rQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
},
"2yZc1aw4okS0G3ywoKQNYw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"rzGZsUJK+USQbEk5rbKcVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TabIs1"));
})(varBag.model, idService);
}
},
"zQ0zIadSG0icNCUWGuCiXQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Permission2"));
})(varBag.model, idService);
}
},
"vWDpcWDtn0u6FWtcCSQQxA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamCaseSelectAll"));
})(varBag.model, idService);
}
},
"d3GwHvJ4k0an1eCUZtN5Kg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"PauJHsb11k2rZjaH0oBixA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamCaseSelectAll2"));
})(varBag.model, idService);
}
},
"BqDgsO5WHkaPTFjYdgsfGw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"hfJyTbpNdE6Tst_IgGHD5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Permission3"));
})(varBag.model, idService);
}
},
"Pq9FYLQ2TECxRGMZVUisNQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamCaseSelect"));
})(varBag.model, idService);
}
},
"5u7fSfrroUa8UAHpjoGq2Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BsE_JX6eT02czyi45nt8fQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamCaseSelect2"));
})(varBag.model, idService);
}
},
"trdzFmXH80y6eeS+BroiCA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"yWhb9UNid0CH4CT5CCC5lw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TeamCasesCaseNumber"));
})(varBag.model, idService);
}
},
"7uINl698EkWYZLJbIxpPmQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsTableLoadingOrEmpty2"));
})(varBag.model, idService);
}
},
"TUauw5AccEamrYOtx7ZUfA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsEmptyMyTeamCases"));
})(varBag.model, idService);
}
},
"iLG_1XHREES9O6w0WD+IWg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoTeamCasesAssigned"));
})(varBag.model, idService);
}
},
"jbzAmSDTDUOavT0JyJlsHw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoTeamCases"));
})(varBag.model, idService);
}
},
"_2y3RvOH9UqtCLYP+PvGyA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"4A5r1KRjGUGexppSxfyBzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"FUaYPoFrE0iIgadqyKAmzQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"CcaqFOco5E2cC4Rn7+RycA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoTeamResults"));
})(varBag.model, idService);
}
},
"o6T7SSVPUk2DCDKsrji2VQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"dJJcbl6ZtkmKKjwug1l7ww": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"XAF_dIp9Z0Skzci+xGynbQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"i2pkBHLmdUq152ZuLEmuOg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsLoading2"));
})(varBag.model, idService);
}
},
"YiZqU_15r0CvyPsGWxEKzA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"xucTACtwRkKvBbNNNG9qKA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
},
"6Xcude3iCUCD4e9Vx7Xi5g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalTab"));
})(varBag.model, idService);
}
},
"QtE7sF6CDUG6IrqxX47iFg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"VsXPLfP2bEeOCWXWjutAWA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TabIs2"));
})(varBag.model, idService);
}
},
"GaQZo+O8oEmH_9_RWNFoyg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalsCaseNumber"));
})(varBag.model, idService);
}
},
"gx1o_iYPmEq855Dr7V_dzg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsApprovalsLoadingOrEmpty"));
})(varBag.model, idService);
}
},
"IOlp0dA5UE+Snf1jRD1r3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsApprovalsEmpty"));
})(varBag.model, idService);
}
},
"RuvSMV2BQE23D5xdXPveJA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoPendingApprovals"));
})(varBag.model, idService);
}
},
"tRAUYfENfkuW8O1K8PLxtA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NoApprovalsAssigned"));
})(varBag.model, idService);
}
},
"o1IBh5yhtECiAy4uY5rJNA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"x1pb7Wvn+ECeT7HZ60fqxQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"coOc7ov+Akygdn0FkzEKbA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"I6ykp0fCYUamrj5hvNDS3w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalNoResults"));
})(varBag.model, idService);
}
},
"A4Q_uqH8rEGQ5EYz4Q0B6g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"xMBJMXNIz0K0DnC3czZ0qQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"jc23S_xQuE2kDv7ukzDmtQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
},
"PzhjejDdxEmeBMwUQfcPhg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsLoading3"));
})(varBag.model, idService);
}
},
"vrSwQPjZk0Gl4n95GO8L7Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"mrIAG3A0xkKqHo6YYgO8vA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
},
"vCSKEUKwYEG5UsnrcwOC2Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"mm24hGdp8kyGqozlLlssMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"6XAs2us4JUmgYLaHTBJnGA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"zixpOhe2XkmEQeGT2oHRiQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"1L779UXpikCRp9ZbeDuu8g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"WofxT54guUGvsfoRba5j4g": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"ZVxoXvXyK0qlqMjgGDMH+w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Tooltip"));
})(varBag.model, idService);
}
},
"uH2w4xp+qUy03Rrqwtf7nQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"VBNSSYBgdkOd2bHa5FCTzw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"xzs8fBpNVkycWj8mLdTvwQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IftNotificationsWithReadReceipts_List_Empty"));
})(varBag.model, idService);
}
},
"olJ2hQh7OEqp8DZiueSVJw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"BpXC8zEaWkO7IM8_uQaVyQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ListItem1"));
})(varBag.model, idService);
}
},
"nz2Slv+k5E+J3lb++DqUSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"a4FU3pLN7EemuawtB3QFtw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"X3xkcQN2V0O4PW2ysZ8csg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"MddOd+DeOUGy7aVNuCSiEA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column1"));
})(varBag.model, idService);
}
},
"01YGKHtPLE+beUX09OtRQg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Column2"));
})(varBag.model, idService);
}
},
"WFajFugpZEi0om4TuEypjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NotificationLink"));
})(varBag.model, idService);
}
},
"o33LrVZk2UixRNRMmMIgsA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyCasesPopup"));
})(varBag.model, idService);
}
},
"sT_FLZUqYEegEOD7WRVvrg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsloadingFilter_MyCases"));
})(varBag.model, idService);
}
},
"6R97EBiR7E2xp5TFQ+DDKQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("MyTeamsPopUp"));
})(varBag.model, idService);
}
},
"uBDAgkMltU6wc6DjmLWA+w": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsloadingFilter_MyTeam"));
})(varBag.model, idService);
}
},
"Wa7_v1+fR0O_p8XWXorPEg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ApprovalsFilterPopUp"));
})(varBag.model, idService);
}
},
"yRBwTV2LS0ew5BPrtM9BVw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsloadingFilter_Approvals"));
})(varBag.model, idService);
}
},
"EI8SFH461Em2kKD+OOhWnA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
