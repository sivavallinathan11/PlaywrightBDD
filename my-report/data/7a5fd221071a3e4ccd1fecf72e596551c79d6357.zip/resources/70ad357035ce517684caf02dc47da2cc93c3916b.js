﻿define("MSD.MSD.MSD.mvc$model", ["OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.controller$ManageEllipsis", "MSD.model$MSD_ItemList", "MSD.controller$ChangeSelectAll", "MSD.controller$CheckIfAllSelected", "MSD.controller$SelectItemsInList", "MSD.model$MSD_ItemRec", "MSD.controller$HandleSelectedList"], function (OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("ShowList", "showListVar", "ShowList", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SearchValue", "searchValueVar", "SearchValue", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("SelectAll", "selectAllVar", "SelectAll", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("LocalItemList", "localItemListVar", "LocalItemList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemList());
}, false, MSDModel.MSD_ItemList), 
this.attr("SelectedItems", "selectedItemsVar", "SelectedItems", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, false, OS.DataTypes.TextList), 
this.attr("AuxItemList", "auxItemListVar", "AuxItemList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemList());
}, false, MSDModel.MSD_ItemList), 
this.attr("UseItemList", "useItemListVar", "UseItemList", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("HideTitle", "hideTitleVar", "HideTitle", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SelectedListToCSV", "selectedListToCSVVar", "SelectedListToCSV", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("ItemList", "itemListIn", "ItemList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemList());
}, false, MSDModel.MSD_ItemList), 
this.attr("_itemListInDataFetchStatus", "_itemListInDataFetchStatus", "_itemListInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("DisplayList", "displayListIn", "DisplayList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new MSDModel.MSD_ItemList());
}, false, MSDModel.MSD_ItemList), 
this.attr("_displayListInDataFetchStatus", "_displayListInDataFetchStatus", "_displayListInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SelectAllEnabled", "selectAllEnabledIn", "SelectAllEnabled", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_selectAllEnabledInDataFetchStatus", "_selectAllEnabledInDataFetchStatus", "_selectAllEnabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("SearchEnabled", "searchEnabledIn", "SearchEnabled", true, false, OS.Types.Boolean, function () {
return true;
}, false), 
this.attr("_searchEnabledInDataFetchStatus", "_searchEnabledInDataFetchStatus", "_searchEnabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("RefreshOnClose", "refreshOnCloseIn", "RefreshOnClose", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_refreshOnCloseInDataFetchStatus", "_refreshOnCloseInDataFetchStatus", "_refreshOnCloseInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("EmptySearchText", "emptySearchTextIn", "EmptySearchText", true, false, OS.Types.Text, function () {
return "No Items found.";
}, false), 
this.attr("_emptySearchTextInDataFetchStatus", "_emptySearchTextInDataFetchStatus", "_emptySearchTextInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("MaxCharBeforeEllipsis", "maxCharBeforeEllipsisIn", "MaxCharBeforeEllipsis", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_maxCharBeforeEllipsisInDataFetchStatus", "_maxCharBeforeEllipsisInDataFetchStatus", "_maxCharBeforeEllipsisInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("AriaLabel", "ariaLabelIn", "AriaLabel", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_ariaLabelInDataFetchStatus", "_ariaLabelInDataFetchStatus", "_ariaLabelInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsDisabled", "isDisabledIn", "IsDisabled", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isDisabledInDataFetchStatus", "_isDisabledInDataFetchStatus", "_isDisabledInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
SearchInput: OS.Model.ValidationWidgetRecord,
SelectAllCheckbox: OS.Model.ValidationWidgetRecord,
ListItemCheckbox: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("ItemList" in inputs) {
this.variables.itemListIn = inputs.ItemList;
if("_itemListInDataFetchStatus" in inputs) {
this.variables._itemListInDataFetchStatus = inputs._itemListInDataFetchStatus;
}

}

if("DisplayList" in inputs) {
this.variables.displayListIn = inputs.DisplayList;
if("_displayListInDataFetchStatus" in inputs) {
this.variables._displayListInDataFetchStatus = inputs._displayListInDataFetchStatus;
}

}

if("SelectAllEnabled" in inputs) {
this.variables.selectAllEnabledIn = inputs.SelectAllEnabled;
if("_selectAllEnabledInDataFetchStatus" in inputs) {
this.variables._selectAllEnabledInDataFetchStatus = inputs._selectAllEnabledInDataFetchStatus;
}

}

if("SearchEnabled" in inputs) {
this.variables.searchEnabledIn = inputs.SearchEnabled;
if("_searchEnabledInDataFetchStatus" in inputs) {
this.variables._searchEnabledInDataFetchStatus = inputs._searchEnabledInDataFetchStatus;
}

}

if("RefreshOnClose" in inputs) {
this.variables.refreshOnCloseIn = inputs.RefreshOnClose;
if("_refreshOnCloseInDataFetchStatus" in inputs) {
this.variables._refreshOnCloseInDataFetchStatus = inputs._refreshOnCloseInDataFetchStatus;
}

}

if("EmptySearchText" in inputs) {
this.variables.emptySearchTextIn = inputs.EmptySearchText;
if("_emptySearchTextInDataFetchStatus" in inputs) {
this.variables._emptySearchTextInDataFetchStatus = inputs._emptySearchTextInDataFetchStatus;
}

}

if("MaxCharBeforeEllipsis" in inputs) {
this.variables.maxCharBeforeEllipsisIn = inputs.MaxCharBeforeEllipsis;
if("_maxCharBeforeEllipsisInDataFetchStatus" in inputs) {
this.variables._maxCharBeforeEllipsisInDataFetchStatus = inputs._maxCharBeforeEllipsisInDataFetchStatus;
}

}

if("AriaLabel" in inputs) {
this.variables.ariaLabelIn = inputs.AriaLabel;
if("_ariaLabelInDataFetchStatus" in inputs) {
this.variables._ariaLabelInDataFetchStatus = inputs._ariaLabelInDataFetchStatus;
}

}

if("IsDisabled" in inputs) {
this.variables.isDisabledIn = inputs.IsDisabled;
if("_isDisabledInDataFetchStatus" in inputs) {
this.variables._isDisabledInDataFetchStatus = inputs._isDisabledInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "MSD.MSD");
});
define("MSD.MSD.MSD.mvc$view", ["OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "react", "OutSystems/ReactView/Main", "MSD.MSD.MSD.mvc$model", "MSD.MSD.MSD.mvc$controller", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.Separator.mvc$view", "MSD.controller$ManageEllipsis", "MSD.model$MSD_ItemList", "MSD.controller$ChangeSelectAll", "MSD.controller$CheckIfAllSelected", "MSD.controller$SelectItemsInList", "MSD.model$MSD_ItemRec", "MSD.controller$HandleSelectedList"], function (OutSystems, MSDModel, MSDController, React, OSView, MSD_MSD_MSD_mvc_model, MSD_MSD_MSD_mvc_controller, OSWidgets, OutSystemsUI_Utilities_Separator_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "MSD.MSD";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/MSD.MSD.MSD.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Utilities_Separator_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return MSD_MSD_MSD_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return MSD_MSD_MSD_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "msd",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD/DropdownFace onclick");
return controller.dropdownOnClick$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
extendedProperties: {
"aria-label": model.variables.ariaLabelIn,
tabIndex: "0",
role: "combobox"
},
style: model.getCachedValue(idService.getId("DropdownFace.Style"), function () {
return ((("display-flex vertical-align msd-dropdown " + ((model.variables.isDisabledIn) ? ("background-neutral-2") : (""))) + " ") + model.variables.extendedClassIn);
}, function () {
return model.variables.isDisabledIn;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
name: "DropdownFace"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isDisabledInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"aria-label": model.variables.ariaLabelIn
},
style: "flex1 margin-s margin-left-base",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
extendedProperties: {
title: model.getCachedValue(idService.getId("yiWdBfioY0ihpMwNbPBAfQ.title"), function () {
return (((((OS.BuiltinFunctions.length(model.variables.selectedListToCSVVar) > model.variables.maxCharBeforeEllipsisIn) && (model.variables.maxCharBeforeEllipsisIn > 0)) && !(model.variables.selectAllVar))) ? (model.variables.selectedListToCSVVar) : (""));
}, function () {
return model.variables.selectedListToCSVVar;
}, function () {
return model.variables.maxCharBeforeEllipsisIn;
}, function () {
return model.variables.selectAllVar;
})
},
value: model.getCachedValue(idService.getId("yiWdBfioY0ihpMwNbPBAfQ.Value"), function () {
return ((model.variables.selectedItemsVar.isEmpty) ? ("Select") : ((((model.variables.selectedItemsVar.length === 1)) ? (((model.variables.selectAllVar) ? ("All") : (OutSystemsDebugger.handleFunctionCall(function () {
return MSDController.default.manageEllipsis$Action(model.variables.selectedListToCSVVar, model.variables.maxCharBeforeEllipsisIn, callContext).processedTextOut;
}, OS.Types.Text, callContext.id)))) : (((model.variables.selectAllVar) ? ("All") : (OutSystemsDebugger.handleFunctionCall(function () {
return MSDController.default.manageEllipsis$Action(model.variables.selectedListToCSVVar, model.variables.maxCharBeforeEllipsisIn, callContext).processedTextOut;
}, OS.Types.Text, callContext.id)))))));
}, function () {
return model.variables.selectedItemsVar.isEmpty;
}, function () {
return model.variables.selectedItemsVar.length;
}, function () {
return model.variables.selectAllVar;
}, function () {
return model.variables.selectedListToCSVVar;
}, function () {
return model.variables.maxCharBeforeEllipsisIn;
}),
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._maxCharBeforeEllipsisInDataFetchStatus)
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "msd-dropdown-icon",
visible: true,
_idProps: {
service: idService,
name: "DropdownIcon"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.showListVar, false, this, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "chevron-up",
iconSize: /*FontSize*/ 0,
style: "msd-icon icon",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}, function () {
return [React.createElement(OSWidgets.Icon, {
icon: "chevron-down",
iconSize: /*FontSize*/ 0,
style: "msd-icon icon",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}))), $if(!(model.variables.showListVar), false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "msd-dropdown-list-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(model.variables.searchEnabledIn, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "msd-search",
visible: true,
_idProps: {
service: idService,
name: "SearchContainer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Search*/ 8,
mandatory: false,
maxLength: 50,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD/SearchInput OnChange");
controller.search_InputOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
prompt: "- Search for an option -",
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.searchValueVar, function (value) {
model.variables.searchValueVar = value;
}),
_idProps: {
service: idService,
name: "SearchInput"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "msd-dropdown-list",
visible: true,
_idProps: {
service: idService,
name: "DropdownList"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.optionsDescription,
extendedProperties: {
className: model.getCachedValue(idService.getId("OptionsDescription.class"), function () {
return ((model.variables.hideTitleVar) ? ("msd-hide") : ("margin-xs msd-options-description"));
}, function () {
return model.variables.hideTitleVar;
})
},
style: "margin-xs msd-options-description",
_idProps: {
service: idService,
name: "OptionsDescription"
},
_widgetRecordProvider: widgetsRecordProvider
}), $if((model.variables.selectAllEnabledIn && !(model.variables.localItemListVar.isEmpty)), false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "vertical-align margin-xs",
visible: true,
_idProps: {
service: idService,
name: "SelectAllcontainer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: true,
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD/SelectAllCheckbox OnChange");
return controller.selectAllCheckboxOnChange$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.selectAllVar, function (value) {
model.variables.selectAllVar = value;
}),
_idProps: {
service: idService,
name: "SelectAllCheckbox"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-left-s",
visible: true,
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, "All")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-xs",
visible: true,
_idProps: {
service: idService,
uuid: "15"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_Separator_mvc_view, {
inputs: {
Color: MSDModel.staticEntities.color.neutral5,
Space: MSDModel.staticEntities.space.none
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "16",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}))];
}, function () {
return [];
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
name: "OptionList"
},
_widgetRecordProvider: widgetsRecordProvider
}, $if(!(model.variables.localItemListVar.isEmpty), false, this, function () {
return [React.createElement(OSWidgets.List, {
animateItems: true,
gridProperties: {
classes: "OSFillParent"
},
mode: /*Default*/ 0,
source: model.variables.localItemListVar,
style: "list list-group msd-dropdown-list-group",
tag: "div",
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "vertical-align margin-xs",
visible: true,
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.localItemListVar.getCurrent(callContext.iterationContext).descriptionAttr), asPrimitiveValue(model.variables.localItemListVar.getCurrent(callContext.iterationContext).isDisabledAttr), asPrimitiveValue(model.variables.localItemListVar.getCurrent(callContext.iterationContext).isSelectedAttr)]
}, React.createElement(OSWidgets.Checkbox, {
_validationProps: {
validationService: validationService
},
enabled: !(model.variables.localItemListVar.getCurrent(callContext.iterationContext).isDisabledAttr),
onChange: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "MSD/MSD/ListItemCheckbox OnChange");
return controller.listItemCheckboxOnChange$Action(model.variables.localItemListVar.getCurrent(callContext.iterationContext), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "checkbox",
variable: model.createVariable(OS.Types.Boolean, model.variables.localItemListVar.getCurrent(callContext.iterationContext).isSelectedAttr, function (value) {
model.variables.localItemListVar.getCurrent(callContext.iterationContext).isSelectedAttr = value;
}),
_idProps: {
service: idService,
name: "ListItemCheckbox"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-left-s",
visible: true,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.localItemListVar.getCurrent(callContext.iterationContext).descriptionAttr,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, callContext, idService, "1")
},
_dependencies: []
})];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
style: "text-align: center;"
},
style: "msd-empty-list",
visible: true,
_idProps: {
service: idService,
name: "EmptyListContainer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.emptySearchTextIn,
_idProps: {
service: idService,
uuid: "24"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._emptySearchTextInDataFetchStatus)
}))];
}))))];
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("MSD.MSD.MSD.mvc$controller", ["OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.languageResources", "MSD.MSD.MSD.mvc$debugger", "MSD.MSD.MSD.mvc$controller.DropdownOnClick.CloseOnOutsideClickJS", "MSD.MSD.MSD.mvc$controller.OnDestroy.RemoveListenerJS", "MSD.controller$ManageEllipsis", "MSD.model$MSD_ItemList", "MSD.controller$ChangeSelectAll", "MSD.controller$CheckIfAllSelected", "MSD.controller$SelectItemsInList", "MSD.model$MSD_ItemRec", "MSD.controller$HandleSelectedList"], function (OutSystems, MSDModel, MSDController, MSDLanguageResources, MSD_MSD_MSD_mvc_Debugger, MSD_MSD_MSD_mvc_controller_DropdownOnClick_CloseOnOutsideClickJS, MSD_MSD_MSD_mvc_controller_OnDestroy_RemoveListenerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
window_OnClick$Action: function () {
return controller.executeActionInsideJSNode(controller._window_OnClick$Action.bind(controller), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "Window_OnClick");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:Dp6CBcZLWkyLBlVKjx57VQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.Dp6CBcZLWkyLBlVKjx57VQ:yji7Kx4eW03N7Uml+zXptg", "MSD", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:8qOXaQoYykm6Y4Q2Qj5JYg", callContext.id);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:w2BWm+6YHka1o8PWHDop9Q", callContext.id);
// Execute Action: Custom_IntChange
controller._custom_IntChange$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:75MqWTVYgkOYbDe+ejrQzw", callContext.id);
// Execute Action: GetSelectedList
controller._getSelectedList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:6oWLYVtG1keyAom7MRKSzA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:Dp6CBcZLWkyLBlVKjx57VQ", callContext.id);
}

};
Controller.prototype._selectAllCheckboxOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("SelectAllCheckboxOnChange");
callContext = controller.callContext(callContext);
var changeSelectAllVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.changeSelectAllVar = changeSelectAllVar;
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:eDfHC+tzoEqqvjaT0FdmXQ:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.eDfHC+tzoEqqvjaT0FdmXQ:y5FSYa5RVKlGSlsatvutNw", "MSD", "SelectAllCheckboxOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:_GH0uqGBYUyOX4hPYDJ+MQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:Wes3kXDpNUe1tdbkDoOP7A", callContext.id);
// Execute Action: ChangeSelectAll
changeSelectAllVar.value = MSDController.default.changeSelectAll$Action(model.variables.selectAllVar, model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:+znx2UcmRk2A4iSK0ClcgA", callContext.id);
// SelectedItems = ChangeSelectAll.SelectedList
model.variables.selectedItemsVar = changeSelectAllVar.value.selectedListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:+znx2UcmRk2A4iSK0ClcgA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// LocalItemList = ChangeSelectAll.List
model.variables.localItemListVar = changeSelectAllVar.value.listOut;
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:Q4uYWel4ZUKtXkc7tcwa_g", callContext.id) && !(model.variables.refreshOnCloseIn))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:lMAq0sbTmUupJ7uHmlpmWA", callContext.id);
// Trigger Event: SendSelectedList
return controller.sendSelectedList$Action(model.variables.localItemListVar, callContext);
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:JHy0wP6y2EKWsAsSXeFVXA", callContext.id);
// Execute Action: GetSelectedList
controller._getSelectedList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:c5WQ8YDVhUC8cenExDDk5A", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:eDfHC+tzoEqqvjaT0FdmXQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:eDfHC+tzoEqqvjaT0FdmXQ", callContext.id);
throw ex;

});
};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:OO+RGn1Bs0CgW4at3zXZVA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.OO+RGn1Bs0CgW4at3zXZVA:3nAkTnpsAcQ9zwsSsJmPcA", "MSD", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:Qc0FmB0IiUWXCx5iwaGVjA", callContext.id);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:WAhQ68PvnUGsw_CigOYS_A", callContext.id);
// Execute Action: Custom_IntChange
controller._custom_IntChange$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:qBVMB2J72keuvhe+_6UJrQ", callContext.id);
// Execute Action: GetSelectedList
controller._getSelectedList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:K0RAf6XskEuttzpwqEiwGw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:OO+RGn1Bs0CgW4at3zXZVA", callContext.id);
}

};
Controller.prototype._listItemCheckboxOnChange$Action = function (itemIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ListItemCheckboxOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.MSD.MSD.ListItemCheckboxOnChange$vars"))());
vars.value.itemInLocal = itemIn.clone();
var checkIfAllSelectedVar = new OS.DataTypes.VariableHolder();
var checkIfAllSelected2Var = new OS.DataTypes.VariableHolder();
var selectItemsInList2Var = new OS.DataTypes.VariableHolder();
var selectItemsInList3Var = new OS.DataTypes.VariableHolder();
var handleSelectedListVar = new OS.DataTypes.VariableHolder();
var selectItemsInListVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.checkIfAllSelectedVar = checkIfAllSelectedVar;
varBag.checkIfAllSelected2Var = checkIfAllSelected2Var;
varBag.selectItemsInList2Var = selectItemsInList2Var;
varBag.selectItemsInList3Var = selectItemsInList3Var;
varBag.handleSelectedListVar = handleSelectedListVar;
varBag.selectItemsInListVar = selectItemsInListVar;
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:NqavOFNydUav6U+fC2rbRA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.NqavOFNydUav6U+fC2rbRA:LCIRHGRU4ZdGO11USuxmlw", "MSD", "ListItemCheckboxOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:IbOJsOW0c0qysaYpNtDV0A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:p2NCoDD8kUGgaOIMl5XmdA", callContext.id);
// Execute Action: HandleSelectedList
handleSelectedListVar.value = MSDController.default.handleSelectedList$Action(vars.value.itemInLocal, model.variables.selectedItemsVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:wfy+ft4qBUiMkeq0nDg+sg", callContext.id);
// SelectedItems = HandleSelectedList.SelectedItems
model.variables.selectedItemsVar = handleSelectedListVar.value.selectedItemsOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:t1rpQ+jc60aZsHGvGBUluQ", callContext.id);
// Execute Action: SelectItemsInList2
selectItemsInList2Var.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.itemListIn, callContext);

if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:59CcFC1nN0qeBfSiHcWbjQ", callContext.id) && model.variables.useItemListVar)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:UUEAo6HSWU23lBkXFsNGig", callContext.id);
// Execute Action: SelectItemsInList
selectItemsInListVar.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:1UGfAYJ3r0qheMhp7sUQsg", callContext.id);
// Execute Action: CheckIfAllSelected
checkIfAllSelectedVar.value = MSDController.default.checkIfAllSelected$Action(model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:CNygtjUkaku6EzTpwp5DaQ", callContext.id);
// SelectAll = CheckIfAllSelected.AllSelected
model.variables.selectAllVar = checkIfAllSelectedVar.value.allSelectedOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:CNygtjUkaku6EzTpwp5DaQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AuxItemList = SelectItemsInList2.ProcessedList
model.variables.auxItemListVar = selectItemsInList2Var.value.processedListOut;
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:wYCDd7oaKE+7RDPgZ2sLtA", callContext.id);
// Execute Action: SelectItemsInList3
selectItemsInList3Var.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.displayListIn, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:OVi7L49SdU205zlq+FKFZQ", callContext.id);
// Execute Action: CheckIfAllSelected2
checkIfAllSelected2Var.value = MSDController.default.checkIfAllSelected$Action(model.variables.displayListIn, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:GhHqyaNJJkuLiTPxvAHG9w", callContext.id);
// SelectAll = CheckIfAllSelected2.AllSelected
model.variables.selectAllVar = checkIfAllSelected2Var.value.allSelectedOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:GhHqyaNJJkuLiTPxvAHG9w", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// AuxItemList = SelectItemsInList2.ProcessedList
model.variables.auxItemListVar = selectItemsInList2Var.value.processedListOut;
}

return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:LLILF2bDHkSoW+q0XWudeg", callContext.id) && !(model.variables.refreshOnCloseIn))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:y9_Vmvi+fUmC0b3Nhg8FVQ", callContext.id);
// Trigger Event: SendSelectedList
return controller.sendSelectedList$Action(model.variables.auxItemListVar, callContext);
}

}).then(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:6aC7AYPj0EKuS3Or2pS9+g", callContext.id);
// Execute Action: GetSelectedList
controller._getSelectedList$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:nbCk7HeEJE63rPCo2hX0nQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:NqavOFNydUav6U+fC2rbRA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:NqavOFNydUav6U+fC2rbRA", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("MSD.MSD.MSD.ListItemCheckboxOnChange$vars", [{
name: "Item",
attrName: "itemInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new MSDModel.MSD_ItemRec();
},
complexType: MSDModel.MSD_ItemRec
}]);
Controller.prototype._dropdownOnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DropdownOnClick");
callContext = controller.callContext(callContext);
var selectItemsInListVar = new OS.DataTypes.VariableHolder();
var selectItemsInList2Var = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.selectItemsInListVar = selectItemsInListVar;
varBag.selectItemsInList2Var = selectItemsInList2Var;
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:u3MdUn9FxkOTFcHJoFWMSg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.u3MdUn9FxkOTFcHJoFWMSg:jOP7OdqniiwkT_khdm96fQ", "MSD", "DropdownOnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:6EJ_dmqoo0uX+kr16XIQYQ", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:dU83Ds_rk0SCEZFLv0czYA", callContext.id) && model.variables.isDisabledIn)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:mPpUHE26ekKKeUQcLsTVuw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:O7vh3xqLykmf8nrMC48N0Q", callContext.id);
// HideTitle = False
model.variables.hideTitleVar = false;
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:zibqKE_lTEC1KHQNlmS9Iw", callContext.id) && model.variables.showListVar)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:qCa5LF+hCUuBTbp81Ff_0w", callContext.id);
// Execute Action: SelectItemsInList
selectItemsInListVar.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:v0BGoXhBp0aXI4sLuya4FQ", callContext.id);
// Execute Action: SelectItemsInList2
selectItemsInList2Var.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.itemListIn, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:kkmfO0aTcEyhUwCjlTmVhA", callContext.id);
// ItemList = SelectItemsInList2.ProcessedList
model.variables.itemListIn = selectItemsInList2Var.value.processedListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:kkmfO0aTcEyhUwCjlTmVhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ShowList = notShowList
model.variables.showListVar = !(model.variables.showListVar);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:kkmfO0aTcEyhUwCjlTmVhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// SearchValue = ""
model.variables.searchValueVar = "";
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:kkmfO0aTcEyhUwCjlTmVhA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// AuxItemList = SelectItemsInList2.ProcessedList
model.variables.auxItemListVar = selectItemsInList2Var.value.processedListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:eG0Cbp1RZE2WTPVuhdimyw", callContext.id);
// Trigger Event: SendSelectedList
return controller.sendSelectedList$Action(model.variables.auxItemListVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:G5y+5SfVekGeLGqkB0wyqw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:suN8O7Kp+EGYeSBh4i6YTg", callContext.id);
// Adds an event to close the drop when clicked outside
controller.safeExecuteJSNode(MSD_MSD_MSD_mvc_controller_DropdownOnClick_CloseOnOutsideClickJS, "CloseOnOutsideClick", "DropdownOnClick", null, function ($parameters) {
}, {
Window_OnClick: controller.clientActionProxies.window_OnClick$Action
}, {});
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:arHaa7Ni0E2ZSBO8l1UyKA", callContext.id) && model.variables.useItemListVar)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:ASEteYXybkuYmbeS5_e5eA", callContext.id);
// HideTitle = True
model.variables.hideTitleVar = true;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:ASEteYXybkuYmbeS5_e5eA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// LocalItemList = ItemList
model.variables.localItemListVar = model.variables.itemListIn;
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:PCV_kLQcaka1MOi8cLwm7w", callContext.id);
// LocalItemList = DisplayList
model.variables.localItemListVar = model.variables.displayListIn;
}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:qyYKJquYKEqEWgLCypaQJg", callContext.id);
// ShowList = notShowList
model.variables.showListVar = !(model.variables.showListVar);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:G5y+5SfVekGeLGqkB0wyqw", callContext.id);
}

});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:u3MdUn9FxkOTFcHJoFWMSg", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:u3MdUn9FxkOTFcHJoFWMSg", callContext.id);
throw ex;

});
};
Controller.prototype._custom_IntChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Custom_IntChange");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:8Bk4Vve6BEuMpIT9Fnm3ng:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.8Bk4Vve6BEuMpIT9Fnm3ng:IjkKyu9eKfqyi6agOvlQGQ", "MSD", "Custom_IntChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:OMIv4PZrlEWX5ar9gIClFA", callContext.id);
do {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:pSxjoXLbD06R1vALeroXzQ", callContext.id);
// UseItemList = False
model.variables.useItemListVar = false;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:JEPC3rV18Uyz3zBMALnrRQ", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.selectedItemsVar, callContext);
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:A7OzjKrnJUe0KUgsed8rMg", callContext.id) && !(model.variables.displayListIn.isEmpty))) {
// Foreach ItemList
callContext.iterationContext.registerIterationStart(model.variables.itemListIn);
try {var itemListIterator = callContext.iterationContext.getIterator(model.variables.itemListIn);
var itemListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:WrpuOhMBs0qCabfrdquFOQ", callContext.id) && (itemListIndex < model.variables.itemListIn.length))) {
itemListIterator.currentRowNumber = itemListIndex;
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:9ZZ1PfMugUaOA0NGF_eVxg", callContext.id) && model.variables.itemListIn.getItem(itemListIndex.valueOf()).isSelectedAttr)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:YQ4YF7E0i0qAZ9JdWT1eSQ", callContext.id);
// UseItemList = True
model.variables.useItemListVar = true;
}

itemListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.itemListIn);
}

if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:5+R2t2_zOEC8KWIxMPvvww", callContext.id) && !(model.variables.useItemListVar))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:1fWZbU0HF0O920Db47SPTw", callContext.id);
// LocalItemList = DisplayList
model.variables.localItemListVar = model.variables.displayListIn;
break;
}

}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:npE2VKWPNkaePcUWiF4WeQ", callContext.id);
// LocalItemList = ItemList
model.variables.localItemListVar = model.variables.itemListIn;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:npE2VKWPNkaePcUWiF4WeQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// UseItemList = True
model.variables.useItemListVar = true;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:npE2VKWPNkaePcUWiF4WeQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// HideTitle = True
model.variables.hideTitleVar = true;
// Foreach LocalItemList
callContext.iterationContext.registerIterationStart(model.variables.localItemListVar);
try {var localItemListIterator = callContext.iterationContext.getIterator(model.variables.localItemListVar);
var localItemListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:zOahnJjSU0KRFH0lZNK2Eg", callContext.id) && (localItemListIndex < model.variables.localItemListVar.length))) {
localItemListIterator.currentRowNumber = localItemListIndex;
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:UhcH30M1pE6x1uaWPdCnlQ", callContext.id) && model.variables.localItemListVar.getItem(localItemListIndex.valueOf()).isSelectedAttr)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:R3IByi9NgE2HOT4CFmTl0w", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(model.variables.selectedItemsVar, model.variables.localItemListVar.getItem(localItemListIndex.valueOf()).itemIdAttr, callContext);
}

localItemListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(model.variables.localItemListVar);
}

// 🠖
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:4EsL4JD86UG6INf_RzwRoA", callContext.id);
} while(false)
;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:6mA9O4RCGE6wMVbv4cSaXg", callContext.id);
// Execute Action: Search_InputOnChange
controller._search_InputOnChange$Action(callContext);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:xJoIrARVFEyeJuXQM87QmA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:8Bk4Vve6BEuMpIT9Fnm3ng", callContext.id);
}

};
Controller.prototype._getSelectedList$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GetSelectedList");
callContext = controller.callContext(callContext);
var listFilter_SelectedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.listFilter_SelectedVar = listFilter_SelectedVar;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:gmbJWyKA9U6xCa7zyXGp2g:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.gmbJWyKA9U6xCa7zyXGp2g:VyVOMnJxFQ1Rl4eQjOx2TQ", "MSD", "GetSelectedList", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:09CCnljwOkOxBHLPvh89AQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:sK1ehUsW7063zEPYQPm_0A", callContext.id);
// Execute Action: ListFilter_Selected
listFilter_SelectedVar.value = OS.SystemActions.listFilter(model.variables.localItemListVar, function (p) {
return p.isSelectedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:vVFO2s4woES0GH4KDmqBbw", callContext.id);
// SelectedListToCSV = ""
model.variables.selectedListToCSVVar = "";
// Foreach ListFilter_Selected.FilteredList
callContext.iterationContext.registerIterationStart(listFilter_SelectedVar.value.filteredListOut);
try {var filteredListIterator = callContext.iterationContext.getIterator(listFilter_SelectedVar.value.filteredListOut);
var filteredListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:ymyvb3uEnE6u8xknvVqCyQ", callContext.id) && (filteredListIndex < listFilter_SelectedVar.value.filteredListOut.length))) {
filteredListIterator.currentRowNumber = filteredListIndex;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:xLRplnxnf02hENshXPD9jw", callContext.id);
// SelectedListToCSV = SelectedListToCSV + ListFilter_Selected.FilteredList.Current.Description + If
model.variables.selectedListToCSVVar = ((model.variables.selectedListToCSVVar + listFilter_SelectedVar.value.filteredListOut.getItem(filteredListIndex.valueOf()).descriptionAttr) + (((listFilter_SelectedVar.value.filteredListOut.getCurrentRowNumber(callContext.iterationContext) === (listFilter_SelectedVar.value.filteredListOut.length - 1))) ? ("") : (", ")));
filteredListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(listFilter_SelectedVar.value.filteredListOut);
}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:2p1QqPDvjUC7eQZAr2CUdw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:gmbJWyKA9U6xCa7zyXGp2g", callContext.id);
}

};
Controller.prototype._search_InputOnChange$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Search_InputOnChange");
callContext = controller.callContext(callContext);
var checkIfAllSelected2Var = new OS.DataTypes.VariableHolder();
var selectItemsInListVar = new OS.DataTypes.VariableHolder();
var listFilterVar = new OS.DataTypes.VariableHolder();
var selectItemsInList2Var = new OS.DataTypes.VariableHolder();
var checkIfAllSelectedVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.checkIfAllSelected2Var = checkIfAllSelected2Var;
varBag.selectItemsInListVar = selectItemsInListVar;
varBag.listFilterVar = listFilterVar;
varBag.selectItemsInList2Var = selectItemsInList2Var;
varBag.checkIfAllSelectedVar = checkIfAllSelectedVar;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:QWQ4X7JSmk+lNUkJZZxFcg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.QWQ4X7JSmk+lNUkJZZxFcg:bM+23jMvKBx2drG1KWMDAA", "MSD", "Search_InputOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:2pe4ai3nk065P1CMhsVXeg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:efkWSDk_Gk6EnBtrpI3J6g", callContext.id) && (OS.BuiltinFunctions.length(model.variables.searchValueVar) === 0))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:4vEvwJe6_0mla4GNzOwMFg", callContext.id);
// LocalItemList = If
model.variables.localItemListVar = ((model.variables.useItemListVar) ? (model.variables.itemListIn) : (model.variables.displayListIn));
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:4vEvwJe6_0mla4GNzOwMFg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// HideTitle = If
model.variables.hideTitleVar = ((model.variables.useItemListVar) ? (true) : (false));
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:nXKvnnZs+U2HYjHbwyXn3w", callContext.id);
// Execute Action: SelectItemsInList
selectItemsInListVar.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:U183xxI3g0qkQZ6TABQvFQ", callContext.id);
// LocalItemList = SelectItemsInList.ProcessedList
model.variables.localItemListVar = selectItemsInListVar.value.processedListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:4kj+Is5LtUSYc+7+Mr4VCg", callContext.id);
// Execute Action: CheckIfAllSelected2
checkIfAllSelected2Var.value = MSDController.default.checkIfAllSelected$Action(model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:lVaUI11NAE2ktJd8N0D0GA", callContext.id);
// SelectAll = CheckIfAllSelected2.AllSelected
model.variables.selectAllVar = checkIfAllSelected2Var.value.allSelectedOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:_oqviK6PmUGvd7chz7s2cw", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:18siTlVw6UyCiR3OEe9qiA", callContext.id) && (OS.BuiltinFunctions.length(model.variables.searchValueVar) >= 2))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:sI9BVVkZkkeNiyKBfa+KIg", callContext.id);
// HideTitle = True
model.variables.hideTitleVar = true;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:CV6opWrVsEqamSmSz00NhA", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(model.variables.itemListIn, function (p) {
return (OS.BuiltinFunctions.index(p.descriptionAttr, model.variables.searchValueVar, 0, false, true) > -1);
}, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:0O7pSxDN2kqeWLjJaMNa2w", callContext.id);
// LocalItemList = ListFilter.FilteredList
model.variables.localItemListVar = listFilterVar.value.filteredListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:_f5uzMp6wE2DXm+VHCyRSg", callContext.id);
// Execute Action: SelectItemsInList2
selectItemsInList2Var.value = MSDController.default.selectItemsInList$Action(model.variables.selectedItemsVar, model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:YWef2Zpo20SkFniRI5NW8A", callContext.id);
// LocalItemList = SelectItemsInList2.ProcessedList
model.variables.localItemListVar = selectItemsInList2Var.value.processedListOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:Jjqd8sjoFkSfcuufrbDOXw", callContext.id);
// Execute Action: CheckIfAllSelected
checkIfAllSelectedVar.value = MSDController.default.checkIfAllSelected$Action(model.variables.localItemListVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:gDw8DWUK2UaNsL6lt_3iIg", callContext.id);
// SelectAll = CheckIfAllSelected.AllSelected
model.variables.selectAllVar = checkIfAllSelectedVar.value.allSelectedOut;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:G7_i+pZC7E+zbVlBfYL3bg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:_oqviK6PmUGvd7chz7s2cw", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:QWQ4X7JSmk+lNUkJZZxFcg", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:Q+G1cikXvkGztY48XlzxBw:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.Q+G1cikXvkGztY48XlzxBw:dQmJYnfDIjIzcaIOqcL7xA", "MSD", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:M+Fn4RrGUE6xGlB48O181A", callContext.id);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:nTthfeqJmUmTIoUxBeDAPg", callContext.id);
controller.safeExecuteJSNode(MSD_MSD_MSD_mvc_controller_OnDestroy_RemoveListenerJS, "RemoveListener", "OnDestroy", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:CADHU3p520ehZw0VpZFOUA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:Q+G1cikXvkGztY48XlzxBw", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:2OVBd9mp90q71fv0wlpz4Q:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.2OVBd9mp90q71fv0wlpz4Q:5CPKeFHVESihZNW9UuqvzA", "MSD", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:Jni2TZsBokydwytm8M2YNA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:25Q96_g0f0ijjVy37wvqgA", callContext.id);
// Trigger Event: OnInitialized
return controller.onInitialized$Action(idService.getId("DropdownFace"), callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:h3+FAjdPBUeYSFRgbD3cSQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:2OVBd9mp90q71fv0wlpz4Q", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:2OVBd9mp90q71fv0wlpz4Q", callContext.id);
throw ex;

});
};
Controller.prototype._window_OnClick$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("Window_OnClick");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:rjwS0W4_X0+Bb5QH+buOdA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg/ClientActions.rjwS0W4_X0+Bb5QH+buOdA:lSgTW6OGX8lCS9a0sTK_1g", "MSD", "Window_OnClick", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:nssBoxl1ZUSo85escPHU5A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:fyMwLXtPIUm5RPTGcLl_lA", callContext.id) && !(model.variables.showListVar))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:ZcP646rlg0+wAkT3KncmQA", callContext.id);
} else {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:VKHSv_p2TEa_gmyakSY0eQ", callContext.id) && model.variables.refreshOnCloseIn)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:_w2ZBqBFFECeC9qbgRNQpQ", callContext.id);
// Execute Action: DropdownOnClick
return controller._dropdownOnClick$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:YfFc0BmOKkW6A3yshV3Nqg", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:tPyq0lMiZUe+Dz0A1ZZKAQ", callContext.id);
// ShowList = False
model.variables.showListVar = false;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:YfFc0BmOKkW6A3yshV3Nqg", callContext.id);
}

});
}

});
}).then(function (res) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:rjwS0W4_X0+Bb5QH+buOdA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:rjwS0W4_X0+Bb5QH+buOdA", callContext.id);
throw ex;

});
};

Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.selectAllCheckboxOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._selectAllCheckboxOnChange$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.listItemCheckboxOnChange$Action = function (itemIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._listItemCheckboxOnChange$Action, callContext, itemIn);

};
Controller.prototype.dropdownOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dropdownOnClick$Action, callContext);

};
Controller.prototype.custom_IntChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._custom_IntChange$Action, callContext);

};
Controller.prototype.getSelectedList$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._getSelectedList$Action, callContext);

};
Controller.prototype.search_InputOnChange$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._search_InputOnChange$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.window_OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._window_OnClick$Action, callContext);

};
Controller.prototype.onInitialized$Action = function () {
return Promise.resolve();
};
Controller.prototype.sendSelectedList$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:fWtJs57lI0qCTlwkcDoxDA:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA:E8OyV3OQngY_56SfmpWnyQ", "MSD", "MSD", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:0SJjaLOvvkmwqVcWzK7WRg:/NRWebFlows.fWtJs57lI0qCTlwkcDoxDA/NodesShownInESpaceTree.0SJjaLOvvkmwqVcWzK7WRg:v5JsLUgdNCMu99yUAXWpJw", "MSD", "MSD", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:0SJjaLOvvkmwqVcWzK7WRg", callContext.id);
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:fWtJs57lI0qCTlwkcDoxDA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MSD/MSD On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MSD/MSD On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MSD/MSD On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "MSD/MSD On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return MSDController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, MSDLanguageResources);
});
define("MSD.MSD.MSD.mvc$controller.DropdownOnClick.CloseOnOutsideClickJS", [], function () {
return function ($actions, $roles, $public) {
 // Close the dropdown if the user clicks outside of it
var controller = new AbortController();
var _signal = controller.signal;

 document.addEventListener("click", function(event){
     if(event.target.matches('.popup-backdrop')){
        $actions.Window_OnClick();
        console.log("popup");
        controller.abort();
    }
    if ((!event.target.matches('.checkbox')) && !event.target.matches('.msd') && !event.target.matches('.msd-dropdown-list-wrapper') && (event.target.offsetParent == null || (!event.target.offsetParent.matches('.msd-dropdown-list-wrapper') && !event.target.offsetParent.matches('.msd-dropdown-list-group') ))){
        $actions.Window_OnClick();
        controller.abort();
    }
 }, { signal: _signal });
};
});
define("MSD.MSD.MSD.mvc$controller.OnDestroy.RemoveListenerJS", [], function () {
return function ($actions, $roles, $public) {
function _listener() {}

document.removeEventListener('click', _listener)
};
});

define("MSD.MSD.MSD.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Wes3kXDpNUe1tdbkDoOP7A": {
getter: function (varBag, idService) {
return varBag.changeSelectAllVar.value;
}
},
"XG4tVagBsEyoQcWVsx52Tg": {
getter: function (varBag, idService) {
return varBag.vars.value.itemInLocal;
}
},
"1UGfAYJ3r0qheMhp7sUQsg": {
getter: function (varBag, idService) {
return varBag.checkIfAllSelectedVar.value;
}
},
"OVi7L49SdU205zlq+FKFZQ": {
getter: function (varBag, idService) {
return varBag.checkIfAllSelected2Var.value;
}
},
"t1rpQ+jc60aZsHGvGBUluQ": {
getter: function (varBag, idService) {
return varBag.selectItemsInList2Var.value;
}
},
"wYCDd7oaKE+7RDPgZ2sLtA": {
getter: function (varBag, idService) {
return varBag.selectItemsInList3Var.value;
}
},
"p2NCoDD8kUGgaOIMl5XmdA": {
getter: function (varBag, idService) {
return varBag.handleSelectedListVar.value;
}
},
"UUEAo6HSWU23lBkXFsNGig": {
getter: function (varBag, idService) {
return varBag.selectItemsInListVar.value;
}
},
"qCa5LF+hCUuBTbp81Ff_0w": {
getter: function (varBag, idService) {
return varBag.selectItemsInListVar.value;
}
},
"v0BGoXhBp0aXI4sLuya4FQ": {
getter: function (varBag, idService) {
return varBag.selectItemsInList2Var.value;
}
},
"suN8O7Kp+EGYeSBh4i6YTg": {
getter: function (varBag, idService) {
return varBag.closeOnOutsideClickJSResult.value;
}
},
"sK1ehUsW7063zEPYQPm_0A": {
getter: function (varBag, idService) {
return varBag.listFilter_SelectedVar.value;
}
},
"4kj+Is5LtUSYc+7+Mr4VCg": {
getter: function (varBag, idService) {
return varBag.checkIfAllSelected2Var.value;
}
},
"nXKvnnZs+U2HYjHbwyXn3w": {
getter: function (varBag, idService) {
return varBag.selectItemsInListVar.value;
}
},
"CV6opWrVsEqamSmSz00NhA": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"_f5uzMp6wE2DXm+VHCyRSg": {
getter: function (varBag, idService) {
return varBag.selectItemsInList2Var.value;
}
},
"Jjqd8sjoFkSfcuufrbDOXw": {
getter: function (varBag, idService) {
return varBag.checkIfAllSelectedVar.value;
}
},
"nTthfeqJmUmTIoUxBeDAPg": {
getter: function (varBag, idService) {
return varBag.removeListenerJSResult.value;
}
},
"PA1VTZANsUedkMeOJv0sPQ": {
getter: function (varBag, idService) {
return varBag.model.variables.showListVar;
},
dataType: OS.Types.Boolean
},
"4Pm7H0FN80mHQiDNzMtzVg": {
getter: function (varBag, idService) {
return varBag.model.variables.searchValueVar;
},
dataType: OS.Types.Text
},
"kUBSYd5FJEqFC6sB4022AA": {
getter: function (varBag, idService) {
return varBag.model.variables.selectAllVar;
},
dataType: OS.Types.Boolean
},
"iLQfxyZBqkaxMorviZ01sg": {
getter: function (varBag, idService) {
return varBag.model.variables.localItemListVar;
}
},
"LqvytcgHrEe4HM8K_9+Csw": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedItemsVar;
}
},
"JsaeWEajIU6kaaoT+v26qw": {
getter: function (varBag, idService) {
return varBag.model.variables.auxItemListVar;
}
},
"bgnTJG4Lk0+4EE2eKpEeUg": {
getter: function (varBag, idService) {
return varBag.model.variables.useItemListVar;
},
dataType: OS.Types.Boolean
},
"vECygzeMPkiz0CMYkDJlag": {
getter: function (varBag, idService) {
return varBag.model.variables.hideTitleVar;
},
dataType: OS.Types.Boolean
},
"WGuJYI0gFUmx+JM2Q2G7Pw": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedListToCSVVar;
},
dataType: OS.Types.Text
},
"cVrMUreqZ0SYp8GaKF6EQw": {
getter: function (varBag, idService) {
return varBag.model.variables.itemListIn;
}
},
"YBUv1WbBEUyYk4mvpFCsPw": {
getter: function (varBag, idService) {
return varBag.model.variables.displayListIn;
}
},
"6yNKQu63cUWYwEwH94Sc5w": {
getter: function (varBag, idService) {
return varBag.model.variables.selectAllEnabledIn;
},
dataType: OS.Types.Boolean
},
"ZlWD_2Zy+kq3OZX2cTtJ6w": {
getter: function (varBag, idService) {
return varBag.model.variables.searchEnabledIn;
},
dataType: OS.Types.Boolean
},
"YNY2ssipX0OFZk1O5Dy5zQ": {
getter: function (varBag, idService) {
return varBag.model.variables.refreshOnCloseIn;
},
dataType: OS.Types.Boolean
},
"1_RZMpC69U+N1dnw3+BMNQ": {
getter: function (varBag, idService) {
return varBag.model.variables.emptySearchTextIn;
},
dataType: OS.Types.Text
},
"jjeG5Hoi1UyaHuXTrwQflg": {
getter: function (varBag, idService) {
return varBag.model.variables.maxCharBeforeEllipsisIn;
},
dataType: OS.Types.Integer
},
"iIuSSukisEC9zfn_qAtyew": {
getter: function (varBag, idService) {
return varBag.model.variables.ariaLabelIn;
},
dataType: OS.Types.Text
},
"YSY2++Opw0iNf+nsgoitQg": {
getter: function (varBag, idService) {
return varBag.model.variables.isDisabledIn;
},
dataType: OS.Types.Boolean
},
"_WtzbG4Vx0yTx0k9+kDkIw": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"3g1Ex_pcWUqYaHATN71fjg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DropdownFace"));
})(varBag.model, idService);
}
},
"6lzVXdnUDkSa_60HnegyVA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DropdownIcon"));
})(varBag.model, idService);
}
},
"Hz+wlBtEN02WbL64wKeN0Q": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SearchContainer"));
})(varBag.model, idService);
}
},
"_MGSMZJwDUWLjrJtRKuBpg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SearchInput"));
})(varBag.model, idService);
}
},
"rDTWSXd+4keldmO22t05Rg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("DropdownList"));
})(varBag.model, idService);
}
},
"eKuU4y7MV06AAwAtdEyrzA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("OptionsDescription"));
})(varBag.model, idService);
}
},
"i5NnAjk06kqwSBMDhgbtEw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SelectAllcontainer"));
})(varBag.model, idService);
}
},
"vdCiK+vBdEuJ5ThnZXKXbg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("SelectAllCheckbox"));
})(varBag.model, idService);
}
},
"uA2vfREwtESPxVsUusk0QA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("OptionList"));
})(varBag.model, idService);
}
},
"qZ8e+kmpvUqL+YjQI61lSg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ListItemCheckbox"));
})(varBag.model, idService);
}
},
"PFOFspQiHkeMkMj0x3JvMw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("EmptyListContainer"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
