﻿define("PHICore.Common_Widgets.CaseNumber.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "Common_CW.controller$Check_SP_ViewRestrictedCases", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$ReplaceIfBlank", "Common_CW.controller$Check_PM_29_RebateExceptionManagement"], function (OutSystems, PHICoreModel, Common_CWController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("CaseId", "caseIdIn", "CaseId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, false), 
this.attr("_caseIdInDataFetchStatus", "_caseIdInDataFetchStatus", "_caseIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CaseNumber", "caseNumberIn", "CaseNumber", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_caseNumberInDataFetchStatus", "_caseNumberInDataFetchStatus", "_caseNumberInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsRestricted", "isRestrictedIn", "IsRestricted", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isRestrictedInDataFetchStatus", "_isRestrictedInDataFetchStatus", "_isRestrictedInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CaseActiveTab", "caseActiveTabIn", "CaseActiveTab", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_caseActiveTabInDataFetchStatus", "_caseActiveTabInDataFetchStatus", "_caseActiveTabInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("IsReactivateMember", "isReactivateMemberIn", "IsReactivateMember", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_isReactivateMemberInDataFetchStatus", "_isReactivateMemberInDataFetchStatus", "_isReactivateMemberInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("CaseStatusPurposeId", "caseStatusPurposeIdIn", "CaseStatusPurposeId", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_caseStatusPurposeIdInDataFetchStatus", "_caseStatusPurposeIdInDataFetchStatus", "_caseStatusPurposeIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("CaseId" in inputs) {
this.variables.caseIdIn = inputs.CaseId;
if("_caseIdInDataFetchStatus" in inputs) {
this.variables._caseIdInDataFetchStatus = inputs._caseIdInDataFetchStatus;
}

}

if("CaseNumber" in inputs) {
this.variables.caseNumberIn = inputs.CaseNumber;
if("_caseNumberInDataFetchStatus" in inputs) {
this.variables._caseNumberInDataFetchStatus = inputs._caseNumberInDataFetchStatus;
}

}

if("IsRestricted" in inputs) {
this.variables.isRestrictedIn = inputs.IsRestricted;
if("_isRestrictedInDataFetchStatus" in inputs) {
this.variables._isRestrictedInDataFetchStatus = inputs._isRestrictedInDataFetchStatus;
}

}

if("CaseActiveTab" in inputs) {
this.variables.caseActiveTabIn = inputs.CaseActiveTab;
if("_caseActiveTabInDataFetchStatus" in inputs) {
this.variables._caseActiveTabInDataFetchStatus = inputs._caseActiveTabInDataFetchStatus;
}

}

if("IsReactivateMember" in inputs) {
this.variables.isReactivateMemberIn = inputs.IsReactivateMember;
if("_isReactivateMemberInDataFetchStatus" in inputs) {
this.variables._isReactivateMemberInDataFetchStatus = inputs._isReactivateMemberInDataFetchStatus;
}

}

if("CaseStatusPurposeId" in inputs) {
this.variables.caseStatusPurposeIdIn = inputs.CaseStatusPurposeId;
if("_caseStatusPurposeIdInDataFetchStatus" in inputs) {
this.variables._caseStatusPurposeIdInDataFetchStatus = inputs._caseStatusPurposeIdInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Common_Widgets.CaseNumber");
});
define("PHICore.Common_Widgets.CaseNumber.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "PHICore.Common_Widgets.CaseNumber.mvc$model", "PHICore.Common_Widgets.CaseNumber.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "Common_CW.controller$Check_SP_ViewRestrictedCases", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$ReplaceIfBlank", "Common_CW.controller$Check_PM_29_RebateExceptionManagement"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, React, OSView, PHICore_Common_Widgets_CaseNumber_mvc_model, PHICore_Common_Widgets_CaseNumber_mvc_controller, PHICoreClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common_Widgets.CaseNumber";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Common_Widgets_CaseNumber_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Common_Widgets_CaseNumber_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(model.variables.isRestrictedIn, false, this, function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewRestrictedCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [$if((model.variables.caseNumberIn === OS.BuiltinFunctions.nullTextIdentifier()), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("wpCpE+Y6kU6jloyVdEbLmQ.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.replaceIfBlank$Action(model.variables.caseNumberIn, "-", callContext).valueOutOut;
}, OS.Types.Text, callContext.id);
}, function () {
return model.variables.caseNumberIn;
}),
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": model.variables.caseNumberIn
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/CaseNumber/Link OnClick");
controller.onClick_CaseNumber$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.variables.caseNumberIn,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
}))];
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.caseNumberIn,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.caseNumberIn,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
})];
}, function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SP_ViewCases$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [$if((model.variables.caseNumberIn === OS.BuiltinFunctions.nullTextIdentifier()), false, this, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("W4YSQGgQg0e3IRYrv569Fw.Value"), function () {
return OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.replaceIfBlank$Action(model.variables.caseNumberIn, "-", callContext).valueOutOut;
}, OS.Types.Text, callContext.id);
}, function () {
return model.variables.caseNumberIn;
}),
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
}, function () {
return [$if((model.variables.caseStatusPurposeIdIn === PHICoreModel.staticEntities.caseStatusPurpose.pendingRebateParticipation), false, this, function () {
return [$if(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_29_RebateExceptionManagement$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id), false, this, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("gdDNqJsc9UKggLBf0j1nig.aria-label"), function () {
return ((model.variables.isReactivateMemberIn) ? ((("Case #" + model.variables.caseNumberIn) + " ")) : (model.variables.caseNumberIn));
}, function () {
return model.variables.isReactivateMemberIn;
}, function () {
return model.variables.caseNumberIn;
})
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/CaseNumber/Link OnClick");
controller.onClick_CaseNumber$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("uuHzEDxRwU2LfNBJ_Zh7Uw.Value"), function () {
return ((model.variables.isReactivateMemberIn) ? ((("Case #" + model.variables.caseNumberIn) + " ")) : (model.variables.caseNumberIn));
}, function () {
return model.variables.isReactivateMemberIn;
}, function () {
return model.variables.caseNumberIn;
}),
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isReactivateMemberInDataFetchStatus, model.variables._caseNumberInDataFetchStatus)
}))];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.caseNumberIn,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
})];
}, function () {
return [React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("8fZ5T0kPeUC63oDQgm6pgQ.aria-label"), function () {
return ((model.variables.isReactivateMemberIn) ? ((("Case #" + model.variables.caseNumberIn) + " ")) : (model.variables.caseNumberIn));
}, function () {
return model.variables.isReactivateMemberIn;
}, function () {
return model.variables.caseNumberIn;
})
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Common_Widgets/CaseNumber/Link OnClick");
controller.onClick_CaseNumber$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("4+kQYLR8xEesHTv2YAzQ8A.Value"), function () {
return ((model.variables.isReactivateMemberIn) ? ((("Case #" + model.variables.caseNumberIn) + " ")) : (model.variables.caseNumberIn));
}, function () {
return model.variables.isReactivateMemberIn;
}, function () {
return model.variables.caseNumberIn;
}),
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._isReactivateMemberInDataFetchStatus, model.variables._caseNumberInDataFetchStatus)
}))];
})];
})];
}, function () {
return [React.createElement(OSWidgets.Expression, {
value: model.variables.caseNumberIn,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._caseNumberInDataFetchStatus)
})];
})];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Common_Widgets.CaseNumber.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Common_Widgets.CaseNumber.mvc$debugger", "PHICore.Common_Widgets.CaseNumber.mvc$controller.OnClick_CaseNumber.OpenNewTabJS", "Common_CW.controller$Check_SP_ViewRestrictedCases", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$Check_SP_ViewCases", "Common_CW.controller$ReplaceIfBlank", "Common_CW.controller$Check_PM_29_RebateExceptionManagement"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Common_Widgets_CaseNumber_mvc_Debugger, PHICore_Common_Widgets_CaseNumber_mvc_controller_OnClick_CaseNumber_OpenNewTabJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onClick_CaseNumber$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_CaseNumber");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:_JMWnCyTYkG28Jk1Ct_a5w:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.LxdZC8roWE2IsdKzRPvPtg/ClientActions._JMWnCyTYkG28Jk1Ct_a5w:5Wga0PfU6Q2cIw8Ejfkqkg", "PHICore", "OnClick_CaseNumber", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zXlHNlH8dUGAIvJn4dRoCQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:FXWpZa9y0UurDW0Ku6x+lA", callContext.id);
controller.safeExecuteJSNode(PHICore_Common_Widgets_CaseNumber_mvc_controller_OnClick_CaseNumber_OpenNewTabJS, "OpenNewTab", "OnClick_CaseNumber", {
CaseId: OS.DataConversion.JSNodeParamConverter.to(model.variables.caseIdIn, OS.Types.LongInteger),
CaseActiveTab: OS.DataConversion.JSNodeParamConverter.to((model.variables.caseActiveTabIn).toString(), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:clSQeqUzM02ISCi8h5xpCw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:_JMWnCyTYkG28Jk1Ct_a5w", callContext.id);
}

};

Controller.prototype.onClick_CaseNumber$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_CaseNumber$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA:PaO6Is3JzvZHxKWiT9km_g", "PHICore", "Common_Widgets", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:LxdZC8roWE2IsdKzRPvPtg:/NRWebFlows.XECLt_ePME2rSnqw4xSdLA/NodesShownInESpaceTree.LxdZC8roWE2IsdKzRPvPtg:OgBFvWjoSltXZQ7HbmyZqg", "PHICore", "CaseNumber", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:LxdZC8roWE2IsdKzRPvPtg", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:XECLt_ePME2rSnqw4xSdLA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});
define("PHICore.Common_Widgets.CaseNumber.mvc$controller.OnClick_CaseNumber.OpenNewTabJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.open('\CaseSummary?CaseActiveTab='+$parameters.CaseActiveTab+'&CaseId='+$parameters.CaseId,'_blank')
};
});

define("PHICore.Common_Widgets.CaseNumber.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"FXWpZa9y0UurDW0Ku6x+lA": {
getter: function (varBag, idService) {
return varBag.openNewTabJSResult.value;
}
},
"4UqC3rQMJUu8xh7ml7EimQ": {
getter: function (varBag, idService) {
return varBag.model.variables.caseIdIn;
},
dataType: OS.Types.LongInteger
},
"aqHIPCWarkqsxDcnPGC+Zg": {
getter: function (varBag, idService) {
return varBag.model.variables.caseNumberIn;
},
dataType: OS.Types.Text
},
"Cqw50z6fNE6+cgJU3mtclA": {
getter: function (varBag, idService) {
return varBag.model.variables.isRestrictedIn;
},
dataType: OS.Types.Boolean
},
"muOqzwz8aEKbIbZjLuOUGg": {
getter: function (varBag, idService) {
return varBag.model.variables.caseActiveTabIn;
},
dataType: OS.Types.Integer
},
"Wn7JdrYmBUKVBaH7cIrhNg": {
getter: function (varBag, idService) {
return varBag.model.variables.isReactivateMemberIn;
},
dataType: OS.Types.Boolean
},
"JgfggpcOc0itaDSgtkWElA": {
getter: function (varBag, idService) {
return varBag.model.variables.caseStatusPurposeIdIn;
},
dataType: OS.Types.Integer
},
"2nCPTWIuxEGv3jwVM7FpBQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("IsCaseRestricted"));
})(varBag.model, idService);
}
},
"5akGDglO8U6m5W5sQ8kUBw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewRestrctCasepermission"));
})(varBag.model, idService);
}
},
"HtGeTb2CP0qsq6fXGh0NUQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewCases"));
})(varBag.model, idService);
}
},
"cdPSMeEdz0i5JJzjBSMy5A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Blank2"));
})(varBag.model, idService);
}
},
"5S9VE13X3UiwNMxE4FQq7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("HasViewCasePermission"));
})(varBag.model, idService);
}
},
"kbyp7qhunkGrme637CejRA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Blank"));
})(varBag.model, idService);
}
},
"+AhUmfF82U6ki6ID7g1sSw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PendingRebateParticipation"));
})(varBag.model, idService);
}
},
"ZbgPcOhmXE+4gtXsdRCyvA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("hasRebateExceptionManagement"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
