﻿define("Common_CW.PHICore_CW.NoItemsFound_Block.mvc$model", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "OutSystemsUI.Content.Card.mvc$model"], function (OutSystems, Common_CWModel, OutSystemsUI_Content_Card_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("HideBorder", "hideBorderIn", "HideBorder", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_hideBorderInDataFetchStatus", "_hideBorderInDataFetchStatus", "_hideBorderInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = OutSystemsUI_Content_Card_mvcModel.hasValidationWidgets;
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
if("HideBorder" in inputs) {
this.variables.hideBorderIn = inputs.HideBorder;
if("_hideBorderInDataFetchStatus" in inputs) {
this.variables._hideBorderInDataFetchStatus = inputs._hideBorderInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "PHICore_CW.NoItemsFound_Block");
});
define("Common_CW.PHICore_CW.NoItemsFound_Block.mvc$view", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$model", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$controller", "Common_CW.clientVariables", "OutSystemsUI.Content.Card.mvc$view", "OutSystems/ReactWidgets/Main"], function (OutSystems, Common_CWModel, Common_CWController, React, OSView, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_model, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_controller, Common_CWClientVariables, OutSystemsUI_Content_Card_mvc_view, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "PHICore_CW.NoItemsFound_Block";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Content_Card_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NoItemsFound_Block_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return Common_CW_PHICore_CW_NoItemsFound_Block_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OutSystemsUI_Content_Card_mvc_view, {
inputs: {
ExtendedClass: model.getCachedValue(idService.getId("nkfOuZw5MEqhhyg8oXwDmw.ExtendedClass"), function () {
return ("empty-state" + ((model.variables.hideBorderIn) ? (" border-none") : ("")));
}, function () {
return model.variables.hideBorderIn;
}),
_extendedClassInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._hideBorderInDataFetchStatus)
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.title_PlaceHolder,
style: "text-align-center font-size-h5",
_idProps: {
service: idService,
name: "Title_PlaceHolder"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.subtitle_Placeholder,
style: "text-align-center margin-top-base font-size-s",
_idProps: {
service: idService,
name: "Subtitle_Placeholder"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.nullPagination_Placeholder,
style: "text-align-center margin-top-base",
_idProps: {
service: idService,
name: "NullPagination_Placeholder"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-align-center margin-top-base",
visible: true,
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Image, {
extendedProperties: {
alt: "No Items"
},
image: OS.Navigation.VersionedURL.getVersionedUrl("img/Common_CW.BlankSlate_Image.png"),
type: /*Static*/ 0,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
}
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("Common_CW.PHICore_CW.NoItemsFound_Block.mvc$controller", ["OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.languageResources", "Common_CW.clientVariables", "Common_CW.PHICore_CW.NoItemsFound_Block.mvc$debugger"], function (OutSystems, Common_CWModel, Common_CWController, Common_CWLanguageResources, Common_CWClientVariables, Common_CW_PHICore_CW_NoItemsFound_Block_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg:w0av_ZVFAQeH1Jbi+Jl2sA", "Common_CW", "PHICore_CW", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:5kYfzKhAYk2hmbNM6fPVzQ:/NRWebFlows.H0iRLaC19UKOgC_EeXEdeg/NodesShownInESpaceTree.5kYfzKhAYk2hmbNM6fPVzQ:teEAkiJkSpipC4bKBCJe+A", "Common_CW", "NoItemsFound_Block", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:5kYfzKhAYk2hmbNM6fPVzQ", callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:H0iRLaC19UKOgC_EeXEdeg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, Common_CWLanguageResources);
});

define("Common_CW.PHICore_CW.NoItemsFound_Block.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"0TcH36mSSkq9cn0IlDNIyw": {
getter: function (varBag, idService) {
return varBag.model.variables.hideBorderIn;
},
dataType: OS.Types.Boolean
},
"4aG0sexbdkCCiZu7DlIO3A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"Q7Wfv70N90CgS+xiZ+Bhxg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title_PlaceHolder"));
})(varBag.model, idService);
}
},
"nY90GBbnrk+kQvqZtmRdCA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Subtitle_Placeholder"));
})(varBag.model, idService);
}
},
"d7_uAFFmgUe3stdciYIDBA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NullPagination_Placeholder"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
