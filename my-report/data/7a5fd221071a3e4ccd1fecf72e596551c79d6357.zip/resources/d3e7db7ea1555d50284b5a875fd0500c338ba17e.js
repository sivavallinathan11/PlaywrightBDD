﻿"use strict";
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        class AbstractGeneric {
            constructor(uniqueId, config) {
                this._uniqueId = uniqueId;
                this._config = config;
            }
            _setCommonHtmlElements() {
                this._selfElem = Charts.Helper.Dom.GetElementByUniqueId(this._uniqueId);
                this._widgetId = Charts.Helper.Dom.GetElementByUniqueId(this._uniqueId).closest(Charts.Constants.HtmlTag.block).id;
            }
            _unsetCommonHtmlElements() {
                this._selfElem = undefined;
            }
            finishBuild() {
                this._isBuilt = true;
            }
            build() {
                this._setCommonHtmlElements();
            }
            dispose() {
                this._unsetCommonHtmlElements();
                this._isBuilt = false;
            }
            equalsToID(elementId) {
                return elementId === this._uniqueId || elementId === this._widgetId;
            }
            updateConfigs(configs) {
                for (const key in configs) {
                    if (this._config[key] !== undefined) {
                        this._config[key] = configs[key];
                    }
                }
            }
            get config() {
                return this._config;
            }
            get isBuilt() {
                return this._isBuilt;
            }
            get selfElem() {
                return this._selfElem;
            }
            get uniqueId() {
                return this._uniqueId;
            }
            get widgetId() {
                return this._widgetId;
            }
        }
        Charts.AbstractGeneric = AbstractGeneric;
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        class AbstractChart extends OSFramework.Charts.AbstractGeneric {
            constructor(uniqueId, config) {
                super(uniqueId, config);
                this._chartInitializedEvent = new OSFramework.Charts.Event.ChartInitializedEvent();
                this._seriesEventClick = new OSFramework.Charts.Event.SeriesEventClick();
            }
            get chartInitializedEvent() {
                return this._chartInitializedEvent;
            }
            get series() {
                return this._series;
            }
            get isReady() {
                return this._isReady;
            }
            get version() {
                return this._version;
            }
            applyConfigs(finalConfigs) {
                this.applyChartConfigs(finalConfigs);
            }
            build() {
                super.build();
            }
            dispose() {
                super.dispose();
                this._isReady = false;
            }
            hideEmptyState() {
                this.removeEmptyState();
            }
            rebuildChart() {
                if (this.isBuilt && this.isReady) {
                    this.rebuildProviderChart();
                }
            }
            setChartEvent(eventName, callback) {
                switch (eventName) {
                    case Charts.Event.ChartEventType.Initialized:
                        this._chartInitializedEvent.addHandler(callback);
                        break;
                    case Charts.Event.SeriesType.Click:
                        this._seriesEventClick.addHandler(callback);
                        break;
                    default:
                        throw new Error(`The event '${eventName}' is not supported in a chart`);
                }
            }
            setData(data, isUpdatingStyling = false) {
                this.updateData(data, isUpdatingStyling);
            }
            showEmptyState() {
                this.renderEmptyState();
            }
            unsetChartEvent(eventName, callback) {
                switch (eventName) {
                    case Charts.Event.ChartEventType.Initialized:
                        this._chartInitializedEvent.removeHandler(callback);
                        break;
                    case Charts.Event.SeriesType.Click:
                        this._seriesEventClick.removeHandler(callback);
                        break;
                    default:
                        throw new Error(`The event '${eventName}' is not supported in a chart`);
                }
            }
            get seriesEventClick() {
                return this._seriesEventClick;
            }
        }
        Charts.AbstractChart = AbstractChart;
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        let AbstractChartFactory;
        (function (AbstractChartFactory) {
            function MakeAbstractChart(version, chartId, type, configs, provider) {
                switch (version) {
                    case Charts.Enum.OSChartVersion.Version1:
                        return Providers.Charts.HighCharts.Version1.Chart.Factory.MakeChart(chartId, type, configs);
                    case Charts.Enum.OSChartVersion.Version2:
                        return Charts.Version2.ChartFactory.MakeChart(chartId, type, configs, provider);
                    default:
                        throw new Error(`There is no factory for this Chart version (${version})`);
                }
            }
            AbstractChartFactory.MakeAbstractChart = MakeAbstractChart;
        })(AbstractChartFactory = Charts.AbstractChartFactory || (Charts.AbstractChartFactory = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        class AbstractConfig {
            constructor(config) {
                for (const key in config) {
                    if (config[key] !== undefined) {
                        this[key] = config[key];
                    }
                }
            }
        }
        Charts.AbstractConfig = AbstractConfig;
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Constants;
        (function (Constants) {
            Constants.Dot = '.';
            Constants.EnableLogMessages = false;
            Constants.HtmlAttribute = {
                name: 'name',
            };
            Constants.HtmlSelector = {
                chart: '.chart-container',
            };
            Constants.HtmlTag = {
                block: '[data-block]',
                chart: '[data-block*="Charts."]',
            };
            Constants.OSChartsVersion = '3.1.0';
        })(Constants = Charts.Constants || (Charts.Constants = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var ErrorCodes;
        (function (ErrorCodes) {
            ErrorCodes.Success = {
                code: '200',
                message: 'Success',
            };
            ErrorCodes.Features = {
                FailSetChartInfo: 'FEATURES-GEN-12001',
            };
        })(ErrorCodes = Charts.ErrorCodes || (Charts.ErrorCodes = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        class ExposedConfigs {
        }
        Charts.ExposedConfigs = ExposedConfigs;
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Enum;
        (function (Enum) {
            let ChartType;
            (function (ChartType) {
                ChartType["Area"] = "area";
                ChartType["AreaSpline"] = "areaspline";
                ChartType["Bar"] = "bar";
                ChartType["Column"] = "column";
                ChartType["Donut"] = "donut";
                ChartType["Line"] = "line";
                ChartType["Pie"] = "pie";
                ChartType["Radar"] = "radar";
                ChartType["Spline"] = "spline";
            })(ChartType = Enum.ChartType || (Enum.ChartType = {}));
        })(Enum = Charts.Enum || (Charts.Enum = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Enum;
        (function (Enum) {
            var Dom;
            (function (Dom) {
                let HtmlAttributes;
                (function (HtmlAttributes) {
                    HtmlAttributes["Name"] = "name";
                })(HtmlAttributes = Dom.HtmlAttributes || (Dom.HtmlAttributes = {}));
                let CSSClasses;
                (function (CSSClasses) {
                    CSSClasses["Container"] = "chart-container";
                    CSSClasses["Wrapper"] = "chart-wrapper";
                })(CSSClasses = Dom.CSSClasses || (Dom.CSSClasses = {}));
            })(Dom = Enum.Dom || (Enum.Dom = {}));
        })(Enum = Charts.Enum || (Charts.Enum = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Enum;
        (function (Enum) {
            let Messages;
            (function (Messages) {
                Messages["NoData"] = "No data to display";
            })(Messages = Enum.Messages || (Enum.Messages = {}));
            let OSChartVersion;
            (function (OSChartVersion) {
                OSChartVersion["Version1"] = "Version1";
                OSChartVersion["Version2"] = "Version2";
            })(OSChartVersion = Enum.OSChartVersion || (Enum.OSChartVersion = {}));
            let ProviderType;
            (function (ProviderType) {
                ProviderType["Highcharts"] = "Highcharts";
            })(ProviderType = Enum.ProviderType || (Enum.ProviderType = {}));
            let xAxisType;
            (function (xAxisType) {
                xAxisType["Category"] = "category";
                xAxisType["Decimal"] = "decimal";
                xAxisType["Datetime"] = "datetime";
                xAxisType["Linear"] = "linear";
                xAxisType["Logarithmic"] = "logarithmic";
            })(xAxisType = Enum.xAxisType || (Enum.xAxisType = {}));
        })(Enum = Charts.Enum || (Charts.Enum = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Enum;
        (function (Enum) {
            var Legend;
            (function (Legend) {
                let AlignValues;
                (function (AlignValues) {
                    AlignValues["Bottom"] = "bottom";
                    AlignValues["Center"] = "center";
                    AlignValues["Left"] = "left";
                    AlignValues["Middle"] = "middle";
                    AlignValues["Right"] = "right";
                    AlignValues["Top"] = "top";
                })(AlignValues = Legend.AlignValues || (Legend.AlignValues = {}));
                let Orientation;
                (function (Orientation) {
                    Orientation["Horizontal"] = "horizontal";
                    Orientation["Vertical"] = "vertical";
                })(Orientation = Legend.Orientation || (Legend.Orientation = {}));
                let Position;
                (function (Position) {
                    Position["Bottom"] = "Bottom";
                    Position["BottomLeft"] = "BottomLeft";
                    Position["BottomRight"] = "BottomRight";
                    Position["Center"] = "Center";
                    Position["Hidden"] = "Hidden";
                    Position["Inside"] = "Inside";
                    Position["Left"] = "Left";
                    Position["Right"] = "Right";
                    Position["Top"] = "Top";
                    Position["TopLeft"] = "TopLeft";
                    Position["TopRight"] = "TopRight";
                })(Position = Legend.Position || (Legend.Position = {}));
            })(Legend = Enum.Legend || (Enum.Legend = {}));
        })(Enum = Charts.Enum || (Charts.Enum = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class AbstractEvent {
                constructor() {
                    this._handlers = [];
                }
                addHandler(handler) {
                    this._handlers.push(handler);
                }
                hasHandlers() {
                    return this._handlers.length > 0;
                }
                removeHandler(handler) {
                    const index = this._handlers.findIndex((hd) => {
                        return hd === handler;
                    });
                    if (index !== -1) {
                        this._handlers.splice(index, 1);
                    }
                }
                trigger(data, ...args) {
                    this._handlers.slice(0).forEach((h) => h(data, ...args));
                }
                get handlers() {
                    return this._handlers;
                }
            }
            Event.AbstractEvent = AbstractEvent;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class AbstractEventsManager {
                constructor() {
                    this._handlers = new Map();
                }
                addHandler(eventType, handler) {
                    if (this._handlers.has(eventType)) {
                        this._handlers.get(eventType).addHandler(handler);
                    }
                    else {
                        const ev = this.getInstanceOfEventType(eventType);
                        ev.addHandler(handler);
                        this._handlers.set(eventType, ev);
                    }
                }
                hasHandlers(eventType) {
                    let returnValue = false;
                    if (this._handlers.has(eventType)) {
                        const event = this._handlers.get(eventType);
                        returnValue = event.hasHandlers();
                    }
                    return returnValue;
                }
                removeHandler(eventType, handler) {
                    if (this._handlers.has(eventType)) {
                        const event = this._handlers.get(eventType);
                        event.removeHandler(handler);
                    }
                }
                trigger(eventType, data, ...args) {
                    if (this._handlers.has(eventType)) {
                        this._handlers.get(eventType).trigger(data, ...args);
                    }
                }
                get handlers() {
                    return this._handlers;
                }
            }
            Event.AbstractEventsManager = AbstractEventsManager;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class ChartInitializedEvent extends Charts.Event.AbstractEvent {
            }
            Event.ChartInitializedEvent = ChartInitializedEvent;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            let ChartEventType;
            (function (ChartEventType) {
                ChartEventType["Initialized"] = "Initialized";
            })(ChartEventType = Event.ChartEventType || (Event.ChartEventType = {}));
            let SeriesType;
            (function (SeriesType) {
                SeriesType["Click"] = "Click";
            })(SeriesType = Event.SeriesType || (Event.SeriesType = {}));
            let Type;
            (function (Type) {
                Type["OrientationChange"] = "window.onorientationchange";
            })(Type = Event.Type || (Event.Type = {}));
            let Window;
            (function (Window) {
                Window["OrientationChange"] = "orientationchange";
            })(Window = Event.Window || (Event.Window = {}));
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class EventManager extends Charts.Event.AbstractEventsManager {
                getInstanceOfEventType(eventType) {
                    let eventInstance;
                    switch (eventType) {
                        case Event.Type.OrientationChange:
                            eventInstance = new Charts.Event.OrientationChange();
                            break;
                        default:
                            throw new Error(`The event ${eventType} is not supported.`);
                    }
                    return eventInstance;
                }
            }
            Event.EventManager = EventManager;
            class GlobalEventManager {
                static get Instance() {
                    return GlobalEventManager._eventManager;
                }
            }
            GlobalEventManager._eventManager = new EventManager();
            Event.GlobalEventManager = GlobalEventManager;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class OrientationChange extends Event.AbstractEvent {
                constructor() {
                    super();
                    window.addEventListener(Event.Window.OrientationChange, this._orientationTrigger.bind(this), true);
                }
                _orientationTrigger(evt) {
                    this.trigger(Event.Window.OrientationChange, evt);
                }
            }
            Event.OrientationChange = OrientationChange;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Event;
        (function (Event) {
            class SeriesEventClick extends Charts.Event.AbstractEvent {
            }
            Event.SeriesEventClick = SeriesEventClick;
        })(Event = Charts.Event || (Charts.Event = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Helper;
        (function (Helper) {
            class AttributeManipulation {
                static Get(element, attrName) {
                    if (element) {
                        const value = element.getAttribute(attrName);
                        return value ? value : undefined;
                    }
                    else {
                        throw Error(`The element does not exist, when trying to get the attribute '${attrName}'.`);
                    }
                }
            }
            class Dom {
                static GetClosestChartId(elem) {
                    let child;
                    if (typeof elem === 'string' || elem instanceof String)
                        child = this.GetElementByUniqueId(elem);
                    else
                        child = elem;
                    const domChart = child.closest(Charts.Constants.HtmlTag.chart);
                    if (domChart) {
                        const uniqueId = domChart
                            .querySelector(Charts.Constants.HtmlSelector.chart)
                            .getAttribute(Charts.Constants.HtmlAttribute.name);
                        return uniqueId;
                    }
                    return null;
                }
                static GetElementByUniqueId(uniqueId, raiseError = true) {
                    const obj = document.getElementsByName(uniqueId);
                    if (obj.length) {
                        return obj[0];
                    }
                    else if (raiseError) {
                        throw new Error(`Object with name '${uniqueId}' not found.`);
                    }
                    else {
                        return undefined;
                    }
                }
                static get Attribute() {
                    return AttributeManipulation;
                }
            }
            Helper.Dom = Dom;
        })(Helper = Charts.Helper || (Charts.Helper = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Helper;
        (function (Helper) {
            var Log;
            (function (Log) {
                Log.textMessage = {
                    apiMethodNotImplemented: 'This API has no implementation for this context.',
                    warning: 'This API is deprecated please use the new api',
                };
                function WarningMessage(message) {
                    console.warn(message);
                }
                Log.WarningMessage = WarningMessage;
            })(Log = Helper.Log || (Helper.Log = {}));
        })(Helper = Charts.Helper || (Charts.Helper = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Helper;
        (function (Helper) {
            var MapOperation;
            (function (MapOperation) {
                function ExportKeys(map) {
                    return [...map.keys()];
                }
                MapOperation.ExportKeys = ExportKeys;
            })(MapOperation = Helper.MapOperation || (Helper.MapOperation = {}));
        })(Helper = Charts.Helper || (Charts.Helper = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version1;
        (function (Version1) {
            class Chart extends Charts.AbstractChart {
                constructor(uniqueId, config) {
                    super(uniqueId, config);
                    this._version = Charts.Enum.OSChartVersion.Version1;
                }
                get chartFormat() {
                    return this._chartFormat;
                }
            }
            Version1.Chart = Chart;
        })(Version1 = Charts.Version1 || (Charts.Version1 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version1;
        (function (Version1) {
            var Enum;
            (function (Enum) {
                let StackingType;
                (function (StackingType) {
                    StackingType[StackingType["NoStacking"] = 1] = "NoStacking";
                    StackingType[StackingType["Stacked"] = 2] = "Stacked";
                    StackingType[StackingType["Stacked100Percent"] = 3] = "Stacked100Percent";
                })(StackingType = Enum.StackingType || (Enum.StackingType = {}));
                let xAxisValuesType;
                (function (xAxisValuesType) {
                    xAxisValuesType["Auto"] = "Auto";
                    xAxisValuesType["Text"] = "Text";
                })(xAxisValuesType = Enum.xAxisValuesType || (Enum.xAxisValuesType = {}));
            })(Enum = Version1.Enum || (Version1.Enum = {}));
        })(Version1 = Charts.Version1 || (Charts.Version1 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            class Chart extends Charts.AbstractChart {
                constructor(uniqueId, config) {
                    super(uniqueId, config);
                    this._addOnsFeatures = new Version2.Feature.AddOnsFeatures();
                    this._version = Charts.Enum.OSChartVersion.Version2;
                }
                _getDefaultLineWidth(chartType) {
                    let lineWidth;
                    switch (chartType) {
                        case Charts.Enum.ChartType.Area:
                        case Charts.Enum.ChartType.AreaSpline:
                        case Charts.Enum.ChartType.Line:
                        case Charts.Enum.ChartType.Spline:
                            lineWidth = 1;
                            break;
                        default:
                            lineWidth = 0;
                            break;
                    }
                    return lineWidth;
                }
                _updateAxis(AxisFeature, featureType, cleanAxis = false) {
                    const feature = AxisFeature;
                    if (cleanAxis) {
                        const axisIndex = this.config.providerConfigs.xAxis.findIndex((element) => element.id === feature.UniqueId) ||
                            this.config.providerConfigs.yAxis.findIndex((element) => element.id === feature.UniqueId);
                        if (featureType === Version2.Feature.Enum.FeatureType.xAxis) {
                            this.config.providerConfigs.xAxis.splice(axisIndex, 1);
                        }
                        else if (featureType === Version2.Feature.Enum.FeatureType.yAxis) {
                            this.config.providerConfigs.yAxis.splice(axisIndex, 1);
                        }
                    }
                    else {
                        let createAxis = false;
                        if ((featureType === Version2.Feature.Enum.FeatureType.xAxis &&
                            this.config.providerConfigs.xAxis &&
                            this.config.providerConfigs.xAxis.length > 0) ||
                            (featureType === Version2.Feature.Enum.FeatureType.yAxis &&
                                this.config.providerConfigs.yAxis &&
                                this.config.providerConfigs.yAxis.length > 0)) {
                            let axis = this.config.providerConfigs.xAxis.find((element) => element.id === feature.UniqueId) ||
                                this.config.providerConfigs.yAxis.find((element) => element.id === feature.UniqueId);
                            if (axis === undefined &&
                                featureType === Version2.Feature.Enum.FeatureType.xAxis &&
                                this.config.providerConfigs.xAxis.length === 1 &&
                                this.config.providerConfigs.xAxis[0].id === undefined) {
                                axis = this.config.providerConfigs.xAxis[0];
                            }
                            else if (axis === undefined &&
                                featureType === Version2.Feature.Enum.FeatureType.yAxis &&
                                this.config.providerConfigs.yAxis.length === 1 &&
                                this.config.providerConfigs.yAxis[0].id === undefined) {
                                axis = this.config.providerConfigs.yAxis[0];
                            }
                            if (axis) {
                                if (feature.ExtendedClass)
                                    axis.className = feature.ExtendedClass;
                                if (feature.Crosshair)
                                    axis.crosshair = feature.Crosshair;
                                axis.labels = {
                                    format: `${feature.ValuesPrefix}{text}${feature.ValuesSuffix}`,
                                    style: {},
                                };
                                if (feature.LabelColor)
                                    axis.labels.style.color = feature.LabelColor;
                                if (feature.LabelSize)
                                    axis.labels.style.fontSize =
                                        feature.LabelSize === 0 ? null : feature.LabelSize.toString() + 'px';
                                if (feature.LabelRotation)
                                    axis.labels.rotation = feature.LabelRotation;
                                if (feature.GridLinesColor)
                                    axis.gridLineColor = feature.GridLinesColor;
                                if (feature.GridLinesWidth)
                                    axis.gridLineWidth = feature.GridLinesWidth.trim();
                                if (feature.LineColor)
                                    axis.lineColor = feature.LineColor;
                                if (feature.LineWidth)
                                    axis.lineWidth = parseInt(feature.LineWidth.trim());
                                if (feature.GridLineStep)
                                    axis.tickInterval = feature.GridLineStep === 0 ? null : feature.GridLineStep;
                                if (feature.Title)
                                    axis.title = {
                                        text: feature.Title,
                                    };
                                if (feature.ValuesType)
                                    axis.type = feature.ValuesType;
                                if (feature.MinValue)
                                    axis.min = feature.MinValue === 0 || !feature.Visible ? null : feature.MinValue;
                                if (feature.MaxValue)
                                    axis.max = feature.MaxValue === 0 || !feature.Visible ? null : feature.MaxValue;
                                axis.visible = feature.Visible;
                                axis.id = feature.UniqueId;
                                if (featureType === Version2.Feature.Enum.FeatureType.xAxis &&
                                    this.config.valuesType === OSFramework.Charts.Version2.Enum.ValuesType.Text) {
                                    axis.categories = this._categories;
                                }
                            }
                            else {
                                createAxis = true;
                            }
                        }
                        else {
                            createAxis = true;
                        }
                        if (createAxis) {
                            const config = {
                                categories: null,
                                className: feature.ExtendedClass,
                                crosshair: feature.Crosshair,
                                id: feature.UniqueId,
                                labels: {
                                    format: `${feature.ValuesPrefix}{text}${feature.ValuesSuffix}`,
                                    style: {
                                        color: feature.LabelColor,
                                        fontSize: feature.LabelSize === 0 ? null : feature.LabelSize.toString() + 'px',
                                    },
                                    rotation: feature.LabelRotation,
                                },
                                gridLineColor: feature.GridLinesColor,
                                gridLineWidth: feature.GridLinesWidth.trim(),
                                lineColor: feature.LineColor,
                                lineWidth: parseInt(feature.LineWidth.trim()),
                                tickInterval: feature.GridLineStep === 0 ? null : feature.GridLineStep,
                                title: {
                                    text: feature.Title,
                                },
                                type: feature.ValuesType,
                                min: feature.MinValue === 0 || !feature.Visible ? null : feature.MinValue,
                                max: feature.MaxValue === 0 || !feature.Visible ? null : feature.MaxValue,
                                visible: feature.Visible,
                            };
                            if (featureType === Version2.Feature.Enum.FeatureType.xAxis) {
                                if (this.config.valuesType === OSFramework.Charts.Version2.Enum.ValuesType.Text) {
                                    config.categories = this._categories;
                                }
                                this.config.providerConfigs.xAxis.push(config);
                            }
                            else if (featureType === Version2.Feature.Enum.FeatureType.yAxis) {
                                this.config.providerConfigs.yAxis.push(config);
                            }
                            createAxis = false;
                        }
                    }
                }
                _updateConfigsAndRedraw(featureItem, featureType) {
                    let isUpdatingAxis = false;
                    if (featureType === Version2.Feature.Enum.FeatureType.seriesStyling) {
                        const SerieStylingFeature = featureItem.config;
                        if (SerieStylingFeature.Binding === '') {
                            this.config.providerConfigs[featureType] = featureItem.config.setFeatureProviderConfigs();
                        }
                        else {
                            this._updateSeries(SerieStylingFeature);
                            if (this._isReady) {
                                this.setData(this._series, true);
                            }
                        }
                    }
                    else if (featureType === Version2.Feature.Enum.FeatureType.xAxis ||
                        featureType === Version2.Feature.Enum.FeatureType.yAxis) {
                        const AxisFeature = featureItem.config;
                        this._updateAxis(AxisFeature, featureType);
                        isUpdatingAxis = true;
                    }
                    else {
                        this.config.providerConfigs[featureType] = featureItem.config.setFeatureProviderConfigs();
                    }
                    if (this._provider !== undefined &&
                        isUpdatingAxis &&
                        this.config.providerConfigs[featureType].length === 1) {
                        this.updateProviderFirstAxisOfType(featureType, this.config.providerConfigs[featureType][0]);
                    }
                    else if (this._isReady) {
                        this.build();
                    }
                }
                _updateSeries(SerieStylingFeature, cleanStyling = false) {
                    const feature = SerieStylingFeature;
                    if (this.config.providerConfigs.series.length > 0) {
                        const serie = this.config.providerConfigs.series.find((element) => element.name === feature.Binding);
                        if (serie) {
                            if (cleanStyling) {
                                const type = this.config.chart.type;
                                if (feature.LineColor) {
                                    serie.borderColor = '';
                                    serie.lineColor = undefined;
                                }
                                if (feature.LineWidth) {
                                    serie.borderWidth = 0;
                                    serie.lineWidth = this._getDefaultLineWidth(type);
                                }
                                if (feature.ExtendedClass)
                                    serie.className = '';
                                if (feature.FillColor)
                                    serie.color = '';
                                if (feature.ShowDataPointValues)
                                    serie.dataLabels.enabled = false;
                                if (feature.MarkerHideMarker)
                                    serie.marker.enabled = true;
                                if (feature.MarkerFillColor)
                                    serie.marker.fillColor = '';
                                if (feature.MarkerBorderColor)
                                    serie.marker.lineColor = '#ffffff';
                                if (feature.MarkerBorderWidth)
                                    serie.marker.lineWidth = 0;
                                if (feature.MarkerSymbol)
                                    serie.marker.symbol = undefined;
                                if (feature.MarkerRadius)
                                    serie.marker.radius = 4;
                                if (feature.Opacity)
                                    serie.opacity = 1;
                                if (feature.ShowInLegend === false)
                                    serie.showInLegend = true;
                                if (feature.Type)
                                    serie.type = '';
                            }
                            else {
                                if (feature.LineColor)
                                    serie.borderColor = feature.LineColor;
                                if (feature.ExtendedClass)
                                    serie.className = feature.ExtendedClass;
                                if (feature.FillColor)
                                    serie.color = feature.FillColor;
                                serie.dataLabels = {
                                    enabled: feature.ShowDataPointValues,
                                };
                                if (feature.LineColor)
                                    serie.lineColor = feature.LineColor;
                                if (feature.LineWidth.trim() !== '') {
                                    serie.lineWidth = feature.LineWidth.trim();
                                    serie.borderWidth = parseInt(feature.LineWidth.trim());
                                }
                                serie.marker = {
                                    enabled: feature.MarkerHideMarker === false,
                                };
                                if (feature.MarkerFillColor)
                                    serie.marker.fillColor = feature.MarkerFillColor;
                                if (feature.MarkerBorderColor)
                                    serie.marker.lineColor = feature.MarkerBorderColor;
                                if (feature.MarkerBorderWidth.trim() !== '')
                                    serie.marker.lineWidth = parseInt(feature.MarkerBorderWidth.trim());
                                if (feature.MarkerSymbol)
                                    serie.marker.symbol = feature.MarkerSymbol;
                                if (feature.MarkerRadius)
                                    serie.marker.radius = feature.MarkerRadius;
                                serie.showInLegend = feature.ShowInLegend;
                                if (feature.Type)
                                    serie.type = feature.Type;
                                if (feature.Opacity.trim() !== '') {
                                    serie.opacity = parseFloat(feature.Opacity.trim());
                                }
                            }
                        }
                    }
                    else {
                        const config = {
                            borderColor: feature.LineColor,
                            className: feature.ExtendedClass,
                            color: feature.FillColor,
                            dataLabels: {
                                enabled: feature.ShowDataPointValues,
                            },
                            marker: {
                                enabled: feature.MarkerHideMarker === false,
                                fillColor: feature.MarkerFillColor,
                                lineColor: feature.MarkerBorderColor,
                                radius: feature.MarkerRadius,
                                symbol: feature.MarkerSymbol,
                            },
                            lineColor: feature.LineColor,
                            showInLegend: feature.ShowInLegend,
                            type: feature.Type,
                        };
                        if (feature.Opacity.trim() !== '') {
                            config['opacity'] = parseFloat(feature.Opacity.trim());
                        }
                        if (feature.MarkerBorderWidth.trim() !== '')
                            config['marker']['lineWidth'] = parseInt(feature.MarkerBorderWidth.trim());
                        if (feature.LineWidth.trim() !== '') {
                            config['lineWidth'] = feature.LineWidth.trim();
                            config['borderWidth'] = parseInt(feature.LineWidth.trim());
                        }
                        this.config.providerConfigs.series[feature.Binding] = config;
                    }
                }
                setFeature(featureItem, featureType) {
                    if (featureType === Version2.Feature.Enum.FeatureType.seriesStyling ||
                        featureType === Version2.Feature.Enum.FeatureType.xAxis ||
                        featureType === Version2.Feature.Enum.FeatureType.yAxis) {
                        if (this._addOnsFeatures[featureType]) {
                            this._addOnsFeatures[featureType].push(featureItem);
                        }
                        else {
                            this._addOnsFeatures[featureType] = [featureItem];
                        }
                    }
                    else {
                        this._addOnsFeatures[featureType] = featureItem;
                    }
                    this._updateConfigsAndRedraw(featureItem, featureType);
                }
                unsetFeature(featureItem, featureType) {
                    if (featureType === Version2.Feature.Enum.FeatureType.seriesStyling) {
                        const SeriesStylingConfigs = featureItem.config;
                        if (SeriesStylingConfigs.Binding === '') {
                            this._addOnsFeatures[featureType] = null;
                            this.config.providerConfigs[featureType] = null;
                        }
                        else {
                            const index = this._addOnsFeatures[featureType].indexOf(featureItem);
                            this._addOnsFeatures[featureType].splice(index, 1);
                            this._updateSeries(SeriesStylingConfigs, true);
                            this.setData(this._series, true);
                        }
                    }
                    else if (featureType === Version2.Feature.Enum.FeatureType.xAxis ||
                        featureType === Version2.Feature.Enum.FeatureType.yAxis) {
                        const index = this._addOnsFeatures[featureType].indexOf(featureItem);
                        this._addOnsFeatures[featureType].splice(index, 1);
                        if ((featureType === Version2.Feature.Enum.FeatureType.xAxis &&
                            this.config.providerConfigs.xAxis.length === 1) ||
                            (featureType === Version2.Feature.Enum.FeatureType.yAxis && this.config.providerConfigs.yAxis.length === 1)) {
                            this.config.providerConfigs[featureType][0] = null;
                        }
                        else {
                            const AxisConfigs = featureItem.config;
                            this._updateAxis(AxisConfigs, featureType, true);
                        }
                    }
                    else {
                        this._addOnsFeatures[featureType] = null;
                        this.config.providerConfigs[featureType] = null;
                    }
                    this.build();
                }
                updateFeature(featureItem, featureType) {
                    this._updateConfigsAndRedraw(featureItem, featureType);
                }
                beNotifiedByFeature(featureItem, featureType, actionType) {
                    switch (actionType) {
                        case Version2.Feature.Enum.ActionType.AddFeature:
                            this.setFeature(featureItem, featureType);
                            break;
                        case Version2.Feature.Enum.ActionType.RemoveFeature:
                            this.unsetFeature(featureItem, featureType);
                            break;
                        case Version2.Feature.Enum.ActionType.UpdateFeature:
                            this.updateFeature(featureItem, featureType);
                    }
                }
                customizeChartObject(advanceConfigs) {
                    this.directUpdateProviderChart(advanceConfigs);
                }
                updateChartConfig(finalConfigs) {
                    this.updateProviderChart(finalConfigs);
                }
                updateColorScheme(colorSchemePalette) {
                    this.updateProviderColorScheme(colorSchemePalette);
                }
                updateSerieConfig(finalConfigs, serieBinding) {
                    this.updateProviderSerie(finalConfigs, serieBinding);
                }
                updateXAxis(finalConfigs, xAxisId) {
                    this.updateProviderXAxis(finalConfigs, xAxisId);
                }
                updateYAxis(finalConfigs, yAxisId) {
                    this.updateProviderYAxis(finalConfigs, yAxisId);
                }
                get features() {
                    return this._addOnsFeatures;
                }
            }
            Version2.Chart = Chart;
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            let ChartFactory;
            (function (ChartFactory) {
                function MakeChart(chartId, type, configs, provider) {
                    if (provider === Charts.Enum.ProviderType.Highcharts) {
                        return Providers.Charts.HighCharts.Version2.Chart.Factory.MakeChart(chartId, type, configs);
                    }
                    else {
                        throw new Error(`There is no factory for a Chart using the provider ${provider}`);
                    }
                }
                ChartFactory.MakeChart = MakeChart;
            })(ChartFactory = Version2.ChartFactory || (Version2.ChartFactory = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Enum;
            (function (Enum) {
                let AxisType;
                (function (AxisType) {
                    AxisType["X"] = "X";
                    AxisType["Y"] = "Y";
                    AxisType["Z"] = "Z";
                })(AxisType = Enum.AxisType || (Enum.AxisType = {}));
                let LegendLayout;
                (function (LegendLayout) {
                    LegendLayout["Horizontal"] = "horizontal";
                    LegendLayout["Proximate"] = "proximate";
                    LegendLayout["Vertical"] = "vertical";
                })(LegendLayout = Enum.LegendLayout || (Enum.LegendLayout = {}));
                let StackingType;
                (function (StackingType) {
                    StackingType["NoStacking"] = "NoStacking";
                    StackingType["Stacked"] = "Stacked";
                    StackingType["Stacked100Percent"] = "Stacked100Percent";
                })(StackingType = Enum.StackingType || (Enum.StackingType = {}));
                let ValuesType;
                (function (ValuesType) {
                    ValuesType["Datetime"] = "datetime";
                    ValuesType["Decimal"] = "decimal";
                    ValuesType["Integer"] = "integer";
                    ValuesType["Text"] = "text";
                })(ValuesType = Enum.ValuesType || (Enum.ValuesType = {}));
            })(Enum = Version2.Enum || (Version2.Enum = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                class AbstractFeature extends Charts.AbstractGeneric {
                    constructor(uniqueId, config, type) {
                        super(uniqueId, config);
                        this._featureType = type;
                    }
                    notifyChart(actionType) {
                        this._chart.beNotifiedByFeature(this, this._featureType, actionType);
                    }
                    setChartInfo() {
                        try {
                            const parentChart = this.selfElem.closest(OSFramework.Charts.Constants.Dot + OSFramework.Charts.Enum.Dom.CSSClasses.Wrapper);
                            this._chartId = OSFramework.Charts.Helper.Dom.Attribute.Get(parentChart.querySelector(OSFramework.Charts.Constants.Dot + OSFramework.Charts.Enum.Dom.CSSClasses.Container), Charts.Enum.Dom.HtmlAttributes.Name);
                            this._chart = OutSystems.ChartAPI.ChartManager.GetChartById(this._chartId);
                        }
                        catch (e) {
                            throw new Error(`${OSFramework.Charts.ErrorCodes.Features.FailSetChartInfo}: Parent of Child with Id: '${this.widgetId}' was not found!. Make sure you use this Feature block inside the Chart Addons Placeholder.`);
                        }
                    }
                    unsetChartInfo() {
                        this._chart = undefined;
                        this._chartId = undefined;
                    }
                    build() {
                        super.build();
                        this.setChartInfo();
                        this.notifyChart(Feature.Enum.ActionType.AddFeature);
                    }
                    dispose() {
                        this.notifyChart(Feature.Enum.ActionType.RemoveFeature);
                        this.unsetChartInfo();
                        super.dispose();
                    }
                    updateConfigs(configs) {
                        super.updateConfigs(configs);
                        this.notifyChart(Feature.Enum.ActionType.UpdateFeature);
                    }
                    get chart() {
                        return this._chart;
                    }
                    get chartId() {
                        return this._chartId;
                    }
                }
                Feature.AbstractFeature = AbstractFeature;
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                class AbstractFeatureConfigs extends Charts.AbstractConfig {
                    updateFeatureProviderConfigs(configs) {
                        for (const key in configs) {
                            if (configs[key] === undefined) {
                                delete configs[key];
                            }
                        }
                        this._featureProviderConfigs = configs;
                        return configs;
                    }
                    get featureProviderConfigs() {
                        return this._featureProviderConfigs;
                    }
                }
                Feature.AbstractFeatureConfigs = AbstractFeatureConfigs;
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                class AddOnsFeatures {
                }
                Feature.AddOnsFeatures = AddOnsFeatures;
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Enum;
                (function (Enum) {
                    let ActionType;
                    (function (ActionType) {
                        ActionType["AddFeature"] = "AddFeature";
                        ActionType["RemoveFeature"] = "RemoveFeature";
                        ActionType["UpdateFeature"] = "UpdateFeature";
                    })(ActionType = Enum.ActionType || (Enum.ActionType = {}));
                    let FeatureType;
                    (function (FeatureType) {
                        FeatureType["export"] = "exporting";
                        FeatureType["legend"] = "legend";
                        FeatureType["seriesStyling"] = "seriesStyling";
                        FeatureType["xAxis"] = "xAxis";
                        FeatureType["yAxis"] = "yAxis";
                    })(FeatureType = Enum.FeatureType || (Enum.FeatureType = {}));
                })(Enum = Feature.Enum || (Feature.Enum = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                let FeatureFactory;
                (function (FeatureFactory) {
                    function Make(uniqueId, configs, type, provider) {
                        let featureInstance;
                        if (provider === Charts.Enum.ProviderType.Highcharts) {
                            switch (type) {
                                case Feature.Enum.FeatureType.export:
                                    featureInstance = new Providers.Charts.HighCharts.Version2.Feature.Export.HighChartsExport(uniqueId, configs);
                                    break;
                                case Feature.Enum.FeatureType.legend:
                                    featureInstance = new Providers.Charts.HighCharts.Version2.Feature.Legend.HighChartLegend(uniqueId, configs);
                                    break;
                                case Feature.Enum.FeatureType.seriesStyling:
                                    featureInstance =
                                        new Providers.Charts.HighCharts.Version2.Feature.Series.HighChartsSeriesStyling(uniqueId, configs);
                                    break;
                                case Feature.Enum.FeatureType.xAxis:
                                case Feature.Enum.FeatureType.yAxis:
                                    featureInstance = Providers.Charts.HighCharts.Version2.Feature.Axis.AxisFactory.MakeAxis(uniqueId, configs, type);
                                    break;
                                default:
                                    throw new Error(`There is no ${type} Feature for the ${provider} provider.`);
                            }
                            return featureInstance;
                        }
                        else {
                            throw new Error(`There is no factory to ${provider} provider.`);
                        }
                    }
                    FeatureFactory.Make = Make;
                })(FeatureFactory = Feature.FeatureFactory || (Feature.FeatureFactory = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Axis;
                (function (Axis) {
                    class AbstractAxis extends Feature.AbstractFeature {
                    }
                    Axis.AbstractAxis = AbstractAxis;
                })(Axis = Feature.Axis || (Feature.Axis = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Axis;
                (function (Axis) {
                    class AbstractAxisConfigs extends Feature.AbstractFeatureConfigs {
                    }
                    Axis.AbstractAxisConfigs = AbstractAxisConfigs;
                })(Axis = Feature.Axis || (Feature.Axis = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Export;
                (function (Export) {
                    class AbstractExport extends Charts.Version2.Feature.AbstractFeature {
                        constructor(uniqueId, config) {
                            super(uniqueId, config, Feature.Enum.FeatureType.export);
                        }
                    }
                    Export.AbstractExport = AbstractExport;
                })(Export = Feature.Export || (Feature.Export = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Export;
                (function (Export) {
                    class AbstractExportConfigs extends Feature.AbstractFeatureConfigs {
                    }
                    Export.AbstractExportConfigs = AbstractExportConfigs;
                })(Export = Feature.Export || (Feature.Export = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Legend;
                (function (Legend) {
                    class AbstractLegend extends Charts.Version2.Feature.AbstractFeature {
                        constructor(uniqueId, config) {
                            super(uniqueId, config, Feature.Enum.FeatureType.legend);
                        }
                    }
                    Legend.AbstractLegend = AbstractLegend;
                })(Legend = Feature.Legend || (Feature.Legend = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Legend;
                (function (Legend) {
                    class AbstractLegendConfigs extends Feature.AbstractFeatureConfigs {
                    }
                    Legend.AbstractLegendConfigs = AbstractLegendConfigs;
                })(Legend = Feature.Legend || (Feature.Legend = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Series;
                (function (Series) {
                    class AbstractSeriesStyling extends Charts.Version2.Feature.AbstractFeature {
                        constructor(uniqueId, config) {
                            super(uniqueId, config, Feature.Enum.FeatureType.seriesStyling);
                        }
                    }
                    Series.AbstractSeriesStyling = AbstractSeriesStyling;
                })(Series = Feature.Series || (Feature.Series = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OSFramework;
(function (OSFramework) {
    var Charts;
    (function (Charts) {
        var Version2;
        (function (Version2) {
            var Feature;
            (function (Feature) {
                var Series;
                (function (Series) {
                    class AbstractSeriesStylingConfigs extends Feature.AbstractFeatureConfigs {
                    }
                    Series.AbstractSeriesStylingConfigs = AbstractSeriesStylingConfigs;
                })(Series = Feature.Series || (Feature.Series = {}));
            })(Feature = Version2.Feature || (Version2.Feature = {}));
        })(Version2 = Charts.Version2 || (Charts.Version2 = {}));
    })(Charts = OSFramework.Charts || (OSFramework.Charts = {}));
})(OSFramework || (OSFramework = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var Advanced;
        (function (Advanced) {
            const _loadedModules = new Map();
            function AddScriptModule(moduleName, url) {
                if (_loadedModules.has(moduleName) === false) {
                    _loadedModules.set(moduleName, { isLoaded: false, fileUrl: url });
                }
            }
            Advanced.AddScriptModule = AddScriptModule;
            function LoadModules(platformRequire) {
                return new Promise((resolve, reject) => {
                    const arrPromisesToFulfill = [];
                    _loadedModules.forEach((module) => {
                        if (module.isLoaded === false) {
                            const promise = platformRequire(module.fileUrl);
                            arrPromisesToFulfill.push(promise);
                            module.isLoaded = true;
                        }
                    });
                    if (arrPromisesToFulfill.length > 0) {
                        const errorArr = [];
                        let numberSuccess = 0;
                        Promise.allSettled(arrPromisesToFulfill)
                            .then((results) => {
                            results.forEach((result) => {
                                if (result.status === 'fulfilled') {
                                    ++numberSuccess;
                                }
                                else {
                                    errorArr.push(result.reason.toString());
                                }
                            });
                        })
                            .finally(() => {
                            if (numberSuccess > 0) {
                                OutSystems.ChartAPI.ChartManager.ForceRebuildAll();
                            }
                            if (errorArr.length > 0) {
                                reject(JSON.stringify(errorArr));
                            }
                            else {
                                resolve(true);
                            }
                        });
                    }
                    else {
                        resolve(false);
                    }
                });
            }
            Advanced.LoadModules = LoadModules;
        })(Advanced = ChartAPI.Advanced || (ChartAPI.Advanced = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var AxisManager;
        (function (AxisManager) {
            const _axisMap = new Map();
            function CreateAxis(axisId, configs, type, provider) {
                if (_axisMap.has(axisId)) {
                    throw new Error(`There is already a ${type}Axis registered under id: ${axisId}`);
                }
                let axisType;
                switch (type) {
                    case OSFramework.Charts.Version2.Enum.AxisType.X:
                        axisType = OSFramework.Charts.Version2.Feature.Enum.FeatureType.xAxis;
                        break;
                    case OSFramework.Charts.Version2.Enum.AxisType.Y:
                        axisType = OSFramework.Charts.Version2.Feature.Enum.FeatureType.yAxis;
                        break;
                }
                const _axis = OSFramework.Charts.Version2.Feature.FeatureFactory.Make(axisId, JSON.parse(configs), axisType, provider);
                _axisMap.set(axisId, _axis);
                return _axis;
            }
            AxisManager.CreateAxis = CreateAxis;
            function GetAllAxis() {
                return OSFramework.Charts.Helper.MapOperation.ExportKeys(_axisMap);
            }
            AxisManager.GetAllAxis = GetAllAxis;
            function GetAxisById(axisId) {
                let axis;
                if (_axisMap.has(axisId)) {
                    axis = _axisMap.get(axisId);
                }
                else {
                    for (const p of _axisMap.values()) {
                        if (p.equalsToID(axisId)) {
                            axis = p;
                            break;
                        }
                    }
                }
                if (axis === undefined) {
                    throw new Error(`Axis id:${axisId} not found`);
                }
                return axis;
            }
            AxisManager.GetAxisById = GetAxisById;
            function InitializeAxis(axisId) {
                const _axis = GetAxisById(axisId);
                _axis.build();
                return _axis;
            }
            AxisManager.InitializeAxis = InitializeAxis;
            function Dispose(axisId) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const axis = GetAxisById(axisId);
                    axis.dispose();
                    _axisMap.delete(axis.uniqueId);
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Axis.FailDispose;
                }
                return JSON.stringify(responseObj);
            }
            AxisManager.Dispose = Dispose;
            function SetHighchartsAxisConfigs(xAxisId, configs) {
                const axis = GetAxisById(xAxisId);
                axis.updateAxisWithCustomConfigs(JSON.parse(configs));
            }
            AxisManager.SetHighchartsAxisConfigs = SetHighchartsAxisConfigs;
            function UpdateConfigs(axisId, configs) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const axis = GetAxisById(axisId);
                    axis.updateConfigs(JSON.parse(configs));
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Axis.FailUpdateConfigs;
                }
                return JSON.stringify(responseObj);
            }
            AxisManager.UpdateConfigs = UpdateConfigs;
        })(AxisManager = ChartAPI.AxisManager || (ChartAPI.AxisManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var ChartManager;
        (function (ChartManager) {
            var Events;
            (function (Events) {
                function Subscribe(chartId, eventName, callback) {
                    const chart = OutSystems.ChartAPI.ChartManager.GetChartById(chartId);
                    switch (eventName) {
                        case OSFramework.Charts.Event.SeriesType.Click:
                            chart.setChartEvent(OSFramework.Charts.Event.SeriesType.Click, callback);
                            break;
                        case OSFramework.Charts.Event.ChartEventType.Initialized:
                            chart.setChartEvent(OSFramework.Charts.Event.ChartEventType.Initialized, callback);
                            break;
                        default:
                            throw new Error(`The event '${eventName}' is not supported in a chart`);
                    }
                }
                Events.Subscribe = Subscribe;
                function Unsubscribe(chartId, eventName, callback) {
                    const chart = OutSystems.ChartAPI.ChartManager.GetChartById(chartId);
                    switch (eventName) {
                        case OSFramework.Charts.Event.SeriesType.Click:
                            chart.unsetChartEvent(OSFramework.Charts.Event.SeriesType.Click, callback);
                            break;
                        case OSFramework.Charts.Event.ChartEventType.Initialized:
                            chart.unsetChartEvent(OSFramework.Charts.Event.ChartEventType.Initialized, callback);
                            break;
                        default:
                            throw new Error(`The event '${eventName}' is not supported in a chart`);
                    }
                }
                Events.Unsubscribe = Unsubscribe;
            })(Events = ChartManager.Events || (ChartManager.Events = {}));
        })(ChartManager = ChartAPI.ChartManager || (ChartAPI.ChartManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var ChartManager;
        (function (ChartManager) {
            const charts = new Map();
            let activeChart = undefined;
            function CreateChart(chartId, type, configs, version, provider) {
                const _chart = OSFramework.Charts.AbstractChartFactory.MakeAbstractChart(version, chartId, type, JSON.parse(configs), provider);
                charts.set(chartId, _chart);
                activeChart = _chart;
                return _chart;
            }
            ChartManager.CreateChart = CreateChart;
            function ForceRebuildAll() {
                charts.forEach((chart) => {
                    chart.rebuildChart();
                });
            }
            ChartManager.ForceRebuildAll = ForceRebuildAll;
            function GetActiveChart() {
                return activeChart;
            }
            ChartManager.GetActiveChart = GetActiveChart;
            function GetChartById(chartId, raiseError = true) {
                let chart;
                if (charts.has(chartId)) {
                    chart = charts.get(chartId);
                }
                else {
                    for (const p of charts.values()) {
                        if (p.equalsToID(chartId)) {
                            chart = p;
                            break;
                        }
                    }
                }
                if (chart === undefined && raiseError) {
                    throw new Error(`Chart id:${chartId} not found`);
                }
                return chart;
            }
            ChartManager.GetChartById = GetChartById;
            function HideEmptyState(chartId) {
                const chart = GetChartById(chartId);
                if (chart !== undefined) {
                    chart.hideEmptyState();
                }
            }
            ChartManager.HideEmptyState = HideEmptyState;
            function RemoveChart(chartId) {
                const chart = GetChartById(chartId);
                if (chart !== undefined) {
                    charts.delete(chart.uniqueId);
                    if (activeChart.uniqueId === chart.uniqueId) {
                        activeChart = Array.from(charts.values()).pop();
                    }
                    chart.dispose();
                }
            }
            ChartManager.RemoveChart = RemoveChart;
            function SetChartData(chartId, data) {
                const chart = GetChartById(chartId);
                let output;
                if (chart !== undefined) {
                    if (data !== '' && data !== '{}') {
                        chart.setData(JSON.parse(data));
                    }
                    output = true;
                }
                return output;
            }
            ChartManager.SetChartData = SetChartData;
            function InitializeChart(chartId, data, xAxisType) {
                const chart = GetChartById(chartId);
                if ('xAxisType' in chart.config) {
                    chart.config.xAxisType = xAxisType;
                }
                chart.setData(JSON.parse(data));
                chart.build();
            }
            ChartManager.InitializeChart = InitializeChart;
            function SetHighchartsChartConfigs(chartId, configs) {
                const chart = GetChartById(chartId);
                chart.updateChartConfig(JSON.parse(configs));
            }
            ChartManager.SetHighchartsChartConfigs = SetHighchartsChartConfigs;
            function SetHighchartsSeriesConfigs(chartId, seriesId, configs) {
                const chart = GetChartById(chartId);
                chart.updateSerieConfig(JSON.parse(configs), seriesId);
            }
            ChartManager.SetHighchartsSeriesConfigs = SetHighchartsSeriesConfigs;
            function UpdateConfigs(chartId, configs, data) {
                const chart = GetChartById(chartId);
                chart.updateConfigs(JSON.parse(configs));
                chart.setData(JSON.parse(data));
                chart.build();
            }
            ChartManager.UpdateConfigs = UpdateConfigs;
            function UpdateColorScheme(chartId, colorSchemePalette) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const chart = GetChartById(chartId);
                    chart.updateColorScheme(colorSchemePalette);
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.ColorScheme.FailUpdateColors;
                }
                return JSON.stringify(responseObj);
            }
            ChartManager.UpdateColorScheme = UpdateColorScheme;
            function ShowEmptyState(chartId) {
                const chart = GetChartById(chartId);
                if (chart !== undefined) {
                    chart.showEmptyState();
                }
            }
            ChartManager.ShowEmptyState = ShowEmptyState;
        })(ChartManager = ChartAPI.ChartManager || (ChartAPI.ChartManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var ChartAPI;
(function (ChartAPI) {
    var ChartManager;
    (function (ChartManager) {
        function CreateChart(chartId, type, configs) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.CreateChart()'`);
            return OutSystems.ChartAPI.ChartManager.CreateChart(chartId, type, configs, OSFramework.Charts.Enum.OSChartVersion.Version1);
        }
        ChartManager.CreateChart = CreateChart;
        function GetChartById(chartId, raiseError = true) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.GetChartById()'`);
            return OutSystems.ChartAPI.ChartManager.GetChartById(chartId, raiseError);
        }
        ChartManager.GetChartById = GetChartById;
        function RemoveChart(chartId) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.RemoveChart()'`);
            return OutSystems.ChartAPI.ChartManager.RemoveChart(chartId);
        }
        ChartManager.RemoveChart = RemoveChart;
        function SetChartData(chartID, data) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.SetChartData()'`);
            return OutSystems.ChartAPI.ChartManager.SetChartData(chartID, data);
        }
        ChartManager.SetChartData = SetChartData;
        function InitializeChart(chartID, data, xAxisType) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.InitializeChart()'`);
            return OutSystems.ChartAPI.ChartManager.InitializeChart(chartID, data, xAxisType);
        }
        ChartManager.InitializeChart = InitializeChart;
        function UpdateConfigs(chartID, configs, data) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.UpdateConfigs()'`);
            return OutSystems.ChartAPI.ChartManager.UpdateConfigs(chartID, configs, data);
        }
        ChartManager.UpdateConfigs = UpdateConfigs;
        function ShowEmptyState(chartID) {
            OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.ShowEmptyState()'`);
            return OutSystems.ChartAPI.ChartManager.ShowEmptyState(chartID);
        }
        ChartManager.ShowEmptyState = ShowEmptyState;
    })(ChartManager = ChartAPI.ChartManager || (ChartAPI.ChartManager = {}));
})(ChartAPI || (ChartAPI = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var ErrorCodes;
        (function (ErrorCodes) {
            ErrorCodes.Success = {
                code: '200',
                message: 'Success',
            };
            ErrorCodes.Chart = {
                FailSubscribeEvent: 'CHART-API-01001',
                FailUnsubscribeEvent: 'CHART-API-01002',
            };
            ErrorCodes.Axis = {
                FailCreate: 'AXIS-API-12001',
                FailDispose: 'AXIS-API-12002',
                FailUpdateConfigs: 'AXIS-API-12002',
            };
            ErrorCodes.Export = {
                FailCreate: 'EXPORTING-API-14001',
                FailDispose: 'EXPORTING-API-14002',
                FailUpdateConfigs: 'EXPORTING-API-14002',
            };
            ErrorCodes.Legend = {
                FailCreate: 'LEGEND-API-13001',
                FailDispose: 'LEGEND-API-13002',
                FailUpdateConfigs: 'LEGEND-API-13002',
            };
            ErrorCodes.SeriesStyling = {
                FailCreate: 'SERIESSTYLING-API-14001',
                FailDispose: 'SERIESSTYLING-API-14002',
                FailUpdateConfigs: 'SERIESSTYLING-API-14002',
            };
            ErrorCodes.ColorScheme = {
                FailUpdateColors: 'COLORSSCHEME-API-15001',
            };
        })(ErrorCodes = ChartAPI.ErrorCodes || (ChartAPI.ErrorCodes = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var ExportManager;
        (function (ExportManager) {
            const _exportMap = new Map();
            function CreateExport(exportId, configs, provider) {
                if (_exportMap.has(exportId)) {
                    throw new Error(`There is already a Export registered under id: ${exportId}`);
                }
                const localExport = OSFramework.Charts.Version2.Feature.FeatureFactory.Make(exportId, JSON.parse(configs), OSFramework.Charts.Version2.Feature.Enum.FeatureType.export, provider);
                _exportMap.set(exportId, localExport);
                return localExport;
            }
            ExportManager.CreateExport = CreateExport;
            function Dispose(exportId) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const localExport = GetExportById(exportId);
                    localExport.dispose();
                    _exportMap.delete(localExport.uniqueId);
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Export.FailDispose;
                }
                return JSON.stringify(responseObj);
            }
            ExportManager.Dispose = Dispose;
            function GetAllExports() {
                return OSFramework.Charts.Helper.MapOperation.ExportKeys(_exportMap);
            }
            ExportManager.GetAllExports = GetAllExports;
            function GetExportById(exportId) {
                let localExport;
                if (_exportMap.has(exportId)) {
                    localExport = _exportMap.get(exportId);
                }
                else {
                    for (const p of _exportMap.values()) {
                        if (p.equalsToID(exportId)) {
                            localExport = p;
                            break;
                        }
                    }
                }
                if (localExport === undefined) {
                    throw new Error(`Export id:${exportId} not found`);
                }
                return localExport;
            }
            ExportManager.GetExportById = GetExportById;
            function InitializeExport(exportId) {
                const localExport = GetExportById(exportId);
                localExport.build();
                return localExport;
            }
            ExportManager.InitializeExport = InitializeExport;
            function UpdateConfigs(exportId, configs) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const localExport = GetExportById(exportId);
                    localExport.updateConfigs(JSON.parse(configs));
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Export.FailUpdateConfigs;
                }
                return JSON.stringify(responseObj);
            }
            ExportManager.UpdateConfigs = UpdateConfigs;
        })(ExportManager = ChartAPI.ExportManager || (ChartAPI.ExportManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        function GetVersion() {
            return OSFramework.Charts.Constants.OSChartsVersion;
        }
        ChartAPI.GetVersion = GetVersion;
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var LegendManager;
        (function (LegendManager) {
            const _legendMap = new Map();
            function CreateLegend(legendId, configs, provider) {
                if (_legendMap.has(legendId)) {
                    throw new Error(`There is already a legend with id: ${legendId}`);
                }
                const _legend = OSFramework.Charts.Version2.Feature.FeatureFactory.Make(legendId, JSON.parse(configs), OSFramework.Charts.Version2.Feature.Enum.FeatureType.legend, provider);
                _legendMap.set(legendId, _legend);
                return _legend;
            }
            LegendManager.CreateLegend = CreateLegend;
            function GetAllLegends() {
                return OSFramework.Charts.Helper.MapOperation.ExportKeys(_legendMap);
            }
            LegendManager.GetAllLegends = GetAllLegends;
            function GetLegendById(legendId) {
                let legend;
                if (_legendMap.has(legendId)) {
                    legend = _legendMap.get(legendId);
                }
                else {
                    for (const p of _legendMap.values()) {
                        if (p.equalsToID(legendId)) {
                            legend = p;
                            break;
                        }
                    }
                }
                if (legend === undefined) {
                    throw new Error(`Legend id:${legendId} not found`);
                }
                return legend;
            }
            LegendManager.GetLegendById = GetLegendById;
            function InitializeLegend(legendId) {
                const _legend = GetLegendById(legendId);
                _legend.build();
                return _legend;
            }
            LegendManager.InitializeLegend = InitializeLegend;
            function Dispose(legendId) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const _legend = GetLegendById(legendId);
                    _legend.dispose();
                    _legendMap.delete(_legend.uniqueId);
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Legend.FailDispose;
                }
                return JSON.stringify(responseObj);
            }
            LegendManager.Dispose = Dispose;
            function UpdateConfigs(legendId, configs) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const _legend = GetLegendById(legendId);
                    _legend.updateConfigs(JSON.parse(configs));
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.Legend.FailUpdateConfigs;
                }
                return JSON.stringify(responseObj);
            }
            LegendManager.UpdateConfigs = UpdateConfigs;
        })(LegendManager = ChartAPI.LegendManager || (ChartAPI.LegendManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var SeriesManager;
        (function (SeriesManager) {
            var Events;
            (function (Events) {
                function Subscribe(chartID, eventName, callback) {
                    OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.Events.Subscribe()'`);
                    OutSystems.ChartAPI.ChartManager.Events.Subscribe(chartID, eventName, callback);
                }
                Events.Subscribe = Subscribe;
                function Unsubscribe(chartID, eventName, callback) {
                    OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.Events.Subscribe()'`);
                    OutSystems.ChartAPI.ChartManager.Events.Unsubscribe(chartID, eventName, callback);
                }
                Events.Unsubscribe = Unsubscribe;
            })(Events = SeriesManager.Events || (SeriesManager.Events = {}));
        })(SeriesManager = ChartAPI.SeriesManager || (ChartAPI.SeriesManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var ChartAPI;
(function (ChartAPI) {
    var ChartManager;
    (function (ChartManager) {
        var Events;
        (function (Events) {
            function Subscribe(chartID, eventName, callback) {
                OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.SeriesManager.Events.Subscribe()'`);
                return OutSystems.ChartAPI.ChartManager.Events.Subscribe(chartID, eventName, callback);
            }
            Events.Subscribe = Subscribe;
            function Unsubscribe(chartID, eventName, callback) {
                OSFramework.Charts.Helper.Log.WarningMessage(`${OSFramework.Charts.Helper.Log.textMessage.warning} 'OutSystems.ChartAPI.ChartManager.Events.Unsubscribe()'`);
                return OutSystems.ChartAPI.ChartManager.Events.Unsubscribe(chartID, eventName, callback);
            }
            Events.Unsubscribe = Unsubscribe;
        })(Events = ChartManager.Events || (ChartManager.Events = {}));
    })(ChartManager = ChartAPI.ChartManager || (ChartAPI.ChartManager = {}));
})(ChartAPI || (ChartAPI = {}));
var OutSystems;
(function (OutSystems) {
    var ChartAPI;
    (function (ChartAPI) {
        var SeriesManager;
        (function (SeriesManager) {
            const _seriesStylingMap = new Map();
            function CreateSeriesStyling(seriesStylingId, configs, provider) {
                if (_seriesStylingMap.has(seriesStylingId)) {
                    throw new Error(`There is already a SerieStyling registered under id: ${seriesStylingId}`);
                }
                const _seriesStyling = OSFramework.Charts.Version2.Feature.FeatureFactory.Make(seriesStylingId, JSON.parse(configs), OSFramework.Charts.Version2.Feature.Enum.FeatureType.seriesStyling, provider);
                _seriesStylingMap.set(seriesStylingId, _seriesStyling);
                return _seriesStyling;
            }
            SeriesManager.CreateSeriesStyling = CreateSeriesStyling;
            function Dispose(seriesStylingId) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const serieStyling = GetSeriesStylingById(seriesStylingId);
                    serieStyling.dispose();
                    _seriesStylingMap.delete(serieStyling.uniqueId);
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.SeriesStyling.FailDispose;
                }
                return JSON.stringify(responseObj);
            }
            SeriesManager.Dispose = Dispose;
            function GetAllSeriesStylings() {
                return OSFramework.Charts.Helper.MapOperation.ExportKeys(_seriesStylingMap);
            }
            SeriesManager.GetAllSeriesStylings = GetAllSeriesStylings;
            function GetSeriesStylingById(seriesStylingId) {
                let serieStyling;
                if (_seriesStylingMap.has(seriesStylingId)) {
                    serieStyling = _seriesStylingMap.get(seriesStylingId);
                }
                else {
                    for (const p of _seriesStylingMap.values()) {
                        if (p.equalsToID(seriesStylingId)) {
                            serieStyling = p;
                            break;
                        }
                    }
                }
                if (serieStyling === undefined) {
                    throw new Error(`SerieStyling id:${seriesStylingId} not found`);
                }
                return serieStyling;
            }
            SeriesManager.GetSeriesStylingById = GetSeriesStylingById;
            function InitializeSeriesStyling(seriesStylingId) {
                const _seriesStyling = GetSeriesStylingById(seriesStylingId);
                _seriesStyling.build();
                return _seriesStyling;
            }
            SeriesManager.InitializeSeriesStyling = InitializeSeriesStyling;
            function UpdateConfigs(seriesStylingId, configs) {
                const responseObj = {
                    isSuccess: true,
                    message: ChartAPI.ErrorCodes.Success.message,
                    code: ChartAPI.ErrorCodes.Success.code,
                };
                try {
                    const serie = GetSeriesStylingById(seriesStylingId);
                    serie.updateConfigs(JSON.parse(configs));
                }
                catch (error) {
                    responseObj.isSuccess = false;
                    responseObj.message = error.message;
                    responseObj.code = ChartAPI.ErrorCodes.SeriesStyling.FailUpdateConfigs;
                }
                return JSON.stringify(responseObj);
            }
            SeriesManager.UpdateConfigs = UpdateConfigs;
        })(SeriesManager = ChartAPI.SeriesManager || (ChartAPI.SeriesManager = {}));
    })(ChartAPI = OutSystems.ChartAPI || (OutSystems.ChartAPI = {}));
})(OutSystems || (OutSystems = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                class HighChartsConfig extends OSFramework.Charts.AbstractConfig {
                    getProviderConfig() {
                        let providerOpts = {
                            chart: this._providerConfigs.chart,
                            colors: this._providerConfigs.colors,
                            credits: this._providerConfigs.credits,
                            exporting: this._providerConfigs.exporting,
                            legend: this._providerConfigs.legend,
                            loading: this._providerConfigs.loading,
                            plotOptions: this._providerConfigs.plotOptions,
                            series: this._providerConfigs.series,
                            title: this._providerConfigs.title,
                            tooltip: this._providerConfigs.tooltip,
                            xAxis: this._providerConfigs.xAxis,
                            yAxis: this._providerConfigs.yAxis,
                        };
                        for (const key in providerOpts) {
                            if (providerOpts[key] === undefined) {
                                delete providerOpts[key];
                            }
                        }
                        return providerOpts;
                    }
                    setSeries(series) {
                        this._providerConfigs.series = series;
                    }
                    get providerConfigs() {
                        return this._providerConfigs;
                    }
                }
                Configuration.HighChartsConfig = HighChartsConfig;
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Area {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.marker = new HighChartsStructure.Marker();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Area = Area;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Bar {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Bar = Bar;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Column {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Column = Column;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class DataItem {
                    }
                    HighChartsStructure.DataItem = DataItem;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class DataLabel {
                    }
                    HighChartsStructure.DataLabel = DataLabel;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Events {
                    }
                    HighChartsStructure.Events = Events;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Legend {
                    }
                    HighChartsStructure.Legend = Legend;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Line {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.marker = new HighChartsStructure.Marker();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Line = Line;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Marker {
                    }
                    HighChartsStructure.Marker = Marker;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Pie {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Pie = Pie;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class PlotOptionSeries {
                        constructor() {
                            this.dataLabels = new HighChartsStructure.DataLabel();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.PlotOptionSeries = PlotOptionSeries;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class PlotOption {
                        constructor() {
                            this.area = new HighChartsStructure.Area();
                            this.bar = new HighChartsStructure.Bar();
                            this.column = new HighChartsStructure.Column();
                            this.line = new HighChartsStructure.Line();
                            this.pie = new HighChartsStructure.Pie();
                            this.series = new HighChartsStructure.PlotOptionSeries();
                        }
                    }
                    HighChartsStructure.PlotOption = PlotOption;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class PointItem {
                        constructor() {
                            this.events = new HighChartsStructure.Events();
                        }
                    }
                    HighChartsStructure.PointItem = PointItem;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Serie {
                        constructor() {
                            this.data = new Array();
                            this.point = new HighChartsStructure.PointItem();
                        }
                    }
                    HighChartsStructure.Serie = Serie;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configuration;
            (function (Configuration) {
                var HighChartsStructure;
                (function (HighChartsStructure) {
                    class Tooltip {
                    }
                    HighChartsStructure.Tooltip = Tooltip;
                })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
            })(Configuration = HighCharts.Configuration || (HighCharts.Configuration = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class AbstractColorConfig {
                    constructor(chart) {
                        this.chart = chart;
                        this.seriesLength = this.chart.config.providerConfigs.series.length;
                    }
                    build() {
                        this.setColorConfig();
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this.chart.config.providerConfigs.colors = this.colorConfig;
                    }
                }
                Configs.AbstractColorConfig = AbstractColorConfig;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class AbstractFactoryBuilder {
                    constructor(chart) {
                        this._chart = chart;
                        this._configList = [];
                        this._configs = new OSFramework.Charts.ExposedConfigs();
                    }
                    _instanceOfIDisposable(object) {
                        return 'dispose' in object;
                    }
                    _makeItem(c, ...args) {
                        const o = new c(this._chart, ...args);
                        this._configList.push(o);
                        return o;
                    }
                    get configs() {
                        return this._configs;
                    }
                    build() {
                        this._configList.forEach((p) => p.build());
                    }
                    dispose() {
                        this._configList.forEach((p) => {
                            this._instanceOfIDisposable(p) && p.dispose();
                            p = undefined;
                        });
                    }
                }
                Configs.AbstractFactoryBuilder = AbstractFactoryBuilder;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Credits {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        this._options = {
                            enabled: false,
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.credits = { enabled: false };
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.Credits = Credits;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                function GetStacking(stakingType) {
                    let stacking;
                    switch (stakingType) {
                        case OSFramework.Charts.Version1.Enum.StackingType.Stacked100Percent:
                            stacking = 'percent';
                            break;
                        case OSFramework.Charts.Version1.Enum.StackingType.Stacked:
                            stacking = 'normal';
                            break;
                    }
                    return stacking;
                }
                Configs.GetStacking = GetStacking;
                class ColumnPlotOptions {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpStacking = GetStacking(this._chart.config.stackingTypeId);
                        const cursorType = 'pointer';
                        this._options = {
                            column: {
                                allowPointSelect: false,
                                animation: this._chart.config.chartFormat.UseAnimation,
                                cursor: cursorType,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                            series: {
                                stacking: tmpStacking,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.plotOptions = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.ColumnPlotOptions = ColumnPlotOptions;
                class BarPlotOptions {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpStacking = GetStacking(this._chart.config.stackingTypeId);
                        const cursorType = 'pointer';
                        this._options = {
                            bar: {
                                allowPointSelect: false,
                                animation: this._chart.config.chartFormat.UseAnimation,
                                cursor: cursorType,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                            series: {
                                stacking: tmpStacking,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.plotOptions = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.BarPlotOptions = BarPlotOptions;
                class LinePlotOptions {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpStacking = GetStacking(this._chart.config.stackingTypeId);
                        const cursorType = 'pointer';
                        this._options = {
                            line: {
                                allowPointSelect: false,
                                animation: this._chart.config.chartFormat.UseAnimation,
                                cursor: cursorType,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                            series: {
                                stacking: tmpStacking,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.plotOptions = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.LinePlotOptions = LinePlotOptions;
                class PiePlotOptions {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpStacking = GetStacking(this._chart.config.stackingTypeId);
                        const cursorType = 'pointer';
                        this._options = {
                            pie: {
                                allowPointSelect: true,
                                animation: this._chart.config.chartFormat.UseAnimation,
                                cursor: cursorType,
                                showInLegend: this._chart.config.legendPositionId !== OSFramework.Charts.Enum.Legend.Position.Hidden,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                                innerSize: this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut ? '50%' : 0,
                            },
                            series: {
                                stacking: tmpStacking,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.plotOptions = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.PiePlotOptions = PiePlotOptions;
                class AreaPlotOptions {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpStacking = GetStacking(this._chart.config.stackingTypeId);
                        const cursorType = 'pointer';
                        this._options = {
                            area: {
                                allowPointSelect: false,
                                animation: this._chart.config.chartFormat.UseAnimation,
                                cursor: cursorType,
                                dataLabels: {
                                    enabled: this._chart.config.stackingTypeId ===
                                        OSFramework.Charts.Version1.Enum.StackingType.NoStacking
                                        ? this._chart.config.chartFormat.ShowDataPointValues
                                        : false,
                                },
                            },
                            series: {
                                stacking: tmpStacking,
                                dataLabels: {
                                    enabled: this._chart.config.chartFormat.ShowDataPointValues,
                                },
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.plotOptions = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.AreaPlotOptions = AreaPlotOptions;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Title {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    get options() {
                        return this._options;
                    }
                    build() {
                        this._options = {
                            text: undefined,
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.title = this._options;
                    }
                }
                Configs.Title = Title;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Tooltip {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const seriesLength = this._chart.config.providerConfigs.series.length;
                        this._options = {
                            formatter() {
                                const tooltipContent = this.point['custom']
                                    ? this.point['custom']
                                    : (seriesLength > 1 ? this.series.name + ', ' : '') + this.x + ':  <b>' + this.y + '</b>';
                                return tooltipContent;
                            },
                        };
                        if ((this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Area ||
                            this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Line) &&
                            this._chart.config.xAxisType === OSFramework.Charts.Enum.xAxisType.Datetime) {
                            this._options.formatter = function () {
                                const date = new Date(this.x);
                                const dateText = date.getUTCFullYear() +
                                    '-' +
                                    (date.getUTCMonth() + 1 < 10 ? '0' : '') +
                                    (date.getUTCMonth() + 1) +
                                    '-' +
                                    (date.getUTCDate() < 10 ? '0' : '') +
                                    date.getUTCDate();
                                if (this.point) {
                                    return this.point['custom']
                                        ? this.point['custom']
                                        : (seriesLength > 1 ? this.series.name + ', ' : '') + dateText + ':  <b>' + this.y + '</b>';
                                }
                                else if (this.points) {
                                    return this.points.reduce(function (s, point) {
                                        return s + '<br/>' + point.series.name + ':  <b>' + point.y + '</b>';
                                    }, '<b>' + dateText + '</b>');
                                }
                            };
                        }
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.tooltip = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.Tooltip = Tooltip;
                class PieTooltip {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        this._options = {
                            formatter() {
                                const tooltipContent = this.point['custom']
                                    ? this.point['custom']
                                    : this.point.name + ': <b>' + this.y + '</b>';
                                return tooltipContent;
                            },
                        };
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.tooltip = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.PieTooltip = PieTooltip;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Xaxis {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    build() {
                        const tmpXAxisFormat = this._chart.config.xAxisFormat;
                        const tmpcategories = this._chart.config.getProviderConfig().xAxis.categories;
                        const tmpXAxisType = this._chart.config.xAxisType;
                        if (this._chart.config.OSVersion === OSFramework.Charts.Enum.OSChartVersion.Version2) {
                            this._options = {
                                visible: false,
                            };
                        }
                        else {
                            this._options = {
                                categories: tmpcategories,
                                type: tmpXAxisType || OSFramework.Charts.Enum.xAxisType.Linear,
                                min: parseInt(tmpXAxisFormat?.MinValue) || null,
                                max: parseInt(tmpXAxisFormat?.MaxValue) || null,
                                labels: {
                                    rotation: tmpXAxisFormat?.LabelsRotation ? tmpXAxisFormat?.LabelsRotation * -1 : 0,
                                },
                                title: {
                                    text: tmpXAxisFormat?.Title || '',
                                },
                                tickInterval: null,
                                tickWidth: 1,
                            };
                            if (this._options.labels.rotation === 0) {
                                delete this._options.labels.rotation;
                            }
                            if (this._chart.config.xAxisType === OSFramework.Charts.Enum.xAxisType.Datetime) {
                                delete this._options.categories;
                                const pointCount = Math.max(...this._chart.config.getProviderConfig().series.map((x) => x.data.length));
                                const dif = parseInt(this._chart.config.xAxisFormat.MaxValue) -
                                    parseInt(this._chart.config.xAxisFormat.MinValue);
                                this._options.tickInterval = Math.floor(dif / pointCount);
                            }
                            else if (this._chart.config.xAxisType === OSFramework.Charts.Enum.xAxisType.Decimal) {
                                delete this._options.categories;
                                this._options.type = OSFramework.Charts.Enum.xAxisType.Linear;
                            }
                            else if ((this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Bar ||
                                this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Column) &&
                                this._options.type === OSFramework.Charts.Enum.xAxisType.Linear) {
                                this._options.type = OSFramework.Charts.Enum.xAxisType.Category;
                            }
                        }
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.xAxis = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.Xaxis = Xaxis;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Yaxis {
                    constructor(chart) {
                        this._chart = chart;
                    }
                    _getYaxisInfo(stackingTypeId, ShowDataPointValues) {
                        const YAxis = new Charts.HighCharts.Version1.Configuration.HighChartsStructure.Yaxis();
                        switch (stackingTypeId) {
                            case OSFramework.Charts.Version1.Enum.StackingType.Stacked100Percent:
                            case OSFramework.Charts.Version1.Enum.StackingType.Stacked:
                                YAxis.reversedStacks = false;
                                YAxis.stackLabels.enabled = ShowDataPointValues;
                                break;
                            default:
                                YAxis.reversedStacks = true;
                                YAxis.stackLabels.enabled = false;
                        }
                        return YAxis;
                    }
                    build() {
                        const tmpYAxisFormat = this._chart.config.yAxisFormat;
                        const Yaxis = this._getYaxisInfo(this._chart.config.stackingTypeId, this._chart.config.chartFormat?.ShowDataPointValues);
                        if (this._chart.config.OSVersion === OSFramework.Charts.Enum.OSChartVersion.Version2) {
                            this._options = {
                                visible: false,
                            };
                        }
                        else {
                            this._options = {
                                allowDecimals: true,
                                title: {
                                    text: tmpYAxisFormat?.Title || '',
                                },
                                tickInterval: tmpYAxisFormat?.GridLineStep > -2147483647 ? tmpYAxisFormat.GridLineStep : null,
                                max: tmpYAxisFormat?.MaxValue > -2147483647 ? tmpYAxisFormat.MaxValue : null,
                                min: tmpYAxisFormat?.MinValue > -2147483647 ? tmpYAxisFormat.MinValue : null,
                                reversedStacks: Yaxis.reversedStacks,
                                stackLabels: {
                                    enabled: Yaxis.stackLabels.enabled,
                                },
                                labels: {
                                    formatter() {
                                        const formatedLabel = (tmpYAxisFormat?.ValuesPrefix !== '' ? tmpYAxisFormat?.ValuesPrefix + ' ' : '') +
                                            this.axis.defaultLabelFormatter.call(this) +
                                            tmpYAxisFormat?.ValuesSuffix;
                                        return formatedLabel;
                                    },
                                },
                            };
                        }
                        if (tmpYAxisFormat?.GridLineStep === 0) {
                            delete this.options.tickInterval;
                        }
                        if (tmpYAxisFormat?.MaxValue === 0) {
                            delete this.options.max;
                        }
                        if (tmpYAxisFormat?.MinValue === 0) {
                            delete this.options.min;
                        }
                        this.setProviderOptions();
                    }
                    setProviderOptions() {
                        this._chart.config.providerConfigs.yAxis = this._options;
                    }
                    get options() {
                        return this._options;
                    }
                }
                Configs.Yaxis = Yaxis;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Utils;
            (function (Utils) {
                function Merge(target, source) {
                    if (typeof target !== 'object') {
                        target = {};
                    }
                    for (const property in source) {
                        if (source.hasOwnProperty(property)) {
                            const sourceProperty = source[property];
                            if (typeof sourceProperty === 'object') {
                                target[property] = Merge(target[property], sourceProperty);
                            }
                            else {
                                target[property] = sourceProperty;
                            }
                        }
                    }
                    for (let k = 2, l = arguments.length; k < l; k++) {
                        Merge(target, arguments[k]);
                    }
                    let isArray;
                    let length = 0;
                    for (const property in target) {
                        if (parseInt(property) === 0) {
                            isArray = true;
                        }
                        length++;
                    }
                    if (isArray) {
                        target['length'] = length;
                        target = Array.prototype.slice.call(target);
                    }
                    return target;
                }
                Utils.Merge = Merge;
            })(Utils = HighCharts.Utils || (HighCharts.Utils = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class AbstractHighCharts extends OSFramework.Charts.Version1.Chart {
                        get stackingType() {
                            return this._stackingType;
                        }
                        get xAxisFormat() {
                            return this._xAxisFormat;
                        }
                        get yAxisFormat() {
                            return this._yAxisFormat;
                        }
                        get legendPosition() {
                            return this._legendPositionId;
                        }
                    }
                    Chart.AbstractHighCharts = AbstractHighCharts;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class AbstractProviderChart extends Chart.AbstractHighCharts {
                        constructor(chartID, configs) {
                            super(chartID, new Charts.HighCharts.Version1.Configuration.HighChartsConfig(configs));
                            this._isReady = false;
                        }
                        _getTickPositions(definedMin, definedMax, runtimeTickPositions, runtimeTickInterval, runtimeMin, runtimeMax) {
                            const tickPositions = [];
                            const tmpMax = definedMax ? Math.round(definedMax) : runtimeMax;
                            const tmpMin = definedMin ? Math.round(definedMin) : runtimeMin;
                            const tmpTickInterval = (tmpMax - tmpMin) / (runtimeTickPositions.length - 1);
                            if (definedMin && definedMax) {
                                tickPositions.push(definedMin);
                                for (let i = 1; i < runtimeTickPositions.length; i++) {
                                    if (i === runtimeTickPositions.length - 1) {
                                        tickPositions.push(definedMax);
                                    }
                                    else if (tickPositions[i - 1] + runtimeTickInterval <
                                        definedMax) {
                                        tickPositions.push(tickPositions[i - 1] + tmpTickInterval);
                                    }
                                    else if (runtimeTickPositions[i] <= definedMax) {
                                        tickPositions.push(definedMax);
                                        break;
                                    }
                                }
                            }
                            else {
                                if (definedMin) {
                                    tickPositions.push(definedMin);
                                    for (let i = 1; i < runtimeTickPositions.length; i++) {
                                        tickPositions.push(tickPositions[i - 1] + tmpTickInterval);
                                    }
                                }
                                else {
                                    tickPositions.push(runtimeTickPositions[0]);
                                    for (let i = 1; i < runtimeTickPositions.length; i++) {
                                        if (i !== runtimeTickPositions.length - 1) {
                                            tickPositions.push(tickPositions[i - 1] + tmpTickInterval);
                                        }
                                        else {
                                            tickPositions.push(definedMax);
                                        }
                                    }
                                }
                            }
                            return tickPositions;
                        }
                        _mergeAdvanceFormats(advancedFormat_JSON) {
                            let source = this.config.getProviderConfig();
                            if (advancedFormat_JSON.HighchartsJSON === '' &&
                                advancedFormat_JSON.XAxisJSON === '' &&
                                advancedFormat_JSON.YAxisJSON === '' &&
                                advancedFormat_JSON.DataPointFormatsJSON === '[]' &&
                                advancedFormat_JSON.DataSeriesFormatsJSON === '[]') {
                                return source;
                            }
                            if (advancedFormat_JSON.XAxisJSON !== '') {
                                source = Chart.MergeXaxis(advancedFormat_JSON.XAxisJSON, source);
                            }
                            if (advancedFormat_JSON.YAxisJSON !== '') {
                                source = Chart.MergeYaxis(advancedFormat_JSON.YAxisJSON, source);
                            }
                            if (advancedFormat_JSON.DataPointFormatsJSON !== '[]') {
                                const dataPointFormat = JSON.parse(advancedFormat_JSON.DataPointFormatsJSON);
                                const chartType = source.chart.type;
                                source = Chart.MergeDataPoints(dataPointFormat, source, chartType);
                            }
                            if (advancedFormat_JSON.DataSeriesFormatsJSON !== '[]') {
                                const dataSeriesFormat = JSON.parse(advancedFormat_JSON.DataSeriesFormatsJSON);
                                source = Chart.MergeDataSeries(dataSeriesFormat, source);
                            }
                            if (advancedFormat_JSON.HighchartsJSON !== '') {
                                source = Chart.MergeHighcharts(advancedFormat_JSON.HighchartsJSON, source);
                            }
                            return source;
                        }
                        _onOrientationChange() {
                            setTimeout(() => {
                                if (this.selfElem.clientWidth !==
                                    this.selfElem.getElementsByClassName('highcharts-container')[0].clientWidth) {
                                    this._provider.reflow();
                                }
                            }, 300);
                        }
                        _setUpEvents() {
                            OSFramework.Charts.Event.GlobalEventManager.Instance.addHandler(OSFramework.Charts.Event.Type.OrientationChange, this._eventOnOrientationChange);
                        }
                        _unsetEvents() {
                            OSFramework.Charts.Event.GlobalEventManager.Instance.removeHandler(OSFramework.Charts.Event.Type.OrientationChange, this._eventOnOrientationChange);
                        }
                        _updateTicks(finalConfigs) {
                            if (finalConfigs.chart.type !== OSFramework.Charts.Enum.ChartType.Pie) {
                                const yAxis = this._provider.yAxis[0];
                                const yAxisConfig = finalConfigs.yAxis || finalConfigs.yAxis[0];
                                if (!!yAxis.tickPositions &&
                                    yAxis.tickPositions.length > 0 &&
                                    yAxisConfig.tickPositions === undefined &&
                                    yAxisConfig.tickInterval === undefined &&
                                    (yAxisConfig.min || yAxisConfig.max)) {
                                    yAxisConfig.tickPositions = this._getTickPositions(yAxisConfig.min, yAxisConfig.max, yAxis.tickPositions, yAxis['tickInterval'], yAxis.min, yAxis.max);
                                }
                            }
                        }
                        applyChartConfigs(finalConfigs) {
                            if (finalConfigs.series.length > 0) {
                                this._provider.hideLoading();
                            }
                            this._provider.update(finalConfigs, true, true);
                        }
                        buildConfigs() {
                            this.exposedConfigs = this.cBuilder.configs;
                            this.cBuilder.build();
                        }
                        rebuildProviderChart() {
                            this._isReady = false;
                            this._provider.destroy();
                            this.config.providerConfigs.chart.renderTo = this.selfElem;
                            this._provider = new Highcharts.Chart(this.config.getProviderConfig());
                            this._isReady = true;
                        }
                        removeEmptyState() {
                            this._provider.hideLoading();
                        }
                        removeSerie(serieIndex) {
                            this._provider.series[serieIndex].remove();
                        }
                        renderEmptyState() {
                            this._provider.redraw();
                            this._provider.showLoading(OSFramework.Charts.Enum.Messages.NoData);
                        }
                        setCallbacks() {
                            this._eventOnOrientationChange = this._onOrientationChange.bind(this);
                        }
                        unsetCallbacks() {
                            this._eventOnOrientationChange = undefined;
                        }
                        updateData(data) {
                            const chartObject = this.config.getProviderConfig();
                            let dataSource;
                            if (this.config.chart.type === OSFramework.Charts.Enum.ChartType.Pie ||
                                this.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut) {
                                dataSource = Chart.TransformPieData(data, this.seriesEventClick, this.config.isClickable);
                            }
                            else {
                                dataSource = Chart.TransformData(data, this.config.xAxisType, this.seriesEventClick, this.config.isClickable);
                            }
                            this.config.setSeries(dataSource.series);
                            if (dataSource.categories !== undefined) {
                                chartObject.xAxis.categories = dataSource.categories;
                            }
                            if (this.config.xAxisType === OSFramework.Charts.Enum.xAxisType.Datetime) {
                                this.config.xAxisFormat.MinValue = this.config.xAxisFormat.MinValue
                                    ? Date.parse(this.config.xAxisFormat.MinValue)
                                    : dataSource.min;
                                this.config.xAxisFormat.MaxValue = this.config.xAxisFormat.MaxValue
                                    ? Date.parse(this.config.xAxisFormat.MaxValue)
                                    : dataSource.max;
                            }
                            if (this._provider) {
                                this._provider.addSeries(dataSource.series, false, false);
                            }
                        }
                        build() {
                            super.build();
                            this.buildConfigs();
                            const finalConfigs = this._mergeAdvanceFormats(this.config.advancedFormat_JSON);
                            if (this.isReady) {
                                super.updateConfigs(finalConfigs);
                                this._updateTicks(finalConfigs);
                                this.applyChartConfigs(finalConfigs);
                            }
                            else {
                                finalConfigs.chart.renderTo = OSFramework.Charts.Helper.Dom.GetElementByUniqueId(this.uniqueId);
                                if (finalConfigs.series.length === 0) {
                                    delete finalConfigs.series;
                                }
                                this._provider = new Highcharts.Chart(finalConfigs);
                                this._isReady = true;
                            }
                            this.setCallbacks();
                            this._setUpEvents();
                            this.finishBuild();
                        }
                        dispose() {
                            this._unsetEvents();
                            this.unsetCallbacks();
                            super.dispose();
                            this._provider.destroy();
                            this._provider = undefined;
                        }
                    }
                    Chart.AbstractProviderChart = AbstractProviderChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class AreaChart extends Chart.AbstractProviderChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.AreaConfigsBuilder(this);
                        }
                    }
                    Chart.AreaChart = AreaChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class BarChart extends Chart.AbstractProviderChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.BarConfigsBuilder(this);
                        }
                    }
                    Chart.BarChart = BarChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    let Factory;
                    (function (Factory) {
                        function MakeChart(chartID, type, configs) {
                            switch (type) {
                                case OSFramework.Charts.Enum.ChartType.Column:
                                    return new Chart.ColumnChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Bar:
                                    return new Chart.BarChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Line:
                                    return new Chart.LineChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Pie:
                                    return new Chart.PieChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Donut:
                                    return new Chart.DonutChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Area:
                                    return new Chart.AreaChart(chartID, configs);
                                default:
                                    throw new Error(`There is no factory for this type of chart (${type})`);
                            }
                        }
                        Factory.MakeChart = MakeChart;
                    })(Factory = Chart.Factory || (Chart.Factory = {}));
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class ColumnChart extends Chart.AbstractProviderChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.ColumnConfigsBuilder(this);
                        }
                    }
                    Chart.ColumnChart = ColumnChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class PieChart extends Chart.AbstractProviderChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.PieConfigsBuilder(this);
                        }
                    }
                    Chart.PieChart = PieChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class DonutChart extends Chart.PieChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.PieConfigsBuilder(this);
                        }
                    }
                    Chart.DonutChart = DonutChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    class LineChart extends Chart.AbstractProviderChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version1.Configs.LineConfigsBuilder(this);
                        }
                    }
                    Chart.LineChart = LineChart;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    function FindCategoryIndex(categories, DataPointLabel) {
                        const categoryIndex = categories.findIndex((element) => element === DataPointLabel);
                        return categoryIndex;
                    }
                    function FindSerie(series, seriesName) {
                        let internalSerie = series.find((element) => {
                            return element.name === seriesName;
                        });
                        if (internalSerie === undefined && series.length === 1) {
                            internalSerie = series[0];
                        }
                        return internalSerie;
                    }
                    function ParseJson(json) {
                        if (json !== undefined && json.length > 0 && json[0] != '{') {
                            json = '{' + json + '}';
                        }
                        json = json?.replace(/''/g, '""');
                        const regularExpression = /(?:"([^\\"]|\\.)*")|(?:'([^\\']|\\.)*')|(-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)|(\w+)\s*:/g;
                        const cleanJSON = json?.replace(regularExpression, function (match, dqString, sqString, numbers, unquoted) {
                            if (numbers) {
                                return numbers;
                            }
                            else if (sqString) {
                                return '"' + match.substring(1, match.length - 1) + '"';
                            }
                            else if (unquoted) {
                                return '"' + unquoted + '":';
                            }
                            else {
                                return match;
                            }
                        });
                        return cleanJSON;
                    }
                    function MergeXaxis(advancedXformat, source) {
                        let toMerge;
                        try {
                            toMerge = JSON.parse('{ "xAxis" : ' + ParseJson(advancedXformat) + '}');
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        catch (e) {
                            eval('toMerge = { xAxis :' + ParseJson(advancedXformat) + '}');
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        return source;
                    }
                    Chart.MergeXaxis = MergeXaxis;
                    function MergeYaxis(advancedYformat, source) {
                        let toMerge;
                        try {
                            toMerge = JSON.parse('{ "yAxis" : ' + ParseJson(advancedYformat) + '}');
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        catch (e) {
                            eval('toMerge = { yAxis :' + ParseJson(advancedYformat) + '}');
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        return source;
                    }
                    Chart.MergeYaxis = MergeYaxis;
                    function MergeHighcharts(advancedHighcharts, source) {
                        let toMerge;
                        try {
                            toMerge = JSON.parse(ParseJson(advancedHighcharts));
                            if (toMerge.hasOwnProperty('tooltip') &&
                                (toMerge.tooltip.hasOwnProperty('valuePrefix') ||
                                    toMerge.tooltip.hasOwnProperty('valueSuffix') ||
                                    toMerge.tooltip.hasOwnProperty('valueDecimals'))) {
                                toMerge.tooltip.formatter = false;
                            }
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        catch (e) {
                            eval(' toMerge =' + ParseJson(advancedHighcharts));
                            source = HighCharts.Utils.Merge(source, toMerge);
                        }
                        return source;
                    }
                    Chart.MergeHighcharts = MergeHighcharts;
                    function MergeDataSeries(dataSeriesFormat, source) {
                        for (let i = 0; i < dataSeriesFormat.length; i++) {
                            const serie = FindSerie(source.series, dataSeriesFormat[i].SeriesName);
                            if (serie) {
                                let toMerge = serie;
                                try {
                                    toMerge = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataSeriesFormat[i].DataSeriesJSON)));
                                }
                                catch (e) {
                                    eval('toMerge = HighCharts.Utils.Merge(toMerge, ' +
                                        ParseJson(dataSeriesFormat[i].DataSeriesJSON) +
                                        ');');
                                }
                            }
                        }
                        return source;
                    }
                    Chart.MergeDataSeries = MergeDataSeries;
                    function MergePieDataPoints(dataPoint, source) {
                        const serie = FindSerie(source.series, dataPoint.DataPoint.SeriesName);
                        if (serie) {
                            for (let j = 0; j < serie.data.length; j++) {
                                if (serie.data[j].y === dataPoint.DataPoint.Value) {
                                    let toMerge = serie.data[j];
                                    try {
                                        toMerge = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataPoint.DataPointJSON)));
                                    }
                                    catch (e) {
                                        eval('toMerge = HighCharts.Utils.Merge(toMerge, ' + ParseJson(dataPoint.DataPointJSON) + ');');
                                    }
                                }
                            }
                        }
                        return source;
                    }
                    Chart.MergePieDataPoints = MergePieDataPoints;
                    function MergeLineDataPoints(dataPoint, source) {
                        const serie = FindSerie(source.series, dataPoint.DataPoint.SeriesName);
                        if (serie) {
                            for (let j = 0; j < serie.data.length; j++) {
                                if (source.xAxis.type === OSFramework.Charts.Enum.xAxisType.Datetime) {
                                    if (serie.data[j].y === dataPoint.DataPoint.Value &&
                                        serie.data[j].x == new Date(dataPoint.DataPoint.Label).getTime()) {
                                        let toMerge = serie.data[j];
                                        try {
                                            toMerge = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataPoint.DataPointJSON)));
                                        }
                                        catch (e) {
                                            eval('toMerge = HighCharts.Utils.Merge(toMerge, ' + ParseJson(dataPoint.DataPointJSON) + ');');
                                        }
                                        break;
                                    }
                                }
                                else if (source.xAxis.type === OSFramework.Charts.Enum.xAxisType.Decimal) {
                                    if (serie.data) {
                                        const seriePoint = serie.data.filter(function (point) {
                                            return (point.x.toString() === dataPoint.DataPoint.Label &&
                                                point.y === dataPoint.DataPoint.Value);
                                        });
                                        if (seriePoint) {
                                            let toMerge = seriePoint[0];
                                            try {
                                                toMerge = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataPoint.DataPointJSON)));
                                            }
                                            catch (e) {
                                                eval('toMerge = HighCharts.Utils.Merge(toMerge, ' +
                                                    ParseJson(dataPoint.DataPointJSON) +
                                                    ');');
                                            }
                                            break;
                                        }
                                    }
                                }
                                else {
                                    const indexInCategory = FindCategoryIndex(source.xAxis.categories, dataPoint.DataPoint.Label);
                                    if (indexInCategory > -1) {
                                        if (serie.data[indexInCategory].y === dataPoint.DataPoint.Value) {
                                            let toMerge = serie.data[indexInCategory];
                                            try {
                                                toMerge = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataPoint.DataPointJSON)));
                                            }
                                            catch (e) {
                                                eval('toMerge = HighCharts.Utils.Merge(toMerge, ' +
                                                    ParseJson(dataPoint.DataPointJSON) +
                                                    ');');
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        return source;
                    }
                    Chart.MergeLineDataPoints = MergeLineDataPoints;
                    function MergeColumnDataPoints(dataPoint, source) {
                        let indexInCategory = -1;
                        const serie = FindSerie(source.series, dataPoint.DataPoint.SeriesName);
                        if (serie) {
                            indexInCategory = FindCategoryIndex(source.xAxis.categories, dataPoint.DataPoint.Label);
                            if (indexInCategory > -1) {
                                if (serie.data[indexInCategory].y === dataPoint.DataPoint.Value ||
                                    serie.data[indexInCategory - 1].y === dataPoint.DataPoint.Value) {
                                    let toMerge = serie.data[indexInCategory];
                                    try {
                                        const newSource = JSON.parse(ParseJson(dataPoint.DataPointJSON));
                                        if (newSource.tooltip) {
                                            newSource.custom = newSource.tooltip;
                                        }
                                        toMerge = HighCharts.Utils.Merge(toMerge, newSource);
                                    }
                                    catch (e) {
                                        eval('toMerge = HighCharts.Utils.Merge(toMerge, ' + ParseJson(dataPoint.DataPointJSON) + ');');
                                    }
                                }
                            }
                        }
                        return source;
                    }
                    Chart.MergeColumnDataPoints = MergeColumnDataPoints;
                    function MergeDefaultDataPoints(dataPoint, source) {
                        let indexInCategory = -1;
                        const serie = FindSerie(source.series, dataPoint.DataPoint.SeriesName);
                        if (serie) {
                            if (source.xAxis.categories) {
                                indexInCategory = FindCategoryIndex(source.xAxis.categories, dataPoint.DataPoint.Label);
                            }
                            else {
                                indexInCategory = serie.data.findIndex((element) => element.x.toString() === dataPoint.DataPoint.Label);
                            }
                            if (indexInCategory > -1) {
                                if (serie.data[indexInCategory].y === dataPoint.DataPoint.Value ||
                                    serie.data[indexInCategory - 1].y === dataPoint.DataPoint.Value) {
                                    let obj;
                                    try {
                                        const toMerge = serie.data[indexInCategory];
                                        obj = HighCharts.Utils.Merge(toMerge, JSON.parse(ParseJson(dataPoint.DataPointJSON)));
                                    }
                                    catch (e) {
                                        eval('obj = HighCharts.Utils.Merge({y : ' +
                                            serie.data[indexInCategory].toString() +
                                            '}, ' +
                                            ParseJson(dataPoint.DataPointJSON) +
                                            ');');
                                    }
                                    finally {
                                        serie.data[indexInCategory] = obj;
                                    }
                                }
                            }
                        }
                        return source;
                    }
                    Chart.MergeDefaultDataPoints = MergeDefaultDataPoints;
                    function MergeDataPoints(dataPointFormat, source, chartType) {
                        for (let i = 0; i < dataPointFormat.length; i++) {
                            if (chartType === OSFramework.Charts.Enum.ChartType.Column) {
                                source = MergeColumnDataPoints(dataPointFormat[i], source);
                            }
                            if (chartType === OSFramework.Charts.Enum.ChartType.Area ||
                                chartType === OSFramework.Charts.Enum.ChartType.Bar) {
                                source = MergeDefaultDataPoints(dataPointFormat[i], source);
                            }
                            if (chartType === OSFramework.Charts.Enum.ChartType.Line) {
                                source = MergeLineDataPoints(dataPointFormat[i], source);
                            }
                            if (chartType === OSFramework.Charts.Enum.ChartType.Pie) {
                                source = MergePieDataPoints(dataPointFormat[i], source);
                            }
                        }
                        return source;
                    }
                    Chart.MergeDataPoints = MergeDataPoints;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    function TransformData(DataPointsList, xAxisType, seriesEventClick, isClickable) {
                        const categories = [];
                        const series = [];
                        let auxMin;
                        let auxMax;
                        DataPointsList.forEach((item) => {
                            let serieIndex;
                            const serie = {
                                name: '',
                                data: [],
                            };
                            const data = new HighCharts.Configuration.HighChartsStructure.DataItem();
                            data.name = undefined;
                            data.x = undefined;
                            data.y = item.Value;
                            data.custom = item.Tooltip === '' ? undefined : item.Tooltip;
                            data.color = item.Color === '' ? undefined : item.Color;
                            if (xAxisType === OSFramework.Charts.Enum.xAxisType.Datetime) {
                                const tempDate = item.Label.replace(' ', 'T');
                                const date = new Date(tempDate);
                                date.setTime(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
                                if (!auxMin || date < auxMin) {
                                    auxMin = date;
                                }
                                if (!auxMax || date > auxMax) {
                                    auxMax = date;
                                }
                                data.x = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
                                delete data.name;
                            }
                            else if (xAxisType === OSFramework.Charts.Enum.xAxisType.Decimal) {
                                data.x = parseFloat(item.Label);
                                delete data.name;
                            }
                            else {
                                data.name = item.Label === '' ? undefined : item.Label;
                                delete data.x;
                                if (categories && categories.indexOf(item.Label) === -1) {
                                    categories.push(item.Label);
                                }
                            }
                            const onclick = function (e) {
                                const dataPoint = {
                                    Color: e.point.color,
                                    SeriesName: e.point.series.name,
                                    Label: HighCharts.Chart.GetLabel(e.point),
                                    Tooltip: e.point.custom,
                                    Value: e.point.y,
                                };
                                seriesEventClick.trigger(this.widgetId, JSON.stringify(dataPoint));
                            };
                            let serieName;
                            if (series) {
                                serieName = series.find((element) => element.name === (item.SeriesName === '' ? undefined : item.SeriesName));
                            }
                            if (serieName) {
                                serieIndex = series.indexOf(serieName);
                                series[serieIndex].data.push(data);
                                if (isClickable && seriesEventClick.hasHandlers()) {
                                    if (!series[serieIndex].point) {
                                        series[serieIndex].point = {};
                                    }
                                    if (!series[serieIndex].point.events) {
                                        series[serieIndex].point.events = {};
                                    }
                                    series[serieIndex].point.events.click = onclick.bind(this);
                                }
                            }
                            else {
                                if (isClickable && seriesEventClick.hasHandlers()) {
                                    if (!serie.point) {
                                        serie.point = {};
                                    }
                                    if (!serie.point.events) {
                                        serie.point.events = {};
                                    }
                                    serie.point.events.click = onclick.bind(this);
                                }
                                serie.name = item.SeriesName === '' ? undefined : item.SeriesName;
                                serie.data = [data];
                                series.push(serie);
                            }
                        });
                        const dataSource = {
                            categories: categories,
                            series: series,
                        };
                        if (xAxisType === OSFramework.Charts.Enum.xAxisType.Datetime) {
                            dataSource.min = auxMin.getTime();
                            dataSource.max = auxMax.getTime();
                        }
                        return dataSource;
                    }
                    Chart.TransformData = TransformData;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Chart;
                (function (Chart) {
                    function TransformPieData(DataPointsList, seriesEventClick, isClickable) {
                        const categories = [];
                        const series = [];
                        const serie = {
                            name: DataPointsList.length > 0 ? DataPointsList[0].SeriesName : '',
                            data: [],
                        };
                        if (DataPointsList.length > 0) {
                            series.push(serie);
                            DataPointsList.forEach((item) => {
                                const data = new HighCharts.Configuration.HighChartsStructure.DataItem();
                                data.name = item.Label === '' ? undefined : item.Label;
                                data.y = item.Value;
                                data.custom = item.Tooltip === '' ? undefined : item.Tooltip;
                                data.color = item.Color === '' ? undefined : item.Color;
                                if (categories && categories.indexOf(item.Label) === -1) {
                                    categories.push(item.Label);
                                }
                                series[0].data.push(data);
                            });
                            const onclick = function (e) {
                                const dataPoint = {
                                    Color: e.point.color,
                                    SeriesName: e.point.series.name,
                                    Label: HighCharts.Chart.GetLabel(e.point),
                                    Tooltip: e.point.custom,
                                    Value: e.point.y,
                                };
                                seriesEventClick.trigger(this.widgetId, JSON.stringify(dataPoint));
                            };
                            if (isClickable && seriesEventClick.hasHandlers()) {
                                if (!series[0].point) {
                                    series[0].point = {};
                                }
                                if (!series[0].point.events) {
                                    series[0].point.events = {};
                                }
                                series[0].point.events.click = onclick.bind(this);
                            }
                        }
                        const dataSource = {
                            series: series,
                        };
                        return dataSource;
                    }
                    Chart.TransformPieData = TransformPieData;
                })(Chart = Version1.Chart || (Version1.Chart = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    class HighChartsConfig extends HighCharts.Configuration.HighChartsConfig {
                        constructor(config) {
                            super(config);
                            this.OSVersion = OSFramework.Charts.Enum.OSChartVersion.Version1;
                            this._providerConfigs = new Configuration.HighChartsProviderConfig({});
                        }
                    }
                    Configuration.HighChartsConfig = HighChartsConfig;
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    class HighChartsProviderConfig extends OSFramework.Charts.AbstractConfig {
                        constructor(config) {
                            super(config);
                            this.chart = new Charts.HighCharts.Version1.Configuration.HighChartsStructure.Chart();
                            this.legend = new Charts.HighCharts.Configuration.HighChartsStructure.Legend();
                            this.plotOptions = new Charts.HighCharts.Configuration.HighChartsStructure.PlotOption();
                            this.series = new Array();
                            this.tooltip = new Charts.HighCharts.Configuration.HighChartsStructure.Tooltip();
                            this.title = new Charts.HighCharts.Version1.Configuration.HighChartsStructure.Title();
                            this.xAxis = new Charts.HighCharts.Version1.Configuration.HighChartsStructure.Xaxis();
                            this.yAxis = new Charts.HighCharts.Version1.Configuration.HighChartsStructure.Yaxis();
                        }
                    }
                    Configuration.HighChartsProviderConfig = HighChartsProviderConfig;
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Chart {
                        }
                        HighChartsStructure.Chart = Chart;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Title {
                        }
                        HighChartsStructure.Title = Title;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Xaxis {
                            constructor() {
                                this.labels = { rotation: 0 };
                                this.title = new HighChartsStructure.Title();
                            }
                        }
                        HighChartsStructure.Xaxis = Xaxis;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Yaxis {
                            constructor() {
                                this.categories = [];
                                this.stackLabels = { enabled: false };
                                this.title = new HighChartsStructure.Title();
                            }
                        }
                        HighChartsStructure.Yaxis = Yaxis;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version1.Configuration || (Version1.Configuration = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class ConfigsBuilder extends HighCharts.Configs.AbstractFactoryBuilder {
                        _makeChart() {
                            this._configs.chart = this._makeItem(Configs.GeneralOptions);
                            return this;
                        }
                        _makeColors() {
                            this._configs.colors = this._makeItem(HighCharts.Configs.Colors);
                            return this;
                        }
                        _makeCredits() {
                            this._configs.credits = this._makeItem(HighCharts.Configs.Credits);
                            return this;
                        }
                        _makeLegend() {
                            this._configs.legend = this._makeItem(Configs.Legend);
                            return this;
                        }
                        _makeTitle() {
                            this._configs.title = this._makeItem(HighCharts.Configs.Title);
                            return this;
                        }
                        _makeXaxis() {
                            this._configs.xAxis = this._makeItem(HighCharts.Configs.Xaxis);
                            return this;
                        }
                        _makeYaxis() {
                            this._configs.yAxis = this._makeItem(HighCharts.Configs.Yaxis);
                            return this;
                        }
                        _setSeriesColor() {
                            const seriesColor = this._chart.config._providerConfigs.colors;
                            if (seriesColor.length >= this._chart.config.providerConfigs.series.length) {
                                this._chart.config.providerConfigs.series.forEach((key, index) => {
                                    key.color = seriesColor[index];
                                });
                            }
                            else {
                                console.warn(`The number of series is higher then the available generated colors on Chart`);
                            }
                            return this;
                        }
                        build() {
                            this._makeChart();
                            this._makeCredits();
                            this._makeLegend();
                            this._makeTitle();
                            this._makeYaxis();
                            this._makeColors();
                            this._makeXaxis();
                            super.build();
                        }
                    }
                    Configs.ConfigsBuilder = ConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class AreaConfigsBuilder extends Configs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            this._configs.plotOptions = this._makeItem(HighCharts.Configs.AreaPlotOptions);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(HighCharts.Configs.Tooltip);
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            this._makeTooltip();
                            super.build();
                            this._setSeriesColor();
                        }
                    }
                    Configs.AreaConfigsBuilder = AreaConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class BarConfigsBuilder extends Configs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            this._configs.plotOptions = this._makeItem(HighCharts.Configs.BarPlotOptions);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(HighCharts.Configs.Tooltip);
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            this._makeTooltip();
                            super.build();
                            this._setSeriesColor();
                        }
                    }
                    Configs.BarConfigsBuilder = BarConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Configs;
            (function (Configs) {
                class Colors extends HighCharts.Configs.AbstractColorConfig {
                    _colorLuminance(hex, lum) {
                        hex = String(hex).replace(/[^0-9a-f]/gi, '');
                        if (hex.length < 6) {
                            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
                        }
                        lum = lum || 0;
                        let rgb = '#';
                        let c;
                        for (let i = 0; i < 3; i++) {
                            c = parseInt(hex.substr(i * 2, 2), 16);
                            c = Math.round(Math.min(Math.max(0, c + c * lum), 255)).toString(16);
                            rgb += ('00' + c).substr(c.length);
                        }
                        return rgb;
                    }
                    _colorToHex(color) {
                        if (color.substr(0, 1) === '#') {
                            return color;
                        }
                        const digits = /(.*?)rgb\((\d+), (\d+), (\d+)\)/.exec(color);
                        const R = parseInt(digits[2]);
                        const G = parseInt(digits[3]);
                        const B = parseInt(digits[4]);
                        return '#' + this._toHex(R) + this._toHex(G) + this._toHex(B);
                    }
                    _convertToHsl(color) {
                        if (color.substr(0, 1) === '#') {
                            return color;
                        }
                        const digits = /(.*?)rgb\((\d+), (\d+), (\d+)\)/.exec(color);
                        const R = parseInt(digits[2]) / 255;
                        const G = parseInt(digits[3]) / 255;
                        const B = parseInt(digits[4]) / 255;
                        const maxColor = Math.max(R, G, B);
                        const minColor = Math.min(R, G, B);
                        let L = (maxColor + minColor) / 2;
                        let S = 0;
                        let H = 0;
                        if (maxColor !== minColor) {
                            if (L < 0.5) {
                                S = (maxColor - minColor) / (maxColor + minColor);
                            }
                            else {
                                S = (maxColor - minColor) / (2.0 - maxColor - minColor);
                            }
                            if (R === maxColor) {
                                H = (G - B) / (maxColor - minColor);
                            }
                            else if (G === maxColor) {
                                H = 2.0 + (B - R) / (maxColor - minColor);
                            }
                            else {
                                H = 4.0 + (R - G) / (maxColor - minColor);
                            }
                        }
                        L = L * 100;
                        S = S * 100;
                        H = H * 60;
                        if (H < 0) {
                            H += 360;
                        }
                        const result = [H, S, L];
                        return result;
                    }
                    _toHex(value) {
                        value = parseInt(value.toString(), 10);
                        if (isNaN(value)) {
                            return '00';
                        }
                        else {
                            value = Math.max(0, Math.min(value, 255));
                            return '0123456789ABCDEF'.charAt((value - (value % 16)) / 16) + '0123456789ABCDEF'.charAt(value % 16);
                        }
                    }
                    setColorConfig() {
                        let mainColor = '#009dde';
                        const chartColorSelector = document.querySelector('.chart-wrapper .chart-color');
                        let style;
                        if (chartColorSelector !== null) {
                            style = window.getComputedStyle(chartColorSelector, '');
                        }
                        if (typeof style !== 'undefined') {
                            mainColor = style.getPropertyValue('background-color');
                        }
                        const hsl = this._convertToHsl(mainColor);
                        mainColor = this._colorToHex(style.getPropertyValue('background-color'));
                        if (hsl[2] > 60) {
                            mainColor = this._colorLuminance(mainColor, -0.1);
                        }
                        const colors = [];
                        let step;
                        if ((this.chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Pie ||
                            this.chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut) &&
                            this.chart.config.providerConfigs.series.length > 0) {
                            step = 1.45 / this.chart.config.providerConfigs.series[0].data.length;
                            for (let i = -0.4; i < 1.05; i += step) {
                                colors.push(this._colorLuminance(mainColor, i));
                            }
                        }
                        else {
                            step = 0.8 / this.seriesLength;
                            for (let i = -0.4; i < 0.4; i += step) {
                                colors.push(this._colorLuminance(mainColor, i));
                            }
                        }
                        this.colorConfig = colors;
                    }
                    build() {
                        super.build();
                    }
                    get options() {
                        return this.colorConfig;
                    }
                }
                Configs.Colors = Colors;
            })(Configs = HighCharts.Configs || (HighCharts.Configs = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class ColumnConfigsBuilder extends Configs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            this._configs.plotOptions = this._makeItem(HighCharts.Configs.ColumnPlotOptions);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(HighCharts.Configs.Tooltip);
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            this._makeTooltip();
                            super.build();
                            this._setSeriesColor();
                        }
                    }
                    Configs.ColumnConfigsBuilder = ColumnConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class GeneralOptions {
                        constructor(chart) {
                            this._chart = chart;
                        }
                        build() {
                            const chartConfig = this._chart.config.chart;
                            const chartFormatConfig = this._chart.config.chartFormat;
                            this._options = {
                                animation: chartFormatConfig.UseAnimation || false,
                                backgroundColor: chartConfig.backgroundColor,
                                height: chartConfig.height,
                                plotShadow: chartConfig.plotShadow,
                                type: chartConfig.type === OSFramework.Charts.Enum.ChartType.Donut
                                    ? OSFramework.Charts.Enum.ChartType.Pie
                                    : chartConfig.type,
                                renderTo: undefined,
                            };
                            this.setProviderOptions();
                        }
                        setProviderOptions() {
                            this._chart.config.providerConfigs.chart = this._options;
                        }
                        get options() {
                            return this._options;
                        }
                    }
                    Configs.GeneralOptions = GeneralOptions;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Chart;
            (function (Chart) {
                function GetLabel(pointObject) {
                    if (pointObject.series.chart.xAxis[0].options.type === 'datetime') {
                        const date = new Date(pointObject.category);
                        return (date.getFullYear() +
                            '-' +
                            (date.getMonth() + 1 < 10 ? '0' : '') +
                            (date.getMonth() + 1) +
                            '-' +
                            (date.getUTCDate() < 10 ? '0' : '') +
                            date.getUTCDate());
                    }
                    else {
                        return pointObject.category !== '' && pointObject.category !== undefined
                            ? pointObject.category.toString()
                            : pointObject.name.toString();
                    }
                }
                Chart.GetLabel = GetLabel;
            })(Chart = HighCharts.Chart || (HighCharts.Chart = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class Legend {
                        constructor(chart) {
                            this._chart = chart;
                        }
                        build() {
                            const _legend = Configs.GetLegendInfo(this._chart.config.legendPositionId, this._chart.config.OSVersion);
                            this._options = {
                                align: _legend.align,
                                enabled: _legend.enabled,
                                floating: _legend.floating,
                                itemMarginBottom: _legend.itemMarginBottom,
                                layout: _legend.layout || 'horizontal',
                                verticalAlign: _legend.verticalAlign,
                            };
                            this.setProviderOptions();
                        }
                        setProviderOptions() {
                            this._chart.config.providerConfigs.legend = this._options;
                        }
                    }
                    Configs.Legend = Legend;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    function GetLegendInfo(LegendPosition, ChartVersion) {
                        const legend = new Charts.HighCharts.Configuration.HighChartsStructure.Legend();
                        legend.enabled = true;
                        legend.floating = false;
                        switch (LegendPosition ||
                            (ChartVersion === OSFramework.Charts.Enum.OSChartVersion.Version1 &&
                                OSFramework.Charts.Enum.Legend.Position.Bottom)) {
                            case OSFramework.Charts.Enum.Legend.Position.Bottom:
                                legend.align = OSFramework.Charts.Enum.Legend.AlignValues.Center;
                                legend.verticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Bottom;
                                break;
                            case OSFramework.Charts.Enum.Legend.Position.Top:
                                legend.align = OSFramework.Charts.Enum.Legend.AlignValues.Center;
                                legend.verticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Top;
                                break;
                            case OSFramework.Charts.Enum.Legend.Position.Right:
                                legend.align = OSFramework.Charts.Enum.Legend.AlignValues.Right;
                                legend.layout = OSFramework.Charts.Enum.Legend.Orientation.Vertical;
                                legend.verticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Middle;
                                break;
                            case OSFramework.Charts.Enum.Legend.Position.Left:
                                legend.align = OSFramework.Charts.Enum.Legend.AlignValues.Left;
                                legend.layout = OSFramework.Charts.Enum.Legend.Orientation.Vertical;
                                legend.verticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Middle;
                                break;
                            case OSFramework.Charts.Enum.Legend.Position.Inside:
                                legend.align = OSFramework.Charts.Enum.Legend.AlignValues.Right;
                                legend.floating = true;
                                legend.layout = OSFramework.Charts.Enum.Legend.Orientation.Vertical;
                                legend.verticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Top;
                                break;
                            case OSFramework.Charts.Enum.Legend.Position.Hidden:
                            default:
                                legend.enabled = false;
                                break;
                        }
                        legend.itemMarginBottom = 10;
                        return legend;
                    }
                    Configs.GetLegendInfo = GetLegendInfo;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class LineConfigsBuilder extends Configs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            this._configs.plotOptions = this._makeItem(HighCharts.Configs.LinePlotOptions);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(HighCharts.Configs.Tooltip);
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            this._makeTooltip();
                            super.build();
                            this._setSeriesColor();
                        }
                    }
                    Configs.LineConfigsBuilder = LineConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version1;
            (function (Version1) {
                var Configs;
                (function (Configs) {
                    class PieConfigsBuilder extends Configs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            this._configs.plotOptions = this._makeItem(HighCharts.Configs.PiePlotOptions);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(HighCharts.Configs.PieTooltip);
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            this._makeTooltip();
                            super.build();
                        }
                    }
                    Configs.PieConfigsBuilder = PieConfigsBuilder;
                })(Configs = Version1.Configs || (Version1.Configs = {}));
            })(Version1 = HighCharts.Version1 || (HighCharts.Version1 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class AbstractHighChart extends OSFramework.Charts.Version2.Chart {
                        constructor(chartId, configs) {
                            super(chartId, new Charts.HighCharts.Version2.Configuration.AbstractHighChartsConfig(configs));
                            this.loadingTimeout = 700;
                            this._isReady = false;
                        }
                        _onOrientationChange() {
                            setTimeout(() => {
                                if (this.selfElem.clientWidth !==
                                    this.selfElem.getElementsByClassName('highcharts-container')[0].clientWidth) {
                                    this._provider.reflow();
                                }
                            }, 300);
                        }
                        _removeSkeletonLoading() {
                            setTimeout(() => {
                                this.removeEmptyState();
                            }, this.loadingTimeout);
                        }
                        _setUpEvents() {
                            OSFramework.Charts.Event.GlobalEventManager.Instance.addHandler(OSFramework.Charts.Event.Type.OrientationChange, this._eventOnOrientationChange);
                        }
                        _unsetEvents() {
                            OSFramework.Charts.Event.GlobalEventManager.Instance.removeHandler(OSFramework.Charts.Event.Type.OrientationChange, this._eventOnOrientationChange);
                        }
                        applyChartConfigs(finalConfigs) {
                            if (finalConfigs.series && finalConfigs.series.length > 0) {
                                if (this.config.disableLoadingAnimation === false) {
                                    this._removeSkeletonLoading();
                                }
                                else {
                                    this.removeEmptyState();
                                }
                            }
                            this._provider.update(finalConfigs, true, true);
                        }
                        buildConfigs() {
                            this.cBuilder.build();
                        }
                        directUpdateProviderChart(chartConfigs) {
                            this._provider.update(chartConfigs, true, true);
                        }
                        rebuildProviderChart() {
                            this._isReady = false;
                            this._provider.destroy();
                            this.config.providerConfigs.chart.renderTo = this.selfElem;
                            this._provider = new Highcharts.Chart(this.config.getProviderConfig());
                            this._isReady = true;
                            this.renderEmptyState();
                            if (this.config.disableLoadingAnimation === false) {
                                this._removeSkeletonLoading();
                            }
                            else {
                                this.removeEmptyState();
                            }
                        }
                        removeEmptyState() {
                            this._provider.hideLoading();
                        }
                        removeSerie(serieIndex) {
                            this._provider.series[serieIndex].remove();
                        }
                        renderEmptyState() {
                            this._provider.showLoading();
                        }
                        setCallbacks() {
                            this._eventOnOrientationChange = this._onOrientationChange.bind(this);
                        }
                        unsetCallbacks() {
                            this._eventOnOrientationChange = undefined;
                        }
                        updateData(data, isUpdatingStyling = false) {
                            const chartObject = this.config.getProviderConfig();
                            let dataSource;
                            if (isUpdatingStyling) {
                                dataSource = {
                                    series: data,
                                    categories: chartObject.xAxis[0].categories,
                                };
                            }
                            else {
                                const dataPointList = data;
                                const seriesStyling = this.features.seriesStyling;
                                dataSource = Chart.TransformData(dataPointList, this.config.stackingType, this.config.valuesType, this.seriesEventClick);
                                if (seriesStyling !== undefined) {
                                    dataSource.series.forEach((serie, index) => {
                                        const SerieStyling = seriesStyling.find((element) => {
                                            return element.config.Binding === serie.name;
                                        });
                                        if (SerieStyling) {
                                            const serieToChange = dataSource.series[index];
                                            const serieConfig = SerieStyling.config;
                                            serieToChange.dataLabels = {};
                                            serieToChange.marker = {};
                                            serieToChange.borderColor = serieConfig.LineColor;
                                            serieToChange.className = serieConfig.ExtendedClass;
                                            serieToChange.color = serieConfig.FillColor;
                                            serieToChange.dataLabels.enabled = serieConfig.ShowDataPointValues;
                                            serieToChange.marker.enabled = serieConfig.MarkerHideMarker === false;
                                            serieToChange.marker.fillColor = serieConfig.MarkerFillColor;
                                            serieToChange.marker.lineColor = serieConfig.MarkerBorderColor;
                                            serieToChange.marker.radius = serieConfig.MarkerRadius;
                                            serieToChange.marker.symbol = serieConfig.MarkerSymbol;
                                            if (serieConfig.MarkerBorderWidth !== '') {
                                                serieToChange.marker.lineWidth = parseInt(serieConfig.MarkerBorderWidth.trim());
                                            }
                                            if (serieConfig.LineWidth.trim() !== '') {
                                                serieToChange.lineWidth = serieConfig.LineWidth.trim();
                                                serieToChange.borderWidth = parseInt(serieConfig.LineWidth.trim());
                                            }
                                            serieToChange.lineColor = serieConfig.LineColor;
                                            if (serieConfig.Opacity.trim() !== '') {
                                                serieToChange.opacity = parseFloat(serieConfig.Opacity.trim());
                                            }
                                            serieToChange.showInLegend = serieConfig.ShowInLegend;
                                            serieToChange.type = serieConfig.Type;
                                        }
                                    });
                                }
                            }
                            this._series = dataSource.series;
                            const series = dataSource.series;
                            this._categories = dataSource.categories;
                            this.config.setSeries(series);
                            if (dataSource.categories !== undefined &&
                                chartObject.xAxis &&
                                this.config.valuesType === OSFramework.Charts.Version2.Enum.ValuesType.Text) {
                                for (const xAxis of chartObject.xAxis) {
                                    xAxis.categories = dataSource.categories;
                                }
                            }
                            else {
                                if (chartObject.xAxis[0] !== null) {
                                    for (const xAxis of chartObject.xAxis) {
                                        xAxis.categories = null;
                                    }
                                }
                            }
                            if (this._provider) {
                                this._provider.addSeries(series, false, false);
                            }
                        }
                        updateProviderChart(chartConfigs) {
                            this._provider.update(Version2.Utils.Extensibility.MergeConfigsObjects(chartConfigs), true);
                        }
                        updateProviderColorScheme(colorSchemePalette) {
                            this.config.providerConfigs.colors = JSON.parse(colorSchemePalette);
                            this._provider.destroy();
                            this._provider = new Highcharts.Chart(this.config.getProviderConfig());
                            this.renderEmptyState();
                            if (this.config.disableLoadingAnimation === false) {
                                this._removeSkeletonLoading();
                            }
                            else {
                                this.removeEmptyState();
                            }
                        }
                        updateProviderFirstAxisOfType(featureType, config) {
                            this._provider[featureType][0].update(config);
                        }
                        updateProviderSerie(serieConfigs, serieBinding) {
                            const serie = this._provider.series.find((element) => element.options.id === serieBinding.trim().replace(/\s/g, ''));
                            if (serie) {
                                serie.update(Version2.Utils.Extensibility.MergeConfigsObjects(serieConfigs), true);
                            }
                        }
                        updateProviderXAxis(xAxisConfigs, xAxisId) {
                            const xAxis = this._provider.xAxis.find((element) => element.options.id === xAxisId);
                            if (xAxis) {
                                xAxis.update(xAxisConfigs, true);
                            }
                        }
                        updateProviderYAxis(yAxisConfigs, yAxisId) {
                            const yAxis = this._provider.yAxis.find((element) => element.options.id === yAxisId);
                            if (yAxis) {
                                yAxis.update(yAxisConfigs, true);
                            }
                        }
                        build() {
                            super.build();
                            this.buildConfigs();
                            const finalConfigs = this.config.getProviderConfig();
                            if (this.isReady) {
                                super.updateConfigs(finalConfigs);
                                this.applyChartConfigs(finalConfigs);
                            }
                            else {
                                finalConfigs.chart.renderTo = OSFramework.Charts.Helper.Dom.GetElementByUniqueId(this.uniqueId);
                                if (finalConfigs.series.length === 0) {
                                    delete finalConfigs.series;
                                }
                                this._provider = new Highcharts.Chart(finalConfigs);
                                if (this.config.disableLoadingAnimation === false) {
                                    this._provider.showLoading();
                                }
                                this._isReady = true;
                                this.chartInitializedEvent.trigger(this.widgetId);
                            }
                            this.setCallbacks();
                            this._setUpEvents();
                            this.finishBuild();
                            if (finalConfigs.series &&
                                finalConfigs.series.length > 0 &&
                                this.config.disableLoadingAnimation === false) {
                                this._removeSkeletonLoading();
                            }
                        }
                        dispose() {
                            this._unsetEvents();
                            this.unsetCallbacks();
                            super.dispose();
                            this._provider.destroy();
                            this._provider = undefined;
                        }
                    }
                    Chart.AbstractHighChart = AbstractHighChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class AreaChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.AreaConfigsBuilder(this);
                        }
                    }
                    Chart.AreaChart = AreaChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class AreaSplineChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.AreaSplineConfigsBuilder(this);
                        }
                    }
                    Chart.AreaSplineChart = AreaSplineChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class BarChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.BarConfigsBuilder(this);
                        }
                    }
                    Chart.BarChart = BarChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class ColumnChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.ColumnConfigsBuilder(this);
                        }
                    }
                    Chart.ColumnChart = ColumnChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class PieChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.PieConfigsBuilder(this);
                        }
                    }
                    Chart.PieChart = PieChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class DonutChart extends Chart.PieChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                        }
                    }
                    Chart.DonutChart = DonutChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    let Factory;
                    (function (Factory) {
                        function MakeChart(chartID, type, configs) {
                            switch (type) {
                                case OSFramework.Charts.Enum.ChartType.Column:
                                    return new Chart.ColumnChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Bar:
                                    return new Chart.BarChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Line:
                                    return new Chart.LineChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Pie:
                                    return new Chart.PieChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Donut:
                                    return new Chart.DonutChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Area:
                                    return new Chart.AreaChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.AreaSpline:
                                    return new Chart.AreaSplineChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Spline:
                                    return new Chart.SplineChart(chartID, configs);
                                case OSFramework.Charts.Enum.ChartType.Radar:
                                    return new Chart.RadarChart(chartID, configs);
                                default:
                                    throw new Error(`There is no factory for this type of chart (${type})`);
                            }
                        }
                        Factory.MakeChart = MakeChart;
                    })(Factory = Chart.Factory || (Chart.Factory = {}));
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class LineChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.LineConfigsBuilder(this);
                        }
                    }
                    Chart.LineChart = LineChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class RadarChart extends Chart.LineChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                        }
                    }
                    Chart.RadarChart = RadarChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    class SplineChart extends Chart.AbstractHighChart {
                        constructor(chartID, configs) {
                            super(chartID, configs);
                            this.cBuilder = new Version2.ExposedConfigs.SplineConfigsBuilder(this);
                        }
                    }
                    Chart.SplineChart = SplineChart;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Chart;
                (function (Chart) {
                    function GetStackingValue(type) {
                        switch (type) {
                            case OSFramework.Charts.Version2.Enum.StackingType.Stacked100Percent:
                                return 'percent';
                            case OSFramework.Charts.Version2.Enum.StackingType.Stacked:
                                return 'normal';
                            default:
                                return undefined;
                        }
                    }
                    function TransformData(DataPointsList, StackingType, ValuesType, seriesEventClick) {
                        const categories = new Array();
                        const series = new Array();
                        const stackingValue = GetStackingValue(StackingType);
                        DataPointsList.forEach((item) => {
                            let serieIndex;
                            const data = new HighCharts.Configuration.HighChartsStructure.DataItem();
                            if (item.Label === '') {
                                data.name = undefined;
                                data.x = undefined;
                            }
                            else {
                                switch (ValuesType) {
                                    case OSFramework.Charts.Version2.Enum.ValuesType.Datetime:
                                        const tempDate = item.Label.replace(' ', 'T');
                                        const date = new Date(tempDate);
                                        date.setTime(date.getTime() - date.getTimezoneOffset() * 60 * 1000);
                                        data.x = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
                                        break;
                                    case OSFramework.Charts.Version2.Enum.ValuesType.Integer:
                                        data.x = parseInt(item.Label);
                                        break;
                                    case OSFramework.Charts.Version2.Enum.ValuesType.Decimal:
                                        data.x = parseFloat(item.Label);
                                        break;
                                    case OSFramework.Charts.Version2.Enum.ValuesType.Text:
                                    default:
                                        data.name = item.Label;
                                        if (categories && categories.indexOf(item.Label) === -1) {
                                            categories.push(item.Label);
                                        }
                                        break;
                                }
                            }
                            data.y = item.Value;
                            data.custom = item.Tooltip === '' ? undefined : item.Tooltip;
                            data.color = item.Color === '' ? undefined : item.Color;
                            const onclick = function (e) {
                                let currlabel;
                                if (ValuesType === OSFramework.Charts.Version2.Enum.ValuesType.Datetime ||
                                    ValuesType === OSFramework.Charts.Version2.Enum.ValuesType.Integer ||
                                    ValuesType === OSFramework.Charts.Version2.Enum.ValuesType.Decimal) {
                                    currlabel = e.point.options.x.toString();
                                }
                                else {
                                    currlabel = e.point.options.name.toString();
                                }
                                const dataPoint = {
                                    Color: e.point.color,
                                    SeriesName: e.point.series.name,
                                    Label: currlabel,
                                    Tooltip: e.point.custom,
                                    Value: e.point.y,
                                };
                                seriesEventClick.trigger(this.widgetId, JSON.stringify(dataPoint));
                            };
                            let serieName;
                            if (series) {
                                serieName = series.find((element) => element.name === (item.SeriesName === '' ? undefined : item.SeriesName));
                            }
                            if (serieName) {
                                serieIndex = series.indexOf(serieName);
                                series[serieIndex].data.push(data);
                                series[serieIndex].stacking = stackingValue;
                                if (seriesEventClick.hasHandlers()) {
                                    if (!series[serieIndex].point) {
                                        series[serieIndex].point = {};
                                    }
                                    if (!series[serieIndex].point.events) {
                                        series[serieIndex].point.events = {};
                                    }
                                    series[serieIndex].point.events.click = onclick.bind(this);
                                }
                            }
                            else {
                                const serie = {};
                                serie.name = item.SeriesName === '' ? undefined : item.SeriesName;
                                serie.id = item.SeriesName.trim().replace(/\s/g, '');
                                serie.data = [data];
                                serie.stacking = stackingValue;
                                if (seriesEventClick.hasHandlers()) {
                                    serie.point = {
                                        events: {
                                            click: onclick,
                                        },
                                    };
                                }
                                series.push(serie);
                            }
                        });
                        const dataSource = {
                            categories: categories,
                            series: series,
                        };
                        return dataSource;
                    }
                    Chart.TransformData = TransformData;
                })(Chart = Version2.Chart || (Version2.Chart = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Configuration;
                (function (Configuration) {
                    class AbstractHighChartsConfig extends HighCharts.Configuration.HighChartsConfig {
                        constructor(config) {
                            super(config);
                            this.disableLoadingAnimation = config.disableLoadingAnimation;
                            this.OSVersion = OSFramework.Charts.Enum.OSChartVersion.Version2;
                            this.stackingType = config.stackingType;
                            this.valuesType = config.valuesType;
                            this._providerConfigs = {
                                chart: new Charts.HighCharts.Version2.Configuration.HighChartsStructure.Chart(),
                                colors: undefined,
                                credits: { enabled: false },
                                legend: { enabled: false },
                                loading: undefined,
                                plotOptions: new Charts.HighCharts.Configuration.HighChartsStructure.PlotOption(),
                                series: new Array(),
                                title: new Charts.HighCharts.Version2.Configuration.HighChartsStructure.Title(),
                                tooltip: undefined,
                                xAxis: [{ visible: false }],
                                yAxis: [{ visible: false }],
                            };
                        }
                    }
                    Configuration.AbstractHighChartsConfig = AbstractHighChartsConfig;
                })(Configuration = Version2.Configuration || (Version2.Configuration = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Axis {
                        }
                        HighChartsStructure.Axis = Axis;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version2.Configuration || (Version2.Configuration = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Chart {
                        }
                        HighChartsStructure.Chart = Chart;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version2.Configuration || (Version2.Configuration = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Configuration;
                (function (Configuration) {
                    var HighChartsStructure;
                    (function (HighChartsStructure) {
                        class Title {
                        }
                        HighChartsStructure.Title = Title;
                    })(HighChartsStructure = Configuration.HighChartsStructure || (Configuration.HighChartsStructure = {}));
                })(Configuration = Version2.Configuration || (Version2.Configuration = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class ConfigsBuilder extends HighCharts.Configs.AbstractFactoryBuilder {
                        _makeChart() {
                            this._configs.chart = this._makeItem(ExposedConfigs.GeneralOptions);
                            return this;
                        }
                        _makeColors() {
                            this._chart._config._providerConfigs.colors = this._makeItem(ExposedConfigs.Color.ColorConfigsBuilder);
                            return this;
                        }
                        _makeCredits() {
                            this._configs.credits = this._makeItem(HighCharts.Configs.Credits);
                            return this;
                        }
                        _makeExporting() {
                            this._chart._config._providerConfigs.exporting = this._chart._config._providerConfigs.exporting || {
                                enabled: false,
                            };
                            return this;
                        }
                        _makeLegend() {
                            this._chart._config._providerConfigs.legend = { ...Highcharts.defaultOptions.legend, enabled: false };
                            return this;
                        }
                        _makeLoading(disableLoadingAnimation) {
                            if (disableLoadingAnimation) {
                                this._chart._config._providerConfigs.loading = Highcharts.defaultOptions.loading;
                            }
                            else {
                                this._chart._config._providerConfigs.loading = this._makeItem(ExposedConfigs.LoadingConfigBuilder);
                            }
                            return this;
                        }
                        _makeTitle() {
                            this._configs.title = this._makeItem(HighCharts.Configs.Title);
                            return this;
                        }
                        _makeTooltip() {
                            this._configs.tooltip = this._makeItem(ExposedConfigs.TooltipConfigBuilder);
                            return this;
                        }
                        _makeXaxis() {
                            this._chart._config._providerConfigs.xAxis[0] = {
                                visible: false,
                                min: null,
                                max: null,
                                crosshair: false,
                                type: 'linear',
                            };
                            return this;
                        }
                        _makeYaxis() {
                            this._chart._config._providerConfigs.yAxis[0] = {
                                visible: false,
                                min: null,
                                max: null,
                                crosshair: false,
                                type: 'linear',
                            };
                            return this;
                        }
                        build() {
                            this._makeChart();
                            this._makeColors();
                            this._makeCredits();
                            this._makeTitle();
                            this._makeTooltip();
                            this._makeLoading(this._chart._config.disableLoadingAnimation);
                            if (this._chart._config._providerConfigs.yAxis[0] === null) {
                                this._makeYaxis();
                            }
                            if (this._chart._config._providerConfigs.xAxis[0] === null) {
                                this._makeXaxis();
                            }
                            if (this._chart._config._providerConfigs.legend === null) {
                                this._makeLegend();
                            }
                            this._makeExporting();
                            super.build();
                        }
                    }
                    ExposedConfigs.ConfigsBuilder = ConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class AreaConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                    lineWidth: 1,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                area: {
                                    color: '',
                                    lineWidth: 1,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            area: {
                                                color: element.config.LineColor ? element.config.LineColor : '',
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.AreaConfigsBuilder = AreaConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class AreaSplineConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                    lineWidth: 1,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                areaspline: {
                                    color: '',
                                    lineWidth: 1,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            areaspline: {
                                                color: element.config.LineColor ? element.config.LineColor : '',
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.AreaSplineConfigsBuilder = AreaSplineConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class BarConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                bar: {
                                    borderColor: '',
                                    borderWidth: 0,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            bar: {
                                                borderColor: element.config.LineColor ? element.config.LineColor : '',
                                                borderWidth: element.config.LineWidth ? element.config.LineWidth : 0,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.BarConfigsBuilder = BarConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class ColumnConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                column: {
                                    borderColor: '',
                                    borderWidth: 0,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            column: {
                                                borderColor: element.config.LineColor ? element.config.LineColor : '',
                                                borderWidth: element.config.LineWidth ? element.config.LineWidth : 0,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.ColumnConfigsBuilder = ColumnConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class GeneralOptions {
                        constructor(chart) {
                            this._chart = chart;
                        }
                        build() {
                            const chartConfig = this._chart.config.chart;
                            this._options = {
                                animation: false,
                                backgroundColor: 'transparent',
                                className: chartConfig.className,
                                height: chartConfig.height,
                                type: chartConfig.type,
                                renderTo: undefined,
                            };
                            this.setProviderOptions();
                        }
                        setProviderOptions() {
                            switch (this._options.type) {
                                case OSFramework.Charts.Enum.ChartType.Donut:
                                    this._options.type = OSFramework.Charts.Enum.ChartType.Pie;
                                    break;
                                case OSFramework.Charts.Enum.ChartType.Radar:
                                    this._options.type = OSFramework.Charts.Enum.ChartType.Line;
                                    this._options.polar = true;
                                    break;
                            }
                            this._chart.config.providerConfigs.chart = this._options;
                        }
                        get options() {
                            return this._options;
                        }
                    }
                    ExposedConfigs.GeneralOptions = GeneralOptions;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class LineConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                    lineWidth: 1,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                line: {
                                    color: '',
                                    lineWidth: 1,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            line: {
                                                color: element.config.LineColor ? element.config.LineColor : '',
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.LineConfigsBuilder = LineConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class LoadingConfigBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _setLoadingConfig() {
                            this._loadingConfig = {
                                hideDuration: 0,
                                style: {
                                    backgroundColor: 'transparent',
                                    opacity: 1,
                                },
                                labelStyle: {
                                    display: 'none',
                                },
                            };
                        }
                        _setProviderOptions() {
                            this._chart.config.providerConfigs.loading = this._loadingConfig;
                        }
                        build() {
                            this._setLoadingConfig();
                            this._setProviderOptions();
                        }
                        get options() {
                            return this._loadingConfig;
                        }
                    }
                    ExposedConfigs.LoadingConfigBuilder = LoadingConfigBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class PieConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                pie: {
                                    innerSize: this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut
                                        ? this._chart.config.chart.innerSize
                                        : 0,
                                },
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                    dataLabels: {
                                        enabled: false,
                                    },
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                pie: {
                                    borderColor: '',
                                    borderWidth: 0,
                                    innerSize: this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut
                                        ? this._chart.config.chart.innerSize
                                        : 0,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            pie: {
                                                borderColor: element.config.LineColor ? element.config.LineColor : '',
                                                borderWidth: element.config.LineWidth ? element.config.LineWidth : 0,
                                                innerSize: this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut
                                                    ? this._chart.config.chart.innerSize
                                                    : 0,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.PieConfigsBuilder = PieConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class SplineConfigsBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _makePlotOptions() {
                            const cursorType = 'pointer';
                            const commonPlotOptions = {
                                series: {
                                    allowPointSelect: false,
                                    cursor: cursorType,
                                    lineWidth: 1,
                                },
                            };
                            let seriesStyling;
                            const resetStyling = {
                                spline: {
                                    color: '',
                                    lineWidth: 1,
                                },
                                series: {
                                    className: '',
                                    color: '',
                                    dataLabels: {
                                        enabled: false,
                                    },
                                    lineWidth: 1,
                                    marker: {
                                        enabled: true,
                                        fillColor: '',
                                        lineColor: '#ffffff',
                                        lineWidth: 0,
                                        symbol: undefined,
                                        radius: 4,
                                    },
                                    opacity: 1,
                                    showInLegend: true,
                                },
                            };
                            if (this._chart.features.seriesStyling === null) {
                                seriesStyling = resetStyling;
                            }
                            else if (this._chart.features.seriesStyling !== undefined) {
                                const listSeriesStyling = this._chart.features.seriesStyling.filter((Element) => Element.config.Binding === '');
                                if (listSeriesStyling.length > 0) {
                                    listSeriesStyling.forEach((element) => {
                                        seriesStyling = {
                                            spline: {
                                                color: element.config.LineColor ? element.config.LineColor : '',
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                            },
                                            series: {
                                                className: element.config.ExtendedClass ? element.config.ExtendedClass : '',
                                                color: element.config.FillColor ? element.config.FillColor : '',
                                                dataLabels: {
                                                    enabled: element.config.ShowDataPointValues,
                                                },
                                                lineWidth: element.config.LineWidth ? element.config.LineWidth : 1,
                                                marker: {
                                                    enabled: !element.config.MarkerHideMarker,
                                                    fillColor: element.config.MarkerFillColor ? element.config.MarkerFillColor : '',
                                                    lineColor: element.config.MarkerBorderColor
                                                        ? element.config.MarkerBorderColor
                                                        : '#ffffff',
                                                    lineWidth: element.config.MarkerBorderWidth
                                                        ? element.config.MarkerBorderWidth
                                                        : null,
                                                    radius: element.config.MarkerRadius ? element.config.MarkerRadius : 4,
                                                    symbol: element.config.MarkerSymbol ? element.config.MarkerSymbol : undefined,
                                                },
                                                opacity: element.config.Opacity ? element.config.Opacity : 1,
                                                showInLegend: element.config.ShowInLegend ? true : element.config.ShowInLegend,
                                            },
                                        };
                                    });
                                }
                                else {
                                    seriesStyling = resetStyling;
                                }
                            }
                            this._chart.config.providerConfigs.plotOptions = { ...commonPlotOptions, ...seriesStyling };
                            return this;
                        }
                        build() {
                            this._makePlotOptions();
                            super.build();
                        }
                    }
                    ExposedConfigs.SplineConfigsBuilder = SplineConfigsBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    class TooltipConfigBuilder extends ExposedConfigs.ConfigsBuilder {
                        constructor(chart) {
                            super(chart);
                        }
                        _setProviderOptions() {
                            this._chart.config.providerConfigs.tooltip = this._options;
                        }
                        build() {
                            if (this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Pie ||
                                this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut) {
                                this._options = {
                                    formatter() {
                                        const tooltipContent = this.point['custom']
                                            ? this.point['custom']
                                            : this.point.name + ': <b>' + this.y + '</b>';
                                        return tooltipContent;
                                    },
                                };
                            }
                            else {
                                const seriesLength = this._chart.config.providerConfigs.series.length;
                                this._options = {
                                    formatter() {
                                        const tooltipContent = this.point['custom']
                                            ? this.point['custom']
                                            : (seriesLength > 1 ? this.series.name + ', ' : '') + this.x + ':  <b>' + this.y + '</b>';
                                        return tooltipContent;
                                    },
                                };
                                if ((this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Area ||
                                    this._chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Line) &&
                                    this._chart.config.valuesType === OSFramework.Charts.Version2.Enum.ValuesType.Datetime) {
                                    this._options.formatter = function () {
                                        const date = new Date(this.x);
                                        const dateText = date.getUTCFullYear() +
                                            '-' +
                                            (date.getUTCMonth() + 1 < 10 ? '0' : '') +
                                            (date.getUTCMonth() + 1) +
                                            '-' +
                                            (date.getUTCDate() < 10 ? '0' : '') +
                                            date.getUTCDate();
                                        if (this.point) {
                                            return this.point['custom']
                                                ? this.point['custom']
                                                : (seriesLength > 1 ? this.series.name + ', ' : '') +
                                                    dateText +
                                                    ':  <b>' +
                                                    this.y +
                                                    '</b>';
                                        }
                                        else if (this.points) {
                                            return this.points.reduce(function (s, point) {
                                                return s + '<br/>' + point.series.name + ':  <b>' + point.y + '</b>';
                                            }, '<b>' + dateText + '</b>');
                                        }
                                    };
                                }
                            }
                            this._setProviderOptions();
                        }
                        get options() {
                            return this._options;
                        }
                    }
                    ExposedConfigs.TooltipConfigBuilder = TooltipConfigBuilder;
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    var Color;
                    (function (Color) {
                        class ColorConfigsBuilder extends Providers.Charts.HighCharts.Configs
                            .AbstractColorConfig {
                            _getColorsList(isTwoSeriesColors) {
                                return [
                                    isTwoSeriesColors ? Color.Enum.TwoSeriesColors.first : Color.Enum.TwelveSeriesColors.first,
                                    isTwoSeriesColors ? Color.Enum.TwoSeriesColors.second : Color.Enum.TwelveSeriesColors.second,
                                    Color.Enum.TwelveSeriesColors.third,
                                    Color.Enum.TwelveSeriesColors.fourth,
                                    Color.Enum.TwelveSeriesColors.fifth,
                                    Color.Enum.TwelveSeriesColors.sixth,
                                    Color.Enum.TwelveSeriesColors.seventh,
                                    Color.Enum.TwelveSeriesColors.eighth,
                                    Color.Enum.TwelveSeriesColors.ninth,
                                    Color.Enum.TwelveSeriesColors.tenth,
                                    Color.Enum.TwelveSeriesColors.eleventh,
                                    Color.Enum.TwelveSeriesColors.twelfth,
                                ];
                            }
                            setColorConfig() {
                                if (this.chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Pie ||
                                    this.chart.config.chart.type === OSFramework.Charts.Enum.ChartType.Donut) {
                                    this.colorConfig = this._getColorsList(this.chart.config.providerConfigs.series.find((serie) => serie.data.length < 3) !== undefined);
                                }
                                else {
                                    this.colorConfig = this._getColorsList(this.seriesLength < 3);
                                }
                            }
                            build() {
                                super.build();
                            }
                        }
                        Color.ColorConfigsBuilder = ColorConfigsBuilder;
                    })(Color = ExposedConfigs.Color || (ExposedConfigs.Color = {}));
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var ExposedConfigs;
                (function (ExposedConfigs) {
                    var Color;
                    (function (Color) {
                        var Enum;
                        (function (Enum) {
                            let TwoSeriesColors;
                            (function (TwoSeriesColors) {
                                TwoSeriesColors["first"] = "#4263EB";
                                TwoSeriesColors["second"] = "#F59F00";
                            })(TwoSeriesColors = Enum.TwoSeriesColors || (Enum.TwoSeriesColors = {}));
                            let TwelveSeriesColors;
                            (function (TwelveSeriesColors) {
                                TwelveSeriesColors["first"] = "#0D8091";
                                TwelveSeriesColors["second"] = "#74B816";
                                TwelveSeriesColors["third"] = "#4263EB";
                                TwelveSeriesColors["fourth"] = "#F59F00";
                                TwelveSeriesColors["fifth"] = "#C92A2A";
                                TwelveSeriesColors["sixth"] = "#37B24D";
                                TwelveSeriesColors["seventh"] = "#D6336C";
                                TwelveSeriesColors["eighth"] = "#087F5B";
                                TwelveSeriesColors["ninth"] = "#7048E8";
                                TwelveSeriesColors["tenth"] = "#F76707";
                                TwelveSeriesColors["eleventh"] = "#AE3EC9";
                                TwelveSeriesColors["twelfth"] = "#1A79CB";
                            })(TwelveSeriesColors = Enum.TwelveSeriesColors || (Enum.TwelveSeriesColors = {}));
                        })(Enum = Color.Enum || (Color.Enum = {}));
                    })(Color = ExposedConfigs.Color || (ExposedConfigs.Color = {}));
                })(ExposedConfigs = Version2.ExposedConfigs || (Version2.ExposedConfigs = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        class AbstractHighChartsAxis extends OSFramework.Charts.Version2.Feature.Axis.AbstractAxis {
                            updateAxisWithCustomConfigs(configs) {
                                switch (this._featureType) {
                                    case OSFramework.Charts.Version2.Feature.Enum.FeatureType.xAxis:
                                        this.chart.updateXAxis(Version2.Utils.Extensibility.MergeConfigsObjects(configs), this.config.UniqueId);
                                        break;
                                    case OSFramework.Charts.Version2.Feature.Enum.FeatureType.yAxis:
                                        this.chart.updateYAxis(Version2.Utils.Extensibility.MergeConfigsObjects(configs), this.config.UniqueId);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        Axis.AbstractHighChartsAxis = AbstractHighChartsAxis;
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        class AbstractHighChartsAxisConfig extends OSFramework.Charts.Version2.Feature.Axis.AbstractAxisConfigs {
                            constructor(config) {
                                super(config);
                            }
                            setFeatureProviderConfigs() {
                                const _featureProviderConfigs = {
                                    className: this.ExtendedClass,
                                    crosshair: this.Crosshair,
                                    labels: {
                                        format: `${this.ValuesPrefix}{text}${this.ValuesSuffix}`,
                                        style: {
                                            color: this.LabelColor,
                                            fontSize: this.LabelSize === 0 ? null : this.LabelSize.toString() + 'px',
                                        },
                                        rotation: this.LabelRotation,
                                    },
                                    gridLineColor: this.GridLinesColor,
                                    id: this.UniqueId,
                                    lineColor: this.LineColor,
                                    tickInterval: this.GridLineStep === 0 ? null : this.GridLineStep,
                                    title: {
                                        text: this.Title,
                                    },
                                    type: this.ValuesType,
                                    min: this.MinValue === 0 || !this.Visible ? null : this.MinValue,
                                    max: this.MaxValue === 0 || !this.Visible ? null : this.MaxValue,
                                    visible: this.Visible,
                                };
                                if (this.GridLinesWidth.trim() !== '') {
                                    _featureProviderConfigs['gridLineWidth'] = this.GridLinesWidth.trim();
                                }
                                if (this.LineWidth.trim() !== '') {
                                    _featureProviderConfigs['lineWidth'] = parseInt(this.LineWidth.trim());
                                }
                                return this.updateFeatureProviderConfigs(_featureProviderConfigs);
                            }
                        }
                        Axis.AbstractHighChartsAxisConfig = AbstractHighChartsAxisConfig;
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        let AxisFactory;
                        (function (AxisFactory) {
                            function MakeAxis(axisId, configs, type) {
                                switch (type) {
                                    case OSFramework.Charts.Version2.Feature.Enum.FeatureType.xAxis:
                                        return new Axis.X.HighChartsXAxis(axisId, configs);
                                    case OSFramework.Charts.Version2.Feature.Enum.FeatureType.yAxis:
                                        return new Axis.Y.HighChartsYAxis(axisId, configs);
                                    default:
                                        throw new Error(`There is no factory for this type of Axis (${type})`);
                                }
                            }
                            AxisFactory.MakeAxis = MakeAxis;
                        })(AxisFactory = Axis.AxisFactory || (Axis.AxisFactory = {}));
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        var X;
                        (function (X) {
                            class HighChartsXAxis extends Axis.AbstractHighChartsAxis {
                                constructor(uniqueId, configs) {
                                    super(uniqueId, new X.HighChartsXAxisConfig(configs), OSFramework.Charts.Version2.Feature.Enum.FeatureType.xAxis);
                                }
                                build() {
                                    super.build();
                                    super.finishBuild();
                                }
                                dispose() {
                                    super.dispose();
                                }
                                updateConfigs(configs) {
                                    super.updateConfigs(configs);
                                }
                            }
                            X.HighChartsXAxis = HighChartsXAxis;
                        })(X = Axis.X || (Axis.X = {}));
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        var X;
                        (function (X) {
                            class HighChartsXAxisConfig extends Axis.AbstractHighChartsAxisConfig {
                                constructor(config) {
                                    super(config);
                                }
                            }
                            X.HighChartsXAxisConfig = HighChartsXAxisConfig;
                        })(X = Axis.X || (Axis.X = {}));
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        var Y;
                        (function (Y) {
                            class HighChartsYAxis extends Axis.AbstractHighChartsAxis {
                                constructor(uniqueId, configs) {
                                    super(uniqueId, new Y.HighChartsYAxisConfig(configs), OSFramework.Charts.Version2.Feature.Enum.FeatureType.yAxis);
                                }
                                build() {
                                    super.build();
                                    super.finishBuild();
                                }
                                dispose() {
                                    super.dispose();
                                }
                                updateConfigs(configs) {
                                    super.updateConfigs(configs);
                                }
                            }
                            Y.HighChartsYAxis = HighChartsYAxis;
                        })(Y = Axis.Y || (Axis.Y = {}));
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Axis;
                    (function (Axis) {
                        var Y;
                        (function (Y) {
                            class HighChartsYAxisConfig extends Axis.AbstractHighChartsAxisConfig {
                                constructor(config) {
                                    super(config);
                                }
                            }
                            Y.HighChartsYAxisConfig = HighChartsYAxisConfig;
                        })(Y = Axis.Y || (Axis.Y = {}));
                    })(Axis = Feature.Axis || (Feature.Axis = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Export;
                    (function (Export) {
                        class HighChartsExport extends OSFramework.Charts.Version2.Feature.Export
                            .AbstractExport {
                            constructor(uniqueId, configs) {
                                super(uniqueId, new Export.HighChartsExportConfigs(configs));
                            }
                            build() {
                                super.build();
                                super.finishBuild();
                            }
                        }
                        Export.HighChartsExport = HighChartsExport;
                    })(Export = Feature.Export || (Feature.Export = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Export;
                    (function (Export) {
                        class HighChartsExportConfigs extends OSFramework.Charts.Version2.Feature.Export.AbstractExportConfigs {
                            constructor(config) {
                                super(config);
                            }
                            _addMenuOption(itemOption, providerOptions, configOption) {
                                if ((configOption && configOption.enabled) || itemOption === "separator") {
                                    providerOptions.buttons.contextButton.menuItems.push(itemOption);
                                }
                                if (configOption && configOption.label) {
                                    const menuItem = providerOptions.menuItemDefinitions[itemOption] ?? {};
                                    menuItem.text = configOption.label;
                                    providerOptions.menuItemDefinitions[itemOption] = menuItem;
                                }
                            }
                            setFeatureProviderConfigs() {
                                const hasFullScreenOrPrint = this.viewInFullScreen.enabled || this.printChart.enabled;
                                const hasDownloads = this.downloadPNG.enabled ||
                                    this.downloadJPEG.enabled ||
                                    this.downloadPDF.enabled ||
                                    this.downloadSVG.enabled;
                                const hasDataFiles = this.downloadCSV.enabled || this.downloadXLS.enabled;
                                const isExportMenuEnabled = hasFullScreenOrPrint || hasDownloads || hasDataFiles;
                                const HcExportConfigs = {
                                    buttons: {
                                        contextButton: {
                                            menuItems: [],
                                            menuClassName: this.menuExtendedClass,
                                            className: this.extendedClass,
                                        },
                                    },
                                    enabled: isExportMenuEnabled,
                                    filename: this.filename,
                                    menuItemDefinitions: {},
                                };
                                if (isExportMenuEnabled) {
                                    if (hasFullScreenOrPrint) {
                                        this._addMenuOption("viewFullscreen", HcExportConfigs, this.viewInFullScreen);
                                        this._addMenuOption("printChart", HcExportConfigs, this.printChart);
                                        if (hasDownloads || hasDataFiles) {
                                            this._addMenuOption("separator", HcExportConfigs);
                                        }
                                    }
                                    if (hasDownloads) {
                                        this._addMenuOption("downloadPNG", HcExportConfigs, this.downloadPNG);
                                        this._addMenuOption("downloadJPEG", HcExportConfigs, this.downloadJPEG);
                                        this._addMenuOption("downloadPDF", HcExportConfigs, this.downloadPDF);
                                        this._addMenuOption("downloadSVG", HcExportConfigs, this.downloadSVG);
                                        if (hasDataFiles) {
                                            this._addMenuOption("separator", HcExportConfigs);
                                        }
                                    }
                                    if (hasDataFiles) {
                                        this._addMenuOption("downloadCSV", HcExportConfigs, this.downloadCSV);
                                        this._addMenuOption("downloadXLS", HcExportConfigs, this.downloadXLS);
                                    }
                                }
                                return HcExportConfigs;
                            }
                        }
                        Export.HighChartsExportConfigs = HighChartsExportConfigs;
                    })(Export = Feature.Export || (Feature.Export = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Legend;
                    (function (Legend) {
                        class HighChartLegend extends OSFramework.Charts.Version2.Feature.Legend
                            .AbstractLegend {
                            constructor(uniqueId, configs) {
                                super(uniqueId, new Legend.HighChartsLegendConfig(configs));
                            }
                            build() {
                                super.build();
                                super.finishBuild();
                            }
                            dispose() {
                                super.dispose();
                            }
                            updateConfigs(configs) {
                                super.updateConfigs(configs);
                            }
                        }
                        Legend.HighChartLegend = HighChartLegend;
                    })(Legend = Feature.Legend || (Feature.Legend = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Legend;
                    (function (Legend) {
                        class HighChartsLegendConfig extends OSFramework.Charts.Version2.Feature.Legend.AbstractLegendConfigs {
                            constructor(config) {
                                super(config);
                            }
                            _getLegendAlign() {
                                let _legendAlign;
                                switch (this.Position) {
                                    case OSFramework.Charts.Enum.Legend.Position.BottomLeft:
                                    case OSFramework.Charts.Enum.Legend.Position.Left:
                                    case OSFramework.Charts.Enum.Legend.Position.TopLeft:
                                        _legendAlign = OSFramework.Charts.Enum.Legend.AlignValues.Left;
                                        break;
                                    case OSFramework.Charts.Enum.Legend.Position.BottomRight:
                                    case OSFramework.Charts.Enum.Legend.Position.Right:
                                    case OSFramework.Charts.Enum.Legend.Position.TopRight:
                                        _legendAlign = OSFramework.Charts.Enum.Legend.AlignValues.Right;
                                        break;
                                    default:
                                        _legendAlign = OSFramework.Charts.Enum.Legend.AlignValues.Center;
                                        break;
                                }
                                return _legendAlign;
                            }
                            _getLegendVerticalAlign() {
                                let _legendVerticalAlign;
                                switch (this.Position) {
                                    case OSFramework.Charts.Enum.Legend.Position.Top:
                                    case OSFramework.Charts.Enum.Legend.Position.TopLeft:
                                    case OSFramework.Charts.Enum.Legend.Position.TopRight:
                                        _legendVerticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Top;
                                        break;
                                    case OSFramework.Charts.Enum.Legend.Position.Center:
                                    case OSFramework.Charts.Enum.Legend.Position.Left:
                                    case OSFramework.Charts.Enum.Legend.Position.Right:
                                        _legendVerticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Middle;
                                        break;
                                    default:
                                        _legendVerticalAlign = OSFramework.Charts.Enum.Legend.AlignValues.Bottom;
                                        break;
                                }
                                return _legendVerticalAlign;
                            }
                            setFeatureProviderConfigs() {
                                const _featureProviderConfigs = {
                                    align: this._getLegendAlign(),
                                    backgroundColor: this.BackgroundColor,
                                    floating: this.Floating,
                                    itemDistance: this.ItemsDistance,
                                    className: this.ExtendedClass,
                                    enabled: this.Visible,
                                    layout: this.Layout === '' ? OSFramework.Charts.Version2.Enum.LegendLayout.Horizontal : this.Layout,
                                    verticalAlign: this._getLegendVerticalAlign(),
                                };
                                return this.updateFeatureProviderConfigs(_featureProviderConfigs);
                            }
                        }
                        Legend.HighChartsLegendConfig = HighChartsLegendConfig;
                    })(Legend = Feature.Legend || (Feature.Legend = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Series;
                    (function (Series) {
                        class AbstractHighChartsSeriesStyling extends OSFramework.Charts.Version2.Feature.Series.AbstractSeriesStyling {
                            constructor(uniqueId, configs) {
                                super(uniqueId, configs);
                            }
                        }
                        Series.AbstractHighChartsSeriesStyling = AbstractHighChartsSeriesStyling;
                    })(Series = Feature.Series || (Feature.Series = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Series;
                    (function (Series) {
                        class HighChartsSeriesStyling extends Series.AbstractHighChartsSeriesStyling {
                            constructor(uniqueId, configs) {
                                super(uniqueId, new Series.HighChartsSeriesStylingConfig(configs));
                            }
                            build() {
                                super.build();
                                super.finishBuild();
                            }
                            dispose() {
                                super.dispose();
                            }
                            updateConfigs(configs) {
                                super.updateConfigs(configs);
                            }
                        }
                        Series.HighChartsSeriesStyling = HighChartsSeriesStyling;
                    })(Series = Feature.Series || (Feature.Series = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Feature;
                (function (Feature) {
                    var Series;
                    (function (Series) {
                        class HighChartsSeriesStylingConfig extends OSFramework.Charts.Version2.Feature.Series.AbstractSeriesStylingConfigs {
                            constructor(config) {
                                super(config);
                            }
                            setFeatureProviderConfigs() {
                                return;
                            }
                        }
                        Series.HighChartsSeriesStylingConfig = HighChartsSeriesStylingConfig;
                    })(Series = Feature.Series || (Feature.Series = {}));
                })(Feature = Version2.Feature || (Version2.Feature = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
var Providers;
(function (Providers) {
    var Charts;
    (function (Charts) {
        var HighCharts;
        (function (HighCharts) {
            var Version2;
            (function (Version2) {
                var Utils;
                (function (Utils) {
                    var Extensibility;
                    (function (Extensibility) {
                        function _cleanBoolean(value) {
                            switch (value) {
                                case 'True':
                                    return true;
                                case 'False':
                                    return false;
                                default:
                                    return value;
                            }
                        }
                        function MergeConfigsObjects(configs) {
                            let finalConfigs = {};
                            for (const arrayItem of configs) {
                                const keys = arrayItem.PropertyPathList;
                                let object;
                                let auxKey;
                                for (let i = keys.length; i >= 0; i--) {
                                    const aux = object;
                                    if (i === keys.length) {
                                        object = _cleanBoolean(arrayItem.Value);
                                    }
                                    else {
                                        object = {};
                                        object[arrayItem.PropertyPathList[i]] = _cleanBoolean(aux);
                                    }
                                }
                                for (const key in arrayItem.PropertyPathList) {
                                    if (finalConfigs[arrayItem.PropertyPathList[key]] !== undefined) {
                                        auxKey = arrayItem.PropertyPathList[key];
                                    }
                                    else {
                                        break;
                                    }
                                }
                                if (auxKey !== undefined) {
                                    finalConfigs = HighCharts.Utils.Merge(finalConfigs, object);
                                }
                                else {
                                    finalConfigs[arrayItem.PropertyPathList[0]] = object[arrayItem.PropertyPathList[0]];
                                }
                            }
                            return finalConfigs;
                        }
                        Extensibility.MergeConfigsObjects = MergeConfigsObjects;
                    })(Extensibility = Utils.Extensibility || (Utils.Extensibility = {}));
                })(Utils = Version2.Utils || (Version2.Utils = {}));
            })(Version2 = HighCharts.Version2 || (HighCharts.Version2 = {}));
        })(HighCharts = Charts.HighCharts || (Charts.HighCharts = {}));
    })(Charts = Providers.Charts || (Providers.Charts = {}));
})(Providers || (Providers = {}));
