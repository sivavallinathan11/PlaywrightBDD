﻿define("Common_CW.controller$Alert", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Alert.JavaScript_triggerAlertJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Alert_JavaScript_triggerAlertJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.alert$Action = function (textToSpeechIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Alert$vars"))());
vars.value.textToSpeechInLocal = textToSpeechIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:6XdKUYQyS0i1AjQAvgy4hA:/ClientActionFlows.6XdKUYQyS0i1AjQAvgy4hA:79mazDHXU2yBV4xxmTAvzA", "Common_CW", "Alert", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:44z8jU_2ZUW0TVKfM8zbww", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jqoqyYG8Hk6LNDRP5CJRfg", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_Alert_JavaScript_triggerAlertJS, "JavaScript_triggerAlert", "Alert", {
TextToSpeech: OS.DataConversion.JSNodeParamConverter.to(vars.value.textToSpeechInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+OQSaQ4_KEubbOMEiFcYMg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:6XdKUYQyS0i1AjQAvgy4hA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Alert$vars", [{
name: "TextToSpeech",
attrName: "textToSpeechInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.alert$Action = function (textToSpeechIn) {
textToSpeechIn = (textToSpeechIn === undefined) ? "" : textToSpeechIn;
return controller.executeActionInsideJSNode(Common_CWController.default.alert$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(textToSpeechIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$Alert.JavaScript_triggerAlertJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
document.querySelector('[alertholder]').innerHTML=$parameters.TextToSpeech;
document.querySelector('[alertholder]').classList.remove('hidden');

setTimeout(function(){
    if(document.querySelector('input.not-valid, .not-valid select')){
        document.querySelector('input.not-valid, .not-valid select').focus();
    }
}, 1000);

setTimeout(function(){
    document.querySelector('[alertholder]').classList.add('hidden');
}, 5000);
};
});

define("Common_CW.controller$Check_AddRemoveUser", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_AddRemoveUser.AddRemoveUserJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_AddRemoveUser_AddRemoveUserJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_AddRemoveUser$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var addRemoveUserJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_AddRemoveUser$outVars"))());
varBag.callContext = callContext;
varBag.addRemoveUserJSResult = addRemoveUserJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:HsmvnkgxH0SH_rxRo7+4RA:/ClientActionFlows.HsmvnkgxH0SH_rxRo7+4RA:QYC+q_bOvvtOC6ZMXfqxyQ", "Common_CW", "Check_AddRemoveUser", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qdGOHSWYUUOKcNwUjbG+kw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:U4oTFjNt+U+3GKGiBIhHOw", callContext.id);
addRemoveUserJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_AddRemoveUser_AddRemoveUserJS, "AddRemoveUser", "Check_AddRemoveUser", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_AddRemoveUser$addRemoveUserJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_8_AddRemoveUsers: Common_CWController.default.roles.OA_8_AddRemoveUsers.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HAd_hRx4h0yJ+ZSxDkLm6w", callContext.id);
// HasAccess = AddRemoveUser.HasAccess
outVars.value.hasAccessOut = addRemoveUserJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Pl6VqO+G_k6axpT2EJRF4Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:HsmvnkgxH0SH_rxRo7+4RA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_AddRemoveUser$addRemoveUserJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_AddRemoveUser$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_AddRemoveUser$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_AddRemoveUser$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_AddRemoveUser.AddRemoveUserJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_8_AddRemoveUsers)
};
});

define("Common_CW.controller$Check_BatchProcesses", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_BatchProcesses.HasAnyBatchProcessRolesJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_BatchProcesses_HasAnyBatchProcessRolesJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_BatchProcesses$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var hasAnyBatchProcessRolesJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_BatchProcesses$outVars"))());
varBag.callContext = callContext;
varBag.hasAnyBatchProcessRolesJSResult = hasAnyBatchProcessRolesJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ifs5da_3YkurPC27raIFEQ:/ClientActionFlows.ifs5da_3YkurPC27raIFEQ:RC_qUEEIvz51TbVrmgXnuA", "Common_CW", "Check_BatchProcesses", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ss6B+8qotECvCRCKcFpCnA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Zw87ccrgg0i0dO1jcz2I8A", callContext.id);
hasAnyBatchProcessRolesJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_BatchProcesses_HasAnyBatchProcessRolesJS, "HasAnyBatchProcessRoles", "Check_BatchProcesses", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_BatchProcesses$hasAnyBatchProcessRolesJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
BP_1_ClaimServicesAustraliaMedicareRebate: Common_CWController.default.roles.BP_1_ClaimServicesAustraliaMedicareRebate.roleKey,
BP_2_LHCReset: Common_CWController.default.roles.BP_2_LHCReset.roleKey,
BP_3_ArrearsManagement: Common_CWController.default.roles.BP_3_ArrearsManagement.roleKey,
BP_4_SendLHCStatement: Common_CWController.default.roles.BP_4_SendLHCStatement.roleKey,
BP_5_SendMembershipCards: Common_CWController.default.roles.BP_5_SendMembershipCards.roleKey,
BP_6_SendCommunication_General_: Common_CWController.default.roles.BP_6_SendCommunication_General_.roleKey,
BP_7_SendRateChangeNotice: Common_CWController.default.roles.BP_7_SendRateChangeNotice.roleKey,
BP_8_TerminatePolicy: Common_CWController.default.roles.BP_8_TerminatePolicy.roleKey,
BP_9_ReactivatePolicy: Common_CWController.default.roles.BP_9_ReactivatePolicy.roleKey,
BP_10_TerminateMembers: Common_CWController.default.roles.BP_10_TerminateMembers.roleKey,
BP_11_ReactivateMembers: Common_CWController.default.roles.BP_11_ReactivateMembers.roleKey,
BP_12_CancelLeads: Common_CWController.default.roles.BP_12_CancelLeads.roleKey,
BP_13_ApplyFlag: Common_CWController.default.roles.BP_13_ApplyFlag.roleKey,
BP_14_ApplyNote: Common_CWController.default.roles.BP_14_ApplyNote.roleKey,
BP_15_AdjustPaidToDateTheoreticalPaidToDate: Common_CWController.default.roles.BP_15_AdjustPaidToDateTheoreticalPaidToDate.roleKey,
BP_16_CancelBatchProcessSendMembershipCards: Common_CWController.default.roles.BP_16_CancelBatchProcessSendMembershipCards.roleKey,
BP_17_AdvancedFilterBulkProcess: Common_CWController.default.roles.BP_17_AdvancedFilterBulkProcess.roleKey,
BP_18_ApproveBatchProcess: Common_CWController.default.roles.BP_18_ApproveBatchProcess.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:mZRQfBvDsUqG6CfdWRy9yA", callContext.id);
// HasAccess = HasAnyBatchProcessRoles.HasAccess
outVars.value.hasAccessOut = hasAnyBatchProcessRolesJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:oSrnwQmVXkmb4mTBj8tLQw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ifs5da_3YkurPC27raIFEQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_BatchProcesses$hasAnyBatchProcessRolesJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_BatchProcesses$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_BatchProcesses$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_BatchProcesses$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_BatchProcesses.HasAnyBatchProcessRolesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.BP_1_ClaimServicesAustraliaMedicareRebate) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_2_LHCReset) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_3_ArrearsManagement) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_4_SendLHCStatement) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_5_SendMembershipCards) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_6_SendCommunication_General_) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_7_SendRateChangeNotice) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_8_TerminatePolicy) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_9_ReactivatePolicy) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_10_TerminateMembers) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_11_ReactivateMembers) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_12_CancelLeads) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_13_ApplyFlag) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_14_ApplyNote) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_15_AdjustPaidToDateTheoreticalPaidToDate) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_16_CancelBatchProcessSendMembershipCards) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_17_AdvancedFilterBulkProcess) ||
                        $public.Security.checkIfCurrentUserHasRole($roles.BP_18_ApproveBatchProcess)
};
});

define("Common_CW.controller$Check_ChangeDueDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_ChangeDueDate.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_ChangeDueDate_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_ChangeDueDate$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_ChangeDueDate$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Plg4Gb8qD0ekz2R7lcXAHg:/ClientActionFlows.Plg4Gb8qD0ekz2R7lcXAHg:xAxo7hWgD6rvw5+sfdUsXw", "Common_CW", "Check_ChangeDueDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7ra3ZCRhYUq+K9lxIl9A8g", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3cBwxW0pMkK0iolPBIMgEA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ChangeDueDate_JavaScriptJS, "JavaScript", "Check_ChangeDueDate", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ChangeDueDate$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_13_Changeduedate: Common_CWController.default.roles.SP_13_Changeduedate.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ridD2ILauk6F4hSWlAToaA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:N93ocO9wIUKgIhfg9uAgrQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Plg4Gb8qD0ekz2R7lcXAHg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ChangeDueDate$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ChangeDueDate$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_ChangeDueDate$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_ChangeDueDate$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_ChangeDueDate.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_13_Changeduedate)
};
});

define("Common_CW.controller$Check_ConfigureAudit", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_ConfigureAudit.HasSystemAdminJS", "Common_CW.controller$Check_ConfigureAudit.HasConfigureFundJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_ConfigureAudit_HasSystemAdminJS, Common_CW_controller_Check_ConfigureAudit_HasConfigureFundJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_ConfigureAudit$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var hasSystemAdminJSResult = new OS.DataTypes.VariableHolder();
var hasConfigureFundJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureAudit$outVars"))());
varBag.callContext = callContext;
varBag.hasSystemAdminJSResult = hasSystemAdminJSResult;
varBag.hasConfigureFundJSResult = hasConfigureFundJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Z4rw9w7O50a2mOWYwMLdPg:/ClientActionFlows.Z4rw9w7O50a2mOWYwMLdPg:PK5jS0K992T_Gq4+bnMMjA", "Common_CW", "Check_ConfigureAudit", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gOrEJ4akzkCc7odmHbx2bA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:UDEE0S3_y0CrgKKR_QfvbQ", callContext.id);
hasConfigureFundJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ConfigureAudit_HasConfigureFundJS, "HasConfigureFund", "Check_ConfigureAudit", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureAudit$hasConfigureFundJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_3_ViewUserAuditLog: Common_CWController.default.roles.OA_3_ViewUserAuditLog.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rErZfyo3Xk+JHKlZsw7Xqw", callContext.id);
hasSystemAdminJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ConfigureAudit_HasSystemAdminJS, "HasSystemAdmin", "Check_ConfigureAudit", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureAudit$hasSystemAdminJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SystemAdministrator: Common_CWController.default.roles.SystemAdministrator.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+wI22EI_DUiIHfHVBEJeXg", callContext.id);
// HasAccess = HasConfigureFund.HasAccess or HasSystemAdmin.HasAccess
outVars.value.hasAccessOut = (hasConfigureFundJSResult.value.hasAccessOut || hasSystemAdminJSResult.value.hasAccessOut);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jVzW8FIYwketU2LgxcKiug", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Z4rw9w7O50a2mOWYwMLdPg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureAudit$hasSystemAdminJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureAudit$hasConfigureFundJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureAudit$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_ConfigureAudit$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_ConfigureAudit$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_ConfigureAudit.HasSystemAdminJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SystemAdministrator)
};
});
define("Common_CW.controller$Check_ConfigureAudit.HasConfigureFundJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_3_ViewUserAuditLog)
};
});

define("Common_CW.controller$Check_ConfigureFund", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_ConfigureFund.HasConfigureFundJS", "Common_CW.controller$Check_ConfigureFund.HasSystemAdminJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_ConfigureFund_HasConfigureFundJS, Common_CW_controller_Check_ConfigureFund_HasSystemAdminJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_ConfigureFund$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var hasConfigureFundJSResult = new OS.DataTypes.VariableHolder();
var hasSystemAdminJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureFund$outVars"))());
varBag.callContext = callContext;
varBag.hasConfigureFundJSResult = hasConfigureFundJSResult;
varBag.hasSystemAdminJSResult = hasSystemAdminJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:PduXsI9S30WPb60WJ3FhBA:/ClientActionFlows.PduXsI9S30WPb60WJ3FhBA:3c2V5aTYazogVHIwexFHsw", "Common_CW", "Check_ConfigureFund", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:VVB1T6KK4U+9XSlvfJRofA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:g1TJI43mWEy+EamF0lknnQ", callContext.id);
hasConfigureFundJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ConfigureFund_HasConfigureFundJS, "HasConfigureFund", "Check_ConfigureFund", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureFund$hasConfigureFundJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_5_ManageFundSetupAndBranding: Common_CWController.default.roles.OA_5_ManageFundSetupAndBranding.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XepnOByMeEadygqcrJKZGw", callContext.id);
hasSystemAdminJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ConfigureFund_HasSystemAdminJS, "HasSystemAdmin", "Check_ConfigureFund", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ConfigureFund$hasSystemAdminJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SystemAdministrator: Common_CWController.default.roles.SystemAdministrator.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gP3ZKZ9MPky_i4j2N8Hikw", callContext.id);
// HasAccess = HasConfigureFund.HasAccess or HasSystemAdmin.HasAccess
outVars.value.hasAccessOut = (hasConfigureFundJSResult.value.hasAccessOut || hasSystemAdminJSResult.value.hasAccessOut);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:QEbE9t0Y_UCdgDy+OaM5kw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:PduXsI9S30WPb60WJ3FhBA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureFund$hasConfigureFundJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureFund$hasSystemAdminJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ConfigureFund$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_ConfigureFund$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_ConfigureFund$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_ConfigureFund.HasConfigureFundJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_5_ManageFundSetupAndBranding)
};
});
define("Common_CW.controller$Check_ConfigureFund.HasSystemAdminJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SystemAdministrator)
};
});

define("Common_CW.controller$Check_CreateModifyRoles", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_CreateModifyRoles.CreateModifyRolesPermissionsJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_CreateModifyRoles_CreateModifyRolesPermissionsJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_CreateModifyRoles$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var createModifyRolesPermissionsJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_CreateModifyRoles$outVars"))());
varBag.callContext = callContext;
varBag.createModifyRolesPermissionsJSResult = createModifyRolesPermissionsJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:mnB2wNmSn0OYqEWegJMjEA:/ClientActionFlows.mnB2wNmSn0OYqEWegJMjEA:_RpL7eo5IGfhM08ZJJ7bYQ", "Common_CW", "Check_CreateModifyRoles", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tDSIGYA0SE2qBSL9QG0V8A", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:g3Ewpcjtbk+7GoEI0_kJSw", callContext.id);
createModifyRolesPermissionsJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_CreateModifyRoles_CreateModifyRolesPermissionsJS, "CreateModifyRolesPermissions", "Check_CreateModifyRoles", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_CreateModifyRoles$createModifyRolesPermissionsJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_6_CreateModifyRolesPermissions: Common_CWController.default.roles.OA_6_CreateModifyRolesPermissions.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rSsQmzDzmkSNC4FiT7Hzww", callContext.id);
// HasAccess = CreateModifyRolesPermissions.HasAccess
outVars.value.hasAccessOut = createModifyRolesPermissionsJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:o0JPpZE_eEyMc6Y7hhs8QQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:mnB2wNmSn0OYqEWegJMjEA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_CreateModifyRoles$createModifyRolesPermissionsJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_CreateModifyRoles$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_CreateModifyRoles$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_CreateModifyRoles$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_CreateModifyRoles.CreateModifyRolesPermissionsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_6_CreateModifyRolesPermissions)
};
});

define("Common_CW.controller$Check_CreateModifyTeams", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_CreateModifyTeams.CreateModifyteamsPermissionsJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_CreateModifyTeams_CreateModifyteamsPermissionsJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_CreateModifyTeams$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var createModifyteamsPermissionsJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_CreateModifyTeams$outVars"))());
varBag.callContext = callContext;
varBag.createModifyteamsPermissionsJSResult = createModifyteamsPermissionsJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:UrKrZFyOh0qXhHKJ14JDAA:/ClientActionFlows.UrKrZFyOh0qXhHKJ14JDAA:MXduwUEC7uY47Ze91G5iVg", "Common_CW", "Check_CreateModifyTeams", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:yqOfpoYsUUODn4Dw6F_FCQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+EL3yZx44EmY4RuARWhRgg", callContext.id);
createModifyteamsPermissionsJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_CreateModifyTeams_CreateModifyteamsPermissionsJS, "CreateModifyteamsPermissions", "Check_CreateModifyTeams", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_CreateModifyTeams$createModifyteamsPermissionsJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_7_CreateModifyteams: Common_CWController.default.roles.OA_7_CreateModifyteams.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+msO5GUTcUW2b24PVSwdrg", callContext.id);
// HasAccess = CreateModifyteamsPermissions.HasAccess
outVars.value.hasAccessOut = createModifyteamsPermissionsJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xEg+mf2LL0axp7NScyTYtw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:UrKrZFyOh0qXhHKJ14JDAA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_CreateModifyTeams$createModifyteamsPermissionsJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_CreateModifyTeams$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_CreateModifyTeams$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_CreateModifyTeams$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_CreateModifyTeams.CreateModifyteamsPermissionsJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_7_CreateModifyteams)
};
});

define("Common_CW.controller$Check_HAMBSAdmin", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_HAMBSAdmin.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_HAMBSAdmin_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_HAMBSAdmin$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_HAMBSAdmin$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:cyNxb2d_Y0uIB0I5xyNXrw:/ClientActionFlows.cyNxb2d_Y0uIB0I5xyNXrw:dVMGT12QSjosUGYtn2MyWA", "Common_CW", "Check_HAMBSAdmin", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rX2MV004OEqErt8SbKLMRA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+JVpM_19ZUKP7X7W7LfH7A", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_HAMBSAdmin_JavaScriptJS, "JavaScript", "Check_HAMBSAdmin", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_HAMBSAdmin$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
HAMBSAdmin: Common_CWController.default.roles.HAMBSAdmin.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3aQmcMl_qEyEp0sxYFfy2Q", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:d1yw+gS0hE+Y4dK1MLOPoA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:cyNxb2d_Y0uIB0I5xyNXrw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_HAMBSAdmin$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_HAMBSAdmin$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_HAMBSAdmin$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_HAMBSAdmin$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_HAMBSAdmin.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.HAMBSAdmin)
};
});

define("Common_CW.controller$Check_MM_CreateEditJoinDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_CreateEditJoinDate.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_CreateEditJoinDate_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_CreateEditJoinDate$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_CreateEditJoinDate$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:qlWB58c1ekCCdT1bF67BRw:/ClientActionFlows.qlWB58c1ekCCdT1bF67BRw:6bzUMUvtR6eN9rO5IbKu5g", "Common_CW", "Check_MM_CreateEditJoinDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jiQoAkq0LEyAT4n2tBD3wA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:P2+sPtXGaEuY28YhWcgS1g", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_CreateEditJoinDate_JavaScriptJS, "JavaScript", "Check_MM_CreateEditJoinDate", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_CreateEditJoinDate$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_2_CreateEditJoinDate: Common_CWController.default.roles.MM_2_CreateEditJoinDate.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:X6Y0O04lKEuNnMA3k7HERA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:R9Sftlx4s0eKIp3FYRS9bg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:qlWB58c1ekCCdT1bF67BRw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_CreateEditJoinDate$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_CreateEditJoinDate$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_CreateEditJoinDate$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_CreateEditJoinDate$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_CreateEditJoinDate.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_2_CreateEditJoinDate)
};
});

define("Common_CW.controller$Check_MM_CreateModifyMember_DEPRECATED", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_CreateModifyMember_DEPRECATED.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_CreateModifyMember_DEPRECATED_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_CreateModifyMember_DEPRECATED$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_CreateModifyMember_DEPRECATED$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:eC7bZMNyfESW6DQdvtnFug:/ClientActionFlows.eC7bZMNyfESW6DQdvtnFug:5hvZmsV2NvRbb5KkBV46Pg", "Common_CW", "Check_MM_CreateModifyMember_DEPRECATED", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tFyhtt0_e06ipEewhU3upg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:IyJhLlibt0+pPlzxGvZJAA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_CreateModifyMember_DEPRECATED_JavaScriptJS, "JavaScript", "Check_MM_CreateModifyMember_DEPRECATED", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_CreateModifyMember_DEPRECATED$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_1_CreateModifyMember: Common_CWController.default.roles.MM_1_CreateModifyMember.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:aW9zHdgzvEOq5l6MMZ5mpA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jLopRp2c+E+VSq4ePm8Wbg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:eC7bZMNyfESW6DQdvtnFug", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_CreateModifyMember_DEPRECATED$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_CreateModifyMember_DEPRECATED$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_CreateModifyMember_DEPRECATED$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_CreateModifyMember_DEPRECATED$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_CreateModifyMember_DEPRECATED.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_1_CreateModifyMember)
};
});

define("Common_CW.controller$Check_MM_EditDependentOverride", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_EditDependentOverride.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_EditDependentOverride_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_EditDependentOverride$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditDependentOverride$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:viQY6Nen+0+JZBhXZN018Q:/ClientActionFlows.viQY6Nen+0+JZBhXZN018Q:Q6mYhIksYsfwluYRHMSjSg", "Common_CW", "Check_MM_EditDependentOverride", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5ATctMNMa0G0GUVR6QvDSA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:L+KhLeFJkU+xYTVRqI77_A", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_EditDependentOverride_JavaScriptJS, "JavaScript", "Check_MM_EditDependentOverride", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditDependentOverride$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_6_EditDependentOverride: Common_CWController.default.roles.MM_6_EditDependentOverride.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_3Oiw0bvdE+EWOiXedWEfA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:RxEbBJ1Z8k6Y484s0gGJuQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:viQY6Nen+0+JZBhXZN018Q", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditDependentOverride$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditDependentOverride$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_EditDependentOverride$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_EditDependentOverride$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_EditDependentOverride.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_6_EditDependentOverride)
};
});

define("Common_CW.controller$Check_MM_EditHospWaitExemptionUsedDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_EditHospWaitExemptionUsedDate.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_EditHospWaitExemptionUsedDate_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_EditHospWaitExemptionUsedDate$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditHospWaitExemptionUsedDate$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:YPen7BYI2UOSY3+E+z+rCw:/ClientActionFlows.YPen7BYI2UOSY3+E+z+rCw:sfPY9CIFrzzi5_NMCYQ1uw", "Common_CW", "Check_MM_EditHospWaitExemptionUsedDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Tnbak0DAOku1MreBr_Igng", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2_HzkDE23UeaXpxGSnpTXA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_EditHospWaitExemptionUsedDate_JavaScriptJS, "JavaScript", "Check_MM_EditHospWaitExemptionUsedDate", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditHospWaitExemptionUsedDate$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_11_EditHospWaitExemptionUsedDate: Common_CWController.default.roles.MM_11_EditHospWaitExemptionUsedDate.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:V5VwuNh6U0q6taAJBJvb1A", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:S4mclwrXtUWstB3jZVn0Ig", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:YPen7BYI2UOSY3+E+z+rCw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditHospWaitExemptionUsedDate$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditHospWaitExemptionUsedDate$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_EditHospWaitExemptionUsedDate$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_EditHospWaitExemptionUsedDate$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_EditHospWaitExemptionUsedDate.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_11_EditHospWaitExemptionUsedDate)
};
});

define("Common_CW.controller$Check_MM_EditLHCEntryAge", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_EditLHCEntryAge.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_EditLHCEntryAge_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_EditLHCEntryAge$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditLHCEntryAge$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:uQQYT4VzwUuvCEidKg9Txw:/ClientActionFlows.uQQYT4VzwUuvCEidKg9Txw:x0R+YwAbnyr_odHAGBzCEw", "Common_CW", "Check_MM_EditLHCEntryAge", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:512kdcDCDU+ZX6o740PEaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:abT8rk0oykSNMOWXVLc6pg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_EditLHCEntryAge_JavaScriptJS, "JavaScript", "Check_MM_EditLHCEntryAge", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditLHCEntryAge$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_7_EditLHCEntryAge: Common_CWController.default.roles.MM_7_EditLHCEntryAge.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TavWoErHn0Cc9c1N8qFeqA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0oAfPA30V0Oy+jhwoeD+ew", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:uQQYT4VzwUuvCEidKg9Txw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditLHCEntryAge$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditLHCEntryAge$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_EditLHCEntryAge$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_EditLHCEntryAge$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_EditLHCEntryAge.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_7_EditLHCEntryAge)
};
});

define("Common_CW.controller$Check_MM_EditPEAOverride", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_EditPEAOverride.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_EditPEAOverride_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_EditPEAOverride$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditPEAOverride$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:vWKldSsMnEq2uZ3+g89okA:/ClientActionFlows.vWKldSsMnEq2uZ3+g89okA:uBz3d5lBdtw6HbbhAzkEOQ", "Common_CW", "Check_MM_EditPEAOverride", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:JGHBl3qD+UueeK1dfFECPg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:39vSCRDUTUimflwBcjRctA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_EditPEAOverride_JavaScriptJS, "JavaScript", "Check_MM_EditPEAOverride", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditPEAOverride$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_10_EditPEAOverride: Common_CWController.default.roles.MM_10_EditPEAOverride.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:q6YCX0hQak+EwSjxz6350w", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PlBMx6Eb_EuVC18z_3vZYw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:vWKldSsMnEq2uZ3+g89okA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditPEAOverride$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditPEAOverride$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_EditPEAOverride$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_EditPEAOverride$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_EditPEAOverride.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_10_EditPEAOverride)
};
});

define("Common_CW.controller$Check_MM_EditPreviousFundPaidHospitalDays", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_EditPreviousFundPaidHospitalDays.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_EditPreviousFundPaidHospitalDays_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_EditPreviousFundPaidHospitalDays$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditPreviousFundPaidHospitalDays$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:4iRdXX2hMEijIMkCVVkkGg:/ClientActionFlows.4iRdXX2hMEijIMkCVVkkGg:pQ7UrH3RdF0VRCGULPVGEA", "Common_CW", "Check_MM_EditPreviousFundPaidHospitalDays", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:s99rOZp5kU+CftofRIkn+w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2rNLLvTkfUOmcqR10_YGRw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_EditPreviousFundPaidHospitalDays_JavaScriptJS, "JavaScript", "Check_MM_EditPreviousFundPaidHospitalDays", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_EditPreviousFundPaidHospitalDays$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_12_EditPreviousFundPaidHospitalDays: Common_CWController.default.roles.MM_12_EditPreviousFundPaidHospitalDays.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FiQVp6LbJE2DrCjfitOq7Q", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bblBC_ksDE+nDFB1QHlY+w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:4iRdXX2hMEijIMkCVVkkGg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditPreviousFundPaidHospitalDays$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_EditPreviousFundPaidHospitalDays$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_EditPreviousFundPaidHospitalDays$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_EditPreviousFundPaidHospitalDays$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_EditPreviousFundPaidHospitalDays.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_12_EditPreviousFundPaidHospitalDays)
};
});

define("Common_CW.controller$Check_MM_PrintSendCommunicationBenefitStatement", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_PrintSendCommunicationBenefitStatement.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_PrintSendCommunicationBenefitStatement_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_PrintSendCommunicationBenefitStatement$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationBenefitStatement$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:SivxlvpwfUCoeehEQ5nwVQ:/ClientActionFlows.SivxlvpwfUCoeehEQ5nwVQ:H8hHUtYotHqRLXE7gAxMKA", "Common_CW", "Check_MM_PrintSendCommunicationBenefitStatement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qeSGTVtpnEK6IX+vffwjaA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xS3lDaUqukyRjcfGc702ZQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_PrintSendCommunicationBenefitStatement_JavaScriptJS, "JavaScript", "Check_MM_PrintSendCommunicationBenefitStatement", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationBenefitStatement$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_19_PrintSendCommunicationBenefitStatement: Common_CWController.default.roles.MM_19_PrintSendCommunicationBenefitStatement.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:r4Tq2nNQp0WQNMxWjacUWw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:n3gDmaxm+kmHFZKynqWKdA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:SivxlvpwfUCoeehEQ5nwVQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationBenefitStatement$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationBenefitStatement$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_PrintSendCommunicationBenefitStatement$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_PrintSendCommunicationBenefitStatement$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_PrintSendCommunicationBenefitStatement.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_19_PrintSendCommunicationBenefitStatement)
};
});

define("Common_CW.controller$Check_MM_PrintSendCommunicationGeneral", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_PrintSendCommunicationGeneral.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_PrintSendCommunicationGeneral_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_PrintSendCommunicationGeneral$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationGeneral$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:+m2eHRgvRkOny9Fak75DhQ:/ClientActionFlows.+m2eHRgvRkOny9Fak75DhQ:J_pxoi3jErlpPftuFjyLqA", "Common_CW", "Check_MM_PrintSendCommunicationGeneral", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0nqw3bsWXkWEmc9n+W3TfA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+lOZHlqMTkOfvzpBXVY3nQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_PrintSendCommunicationGeneral_JavaScriptJS, "JavaScript", "Check_MM_PrintSendCommunicationGeneral", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationGeneral$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_21_PrintSendCommunicationGeneral: Common_CWController.default.roles.MM_21_PrintSendCommunicationGeneral.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ud96GvkG8UKUTxGjB7Xeew", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:iAC5ZKhwEUOlUCetit76+A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:+m2eHRgvRkOny9Fak75DhQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationGeneral$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationGeneral$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_PrintSendCommunicationGeneral$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_PrintSendCommunicationGeneral$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_PrintSendCommunicationGeneral.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_21_PrintSendCommunicationGeneral)
};
});

define("Common_CW.controller$Check_MM_PrintSendCommunicationLHCStatement", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_PrintSendCommunicationLHCStatement.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_PrintSendCommunicationLHCStatement_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_PrintSendCommunicationLHCStatement$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationLHCStatement$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:3mnYt_FIxEmeZ7rfWMmt+A:/ClientActionFlows.3mnYt_FIxEmeZ7rfWMmt+A:E6YcnBDUVcMR9zOl5MI65g", "Common_CW", "Check_MM_PrintSendCommunicationLHCStatement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:lWPPFd96pkuBMZahjAKmaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vFXVSSmjakuTjPLmlAWfsQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_PrintSendCommunicationLHCStatement_JavaScriptJS, "JavaScript", "Check_MM_PrintSendCommunicationLHCStatement", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationLHCStatement$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_20_PrintSendCommunicationLHCStatement: Common_CWController.default.roles.MM_20_PrintSendCommunicationLHCStatement.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9yPfkI9exUSWT4hZMSMbKA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:uitWEHth9EmQEnJEcT3XfA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:3mnYt_FIxEmeZ7rfWMmt+A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationLHCStatement$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_PrintSendCommunicationLHCStatement$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_PrintSendCommunicationLHCStatement$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_PrintSendCommunicationLHCStatement$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_PrintSendCommunicationLHCStatement.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_20_PrintSendCommunicationLHCStatement)
};
});

define("Common_CW.controller$Check_MM_ViewMember_DEPRECATED", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_MM_ViewMember_DEPRECATED.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_MM_ViewMember_DEPRECATED_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_MM_ViewMember_DEPRECATED$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_ViewMember_DEPRECATED$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8Wk9f7u7x0mZnrMmav67ow:/ClientActionFlows.8Wk9f7u7x0mZnrMmav67ow:43R82NPWpZMFRMpCUj60Qw", "Common_CW", "Check_MM_ViewMember_DEPRECATED", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wNsJq+04EEadT2ci7YQ_xw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:I3xDawN21ESyRNjeIqXnPQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_MM_ViewMember_DEPRECATED_JavaScriptJS, "JavaScript", "Check_MM_ViewMember_DEPRECATED", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_MM_ViewMember_DEPRECATED$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
MM_17_ViewMember: Common_CWController.default.roles.MM_17_ViewMember.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bK4KX1cJw0Szoa_4FgYe6g", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Xfvj06JmQUeqhmI2KUQvDA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8Wk9f7u7x0mZnrMmav67ow", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_ViewMember_DEPRECATED$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_MM_ViewMember_DEPRECATED$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_MM_ViewMember_DEPRECATED$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_MM_ViewMember_DEPRECATED$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_MM_ViewMember_DEPRECATED.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.MM_17_ViewMember)
};
});

define("Common_CW.controller$Check_OA_4_ViewUserAuditLog", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_OA_4_ViewUserAuditLog.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_OA_4_ViewUserAuditLog_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_OA_4_ViewUserAuditLog$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_OA_4_ViewUserAuditLog$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:7HfYj9yJ7USUYbQ1RxKt0A:/ClientActionFlows.7HfYj9yJ7USUYbQ1RxKt0A:o8rw_iTVgl1dhtt31cq+Fw", "Common_CW", "Check_OA_4_ViewUserAuditLog", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HZtZKa9G7EyyWtjISGF8KQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:N0KpO0bMvkqK3oP4bZIERQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_OA_4_ViewUserAuditLog_JavaScriptJS, "JavaScript", "Check_OA_4_ViewUserAuditLog", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_OA_4_ViewUserAuditLog$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_3_ViewUserAuditLog: Common_CWController.default.roles.OA_3_ViewUserAuditLog.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:QhZKAnK6IkeURw6Zk1sSZg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kEC5kCHPkEqOXPYMbLRnfw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:7HfYj9yJ7USUYbQ1RxKt0A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_OA_4_ViewUserAuditLog$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_OA_4_ViewUserAuditLog$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_OA_4_ViewUserAuditLog$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_OA_4_ViewUserAuditLog$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_OA_4_ViewUserAuditLog.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_3_ViewUserAuditLog)
};
});

define("Common_CW.controller$Check_OA_CreateMaintainReferenceData", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_OA_CreateMaintainReferenceData.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_OA_CreateMaintainReferenceData_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_OA_CreateMaintainReferenceData$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_OA_CreateMaintainReferenceData$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ukiV+MXi7kq9_QoaMiC_Ow:/ClientActionFlows.ukiV+MXi7kq9_QoaMiC_Ow:Kk28uaLtLEnwWyeOKku7CQ", "Common_CW", "Check_OA_CreateMaintainReferenceData", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7Cg_4dWNgEWG3Wlo65iqiQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:G1Tbmk9jJ0CrQI+01VBxcg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_OA_CreateMaintainReferenceData_JavaScriptJS, "JavaScript", "Check_OA_CreateMaintainReferenceData", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_OA_CreateMaintainReferenceData$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
OA_2_CreateMaintainReferenceData: Common_CWController.default.roles.OA_2_CreateMaintainReferenceData.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kLm1YqNK5kmDl6hU0A5vAw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+z6F0TYcpU2UgZ5xByxaxA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ukiV+MXi7kq9_QoaMiC_Ow", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_OA_CreateMaintainReferenceData$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_OA_CreateMaintainReferenceData$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_OA_CreateMaintainReferenceData$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_OA_CreateMaintainReferenceData$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_OA_CreateMaintainReferenceData.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.OA_2_CreateMaintainReferenceData)
};
});

define("Common_CW.controller$Check_PM_1_CreateModifyQuote", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_1_CreateModifyQuote.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_1_CreateModifyQuote_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_1_CreateModifyQuote$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_1_CreateModifyQuote$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:XNI1E0bVHEq8N+snTfZl5w:/ClientActionFlows.XNI1E0bVHEq8N+snTfZl5w:+qoYxGOHeas8fKyA8_UPhw", "Common_CW", "Check_PM_1_CreateModifyQuote", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qVDAOgHL1Em0RBPlBLuS2g", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tqFpu1Mid0Gpta_FC_paXQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_1_CreateModifyQuote_JavaScriptJS, "JavaScript", "Check_PM_1_CreateModifyQuote", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_1_CreateModifyQuote$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_1_CreateModifyQuote: Common_CWController.default.roles.PM_1_CreateModifyQuote.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:uGMY7lmWmEyCaAn3eqtElg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ac_jKCfxZEaG7MxWYW5CGA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:XNI1E0bVHEq8N+snTfZl5w", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_1_CreateModifyQuote$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_1_CreateModifyQuote$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_1_CreateModifyQuote$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_1_CreateModifyQuote$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_1_CreateModifyQuote.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_1_CreateModifyQuote)
};
});

define("Common_CW.controller$Check_PM_10_ReactivatePolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_10_ReactivatePolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_10_ReactivatePolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_10_ReactivatePolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_10_ReactivatePolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:acbJbIlYpkSb9xgcVWMMtA:/ClientActionFlows.acbJbIlYpkSb9xgcVWMMtA:86B1N99VErlXocHYuaSBSQ", "Common_CW", "Check_PM_10_ReactivatePolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rGZBR3NsGkuXOIp7j6y2aA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:X6ZPEkFEpkmZy9FjL7vH7g", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_10_ReactivatePolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_10_ReactivatePolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_10_ReactivatePolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_10_ReactivatePolicy: Common_CWController.default.roles.PM_10_ReactivatePolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:uI_0xwQE6EOsX+jgZWGcgg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dCY5y5Sw6kGoO+QaVVuoMA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:acbJbIlYpkSb9xgcVWMMtA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_10_ReactivatePolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_10_ReactivatePolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_10_ReactivatePolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_10_ReactivatePolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_10_ReactivatePolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_10_ReactivatePolicy)
};
});

define("Common_CW.controller$Check_PM_13_ModifyWaitPeriod", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_13_ModifyWaitPeriod.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_13_ModifyWaitPeriod_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_13_ModifyWaitPeriod$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_13_ModifyWaitPeriod$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ouwgu0oGxUytZm5M+IRl8A:/ClientActionFlows.ouwgu0oGxUytZm5M+IRl8A:bYZfezC1+E3xF_Yu99ttYg", "Common_CW", "Check_PM_13_ModifyWaitPeriod", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tgKaEbPOZ0OFF2suqMYQ1w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hYKx3maJukqX3iG8ZWQHmg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_13_ModifyWaitPeriod_JavaScriptJS, "JavaScript", "Check_PM_13_ModifyWaitPeriod", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_13_ModifyWaitPeriod$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_13_ModifyWaitingPeriodPolicyMember: Common_CWController.default.roles.PM_13_ModifyWaitingPeriodPolicyMember.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:W7toPGkwbkOkePsR_zgGKg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:V5mvTELFL0eJnXgoGq5T8g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ouwgu0oGxUytZm5M+IRl8A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_13_ModifyWaitPeriod$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_13_ModifyWaitPeriod$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_13_ModifyWaitPeriod$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_13_ModifyWaitPeriod$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_13_ModifyWaitPeriod.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_13_ModifyWaitingPeriodPolicyMember)
};
});

define("Common_CW.controller$Check_PM_2_AddConvertQuote", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_2_AddConvertQuote.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_2_AddConvertQuote_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_2_AddConvertQuote$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_2_AddConvertQuote$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:+T5PKYYTlESiG4RWNtTgrg:/ClientActionFlows.+T5PKYYTlESiG4RWNtTgrg:yC8oBlsYEzgTbPkFJCy6WQ", "Common_CW", "Check_PM_2_AddConvertQuote", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:obF+GHdwE0SXaHnI0DHjUA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XX0yqjj+nUWpZtkyfVYmVg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_2_AddConvertQuote_JavaScriptJS, "JavaScript", "Check_PM_2_AddConvertQuote", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_2_AddConvertQuote$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_2_ConvertQuote: Common_CWController.default.roles.PM_2_ConvertQuote.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_vZ0nVTCtUugZwdtYE5NBA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LRqTScEKEUiYBLCOq4_bhQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:+T5PKYYTlESiG4RWNtTgrg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_2_AddConvertQuote$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_2_AddConvertQuote$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_2_AddConvertQuote$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_2_AddConvertQuote$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_2_AddConvertQuote.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_2_ConvertQuote)
};
});

define("Common_CW.controller$Check_PM_23_ViewPolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_23_ViewPolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_23_ViewPolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_23_ViewPolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:YMaLUKsgq0exeY1WrdwqCg:/ClientActionFlows.YMaLUKsgq0exeY1WrdwqCg:PoOo6MrWEnIVPTC9t16vwQ", "Common_CW", "Check_PM_23_ViewPolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:snxQrl9jj0WEvoSosCvG1w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:iiR9Y5ibiUi3KjY_ghKInA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_23_ViewPolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_23_ViewPolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_23_ViewPolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_20_ViewPolicy: Common_CWController.default.roles.PM_20_ViewPolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hOkYublsSUe1+w7z1TIsJg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:O9bpQZfWm0+eoMqNlUhwKg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:YMaLUKsgq0exeY1WrdwqCg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_23_ViewPolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_23_ViewPolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_23_ViewPolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_23_ViewPolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_23_ViewPolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_20_ViewPolicy)
};
});

define("Common_CW.controller$Check_PM_29_RebateExceptionManagement", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_29_RebateExceptionManagement.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_29_RebateExceptionManagement_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_29_RebateExceptionManagement$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_29_RebateExceptionManagement$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:stVGoJ49b0yILZFClR4eug:/ClientActionFlows.stVGoJ49b0yILZFClR4eug:N3BrhEwo7RKcVfFvOg10SQ", "Common_CW", "Check_PM_29_RebateExceptionManagement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:y2zWg1zJxUWADI6isUZ69A", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:54Z7FCXveE2FcQR6ZTPqgQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_29_RebateExceptionManagement_JavaScriptJS, "JavaScript", "Check_PM_29_RebateExceptionManagement", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_29_RebateExceptionManagement$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_29_RebateExceptionmanagementFromRealTimeIntegra: Common_CWController.default.roles.PM_29_RebateExceptionmanagementFromRealTimeIntegra.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:zv2NnEit1Ue04FRuzeSp2A", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:z9yKAcaGuU2Sc5OH0k2eVw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:stVGoJ49b0yILZFClR4eug", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_29_RebateExceptionManagement$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_29_RebateExceptionManagement$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_29_RebateExceptionManagement$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_29_RebateExceptionManagement$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_29_RebateExceptionManagement.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_29_RebateExceptionmanagementFromRealTimeIntegra)
};
});

define("Common_CW.controller$Check_PM_34_ViewQuoteAndProspect", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_34_ViewQuoteAndProspect.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_34_ViewQuoteAndProspect_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_34_ViewQuoteAndProspect$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_34_ViewQuoteAndProspect$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:oz70c4MiYEyvEvsIq8R64g:/ClientActionFlows.oz70c4MiYEyvEvsIq8R64g:oYUoZx30sCYDbZAYg5DcWA", "Common_CW", "Check_PM_34_ViewQuoteAndProspect", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KbSvnCCzj0WjxR9gdfrWNA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OufzkB4b70eQI_b0P11VAQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_34_ViewQuoteAndProspect_JavaScriptJS, "JavaScript", "Check_PM_34_ViewQuoteAndProspect", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_34_ViewQuoteAndProspect$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_3_ViewQuote: Common_CWController.default.roles.PM_3_ViewQuote.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qLSs0bBCYUuB3oexwY5bmA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tW5m3FeouEm3RqrP6Eo7Jw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:oz70c4MiYEyvEvsIq8R64g", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_34_ViewQuoteAndProspect$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_34_ViewQuoteAndProspect$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_34_ViewQuoteAndProspect$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_34_ViewQuoteAndProspect$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_34_ViewQuoteAndProspect.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_3_ViewQuote)
};
});

define("Common_CW.controller$Check_PM_4_CreatePolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_4_CreatePolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_4_CreatePolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_4_CreatePolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:fJckYDCpYEW1RYFuaeSkJQ:/ClientActionFlows.fJckYDCpYEW1RYFuaeSkJQ:BbGxKBYkJ8oW7PPTOgVcaA", "Common_CW", "Check_PM_4_CreatePolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Dal695uaOUSqai11AlIFUw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:khme6d0vW0S5eJNWOcOJLQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_4_CreatePolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_4_CreatePolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_4_CreatePolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_4_CreatePolicy: Common_CWController.default.roles.PM_4_CreatePolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dPoT14boIkyG22WrAn83Bw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ve_Oxantak6u196CU1eKZQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:fJckYDCpYEW1RYFuaeSkJQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_4_CreatePolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_4_CreatePolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_4_CreatePolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_4_CreatePolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_4_CreatePolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_4_CreatePolicy)
};
});

define("Common_CW.controller$Check_PM_5_MaintainPolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_5_MaintainPolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_5_MaintainPolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_5_MaintainPolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_5_MaintainPolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:mwcfK5qx1EePHvpqAkvOHw:/ClientActionFlows.mwcfK5qx1EePHvpqAkvOHw:aXhPJYuY5f_MLn3JHBtefQ", "Common_CW", "Check_PM_5_MaintainPolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kdqPpdrjNE+7ipDq7XE9UA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kJdm9cVsrkyiuKQlDrUb0A", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_5_MaintainPolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_5_MaintainPolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_5_MaintainPolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_5_MaintainPolicy: Common_CWController.default.roles.PM_5_MaintainPolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:JpqxjAUvq0OUN+2DFwmzeQ", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:AJXEtBpVf0622hCoybBPPg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:mwcfK5qx1EePHvpqAkvOHw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_5_MaintainPolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_5_MaintainPolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_5_MaintainPolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_5_MaintainPolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_5_MaintainPolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_5_MaintainPolicy)
};
});

define("Common_CW.controller$Check_PM_8_TerminatePolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_8_TerminatePolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_8_TerminatePolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_8_TerminatePolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_8_TerminatePolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:pSLccGsMdkOnohIO04XkvQ:/ClientActionFlows.pSLccGsMdkOnohIO04XkvQ:qucyQ+k8xPM0R2Uq9W2sDg", "Common_CW", "Check_PM_8_TerminatePolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Snp4ithAJEi6AgS4yJf1Bg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:C4q+QUtxg0i4LlSQfLH2AQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_8_TerminatePolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_8_TerminatePolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_8_TerminatePolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_8_TerminatePolicy: Common_CWController.default.roles.PM_8_TerminatePolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:iXeNvCKndkq6V0wlwCix4g", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:O5KlhLOElE6tJmnJ3L7NJQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:pSLccGsMdkOnohIO04XkvQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_8_TerminatePolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_8_TerminatePolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_8_TerminatePolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_8_TerminatePolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_8_TerminatePolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_8_TerminatePolicy)
};
});

define("Common_CW.controller$Check_PM_9_SuspendPolicyAndMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_9_SuspendPolicyAndMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_9_SuspendPolicyAndMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_9_SuspendPolicyAndMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_9_SuspendPolicyAndMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:rIDlwQ_lpkynQsITPMyQlg:/ClientActionFlows.rIDlwQ_lpkynQsITPMyQlg:s7qNqUyNc7w8SZZttsGfvQ", "Common_CW", "Check_PM_9_SuspendPolicyAndMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OHu8o2EIbkW+Xfa9yPouFQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MJfUZish5EO7bW0wt5Ghqw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_9_SuspendPolicyAndMember_JavaScriptJS, "JavaScript", "Check_PM_9_SuspendPolicyAndMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_9_SuspendPolicyAndMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_9_SuspendPolicy: Common_CWController.default.roles.PM_9_SuspendPolicy.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qEx4HivW90+aEIjpslwtqg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MqJlNJ54p025600eK8jM_g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:rIDlwQ_lpkynQsITPMyQlg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_9_SuspendPolicyAndMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_9_SuspendPolicyAndMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_9_SuspendPolicyAndMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_9_SuspendPolicyAndMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_9_SuspendPolicyAndMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_9_SuspendPolicy)
};
});

define("Common_CW.controller$Check_PM_AddModifyWithdrawRebateParticipation", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_AddModifyWithdrawRebateParticipation.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_AddModifyWithdrawRebateParticipation_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_AddModifyWithdrawRebateParticipation$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_AddModifyWithdrawRebateParticipation$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ubms3QR2o06D4k6vvaY8ug:/ClientActionFlows.ubms3QR2o06D4k6vvaY8ug:xhJAz3Y1Yvdg1pSJNASdng", "Common_CW", "Check_PM_AddModifyWithdrawRebateParticipation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:crdQMt9Vz0GUvof62scuNA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7rfmE2m0ukWucCSIDX0Usg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_AddModifyWithdrawRebateParticipation_JavaScriptJS, "JavaScript", "Check_PM_AddModifyWithdrawRebateParticipation", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_AddModifyWithdrawRebateParticipation$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_7_AddModifyWithdrawRebateParticipation: Common_CWController.default.roles.PM_7_AddModifyWithdrawRebateParticipation.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hb6QA_JByka5sM24nXInJw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Plk5GtOSM0S1FW0RuJpqkQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ubms3QR2o06D4k6vvaY8ug", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_AddModifyWithdrawRebateParticipation$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_AddModifyWithdrawRebateParticipation$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_AddModifyWithdrawRebateParticipation$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_AddModifyWithdrawRebateParticipation$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_AddModifyWithdrawRebateParticipation.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_7_AddModifyWithdrawRebateParticipation)
};
});

define("Common_CW.controller$Check_PM_AdjustPaidToDateTheoreticalPaidToDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_AdjustPaidToDateTheoreticalPaidToDate.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_AdjustPaidToDateTheoreticalPaidToDate_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_AdjustPaidToDateTheoreticalPaidToDate$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_AdjustPaidToDateTheoreticalPaidToDate$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:WEnVKTh3JkeUIrBvnUvpgQ:/ClientActionFlows.WEnVKTh3JkeUIrBvnUvpgQ:zdeHrI4RG0sFgRrVLp5Phg", "Common_CW", "Check_PM_AdjustPaidToDateTheoreticalPaidToDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Qabihv9qGUGzOmcW4MmPaw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:eMPG_mW+x0+TGuQr7yOPSA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_AdjustPaidToDateTheoreticalPaidToDate_JavaScriptJS, "JavaScript", "Check_PM_AdjustPaidToDateTheoreticalPaidToDate", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_AdjustPaidToDateTheoreticalPaidToDate$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_26_AdjustPaidToDateTheoreticalPaidToDate: Common_CWController.default.roles.PM_26_AdjustPaidToDateTheoreticalPaidToDate.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xJKCaCTaE0OCXofBDKbimQ", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ni7wMFOyEk2QuIxIAdRCCw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:WEnVKTh3JkeUIrBvnUvpgQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_AdjustPaidToDateTheoreticalPaidToDate$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_AdjustPaidToDateTheoreticalPaidToDate$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_AdjustPaidToDateTheoreticalPaidToDate$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_AdjustPaidToDateTheoreticalPaidToDate$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_AdjustPaidToDateTheoreticalPaidToDate.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_26_AdjustPaidToDateTheoreticalPaidToDate)
};
});

define("Common_CW.controller$Check_PM_CreateMaintainPolicyEditStartDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_CreateMaintainPolicyEditStartDate.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_CreateMaintainPolicyEditStartDate_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_CreateMaintainPolicyEditStartDate$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_CreateMaintainPolicyEditStartDate$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:A3MpTHTCpkOKC4y6TEo4Vw:/ClientActionFlows.A3MpTHTCpkOKC4y6TEo4Vw:Xiw5jbOPuZzs4KE1TFNEcw", "Common_CW", "Check_PM_CreateMaintainPolicyEditStartDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:aU66GRBQ+U6g6IJtA8ummQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7tFeCUetsEyhrmJq4E6w7g", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_CreateMaintainPolicyEditStartDate_JavaScriptJS, "JavaScript", "Check_PM_CreateMaintainPolicyEditStartDate", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_CreateMaintainPolicyEditStartDate$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_6_CreateMaintainPolicyEditStartDate: Common_CWController.default.roles.PM_6_CreateMaintainPolicyEditStartDate.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:WthtmJVvTEG_w4l+zMcGcQ", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KKzH4H6YCk2AC5J+8KC7sg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:A3MpTHTCpkOKC4y6TEo4Vw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_CreateMaintainPolicyEditStartDate$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_CreateMaintainPolicyEditStartDate$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_CreateMaintainPolicyEditStartDate$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_CreateMaintainPolicyEditStartDate$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_CreateMaintainPolicyEditStartDate.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_6_CreateMaintainPolicyEditStartDate)
};
});

define("Common_CW.controller$Check_PM_CreateNotes", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_CreateNotes.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_CreateNotes_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_CreateNotes$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_CreateNotes$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8dBqbaSxT0CDV9CdQVuX+Q:/ClientActionFlows.8dBqbaSxT0CDV9CdQVuX+Q:FJLtiLZ8uBp9xIM1II0b1Q", "Common_CW", "Check_PM_CreateNotes", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:RxSNcJapakuwGErOSeZDQg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:92ClQbn8u06_0tgvjO6c9Q", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_CreateNotes_JavaScriptJS, "JavaScript", "Check_PM_CreateNotes", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_CreateNotes$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_18_CreateNotes: Common_CWController.default.roles.PM_18_CreateNotes.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cWDitgouH0OMYmrYlrgC8g", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:RNVjN6PxZEuoGtaYUQnpAg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8dBqbaSxT0CDV9CdQVuX+Q", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_CreateNotes$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_CreateNotes$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_CreateNotes$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_CreateNotes$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_CreateNotes.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_18_CreateNotes)
};
});

define("Common_CW.controller$Check_PM_MaintainNotes", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_MaintainNotes.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_MaintainNotes_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_MaintainNotes$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_MaintainNotes$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:JFhTd7js2kaI7Q3iABRvBw:/ClientActionFlows.JFhTd7js2kaI7Q3iABRvBw:HAgbW1SDAEJOxoFatFR2mw", "Common_CW", "Check_PM_MaintainNotes", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ZNGlpW6oR0a8puHFKgOrGQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OjkMJLQF20q29b8u94oYFg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_MaintainNotes_JavaScriptJS, "JavaScript", "Check_PM_MaintainNotes", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_MaintainNotes$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_19_MaintainNotes: Common_CWController.default.roles.PM_19_MaintainNotes.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pfNQsN259U2Cu4nwGoKlng", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Qk7C1LMk90eAGhFuRxpzTQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:JFhTd7js2kaI7Q3iABRvBw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_MaintainNotes$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_MaintainNotes$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_MaintainNotes$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_MaintainNotes$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_MaintainNotes.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_19_MaintainNotes)
};
});

define("Common_CW.controller$Check_PM_PrintSendCommunicationGeneral", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_PrintSendCommunicationGeneral.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_PrintSendCommunicationGeneral_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_PrintSendCommunicationGeneral$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationGeneral$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:njiRzRS3zk2aJJYzwNo+Dg:/ClientActionFlows.njiRzRS3zk2aJJYzwNo+Dg:umuIirD66SC5TDiJZ+CPJw", "Common_CW", "Check_PM_PrintSendCommunicationGeneral", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:0ZLlHmHF8kS2JN0EsjTDHA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:zOsvTxIaGkSlSoVf+3ra1w", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_PrintSendCommunicationGeneral_JavaScriptJS, "JavaScript", "Check_PM_PrintSendCommunicationGeneral", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationGeneral$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_27_PrintSendCommunicationGeneral: Common_CWController.default.roles.PM_27_PrintSendCommunicationGeneral.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Vv4L_5LgekaFOx1YiLn6RA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:n7l4Pt19xEemVrt7c8fCCw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:njiRzRS3zk2aJJYzwNo+Dg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationGeneral$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationGeneral$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_PrintSendCommunicationGeneral$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_PrintSendCommunicationGeneral$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_PrintSendCommunicationGeneral.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_27_PrintSendCommunicationGeneral)
};
});

define("Common_CW.controller$Check_PM_PrintSendCommunicationRebateStatement", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_PM_PrintSendCommunicationRebateStatement.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_PM_PrintSendCommunicationRebateStatement_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_PM_PrintSendCommunicationRebateStatement$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationRebateStatement$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:7nK2EW4ZHk6L8e52sKcZ+g:/ClientActionFlows.7nK2EW4ZHk6L8e52sKcZ+g:bzQJdoO1jViM+pucQCbcnA", "Common_CW", "Check_PM_PrintSendCommunicationRebateStatement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NU_nq59T0ku0NcRSd0yPog", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1StE3DB+6EGudidUhG2bBQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_PM_PrintSendCommunicationRebateStatement_JavaScriptJS, "JavaScript", "Check_PM_PrintSendCommunicationRebateStatement", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationRebateStatement$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
PM_28_PrintSendCommunicationRebateStatement: Common_CWController.default.roles.PM_28_PrintSendCommunicationRebateStatement.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:X+xx4ML8aEyiWhkJFzEHLg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:WTUtjsFIJk21R0pUpFlqCg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:7nK2EW4ZHk6L8e52sKcZ+g", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationRebateStatement$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_PM_PrintSendCommunicationRebateStatement$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_PM_PrintSendCommunicationRebateStatement$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_PM_PrintSendCommunicationRebateStatement$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_PM_PrintSendCommunicationRebateStatement.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.PM_28_PrintSendCommunicationRebateStatement)
};
});

define("Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_1_AddModifyReopenCancelLead_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_1_AddModifyReopenCancelLead$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:fGP0KCH8NkObMvc5sJ0JKQ:/ClientActionFlows.fGP0KCH8NkObMvc5sJ0JKQ:zk8Xl6+mvTTlnM3C9UyLkw", "Common_CW", "Check_SM_1_AddModifyReopenCancelLead", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jcS5aJ6EpkGeOkVEG+CaIw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:G7tcgLiri0q_Qs_p2r00RA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_1_AddModifyReopenCancelLead_JavaScriptJS, "JavaScript", "Check_SM_1_AddModifyReopenCancelLead", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_1_AddModifyReopenCancelLead$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_1_AddModifyReopenCancelLead: Common_CWController.default.roles.SM_1_AddModifyReopenCancelLead.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:vAAZAVRtVkqvPh8pRKdCYA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:aUvKOn0YckOsi7knKIWQKA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:fGP0KCH8NkObMvc5sJ0JKQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_1_AddModifyReopenCancelLead$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_1_AddModifyReopenCancelLead$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_1_AddModifyReopenCancelLead$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_1_AddModifyReopenCancelLead)
};
});

define("Common_CW.controller$Check_SM_2_AddModifyDirectCreditAccountsStakeholde", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_2_AddModifyDirectCreditAccountsStakeholde.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_2_AddModifyDirectCreditAccountsStakeholde_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_2_AddModifyDirectCreditAccountsStakeholde$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_2_AddModifyDirectCreditAccountsStakeholde$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:pSum3fGcV0+bELfJJtG9Fw:/ClientActionFlows.pSum3fGcV0+bELfJJtG9Fw:u3wf3urOPGJyy5Te6GaxmA", "Common_CW", "Check_SM_2_AddModifyDirectCreditAccountsStakeholde", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:noEcY0ViR0O0ibNRFkhtLQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kOD2PmKU+U+GHAKbQcvNdA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_2_AddModifyDirectCreditAccountsStakeholde_JavaScriptJS, "JavaScript", "Check_SM_2_AddModifyDirectCreditAccountsStakeholde", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_2_AddModifyDirectCreditAccountsStakeholde$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_2_AddModifyDirectCreditAccountsStakeholder: Common_CWController.default.roles.SM_2_AddModifyDirectCreditAccountsStakeholder.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:EZ6_qPYoP0K7W2u9qZVBEg", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TVrbCGtUUUO1Yr5wsCKZ7Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:pSum3fGcV0+bELfJJtG9Fw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_2_AddModifyDirectCreditAccountsStakeholde$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_2_AddModifyDirectCreditAccountsStakeholde$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_2_AddModifyDirectCreditAccountsStakeholde$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_2_AddModifyDirectCreditAccountsStakeholde$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_2_AddModifyDirectCreditAccountsStakeholde.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_2_AddModifyDirectCreditAccountsStakeholder)
};
});

define("Common_CW.controller$Check_SM_3_AddModifyDirectDebitAccountsStakehold", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_3_AddModifyDirectDebitAccountsStakehold.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_3_AddModifyDirectDebitAccountsStakehold_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_3_AddModifyDirectDebitAccountsStakehold$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_3_AddModifyDirectDebitAccountsStakehold$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:YEA7ApOWBkaY89oodu2w2g:/ClientActionFlows.YEA7ApOWBkaY89oodu2w2g:c3jLHlv5OJrib7XMXnJMJw", "Common_CW", "Check_SM_3_AddModifyDirectDebitAccountsStakehold", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Suls9LSnBEW+E5xL647a+w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:HtNOLKHb4U2i5H2tZFJXgA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_3_AddModifyDirectDebitAccountsStakehold_JavaScriptJS, "JavaScript", "Check_SM_3_AddModifyDirectDebitAccountsStakehold", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_3_AddModifyDirectDebitAccountsStakehold$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_3_AddModifyDirectDebitAccountsStakeholder: Common_CWController.default.roles.SM_3_AddModifyDirectDebitAccountsStakeholder.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wcUC1Hwcj02VMyKLWfHEYA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gL1k0zJR7kOsGb0xBHpToQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:YEA7ApOWBkaY89oodu2w2g", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_3_AddModifyDirectDebitAccountsStakehold$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_3_AddModifyDirectDebitAccountsStakehold$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_3_AddModifyDirectDebitAccountsStakehold$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_3_AddModifyDirectDebitAccountsStakehold$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_3_AddModifyDirectDebitAccountsStakehold.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_3_AddModifyDirectDebitAccountsStakeholder)
};
});

define("Common_CW.controller$Check_SM_6_CreateNotes", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_6_CreateNotes.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_6_CreateNotes_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_6_CreateNotes$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_6_CreateNotes$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:R6R2O6sP+EilW7cbuO3iTA:/ClientActionFlows.R6R2O6sP+EilW7cbuO3iTA:iMrV2B4UGY8UKajv42xyuA", "Common_CW", "Check_SM_6_CreateNotes", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:EnpMuVULNUuvJL7AVjdePg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PThEj19zP0y2ZuvP1LyWaQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_6_CreateNotes_JavaScriptJS, "JavaScript", "Check_SM_6_CreateNotes", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_6_CreateNotes$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_6_CreateNotes: Common_CWController.default.roles.SM_6_CreateNotes.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:s0NUwNNicE+kDaEGS3Sh_w", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+q_xwyQ2VU29JDKwCx3JJw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:R6R2O6sP+EilW7cbuO3iTA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_6_CreateNotes$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_6_CreateNotes$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_6_CreateNotes$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_6_CreateNotes$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_6_CreateNotes.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_6_CreateNotes)
};
});

define("Common_CW.controller$Check_SM_7_MaintainNotes", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_7_MaintainNotes.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_7_MaintainNotes_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_7_MaintainNotes$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_7_MaintainNotes$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Fp2iw0JmJ0OeV5bjaY__4A:/ClientActionFlows.Fp2iw0JmJ0OeV5bjaY__4A:L2yVvGIHpSWDfBUGOcI97A", "Common_CW", "Check_SM_7_MaintainNotes", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XjkqDPLnpEy+3ggDjPRQTA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:S2zzImDTNUe1ByT9N3_NSw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_7_MaintainNotes_JavaScriptJS, "JavaScript", "Check_SM_7_MaintainNotes", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_7_MaintainNotes$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_7_MaintainNotes: Common_CWController.default.roles.SM_7_MaintainNotes.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Phak1lnRJkq0y_GhAoT03w", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:f+w8ztGiwkW_QG768SO5jQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Fp2iw0JmJ0OeV5bjaY__4A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_7_MaintainNotes$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_7_MaintainNotes$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_7_MaintainNotes$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_7_MaintainNotes$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_7_MaintainNotes.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_7_MaintainNotes)
};
});

define("Common_CW.controller$Check_SM_8_CreateInteractionRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_8_CreateInteractionRecord.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_8_CreateInteractionRecord_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_8_CreateInteractionRecord$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_8_CreateInteractionRecord$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:RdYWOzEh6EK3kQW4RsoN1w:/ClientActionFlows.RdYWOzEh6EK3kQW4RsoN1w:4NSrV1u7tIYUuGL7iz4cwA", "Common_CW", "Check_SM_8_CreateInteractionRecord", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FFSy65YIWkWePRMmVQ_GCQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nvFzWUANt0Wuu3aZfWRptw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_8_CreateInteractionRecord_JavaScriptJS, "JavaScript", "Check_SM_8_CreateInteractionRecord", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_8_CreateInteractionRecord$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_8_CreateInteractionRecord: Common_CWController.default.roles.SM_8_CreateInteractionRecord.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:WNqoZKMEaEKticW+pSxBbA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qMDDnwEvXkOOzjfniCo3oQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:RdYWOzEh6EK3kQW4RsoN1w", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_8_CreateInteractionRecord$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_8_CreateInteractionRecord$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_8_CreateInteractionRecord$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_8_CreateInteractionRecord$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_8_CreateInteractionRecord.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_8_CreateInteractionRecord)
};
});

define("Common_CW.controller$Check_SM_9_ViewRestrictedInteractionRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_9_ViewRestrictedInteractionRecord.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_9_ViewRestrictedInteractionRecord_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_9_ViewRestrictedInteractionRecord$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_9_ViewRestrictedInteractionRecord$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:cZhrjzeXx0aBKKK3gcGc1g:/ClientActionFlows.cZhrjzeXx0aBKKK3gcGc1g:HWpe3JzqRXfzAMdt_NYXYw", "Common_CW", "Check_SM_9_ViewRestrictedInteractionRecord", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:S1xscZJpnE2lqcU_IDX38w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Odw8lirtp0uCmJwsjDe9lA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_9_ViewRestrictedInteractionRecord_JavaScriptJS, "JavaScript", "Check_SM_9_ViewRestrictedInteractionRecord", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_9_ViewRestrictedInteractionRecord$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_9_MaintainInteractionRecord: Common_CWController.default.roles.SM_9_MaintainInteractionRecord.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:8jBuFCZCgEukPXhbj+g9UA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:YJh06UylVEODCHUD6wFW8A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:cZhrjzeXx0aBKKK3gcGc1g", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_9_ViewRestrictedInteractionRecord$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_9_ViewRestrictedInteractionRecord$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_9_ViewRestrictedInteractionRecord$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_9_ViewRestrictedInteractionRecord$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_9_ViewRestrictedInteractionRecord.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_9_MaintainInteractionRecord)
};
});

define("Common_CW.controller$Check_SM_CommunicationAdministration_Ind", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_CommunicationAdministration_Ind.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_CommunicationAdministration_Ind_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_CommunicationAdministration_Ind$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_CommunicationAdministration_Ind$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:abKbOUvgIkOnwn5oXiydlg:/ClientActionFlows.abKbOUvgIkOnwn5oXiydlg:JB2hodaUcF8T2ulTNvwJDA", "Common_CW", "Check_SM_CommunicationAdministration_Ind", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:YyrlIySNd0isp2JmtkOimw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hFi4eIACV0WAtZRNyrSZrA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_CommunicationAdministration_Ind_JavaScriptJS, "JavaScript", "Check_SM_CommunicationAdministration_Ind", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_CommunicationAdministration_Ind$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_10_CommunicationAdministration_Ind: Common_CWController.default.roles.SM_10_CommunicationAdministration_Ind.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FbEabZBp8kaD5cDc8O5B_A", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GdeD3qZgKE6roQWsEvHdNA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:abKbOUvgIkOnwn5oXiydlg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_CommunicationAdministration_Ind$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_CommunicationAdministration_Ind$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_CommunicationAdministration_Ind$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_CommunicationAdministration_Ind$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_CommunicationAdministration_Ind.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_10_CommunicationAdministration_Ind)
};
});

define("Common_CW.controller$Check_SM_PrintSendCommunicationGeneral", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_PrintSendCommunicationGeneral.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_PrintSendCommunicationGeneral_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_PrintSendCommunicationGeneral$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_PrintSendCommunicationGeneral$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Vb+DYua0VEWQbIOWDAq3kw:/ClientActionFlows.Vb+DYua0VEWQbIOWDAq3kw:iIyBX9ssoHBhZ301+P5p7Q", "Common_CW", "Check_SM_PrintSendCommunicationGeneral", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FZzFI0aXb0CErGwKHDYhyQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:CIQsQU+L+0qAB27o5865GQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_PrintSendCommunicationGeneral_JavaScriptJS, "JavaScript", "Check_SM_PrintSendCommunicationGeneral", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_PrintSendCommunicationGeneral$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_11_PrintSendCommunicationGeneral: Common_CWController.default.roles.SM_11_PrintSendCommunicationGeneral.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ao9pIhCb2ESgLGQQn0tXyw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:oOl1gpN+XkOEn5_La8xenA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Vb+DYua0VEWQbIOWDAq3kw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_PrintSendCommunicationGeneral$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_PrintSendCommunicationGeneral$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_PrintSendCommunicationGeneral$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_PrintSendCommunicationGeneral$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_PrintSendCommunicationGeneral.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_11_PrintSendCommunicationGeneral)
};
});

define("Common_CW.controller$Check_SM_ViewStakeholderExclMember", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SM_ViewStakeholderExclMember.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SM_ViewStakeholderExclMember_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SM_ViewStakeholderExclMember$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_ViewStakeholderExclMember$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:nXvL0VhreU20xxjMWiv0MQ:/ClientActionFlows.nXvL0VhreU20xxjMWiv0MQ:ZH4rYZAGHrRrsV9RVkaKhA", "Common_CW", "Check_SM_ViewStakeholderExclMember", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FYUF4elY4k2fknaFiwHQnA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:joAqW96S20m1XBpniIXNAg", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SM_ViewStakeholderExclMember_JavaScriptJS, "JavaScript", "Check_SM_ViewStakeholderExclMember", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SM_ViewStakeholderExclMember$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SM_4_ViewStakeholderLead: Common_CWController.default.roles.SM_4_ViewStakeholderLead.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:lzecMfsqy0mir3wgODjBzw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:6vcXIf3ga0ieDoLCaCX+NA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:nXvL0VhreU20xxjMWiv0MQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_ViewStakeholderExclMember$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SM_ViewStakeholderExclMember$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SM_ViewStakeholderExclMember$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SM_ViewStakeholderExclMember$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SM_ViewStakeholderExclMember.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SM_4_ViewStakeholderLead)
};
});

define("Common_CW.controller$Check_SP_AssignCaseBulk", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_AssignCaseBulk.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_AssignCaseBulk_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_AssignCaseBulk$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseBulk$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:LciSi0gACUyf2jNAMpAung:/ClientActionFlows.LciSi0gACUyf2jNAMpAung:4AAOZXum+mlYUl6q5v5SeA", "Common_CW", "Check_SP_AssignCaseBulk", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:UCN5HqsbgkmK+g8l0ci2bQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:aK9FKrRbzE2OKQGBm41Zag", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_AssignCaseBulk_JavaScriptJS, "JavaScript", "Check_SP_AssignCaseBulk", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseBulk$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_9_AssignCaseBulk: Common_CWController.default.roles.SP_9_AssignCaseBulk.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2+M4fczYJ0qo406+zADzMQ", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:q+ohT+XP_0m70vY6f3CoYQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:LciSi0gACUyf2jNAMpAung", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseBulk$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseBulk$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_AssignCaseBulk$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_AssignCaseBulk$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_AssignCaseBulk.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_9_AssignCaseBulk)
};
});

define("Common_CW.controller$Check_SP_AssignCaseIndividual", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_AssignCaseIndividual.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_AssignCaseIndividual_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_AssignCaseIndividual$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseIndividual$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:aiPjhXtTrk6r7I9tI3ZXMQ:/ClientActionFlows.aiPjhXtTrk6r7I9tI3ZXMQ:M0jFw0VOyKAT1gkNkDfsyQ", "Common_CW", "Check_SP_AssignCaseIndividual", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qQoL9zKUkUSXAh_VXFSswA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wZ8vVgWskkqFZuwlzMedOw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_AssignCaseIndividual_JavaScriptJS, "JavaScript", "Check_SP_AssignCaseIndividual", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseIndividual$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_8_AssignCaseIndividual: Common_CWController.default.roles.SP_8_AssignCaseIndividual.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:yUCnFNyDDU+tl9FdRjH2tA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gtciyXX2dE6X0FmIztL4Jw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:aiPjhXtTrk6r7I9tI3ZXMQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseIndividual$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseIndividual$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_AssignCaseIndividual$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_AssignCaseIndividual$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_AssignCaseIndividual.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_8_AssignCaseIndividual)
};
});

define("Common_CW.controller$Check_SP_AssignCasePerson", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_AssignCasePerson.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_AssignCasePerson_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_AssignCasePerson$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCasePerson$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:Lb9eMa+2t0m0T2w8Tt4+Qg:/ClientActionFlows.Lb9eMa+2t0m0T2w8Tt4+Qg:3rRvTFndYJgR4EyeUaoyZw", "Common_CW", "Check_SP_AssignCasePerson", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pE_IjvdDaku2U7ioKiwydQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:VbuOmuY8LUC3GWroI7EU4w", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_AssignCasePerson_JavaScriptJS, "JavaScript", "Check_SP_AssignCasePerson", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCasePerson$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_10_AssignCasePersonTeam: Common_CWController.default.roles.SP_10_AssignCasePersonTeam.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1ACSH4gG5UiArBFdafWzeA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:avqH0NkqTkiKPhhz40nkkg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:Lb9eMa+2t0m0T2w8Tt4+Qg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCasePerson$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCasePerson$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_AssignCasePerson$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_AssignCasePerson$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_AssignCasePerson.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_10_AssignCasePersonTeam)
};
});

define("Common_CW.controller$Check_SP_AssignCaseTeam", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_AssignCaseTeam.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_AssignCaseTeam_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_AssignCaseTeam$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseTeam$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:WSwOoy24C0e7SkHxIa6lRw:/ClientActionFlows.WSwOoy24C0e7SkHxIa6lRw:6dGLZ+Zf5o2fAwqLSG4thg", "Common_CW", "Check_SP_AssignCaseTeam", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Pn_pZ_zCjEag3D6xizIPeA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dtZZR4sHDk2qzCcxvbixdQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_AssignCaseTeam_JavaScriptJS, "JavaScript", "Check_SP_AssignCaseTeam", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_AssignCaseTeam$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_11_AssignCaseTeam: Common_CWController.default.roles.SP_11_AssignCaseTeam.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rtXLTj6_D0et8huYGsAJ3w", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ZQze7dYo2kSqsQl_CB60NQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:WSwOoy24C0e7SkHxIa6lRw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseTeam$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_AssignCaseTeam$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_AssignCaseTeam$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_AssignCaseTeam$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_AssignCaseTeam.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_11_AssignCaseTeam)
};
});

define("Common_CW.controller$Check_SP_CancelCase", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_CancelCase.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_CancelCase_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_CancelCase$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_CancelCase$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:T7JF8ZUGmkiu0RFi7_EoBg:/ClientActionFlows.T7JF8ZUGmkiu0RFi7_EoBg:lG4E773hCzJjpeGv5yRZhw", "Common_CW", "Check_SP_CancelCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tNIYeFaSRkGm2lcoiQcNzA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:AlNw552U6kO8Q+SG+vjLZA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_CancelCase_JavaScriptJS, "JavaScript", "Check_SP_CancelCase", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_CancelCase$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_7_CancelCase: Common_CWController.default.roles.SP_7_CancelCase.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ldv8rAHO9kmbQFQo5gDpzw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:AwxqUlY7B0if79om4AttRA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:T7JF8ZUGmkiu0RFi7_EoBg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_CancelCase$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_CancelCase$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_CancelCase$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_CancelCase$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_CancelCase.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_7_CancelCase)
};
});

define("Common_CW.controller$Check_SP_CreateUpdateCloseCase", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_CreateUpdateCloseCase.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_CreateUpdateCloseCase_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_CreateUpdateCloseCase$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_CreateUpdateCloseCase$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:1RE44poQu0CJfCsPVkFbUg:/ClientActionFlows.1RE44poQu0CJfCsPVkFbUg:JtEfMJEjdiYBLFSJICGvnQ", "Common_CW", "Check_SP_CreateUpdateCloseCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_0opWepYBEKOXf3X1cByWQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LZ+Wgq5CrkGhPBIt78WPkQ", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_CreateUpdateCloseCase_JavaScriptJS, "JavaScript", "Check_SP_CreateUpdateCloseCase", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_CreateUpdateCloseCase$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_5_CreateUpdateCloseCase: Common_CWController.default.roles.SP_5_CreateUpdateCloseCase.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:JOfWkbblukS6aI4IMpVBOw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9jb0KmLZUUauAUy0Y7aMxA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:1RE44poQu0CJfCsPVkFbUg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_CreateUpdateCloseCase$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_CreateUpdateCloseCase$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_CreateUpdateCloseCase$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_CreateUpdateCloseCase$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_CreateUpdateCloseCase.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_5_CreateUpdateCloseCase)
};
});

define("Common_CW.controller$Check_SP_PlaceOnHoldCase", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_PlaceOnHoldCase.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_PlaceOnHoldCase_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_PlaceOnHoldCase$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_PlaceOnHoldCase$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:e7X2UlOBlkuf5fhOFz3_0g:/ClientActionFlows.e7X2UlOBlkuf5fhOFz3_0g:iw19LKZTQPTm8lER3k6PxA", "Common_CW", "Check_SP_PlaceOnHoldCase", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:VgDR7x3mL0GrrosNbiwKMw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GN3FKfwjikel0jhEQy5C3w", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_PlaceOnHoldCase_JavaScriptJS, "JavaScript", "Check_SP_PlaceOnHoldCase", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_PlaceOnHoldCase$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_6_PlaceonholdCase: Common_CWController.default.roles.SP_6_PlaceonholdCase.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:sqUxy5sqlECiPui5WA0t+g", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:c6evN5yMK0S2apjwKGPtlg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:e7X2UlOBlkuf5fhOFz3_0g", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_PlaceOnHoldCase$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_PlaceOnHoldCase$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_PlaceOnHoldCase$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_PlaceOnHoldCase$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_PlaceOnHoldCase.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_6_PlaceonholdCase)
};
});

define("Common_CW.controller$Check_SP_SearchRecord", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_SearchRecord.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_SearchRecord_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_SearchRecord$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_SearchRecord$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:LTvp6TFLuEqdZGPf1zuxIw:/ClientActionFlows.LTvp6TFLuEqdZGPf1zuxIw:_gtDlRK5PlqHXVvrb_AGCA", "Common_CW", "Check_SP_SearchRecord", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tJyhopoOf0iv6onScJDk6A", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nA0vGpdy6Ui5Sy+RSMEwFA", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_SearchRecord_JavaScriptJS, "JavaScript", "Check_SP_SearchRecord", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_SearchRecord$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_2_SearchRecord: Common_CWController.default.roles.SP_2_SearchRecord.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:n0ovqKydp0m0mRjNZ_0iKQ", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rAPsiiMscUCKrQV5LVkq8A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:LTvp6TFLuEqdZGPf1zuxIw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_SearchRecord$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_SearchRecord$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_SearchRecord$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_SearchRecord$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_SearchRecord.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_2_SearchRecord)
};
});

define("Common_CW.controller$Check_SP_ViewCases", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_ViewCases.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_ViewCases_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_ViewCases$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_ViewCases$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:joInj1WuJEWDtmpkaE1ehw:/ClientActionFlows.joInj1WuJEWDtmpkaE1ehw:_hmaSc7JwuAnXvDbaIFcAQ", "Common_CW", "Check_SP_ViewCases", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2bw4s4Dlf02v8the6YfiUw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2+2KjhnMEEO0cYYq4dvMcw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_ViewCases_JavaScriptJS, "JavaScript", "Check_SP_ViewCases", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_ViewCases$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_3_ViewCases: Common_CWController.default.roles.SP_3_ViewCases.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:CSFrsPQIHE2ylhgti4CNYw", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fUcm+0JUaUGMPjG6CL+w9w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:joInj1WuJEWDtmpkaE1ehw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_ViewCases$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_ViewCases$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_ViewCases$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_ViewCases$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_ViewCases.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_3_ViewCases)
};
});

define("Common_CW.controller$Check_SP_ViewRestrictedCases", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SP_ViewRestrictedCases.JavaScriptJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SP_ViewRestrictedCases_JavaScriptJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SP_ViewRestrictedCases$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var javaScriptJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_ViewRestrictedCases$outVars"))());
varBag.callContext = callContext;
varBag.javaScriptJSResult = javaScriptJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:AR0x70E61Eif5VuEfQOtKA:/ClientActionFlows.AR0x70E61Eif5VuEfQOtKA:9GdelBr+vLBnySV3bngT9w", "Common_CW", "Check_SP_ViewRestrictedCases", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fKPGQJlztEuFt3IivH9ATA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tlpRM3Z7IkmhQ5pxhPaXEw", callContext.id);
javaScriptJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SP_ViewRestrictedCases_JavaScriptJS, "JavaScript", "Check_SP_ViewRestrictedCases", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SP_ViewRestrictedCases$javaScriptJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_12_ViewRestrictedCases: Common_CWController.default.roles.SP_12_ViewRestrictedCases.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:6+24+t8yoE2nbyLBH_QepA", callContext.id);
// HasAccess = JavaScript.HasAccess
outVars.value.hasAccessOut = javaScriptJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:kYs685XNt0C8mOoY7ZAcUQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:AR0x70E61Eif5VuEfQOtKA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_ViewRestrictedCases$javaScriptJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SP_ViewRestrictedCases$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SP_ViewRestrictedCases$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SP_ViewRestrictedCases$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SP_ViewRestrictedCases.JavaScriptJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_12_ViewRestrictedCases)
};
});

define("Common_CW.controller$Check_SystemAdmin", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_SystemAdmin.HasSystemAdminJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_SystemAdmin_HasSystemAdminJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_SystemAdmin$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var hasSystemAdminJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_SystemAdmin$outVars"))());
varBag.callContext = callContext;
varBag.hasSystemAdminJSResult = hasSystemAdminJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:kZQmzeorsk+mxxWrzvUiJw:/ClientActionFlows.kZQmzeorsk+mxxWrzvUiJw:UdgDPe8WlDSBj16X08UuDw", "Common_CW", "Check_SystemAdmin", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GhSBQseKHk69F43xeIY0mw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Sm0ZaMBTNUWirRNk2WU+gg", callContext.id);
hasSystemAdminJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_SystemAdmin_HasSystemAdminJS, "HasSystemAdmin", "Check_SystemAdmin", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_SystemAdmin$hasSystemAdminJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SystemAdministrator: Common_CWController.default.roles.SystemAdministrator.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:1fmuzG0DykWR+TqKptVnoQ", callContext.id);
// HasAccess = HasSystemAdmin.HasAccess
outVars.value.hasAccessOut = hasSystemAdminJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dMVVrD4q0EKQwZBBpyL7fQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:kZQmzeorsk+mxxWrzvUiJw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SystemAdmin$hasSystemAdminJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_SystemAdmin$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_SystemAdmin$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_SystemAdmin$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_SystemAdmin.HasSystemAdminJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SystemAdministrator)
};
});

define("Common_CW.controller$Check_ViewDashboard", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Check_ViewDashboard.ViewDashboardJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Check_ViewDashboard_ViewDashboardJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.check_ViewDashboard$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var viewDashboardJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Check_ViewDashboard$outVars"))());
varBag.callContext = callContext;
varBag.viewDashboardJSResult = viewDashboardJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:AABIjIK7ykSNftqfcXgcZg:/ClientActionFlows.AABIjIK7ykSNftqfcXgcZg:avlFQ6X007zwIETsrLheTg", "Common_CW", "Check_ViewDashboard", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:x7FdoWYqckCvdQ6J4L+PAA", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Jsa2vcxRo0ebB0Viyse7LA", callContext.id);
viewDashboardJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_Check_ViewDashboard_ViewDashboardJS, "ViewDashboard", "Check_ViewDashboard", {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.Check_ViewDashboard$viewDashboardJSResult"))();
jsNodeResult.hasAccessOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasAccess, OS.Types.Boolean);
return jsNodeResult;
}, {}, {
SP_4_ViewDashboards: Common_CWController.default.roles.SP_4_ViewDashboards.roleKey
});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Zrwxm1AH6U2s6n_MR8O1gg", callContext.id);
// HasAccess = ViewDashboard.HasAccess
outVars.value.hasAccessOut = viewDashboardJSResult.value.hasAccessOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:8LVYxEhbZUOB3mEl6nij7A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:AABIjIK7ykSNftqfcXgcZg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ViewDashboard$viewDashboardJSResult", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Check_ViewDashboard$outVars", [{
name: "HasAccess",
attrName: "hasAccessOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.check_ViewDashboard$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.check_ViewDashboard$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
HasAccess: OS.DataConversion.JSNodeParamConverter.to(actionResults.hasAccessOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$Check_ViewDashboard.ViewDashboardJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasAccess = $public.Security.checkIfCurrentUserHasRole($roles.SP_4_ViewDashboards)
};
});

define("Common_CW.controller$CheckboxReturnOne", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$CheckboxReturnOne.cbChangeJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_CheckboxReturnOne_cbChangeJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.checkboxReturnOne$Action = function (classNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.CheckboxReturnOne$vars"))());
vars.value.classNameInLocal = classNameIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:n70emE98AkyEdYVk8b5x6A:/ClientActionFlows.n70emE98AkyEdYVk8b5x6A:D2EbpGDI_+H0A4fZif7pZQ", "Common_CW", "CheckboxReturnOne", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:DmYPqnM4+UyJXlTHOdeHfQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qkb6cUsMa0q31z8aAkHv+Q", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_CheckboxReturnOne_cbChangeJS, "cbChange", "CheckboxReturnOne", {
className: OS.DataConversion.JSNodeParamConverter.to(vars.value.classNameInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rnVpvzdbw0OXN9+yBJ9C5A", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:n70emE98AkyEdYVk8b5x6A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.CheckboxReturnOne$vars", [{
name: "className",
attrName: "classNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.checkboxReturnOne$Action = function (classNameIn) {
classNameIn = (classNameIn === undefined) ? "" : classNameIn;
return controller.executeActionInsideJSNode(Common_CWController.default.checkboxReturnOne$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(classNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$CheckboxReturnOne.cbChangeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function cbChange(obj) {
    var cbs = document.getElementsByClassName($parameters.className);
    for (var i = 0; i < cbs.length; i++) {
        cbs[i].checked = false;
    }
    obj.checked = true;
}
};
});

define("Common_CW.controller$ClearDropdownTag", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$ClearDropdownTag.JavaScript_ClearDropdownTagJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_ClearDropdownTag_JavaScript_ClearDropdownTagJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.clearDropdownTag$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ClearDropdownTag$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:f7zBB+456UmABgjndwawTw:/ClientActionFlows.f7zBB+456UmABgjndwawTw:cvXl5nw5gKwqHVZrOLmvDw", "Common_CW", "ClearDropdownTag", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XtspHj20KUKUyiHU2pTb+Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:lX8tVKXqHUCpdal3sfcxlA", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_ClearDropdownTag_JavaScript_ClearDropdownTagJS, "JavaScript_ClearDropdownTag", "ClearDropdownTag", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xk5uF3D5aU62DlkqEz7l6w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:f7zBB+456UmABgjndwawTw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ClearDropdownTag$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.clearDropdownTag$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(Common_CWController.default.clearDropdownTag$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$ClearDropdownTag.JavaScript_ClearDropdownTagJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(document.querySelector('#'+$parameters.WidgetId+' .vscomp-clear-button')) {
    document.querySelector('#'+$parameters.WidgetId+' .vscomp-clear-button').click();
}
};
});

define("Common_CW.controller$DecodeHTML", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$DecodeHTML.JavaScript_DecodeHTMLJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_DecodeHTML_JavaScript_DecodeHTMLJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.decodeHTML$Action = function (inputIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.DecodeHTML$vars"))());
vars.value.inputInLocal = inputIn;
var javaScript_DecodeHTMLJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.DecodeHTML$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.javaScript_DecodeHTMLJSResult = javaScript_DecodeHTMLJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:TaP_QzEwu0Wa6TFSXIAApg:/ClientActionFlows.TaP_QzEwu0Wa6TFSXIAApg:F1blNzCzNE_6Ve23FC4Dvw", "Common_CW", "DecodeHTML", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:l6EOBwXrRke_EX0HobHntA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fsUso7LkoE6as0yaPQw8lQ", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.inputInLocal) === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jlZte8Iyp0u3XIyXVDXT+g", callContext.id);
// Output = Input
outVars.value.outputOut = vars.value.inputInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fwtd+KwQAUu3mbBM8t4wLQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Nlls9m6aHkK+Qz9l3km7OA", callContext.id);
javaScript_DecodeHTMLJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_DecodeHTML_JavaScript_DecodeHTMLJS, "JavaScript_DecodeHTML", "DecodeHTML", {
Input: OS.DataConversion.JSNodeParamConverter.to(vars.value.inputInLocal, OS.Types.Text),
Output: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.DecodeHTML$javaScript_DecodeHTMLJSResult"))();
jsNodeResult.outputOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Output, OS.Types.Text);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:NfOtrkokoUiwIVR0OeyKzA", callContext.id) && (OS.BuiltinFunctions.trim(javaScript_DecodeHTMLJSResult.value.outputOut) === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ENty4jR9U02sBwXLBBTLtw", callContext.id);
// Output = Input
outVars.value.outputOut = vars.value.inputInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:j21cFt3ZD0uFYJP6_rXNlA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Gzl+rAMRsEymTjgRpyQozg", callContext.id);
// Output = JavaScript_DecodeHTML.Output
outVars.value.outputOut = javaScript_DecodeHTMLJSResult.value.outputOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:j21cFt3ZD0uFYJP6_rXNlA", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:TaP_QzEwu0Wa6TFSXIAApg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.DecodeHTML$vars", [{
name: "Input",
attrName: "inputInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.DecodeHTML$javaScript_DecodeHTMLJSResult", [{
name: "Output",
attrName: "outputOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.DecodeHTML$outVars", [{
name: "Output",
attrName: "outputOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.decodeHTML$Action = function (inputIn) {
inputIn = (inputIn === undefined) ? "" : inputIn;
return controller.executeActionInsideJSNode(Common_CWController.default.decodeHTML$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(inputIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Output: OS.DataConversion.JSNodeParamConverter.to(actionResults.outputOut, OS.Types.Text)
};
});
};
});
define("Common_CW.controller$DecodeHTML.JavaScript_DecodeHTMLJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var surrogate = encodeURIComponent($parameters.Input);
var result = '';
for (var i = 0; i < surrogate.length;) {
var character = surrogate[i];
    i += 1;
    if (character == '%') {
        var hex = surrogate.substring(i, i += 2);
        if (hex) {
            result += String.fromCharCode(parseInt(hex, 16));
        }
    } else {
        result += character;
    }
}
console.log(result);
$parameters.Output = result;
};
});

define("Common_CW.controller$DisabledWidget", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$DisabledWidget.JavaScript_DisableWidgetJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_DisabledWidget_JavaScript_DisableWidgetJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.disabledWidget$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.DisabledWidget$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:r7nJrOxaNEa12NWo2jsURg:/ClientActionFlows.r7nJrOxaNEa12NWo2jsURg:U_F4xF1pfySXM+jrPl7HVg", "Common_CW", "DisabledWidget", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qrNhAsiQF0aTMtswLr4M3A", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:iNr9CMn3JUK45TBOH38Rvw", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_DisabledWidget_JavaScript_DisableWidgetJS, "JavaScript_DisableWidget", "DisabledWidget", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:8Fsiox+MzESfq2cCWQfzBg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:r7nJrOxaNEa12NWo2jsURg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.DisabledWidget$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.disabledWidget$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(Common_CWController.default.disabledWidget$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$DisabledWidget.JavaScript_DisableWidgetJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function(){
    document.getElementById($parameters.WidgetId).setAttribute('disabled', '');
},5000);
};
});

define("Common_CW.controller$GetImage", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$GetImage.Base64ToBinaryJS", "Common_CW.clientVariables", "Common_CW.controller$ImageFormatChecking"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_GetImage_Base64ToBinaryJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.getImage$Action = function (base64In, fileNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.GetImage$vars"))());
vars.value.base64InLocal = base64In;
vars.value.fileNameInLocal = fileNameIn;
var imageFormatCheckingVar = new OS.DataTypes.VariableHolder();
var base64ToBinaryJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.GetImage$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.imageFormatCheckingVar = imageFormatCheckingVar;
varBag.base64ToBinaryJSResult = base64ToBinaryJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:PtxawGchK0O3z+NwXkJxDg:/ClientActionFlows.PtxawGchK0O3z+NwXkJxDg:6hNpL7K84ZcQKjfUvZL1hg", "Common_CW", "GetImage", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:6oTmF_uHi0SCbvysTSJceQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:KkvN+Ov8nUmvcdk5RYk0OA", callContext.id);
base64ToBinaryJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_GetImage_Base64ToBinaryJS, "Base64ToBinary", "GetImage", {
base64String: OS.DataConversion.JSNodeParamConverter.to(vars.value.base64InLocal, OS.Types.Text),
BinaryData: OS.DataConversion.JSNodeParamConverter.to(OS.DataTypes.BinaryData.defaultValue, OS.Types.BinaryData)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.GetImage$base64ToBinaryJSResult"))();
jsNodeResult.binaryDataOut = OS.DataConversion.JSNodeParamConverter.from($parameters.BinaryData, OS.Types.BinaryData);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:dQmzd0tQ7kuRCiGV7DU4+w", callContext.id);
// Execute Action: ImageFormatChecking
imageFormatCheckingVar.value = Common_CWController.default.imageFormatChecking$Action(vars.value.fileNameInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:5AELOKRUWkqRtoHTWP0ooQ", callContext.id) && imageFormatCheckingVar.value.isSVGOut)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TsSzR376kUmTmptdJvCClw", callContext.id);
// SVGLogo = Base64
outVars.value.sVGLogoOut = vars.value.base64InLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TsSzR376kUmTmptdJvCClw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSVGLogo = True
outVars.value.isSVGLogoOut = true;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Fj8LutHLXESeNpokDtg2ww", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qalIUGJD50Whfcq9_rt5pQ", callContext.id);
// IsSVGLogo = False
outVars.value.isSVGLogoOut = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qalIUGJD50Whfcq9_rt5pQ", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Image = Base64ToBinary.BinaryData
outVars.value.imageOut = base64ToBinaryJSResult.value.binaryDataOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Fj8LutHLXESeNpokDtg2ww", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:PtxawGchK0O3z+NwXkJxDg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.GetImage$vars", [{
name: "Base64",
attrName: "base64InLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "FileName",
attrName: "fileNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.GetImage$base64ToBinaryJSResult", [{
name: "BinaryData",
attrName: "binaryDataOut",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.GetImage$outVars", [{
name: "Image",
attrName: "imageOut",
mandatory: false,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "SVGLogo",
attrName: "sVGLogoOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsSVGLogo",
attrName: "isSVGLogoOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.getImage$Action = function (base64In, fileNameIn) {
base64In = (base64In === undefined) ? "" : base64In;
fileNameIn = (fileNameIn === undefined) ? "" : fileNameIn;
return controller.executeActionInsideJSNode(Common_CWController.default.getImage$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(base64In, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(fileNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Image: OS.DataConversion.JSNodeParamConverter.to(actionResults.imageOut, OS.Types.BinaryData),
SVGLogo: OS.DataConversion.JSNodeParamConverter.to(actionResults.sVGLogoOut, OS.Types.Text),
IsSVGLogo: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSVGLogoOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$GetImage.Base64ToBinaryJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var encodedText = window.btoa( $parameters.base64String );
$parameters.BinaryData = encodedText;
};
});

define("Common_CW.controller$GetRequiredFieldMsg", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.getRequiredFieldMsg$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.GetRequiredFieldMsg$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:_5okDhQmn0GEg7QQpuLC3Q:/ClientActionFlows._5okDhQmn0GEg7QQpuLC3Q:MGnb2zGJds+v9VxNGfM_oA", "Common_CW", "GetRequiredFieldMsg", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rMi_AaL3tku2n8tFq_4Yfw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ctGUInM3nUioHNea8YI8xw", callContext.id);
// Msg = "Required field"
outVars.value.msgOut = "Required field";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MDo9r9B5qUSrziVPCm3Vzg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:_5okDhQmn0GEg7QQpuLC3Q", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.GetRequiredFieldMsg$outVars", [{
name: "Msg",
attrName: "msgOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.getRequiredFieldMsg$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.getRequiredFieldMsg$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Msg: OS.DataConversion.JSNodeParamConverter.to(actionResults.msgOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$HexValidation", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables", "Common_CW.controller$ServerAction.Regex_Search"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.hexValidation$Action = function (hexCodeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.HexValidation$vars"))());
vars.value.hexCodeInLocal = hexCodeIn;
var regex_SearchVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.HexValidation$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.regex_SearchVar = regex_SearchVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ISz0Atwm_Uq_usSpv_16SA:/ClientActionFlows.ISz0Atwm_Uq_usSpv_16SA:FeKr+qzPSB32Yc5+elv+uA", "Common_CW", "HexValidation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TXkYaJHKD0mIIm0yfDvhiA", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:POUjPsboPUuwWDyKXEsFqg", callContext.id) && ((vars.value.hexCodeInLocal === "") || (vars.value.hexCodeInLocal === "#")))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nnBts1eWREmdvzO2hb2n5w", callContext.id);
// IsEmpty = True
outVars.value.isEmptyOut = true;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qtMfhefuUkmeYGHbr8mH5A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:G22xHMuF40K_tFNYIfNDKg", callContext.id);
// Execute Action: Regex_Search
return controller.regex_Search$ServerAction(vars.value.hexCodeInLocal, "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$", true, true, false, callContext).then(function (value) {
regex_SearchVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:q9FqVkj1jEibWzNXzr6AIA", callContext.id);
// IsValid = Regex_Search.Found
outVars.value.isValidOut = regex_SearchVar.value.foundOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qtMfhefuUkmeYGHbr8mH5A", callContext.id);
});
}

});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ISz0Atwm_Uq_usSpv_16SA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ISz0Atwm_Uq_usSpv_16SA", callContext.id);
throw ex;

});
};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.HexValidation$vars", [{
name: "HexCode",
attrName: "hexCodeInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.HexValidation$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsEmpty",
attrName: "isEmptyOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.hexValidation$Action = function (hexCodeIn) {
hexCodeIn = (hexCodeIn === undefined) ? "" : hexCodeIn;
return controller.executeActionInsideJSNode(Common_CWController.default.hexValidation$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hexCodeIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean),
IsEmpty: OS.DataConversion.JSNodeParamConverter.to(actionResults.isEmptyOut, OS.Types.Boolean)
};
});
};
});

define("Common_CW.controller$ImageComparison", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables", "Common_CW.controller$ServerAction.ImageComparison"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.imageComparison$Action = function (oldImageIn, newImageIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ImageComparison$vars"))());
vars.value.oldImageInLocal = oldImageIn;
vars.value.newImageInLocal = newImageIn;
var imageComparisonVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ImageComparison$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.imageComparisonVar = imageComparisonVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:pMT7jgjWz0mX6cWsrxnyRA:/ClientActionFlows.pMT7jgjWz0mX6cWsrxnyRA:3XasKn9VpOJmm0WHybFcLg", "Common_CW", "ImageComparison", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cOHILyoEs024izoRIgsnNw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OBWVFB_ktkq73eov2MWepw", callContext.id);
// Execute Action: ImageComparison
return controller.imageComparison$ServerAction(vars.value.oldImageInLocal, vars.value.newImageInLocal, callContext).then(function (value) {
imageComparisonVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:H8tDKwwmH0y7Usg3HFArzw", callContext.id);
// IsMatched = ImageComparison.IsMatched
outVars.value.isMatchedOut = imageComparisonVar.value.isMatchedOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:QHN7R4vl3E6EWIHY5+AaHQ", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:pMT7jgjWz0mX6cWsrxnyRA", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:pMT7jgjWz0mX6cWsrxnyRA", callContext.id);
throw ex;

});
};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ImageComparison$vars", [{
name: "OldImage",
attrName: "oldImageInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "newImage",
attrName: "newImageInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ImageComparison$outVars", [{
name: "IsMatched",
attrName: "isMatchedOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.imageComparison$Action = function (oldImageIn, newImageIn) {
oldImageIn = (oldImageIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : oldImageIn;
newImageIn = (newImageIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : newImageIn;
return controller.executeActionInsideJSNode(Common_CWController.default.imageComparison$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(oldImageIn, OS.Types.BinaryData), OS.DataConversion.JSNodeParamConverter.from(newImageIn, OS.Types.BinaryData)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsMatched: OS.DataConversion.JSNodeParamConverter.to(actionResults.isMatchedOut, OS.Types.Boolean)
};
});
};
});

define("Common_CW.controller$ImageFormatChecking", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$ImageFormatChecking.RegexIsSVGJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_ImageFormatChecking_RegexIsSVGJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.imageFormatChecking$Action = function (filenameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ImageFormatChecking$vars"))());
vars.value.filenameInLocal = filenameIn;
var regexIsSVGJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ImageFormatChecking$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.regexIsSVGJSResult = regexIsSVGJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:ZphWgi5OV0qY+A7O2987Sw:/ClientActionFlows.ZphWgi5OV0qY+A7O2987Sw:jWVjQ304E56VCskLRI1vQQ", "Common_CW", "ImageFormatChecking", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:E4KB5N34kUa+bF9ydcWTcg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_jnHTB+MDUeIB86fTExYEQ", callContext.id);
regexIsSVGJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_ImageFormatChecking_RegexIsSVGJS, "RegexIsSVG", "ImageFormatChecking", {
Filename: OS.DataConversion.JSNodeParamConverter.to(vars.value.filenameInLocal, OS.Types.Text),
IsImage: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean),
IsSVG: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.ImageFormatChecking$regexIsSVGJSResult"))();
jsNodeResult.isImageOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsImage, OS.Types.Boolean);
jsNodeResult.isSVGOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsSVG, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FTM4vX+yV0ahOVrL4s8qCA", callContext.id);
// IsSVG = RegexIsSVG.IsSVG
outVars.value.isSVGOut = regexIsSVGJSResult.value.isSVGOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FTM4vX+yV0ahOVrL4s8qCA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsImage = RegexIsSVG.IsImage
outVars.value.isImageOut = regexIsSVGJSResult.value.isImageOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2tM14ZhixEW974okOqlURg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:ZphWgi5OV0qY+A7O2987Sw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ImageFormatChecking$vars", [{
name: "Filename",
attrName: "filenameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ImageFormatChecking$regexIsSVGJSResult", [{
name: "IsImage",
attrName: "isImageOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsSVG",
attrName: "isSVGOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ImageFormatChecking$outVars", [{
name: "IsSVG",
attrName: "isSVGOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsImage",
attrName: "isImageOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.imageFormatChecking$Action = function (filenameIn) {
filenameIn = (filenameIn === undefined) ? "" : filenameIn;
return controller.executeActionInsideJSNode(Common_CWController.default.imageFormatChecking$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(filenameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsSVG: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSVGOut, OS.Types.Boolean),
IsImage: OS.DataConversion.JSNodeParamConverter.to(actionResults.isImageOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$ImageFormatChecking.RegexIsSVGJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var imageRGEX=/^.*\.(svg|SVG|jpg|JPG|jpeg|JPEG|png|PNG)$/
var svgRGEX=/^.*\.(svg|SVG)$/
 
$parameters.IsImage = imageRGEX.test($parameters.Filename);
$parameters.IsSVG =  svgRGEX.test($parameters.Filename);
};
});

define("Common_CW.controller$Logging_FormatDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.logging_FormatDate$Action = function (dateIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Logging_FormatDate$vars"))());
vars.value.dateInLocal = dateIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Logging_FormatDate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:8t6ueusDmESXPi2YSleKZw:/ClientActionFlows.8t6ueusDmESXPi2YSleKZw:lJIJ69f_c6KWvfu++e23ZA", "Common_CW", "Logging_FormatDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:MPx8YibTs02jSvksdg9xvg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:30SnNjLzuEuD9BEDZXz_IQ", callContext.id);
// FormattedDT = If
outVars.value.formattedDTOut = (((OS.BuiltinFunctions.timeToText(OS.BuiltinFunctions.newTime(OS.BuiltinFunctions.hour(vars.value.dateInLocal), OS.BuiltinFunctions.minute(vars.value.dateInLocal), OS.BuiltinFunctions.second(vars.value.dateInLocal))) === "00:00:00")) ? (OS.BuiltinFunctions.formatDateTime(vars.value.dateInLocal, "dd/MM/yyyy")) : (OS.BuiltinFunctions.formatDateTime(vars.value.dateInLocal, "dd/MM/yyyy hh:mm:ss")));
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:H6suoPiEok+f96nWX8ZzHQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:8t6ueusDmESXPi2YSleKZw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Logging_FormatDate$vars", [{
name: "Date",
attrName: "dateInLocal",
mandatory: true,
dataType: OS.Types.DateTime,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Logging_FormatDate$outVars", [{
name: "FormattedDT",
attrName: "formattedDTOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.logging_FormatDate$Action = function (dateIn) {
dateIn = (dateIn === undefined) ? OS.DataTypes.DateTime.defaultValue : dateIn;
return controller.executeActionInsideJSNode(Common_CWController.default.logging_FormatDate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(dateIn, OS.Types.DateTime)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
FormattedDT: OS.DataConversion.JSNodeParamConverter.to(actionResults.formattedDTOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$LogoValidation", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$LogoValidation.ToMbJS", "Common_CW.controller$LogoValidation.JavaScript_GetSizeJS", "Common_CW.clientVariables", "Common_CW.controller$ImageFormatChecking"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_LogoValidation_ToMbJS, Common_CW_controller_LogoValidation_JavaScript_GetSizeJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.logoValidation$Action = function (logoIn, fileNameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.LogoValidation$vars"))());
vars.value.logoInLocal = logoIn;
vars.value.fileNameInLocal = fileNameIn;
var imageFormatCheckingVar = new OS.DataTypes.VariableHolder();
var toMbJSResult = new OS.DataTypes.VariableHolder();
var javaScript_GetSizeJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.LogoValidation$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.imageFormatCheckingVar = imageFormatCheckingVar;
varBag.toMbJSResult = toMbJSResult;
varBag.javaScript_GetSizeJSResult = javaScript_GetSizeJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:qCqnk8XbMEaQqbPFRVpwvQ:/ClientActionFlows.qCqnk8XbMEaQqbPFRVpwvQ:VcVsjiPH9JsLbWWvz1K8gw", "Common_CW", "LogoValidation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:APa0GsTKOEyhZBxpqnQhpw", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tTl_snsF6UWWESaVxM7U9A", callContext.id);
// Execute Action: ImageFormatChecking
imageFormatCheckingVar.value = Common_CWController.default.imageFormatChecking$Action(vars.value.fileNameInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:9lQVlnXWGku_L7i_wJX0eg", callContext.id) && (vars.value.fileNameInLocal === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nk6BQc0NJEOR9rZhkGaPSg", callContext.id);
// ErrorMessage = ""
outVars.value.errorMessageOut = "";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:GnugNoiPsEO2FlwCujpqqA", callContext.id);
} else {
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ThRlafPya0iKKv4LHX1oWA", callContext.id) && imageFormatCheckingVar.value.isImageOut)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:bhU05lBqj0qr+rFUJOwYQg", callContext.id);
javaScript_GetSizeJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_LogoValidation_JavaScript_GetSizeJS, "JavaScript_GetSize", "LogoValidation", {
Logo: OS.DataConversion.JSNodeParamConverter.to(vars.value.logoInLocal, OS.Types.BinaryData),
Size: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.LogoValidation$javaScript_GetSizeJSResult"))();
jsNodeResult.sizeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Size, OS.Types.Integer);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qLQAvuC1LEmAVZ3VJOy0vQ", callContext.id);
toMbJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_LogoValidation_ToMbJS, "ToMb", "LogoValidation", {
BinaryTotalSize: OS.DataConversion.JSNodeParamConverter.to(javaScript_GetSizeJSResult.value.sizeOut, OS.Types.Integer),
Size: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.LogoValidation$toMbJSResult"))();
jsNodeResult.sizeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Size, OS.Types.Integer);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tfeFA2U_4kSgi+uL0Vwusw", callContext.id) && (toMbJSResult.value.sizeOut >= 1))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:xZEiUlBnu02XOfmwBdHXLw", callContext.id);
// ErrorMessage = "This image is too large, maximum file size 1MB."
outVars.value.errorMessageOut = "This image is too large, maximum file size 1MB.";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qu9cGm3qNEGdRCu5AtADOA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:v85+Ob5JQEyWtoBnfp04BA", callContext.id);
// ErrorMessage = ""
outVars.value.errorMessageOut = "";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:pSCysO4bJU2eAVSLKHw4jw", callContext.id);
}

} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:SAI41Chny0CoUlYxxr2Uyw", callContext.id);
// ErrorMessage = "Invalid file format, file types allowed png, jpg, jpeg, svg"
outVars.value.errorMessageOut = "Invalid file format, file types allowed png, jpg, jpeg, svg";
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ktcyFRKEXU6R34H6spm_kw", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:qCqnk8XbMEaQqbPFRVpwvQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.LogoValidation$vars", [{
name: "Logo",
attrName: "logoInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "FileName",
attrName: "fileNameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.LogoValidation$toMbJSResult", [{
name: "Size",
attrName: "sizeOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.LogoValidation$javaScript_GetSizeJSResult", [{
name: "Size",
attrName: "sizeOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.LogoValidation$outVars", [{
name: "ErrorMessage",
attrName: "errorMessageOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.logoValidation$Action = function (logoIn, fileNameIn) {
logoIn = (logoIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : logoIn;
fileNameIn = (fileNameIn === undefined) ? "" : fileNameIn;
return controller.executeActionInsideJSNode(Common_CWController.default.logoValidation$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(logoIn, OS.Types.BinaryData), OS.DataConversion.JSNodeParamConverter.from(fileNameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(actionResults.errorMessageOut, OS.Types.Text)
};
});
};
});
define("Common_CW.controller$LogoValidation.ToMbJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Size = $parameters.BinaryTotalSize / Math.pow(1024,2);
};
});
define("Common_CW.controller$LogoValidation.JavaScript_GetSizeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var binary_string =  window.atob($parameters.Logo);
$parameters.Size =  binary_string.length;
};
});

define("Common_CW.controller$MSD_JoinIDs", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables", "Common_CW.model$TextRecordList", "Common_CW.controller$String_Join", "Common_CW.model$MSD_ItemList"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.mSD_JoinIDs$Action = function (mSD_ItemIn, separatorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.MSD_JoinIDs$vars"))());
vars.value.mSD_ItemInLocal = mSD_ItemIn.clone();
vars.value.separatorInLocal = separatorIn;
var string_JoinVar = new OS.DataTypes.VariableHolder();
var listFilterVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.MSD_JoinIDs$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.string_JoinVar = string_JoinVar;
varBag.listFilterVar = listFilterVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:dg8_HmT4TkagBLcXNVvcag:/ClientActionFlows.dg8_HmT4TkagBLcXNVvcag:IUxuBA1NaNVdgFt1VaXNxA", "Common_CW", "MSD_JoinIDs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:BPo5dK_v0kKpK7cKXuYudQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:XIsIjo1UDUarqsVyKftbPQ", callContext.id);
// Execute Action: ListFilter
listFilterVar.value = OS.SystemActions.listFilter(vars.value.mSD_ItemInLocal, function (p) {
return p.isSelectedAttr;
}, callContext);

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qKGuPJjCuEGHHA9fDGXH0A", callContext.id);
// Execute Action: String_Join
string_JoinVar.value = Common_CWController.default.string_Join$Action(OS.DataConversion.JSConversions.typeConvertRecordList(listFilterVar.value.filteredListOut, new Common_CWModel.TextRecordList(), function (source, target) {
target.textAttr.valueAttr = source.itemIdAttr;
return target;
}), vars.value.separatorInLocal, callContext);

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:l30XN0KUfEap0EQ+ZbHvLg", callContext.id);
// JoinedStrings = String_Join.Text
outVars.value.joinedStringsOut = string_JoinVar.value.textOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:SW5HW7rmTkmaKa4f4G1Ohw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:dg8_HmT4TkagBLcXNVvcag", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.MSD_JoinIDs$vars", [{
name: "MSD_Item",
attrName: "mSD_ItemInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new Common_CWModel.MSD_ItemList();
},
complexType: Common_CWModel.MSD_ItemList
}, {
name: "Separator",
attrName: "separatorInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "|";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.MSD_JoinIDs$outVars", [{
name: "JoinedStrings",
attrName: "joinedStringsOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.mSD_JoinIDs$Action = function (mSD_ItemIn, separatorIn) {
mSD_ItemIn = (mSD_ItemIn === undefined) ? new Common_CWModel.MSD_ItemList() : mSD_ItemIn;
separatorIn = (separatorIn === undefined) ? "|" : separatorIn;
return controller.executeActionInsideJSNode(Common_CWController.default.mSD_JoinIDs$Action.bind(controller, mSD_ItemIn, OS.DataConversion.JSNodeParamConverter.from(separatorIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
JoinedStrings: OS.DataConversion.JSNodeParamConverter.to(actionResults.joinedStringsOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$OnValidate_Flags", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables", "Common_CW.model$FlagItemList", "Common_CW.controller$ServerAction.ValidateFlagsByPermissions"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.onValidate_Flags$Action = function (flags_ListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.OnValidate_Flags$vars"))());
vars.value.flags_ListInLocal = flags_ListIn.clone();
var validateFlagsByPermissionsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.OnValidate_Flags$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.validateFlagsByPermissionsVar = validateFlagsByPermissionsVar;
varBag.outVars = outVars;
OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:gPVsZ4XbHkqoMia3pr_Mgw:/ClientActionFlows.gPVsZ4XbHkqoMia3pr_Mgw:sXinQzDvZCeujJxeXNM6SQ", "Common_CW", "OnValidate_Flags", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PEEFMt63r02+arrOciEs2A", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tVytN46ceUiuyh1BhD1VYQ", callContext.id);
// Execute Action: ValidateFlagsByPermissions
return controller.validateFlagsByPermissions$ServerAction(vars.value.flags_ListInLocal, callContext).then(function (value) {
validateFlagsByPermissionsVar.value = value;
}).then(function () {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:G+U+Zryd5k2wLltndss+bQ", callContext.id);
// IsValid = ValidateFlagsByPermissions.IsValid
outVars.value.isValidOut = validateFlagsByPermissionsVar.value.isValidOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:IV1xWUeDe0mTxZZnJzKCLw", callContext.id);
});
}).then(function () {
return outVars.value;
}).then(function (res) {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:gPVsZ4XbHkqoMia3pr_Mgw", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:gPVsZ4XbHkqoMia3pr_Mgw", callContext.id);
throw ex;

});
};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.OnValidate_Flags$vars", [{
name: "Flags_List",
attrName: "flags_ListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new Common_CWModel.FlagItemList();
},
complexType: Common_CWModel.FlagItemList
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.OnValidate_Flags$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.onValidate_Flags$Action = function (flags_ListIn) {
flags_ListIn = (flags_ListIn === undefined) ? new Common_CWModel.FlagItemList() : flags_ListIn;
return controller.executeActionInsideJSNode(Common_CWController.default.onValidate_Flags$Action.bind(controller, flags_ListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});

define("Common_CW.controller$ReplaceIfBlank", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.replaceIfBlank$Action = function (valueInIn, replacementIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfBlank$vars"))());
vars.value.valueInInLocal = valueInIn;
vars.value.replacementInLocal = replacementIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfBlank$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:_JBVh8IXcEuodkao2q0x5A:/ClientActionFlows._JBVh8IXcEuodkao2q0x5A:eA4oGXVAYCHZM9yDj4T5HQ", "Common_CW", "ReplaceIfBlank", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:FxsirRcK5Em+tZovlO2_OA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:jLnNsRkYn0CJXd3I74ofVQ", callContext.id) && (OS.BuiltinFunctions.trim(vars.value.valueInInLocal) === ""))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cytu7EXv_EmmuJaSOori1g", callContext.id);
// ValueOut = Replacement
outVars.value.valueOutOut = vars.value.replacementInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nFi4VMOCmUSDuMclq78OlQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cva0RYbMN0qkW83ezr1GkQ", callContext.id);
// ValueOut = ValueIn
outVars.value.valueOutOut = vars.value.valueInInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:nFi4VMOCmUSDuMclq78OlQ", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:_JBVh8IXcEuodkao2q0x5A", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfBlank$vars", [{
name: "ValueIn",
attrName: "valueInInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Replacement",
attrName: "replacementInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "-";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfBlank$outVars", [{
name: "ValueOut",
attrName: "valueOutOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.replaceIfBlank$Action = function (valueInIn, replacementIn) {
valueInIn = (valueInIn === undefined) ? "" : valueInIn;
replacementIn = (replacementIn === undefined) ? "-" : replacementIn;
return controller.executeActionInsideJSNode(Common_CWController.default.replaceIfBlank$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(valueInIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(replacementIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ValueOut: OS.DataConversion.JSNodeParamConverter.to(actionResults.valueOutOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$ReplaceIfNullDate", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.replaceIfNullDate$Action = function (valueInIn, replacementIn, formatIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfNullDate$vars"))());
vars.value.valueInInLocal = valueInIn;
vars.value.replacementInLocal = replacementIn;
vars.value.formatInLocal = formatIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfNullDate$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:I5cEcEobX0C146sBT5T80Q:/ClientActionFlows.I5cEcEobX0C146sBT5T80Q:kM+GF8DwHKtQeVXH_qHjRg", "Common_CW", "ReplaceIfNullDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:i4Mbpft_fkON+uKNmiUTAQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:PshSbxXU7EiMT8w9bWhX0w", callContext.id) && vars.value.valueInInLocal.equals(OS.BuiltinFunctions.nullDate()))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:mE4XWveaGUGcYuUolg2T0A", callContext.id);
// ValueOut = Replacement
outVars.value.valueOutOut = vars.value.replacementInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Awg2edkHRkCg3Q943+AB7A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hnDPA4k9iEKYcoFomngoXw", callContext.id);
// ValueOut = FormatDateTime
outVars.value.valueOutOut = OS.BuiltinFunctions.formatDateTime(vars.value.valueInInLocal, vars.value.formatInLocal);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Awg2edkHRkCg3Q943+AB7A", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:I5cEcEobX0C146sBT5T80Q", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfNullDate$vars", [{
name: "ValueIn",
attrName: "valueInInLocal",
mandatory: true,
dataType: OS.Types.DateTime,
defaultValue: function () {
return OS.DataTypes.DateTime.defaultValue;
}
}, {
name: "Replacement",
attrName: "replacementInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "-";
}
}, {
name: "Format",
attrName: "formatInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "dd/MM/yyyy";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfNullDate$outVars", [{
name: "ValueOut",
attrName: "valueOutOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.replaceIfNullDate$Action = function (valueInIn, replacementIn, formatIn) {
valueInIn = (valueInIn === undefined) ? OS.DataTypes.DateTime.defaultValue : valueInIn;
replacementIn = (replacementIn === undefined) ? "-" : replacementIn;
formatIn = (formatIn === undefined) ? "dd/MM/yyyy" : formatIn;
return controller.executeActionInsideJSNode(Common_CWController.default.replaceIfNullDate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(valueInIn, OS.Types.DateTime), OS.DataConversion.JSNodeParamConverter.from(replacementIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(formatIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ValueOut: OS.DataConversion.JSNodeParamConverter.to(actionResults.valueOutOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$ReplaceIfZero", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.replaceIfZero$Action = function (valueInIn, replacementIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfZero$vars"))());
vars.value.valueInInLocal = valueInIn;
vars.value.replacementInLocal = replacementIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ReplaceIfZero$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:oNgiF+UTJku_TY8qAGx3DQ:/ClientActionFlows.oNgiF+UTJku_TY8qAGx3DQ:iZUcablQHJVwl8CVPhLnbQ", "Common_CW", "ReplaceIfZero", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Ja6iq23l1k24DqCAB1MOPw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ufpg6rOs9ka5mOb27AoPqQ", callContext.id) && vars.value.valueInInLocal.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:YcJ0+VfYgU290Vp7Q4A6Tw", callContext.id);
// ValueOut = Replacement
outVars.value.valueOutOut = vars.value.replacementInLocal;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3+rd6PDKnkWZgGdEjMffVw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:uxmC7tEwvkim8SNuq4XjSg", callContext.id);
// ValueOut = ValueIn
outVars.value.valueOutOut = OS.BuiltinFunctions.longIntegerToText(vars.value.valueInInLocal);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3+rd6PDKnkWZgGdEjMffVw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:oNgiF+UTJku_TY8qAGx3DQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfZero$vars", [{
name: "ValueIn",
attrName: "valueInInLocal",
mandatory: true,
dataType: OS.Types.LongInteger,
defaultValue: function () {
return OS.DataTypes.LongInteger.defaultValue;
}
}, {
name: "Replacement",
attrName: "replacementInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "-";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ReplaceIfZero$outVars", [{
name: "ValueOut",
attrName: "valueOutOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.replaceIfZero$Action = function (valueInIn, replacementIn) {
valueInIn = (valueInIn === undefined) ? OS.DataTypes.LongInteger.defaultValue : valueInIn;
replacementIn = (replacementIn === undefined) ? "-" : replacementIn;
return controller.executeActionInsideJSNode(Common_CWController.default.replaceIfZero$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(valueInIn, OS.Types.LongInteger), OS.DataConversion.JSNodeParamConverter.from(replacementIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ValueOut: OS.DataConversion.JSNodeParamConverter.to(actionResults.valueOutOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$ResetBranding", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.resetBranding$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:wZkTrkSesEaPxzRahd28yQ:/ClientActionFlows.wZkTrkSesEaPxzRahd28yQ:ZTeFz6fMN_zMzxGg9C8B3g", "Common_CW", "ResetBranding", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:it9W0OPHD0SMzV28hfNUDg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TkerS9QTlkuPofxOHZpEMw", callContext.id);
// TenantLogo = ""
Common_CWClientVariables.setTenantLogo("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TkerS9QTlkuPofxOHZpEMw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// PrimaryColor = ""
Common_CWClientVariables.setPrimaryColor("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:TkerS9QTlkuPofxOHZpEMw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// LogoFileName = ""
Common_CWClientVariables.setLogoFileName("");
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:7hqQGx_gnUaRdYVXfFGa7w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:wZkTrkSesEaPxzRahd28yQ", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.clientActionProxies.resetBranding$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.resetBranding$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("Common_CW.controller$SelectActiveStep", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.selectActiveStep$Action = function (widgetOrderIn, currentSelectedStepIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.SelectActiveStep$vars"))());
vars.value.widgetOrderInLocal = widgetOrderIn;
vars.value.currentSelectedStepInLocal = currentSelectedStepIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.SelectActiveStep$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:DZUrk03uSE2yETSZ4HB7fg:/ClientActionFlows.DZUrk03uSE2yETSZ4HB7fg:JfWu8KmUxqouXGb2RO9J_A", "Common_CW", "SelectActiveStep", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:fhrrXIkVRk2Z7ZDPvOVuhg", callContext.id);
// WidgetBefore
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:ASCYRNM6F0OiObeg3wOCeA", callContext.id) && (vars.value.widgetOrderInLocal < vars.value.currentSelectedStepInLocal))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:tPJdn5blWUaaYdgwhtrzpQ", callContext.id);
// WizardStatus = Past
outVars.value.wizardStatusOut = Common_CWModel.staticEntities.steps.past;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:W3y8JEr6LkSJpsEoy53VBA", callContext.id);
} else {
// Widget After
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LJReRRtg4EmM04Kz916s1A", callContext.id) && (vars.value.widgetOrderInLocal > vars.value.currentSelectedStepInLocal))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:hwNAkg7GXUWVeWxvPC2jmQ", callContext.id);
// WizardStatus = Next
outVars.value.wizardStatusOut = Common_CWModel.staticEntities.steps.next;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:W3y8JEr6LkSJpsEoy53VBA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:o_10BQnRiEK08GFVvtdgtQ", callContext.id);
// WizardStatus = Active
outVars.value.wizardStatusOut = Common_CWModel.staticEntities.steps.active;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:z5dM7QSqEkeNy572JyUT2A", callContext.id);
}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:DZUrk03uSE2yETSZ4HB7fg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SelectActiveStep$vars", [{
name: "WidgetOrder",
attrName: "widgetOrderInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "CurrentSelectedStep",
attrName: "currentSelectedStepInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SelectActiveStep$outVars", [{
name: "WizardStatus",
attrName: "wizardStatusOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.selectActiveStep$Action = function (widgetOrderIn, currentSelectedStepIn) {
widgetOrderIn = (widgetOrderIn === undefined) ? 0 : widgetOrderIn;
currentSelectedStepIn = (currentSelectedStepIn === undefined) ? 0 : currentSelectedStepIn;
return controller.executeActionInsideJSNode(Common_CWController.default.selectActiveStep$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetOrderIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(currentSelectedStepIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
WizardStatus: actionResults.wizardStatusOut
};
});
};
});

define("Common_CW.controller$SelectFocus", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$SelectFocus.SetFocusJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_SelectFocus_SetFocusJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.selectFocus$Action = function (elementIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.SelectFocus$vars"))());
vars.value.elementIdInLocal = elementIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:VvOW_GjpIUSE8SdTp6qZkA:/ClientActionFlows.VvOW_GjpIUSE8SdTp6qZkA:2d5lEPHrV8CmevtbL+y23Q", "Common_CW", "SelectFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:AEOA4VE0sUeyQz5yj1s46w", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:VcOMdsFlLU+Pf7lOMySOvw", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_SelectFocus_SetFocusJS, "SetFocus", "SelectFocus", {
ElementSelector: OS.DataConversion.JSNodeParamConverter.to(vars.value.elementIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rhhtdKZLBEaFzZetVBHtxw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:VvOW_GjpIUSE8SdTp6qZkA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SelectFocus$vars", [{
name: "ElementId",
attrName: "elementIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.selectFocus$Action = function (elementIdIn) {
elementIdIn = (elementIdIn === undefined) ? "" : elementIdIn;
return controller.executeActionInsideJSNode(Common_CWController.default.selectFocus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(elementIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$SelectFocus.SetFocusJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function() {
    $($parameters.ElementSelector).focus();
}, 300);
};
});

define("Common_CW.controller$Set_Focus", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$Set_Focus.GetPopupIdJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_Set_Focus_GetPopupIdJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.set_Focus$Action = function (isShowIn, widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.Set_Focus$vars"))());
vars.value.isShowInLocal = isShowIn;
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:3olhBPPPoU6M5e1K+AxXGw:/ClientActionFlows.3olhBPPPoU6M5e1K+AxXGw:1vWQwWFlsAO7geT3bldvLw", "Common_CW", "Set_Focus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:+kMW+_G8o0uFAg9beInPDQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:_B3h91BWZ0ucpEk+Mot4gA", callContext.id) && vars.value.isShowInLocal)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:yVFvXtLm6EeHa54vq94HDQ", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_Set_Focus_GetPopupIdJS, "GetPopupId", "Set_Focus", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wbmYGls+QEmxY3fmoOj2hw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:wbmYGls+QEmxY3fmoOj2hw", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:3olhBPPPoU6M5e1K+AxXGw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.Set_Focus$vars", [{
name: "IsShow",
attrName: "isShowInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.set_Focus$Action = function (isShowIn, widgetIdIn) {
isShowIn = (isShowIn === undefined) ? false : isShowIn;
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(Common_CWController.default.set_Focus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isShowIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$Set_Focus.GetPopupIdJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function() {
var a = document.getElementById($parameters.WidgetId);
if (a) {
    var popupDialogElement = a.closest('.popup-dialog'); 
    if (popupDialogElement) {
        popupDialogElement.setAttribute("tabIndex", "0");
        popupDialogElement.focus();
    }
}
}, 300);
};
});

define("Common_CW.controller$SetCurrentAsValidURL", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$SetCurrentAsValidURL.JavaScript_SetValidURLJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_SetCurrentAsValidURL_JavaScript_SetValidURLJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.setCurrentAsValidURL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:mH_S8t_J90igziQvcjMISA:/ClientActionFlows.mH_S8t_J90igziQvcjMISA:FocggGRXS8oHwRh36nNmew", "Common_CW", "SetCurrentAsValidURL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Z7ZRQRqWNUu_Iayxbk638g", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:DeYOirakBEK3gwTuM2y6qQ", callContext.id);
controller.safeExecuteJSNode(Common_CW_controller_SetCurrentAsValidURL_JavaScript_SetValidURLJS, "JavaScript_SetValidURL", "SetCurrentAsValidURL", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:D_Fha3AXjEaXc4wV9jsSsw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:mH_S8t_J90igziQvcjMISA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.clientActionProxies.setCurrentAsValidURL$Action = function () {
return controller.executeActionInsideJSNode(Common_CWController.default.setCurrentAsValidURL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("Common_CW.controller$SetCurrentAsValidURL.JavaScript_SetValidURLJS", [], function () {
return function ($actions, $roles, $public) {
localStorage.setItem("PhiValidURL", window.location.href);

};
});

define("Common_CW.controller$String_Join", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.clientVariables", "Common_CW.model$TextRecordList"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.string_Join$Action = function (listIn, separatorIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.String_Join$vars"))());
vars.value.listInLocal = listIn.clone();
vars.value.separatorInLocal = separatorIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.String_Join$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:4BaiSxhRw0iNuxWHLimRpA:/ClientActionFlows.4BaiSxhRw0iNuxWHLimRpA:f6IYMw+dy3VY7b2wyZI_1A", "Common_CW", "String_Join", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:yYeS0ScbOkqg8LnZ1KopPg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:srP9+qrw20O46dZ5xxWQcw", callContext.id) && vars.value.listInLocal.isEmpty)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:v0I80MGEqkOBbXC1MwOncg", callContext.id);
} else {
// Foreach List
callContext.iterationContext.registerIterationStart(vars.value.listInLocal);
try {var listIterator = callContext.iterationContext.getIterator(vars.value.listInLocal);
var listIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:LefNziwLnUCA2SnYatR6BA", callContext.id) && (listIndex < vars.value.listInLocal.length))) {
listIterator.currentRowNumber = listIndex;
if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:W4JRDkZIVEaV4yWqBGZAHg", callContext.id) && (vars.value.listInLocal.getCurrentRowNumber(callContext.iterationContext) === 0))) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:c64Gf16aeE2WXoI7_6yRRQ", callContext.id);
// Text = List.Current.Text.Value
outVars.value.textOut = vars.value.listInLocal.getItem(listIndex.valueOf()).textAttr.valueAttr;
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:m7TbUJM+fEe5HDuhivc3WA", callContext.id);
// Text = Text + Separator + List.Current.Text.Value
outVars.value.textOut = ((outVars.value.textOut + vars.value.separatorInLocal) + vars.value.listInLocal.getItem(listIndex.valueOf()).textAttr.valueAttr);
}

listIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.listInLocal);
}

OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Jx_uyfB7+0aWz2U6rFXYHA", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:4BaiSxhRw0iNuxWHLimRpA", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.String_Join$vars", [{
name: "List",
attrName: "listInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new Common_CWModel.TextRecordList();
},
complexType: Common_CWModel.TextRecordList
}, {
name: "Separator",
attrName: "separatorInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.String_Join$outVars", [{
name: "Text",
attrName: "textOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.clientActionProxies.string_Join$Action = function (listIn, separatorIn) {
listIn = (listIn === undefined) ? new Common_CWModel.TextRecordList() : listIn;
separatorIn = (separatorIn === undefined) ? "" : separatorIn;
return controller.executeActionInsideJSNode(Common_CWController.default.string_Join$Action.bind(controller, listIn, OS.DataConversion.JSNodeParamConverter.from(separatorIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Text: OS.DataConversion.JSNodeParamConverter.to(actionResults.textOut, OS.Types.Text)
};
});
};
});

define("Common_CW.controller$SVGConversion", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$SVGConversion.BinaryToBase64JS", "Common_CW.clientVariables", "Common_CW.controller$ImageFormatChecking"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_SVGConversion_BinaryToBase64JS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.sVGConversion$Action = function (binaryIn, filenameIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.SVGConversion$vars"))());
vars.value.binaryInLocal = binaryIn;
vars.value.filenameInLocal = filenameIn;
var imageFormatCheckingVar = new OS.DataTypes.VariableHolder();
var binaryToBase64JSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.SVGConversion$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.imageFormatCheckingVar = imageFormatCheckingVar;
varBag.binaryToBase64JSResult = binaryToBase64JSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:MhQLSZVOi0emhiUiTuSHpw:/ClientActionFlows.MhQLSZVOi0emhiUiTuSHpw:P_Tp54Zb6DYENeO9e0WbnQ", "Common_CW", "SVGConversion", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:gWp61kwNUEmu+tjGncG3Jg", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:Vi5g_+KsO0qJOr_3vFkhoA", callContext.id);
// Execute Action: ImageFormatChecking
imageFormatCheckingVar.value = Common_CWController.default.imageFormatChecking$Action(vars.value.filenameInLocal, callContext);

if((OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:3idie0v7B0KUn+4CGZX+nA", callContext.id) && imageFormatCheckingVar.value.isSVGOut)) {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:rvRSV9XKQkulTaaIxTQM6Q", callContext.id);
binaryToBase64JSResult.value = controller.safeExecuteJSNode(Common_CW_controller_SVGConversion_BinaryToBase64JS, "BinaryToBase64", "SVGConversion", {
binary: OS.DataConversion.JSNodeParamConverter.to(vars.value.binaryInLocal, OS.Types.BinaryData),
base64String: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.SVGConversion$binaryToBase64JSResult"))();
jsNodeResult.base64StringOut = OS.DataConversion.JSNodeParamConverter.from($parameters.base64String, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OnxYKb3tlE6G0rMG6EH_Hg", callContext.id);
// Text = BinaryToBase64.base64String
outVars.value.textOut = binaryToBase64JSResult.value.base64StringOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:OnxYKb3tlE6G0rMG6EH_Hg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsSVG = True
outVars.value.isSVGOut = true;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:cUtFtYQmM024tynns5MI4A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:eZmfibP9xE6SPBJ93mnB5g", callContext.id);
// IsSVG = False
outVars.value.isSVGOut = false;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:2WIFu0ytF0+Ynm1znWv48w", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:MhQLSZVOi0emhiUiTuSHpw", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SVGConversion$vars", [{
name: "Binary",
attrName: "binaryInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}, {
name: "Filename",
attrName: "filenameInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SVGConversion$binaryToBase64JSResult", [{
name: "base64String",
attrName: "base64StringOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.SVGConversion$outVars", [{
name: "Text",
attrName: "textOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsSVG",
attrName: "isSVGOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.sVGConversion$Action = function (binaryIn, filenameIn) {
binaryIn = (binaryIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : binaryIn;
filenameIn = (filenameIn === undefined) ? "" : filenameIn;
return controller.executeActionInsideJSNode(Common_CWController.default.sVGConversion$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(binaryIn, OS.Types.BinaryData), OS.DataConversion.JSNodeParamConverter.from(filenameIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Text: OS.DataConversion.JSNodeParamConverter.to(actionResults.textOut, OS.Types.Text),
IsSVG: OS.DataConversion.JSNodeParamConverter.to(actionResults.isSVGOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$SVGConversion.BinaryToBase64JS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var toBase64 = $parameters.binary;
$parameters.base64String = window.atob(toBase64);
};
});

define("Common_CW.controller$ValidateEmail", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller", "Common_CW.controller$ValidateEmail.EmailValidationJS", "Common_CW.clientVariables"], function (exports, OutSystems, Common_CWModel, Common_CWController, Common_CW_controller_ValidateEmail_EmailValidationJS, Common_CWClientVariables) {
var OS = OutSystems.Internal;
Common_CWController.default.validateEmail$Action = function (emailIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ValidateEmail$vars"))());
vars.value.emailInLocal = emailIn;
var emailValidationJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("Common_CW.ValidateEmail$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.emailValidationJSResult = emailValidationJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("ROjy7cVDMUC3nbtJFcEmwQ:dFhqr_lnvEOngOr30W53hg:/ClientActionFlows.dFhqr_lnvEOngOr30W53hg:LATjTpSWUX+yymA8Q0+jNw", "Common_CW", "ValidateEmail", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:zDBsUx5H90WeK03Ts09Wow", callContext.id);
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:qE28MrqYmkWgg7MjxtiK_g", callContext.id);
emailValidationJSResult.value = controller.safeExecuteJSNode(Common_CW_controller_ValidateEmail_EmailValidationJS, "EmailValidation", "ValidateEmail", {
Email: OS.DataConversion.JSNodeParamConverter.to(vars.value.emailInLocal, OS.Types.Text),
IsValid: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("Common_CW.ValidateEmail$emailValidationJSResult"))();
jsNodeResult.isValidOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsValid, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:zxo+o+3d7E2S6tKLjHsLog", callContext.id);
// IsValid = EmailValidation.IsValid
outVars.value.isValidOut = emailValidationJSResult.value.isValidOut;
OutSystemsDebugger.handleBreakpoint("ROjy7cVDMUC3nbtJFcEmwQ:w6aebgz2JU+MVW3q3Yw4Ag", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("ROjy7cVDMUC3nbtJFcEmwQ:dFhqr_lnvEOngOr30W53hg", callContext.id);
}

};
var controller = Common_CWController.default;
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ValidateEmail$vars", [{
name: "Email",
attrName: "emailInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ValidateEmail$emailValidationJSResult", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.constructor.registerVariableGroupType("Common_CW.ValidateEmail$outVars", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Common_CWController.default.clientActionProxies.validateEmail$Action = function (emailIn) {
emailIn = (emailIn === undefined) ? "" : emailIn;
return controller.executeActionInsideJSNode(Common_CWController.default.validateEmail$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(emailIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsValid: OS.DataConversion.JSNodeParamConverter.to(actionResults.isValidOut, OS.Types.Boolean)
};
});
};
});
define("Common_CW.controller$ValidateEmail.EmailValidationJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var validator=/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

$parameters.IsValid = validator.test($parameters.Email);

};
});

define("Common_CW.controller$ServerAction.ImageComparison", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller"], function (exports, OutSystems, Common_CWModel, Common_CWController) {
var OS = OutSystems.Internal;
Common_CWController.default.imageComparison$ServerAction = function (oldImageIn, newImageIn, callContext) {
var controller = this.controller;
var inputs = {
OldImage: OS.DataConversion.ServerDataConverter.to(oldImageIn, OS.Types.BinaryData),
newImage: OS.DataConversion.ServerDataConverter.to(newImageIn, OS.Types.BinaryData)
};
return controller.callServerAction("ImageComparison", "screenservices/Common_CW/ActionImageComparison", "D_4yOaC05lQCkdqNiWyqlA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("Common_CW$ActionImageComparison"))();
executeServerActionResult.isMatchedOut = OS.DataConversion.ServerDataConverter.from(outputs.IsMatched, OS.Types.Boolean);
return executeServerActionResult;
});
};
Common_CWController.default.constructor.registerVariableGroupType("Common_CW$ActionImageComparison", [{
name: "IsMatched",
attrName: "isMatchedOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
});
define("Common_CW.controller$ServerAction.Regex_Search", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller"], function (exports, OutSystems, Common_CWModel, Common_CWController) {
var OS = OutSystems.Internal;
Common_CWController.default.regex_Search$ServerAction = function (textIn, patternIn, ignoreCaseIn, multiLineIn, singleLineIn, callContext) {
var controller = this.controller;
var inputs = {
Text: OS.DataConversion.ServerDataConverter.to(textIn, OS.Types.Text),
Pattern: OS.DataConversion.ServerDataConverter.to(patternIn, OS.Types.Text),
IgnoreCase: OS.DataConversion.ServerDataConverter.to(ignoreCaseIn, OS.Types.Boolean),
MultiLine: OS.DataConversion.ServerDataConverter.to(multiLineIn, OS.Types.Boolean),
SingleLine: OS.DataConversion.ServerDataConverter.to(singleLineIn, OS.Types.Boolean)
};
return controller.callServerAction("Regex_Search", "screenservices/Common_CW/ActionRegex_Search", "QKXlczRQIwNrJOt00V8WSg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("Common_CW$rssextensiontext_ActionRegex_Search"))();
executeServerActionResult.foundOut = OS.DataConversion.ServerDataConverter.from(outputs.Found, OS.Types.Boolean);
executeServerActionResult.patternResultOut = OS.DataConversion.ServerDataConverter.from(outputs.PatternResult, OS.Types.Text);
executeServerActionResult.firstIndexOut = OS.DataConversion.ServerDataConverter.from(outputs.FirstIndex, OS.Types.Integer);
return executeServerActionResult;
});
};
Common_CWController.default.constructor.registerVariableGroupType("Common_CW$rssextensiontext_ActionRegex_Search", [{
name: "Found",
attrName: "foundOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "PatternResult",
attrName: "patternResultOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "FirstIndex",
attrName: "firstIndexOut",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
});
define("Common_CW.controller$ServerAction.User_GetUnifiedLoginUrl", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller"], function (exports, OutSystems, Common_CWModel, Common_CWController) {
var OS = OutSystems.Internal;
Common_CWController.default.user_GetUnifiedLoginUrl$ServerAction = function (originalUrlIn, toolNameIn, callContext) {
var controller = this.controller;
var inputs = {
OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text),
ToolName: OS.DataConversion.ServerDataConverter.to(toolNameIn, OS.Types.Text)
};
return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/Common_CW/ActionUser_GetUnifiedLoginUrl", "cttvMQpQoQ_vXqICRkdvyg", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("Common_CW$rssespaceusers_ActionUser_GetUnifiedLoginUrl"))();
executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
return executeServerActionResult;
});
};
Common_CWController.default.constructor.registerVariableGroupType("Common_CW$rssespaceusers_ActionUser_GetUnifiedLoginUrl", [{
name: "Url",
attrName: "urlOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
});
define("Common_CW.controller$ServerAction.ValidateFlagsByPermissions", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller"], function (exports, OutSystems, Common_CWModel, Common_CWController) {
var OS = OutSystems.Internal;
Common_CWController.default.validateFlagsByPermissions$ServerAction = function (flags_ListIn, callContext) {
var controller = this.controller;
var inputs = {
Flags_List: OS.DataConversion.ServerDataConverter.to(flags_ListIn, OS.Types.RecordList)
};
return controller.callServerAction("ValidateFlagsByPermissions", "screenservices/Common_CW/ActionValidateFlagsByPermissions", "zaria6c7EzIxD4_IqgNUDA", inputs, controller.callContext(callContext), OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, false).then(function (outputs) {
var executeServerActionResult = new (controller.constructor.getVariableGroupType("Common_CW$ActionValidateFlagsByPermissions"))();
executeServerActionResult.isValidOut = OS.DataConversion.ServerDataConverter.from(outputs.IsValid, OS.Types.Boolean);
return executeServerActionResult;
});
};
Common_CWController.default.constructor.registerVariableGroupType("Common_CW$ActionValidateFlagsByPermissions", [{
name: "IsValid",
attrName: "isValidOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
});
define("Common_CW.controller", ["exports", "OutSystems/ClientRuntime/Main", "Common_CW.model", "Common_CW.controller$debugger"], function (exports, OutSystems, Common_CWModel, Common_CW_Controller_debugger) {
var OS = OutSystems.Internal;
var Common_CWController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {
OA_8_AddRemoveUsers: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pu3dAtqukUaeLexNMXrA7w",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_8_AddRemoveUsers", "OA_8_AddRemoveUsers role required")
},
SP_3_ViewCases: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*qN9KBWljFEClFBO1VDlRRw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_3_ViewCases", "SP_3_ViewCases role required")
},
BP_11_ReactivateMembers: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pYB6Cru9k0CVhLcMKhT9HA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_11_ReactivateMembers", "BP_11_ReactivateMembers role required")
},
MM_21_PrintSendCommunicationGeneral: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*fArhC4gBJk2R_y9lZjLm0A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_21_PrintSendCommunicationGeneral", "MM_21_PrintSendCommunicationGeneral role required")
},
PM_13_ModifyWaitingPeriodPolicyMember: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*Uma0FI3LCUymH7UdjWRKlw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_13_ModifyWaitingPeriodPolicyMember", "PM_13_ModifyWaitingPeriodPolicyMember role required")
},
MM_2_CreateEditJoinDate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*PP60F0gC3UaZNhgXqtFqfQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_2_CreateEditJoinDate", "MM_2_CreateEditJoinDate role required")
},
SP_13_Changeduedate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*5VmqGW4+oka++1kXS9ia0A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_13_Changeduedate", "SP_13_Changeduedate role required")
},
SM_1_AddModifyReopenCancelLead: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*mmhCHAVHE0+ovsYgY_p9kw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_1_AddModifyReopenCancelLead", "SM_1_AddModifyReopenCancelLead role required")
},
BP_6_SendCommunication_General_: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*A1VnHls3OUKyKZheZbahNA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_6_SendCommunication_General_", "BP_6_SendCommunication_General_ role required")
},
MM_12_EditPreviousFundPaidHospitalDays: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*dBysHp3WvUCJ6iiU6Lj6mA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_12_EditPreviousFundPaidHospitalDays", "MM_12_EditPreviousFundPaidHospitalDays role required")
},
PM_4_CreatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*xT5TIAW_wUuUGIkVHTHK8A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_4_CreatePolicy", "PM_4_CreatePolicy role required")
},
PM_6_CreateMaintainPolicyEditStartDate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*PWRUIk433UyauV+2Rt_9zg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_6_CreateMaintainPolicyEditStartDate", "PM_6_CreateMaintainPolicyEditStartDate role required")
},
MM_17_ViewMember: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*KUxnKQfxhk+r7amhARpkjA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_17_ViewMember", "MM_17_ViewMember role required")
},
SP_2_SearchRecord: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*ut7JKnAc5U2NB+b50Tu3Fg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_2_SearchRecord", "SP_2_SearchRecord role required")
},
PM_26_AdjustPaidToDateTheoreticalPaidToDate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*eoo7MAQv3kuHL61Rafv3zA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_26_AdjustPaidToDateTheoreticalPaidToDate", "PM_26_AdjustPaidToDateTheoreticalPaidToDate role required")
},
PM_20_ViewPolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*dzbFMugvtEmEiwQhu+dZ0A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_20_ViewPolicy", "PM_20_ViewPolicy role required")
},
BP_9_ReactivatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*oE58NLbceEuBF9s2IEnXCQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_9_ReactivatePolicy", "BP_9_ReactivatePolicy role required")
},
OA_7_CreateModifyteams: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*6P7xRFANNkSQvmQrOYKljQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_7_CreateModifyteams", "OA_7_CreateModifyteams role required")
},
SM_11_PrintSendCommunicationGeneral: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*V3SfRfZNLEij0hkYxvTKvA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_11_PrintSendCommunicationGeneral", "SM_11_PrintSendCommunicationGeneral role required")
},
SP_9_AssignCaseBulk: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*H+MKTzSRR0WJTEbFfH7puw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_9_AssignCaseBulk", "SP_9_AssignCaseBulk role required")
},
HAMBSAdmin: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pTbfUvhMMEq0Im8nv1GeQg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotHAMBSAdmin", "HAMBSAdmin role required")
},
BP_16_CancelBatchProcessSendMembershipCards: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*kl9WVVpPK0GqW0Qby72shQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_16_CancelBatchProcessSendMembershipCards", "BP_16_CancelBatchProcessSendMembershipCards role required")
},
MM_11_EditHospWaitExemptionUsedDate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*M2ofXZpmYUe2hMAqedcwVA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_11_EditHospWaitExemptionUsedDate", "MM_11_EditHospWaitExemptionUsedDate role required")
},
PM_2_ConvertQuote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*g3bnXoTMqESKXlnKQehEwg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_2_ConvertQuote", "PM_2_ConvertQuote role required")
},
PM_8_TerminatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*zPV7aVmd2E2gp3iHK+3Drw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_8_TerminatePolicy", "PM_8_TerminatePolicy role required")
},
BP_7_SendRateChangeNotice: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*Sj7QadXt1EOILPcGROpq2g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_7_SendRateChangeNotice", "BP_7_SendRateChangeNotice role required")
},
SM_4_ViewStakeholderLead: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*QTtsahid6EObPodwpHEwtA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_4_ViewStakeholderLead", "SM_4_ViewStakeholderLead role required")
},
BP_5_SendMembershipCards: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pzsmds5O006yNyqkNPAq4g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_5_SendMembershipCards", "BP_5_SendMembershipCards role required")
},
SM_7_MaintainNotes: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*RefdeOv9zUeoZyqP0OMcEw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_7_MaintainNotes", "SM_7_MaintainNotes role required")
},
PM_27_PrintSendCommunicationGeneral: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*dZHYfaIPXU6srrDxfSWZVw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_27_PrintSendCommunicationGeneral", "PM_27_PrintSendCommunicationGeneral role required")
},
PM_5_MaintainPolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*qCo0gYwe+Uu0jgrGNoPTRw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_5_MaintainPolicy", "PM_5_MaintainPolicy role required")
},
BP_2_LHCReset: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*VQP6iKG3UUSuaf0YCBDUWg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_2_LHCReset", "BP_2_LHCReset role required")
},
MM_10_EditPEAOverride: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*bnRDip7Fzkai5SwHJB2l0Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_10_EditPEAOverride", "MM_10_EditPEAOverride role required")
},
PM_3_ViewQuote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*q06ei11yXkujJHKgirKcEw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_3_ViewQuote", "PM_3_ViewQuote role required")
},
BP_18_ApproveBatchProcess: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*dCcrj_0HnUuWIPeZDtJ6vw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_18_ApproveBatchProcess", "BP_18_ApproveBatchProcess role required")
},
BP_1_ClaimServicesAustraliaMedicareRebate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*8878k35S2kCJMsnx_vm1Iw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_1_ClaimServicesAustraliaMedicareRebate", "BP_1_ClaimServicesAustraliaMedicareRebate role required")
},
BP_13_ApplyFlag: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*m89Hmbn7TkWe_s6XKk6HQw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_13_ApplyFlag", "BP_13_ApplyFlag role required")
},
PM_29_RebateExceptionmanagementFromRealTimeIntegra: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*DlZQmZ68lUe7NLryvTpjBg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_29_RebateExceptionmanagementFromRealTimeIntegra", "PM_29_RebateExceptionmanagementFromRealTimeIntegra role required")
},
SP_10_AssignCasePersonTeam: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*8VHOmuAz10Kk7EDLsb9SNg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_10_AssignCasePersonTeam", "SP_10_AssignCasePersonTeam role required")
},
MM_19_PrintSendCommunicationBenefitStatement: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*jAIJmwopBUmrKptHURDUnw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_19_PrintSendCommunicationBenefitStatement", "MM_19_PrintSendCommunicationBenefitStatement role required")
},
SystemAdministrator: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*eGpqnKatjECYBG4l+F4pYA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSystemAdministrator", "SystemAdministrator role required")
},
MM_20_PrintSendCommunicationLHCStatement: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*+IznnSysaUCaEnN1TaanSg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_20_PrintSendCommunicationLHCStatement", "MM_20_PrintSendCommunicationLHCStatement role required")
},
BP_8_TerminatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*n6IznlYll0CdaVYdge5R2Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_8_TerminatePolicy", "BP_8_TerminatePolicy role required")
},
SP_6_PlaceonholdCase: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*q9WvngKAHk6NerVD7ThHhQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_6_PlaceonholdCase", "SP_6_PlaceonholdCase role required")
},
BP_14_ApplyNote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pzBdoj_yKU6eRVLTP88bgQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_14_ApplyNote", "BP_14_ApplyNote role required")
},
BP_12_CancelLeads: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pkWMpt6cV0eZJrF+7e53bQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_12_CancelLeads", "BP_12_CancelLeads role required")
},
MM_1_CreateModifyMember: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*yL_Dpk5m20azflVM1gg9Tg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_1_CreateModifyMember", "MM_1_CreateModifyMember role required")
},
MM_6_EditDependentOverride: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*xuwoqlfC1UC2RdDo8zXgvg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_6_EditDependentOverride", "MM_6_EditDependentOverride role required")
},
OA_5_ManageFundSetupAndBranding: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*SgSQq7k8qkC9DtiSVCHwYQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_5_ManageFundSetupAndBranding", "OA_5_ManageFundSetupAndBranding role required")
},
SP_12_ViewRestrictedCases: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*mrMosvKTGEybYT_5CkZo0g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_12_ViewRestrictedCases", "SP_12_ViewRestrictedCases role required")
},
BP_17_AdvancedFilterBulkProcess: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*qgyEuVyZ6UCJJkkppzLQBA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_17_AdvancedFilterBulkProcess", "BP_17_AdvancedFilterBulkProcess role required")
},
OA_6_CreateModifyRolesPermissions: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*q5Wlu5Kr3Uq09aiaZ4wbLA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_6_CreateModifyRolesPermissions", "OA_6_CreateModifyRolesPermissions role required")
},
PM_19_MaintainNotes: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*MvPVv2aL8kKSWTNRYZLn2g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_19_MaintainNotes", "PM_19_MaintainNotes role required")
},
SM_2_AddModifyDirectCreditAccountsStakeholder: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*myg3wQ2+ok+vQe2nnO0Dxg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_2_AddModifyDirectCreditAccountsStakeholder", "SM_2_AddModifyDirectCreditAccountsStakeholder role required")
},
PM_18_CreateNotes: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*Bd+uwfKrv0+xOGoQcT7QRw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_18_CreateNotes", "PM_18_CreateNotes role required")
},
MM_7_EditLHCEntryAge: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*pOeZwlhRiEKbwAX8HtZFGg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotMM_7_EditLHCEntryAge", "MM_7_EditLHCEntryAge role required")
},
SP_5_CreateUpdateCloseCase: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*uJ5Ww6BHJE+Xrf94SmNx_A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_5_CreateUpdateCloseCase", "SP_5_CreateUpdateCloseCase role required")
},
SP_8_AssignCaseIndividual: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*YSkRx7phREKgRuTq5SDziQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_8_AssignCaseIndividual", "SP_8_AssignCaseIndividual role required")
},
PM_28_PrintSendCommunicationRebateStatement: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*OINSyRDYWEy4qpgPyvUzUg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_28_PrintSendCommunicationRebateStatement", "PM_28_PrintSendCommunicationRebateStatement role required")
},
BP_4_SendLHCStatement: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*YwU2zIp50kil8I7GHr48+g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_4_SendLHCStatement", "BP_4_SendLHCStatement role required")
},
SM_10_CommunicationAdministration_Ind: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*7SZw0KDCskKopgM3HKnN7g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_10_CommunicationAdministration_Ind", "SM_10_CommunicationAdministration_Ind role required")
},
SM_3_AddModifyDirectDebitAccountsStakeholder: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*tfTt1BuaKEO7cSTKcAxUuQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_3_AddModifyDirectDebitAccountsStakeholder", "SM_3_AddModifyDirectDebitAccountsStakeholder role required")
},
SP_7_CancelCase: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*NR2U1trNx0yscniClhht5A",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_7_CancelCase", "SP_7_CancelCase role required")
},
OA_2_CreateMaintainReferenceData: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*1Lmy2hcKLkyr3JlRAIcDxA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_2_CreateMaintainReferenceData", "OA_2_CreateMaintainReferenceData role required")
},
OA_3_ViewUserAuditLog: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*NDgH3PVxSU+yHw6j6jG2Ow",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotOA_3_ViewUserAuditLog", "OA_3_ViewUserAuditLog role required")
},
BP_15_AdjustPaidToDateTheoreticalPaidToDate: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*l1143ku15Em0wtbkiPZaWA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_15_AdjustPaidToDateTheoreticalPaidToDate", "BP_15_AdjustPaidToDateTheoreticalPaidToDate role required")
},
SM_8_CreateInteractionRecord: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*vANt5wXqHEqjOKxEDMnVMg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_8_CreateInteractionRecord", "SM_8_CreateInteractionRecord role required")
},
BP_3_ArrearsManagement: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*mbLX51AhMEymn0GQUss50g",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_3_ArrearsManagement", "BP_3_ArrearsManagement role required")
},
SM_6_CreateNotes: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*1Uu07oC9DEaNRmlWtsj3nA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_6_CreateNotes", "SM_6_CreateNotes role required")
},
SP_11_AssignCaseTeam: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*5AAj7zFNy0qEDUS81G6ktw",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_11_AssignCaseTeam", "SP_11_AssignCaseTeam role required")
},
PM_10_ReactivatePolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*Ww_N83Gz+UyyqRk0tI36Yg",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_10_ReactivatePolicy", "PM_10_ReactivatePolicy role required")
},
PM_1_CreateModifyQuote: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*4z0_9Eh_QE+_MEzwNwbD9Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_1_CreateModifyQuote", "PM_1_CreateModifyQuote role required")
},
SP_4_ViewDashboards: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*z_ES9dS+0ka1KmVMM7YAOA",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSP_4_ViewDashboards", "SP_4_ViewDashboards role required")
},
PM_9_SuspendPolicy: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*_Zl9+s3HnEiBkHP9+tS6Ag",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_9_SuspendPolicy", "PM_9_SuspendPolicy role required")
},
SM_9_MaintainInteractionRecord: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*zqMd+yL1R0SQYY_Q+l+C4Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotSM_9_MaintainInteractionRecord", "SM_9_MaintainInteractionRecord role required")
},
PM_7_AddModifyWithdrawRebateParticipation: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*vJok_0Z190OOYCERddkjEQ",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotPM_7_AddModifyWithdrawRebateParticipation", "PM_7_AddModifyWithdrawRebateParticipation role required")
},
BP_10_TerminateMembers: {
roleKey: "Bh0bGaoi+EOmvp2PRgBTXQ*GFho_0rBuEOi0xzPoI3D9Q",
roleException: new OS.Exceptions.Exceptions.NotRegisteredException("AccessControl_CS.NotBP_10_TerminateMembers", "BP_10_TerminateMembers role required")
}
};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return Common_CWController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
Common_CWController.default = new Controller(null, "Common_CW");
});
define("Common_CW.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main", "Common_CW.clientVariables"], function (exports, Debugger, OutSystems, Common_CWClientVariables) {
var OS = OutSystems.Internal;
var metaInfo = {
"fGu_62UmY0Kz9ogCkomErA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"HtNOLKHb4U2i5H2tZFJXgA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"SPdyvC7UU0GeRYsmlUI6mA": {
getter: function (varBag, idService) {
return varBag.vars.value.hexCodeInLocal;
},
dataType: OS.Types.Text
},
"zt_KPcdXjkulyEVNx_WFsw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"91nJ_bBjEEeD7WfXv+52Kg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isEmptyOut;
},
dataType: OS.Types.Boolean
},
"G22xHMuF40K_tFNYIfNDKg": {
getter: function (varBag, idService) {
return varBag.regex_SearchVar.value;
}
},
"m91f1qU_tE6t3RavcxXA+A": {
getter: function (varBag, idService) {
return varBag.vars.value.isShowInLocal;
},
dataType: OS.Types.Boolean
},
"L7C4+dlfmEmD6DFG2TKyAw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"yVFvXtLm6EeHa54vq94HDQ": {
getter: function (varBag, idService) {
return varBag.getPopupIdJSResult.value;
}
},
"iHH6e6WT70us6srW6LYBqg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"lX8tVKXqHUCpdal3sfcxlA": {
getter: function (varBag, idService) {
return varBag.javaScript_ClearDropdownTagJSResult.value;
}
},
"HXq+Oq5msk2mGgFwQ3ex_A": {
getter: function (varBag, idService) {
return varBag.outVars.value.msgOut;
},
dataType: OS.Types.Text
},
"XD3feWdlM0OIvVKOrmmQgA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"1StE3DB+6EGudidUhG2bBQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"7mW_sjtIT0O3ld9h7pOzdQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"tqFpu1Mid0Gpta_FC_paXQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"8DBsQbD+jUCdC2pWhGVgpQ": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInInLocal;
},
dataType: OS.Types.LongInteger
},
"T5lUyDV5YEW3TgPwu_Zwbw": {
getter: function (varBag, idService) {
return varBag.vars.value.replacementInLocal;
},
dataType: OS.Types.Text
},
"7EYpcu9TgU+TxCvtpXzeXw": {
getter: function (varBag, idService) {
return varBag.outVars.value.valueOutOut;
},
dataType: OS.Types.Text
},
"MEyClJVkNU+zcZ1RM1kdbQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"3cBwxW0pMkK0iolPBIMgEA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"wcAuMNuZ2k6oyA7YU0M5Xw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"+lOZHlqMTkOfvzpBXVY3nQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"6CUIK25IskKP3Fd3Fg1Dog": {
getter: function (varBag, idService) {
return varBag.vars.value.mSD_ItemInLocal;
}
},
"XXS1uIX0RUGmMFDXxz2UbQ": {
getter: function (varBag, idService) {
return varBag.vars.value.separatorInLocal;
},
dataType: OS.Types.Text
},
"xTw6cI92t06Ydw7xKnDYQg": {
getter: function (varBag, idService) {
return varBag.outVars.value.joinedStringsOut;
},
dataType: OS.Types.Text
},
"qKGuPJjCuEGHHA9fDGXH0A": {
getter: function (varBag, idService) {
return varBag.string_JoinVar.value;
}
},
"XIsIjo1UDUarqsVyKftbPQ": {
getter: function (varBag, idService) {
return varBag.listFilterVar.value;
}
},
"KJXR8A1Yq0C8W6hGIYJ6SQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"G7tcgLiri0q_Qs_p2r00RA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"26capBFn_k6YP6Nd9MQPJQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"XX0yqjj+nUWpZtkyfVYmVg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"8nhqpqCPq0KWybfbdvI67A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"eMPG_mW+x0+TGuQr7yOPSA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"2jfBfV4xNUSDPRcE8uWa3A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"kJdm9cVsrkyiuKQlDrUb0A": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"cBhh2fH2eUy1gcTnVLnpmg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"VbuOmuY8LUC3GWroI7EU4w": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"B+Kz+d5U8Ei9u8b5YV11ZA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"hFi4eIACV0WAtZRNyrSZrA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"ez1iVBuBFEiI5KluqrmmNA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"nvFzWUANt0Wuu3aZfWRptw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"y_N8UMGAbEK8nzwMEsy0Cw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"PThEj19zP0y2ZuvP1LyWaQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"xK5LBYSKXUWoo5HzoTDpsQ": {
getter: function (varBag, idService) {
return varBag.vars.value.inputInLocal;
},
dataType: OS.Types.Text
},
"p7pPpWEGXE2SVDxZtkVrCg": {
getter: function (varBag, idService) {
return varBag.outVars.value.outputOut;
},
dataType: OS.Types.Text
},
"Nlls9m6aHkK+Qz9l3km7OA": {
getter: function (varBag, idService) {
return varBag.javaScript_DecodeHTMLJSResult.value;
}
},
"A4zs+D86Yk+jBP+JsU3sEw": {
getter: function (varBag, idService) {
return varBag.vars.value.binaryInLocal;
},
dataType: OS.Types.BinaryData
},
"g4OfXz8Bf0epoN7RtysjWA": {
getter: function (varBag, idService) {
return varBag.vars.value.filenameInLocal;
},
dataType: OS.Types.Text
},
"TikQHY9QY0CITNdFdWnDRA": {
getter: function (varBag, idService) {
return varBag.outVars.value.textOut;
},
dataType: OS.Types.Text
},
"Tb93GuOCY0ynCbhynFt+mA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSVGOut;
},
dataType: OS.Types.Boolean
},
"Vi5g_+KsO0qJOr_3vFkhoA": {
getter: function (varBag, idService) {
return varBag.imageFormatCheckingVar.value;
}
},
"rvRSV9XKQkulTaaIxTQM6Q": {
getter: function (varBag, idService) {
return varBag.binaryToBase64JSResult.value;
}
},
"eOycp+1BWUSLy4DH5y5YRg": {
getter: function (varBag, idService) {
return varBag.vars.value.listInLocal;
}
},
"BD+O+G3fjkyqgElZo3kpgg": {
getter: function (varBag, idService) {
return varBag.vars.value.separatorInLocal;
},
dataType: OS.Types.Text
},
"7Fy6ZxU5mEW3+mIiN5AEMw": {
getter: function (varBag, idService) {
return varBag.outVars.value.textOut;
},
dataType: OS.Types.Text
},
"WJV8RRX8VEKzcaJ4Q35BbQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"7tFeCUetsEyhrmJq4E6w7g": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"X_a+FfGxyEaQ5oCQEMVRIA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"abT8rk0oykSNMOWXVLc6pg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"SeTEQSOpJkunHOHxBp8LDQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"iiR9Y5ibiUi3KjY_ghKInA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"Rg51kQVE_EGvFCZhcTUsTA": {
getter: function (varBag, idService) {
return varBag.vars.value.textToSpeechInLocal;
},
dataType: OS.Types.Text
},
"jqoqyYG8Hk6LNDRP5CJRfg": {
getter: function (varBag, idService) {
return varBag.javaScript_triggerAlertJSResult.value;
}
},
"R8sJOeZwdUO8aZVqCM+rVg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"GN3FKfwjikel0jhEQy5C3w": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"UQ2Fj8QasUmUgEW420Xjeg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"2rNLLvTkfUOmcqR10_YGRw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"sz0MpDmrz0O+OFVYFMmlEg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"khme6d0vW0S5eJNWOcOJLQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"w6fbS1YerkqeuYlB18ezAA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"CIQsQU+L+0qAB27o5865GQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"8rfns5gQuUe8HnC8avd6Cg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"+EL3yZx44EmY4RuARWhRgg": {
getter: function (varBag, idService) {
return varBag.createModifyteamsPermissionsJSResult.value;
}
},
"KNRqVMxb9E6jMLlusU9Gkg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"IyJhLlibt0+pPlzxGvZJAA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"NAVyt76KiEqYKczdyOdbQA": {
getter: function (varBag, idService) {
return varBag.vars.value.flags_ListInLocal;
}
},
"p_1Hk97OhUSUXcLzzIu5mw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"tVytN46ceUiuyh1BhD1VYQ": {
getter: function (varBag, idService) {
return varBag.validateFlagsByPermissionsVar.value;
}
},
"6IgF_DhR2ke3wXbR0cbNvw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"X6ZPEkFEpkmZy9FjL7vH7g": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"NAPbXppdfkSYqb5z2Yxnrw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"92ClQbn8u06_0tgvjO6c9Q": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"_SLNDKvgT0OJioXXn5Zkbw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"+JVpM_19ZUKP7X7W7LfH7A": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"p_qn7NWc00KyqAyPoIwMNA": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInInLocal;
},
dataType: OS.Types.DateTime
},
"P1TgsNbDO0yDiZTtVXRY6Q": {
getter: function (varBag, idService) {
return varBag.vars.value.replacementInLocal;
},
dataType: OS.Types.Text
},
"yTK_kXQc80qw1496pnGFFA": {
getter: function (varBag, idService) {
return varBag.vars.value.formatInLocal;
},
dataType: OS.Types.Text
},
"TKQUPTbtf0+0rMG4tiV_6A": {
getter: function (varBag, idService) {
return varBag.outVars.value.valueOutOut;
},
dataType: OS.Types.Text
},
"qD7J5bJk5EG7Hom2nlg_6w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"C4q+QUtxg0i4LlSQfLH2AQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"1lzlI6k3L0Ke90JfbkdUMg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"OufzkB4b70eQI_b0P11VAQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"OpIrPumsUEqLJ541HAFVHg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"Zw87ccrgg0i0dO1jcz2I8A": {
getter: function (varBag, idService) {
return varBag.hasAnyBatchProcessRolesJSResult.value;
}
},
"ZuI31ZP1_EGZ8HLG78Iy1Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"39vSCRDUTUimflwBcjRctA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"90xoFyKtA0GzMAOeENvaNg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"OjkMJLQF20q29b8u94oYFg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"Xs3AtqeOU06pRCv3Oav4Xg": {
getter: function (varBag, idService) {
return varBag.vars.value.dateInLocal;
},
dataType: OS.Types.DateTime
},
"CSwQnv6aFEqShtqneslylQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.formattedDTOut;
},
dataType: OS.Types.Text
},
"tCpF0eeGWk2hLskCmEo9Jg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"I3xDawN21ESyRNjeIqXnPQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"CxMY3yWaEkKWW4_yIJIx9g": {
getter: function (varBag, idService) {
return varBag.vars.value.filenameInLocal;
},
dataType: OS.Types.Text
},
"PK3jxRRTWU66F6nHnPOGAw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSVGOut;
},
dataType: OS.Types.Boolean
},
"suhw4gMHIUq77TkY8LgvyA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isImageOut;
},
dataType: OS.Types.Boolean
},
"_jnHTB+MDUeIB86fTExYEQ": {
getter: function (varBag, idService) {
return varBag.regexIsSVGJSResult.value;
}
},
"mmg_I01R9UyVpreeplAs1w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"wZ8vVgWskkqFZuwlzMedOw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"Iuk7DyliE0SU+pwLtTIWBg": {
getter: function (varBag, idService) {
return varBag.vars.value.valueInInLocal;
},
dataType: OS.Types.Text
},
"L9hByT6bykCwTbP_KhQWkA": {
getter: function (varBag, idService) {
return varBag.vars.value.replacementInLocal;
},
dataType: OS.Types.Text
},
"NJU3c4xQO0ijLrlzDKgluA": {
getter: function (varBag, idService) {
return varBag.outVars.value.valueOutOut;
},
dataType: OS.Types.Text
},
"C2z0WkQeo0aXDr_DNj4RHA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"aK9FKrRbzE2OKQGBm41Zag": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"6+6ttxWGbkWHg9sfAnyLdA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"Jsa2vcxRo0ebB0Viyse7LA": {
getter: function (varBag, idService) {
return varBag.viewDashboardJSResult.value;
}
},
"METxP0PqMUq0EVfnKmfj_w": {
getter: function (varBag, idService) {
return varBag.vars.value.oldImageInLocal;
},
dataType: OS.Types.BinaryData
},
"As_LGv4sQUiDwWkLc8hWEw": {
getter: function (varBag, idService) {
return varBag.vars.value.newImageInLocal;
},
dataType: OS.Types.BinaryData
},
"2KkhtP3wzUqVjNdXfXV37Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.isMatchedOut;
},
dataType: OS.Types.Boolean
},
"OBWVFB_ktkq73eov2MWepw": {
getter: function (varBag, idService) {
return varBag.imageComparisonVar.value;
}
},
"bC8qAJ156U2_sixfhC7k6A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"2+2KjhnMEEO0cYYq4dvMcw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"8HGizfEVNkquoj_VBu5i9A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"Odw8lirtp0uCmJwsjDe9lA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"fNINJlm_TU67sCunC+rCyw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"N0KpO0bMvkqK3oP4bZIERQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"qxGocjpAzUWeq2yeGZMOaA": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetOrderInLocal;
},
dataType: OS.Types.Integer
},
"jHoSTTjlvkuXL9Nah5GOPg": {
getter: function (varBag, idService) {
return varBag.vars.value.currentSelectedStepInLocal;
},
dataType: OS.Types.Integer
},
"VJyPLpvMQE+u175L8z+2fA": {
getter: function (varBag, idService) {
return varBag.outVars.value.wizardStatusOut;
},
dataType: OS.Types.Text
},
"7Omhp5LK60azaocfat7Y2w": {
getter: function (varBag, idService) {
return varBag.vars.value.logoInLocal;
},
dataType: OS.Types.BinaryData
},
"Py5hg5n+q06iMxoHlfVF5w": {
getter: function (varBag, idService) {
return varBag.vars.value.fileNameInLocal;
},
dataType: OS.Types.Text
},
"wDT+VnIRME6MwCvhNfXcPA": {
getter: function (varBag, idService) {
return varBag.outVars.value.errorMessageOut;
},
dataType: OS.Types.Text
},
"tTl_snsF6UWWESaVxM7U9A": {
getter: function (varBag, idService) {
return varBag.imageFormatCheckingVar.value;
}
},
"qLQAvuC1LEmAVZ3VJOy0vQ": {
getter: function (varBag, idService) {
return varBag.toMbJSResult.value;
}
},
"bhU05lBqj0qr+rFUJOwYQg": {
getter: function (varBag, idService) {
return varBag.javaScript_GetSizeJSResult.value;
}
},
"j5M+tF94ckWAKwIPWJc0WQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"xS3lDaUqukyRjcfGc702ZQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"nGXOkKgb9UaK1ZmJ8eI2KA": {
getter: function (varBag, idService) {
return varBag.vars.value.classNameInLocal;
},
dataType: OS.Types.Text
},
"qkb6cUsMa0q31z8aAkHv+Q": {
getter: function (varBag, idService) {
return varBag.cbChangeJSResult.value;
}
},
"VwTG_DEcIU2jCEA6aqrAPA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"U4oTFjNt+U+3GKGiBIhHOw": {
getter: function (varBag, idService) {
return varBag.addRemoveUserJSResult.value;
}
},
"WgW_2HUmQkWa5IKyV8Upiw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"54Z7FCXveE2FcQR6ZTPqgQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"cdekI5W5VE6jgEMFIHDN4A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"dtZZR4sHDk2qzCcxvbixdQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"A3329CVwP0KrOHVfSBbIbw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"iNr9CMn3JUK45TBOH38Rvw": {
getter: function (varBag, idService) {
return varBag.javaScript_DisableWidgetJSResult.value;
}
},
"QyS7GCJ0T0KRasNIZ7Rg+g": {
getter: function (varBag, idService) {
return varBag.vars.value.emailInLocal;
},
dataType: OS.Types.Text
},
"+cTUf9O_wkyKQSfYynt__g": {
getter: function (varBag, idService) {
return varBag.outVars.value.isValidOut;
},
dataType: OS.Types.Boolean
},
"qE28MrqYmkWgg7MjxtiK_g": {
getter: function (varBag, idService) {
return varBag.emailValidationJSResult.value;
}
},
"d0nD2BMKUkqeD8f32aNhgA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"g1TJI43mWEy+EamF0lknnQ": {
getter: function (varBag, idService) {
return varBag.hasConfigureFundJSResult.value;
}
},
"XepnOByMeEadygqcrJKZGw": {
getter: function (varBag, idService) {
return varBag.hasSystemAdminJSResult.value;
}
},
"PxSudRUO_kmy4faZgbWvkg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"vFXVSSmjakuTjPLmlAWfsQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"xH3Si5qNkkSzaKYD6LLLvQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"hYKx3maJukqX3iG8ZWQHmg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"Ofh+FrsDMUCeWyfZ2_yWrw": {
getter: function (varBag, idService) {
return varBag.vars.value.base64InLocal;
},
dataType: OS.Types.Text
},
"CIqFLGhjGU+yW+B4BprqGQ": {
getter: function (varBag, idService) {
return varBag.vars.value.fileNameInLocal;
},
dataType: OS.Types.Text
},
"BGMIuWTndkuHDVWSdwcc7w": {
getter: function (varBag, idService) {
return varBag.outVars.value.imageOut;
},
dataType: OS.Types.BinaryData
},
"mdTqr4Ney0+ueGBnibDLjA": {
getter: function (varBag, idService) {
return varBag.outVars.value.sVGLogoOut;
},
dataType: OS.Types.Text
},
"3T6XrfUo1kmiFoBjcEtGiA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isSVGLogoOut;
},
dataType: OS.Types.Boolean
},
"dQmzd0tQ7kuRCiGV7DU4+w": {
getter: function (varBag, idService) {
return varBag.imageFormatCheckingVar.value;
}
},
"KkvN+Ov8nUmvcdk5RYk0OA": {
getter: function (varBag, idService) {
return varBag.base64ToBinaryJSResult.value;
}
},
"awvLpoOUGE2NKX1c5orqbQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"g3Ewpcjtbk+7GoEI0_kJSw": {
getter: function (varBag, idService) {
return varBag.createModifyRolesPermissionsJSResult.value;
}
},
"FrSO3C6DXUeYgwA5+TT2WQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"MJfUZish5EO7bW0wt5Ghqw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"JWtSNqvuvkKpsbYBtFxoNw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"S2zzImDTNUe1ByT9N3_NSw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"3+uhXHP9L0u6H98qp1fxMw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"Sm0ZaMBTNUWirRNk2WU+gg": {
getter: function (varBag, idService) {
return varBag.hasSystemAdminJSResult.value;
}
},
"ZBhACQV1l0Kh2yk6EON1hw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"zOsvTxIaGkSlSoVf+3ra1w": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"vMbJDoWJn0ideSu_2nNLvQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"joAqW96S20m1XBpniIXNAg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"fB4URyw6tUiKIJm_FyeR_w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"kOD2PmKU+U+GHAKbQcvNdA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"1ldzJ+Y3YUaU2t8V2bgcYA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"7rfmE2m0ukWucCSIDX0Usg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"Ze_FxeQtak+PcJ8ZopIrgg": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"LZ+Wgq5CrkGhPBIt78WPkQ": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"dJm4ApJ2G0WWZihKfvRA2A": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"P2+sPtXGaEuY28YhWcgS1g": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"+3n7alAFDkCam2omEim_9w": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"L+KhLeFJkU+xYTVRqI77_A": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"gLgDaz_dAE6ke3FHusHuMA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"nA0vGpdy6Ui5Sy+RSMEwFA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"qPYQoAU7aESQiHKe54TTQw": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"2_HzkDE23UeaXpxGSnpTXA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"5AQXRLANZ0mTUBG6ATZC7Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"tlpRM3Z7IkmhQ5pxhPaXEw": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"if6T7EVWxUi9H99tdB7_ng": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"AlNw552U6kO8Q+SG+vjLZA": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"DeYOirakBEK3gwTuM2y6qQ": {
getter: function (varBag, idService) {
return varBag.javaScript_SetValidURLJSResult.value;
}
},
"CHHXyaGntUWvHZPURpXGYA": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"rErZfyo3Xk+JHKlZsw7Xqw": {
getter: function (varBag, idService) {
return varBag.hasSystemAdminJSResult.value;
}
},
"UDEE0S3_y0CrgKKR_QfvbQ": {
getter: function (varBag, idService) {
return varBag.hasConfigureFundJSResult.value;
}
},
"YJfnCIC6IkWLcIdwJF4XMQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.hasAccessOut;
},
dataType: OS.Types.Boolean
},
"G1Tbmk9jJ0CrQI+01VBxcg": {
getter: function (varBag, idService) {
return varBag.javaScriptJSResult.value;
}
},
"rVHaMMh1Tkm76yRu7Efv5A": {
getter: function (varBag, idService) {
return varBag.vars.value.elementIdInLocal;
},
dataType: OS.Types.Text
},
"VcOMdsFlLU+Pf7lOMySOvw": {
getter: function (varBag, idService) {
return varBag.setFocusJSResult.value;
}
},
"4BcWEWvHTk2h3psxeZoyng": {
getter: function (varBag, idService) {
return Common_CWClientVariables.getLastURL();
},
dataType: OS.Types.Text
},
"JUWmiO2JYkSjYXqdphMmWQ": {
getter: function (varBag, idService) {
return Common_CWClientVariables.getPrimaryColor();
},
dataType: OS.Types.Text
},
"xiMHuVCjqU2wmFXj+98+_g": {
getter: function (varBag, idService) {
return Common_CWClientVariables.getGlobalBasicSearch();
},
dataType: OS.Types.Text
},
"jVQMzAfyQEyDzAt8ZRgO_A": {
getter: function (varBag, idService) {
return Common_CWClientVariables.getTenantLogo();
},
dataType: OS.Types.Text
},
"FrDh6GEtcUeQe7c5kutDkw": {
getter: function (varBag, idService) {
return Common_CWClientVariables.getLogoFileName();
},
dataType: OS.Types.Text
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
