﻿define("PHICore.Stakeholder.NewStakeholder_Popup.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore.model", "Common_CW.controller", "PHICore.model$Text3RecordList", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$GetRequiredFieldMsg", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Set_Focus", "PHICore.model$Text3Record", "PHICore.model$StakeholderTypeRecordList"], function (OutSystems, PHICoreModel, Common_CWController) {
var OS = OutSystems.Internal;
var GetStakeholderTypesAggrRec = (function (_super) {
__extends(GetStakeholderTypesAggrRec, _super);
function GetStakeholderTypesAggrRec(defaults) {
_super.apply(this, arguments);
}
GetStakeholderTypesAggrRec.RecordListType = PHICoreModel.StakeholderTypeRecordList;
GetStakeholderTypesAggrRec.init();
return GetStakeholderTypesAggrRec;
})(OS.Model.AggregateRecord);


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("StakeholderTypeList", "stakeholderTypeListVar", "StakeholderTypeList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new PHICoreModel.Text3RecordList());
}, false, PHICoreModel.Text3RecordList), 
this.attr("StakeholderType", "stakeholderTypeVar", "StakeholderType", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("ShowRestrictedPermission", "showRestrictedPermissionVar", "ShowRestrictedPermission", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ShowNewStakeholderPopup", "showNewStakeholderPopupIn", "ShowNewStakeholderPopup", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showNewStakeholderPopupInDataFetchStatus", "_showNewStakeholderPopupInDataFetchStatus", "_showNewStakeholderPopupInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("GetStakeholderTypes", "getStakeholderTypesAggr", "getStakeholderTypesAggr", true, true, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new GetStakeholderTypesAggrRec());
}, true, GetStakeholderTypesAggrRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Dropdown_StakeholderType: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("ShowNewStakeholderPopup" in inputs) {
this.variables.showNewStakeholderPopupIn = inputs.ShowNewStakeholderPopup;
if("_showNewStakeholderPopupInDataFetchStatus" in inputs) {
this.variables._showNewStakeholderPopupInDataFetchStatus = inputs._showNewStakeholderPopupInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Stakeholder.NewStakeholder_Popup");
});
define("PHICore.Stakeholder.NewStakeholder_Popup.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "react", "OutSystems/ReactView/Main", "PHICore.Stakeholder.NewStakeholder_Popup.mvc$model", "PHICore.Stakeholder.NewStakeholder_Popup.mvc$controller", "PHICore.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "Common_CW.PHICore_CW.PreviousFocus.mvc$view", "Common_CW.PHICore_CW.NextFocus.mvc$view", "Common_CW.PHICore_CW.RestrictedPopup.mvc$view", "PHICore.model$Text3RecordList", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$GetRequiredFieldMsg", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Set_Focus", "PHICore.model$Text3Record", "PHICore.model$StakeholderTypeRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, React, OSView, PHICore_Stakeholder_NewStakeholder_Popup_mvc_model, PHICore_Stakeholder_NewStakeholder_Popup_mvc_controller, PHICoreClientVariables, OSWidgets, OutSystemsUI_Utilities_AlignCenter_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Stakeholder.NewStakeholder_Popup";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [OutSystemsUI_Utilities_AlignCenter_mvc_view, Common_CW_PHICore_CW_PreviousFocus_mvc_view, Common_CW_PHICore_CW_NextFocus_mvc_view, Common_CW_PHICore_CW_RestrictedPopup_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_Stakeholder_NewStakeholder_Popup_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_Stakeholder_NewStakeholder_Popup_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Popup, {
showPopup: model.variables.showNewStakeholderPopupIn,
style: "popup-dialog popup-small",
_idProps: {
service: idService,
name: "Popup_NewStakeholder"
},
_widgetRecordProvider: widgetsRecordProvider,
showPopup_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showNewStakeholderPopupInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
name: "Title"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width11"
},
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.AdvancedHtml, {
tag: "h4",
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "font-regular",
text: ["New Stakeholder"],
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width1"
},
style: "text-align-right",
visible: true,
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Link, {
enabled: true,
extendedProperties: {
role: "button",
"aria-label": "close new stakeholder"
},
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup/Link_CloseCreateNewStakeholder OnClick");
controller.toggle_NewStakeholder$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
visible: true,
_idProps: {
service: idService,
name: "Link_CloseCreateNewStakeholder"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "times",
iconSize: /*FontSize*/ 0,
style: "icon text-neutral-6",
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "margin-bottom-m",
visible: true,
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: true,
targetWidget: "Dropdown_StakeholderType",
_idProps: {
service: idService,
uuid: "10"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Stakeholder Type"), React.createElement(OSWidgets.Dropdown, {
_validationProps: {
validationService: validationService
},
dropdownMode: /*Text*/ 0,
emptyValue: "Select",
enabled: true,
labels: function (elem) {
return elem.stakeholderTypeAttr.labelAttr;
},
list: model.variables.getStakeholderTypesAggr.listOut,
mandatory: true,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup/Dropdown_StakeholderType OnChange");
controller.onChange_StakeholderType$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "dropdown",
values: function (elem) {
return elem.stakeholderTypeAttr.idAttr;
},
variable: model.createVariable(OS.Types.Integer, model.variables.stakeholderTypeVar, function (value) {
model.variables.stakeholderTypeVar = value;
}),
_idProps: {
service: idService,
name: "Dropdown_StakeholderType"
},
_widgetRecordProvider: widgetsRecordProvider,
list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getStakeholderTypesAggr.dataFetchStatusAttr),
placeholders: {
content: PlaceholderContent.Empty
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "display-flex justify-content-space-between",
visible: true,
_idProps: {
service: idService,
name: "Footer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: true,
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup/Btn_Cancel OnClick");
controller.toggle_NewStakeholder$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn",
visible: true,
_idProps: {
service: idService,
name: "Btn_Cancel"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Cancel"), React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Stakeholder/NewStakeholder_Popup/Button_Next OnClick");
controller.onClick_Next$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "Button_Next"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Next")), React.createElement(Common_CW_PHICore_CW_PreviousFocus_mvc_view, {
inputs: {
PreviousElement: ("#" + idService.getId("Button_Next")),
CurrentWidgetId: idService.getId("PreviousFocus"),
CurrentElement: ("#" + idService.getId("Link_CloseCreateNewStakeholder"))
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "PreviousFocus",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_NextFocus_mvc_view, {
inputs: {
NextElement: ("#" + idService.getId("Link_CloseCreateNewStakeholder")),
CurrentElement: ("#" + idService.getId("Button_Next")),
CurrentWidgetId: idService.getId("NextFocus")
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
name: "NextFocus",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
}), React.createElement(Common_CW_PHICore_CW_RestrictedPopup_mvc_view, {
inputs: {
Show: model.variables.showRestrictedPermissionVar,
Message: "Your current permissions do not allow access this record. If you think this is an error, please contact your administrator."
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
},
eventClose$Action: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "PHICore_CW/RestrictedPopup EventClose");
controller.restrictedPopupEventClose$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore.Stakeholder.NewStakeholder_Popup.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore.model", "PHICore.controller", "Common_CW.controller", "PHICore.languageResources", "PHICore.clientVariables", "PHICore.Stakeholder.NewStakeholder_Popup.mvc$debugger", "PHICore.model$Text3RecordList", "Common_CW.controller$Check_SM_1_AddModifyReopenCancelLead", "PHICore.referencesHealth", "PHICore.referencesHealth$Common_CW", "Common_CW.controller$GetRequiredFieldMsg", "Common_CW.controller$Check_PM_1_CreateModifyQuote", "Common_CW.controller$Set_Focus", "PHICore.model$Text3Record", "PHICore.model$StakeholderTypeRecordList"], function (OutSystems, PHICoreModel, PHICoreController, Common_CWController, PHICoreLanguageResources, PHICoreClientVariables, PHICore_Stakeholder_NewStakeholder_Popup_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {
getStakeholderTypes$AggrRefresh: 0
};
this.dataFetchDependentsGraph = {
getStakeholderTypes$AggrRefresh: []
};
this.shouldSendClientVarsToDataSources = true;
}
// Server Actions

// Aggregates and Data Actions
Controller.prototype.getStakeholderTypes$AggrRefresh = function (maxRecords, startIndex, callContext) {
var model = this.model;
var controller = this.controller;
var callContext = controller.callContext(callContext);
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:9026TsxqIEm6bFKpolRBUA:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ScreenDataSets.9026TsxqIEm6bFKpolRBUA:roOEy5mBXWC5saN4ma5INA", "PHICore", "GetStakeholderTypes", "NRNodes.WebScreenDataSet", callContext.id, varBag);
OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/NewStakeholder_Popup/GetStakeholderTypes");
return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetStakeholderTypes", "screenservices/PHICore/Stakeholder/NewStakeholder_Popup/ScreenDataSetGetStakeholderTypes", "Et0gi8JFKdxlZtY7KP7Riw", maxRecords, startIndex, function (b) {
model.variables.getStakeholderTypesAggr.dataFetchStatusAttr = b;
}, function (json) {
model.variables.getStakeholderTypesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getStakeholderTypesAggr.constructor));
}, undefined, OutSystemsDebugger.getRequestHeaders(callContext.id), function (json, headers) {
OutSystemsDebugger.processResponseHeaders(callContext.id, headers);
}, callContext, PHICoreClientVariables, false);

}, function () {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:9026TsxqIEm6bFKpolRBUA", callContext.id);
controller.popDebuggerContext(callContext);

});
};

Controller.prototype.dataFetchActionNames = ["getStakeholderTypes$AggrRefresh"];
// Client Actions
Controller.prototype._restrictedPopupEventClose$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("RestrictedPopupEventClose");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:Q6KoQfmCrkCU301J0v81Hg:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.Q6KoQfmCrkCU301J0v81Hg:QufYiZBKHC0r+a2EEJdc_g", "PHICore", "RestrictedPopupEventClose", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:oQ6fmd_Nw0GXr36WhLGm3w", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:L3Iib0N950SlOfzr4mjRCA", callContext.id);
// ShowRestrictedPermission = False
model.variables.showRestrictedPermissionVar = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:pXDNbGaZ00u6LqknzQ4QUw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:Q6KoQfmCrkCU301J0v81Hg", callContext.id);
}

};
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:1dtHXgnS1EGGfBE12vDhUw:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.1dtHXgnS1EGGfBE12vDhUw:vF8FTjRVZYb3PYl_lmGMhg", "PHICore", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:GVb+BScQqk6JykjwgYxHaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:C69t1cGAc0mnXkab0DJD0g", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:1dtHXgnS1EGGfBE12vDhUw", callContext.id);
}

};
Controller.prototype._onClick_Next$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnClick_Next");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:iDCnhFOwd0i9+d52IBoBVA:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.iDCnhFOwd0i9+d52IBoBVA:JevK4sCa0_FILXklA+moUw", "PHICore", "OnClick_Next", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:0JzpjPbpIEikxqV5Bz+81Q", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:iekI8V37EkC1Ha6KRlu9MA", callContext.id) && (model.variables.stakeholderTypeVar === OS.BuiltinFunctions.nullIdentifier()))) {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Pe1uvYKL0kShMyVuadXfFg", callContext.id);
// Dropdown_StakeholderType.Valid = False
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validAttr = false;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:Pe1uvYKL0kShMyVuadXfFg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Dropdown_StakeholderType.ValidationMessage = GetRequiredFieldMsg()
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validationMessageAttr = OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.getRequiredFieldMsg$Action(callContext).msgOut;
}, OS.Types.Text, callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:4eRVvz5F5EO7iYzYg5OZrA", callContext.id);
OS.FeedbackMessageService.showFeedbackMessage("Errors have occurred, please review highlighted fields", /*Error*/ 3);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:fwtYYbOWoEyjGK14pdqvaw", callContext.id);
} else {
do {
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nzJE+mV5SkaP0B6kRmtOow", callContext.id);
// Dropdown_StakeholderType.Valid = True
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nzJE+mV5SkaP0B6kRmtOow", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Dropdown_StakeholderType.ValidationMessage = ""
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validationMessageAttr = "";
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:6lfyNbscCkKzsCWd5IMcVg", callContext.id) && (model.variables.stakeholderTypeVar === PHICoreModel.staticEntities.stakeholderType.prospect))) {
// Has Create Prospect Permission
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:tTmqxOJhk0iM54bN8enMrQ", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_PM_1_CreateModifyQuote$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
break;
}

} else {
if((model.variables.stakeholderTypeVar === PHICoreModel.staticEntities.stakeholderType.lead)) {
// Has AddModifyReopenCancelLead Permission
if((OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:gPeklMpRQkCmQPWJeqvp1Q", callContext.id) && !(OutSystemsDebugger.handleFunctionCall(function () {
return Common_CWController.default.check_SM_1_AddModifyReopenCancelLead$Action(callContext).hasAccessOut;
}, OS.Types.Boolean, callContext.id)))) {
break;
}

}

}

OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:zX6kKKopnEunHNsAAmRrjw", callContext.id);
// Destination: /PHICore/NewLead
return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("PHICore", "NewLead", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
} while(false)
;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:nhBrkqLwDE2ojzfkyLlmag", callContext.id);
// ShowRestrictedPermission = True
model.variables.showRestrictedPermissionVar = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:ndSDLwz25EGws4GPq6M0Gg", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:iDCnhFOwd0i9+d52IBoBVA", callContext.id);
}

};
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:KiYEl2OjO0+nIv0PCt0EtA:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.KiYEl2OjO0+nIv0PCt0EtA:f5WfjSvMQksg+ElsYYYt6g", "PHICore", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hmgDS8x1TEi+7Vm205xjKQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:DGOKi7H5Zk+IUdn5UfRaZQ", callContext.id);
// Execute Action: Set_Focus
Common_CWController.default.set_Focus$Action(model.variables.showNewStakeholderPopupIn, idService.getId("Link_CloseCreateNewStakeholder"), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:eezF2BNgx0q89yyLjqr6fg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:KiYEl2OjO0+nIv0PCt0EtA", callContext.id);
}

};
Controller.prototype._onChange_StakeholderType$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnChange_StakeholderType");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:pswPuqoNmUGXL4Uz+sld8Q:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.pswPuqoNmUGXL4Uz+sld8Q:KliF6F_fPO93ca0kgxe7GQ", "PHICore", "OnChange_StakeholderType", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:cePjzkymIUy4KxVGf1Gcqw", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WVkV9StTZkOTooc91gD3Ig", callContext.id);
// Dropdown_StakeholderType.Valid = True
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validAttr = true;
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:WVkV9StTZkOTooc91gD3Ig", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Dropdown_StakeholderType.ValidationMessage = ""
model.widgets.get(idService.getId("Dropdown_StakeholderType")).validationMessageAttr = "";
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:hetwPR0JgEufakkURlx89A", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:pswPuqoNmUGXL4Uz+sld8Q", callContext.id);
}

};
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:xAuo6LyY6km+xaYb1Hnnpw:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ/ClientActions.xAuo6LyY6km+xaYb1Hnnpw:_ixJq9elcEE9wFeauaec3g", "PHICore", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:I7xzXnyEsU2DSp1sRWzUlQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:rIp9oRZeakemTo0TEEMQ6A", callContext.id);
// Execute Action: ListAppendAll
OS.SystemActions.listAppendAll(model.variables.stakeholderTypeListVar, function () {
var list = new PHICoreModel.Text3RecordList();
list.pushAll([function () {
var rec = new PHICoreModel.Text3Record();
rec.textAttr = "";
return rec;
}(), function () {
var rec = new PHICoreModel.Text3Record();
rec.textAttr = "Lead";
return rec;
}()]);
return list;
}(), callContext);
OutSystemsDebugger.handleBreakpoint("i+ss0+TkUkS7Et08zebfYg:HRTZ8S37l0aj+25Luu8UFg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:xAuo6LyY6km+xaYb1Hnnpw", callContext.id);
}

};

Controller.prototype.restrictedPopupEventClose$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._restrictedPopupEventClose$Action, callContext);

};
Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onClick_Next$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onClick_Next$Action, callContext);

};
Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onChange_StakeholderType$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onChange_StakeholderType$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.toggle_NewStakeholder$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:81TaMXbH30eFBDGHZnRU9A:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A:yTK3TFV6a6LgpT6Ltgqz_Q", "PHICore", "Stakeholder", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("i+ss0+TkUkS7Et08zebfYg:WtZMyDPioUWEXttriB6sIQ:/NRWebFlows.81TaMXbH30eFBDGHZnRU9A/NodesShownInESpaceTree.WtZMyDPioUWEXttriB6sIQ:SRdQDmoCjGCAzj5abSJMUg", "PHICore", "NewStakeholder_Popup", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:WtZMyDPioUWEXttriB6sIQ", callContext.id);
OutSystemsDebugger.pop("i+ss0+TkUkS7Et08zebfYg:81TaMXbH30eFBDGHZnRU9A", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/NewStakeholder_Popup On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/NewStakeholder_Popup On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Stakeholder/NewStakeholder_Popup On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICoreController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICoreLanguageResources);
});

define("PHICore.Stakeholder.NewStakeholder_Popup.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"RNYaMbkkUkOk7tlUsOeUdA": {
getter: function (varBag, idService) {
return varBag.model.variables.stakeholderTypeListVar;
}
},
"uzZF8gaOQkWHIMDYwUtfNg": {
getter: function (varBag, idService) {
return varBag.model.variables.stakeholderTypeVar;
},
dataType: OS.Types.Integer
},
"fSCVKnBjjkGpEFnYIqlgdA": {
getter: function (varBag, idService) {
return varBag.model.variables.showRestrictedPermissionVar;
},
dataType: OS.Types.Boolean
},
"ssYQkvYTKUaN_hiCUpVW5g": {
getter: function (varBag, idService) {
return varBag.model.variables.showNewStakeholderPopupIn;
},
dataType: OS.Types.Boolean
},
"9026TsxqIEm6bFKpolRBUA": {
getter: function (varBag, idService) {
return varBag.model.variables.getStakeholderTypesAggr;
}
},
"eXxkdSDS2U+eWgWMIlebqQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Popup_NewStakeholder"));
})(varBag.model, idService);
}
},
"omGoiAFbL0OUFhAq3DwVwg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Title"));
})(varBag.model, idService);
}
},
"CgGQm6w2GkaIMdfNTyVXpA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"aGBS9RJEe0mAnifwcQlXnw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Link_CloseCreateNewStakeholder"));
})(varBag.model, idService);
}
},
"C8kttd20UkedE3YGHx3tPw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
},
"DG5Af724hEmq0V_8oKvJ9A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Dropdown_StakeholderType"));
})(varBag.model, idService);
}
},
"_FGtpt6wxkGk+A6bTp98Qw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Footer"));
})(varBag.model, idService);
}
},
"JXJbmxoHrkum37H2MF2yag": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Btn_Cancel"));
})(varBag.model, idService);
}
},
"bmh5Meb5q02weEBi+20Yiw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Button_Next"));
})(varBag.model, idService);
}
},
"oKRFJi9FX06j_BkPQ2W0VQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PreviousFocus"));
})(varBag.model, idService);
}
},
"tiJtqzJ_v0K0aZFZtEn4xg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("NextFocus"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
