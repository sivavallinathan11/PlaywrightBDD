﻿define("OutSystemsCharts.Version1.DonutChart_v1.mvc$model", ["OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.model$Legacy_InternalConfigRec", "OutSystemsCharts.model$Legacy_DataPointList", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "OutSystemsCharts.controller$UpdateConfigs", "OutSystemsCharts.model$Legacy_AdvancedDataPointFormatList", "OutSystemsCharts.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.controller$RemoveChart", "OutSystemsCharts.controller$SeriesEventUnsubscribe", "OutSystemsCharts.controller$CreateChart", "OutSystemsCharts.controller$GenerateUniqueId", "OutSystemsCharts.model$Legacy_DataPointRec", "OutSystemsCharts.controller$Legacy_InitChart", "OutSystemsCharts.controller$SeriesEventSubscribe"], function (OutSystems, OutSystemsChartsModel, OutSystemsChartsController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("UniqueId", "uniqueIdVar", "UniqueId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("Internal_Configs", "internal_ConfigsVar", "Internal_Configs", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.Legacy_InternalConfigRec());
}, false, OutSystemsChartsModel.Legacy_InternalConfigRec), 
this.attr("IsInitialized", "isInitializedVar", "IsInitialized", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("SourceDataPointList", "sourceDataPointListIn", "SourceDataPointList", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.Legacy_DataPointList());
}, false, OutSystemsChartsModel.Legacy_DataPointList), 
this.attr("_sourceDataPointListInDataFetchStatus", "_sourceDataPointListInDataFetchStatus", "_sourceDataPointListInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Height", "heightIn", "Height", true, false, OS.Types.Integer, function () {
return 300;
}, false), 
this.attr("_heightInDataFetchStatus", "_heightInDataFetchStatus", "_heightInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("LegendPositionId", "legendPositionIdIn", "LegendPositionId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_legendPositionIdInDataFetchStatus", "_legendPositionIdInDataFetchStatus", "_legendPositionIdInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ChartFormat", "chartFormatIn", "ChartFormat", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.Legacy_ChartFormatRec());
}, false, OutSystemsChartsModel.Legacy_ChartFormatRec), 
this.attr("_chartFormatInDataFetchStatus", "_chartFormatInDataFetchStatus", "_chartFormatInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("Clickable", "clickableIn", "Clickable", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_clickableInDataFetchStatus", "_clickableInDataFetchStatus", "_clickableInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("AdvancedFormat", "advancedFormatIn", "AdvancedFormat", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.Legacy_AdvancedFormatRec());
}, false, OutSystemsChartsModel.Legacy_AdvancedFormatRec), 
this.attr("_advancedFormatInDataFetchStatus", "_advancedFormatInDataFetchStatus", "_advancedFormatInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("SourceDataPointList" in inputs) {
this.variables.sourceDataPointListIn = inputs.SourceDataPointList;
if("_sourceDataPointListInDataFetchStatus" in inputs) {
this.variables._sourceDataPointListInDataFetchStatus = inputs._sourceDataPointListInDataFetchStatus;
}

}

if("Height" in inputs) {
this.variables.heightIn = inputs.Height;
if("_heightInDataFetchStatus" in inputs) {
this.variables._heightInDataFetchStatus = inputs._heightInDataFetchStatus;
}

}

if("LegendPositionId" in inputs) {
this.variables.legendPositionIdIn = inputs.LegendPositionId;
if("_legendPositionIdInDataFetchStatus" in inputs) {
this.variables._legendPositionIdInDataFetchStatus = inputs._legendPositionIdInDataFetchStatus;
}

}

if("ChartFormat" in inputs) {
this.variables.chartFormatIn = inputs.ChartFormat;
if("_chartFormatInDataFetchStatus" in inputs) {
this.variables._chartFormatInDataFetchStatus = inputs._chartFormatInDataFetchStatus;
}

}

if("Clickable" in inputs) {
this.variables.clickableIn = inputs.Clickable;
if("_clickableInDataFetchStatus" in inputs) {
this.variables._clickableInDataFetchStatus = inputs._clickableInDataFetchStatus;
}

}

if("AdvancedFormat" in inputs) {
this.variables.advancedFormatIn = inputs.AdvancedFormat;
if("_advancedFormatInDataFetchStatus" in inputs) {
this.variables._advancedFormatInDataFetchStatus = inputs._advancedFormatInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Version1.DonutChart_v1");
});
define("OutSystemsCharts.Version1.DonutChart_v1.mvc$view", ["OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "react", "OutSystems/ReactView/Main", "OutSystemsCharts.Version1.DonutChart_v1.mvc$model", "OutSystemsCharts.Version1.DonutChart_v1.mvc$controller", "OutSystems/ReactWidgets/Main", "OutSystemsCharts.model$Legacy_InternalConfigRec", "OutSystemsCharts.model$Legacy_DataPointList", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "OutSystemsCharts.controller$UpdateConfigs", "OutSystemsCharts.model$Legacy_AdvancedDataPointFormatList", "OutSystemsCharts.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.controller$RemoveChart", "OutSystemsCharts.controller$SeriesEventUnsubscribe", "OutSystemsCharts.controller$CreateChart", "OutSystemsCharts.controller$GenerateUniqueId", "OutSystemsCharts.model$Legacy_DataPointRec", "OutSystemsCharts.controller$Legacy_InitChart", "OutSystemsCharts.controller$SeriesEventSubscribe"], function (OutSystems, OutSystemsChartsModel, OutSystemsChartsController, React, OSView, OutSystemsCharts_Version1_DonutChart_v1_mvc_model, OutSystemsCharts_Version1_DonutChart_v1_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Version1.DonutChart_v1";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/OutSystemsCharts.Highcharts.js", "scripts/OutSystemsCharts.HighchartsMore.js", "scripts/OutSystemsCharts.Highcharts3d.js", "scripts/OutSystemsCharts.Accessibility.js", "scripts/OutSystemsCharts.OutsystemsCharts.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return OutSystemsCharts_Version1_DonutChart_v1_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return OutSystemsCharts_Version1_DonutChart_v1_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "chart-wrapper",
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
name: model.variables.uniqueIdVar
},
style: "chart-container",
visible: true,
_idProps: {
service: idService,
name: "ChartContainer"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "chart-color background-primary-color background-primary invisible",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("OutSystemsCharts.Version1.DonutChart_v1.mvc$controller", ["OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.controller", "OutSystemsCharts.languageResources", "OutSystemsCharts.Version1.DonutChart_v1.mvc$debugger", "OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.UnsubscribeEvents.GetActionsHandlerJS", "OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.GenerateChart.ShowEmptyStateJS", "OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.GenerateChart.GetActionsHandlerJS", "OutSystemsCharts.model$Legacy_InternalConfigRec", "OutSystemsCharts.model$Legacy_DataPointList", "OutSystemsCharts.model$Legacy_ChartFormatRec", "OutSystemsCharts.model$Legacy_AdvancedFormatRec", "OutSystemsCharts.controller$UpdateConfigs", "OutSystemsCharts.model$Legacy_AdvancedDataPointFormatList", "OutSystemsCharts.model$Legacy_AdvancedDataSeriesFormatList", "OutSystemsCharts.controller$RemoveChart", "OutSystemsCharts.controller$SeriesEventUnsubscribe", "OutSystemsCharts.controller$CreateChart", "OutSystemsCharts.controller$GenerateUniqueId", "OutSystemsCharts.model$Legacy_DataPointRec", "OutSystemsCharts.controller$Legacy_InitChart", "OutSystemsCharts.controller$SeriesEventSubscribe"], function (OutSystems, OutSystemsChartsModel, OutSystemsChartsController, OutSystemsChartsLanguageResources, OutSystemsCharts_Version1_DonutChart_v1_mvc_Debugger, OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_UnsubscribeEvents_GetActionsHandlerJS, OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_GenerateChart_ShowEmptyStateJS, OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_GenerateChart_GetActionsHandlerJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
dataClicked$Action: function (chartIdIn, dataPointStrIn) {
chartIdIn = (chartIdIn === undefined) ? "" : chartIdIn;
dataPointStrIn = (dataPointStrIn === undefined) ? "" : dataPointStrIn;
return controller.executeActionInsideJSNode(controller._dataClicked$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(chartIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(dataPointStrIn, OS.Types.Text)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "DataClicked");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onParametersChanged$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnParametersChanged");
callContext = controller.callContext(callContext);
var jSONDataPointFormatsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONInternal_ConfigsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONDataSeriesFormatsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONSerialize_SourceDataPoint_ListVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.jSONDataPointFormatsVar = jSONDataPointFormatsVar;
varBag.jSONInternal_ConfigsVar = jSONInternal_ConfigsVar;
varBag.jSONDataSeriesFormatsVar = jSONDataSeriesFormatsVar;
varBag.jSONSerialize_SourceDataPoint_ListVar = jSONSerialize_SourceDataPoint_ListVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:FUEZEWFEXEyjuXRw2Vdbkw:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.FUEZEWFEXEyjuXRw2Vdbkw:qNPsuM00hg3eLkcRGkbc1g", "OutSystemsCharts", "OnParametersChanged", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:NLkV9omyWEqMC+o69ck+WA", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:mdvqBjJQv0CP1hc0JdoiOg", callContext.id) && !(model.variables.isInitializedVar))) {
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:yqvaU6GBEUebPeeY7YNkiA", callContext.id) && !(model.variables.sourceDataPointListIn.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:EzRe+68qJEC1oDzi1y0RGA", callContext.id);
// Execute Action: GenerateChart
controller._generateChart$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:dM+0OeFU_ke1UThyascptA", callContext.id);
return ;

}

}

OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:HzztKHjXr0yaoZLaK9iLJg", callContext.id);
// JSON Serialize: JSONDataPointFormats
jSONDataPointFormatsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.advancedFormatIn.dataPointFormatsAttr, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:2Yn5ObfzQ06mGaMMeV2Zmw", callContext.id);
// JSON Serialize: JSONDataSeriesFormats
jSONDataSeriesFormatsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.advancedFormatIn.dataSeriesFormatsAttr, true, false);
// Internal_NewConfig
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id);
// Internal_Configs.chartFormat = ChartFormat
model.variables.internal_ConfigsVar.chartFormatAttr = model.variables.chartFormatIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Internal_Configs.legendPositionId = LegendPositionId
model.variables.internal_ConfigsVar.legendPositionIdAttr = model.variables.legendPositionIdIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Internal_Configs.chart.height = Height
model.variables.internal_ConfigsVar.chartAttr.heightAttr = model.variables.heightIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Internal_Configs.isClickable = Clickable
model.variables.internal_ConfigsVar.isClickableAttr = model.variables.clickableIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Internal_Configs.advancedFormat_JSON.DataPointFormatsJSON = JSONDataPointFormats.JSON
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.dataPointFormatsJSONAttr = jSONDataPointFormatsVar.value.jSONOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Internal_Configs.advancedFormat_JSON.DataSeriesFormatsJSON = JSONDataSeriesFormats.JSON
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.dataSeriesFormatsJSONAttr = jSONDataSeriesFormatsVar.value.jSONOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Internal_Configs.advancedFormat_JSON.XAxisJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.xAxisJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.xAxisJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Internal_Configs.advancedFormat_JSON.YAxisJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.yAxisJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.yAxisJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:vA2FkaQ5z02VsnNE0xnXIw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Internal_Configs.advancedFormat_JSON.HighchartsJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.highchartsJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.highchartsJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:M7JeKiB8pUeJ0cu7gy_O2g", callContext.id);
// JSON Serialize: JSONInternal_Configs
jSONInternal_ConfigsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.internal_ConfigsVar, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:s7Dn8BPauka2mFWqGfQ_gw", callContext.id);
// JSON Serialize: JSONSerialize_SourceDataPoint_List
jSONSerialize_SourceDataPoint_ListVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.sourceDataPointListIn, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:tUcHfMIAZ0yHX_7KKDsBsg", callContext.id);
// Execute Action: UpdateConfigs
OutSystemsChartsController.default.updateConfigs$Action(model.variables.uniqueIdVar, jSONInternal_ConfigsVar.value.jSONOut, jSONSerialize_SourceDataPoint_ListVar.value.jSONOut, callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:En630vASiUykkr08vEQcmA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:FUEZEWFEXEyjuXRw2Vdbkw", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:uPMkO+UuO0CKjkaxWktvug:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.uPMkO+UuO0CKjkaxWktvug:SSuKX0Gyck3wdk64Pp_wvQ", "OutSystemsCharts", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:bXYkqzRNgk2OECfah2CWCQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:jten_XiYGU62mRj8ScdsyA", callContext.id);
// Execute Action: UnsubscribeEvents
controller._unsubscribeEvents$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:nk20jZPtDUG6YGJCUj0_9w", callContext.id);
// Execute Action: RemoveChart
OutSystemsChartsController.default.removeChart$Action(model.variables.uniqueIdVar, callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:9C_rbn6TtUKRGM7xCR9niQ", callContext.id);
// IsInitialized = False
model.variables.isInitializedVar = false;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:JO8_rTgPdEG_BSsVIIXcxA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:uPMkO+UuO0CKjkaxWktvug", callContext.id);
}

};
Controller.prototype._unsubscribeEvents$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("UnsubscribeEvents");
callContext = controller.callContext(callContext);
var getActionsHandlerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getActionsHandlerJSResult = getActionsHandlerJSResult;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:s2W2gS6HE0aqLTRE8d1LbQ:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.s2W2gS6HE0aqLTRE8d1LbQ:WqxjliW89v1kIvGJGJ_NeA", "OutSystemsCharts", "UnsubscribeEvents", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:uV5hEcEoW0OzA3i8yhHRQg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:3HA+K0TClk2DU2e8rAyRJQ", callContext.id);
getActionsHandlerJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_UnsubscribeEvents_GetActionsHandlerJS, "GetActionsHandler", "UnsubscribeEvents", {
CallbackEvent: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.UnsubscribeEvents$getActionsHandlerJSResult"))();
jsNodeResult.callbackEventOut = OS.DataConversion.JSNodeParamConverter.from($parameters.CallbackEvent, OS.Types.Object);
return jsNodeResult;
}, {
DataClicked: controller.clientActionProxies.dataClicked$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:S7wWqvWDEUWszx3J6QrcOw", callContext.id);
// Execute Action: SeriesEventUnsubscribe
OutSystemsChartsController.default.seriesEventUnsubscribe$Action(model.variables.uniqueIdVar, OutSystemsChartsModel.staticEntities.seriesEvent_v1.click, getActionsHandlerJSResult.value.callbackEventOut, callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:p1bQM1CFfkOBx42kHNHRaw", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:s2W2gS6HE0aqLTRE8d1LbQ", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.UnsubscribeEvents$getActionsHandlerJSResult", [{
name: "CallbackEvent",
attrName: "callbackEventOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
Controller.prototype._onInitialize$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var generateUniqueIdVar = new OS.DataTypes.VariableHolder();
var jSONDataSeriesFormatsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var jSONDataPointFormatsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var serialize_configsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
varBag.callContext = callContext;
varBag.generateUniqueIdVar = generateUniqueIdVar;
varBag.jSONDataSeriesFormatsVar = jSONDataSeriesFormatsVar;
varBag.jSONDataPointFormatsVar = jSONDataPointFormatsVar;
varBag.serialize_configsVar = serialize_configsVar;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:rrPahKN0rEK0JLOUK7rPaQ:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.rrPahKN0rEK0JLOUK7rPaQ:ym4tKezad3DrXPm6G+L_UQ", "OutSystemsCharts", "OnInitialize", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:lTCRHYKtNEauXhsjCNu5JQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:YwHNldaF6k2Ui8h_eKBVTA", callContext.id);
// Execute Action: GenerateUniqueId
generateUniqueIdVar.value = OutSystemsChartsController.default.generateUniqueId$Action(model.variables.uniqueIdVar, callContext);

OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:03ZHJBxLi0ib9wo_lV6u0A", callContext.id);
// UniqueId = GenerateUniqueId.Unique_ID
model.variables.uniqueIdVar = generateUniqueIdVar.value.unique_IDOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:03ZHJBxLi0ib9wo_lV6u0A", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsInitialized = False
model.variables.isInitializedVar = false;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:pk8DNTkns0CjIPKneNgZEw", callContext.id);
// JSON Serialize: JSONDataPointFormats
jSONDataPointFormatsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.advancedFormatIn.dataPointFormatsAttr, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:1rHoGvPKyEKaibEUJ1A6sA", callContext.id);
// JSON Serialize: JSONDataSeriesFormats
jSONDataSeriesFormatsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.advancedFormatIn.dataSeriesFormatsAttr, true, false);
// Internal_NewConfig
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id);
// Internal_Configs.chartFormat = ChartFormat
model.variables.internal_ConfigsVar.chartFormatAttr = model.variables.chartFormatIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// Internal_Configs.legendPositionId = LegendPositionId
model.variables.internal_ConfigsVar.legendPositionIdAttr = model.variables.legendPositionIdIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// Internal_Configs.chart.type = "donut"
model.variables.internal_ConfigsVar.chartAttr.typeAttr = "donut";
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// Internal_Configs.uniqueId = UniqueId
model.variables.internal_ConfigsVar.uniqueIdAttr = model.variables.uniqueIdVar;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// Internal_Configs.chart.height = Height
model.variables.internal_ConfigsVar.chartAttr.heightAttr = model.variables.heightIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// Internal_Configs.isClickable = Clickable
model.variables.internal_ConfigsVar.isClickableAttr = model.variables.clickableIn;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// Internal_Configs.advancedFormat_JSON.DataPointFormatsJSON = JSONDataPointFormats.JSON
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.dataPointFormatsJSONAttr = jSONDataPointFormatsVar.value.jSONOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// Internal_Configs.advancedFormat_JSON.DataSeriesFormatsJSON = JSONDataSeriesFormats.JSON
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.dataSeriesFormatsJSONAttr = jSONDataSeriesFormatsVar.value.jSONOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// Internal_Configs.advancedFormat_JSON.XAxisJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.xAxisJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.xAxisJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// Internal_Configs.advancedFormat_JSON.YAxisJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.yAxisJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.yAxisJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:diq7MnImdUiuyvn4m9LlEg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// Internal_Configs.advancedFormat_JSON.HighchartsJSON = Trim
model.variables.internal_ConfigsVar.advancedFormat_JSONAttr.highchartsJSONAttr = OS.BuiltinFunctions.trim(model.variables.advancedFormatIn.highchartsJSONAttr);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:JBKbWuL8nU+_aYWcyF_jUQ", callContext.id);
// JSON Serialize: Serialize_configs
serialize_configsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(model.variables.internal_ConfigsVar, true, false);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:a48Dfu4MS0SYYyIFistgYQ", callContext.id);
// Execute Action: CreateChart
OutSystemsChartsController.default.createChart$Action(model.variables.uniqueIdVar, model.variables.internal_ConfigsVar.chartAttr.typeAttr, serialize_configsVar.value.jSONOut, OutSystemsChartsModel.staticEntities.oSChartVersion.version1, OutSystemsChartsModel.staticEntities.chartProvider.highcharts, callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:XdzD5rwye0u1Ch7TJ35+lg", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:rrPahKN0rEK0JLOUK7rPaQ", callContext.id);
}

};
Controller.prototype._dataClicked$Action = function (chartIdIn, dataPointStrIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("DataClicked");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.DataClicked$vars"))());
vars.value.chartIdInLocal = chartIdIn;
vars.value.dataPointStrInLocal = dataPointStrIn;
var jSONDeserializeDataPointVar = new OS.DataTypes.VariableHolder(new (OS.Controller.BaseController.getJSONDeserializeOutputType(OutSystemsChartsModel.Legacy_DataPointRec))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jSONDeserializeDataPointVar = jSONDeserializeDataPointVar;
OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:GMeXlqSudkmGPl8oAtv7sQ:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.GMeXlqSudkmGPl8oAtv7sQ:x08Lla79kXqbREjS1gUmyw", "OutSystemsCharts", "DataClicked", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Xq3HEZeW+0OiP74la4v+Kg", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:WZsc77FU5UGnze6kXSah6Q", callContext.id);
// JSON Deserialize: JSONDeserializeDataPoint
jSONDeserializeDataPointVar.value.dataOut = OS.JSONUtils.deserializeFromJSON(vars.value.dataPointStrInLocal, OutSystemsChartsModel.Legacy_DataPointRec, false);
// Fill Data Item
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Vhi1InNUjUqhpgvPwQW5aQ", callContext.id);
// DataPoint = JSONDeserializeDataPoint.Data
vars.value.dataPointVar = jSONDeserializeDataPointVar.value.dataOut;
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:tzuT+LsLNU2gKbkLZLDVzg", callContext.id);
// Trigger Event: OnClick
return controller.onClick$Action(vars.value.dataPointVar, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Al_uGxUpTkG1byWUoMqNbQ", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:GMeXlqSudkmGPl8oAtv7sQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:GMeXlqSudkmGPl8oAtv7sQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.DataClicked$vars", [{
name: "ChartId",
attrName: "chartIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "DataPointStr",
attrName: "dataPointStrInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "DataPoint",
attrName: "dataPointVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsChartsModel.Legacy_DataPointRec();
},
complexType: OutSystemsChartsModel.Legacy_DataPointRec
}]);
Controller.prototype._generateChart$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GenerateChart");
callContext = controller.callContext(callContext);
var getActionsHandlerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.getActionsHandlerJSResult = getActionsHandlerJSResult;
try {OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:zS_2wZGl4UKtqNdY6ds5RQ:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw/ClientActions.zS_2wZGl4UKtqNdY6ds5RQ:Xp+9achHHr12UXuEM4kCYQ", "OutSystemsCharts", "GenerateChart", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:c37Olh+zd0W3b1DuM45k4g", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:h8D9p3U0S0C6QiD0kS7zqw", callContext.id) && model.variables.isInitializedVar)) {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:8dOVFNCOiUqGhQPek5yXfg", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:nWSAzsScf0qzpbX0lJ8T4Q", callContext.id);
getActionsHandlerJSResult.value = controller.safeExecuteJSNode(OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_GenerateChart_GetActionsHandlerJS, "GetActionsHandler", "GenerateChart", {
CallbackEvent: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.GenerateChart$getActionsHandlerJSResult"))();
jsNodeResult.callbackEventOut = OS.DataConversion.JSNodeParamConverter.from($parameters.CallbackEvent, OS.Types.Object);
return jsNodeResult;
}, {
DataClicked: controller.clientActionProxies.dataClicked$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:f5gd0wNookKimU99vXytiA", callContext.id);
// Execute Action: SeriesEventSubscribe
OutSystemsChartsController.default.seriesEventSubscribe$Action(model.variables.uniqueIdVar, OutSystemsChartsModel.staticEntities.seriesEvent_v1.click, getActionsHandlerJSResult.value.callbackEventOut, callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:Ij0+zaoHHkiu_kTr87du9g", callContext.id);
// Execute Action: Legacy_InitChart
OutSystemsChartsController.default.legacy_InitChart$Action(model.variables.uniqueIdVar, model.variables.sourceDataPointListIn, "", callContext);
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:DVKOm9oFMkiFO6oz6Zqiuw", callContext.id);
// IsInitialized = True
model.variables.isInitializedVar = true;
if((OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:noiiWY26z0+7x0xIGbho1g", callContext.id) && !(model.variables.sourceDataPointListIn.isEmpty))) {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:JUuKanC7FE6VcgWqZ7NNXA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:GqTQAGSa7UuB8ZIaUYgtrw", callContext.id);
controller.safeExecuteJSNode(OutSystemsCharts_Version1_DonutChart_v1_mvc_controller_GenerateChart_ShowEmptyStateJS, "ShowEmptyState", "GenerateChart", {
containerId: OS.DataConversion.JSNodeParamConverter.to(model.variables.uniqueIdVar, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Iw63OPxQEEeAzzaCqdyZig:JUuKanC7FE6VcgWqZ7NNXA", callContext.id);
}

}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:zS_2wZGl4UKtqNdY6ds5RQ", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsCharts.Version1.DonutChart_v1.GenerateChart$getActionsHandlerJSResult", [{
name: "CallbackEvent",
attrName: "callbackEventOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);

Controller.prototype.onParametersChanged$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onParametersChanged$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.unsubscribeEvents$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._unsubscribeEvents$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.dataClicked$Action = function (chartIdIn, dataPointStrIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dataClicked$Action, callContext, chartIdIn, dataPointStrIn);

};
Controller.prototype.generateChart$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._generateChart$Action, callContext);

};
Controller.prototype.onClick$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:++cioh2mZkOlEo3O+qWnTg:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg:arpeCTWowRdJ6ITGyhadeQ", "OutSystemsCharts", "Version1", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Iw63OPxQEEeAzzaCqdyZig:DjchUpWISUiy6HNXgascMw:/NRWebFlows.++cioh2mZkOlEo3O+qWnTg/NodesShownInESpaceTree.DjchUpWISUiy6HNXgascMw:tFRMwIJk1mR6zXd1mZ_4bw", "OutSystemsCharts", "DonutChart_v1", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:DjchUpWISUiy6HNXgascMw", callContext.id);
OutSystemsDebugger.pop("Iw63OPxQEEeAzzaCqdyZig:++cioh2mZkOlEo3O+qWnTg", callContext.id);
};
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Version1/DonutChart_v1 On Initialize");
return controller.onInitialize$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Version1/DonutChart_v1 On Ready");
return controller.generateChart$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Version1/DonutChart_v1 On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Version1/DonutChart_v1 On Parameters Changed");
return controller.onParametersChanged$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsChartsController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, OutSystemsChartsLanguageResources);
});
define("OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.UnsubscribeEvents.GetActionsHandlerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CallbackEvent = $actions.DataClicked
};
});
define("OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.GenerateChart.ShowEmptyStateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
OutSystems.ChartAPI.ChartManager.ShowEmptyState(
$parameters.containerId
);
};
});
define("OutSystemsCharts.Version1.DonutChart_v1.mvc$controller.GenerateChart.GetActionsHandlerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.CallbackEvent = $actions.DataClicked
};
});

define("OutSystemsCharts.Version1.DonutChart_v1.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"HzztKHjXr0yaoZLaK9iLJg": {
getter: function (varBag, idService) {
return varBag.jSONDataPointFormatsVar.value;
}
},
"M7JeKiB8pUeJ0cu7gy_O2g": {
getter: function (varBag, idService) {
return varBag.jSONInternal_ConfigsVar.value;
}
},
"2Yn5ObfzQ06mGaMMeV2Zmw": {
getter: function (varBag, idService) {
return varBag.jSONDataSeriesFormatsVar.value;
}
},
"s7Dn8BPauka2mFWqGfQ_gw": {
getter: function (varBag, idService) {
return varBag.jSONSerialize_SourceDataPoint_ListVar.value;
}
},
"3HA+K0TClk2DU2e8rAyRJQ": {
getter: function (varBag, idService) {
return varBag.getActionsHandlerJSResult.value;
}
},
"YwHNldaF6k2Ui8h_eKBVTA": {
getter: function (varBag, idService) {
return varBag.generateUniqueIdVar.value;
}
},
"1rHoGvPKyEKaibEUJ1A6sA": {
getter: function (varBag, idService) {
return varBag.jSONDataSeriesFormatsVar.value;
}
},
"pk8DNTkns0CjIPKneNgZEw": {
getter: function (varBag, idService) {
return varBag.jSONDataPointFormatsVar.value;
}
},
"JBKbWuL8nU+_aYWcyF_jUQ": {
getter: function (varBag, idService) {
return varBag.serialize_configsVar.value;
}
},
"NBKn2Snls0aXj+iOBKA7dA": {
getter: function (varBag, idService) {
return varBag.vars.value.dataPointVar;
}
},
"S9FI3ZGQAkqqYBDVoohvHQ": {
getter: function (varBag, idService) {
return varBag.vars.value.chartIdInLocal;
},
dataType: OS.Types.Text
},
"EkvVI8JGH0Oh9x0X2o1Sxg": {
getter: function (varBag, idService) {
return varBag.vars.value.dataPointStrInLocal;
},
dataType: OS.Types.Text
},
"WZsc77FU5UGnze6kXSah6Q": {
getter: function (varBag, idService) {
return varBag.jSONDeserializeDataPointVar.value;
}
},
"GqTQAGSa7UuB8ZIaUYgtrw": {
getter: function (varBag, idService) {
return varBag.showEmptyStateJSResult.value;
}
},
"nWSAzsScf0qzpbX0lJ8T4Q": {
getter: function (varBag, idService) {
return varBag.getActionsHandlerJSResult.value;
}
},
"r_lZqyz_ska81jAkmwxuDw": {
getter: function (varBag, idService) {
return varBag.model.variables.uniqueIdVar;
},
dataType: OS.Types.Text
},
"urK7wwwZf0GADWnIDanTzw": {
getter: function (varBag, idService) {
return varBag.model.variables.internal_ConfigsVar;
}
},
"ZjlIT4j2rku18qxAQbTKug": {
getter: function (varBag, idService) {
return varBag.model.variables.isInitializedVar;
},
dataType: OS.Types.Boolean
},
"vzzFMQPZKUGQKQsY_n14Eg": {
getter: function (varBag, idService) {
return varBag.model.variables.sourceDataPointListIn;
}
},
"YUlMWMIqqEeAG5Osu70vEA": {
getter: function (varBag, idService) {
return varBag.model.variables.heightIn;
},
dataType: OS.Types.Integer
},
"0OAuaIhkz0if99GxlVE0LQ": {
getter: function (varBag, idService) {
return varBag.model.variables.legendPositionIdIn;
},
dataType: OS.Types.Text
},
"sVgYM2ypLkamYU+PhFLJMg": {
getter: function (varBag, idService) {
return varBag.model.variables.chartFormatIn;
}
},
"Ejz272hbSkCfqWHlDmWluw": {
getter: function (varBag, idService) {
return varBag.model.variables.clickableIn;
},
dataType: OS.Types.Boolean
},
"YR+N7bv46EecdpuqcFmxyw": {
getter: function (varBag, idService) {
return varBag.model.variables.advancedFormatIn;
}
},
"RCABWDInAkus8CAdhl9FqA": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("ChartContainer"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
