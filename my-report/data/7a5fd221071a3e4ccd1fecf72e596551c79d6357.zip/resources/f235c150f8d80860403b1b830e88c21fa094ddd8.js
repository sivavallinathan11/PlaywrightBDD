﻿define("LazyDropdownSearch.controller$FocusOnElement", ["exports", "OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "LazyDropdownSearch.controller$FocusOnElement.FocusOnInputJS"], function (exports, OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, LazyDropdownSearch_controller_FocusOnElement_FocusOnInputJS) {
var OS = OutSystems.Internal;
LazyDropdownSearchController.default.focusOnElement$Action = function (idIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.FocusOnElement$vars"))());
vars.value.idInLocal = idIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:YyRyEGIIYk6mQLKdEgeABg:/ClientActionFlows.YyRyEGIIYk6mQLKdEgeABg:SHT+OAu3sYGhf4l7dhSdxA", "LazyDropdownSearch", "FocusOnElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:yssekv9gL0+PHxY6muq1IQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:eCLf3HKefkCosqE4PbMvTQ", callContext.id);
controller.safeExecuteJSNode(LazyDropdownSearch_controller_FocusOnElement_FocusOnInputJS, "FocusOnInput", "FocusOnElement", {
InputWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.idInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:RCoFdowAskywXQYgKPch4g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:YyRyEGIIYk6mQLKdEgeABg", callContext.id);
}

};
var controller = LazyDropdownSearchController.default;
LazyDropdownSearchController.default.constructor.registerVariableGroupType("LazyDropdownSearch.FocusOnElement$vars", [{
name: "Id",
attrName: "idInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
LazyDropdownSearchController.default.clientActionProxies.focusOnElement$Action = function (idIn) {
idIn = (idIn === undefined) ? "" : idIn;
return controller.executeActionInsideJSNode(LazyDropdownSearchController.default.focusOnElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(idIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("LazyDropdownSearch.controller$FocusOnElement.FocusOnInputJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function () {document.getElementById($parameters.InputWidgetId).focus();}, 200);

};
});

define("LazyDropdownSearch.controller$ScrollToElement", ["exports", "OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller", "LazyDropdownSearch.controller$ScrollToElement.ScrollToElementJS"], function (exports, OutSystems, LazyDropdownSearchModel, LazyDropdownSearchController, LazyDropdownSearch_controller_ScrollToElement_ScrollToElementJS) {
var OS = OutSystems.Internal;
LazyDropdownSearchController.default.scrollToElement$Action = function (idIn, isScrollToTopIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("LazyDropdownSearch.ScrollToElement$vars"))());
vars.value.idInLocal = idIn;
vars.value.isScrollToTopInLocal = isScrollToTopIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("is1HXMHMV0Ott1BMjYZcLg:6Y8uFHiq00y786FcY_f2Sg:/ClientActionFlows.6Y8uFHiq00y786FcY_f2Sg:QVYgopKcpi+MY+oqLf0srg", "LazyDropdownSearch", "ScrollToElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:uqpCgOQ0g06EKW+h+xpeUw", callContext.id);
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:4ZIFfnBvhE6birwIaBuKyA", callContext.id);
controller.safeExecuteJSNode(LazyDropdownSearch_controller_ScrollToElement_ScrollToElementJS, "ScrollToElement", "ScrollToElement", {
InputWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.idInLocal, OS.Types.Text),
IsScrollToTop: OS.DataConversion.JSNodeParamConverter.to(vars.value.isScrollToTopInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("is1HXMHMV0Ott1BMjYZcLg:eE+Si_CqMEG75TPLwS38Zw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("is1HXMHMV0Ott1BMjYZcLg:6Y8uFHiq00y786FcY_f2Sg", callContext.id);
}

};
var controller = LazyDropdownSearchController.default;
LazyDropdownSearchController.default.constructor.registerVariableGroupType("LazyDropdownSearch.ScrollToElement$vars", [{
name: "Id",
attrName: "idInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsScrollToTop",
attrName: "isScrollToTopInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
LazyDropdownSearchController.default.clientActionProxies.scrollToElement$Action = function (idIn, isScrollToTopIn) {
idIn = (idIn === undefined) ? "" : idIn;
isScrollToTopIn = (isScrollToTopIn === undefined) ? true : isScrollToTopIn;
return controller.executeActionInsideJSNode(LazyDropdownSearchController.default.scrollToElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(idIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isScrollToTopIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("LazyDropdownSearch.controller$ScrollToElement.ScrollToElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
setTimeout(function () {document.getElementById($parameters.InputWidgetId).scrollIntoViewIfNeeded($parameters.IsScrollToTop);}, 200);

};
});

define("LazyDropdownSearch.controller", ["exports", "OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.controller$debugger"], function (exports, OutSystems, LazyDropdownSearchModel, LazyDropdownSearch_Controller_debugger) {
var OS = OutSystems.Internal;
var LazyDropdownSearchController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return LazyDropdownSearchController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
LazyDropdownSearchController.default = new Controller(null, "LazyDropdownSearch");
});
define("LazyDropdownSearch.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"g_AYU5s5DEWPtzhOkwSxnA": {
getter: function (varBag, idService) {
return varBag.vars.value.idInLocal;
},
dataType: OS.Types.Text
},
"eCLf3HKefkCosqE4PbMvTQ": {
getter: function (varBag, idService) {
return varBag.focusOnInputJSResult.value;
}
},
"Q97nh9XWOEGLl+svFcDfpQ": {
getter: function (varBag, idService) {
return varBag.vars.value.idInLocal;
},
dataType: OS.Types.Text
},
"+5EvOrNaHkO4Oag5UFe7pQ": {
getter: function (varBag, idService) {
return varBag.vars.value.isScrollToTopInLocal;
},
dataType: OS.Types.Boolean
},
"4ZIFfnBvhE6birwIaBuKyA": {
getter: function (varBag, idService) {
return varBag.scrollToElementJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
