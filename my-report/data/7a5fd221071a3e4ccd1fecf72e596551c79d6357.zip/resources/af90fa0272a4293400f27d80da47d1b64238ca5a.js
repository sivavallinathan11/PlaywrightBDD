﻿define("MSD.controller$ChangeSelectAll", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.model$MSD_ItemRec", "MSD.controller$HandleSelectedList", "MSD.model$MSD_ItemList"], function (exports, OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;
MSDController.default.changeSelectAll$Action = function (toSelectIn, listToApllyIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.ChangeSelectAll$vars"))());
vars.value.toSelectInLocal = toSelectIn;
vars.value.listToApllyInLocal = listToApllyIn.clone();
var handleSelectedListVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.ChangeSelectAll$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.handleSelectedListVar = handleSelectedListVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:X+XJZwyf10WFhBFMAdEavw:/ClientActionFlows.X+XJZwyf10WFhBFMAdEavw:HQUGo_aUiAdlmVuYuc3S0g", "MSD", "ChangeSelectAll", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:sUz5_J9fI0mbDsF0ZwL+8A", callContext.id);
// Foreach ListToAplly
callContext.iterationContext.registerIterationStart(vars.value.listToApllyInLocal);
try {var listToApllyIterator = callContext.iterationContext.getIterator(vars.value.listToApllyInLocal);
var listToApllyIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:2UX0xVT4ZEGfX9Vl9+UiNQ", callContext.id) && (listToApllyIndex < vars.value.listToApllyInLocal.length))) {
listToApllyIterator.currentRowNumber = listToApllyIndex;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:MGIVKsXDF0CdITuusZm_aA", callContext.id);
// ListToAplly.Current.IsSelected = If
vars.value.listToApllyInLocal.getItem(listToApllyIndex.valueOf()).isSelectedAttr = ((vars.value.listToApllyInLocal.getItem(listToApllyIndex.valueOf()).isDisabledAttr) ? (false) : (vars.value.toSelectInLocal));
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:fRecschpB0qVF8ZWsOa59g", callContext.id);
// Execute Action: HandleSelectedList
handleSelectedListVar.value = MSDController.default.handleSelectedList$Action(vars.value.listToApllyInLocal.getItem(listToApllyIndex.valueOf()), vars.value.selectedItemsVar, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:g6857VLAzU6genlAoZ5lbQ", callContext.id);
// SelectedItems = HandleSelectedList.SelectedItems
vars.value.selectedItemsVar = handleSelectedListVar.value.selectedItemsOut;
listToApllyIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.listToApllyInLocal);
}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:M2Xaue0Rtke54PZHo2HJzA", callContext.id);
// List = ListToAplly
outVars.value.listOut = vars.value.listToApllyInLocal;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:M2Xaue0Rtke54PZHo2HJzA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// SelectedList = SelectedItems
outVars.value.selectedListOut = vars.value.selectedItemsVar;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:+yda3WGA7UGRQZUHQdKmcA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:X+XJZwyf10WFhBFMAdEavw", callContext.id);
}

};
var controller = MSDController.default;
MSDController.default.constructor.registerVariableGroupType("MSD.ChangeSelectAll$vars", [{
name: "ToSelect",
attrName: "toSelectInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ListToAplly",
attrName: "listToApllyInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new MSDModel.MSD_ItemList();
},
complexType: MSDModel.MSD_ItemList
}, {
name: "SelectedItems",
attrName: "selectedItemsVar",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
MSDController.default.constructor.registerVariableGroupType("MSD.ChangeSelectAll$outVars", [{
name: "List",
attrName: "listOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new MSDModel.MSD_ItemList();
},
complexType: MSDModel.MSD_ItemList
}, {
name: "SelectedList",
attrName: "selectedListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
MSDController.default.clientActionProxies.changeSelectAll$Action = function (toSelectIn, listToApllyIn) {
toSelectIn = (toSelectIn === undefined) ? false : toSelectIn;
listToApllyIn = (listToApllyIn === undefined) ? new MSDModel.MSD_ItemList() : listToApllyIn;
return controller.executeActionInsideJSNode(MSDController.default.changeSelectAll$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(toSelectIn, OS.Types.Boolean), listToApllyIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
List: actionResults.listOut,
SelectedList: actionResults.selectedListOut
};
});
};
});

define("MSD.controller$CheckIfAllSelected", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.model$MSD_ItemList"], function (exports, OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;
MSDController.default.checkIfAllSelected$Action = function (selectedListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.CheckIfAllSelected$vars"))());
vars.value.selectedListInLocal = selectedListIn.clone();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.CheckIfAllSelected$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:YFmm0aE9ikqgwm9_6YsLpA:/ClientActionFlows.YFmm0aE9ikqgwm9_6YsLpA:oE46aUWBOi3txjcwx8swjA", "MSD", "CheckIfAllSelected", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:d+oyhPF5ZkCrczK5y1MwEQ", callContext.id);
// Foreach SelectedList
callContext.iterationContext.registerIterationStart(vars.value.selectedListInLocal);
try {var selectedListIterator = callContext.iterationContext.getIterator(vars.value.selectedListInLocal);
var selectedListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:nAsotBhsMUGE+BPEfHxm4Q", callContext.id) && (selectedListIndex < vars.value.selectedListInLocal.length))) {
selectedListIterator.currentRowNumber = selectedListIndex;
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:XKRV4tIijUGs6fJYb8jTHg", callContext.id) && !((vars.value.selectedListInLocal.getItem(selectedListIndex.valueOf()).isSelectedAttr || vars.value.selectedListInLocal.getItem(selectedListIndex.valueOf()).isDisabledAttr)))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:KZO0oenkikeuY34qdAtqGw", callContext.id);
// AllSelected = False
outVars.value.allSelectedOut = false;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:BZ++0EH2F0mcUp44R2iWag", callContext.id);
return outVars.value;

}

selectedListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(vars.value.selectedListInLocal);
}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:GwwAGQlRK0qeaXPd32s1pg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:YFmm0aE9ikqgwm9_6YsLpA", callContext.id);
}

};
var controller = MSDController.default;
MSDController.default.constructor.registerVariableGroupType("MSD.CheckIfAllSelected$vars", [{
name: "SelectedList",
attrName: "selectedListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new MSDModel.MSD_ItemList();
},
complexType: MSDModel.MSD_ItemList
}]);
MSDController.default.constructor.registerVariableGroupType("MSD.CheckIfAllSelected$outVars", [{
name: "AllSelected",
attrName: "allSelectedOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
MSDController.default.clientActionProxies.checkIfAllSelected$Action = function (selectedListIn) {
selectedListIn = (selectedListIn === undefined) ? new MSDModel.MSD_ItemList() : selectedListIn;
return controller.executeActionInsideJSNode(MSDController.default.checkIfAllSelected$Action.bind(controller, selectedListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AllSelected: OS.DataConversion.JSNodeParamConverter.to(actionResults.allSelectedOut, OS.Types.Boolean)
};
});
};
});

define("MSD.controller$HandleSelectedList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.model$MSD_ItemRec"], function (exports, OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;
MSDController.default.handleSelectedList$Action = function (itemIn, selectedItemsListIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.HandleSelectedList$vars"))());
vars.value.itemInLocal = itemIn.clone();
vars.value.selectedItemsListInLocal = selectedItemsListIn.clone();
var listIndexOfVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.HandleSelectedList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listIndexOfVar = listIndexOfVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:cuBc+AztPEutNt_5wgnKHg:/ClientActionFlows.cuBc+AztPEutNt_5wgnKHg:RA+yFDFRILtDIu2jgvR54Q", "MSD", "HandleSelectedList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:UM7TJ7g9hkCO5vep1fn3Og", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:gpDbWmPCMUKPoKxh4GmrYg", callContext.id) && vars.value.itemInLocal.isSelectedAttr)) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:rEZusnQ140OqJJw706R4Rw", callContext.id);
// Execute Action: ListAppend
OS.SystemActions.listAppend(vars.value.selectedItemsListInLocal, vars.value.itemInLocal.itemIdAttr, callContext);
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:x+dDx2RN8Uuk9Ed2y8KUuw", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(vars.value.selectedItemsListInLocal, function (p) {
return (p === vars.value.itemInLocal.itemIdAttr);
}, callContext);

if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:CE5nhVsTYUS0YIXjkIJNpQ", callContext.id) && ((listIndexOfVar.value.positionOut) !== (-1)))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:4LaEE7ZmZ0eM6NlQq0vhlg", callContext.id);
// Execute Action: ListRemove
OS.SystemActions.listRemove(vars.value.selectedItemsListInLocal, listIndexOfVar.value.positionOut, callContext);
}

}

// Output Variables
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:TYlXHQhcKkqIn+iuWO8h_w", callContext.id);
// SelectedItems = SelectedItemsList
outVars.value.selectedItemsOut = vars.value.selectedItemsListInLocal;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:jagPBFj9uEWJPZbFmdSnfQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:cuBc+AztPEutNt_5wgnKHg", callContext.id);
}

};
var controller = MSDController.default;
MSDController.default.constructor.registerVariableGroupType("MSD.HandleSelectedList$vars", [{
name: "Item",
attrName: "itemInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new MSDModel.MSD_ItemRec();
},
complexType: MSDModel.MSD_ItemRec
}, {
name: "SelectedItemsList",
attrName: "selectedItemsListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
MSDController.default.constructor.registerVariableGroupType("MSD.HandleSelectedList$outVars", [{
name: "SelectedItems",
attrName: "selectedItemsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}]);
MSDController.default.clientActionProxies.handleSelectedList$Action = function (itemIn, selectedItemsListIn) {
itemIn = (itemIn === undefined) ? new MSDModel.MSD_ItemRec() : itemIn;
selectedItemsListIn = (selectedItemsListIn === undefined) ? new OS.DataTypes.TextList() : selectedItemsListIn;
return controller.executeActionInsideJSNode(MSDController.default.handleSelectedList$Action.bind(controller, itemIn, selectedItemsListIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
SelectedItems: actionResults.selectedItemsOut
};
});
};
});

define("MSD.controller$ManageEllipsis", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller"], function (exports, OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;
MSDController.default.manageEllipsis$Action = function (inputTextIn, maxCharBeforeEllipsisIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.ManageEllipsis$vars"))());
vars.value.inputTextInLocal = inputTextIn;
vars.value.maxCharBeforeEllipsisInLocal = maxCharBeforeEllipsisIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.ManageEllipsis$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:cEbsEyFbKUKFr9DTTdSTHg:/ClientActionFlows.cEbsEyFbKUKFr9DTTdSTHg:jGlQGO4Vtptas7ZBsPwq7Q", "MSD", "ManageEllipsis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:RnlijhEylU6ww8H+couYDg", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:14tm+jldakO1aMugBHOMSw", callContext.id) && (OS.BuiltinFunctions.length(vars.value.inputTextInLocal) > vars.value.maxCharBeforeEllipsisInLocal))) {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:jePqDRtU2ESNILJucvKdzw", callContext.id);
// ProcessedText = Substr + "..."
outVars.value.processedTextOut = (OS.BuiltinFunctions.substr(vars.value.inputTextInLocal, 0, vars.value.maxCharBeforeEllipsisInLocal) + "...");
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:9HK89Aie2EuG9EV3EzAqHw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:+NLcsBYhI0u5ujT9NysSCQ", callContext.id);
// ProcessedText = InputText
outVars.value.processedTextOut = vars.value.inputTextInLocal;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:9HK89Aie2EuG9EV3EzAqHw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:cEbsEyFbKUKFr9DTTdSTHg", callContext.id);
}

};
var controller = MSDController.default;
MSDController.default.constructor.registerVariableGroupType("MSD.ManageEllipsis$vars", [{
name: "InputText",
attrName: "inputTextInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MaxCharBeforeEllipsis",
attrName: "maxCharBeforeEllipsisInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
MSDController.default.constructor.registerVariableGroupType("MSD.ManageEllipsis$outVars", [{
name: "ProcessedText",
attrName: "processedTextOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
MSDController.default.clientActionProxies.manageEllipsis$Action = function (inputTextIn, maxCharBeforeEllipsisIn) {
inputTextIn = (inputTextIn === undefined) ? "" : inputTextIn;
maxCharBeforeEllipsisIn = (maxCharBeforeEllipsisIn === undefined) ? 0 : maxCharBeforeEllipsisIn;
return controller.executeActionInsideJSNode(MSDController.default.manageEllipsis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(inputTextIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(maxCharBeforeEllipsisIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ProcessedText: OS.DataConversion.JSNodeParamConverter.to(actionResults.processedTextOut, OS.Types.Text)
};
});
};
});

define("MSD.controller$SelectItemsInList", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller", "MSD.model$MSD_ItemList"], function (exports, OutSystems, MSDModel, MSDController) {
var OS = OutSystems.Internal;
MSDController.default.selectItemsInList$Action = function (selectedListIn, listToApplyIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.SelectItemsInList$vars"))());
vars.value.selectedListInLocal = selectedListIn.clone();
vars.value.listToApplyInLocal = listToApplyIn.clone();
var listIndexOfVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("MSD.SelectItemsInList$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.listIndexOfVar = listIndexOfVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("CLNmk7qA3kKckRWSN6k5Bw:dGzxd4bZ9EWpivsoPRZYPg:/ClientActionFlows.dGzxd4bZ9EWpivsoPRZYPg:TnuMKnX+Z2+cR8FebzU96A", "MSD", "SelectItemsInList", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:JLQnJTezQUKyIXnaKG8kGw", callContext.id);
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:yUhusVTlXU+GeCT5MeYSRA", callContext.id);
// ProcessedList = ListToApply
outVars.value.processedListOut = vars.value.listToApplyInLocal;
// Foreach ProcessedList
callContext.iterationContext.registerIterationStart(outVars.value.processedListOut);
try {var processedListIterator = callContext.iterationContext.getIterator(outVars.value.processedListOut);
var processedListIndex = 0;
while ((OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:kvMysx_Y3kGIe9CewxZusA", callContext.id) && (processedListIndex < outVars.value.processedListOut.length))) {
processedListIterator.currentRowNumber = processedListIndex;
OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:hjvtyqsc3E2ltY0Hcve01g", callContext.id);
// Execute Action: ListIndexOf
listIndexOfVar.value = OS.SystemActions.listIndexOf(vars.value.selectedListInLocal, function (p) {
return (p === outVars.value.processedListOut.getItem(processedListIndex.valueOf()).itemIdAttr);
}, callContext);

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:3xycwB_uSkif_VHlUak0pA", callContext.id);
// ProcessedList.Current.IsSelected = ListIndexOf.Position > -1
outVars.value.processedListOut.getItem(processedListIndex.valueOf()).isSelectedAttr = (listIndexOfVar.value.positionOut > -1);
processedListIndex++;
}

} finally {
callContext.iterationContext.registerIterationEnd(outVars.value.processedListOut);
}

OutSystemsDebugger.handleBreakpoint("CLNmk7qA3kKckRWSN6k5Bw:+WIu1E8ERkCtX3FV_49mUA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("CLNmk7qA3kKckRWSN6k5Bw:dGzxd4bZ9EWpivsoPRZYPg", callContext.id);
}

};
var controller = MSDController.default;
MSDController.default.constructor.registerVariableGroupType("MSD.SelectItemsInList$vars", [{
name: "SelectedList",
attrName: "selectedListInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OS.DataTypes.TextList();
},
complexType: OS.DataTypes.TextList
}, {
name: "ListToApply",
attrName: "listToApplyInLocal",
mandatory: true,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new MSDModel.MSD_ItemList();
},
complexType: MSDModel.MSD_ItemList
}]);
MSDController.default.constructor.registerVariableGroupType("MSD.SelectItemsInList$outVars", [{
name: "ProcessedList",
attrName: "processedListOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new MSDModel.MSD_ItemList();
},
complexType: MSDModel.MSD_ItemList
}]);
MSDController.default.clientActionProxies.selectItemsInList$Action = function (selectedListIn, listToApplyIn) {
selectedListIn = (selectedListIn === undefined) ? new OS.DataTypes.TextList() : selectedListIn;
listToApplyIn = (listToApplyIn === undefined) ? new MSDModel.MSD_ItemList() : listToApplyIn;
return controller.executeActionInsideJSNode(MSDController.default.selectItemsInList$Action.bind(controller, selectedListIn, listToApplyIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
ProcessedList: actionResults.processedListOut
};
});
};
});

define("MSD.controller", ["exports", "OutSystems/ClientRuntime/Main", "MSD.model", "MSD.controller$debugger"], function (exports, OutSystems, MSDModel, MSD_Controller_debugger) {
var OS = OutSystems.Internal;
var MSDController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return MSDController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
MSDController.default = new Controller(null, "MSD");
});
define("MSD.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"vSt+K2AaFkCmBSJ8IbreUA": {
getter: function (varBag, idService) {
return varBag.vars.value.inputTextInLocal;
},
dataType: OS.Types.Text
},
"OtPHduacgECKoYu73FZ_zA": {
getter: function (varBag, idService) {
return varBag.vars.value.maxCharBeforeEllipsisInLocal;
},
dataType: OS.Types.Integer
},
"uEvpXAfL9UaxTwBuZ8mtAA": {
getter: function (varBag, idService) {
return varBag.outVars.value.processedTextOut;
},
dataType: OS.Types.Text
},
"dL8XFkueY0OBxjudKT53dA": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedItemsVar;
}
},
"7uZxAr87vEq1HEssayARlw": {
getter: function (varBag, idService) {
return varBag.vars.value.toSelectInLocal;
},
dataType: OS.Types.Boolean
},
"GWvQ9XcGcke6q+2ihcLFZw": {
getter: function (varBag, idService) {
return varBag.vars.value.listToApllyInLocal;
}
},
"0UF+EujTLEWQ8n+FenhEFA": {
getter: function (varBag, idService) {
return varBag.outVars.value.listOut;
}
},
"PGFNO9MEF0a+4BDoc0BEIw": {
getter: function (varBag, idService) {
return varBag.outVars.value.selectedListOut;
}
},
"fRecschpB0qVF8ZWsOa59g": {
getter: function (varBag, idService) {
return varBag.handleSelectedListVar.value;
}
},
"KhqBQcAqEU6tpP8_YO4r0Q": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedListInLocal;
}
},
"o9zkDxzRNkOYiquD_LblMQ": {
getter: function (varBag, idService) {
return varBag.vars.value.listToApplyInLocal;
}
},
"OKeh1orLU0uTqWrVa_G2Dg": {
getter: function (varBag, idService) {
return varBag.outVars.value.processedListOut;
}
},
"hjvtyqsc3E2ltY0Hcve01g": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
},
"unppbIR4vUimylyocQH_Zg": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedListInLocal;
}
},
"BU4qfgAOEkqmHfBHeaQFCw": {
getter: function (varBag, idService) {
return varBag.outVars.value.allSelectedOut;
},
dataType: OS.Types.Boolean
},
"Zh0A9F+z8kONp1crJeXUcQ": {
getter: function (varBag, idService) {
return varBag.vars.value.itemInLocal;
}
},
"wXb12CCOyUW9AWab9_MOsQ": {
getter: function (varBag, idService) {
return varBag.vars.value.selectedItemsListInLocal;
}
},
"DZo8Ks2_M061Qb6b60uq6g": {
getter: function (varBag, idService) {
return varBag.outVars.value.selectedItemsOut;
}
},
"x+dDx2RN8Uuk9Ed2y8KUuw": {
getter: function (varBag, idService) {
return varBag.listIndexOfVar.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
