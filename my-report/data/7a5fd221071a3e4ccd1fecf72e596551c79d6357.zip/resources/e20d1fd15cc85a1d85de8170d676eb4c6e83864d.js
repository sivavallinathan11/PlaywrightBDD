﻿define("PHICore_TH.Layouts.LayoutBlank.mvc$model", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("EnableAccessibilityFeatures", "enableAccessibilityFeaturesIn", "EnableAccessibilityFeatures", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_enableAccessibilityFeaturesInDataFetchStatus", "_enableAccessibilityFeaturesInDataFetchStatus", "_enableAccessibilityFeaturesInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("EnableAccessibilityFeatures" in inputs) {
this.variables.enableAccessibilityFeaturesIn = inputs.EnableAccessibilityFeatures;
if("_enableAccessibilityFeaturesInDataFetchStatus" in inputs) {
this.variables._enableAccessibilityFeaturesInDataFetchStatus = inputs._enableAccessibilityFeaturesInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model, "Layouts.LayoutBlank");
});
define("PHICore_TH.Layouts.LayoutBlank.mvc$view", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "PHICore_TH.Layouts.LayoutBlank.mvc$model", "PHICore_TH.Layouts.LayoutBlank.mvc$controller", "PHICore_TH.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, React, OSView, PHICore_TH_Layouts_LayoutBlank_mvc_model, PHICore_TH_Layouts_LayoutBlank_mvc_controller, PHICore_THClientVariables, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Layouts.LayoutBlank";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/OutSystemsUI.OutSystemsUI.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return PHICore_TH_Layouts_LayoutBlank_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return PHICore_TH_Layouts_LayoutBlank_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: model.getCachedValue(idService.getId("8lEy+z8iXUqB3svMwRxbLw.Style"), function () {
return (("layout blank" + ((!(model.variables.enableAccessibilityFeaturesIn)) ? ("") : (" has-accessible-features"))) + (((model.variables.extendedClassIn === "")) ? ("") : ((" " + model.variables.extendedClassIn))));
}, function () {
return model.variables.enableAccessibilityFeaturesIn;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._enableAccessibilityFeaturesInDataFetchStatus, model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "main"
},
style: "content",
visible: true,
_idProps: {
service: idService,
uuid: "1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.content,
style: "main-content",
_idProps: {
service: idService,
name: "Content"
},
_widgetRecordProvider: widgetsRecordProvider
}))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("PHICore_TH.Layouts.LayoutBlank.mvc$controller", ["OutSystems/ClientRuntime/Main", "PHICore_TH.model", "PHICore_TH.controller", "OutSystemsUI.model", "OutSystemsUI.controller", "PHICore_TH.languageResources", "PHICore_TH.clientVariables", "PHICore_TH.Layouts.LayoutBlank.mvc$debugger", "OutSystemsUI.model$ErrorMessageRec", "PHICore_TH.referencesHealth", "PHICore_TH.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$SetLang", "OutSystemsUI.controller$AddFavicon", "OutSystemsUI.controller$LayoutReady", "OutSystemsUI.controller$LayoutDestroy"], function (OutSystems, PHICore_THModel, PHICore_THController, OutSystemsUIModel, OutSystemsUIController, PHICore_THLanguageResources, PHICore_THClientVariables, PHICore_TH_Layouts_LayoutBlank_mvc_Debugger) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var setLangVar = new OS.DataTypes.VariableHolder();
var addFaviconVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.setLangVar = setLangVar;
varBag.addFaviconVar = addFaviconVar;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:liohM6qCc0mdOGuBiafMYg:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.Lvz40cvMOkqLEG6fU0bYcg/ClientActions.liohM6qCc0mdOGuBiafMYg:XDq8v+XHti_rfMhGck7H8g", "PHICore_TH", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:iR8Vgbps6UyLcVmBiFofeA", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:OmCNmhHGRU2VB0lVbZn0eA", callContext.id);
// Execute Action: LayoutReady
OutSystemsUIController.default.layoutReady$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:s1EzE8zcm0aoIcYSiDNhgA", callContext.id);
// Execute Action: SetLang
setLangVar.value = OutSystemsUIController.default.setLang$Action("", callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:kcMMJV_tS0uwlpasvwjI9Q", callContext.id);
// Execute Action: AddFavicon
addFaviconVar.value = OutSystemsUIController.default.addFavicon$Action("favicon.png", callContext);

OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:PyMbSrJ03U+6PK7udNFoMQ", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:liohM6qCc0mdOGuBiafMYg", callContext.id);
}

};
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:CnOV_pfojUKbFQexjtTCTw:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.Lvz40cvMOkqLEG6fU0bYcg/ClientActions.CnOV_pfojUKbFQexjtTCTw:bOHGmoPYBNWr8Nh43hPeaQ", "PHICore_TH", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:Lo5cbriMYE6r5Rq8uAbNpg", callContext.id);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:+kPrPkau5Um4PI4OycsWRw", callContext.id);
// Execute Action: LayoutDestroy
OutSystemsUIController.default.layoutDestroy$Action(callContext);
OutSystemsDebugger.handleBreakpoint("xrfQpWAZkUyxt+2shA6w4A:KPXM2dEBzkeK7w9THaPo6w", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:CnOV_pfojUKbFQexjtTCTw", callContext.id);
}

};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:h5vDTMuLX06AWEdKRweFvA:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA:lwBqpM5MEmNYSGKQjqDzFw", "PHICore_TH", "Layouts", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("xrfQpWAZkUyxt+2shA6w4A:Lvz40cvMOkqLEG6fU0bYcg:/NRWebFlows.h5vDTMuLX06AWEdKRweFvA/NodesShownInESpaceTree.Lvz40cvMOkqLEG6fU0bYcg:xpO9QX8zXxRk7rVFL3LxBQ", "PHICore_TH", "LayoutBlank", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:Lvz40cvMOkqLEG6fU0bYcg", callContext.id);
OutSystemsDebugger.pop("xrfQpWAZkUyxt+2shA6w4A:h5vDTMuLX06AWEdKRweFvA", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/LayoutBlank On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Layouts/LayoutBlank On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return PHICore_THController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, PHICore_THLanguageResources);
});

define("PHICore_TH.Layouts.LayoutBlank.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"s1EzE8zcm0aoIcYSiDNhgA": {
getter: function (varBag, idService) {
return varBag.setLangVar.value;
}
},
"kcMMJV_tS0uwlpasvwjI9Q": {
getter: function (varBag, idService) {
return varBag.addFaviconVar.value;
}
},
"JDOkVuqzEUuAxLmTdYjfFA": {
getter: function (varBag, idService) {
return varBag.model.variables.enableAccessibilityFeaturesIn;
},
dataType: OS.Types.Boolean
},
"cHMqBhjnRUi4XdiucudZZg": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"2LSq6h5P6UCTE49+x0DQYQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Content"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
