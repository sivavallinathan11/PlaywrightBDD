﻿define("LazyDropdownSearch.model$DropdownItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "LazyDropdownSearch.model", "OutSystemsUI.model$DropdownItemRec", "LazyDropdownSearch.referencesHealth", "LazyDropdownSearch.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, LazyDropdownSearchModel) {
var OS = OutSystems.Internal;
var DropdownItemRecord = (function (_super) {
__extends(DropdownItemRecord, _super);
function DropdownItemRecord(defaults) {
_super.apply(this, arguments);
}
DropdownItemRecord.attributesToDeclare = function () {
return [
this.attr("DropdownItem", "dropdownItemAttr", "DropdownItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DropdownItemRec());
}, true, OutSystemsUIModel.DropdownItemRec)
].concat(_super.attributesToDeclare.call(this));
};
DropdownItemRecord.fromStructure = function (str) {
return new DropdownItemRecord(new DropdownItemRecord.RecordClass({
dropdownItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DropdownItemRecord._isAnonymousRecord = true;
DropdownItemRecord.UniqueId = "56805fde-f633-2e01-f13c-0f9217357dbc";
DropdownItemRecord.init();
return DropdownItemRecord;
})(OS.DataTypes.GenericRecord);
LazyDropdownSearchModel.DropdownItemRecord = DropdownItemRecord;

});
define("LazyDropdownSearch.model$DropdownItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "LazyDropdownSearch.model", "OutSystemsUI.model$DropdownItemRec", "LazyDropdownSearch.referencesHealth", "LazyDropdownSearch.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, LazyDropdownSearchModel) {
var OS = OutSystems.Internal;
var DropdownItemList = (function (_super) {
__extends(DropdownItemList, _super);
function DropdownItemList(defaults) {
_super.apply(this, arguments);
}
DropdownItemList.itemType = OutSystemsUIModel.DropdownItemRec;
return DropdownItemList;
})(OS.DataTypes.GenericRecordList);
LazyDropdownSearchModel.DropdownItemList = DropdownItemList;

});
define("LazyDropdownSearch.model$DropdownItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "LazyDropdownSearch.model", "LazyDropdownSearch.model$DropdownItemRecord"], function (exports, OutSystems, LazyDropdownSearchModel) {
var OS = OutSystems.Internal;
var DropdownItemRecordList = (function (_super) {
__extends(DropdownItemRecordList, _super);
function DropdownItemRecordList(defaults) {
_super.apply(this, arguments);
}
DropdownItemRecordList.itemType = LazyDropdownSearchModel.DropdownItemRecord;
return DropdownItemRecordList;
})(OS.DataTypes.GenericRecordList);
LazyDropdownSearchModel.DropdownItemRecordList = DropdownItemRecordList;

});
define("LazyDropdownSearch.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var LazyDropdownSearchModel = exports;
Object.defineProperty(LazyDropdownSearchModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["5c47cd8a-ccc1-4357-adb7-504c8d865c2e"];
}
});

LazyDropdownSearchModel.staticEntities = {};
});
