﻿define("SandBoxLogin.referencesHealth$AccessControl_CS", [], function () {
// Reference to producer 'AccessControl_CS' is OK.
});
define("SandBoxLogin.referencesHealth$Common_CS", [], function () {
// Reference to producer 'Common_CS' is OK.
});
define("SandBoxLogin.referencesHealth$OutSystemsUI", [], function () {
// Reference to producer 'OutSystemsUI' is OK.
});
define("SandBoxLogin.referencesHealth$PHICore_TH", [], function () {
// Reference to producer 'PHICore_TH' is OK.
});
define("SandBoxLogin.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("SandBoxLogin.referencesHealth$TenantProvisioning_CS", [], function () {
// Reference to producer 'TenantProvisioning_CS' is OK.
});
define("SandBoxLogin.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("SandBoxLogin.referencesHealth", [], function () {
});
